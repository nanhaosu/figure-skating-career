extends RefCounted
const T=preload("res://tests/test_support.gd")
const Codec=preload("res://src/persistence/competition_archive_codec.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"cold packed validation avoids a second full protocol tree","callable":allocation},
		{"name":"committing a large career does not serialize its copied state for field names","callable":commit_allocation},
		{"name":"validation preserves caller metadata and rejects post-cache index changes","callable":integrity}]
func allocation():
	var output: Array=[]
	var code:=OS.execute(OS.get_executable_path(),["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/fixtures/archive_validation_memory_probe.gd"],output,true)
	for chunk in output: print(str(chunk))
	T.assert_equal(code,0,"cold validation of 20k nested telemetry rows must stay within 50 MiB additional engine allocation")
func commit_allocation():
	var output: Array=[]
	var code:=OS.execute(OS.get_executable_path(),["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/fixtures/career_commit_memory_probe.gd"],output,true)
	for chunk in output: print(str(chunk))
	T.assert_equal(code,0,"publishing an existing state must not make a deep copy of 40k snapshot rows merely to enumerate fields")
func integrity():
	var raw: Dictionary={"status":"complete","seed":17,"roster":[{"athlete_id":"qa","athlete":{"samples":[{"part_index":2.0,"value":1.123456789123}]}}],"short_results":{"qa":{"protocol":{"total":0.0}}},"free_results":{"qa":{"protocol":{"total":0.0}}},"extension":{"from":2.0,"unknown":["retained",1.25]}}
	var packed:=Codec.compact(raw)
	Codec._validated_payloads.clear()
	var before:=JSON.stringify(packed,"",true,true)
	T.assert_equal(Codec.validate(packed),"")
	T.assert_equal(JSON.stringify(packed,"",true,true),before,"validation cannot normalize or mutate the supplied index")
	var expanded:=Codec.expand(packed)
	T.assert_equal(expanded.extension.unknown,raw.extension.unknown)
	T.assert_equal(expanded.roster[0].athlete.samples[0].value,raw.roster[0].athlete.samples[0].value,"historical numeric payload must remain exact")
	packed.extension.unknown.append("changed")
	T.assert_equal(Codec.validate(packed).is_empty(),false,"changing unknown public metadata must invalidate an earlier cache hit")
