extends RefCounted
const T=preload("res://tests/test_support.gd")
const F=preload("res://tests/fixtures.gd")
const Repo=preload("res://src/persistence/save_repository.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"long history save avoids a whole-career JSON string without pruning rows","callable":memory},
		{"name":"chunked save emits the existing exact sorted full-precision JSON representation","callable":wire_bytes},
		{"name":"streamed section keys preserve mixed names and native numeric-key fallback","callable":section_keys}]
func memory():
	var output: Array=[]
	var code:=OS.execute(OS.get_executable_path(),["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/fixtures/streaming_save_memory_probe.gd"],output,true)
	for chunk in output: print(str(chunk))
	T.assert_equal(code,0,"saving 16k history rows must stay below 64 MiB extra allocation and preserve every row")
func wire_bytes():
	var career=F.starting_career(18214)
	career.history.append({"category":"qa","target":"history","delta":0.125,"cause_codes":[],"summary_key":"qa","未知\n\"键":{"2":"中文 😀 \\ /","10":[null,true,false,1.123456789123,-0.0],"a":{17:"numeric-key",&"named":"string-name"}}})
	var before:=JSON.stringify(career.to_dict(),"",true,true)
	var path: String="user://streaming-wire-%d.json" % Time.get_ticks_usec()
	var saved: Dictionary=Repo.save(career,path,false)
	T.assert_equal(saved.ok,true)
	if not saved.ok:return
	var actual:=FileAccess.get_file_as_string(path)
	var parsed: Dictionary=JSON.parse_string(actual)
	var expected: String=JSON.stringify({"save_version":Repo.SAVE_VERSION,"saved_at_unix":parsed.saved_at_unix,"career":saved.canonical_state},"",true,true)
	T.assert_equal(actual==expected,true,"existing readers, sorting, escaping and numeric formatting must see the same JSON bytes")
	T.assert_equal(JSON.stringify(career.to_dict(),"",true,true),before,"pre-ack writing must not mutate the caller")
func section_keys():
	for numeric in [false,true]:
		var career=F.starting_career(18215)
		career.world_state[&"qa_named"]="中文"
		career.world_state["qa_string"]="escaped\n\""
		if numeric: career.world_state[17]="numeric key"
		var path: String="user://streaming-keys-%d-%s.json" % [Time.get_ticks_usec(),str(numeric)]
		var saved: Dictionary=Repo.save(career,path,false)
		T.assert_equal(saved.ok,true)
		if not saved.ok:continue
		var actual:=FileAccess.get_file_as_string(path)
		var parsed: Dictionary=JSON.parse_string(actual)
		var expected: String=JSON.stringify({"save_version":Repo.SAVE_VERSION,"saved_at_unix":parsed.saved_at_unix,"career":saved.canonical_state},"",true,true)
		if actual!=expected:
			for index in mini(actual.length(),expected.length()):
				if actual[index]!=expected[index]:
					print("WIRE DIFFERENCE numeric=",numeric," index=",index," actual=",actual.substr(maxi(0,index-40),120)," expected=",expected.substr(maxi(0,index-40),120))
					break
		T.assert_equal(actual==expected,true,"section key ordering/conversion must match native JSON exactly")
