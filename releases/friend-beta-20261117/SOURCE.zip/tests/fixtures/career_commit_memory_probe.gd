extends SceneTree
func _initialize():
	var f=load("res://tests/fixtures.gd")
	var source=f.starting_career(18211)
	var target=f.starting_career(18212)
	var rows: Array=[]
	for i in 40000: rows.append({"value":float(i)/100.0,"state":{"rank":i}})
	source.world_athletes["large_snapshot"]={"samples":rows}
	var before:=OS.get_static_memory_usage()
	target.commit_from(source)
	var delta:=OS.get_static_memory_peak_usage()-before
	var same: bool=is_same(target.world_athletes,source.world_athletes) and target.seed==source.seed and target.world_athletes.large_snapshot.samples.size()==40000
	print("ALLOCATION commit_peak_delta=",delta," budget=",8*1024*1024," state_preserved=",same)
	quit(0 if same and delta<=8*1024*1024 else 1)
