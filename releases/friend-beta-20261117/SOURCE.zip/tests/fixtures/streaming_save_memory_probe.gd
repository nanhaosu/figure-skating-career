extends SceneTree
func _initialize():
	# This allocation probe owns this exact temporary save family and measures
	# a fresh write; previous test runs must not add a cold-primary reload.
	for suffix in ["",".bak",".tmp"]:
		var path: String="user://streaming-memory.json"+suffix
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	var career=load("res://tests/fixtures.gd").starting_career(18213)
	var note := "history-"+"x".repeat(1016)
	for i in 16000:
		career.history.append({"category":"qa","target":"history","delta":0.0,"cause_codes":[],"summary_key":"qa","note":note,"sequence":i})
	var repo=load("res://src/persistence/save_repository.gd")
	var before:=OS.get_static_memory_usage()
	var saved: Dictionary=repo.save(career,"user://streaming-memory.json",false)
	var delta:=OS.get_static_memory_peak_usage()-before
	print("ALLOCATION save_peak_delta=",delta," budget=",64*1024*1024," save_ok=",saved.ok," errors=",saved.errors)
	var loaded: Dictionary=repo.load_save("user://streaming-memory.json")
	var same: bool=loaded.ok and loaded.career.history.size()==career.history.size() and loaded.career.history[-1].note==note and int(loaded.career.history[-1].sequence)==15999
	print("HISTORY complete=",same)
	quit(0 if saved.ok and same and delta<=64*1024*1024 else 1)
