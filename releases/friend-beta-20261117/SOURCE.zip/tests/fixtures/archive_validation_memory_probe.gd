extends SceneTree
func _initialize():
	var row := '{"part_index":2,"point_index":3,"x":0.25,"y":0.75,"value":1.125,"extra":{"from":1,"to":2}},'
	var records := row.repeat(20000).trim_suffix(",")
	var raw := '{"status":"complete","seed":17,"roster":[{"athlete_id":"qa","athlete":{"samples":['+records+']}}],"short_results":{"qa":{"protocol":{"total":0}}},"free_results":{"qa":{"protocol":{"total":0}}}}'
	records=""
	var codec=load("res://src/persistence/competition_archive_codec.gd")
	var scores := {"qa":{"score":{"total":0,"tes":0,"pcs":0,"deductions":0,"domestic_bonus":0}}}
	var payload := Marshalls.raw_to_base64(raw.to_utf8_buffer().compress(FileAccess.COMPRESSION_GZIP))
	var archive := {"status":"complete","seed":17,"roster":[{"athlete_id":"qa"}],"short_results":scores,"free_results":scores.duplicate(true),"packed_archive":{"version":1,"encoding":"gzip_base64","raw_bytes":raw.to_utf8_buffer().size(),"sha256":raw.sha256_text(),"payload":payload,"payload_sha256":payload.sha256_text()}}
	raw="";payload=""
	var before := OS.get_static_memory_usage()
	var error: String=codec.validate(archive)
	var delta := OS.get_static_memory_peak_usage()-before
	print("ALLOCATION validation_peak_delta=",delta," budget=",50*1024*1024," error=",error)
	quit(0 if error.is_empty() and delta<=50*1024*1024 else 1)
