class_name SaveRepository
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const SaveMigrator = preload("res://src/persistence/save_migrator.gd")
const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const SaveSchema = preload("res://src/persistence/save_schema.gd")
const StoryContext = preload("res://src/domain/story_context.gd")
const RandomStreamState = preload("res://src/domain/random_stream_state.gd")
const SeasonEntryPlan = preload("res://src/domain/season_entry_plan.gd")
const NumericState = preload("res://src/persistence/numeric_state.gd")
const TrainingIntent = preload("res://src/domain/training_intent.gd")
const TrainingPolicy = preload("res://src/domain/training_policy.gd")

const SAVE_VERSION := SaveSchema.CURRENT_VERSION
const JUMP_FOUNDATION_METRICS := ["takeoff_power", "speed_conversion", "timing", "air_axis", "air_tightness", "spatial_awareness", "rotation_completion", "landing_control", "landing_flow"]
const REQUIRED_SAVE_KEYS := ["save_version", "saved_at_unix", "career"]
const REQUIRED_CAREER_KEYS := ["schema_version", "seed", "rng_step", "story_context", "random_streams", "clock", "athlete", "relationships", "history", "pre_career_history", "opening_stage", "career_goal", "training_period_state", "coach_assignment", "training_preferences", "last_training_policy", "last_generated_plan", "season_state", "world_athletes", "competition_archive", "record_book", "ranking_state", "internal_invitation_state", "certification_state", "condition_state", "social_state", "selection_state", "event_ledger", "world_state"]
const ATHLETE_METRICS := {
	"technique": ["rotation", "landing", "single_jumps"],
	"skating": ["speed", "flow", "one_foot_stability", "deep_edge", "turns", "knee_action", "ice_efficiency"],
	"body": ["acute_fatigue", "cumulative_fatigue", "ankle_load", "growth_trend", "impact_load", "strength_readiness", "joint_readiness", "recovery_capacity", "energy_availability_signal"],
	"mind": ["motivation", "training_fear"],
	"resources": ["money", "ice_access"],
}
const RELATIONSHIP_FIELDS := ["closeness", "professional_trust", "control", "health_priority"]
const OUTCOME_FIELDS := ["category", "target", "delta", "cause_codes", "summary_key"]
static var _verified_hashes: Dictionary = {}

class JSONByteCounter extends RefCounted:
	var size: int = 0
	func store_buffer(bytes: PackedByteArray) -> void:
		size += bytes.size()

static func save(career: CareerState, path: String, publish: bool = true) -> Dictionary:
	if career == null:
		return _failure("没有可保存的生涯数据")
	var payload := _save_payload(career)
	var validation_error := _validate_payload(payload)
	if not validation_error.is_empty(): return _failure("临时存档验证失败：%s" % validation_error)
	if not _finite_json_values(payload): return _failure("存档包含非有限数值")
	var canonical_state: Dictionary = NumericState.canonical_copy(payload.career)
	payload.career = canonical_state
	return _write_prepared_save(career,path,publish,payload,canonical_state)

# Yield only while preparing the private candidate. File replacement below
# remains one uninterrupted transaction, with the same checks as sync saves.
static func save_responsive(career: CareerState, path: String, publish: bool = true, progress: Callable = Callable()) -> Dictionary:
	if career == null: return _failure("没有可保存的生涯数据")
	_report_load_progress(progress,"save_preparing",0)
	await Engine.get_main_loop().process_frame
	var payload := _save_payload(career)
	_report_load_progress(progress,"save_validating",15)
	await Engine.get_main_loop().process_frame
	var validation_error := _validate_payload(payload)
	if not validation_error.is_empty(): return _failure("临时存档验证失败：%s" % validation_error)
	_report_load_progress(progress,"save_checking",35)
	await Engine.get_main_loop().process_frame
	if not _finite_json_values(payload): return _failure("存档包含非有限数值")
	_report_load_progress(progress,"save_normalizing",50)
	await Engine.get_main_loop().process_frame
	var canonical_state: Dictionary = NumericState.canonical_copy(payload.career)
	payload.career = canonical_state
	_report_load_progress(progress,"save_encoding",65)
	await Engine.get_main_loop().process_frame
	_report_load_progress(progress,"save_writing",80)
	await Engine.get_main_loop().process_frame
	return _write_prepared_save(career,path,publish,payload,canonical_state)

static func _save_payload(career: CareerState) -> Dictionary:
	var serialized: Dictionary = career.serialization_view()
	# Old saves may contain one last raw completed event. Compact it at the
	# first subsequent save; already packed immutable history is shared.
	var compact_archives: Array = []
	for archive in serialized.competition_archive:
		compact_archives.append(preload("res://src/persistence/competition_archive_codec.gd").compact(archive))
	serialized = serialized.duplicate(false)
	serialized.competition_archive = compact_archives
	return {
		"save_version": SAVE_VERSION,
		"saved_at_unix": Time.get_unix_time_from_system(),
		"career": serialized,
	}

static func _write_prepared_save(career: CareerState, path: String, publish: bool, payload: Dictionary, canonical_state: Dictionary) -> Dictionary:
	var temporary_path := "%s.tmp" % path
	_remove_file_if_present(temporary_path)
	var file := FileAccess.open(temporary_path, FileAccess.WRITE)
	if file == null:
		return _failure("无法写入临时存档：%s" % temporary_path)
	# Encode bounded sections directly to the private candidate. A long JSON
	# save otherwise retains a four-byte-per-character string next to its UTF-8
	# file, canonical state, rollback snapshot and prior committed career.
	var hasher := HashingContext.new()
	if hasher.start(HashingContext.HASH_SHA256) != OK:
		file.close()
		_remove_file_if_present(temporary_path)
		return _failure("无法初始化存档内容校验")
	var counter := JSONByteCounter.new()
	_store_json_value(counter,hasher,payload)
	var expected_hash := hasher.finish().hex_encode()
	# MEMFS repeatedly grows/copies its JS backing buffer for small writes.
	# Reserve the exact UTF-8 length once; the second pass overwrites every
	# byte and the normal disk hash verifies both passes agree before commit.
	if counter.size > 0:
		file.seek(counter.size-1)
		file.store_8(0)
		if file.get_error() != OK:
			file.close()
			_remove_file_if_present(temporary_path)
			return _failure("无法预留临时存档空间")
		file.seek(0)
	_store_json_value(file,null,payload)
	var write_error := file.get_error()
	file.close()
	if write_error != OK:
		_remove_file_if_present(temporary_path)
		return _failure("无法写入临时存档：%s" % temporary_path)
	if FileAccess.get_sha256(temporary_path) != expected_hash:
		_remove_file_if_present(temporary_path)
		return _failure("临时存档验证失败：写入内容校验不一致")
	var backup_path := "%s.bak" % path
	var had_valid_primary := false
	if FileAccess.file_exists(path):
		var existing_error := _verify_payload(path)
		if not existing_error.is_empty():
			_remove_file_if_present(temporary_path)
			return _failure("现有存档验证失败，未覆盖：%s" % existing_error)
		had_valid_primary = true
		if FileAccess.file_exists(backup_path):
			var remove_backup_error := DirAccess.remove_absolute(ProjectSettings.globalize_path(backup_path))
			if remove_backup_error != OK:
				_remove_file_if_present(temporary_path)
				return _failure("无法更新最近备份：%s" % backup_path)
		var backup_error := DirAccess.rename_absolute(
			ProjectSettings.globalize_path(path),
			ProjectSettings.globalize_path(backup_path),
		)
		if backup_error != OK:
			_remove_file_if_present(temporary_path)
			return _failure("无法保留最近备份：%s" % backup_path)
	var replace_error := DirAccess.rename_absolute(
		ProjectSettings.globalize_path(temporary_path),
		ProjectSettings.globalize_path(path),
	)
	if replace_error != OK:
		_remove_file_if_present(temporary_path)
		if had_valid_primary:
			var restore_error := DirAccess.rename_absolute(
				ProjectSettings.globalize_path(backup_path),
				ProjectSettings.globalize_path(path),
			)
			if restore_error != OK:
				return _failure("无法替换存档，原存档仍保留在最近备份：%s" % backup_path)
		return _failure("无法替换存档文件：%s" % path)
	_remember_verified(path,expected_hash)
	if publish: career.commit_from(CareerState.from_dict(canonical_state,true))
	return {"ok": true, "career": career, "errors": [], "canonical_state":canonical_state} if not publish else {"ok":true,"career":career,"errors":[]}

static func _store_json_value(file, hasher: HashingContext, value, depth: int = 0) -> void:
	# The envelope, career sections, then individual archives/athletes/history
	# rows are streamed. Native JSON still owns every leaf's escaping and full
	# float precision. Rare non-string dictionary keys keep native conversion.
	if depth >= 3 or not (value is Dictionary or value is Array):
		_store_json_chunk(file,hasher,JSON.stringify(value,"",true,true))
		return
	if value is Dictionary:
		for key in value:
			if not (key is String or key is StringName):
				_store_json_chunk(file,hasher,JSON.stringify(value,"",true,true))
				return
		var keys: Array=value.keys()
		# Variant ordering groups String and StringName separately; native JSON
		# sorts their textual keys together, including dictionaries with both.
		keys.sort_custom(func(a,b): return str(a) < str(b))
		_store_json_chunk(file,hasher,"{")
		for i in keys.size():
			if i > 0: _store_json_chunk(file,hasher,",")
			_store_json_chunk(file,hasher,JSON.stringify(str(keys[i]),"",true,true)+":")
			_store_json_value(file,hasher,value[keys[i]],depth+1)
		_store_json_chunk(file,hasher,"}")
	else:
		_store_json_chunk(file,hasher,"[")
		for i in value.size():
			if i > 0: _store_json_chunk(file,hasher,",")
			_store_json_value(file,hasher,value[i],depth+1)
		_store_json_chunk(file,hasher,"]")

static func _store_json_chunk(file, hasher: HashingContext, text: String) -> void:
	var bytes := text.to_utf8_buffer()
	file.store_buffer(bytes)
	if hasher != null: hasher.update(bytes)

static func load_save(path: String) -> Dictionary:
	var decoded := _read_payload(path)
	if not decoded.ok:
		return decoded
	var career := CareerState.from_dict(decoded.data.career,true)
	restore_loaded_experiences(career)
	return {
		"ok": true,
		# The validated JSON tree is private to this load; transfer its large
		# branches instead of retaining a second complete decoded event tree.
		"career": career,
		"errors": [],
	}

# Interactive reads must leave the input callback before doing large work.
# The parsed candidate stays private until every archive has been validated
# and normalized; no partially loaded state is published between frames.
static func load_save_responsive(path: String, progress: Callable = Callable()) -> Dictionary:
	_report_load_progress(progress,"reading",0)
	await Engine.get_main_loop().process_frame
	if not FileAccess.file_exists(path): return _failure("存档文件不存在：%s" % path)
	var decoded := _parse_payload(FileAccess.get_file_as_string(path))
	if not decoded.ok: return decoded
	_report_load_progress(progress,"schema",10)
	var data: Dictionary = decoded.data
	var validation_error := _validate_payload(data,false)
	if not validation_error.is_empty(): return _failure(validation_error)
	await Engine.get_main_loop().process_frame
	var archives: Array = data.career.get("competition_archive",[])
	var archive_total := archives.size()
	var other_keys: Array = data.career.keys().filter(func(key): return key != "competition_archive")
	var normalized_sections := 0
	for i in archives.size():
		var archive: Dictionary = archives[i]
		var error := preload("res://src/persistence/competition_archive_codec.gd").validate(archive)
		if not error.is_empty(): return _failure(error)
		await Engine.get_main_loop().process_frame
		data.career.competition_archive[i] = NumericState.canonical_copy(archive)
		_report_load_progress(progress,"archives",15 + int(round(70.0 * float(i + 1) / float(maxi(archive_total,1)))),i + 1,archive_total)
		await Engine.get_main_loop().process_frame
	for key in other_keys:
		data.career[key] = NumericState.canonical_copy(data.career[key])
		normalized_sections += 1
		_report_load_progress(progress,"career",85 + int(round(12.0 * float(normalized_sections) / float(maxi(other_keys.size(),1)))))
		await Engine.get_main_loop().process_frame
	_report_load_progress(progress,"constructing",98)
	await Engine.get_main_loop().process_frame
	var career := CareerState.from_dict(data.career,true)
	restore_loaded_experiences(career)
	_report_load_progress(progress,"complete",100)
	await Engine.get_main_loop().process_frame
	return {"ok":true,"career":career,"errors":[]}

static func restore_loaded_experiences(career) -> void:
	var restored := preload("res://src/persistence/career_milestone_restore_service.gd").restore(career)
	career.experience_state = restored.experience_state

static func _report_load_progress(callback: Callable, stage: String, percent: int, current: int = 0, total: int = 0) -> void:
	if not callback.is_valid(): return
	callback.call({"stage":stage,"percent":clampi(percent,0,100),"current":current,"total":total})

static func load_with_recovery(path: String) -> Dictionary:
	var primary := load_save(path)
	if primary.ok:
		return {
			"ok": true,
			"career": primary.career,
			"errors": [],
			"recovered_from_backup": false,
			"primary_error": "",
		}
	var backup := load_save("%s.bak" % path)
	if backup.ok:
		return {
			"ok": true,
			"career": backup.career,
			"errors": [],
			"recovered_from_backup": true,
			"primary_error": str(primary.errors[0]),
		}
	return {
		"ok": false,
		"career": null,
		"errors": ["主存档与最近备份均无法读取", str(primary.errors[0]), str(backup.errors[0])],
		"recovered_from_backup": false,
		"primary_error": str(primary.errors[0]),
	}

static func _verify_payload(path: String) -> String:
	# Do not retain a decoded primary and decoded temporary save simultaneously.
	var digest := FileAccess.get_sha256(path)
	if not digest.is_empty() and _verified_hashes.get(ProjectSettings.globalize_path(path),"") == digest: return ""
	var result := _read_payload(path)
	if result.ok: _remember_verified(path,digest)
	return "" if result.ok else str(result.errors[0])

static func _remember_verified(path: String, digest: String) -> void:
	# Cache only a bounded fingerprint, never a decoded career or archive tree.
	if _verified_hashes.size() >= 8: _verified_hashes.clear()
	_verified_hashes[ProjectSettings.globalize_path(path)] = digest

static func _finite_json_values(value) -> bool:
	if value is float: return is_finite(value)
	if value is Dictionary:
		for key in value:
			if not _finite_json_values(value[key]): return false
		return true
	if value is Array:
		for child in value:
			if not _finite_json_values(child): return false
		return true
	return true

static func _read_payload(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return _failure("存档文件不存在：%s" % path)
	return decode_payload(FileAccess.get_file_as_string(path))

static func decode_payload(payload: String) -> Dictionary:
	var decoded := _parse_payload(payload)
	if not decoded.ok: return decoded
	var migrated_data: Dictionary = decoded.data
	var validation_error := _validate_payload(migrated_data)
	if not validation_error.is_empty(): return _failure(validation_error)
	migrated_data.career = NumericState.canonical_copy(migrated_data.career)
	return {"ok": true, "data": migrated_data, "career": null, "errors": []}

static func _parse_payload(payload: String) -> Dictionary:
	var json := JSON.new()
	if json.parse(payload) != OK:
		return _failure("存档文件不是有效的JSON")
	if not json.data is Dictionary:
		return _failure("存档根节点必须是对象")
	for key in REQUIRED_SAVE_KEYS:
		if not json.data.has(key):
			return _failure("存档缺少字段：%s" % key)
	# Current saves are already private parsed trees; migration's defensive
	# deep clone is necessary only when actually transforming an older schema.
	var migration: Dictionary = {"ok":true,"data":json.data} if json.data.get("save_version") == SAVE_VERSION else SaveMigrator.to_current(json.data)
	if not migration.ok:
		return _failure(migration.errors[0])
	return {"ok":true,"data":migration.data,"career":null,"errors":[]}

static func _validate_payload(data: Dictionary, validate_archive_payloads: bool = true) -> String:
	for key in REQUIRED_SAVE_KEYS:
		if not data.has(key):
			return "存档缺少字段：%s" % key
	if not _is_integer(data.save_version):
		return "存档版本必须是整数"
	var save_version := int(data.save_version)
	if save_version < 1:
		return "该存档版本过低：%d" % save_version
	if save_version > SAVE_VERSION:
		return "该存档来自尚不支持的版本：%d" % save_version
	if not _is_number(data.saved_at_unix):
		return "存档字段 saved_at_unix 必须是数字"
	if not data.career is Dictionary:
		return "存档字段 career 必须是对象"
	for key in REQUIRED_CAREER_KEYS:
		if not data.career.has(key):
			return "生涯数据缺少字段：%s" % key
	if not _is_integer(data.career.schema_version):
		return "生涯字段 schema_version 必须是整数"
	if int(data.career.schema_version) != SAVE_VERSION:
		return "生涯字段 schema_version 不受支持：%d" % int(data.career.schema_version)
	if not _is_integer(data.career.seed):
		return "生涯字段 seed 必须是整数"
	if int(data.career.seed) < 0:
		return "生涯字段 seed 必须为非负整数"
	if not _is_integer(data.career.rng_step):
		return "生涯字段 rng_step 必须是整数"
	if int(data.career.rng_step) < 0:
		return "生涯字段 rng_step 必须为非负整数"
	if not data.career.story_context is Dictionary:
		return "生涯字段 story_context 必须是对象"
	var story_error := StoryContext.validate(data.career.story_context)
	if not story_error.is_empty():
		return story_error
	if not data.career.random_streams is Dictionary:
		return "生涯字段 random_streams 必须是对象"
	var random_stream_error := RandomStreamState.validate(data.career.random_streams)
	if not random_stream_error.is_empty():
		return random_stream_error
	if not data.career.clock is Dictionary:
		return "生涯字段 clock 必须是对象"
	var clock_error := _validate_clock(data.career.clock)
	if not clock_error.is_empty():
		return clock_error
	if not data.career.athlete is Dictionary:
		return "生涯字段 athlete 必须是对象"
	var athlete_error := _validate_athlete(data.career.athlete)
	if not athlete_error.is_empty():
		return athlete_error
	if not data.career.relationships is Dictionary:
		return "生涯字段 relationships 必须是对象"
	for relationship_id in data.career.relationships:
		var relationship = data.career.relationships[relationship_id]
		if not relationship is Dictionary:
			return "生涯字段 relationships.%s 必须是对象" % str(relationship_id)
		for key in RELATIONSHIP_FIELDS:
			if not relationship.has(key):
				return "生涯关系数据缺少字段：%s.%s" % [str(relationship_id), key]
			if not _is_number(relationship[key]):
				return "生涯字段 relationships.%s.%s 必须是数字" % [str(relationship_id), key]
			if float(relationship[key]) < 0.0 or float(relationship[key]) > 100.0:
				return "生涯字段 relationships.%s.%s 必须在0至100之间" % [str(relationship_id), key]
	if not data.career.history is Array:
		return "生涯字段 history 必须是数组"
	for index in data.career.history.size():
		var outcome = data.career.history[index]
		if not outcome is Dictionary:
			return "生涯字段 history.%d 必须是对象" % index
		var outcome_error := _validate_outcome(outcome, index)
		if not outcome_error.is_empty():
			return outcome_error
	if not data.career.get("memories", []) is Array:
		return "生涯字段 memories 必须是数组"
	for index in data.career.get("memories", []).size():
		var memory = data.career.memories[index]
		if not memory is Dictionary:
			return "生涯字段 memories.%d 必须是对象" % index
		for metric in ["strength", "credibility"]:
			if not _is_number(memory.get(metric)) or float(memory[metric]) < 0.0 or float(memory[metric]) > 100.0:
				return "生涯字段 memories.%d.%s 必须在0至100之间" % [index, metric]
		if not _is_number(memory.get("decay_per_quarter")) or float(memory.decay_per_quarter) < 0.0:
			return "生涯字段 memories.%d.decay_per_quarter 必须是非负数字" % index
		for field in ["id", "kind", "signature"]:
			if not memory.get(field) is String:
				return "生涯字段 memories.%d.%s 必须是字符串" % [index, field]
		if not memory.get("cause_ids") is Array:
			return "生涯字段 memories.%d.cause_ids 必须是数组" % index
	if not data.career.get("development_roadmap", {}) is Dictionary:
		return "生涯字段 development_roadmap 必须是对象"
	var roadmap_data: Dictionary = data.career.get("development_roadmap", {})
	if not roadmap_data.is_empty() and DevelopmentRoadmap.from_dict(roadmap_data) == null:
		return "生涯字段 development_roadmap 不是有效成长路线"
	if not data.career.get("roadmap_revision_history", []) is Array:
		return "生涯字段 roadmap_revision_history 必须是数组"
	if not data.career.get("active_programs", {}) is Dictionary:
		return "生涯字段 active_programs 必须是对象"
	for segment in ["short", "free"]:
		var program = data.career.active_programs.get(segment, {})
		if not program is Dictionary: return "生涯字段 active_programs.%s 必须是对象" % segment
		if not program.is_empty():
			var restored = SkatingProgram.from_dict(program)
			if restored == null or restored.segment != segment: return "生涯字段 active_programs.%s 不是有效节目" % segment
	if not data.career.get("program_archive", []) is Array:
		return "生涯字段 program_archive 必须是数组"
	for index in data.career.program_archive.size():
		if not data.career.program_archive[index] is Dictionary or SkatingProgram.from_dict(data.career.program_archive[index]) == null:
			return "生涯字段 program_archive.%d 不是有效节目" % index
	var invitation = data.career.internal_invitation_state
	if not invitation is Dictionary or not ["not_ready", "pending", "deferred", "accepted", "completed"].has(str(invitation.get("status", ""))) or not invitation.get("offered_clock", {}) is Dictionary:
		return "生涯字段 internal_invitation_state 无效"
	var certification = data.career.certification_state
	if not certification is Dictionary: return "生涯字段 certification_state 必须是对象"
	if not _is_integer(certification.get("national_technical_grade")) or int(certification.national_technical_grade) < 0:
		return "生涯字段 certification_state.national_technical_grade 必须是非负整数"
	if not certification.get("last_assessment", {}) is Dictionary or not certification.get("history", []) is Array:
		return "生涯字段 certification_state 考核记录无效"
	if not data.career.get("competition_state", {}) is Dictionary:
		return "生涯字段 competition_state 必须是对象"
	var competition: Dictionary = data.career.get("competition_state", {})
	if not competition.is_empty():
		if not competition.get("status", "") is String:
			return "生涯字段 competition_state.status 必须是字符串"
		if not [
			"ready", "awaiting_adjustment", "free_ready", "complete",
			"roster_ready", "practice_ready", "short_ready", "short_complete", "free_adjustment",
		].has(str(competition.get("status", ""))):
			return "生涯字段 competition_state.status 无效"
	if not data.career.world_athletes is Dictionary:
		return "生涯字段 world_athletes 必须是对象"
	for athlete_id in data.career.world_athletes:
		if not data.career.world_athletes[athlete_id] is Dictionary:
			return "生涯字段 world_athletes.%s 必须是对象" % str(athlete_id)
		var world_error := _validate_world_record(str(athlete_id), data.career.world_athletes[athlete_id])
		if not world_error.is_empty(): return world_error
	if not data.career.competition_archive is Array:
		return "生涯字段 competition_archive 必须是数组"
	for index in data.career.competition_archive.size():
		if not data.career.competition_archive[index] is Dictionary:
			return "生涯字段 competition_archive.%d 必须是对象" % index
		var archive_error := preload("res://src/persistence/competition_archive_codec.gd").validate(data.career.competition_archive[index],validate_archive_payloads)
		if not archive_error.is_empty(): return archive_error
	if not data.career.record_book is Dictionary:
		return "生涯字段 record_book 必须是对象"
	if not data.career.ranking_state is Dictionary:
		return "生涯字段 ranking_state 必须是对象"
	var season_error := _validate_season_state(data.career.season_state)
	if not season_error.is_empty():
		return season_error
	var boundary_error := _validate_version_thirteen_state(data.career)
	if not boundary_error.is_empty():
		return boundary_error
	var history_boundary_error := _validate_version_fourteen_state(data.career)
	if not history_boundary_error.is_empty():
		return history_boundary_error
	var first_loop_error := _validate_version_fifteen_state(data.career)
	if not first_loop_error.is_empty(): return first_loop_error
	var plan_error := _validate_saved_plan(data.career.get("last_generated_plan", {}))
	if not plan_error.is_empty(): return plan_error
	var health_error := _validate_version_sixteen_state(data.career)
	if not health_error.is_empty(): return health_error
	return ""

static func _validate_version_sixteen_state(career: Dictionary) -> String:
	if career.has("competition_timeline") and not career.competition_timeline is Dictionary: return "生涯日期游标必须为对象"
	var timeline_error := preload("res://src/domain/competition_timeline.gd").validate(career.get("competition_timeline",preload("res://src/domain/competition_timeline.gd").empty()),career.get("clock",{}))
	if not timeline_error.is_empty(): return timeline_error
	# Optional for unreleased v23 QA/legacy payloads; absence is unexamined,
	# never declined. Present data is validated before it can replace a file.
	var series_error := preload("res://src/domain/beijing_trial_series.gd").validate(career.get("beijing_trial_series",preload("res://src/domain/beijing_trial_series.gd").empty()))
	if not series_error.is_empty(): return series_error
	var series_time_error := preload("res://src/domain/beijing_trial_series.gd").chronology_error(career.get("beijing_trial_series",preload("res://src/domain/beijing_trial_series.gd").empty()),career.get("clock"))
	if not series_time_error.is_empty(): return series_time_error
	for athlete_id in career.get("beijing_trial_series",{}).get("entrant_ids",[]):
		if athlete_id == "player": continue
		if not career.get("world_athletes") is Dictionary or not career.world_athletes.get(athlete_id) is Dictionary: return "北京选拔参赛名单包含不存在的持久选手"
	var quota_error := preload("res://src/domain/olympic_quota_state.gd").validate(career.get("olympic_quota_state"))
	if not quota_error.is_empty(): return quota_error
	if career.olympic_quota_state.get("edition") != 2022: return "北京奥运国家席位存档周期无效"
	var milano_quota = career.get("milano_olympic_quota_state",preload("res://src/domain/olympic_quota_state.gd").empty(2026))
	var milano_quota_error := preload("res://src/domain/olympic_quota_state.gd").validate(milano_quota)
	if not milano_quota_error.is_empty(): return milano_quota_error
	if milano_quota.get("edition") != 2026: return "米兰奥运国家席位存档周期无效"
	if not career.get("coach_training_state") is Dictionary: return "生涯字段 coach_training_state 必须为对象"
	var coaching_errors: Array[String] = preload("res://src/domain/coach_training_state.gd").validate(career.coach_training_state)
	if not coaching_errors.is_empty(): return "；".join(coaching_errors)
	if not career.get("training_direction") is Dictionary: return "生涯字段 training_direction 必须为对象"
	var direction_error: String = preload("res://src/domain/training_direction.gd").validate(career.training_direction)
	if not direction_error.is_empty(): return direction_error
	for field in ["season_program_plan","technical_repertoire"]:
		if not career.get(field) is Dictionary: return "生涯字段 %s 必须为对象" % field
	var plan_error: String = preload("res://src/domain/season_program_plan.gd").validate(career.season_program_plan)
	if not plan_error.is_empty(): return plan_error
	var repertoire_error: String = preload("res://src/domain/technical_repertoire.gd").validate(career.technical_repertoire)
	if not repertoire_error.is_empty(): return repertoire_error
	if not career.get("experience_state") is Dictionary: return "生涯字段 experience_state 必须是对象"
	var experience_error: String = preload("res://src/domain/career_experience_state.gd").validate(career.experience_state)
	if not experience_error.is_empty(): return experience_error
	for field in ["function_limits","rehabilitation","pending_decision"]:
		if not career.condition_state.get(field,{}) is Dictionary: return "身体状态 %s 必须为对象" % field
	if career.condition_state.get("health_model_version",1) != 1: return "身体模型版本无效"
	var limits_error := _validate_function_limits(career.condition_state.get("function_limits",{}))
	if not limits_error.is_empty(): return limits_error
	var injury_ids: Array = []
	for injury in career.condition_state.injuries:
		injury_ids.append(str(injury.id))
		if injury.has("dated_recovery_fraction"):
			var fraction = injury.dated_recovery_fraction
			if not fraction is Dictionary or fraction.is_empty() or not preload("res://src/simulation/dated_training_dose.gd").accrue_period(fraction,0,90).errors.is_empty(): return "轻伤日期恢复余量无效"
		limits_error = _validate_function_limits(injury.get("function_limits",{}))
		if not limits_error.is_empty(): return limits_error
		limits_error = _validate_function_limits(injury.get("residual_function_limits",{}))
		if not limits_error.is_empty(): return limits_error
	for injury_id in career.condition_state.get("rehabilitation",{}):
		var record = career.condition_state.rehabilitation[injury_id]
		if not injury_ids.has(str(injury_id)) or not record is Dictionary: return "康复记录缺少对应伤情"
		if not ["conservative","full_rehabilitation"].has(record.get("route_id")): return "康复路线无效"
		if not ["protection","functional_recovery","review","return_to_training"].has(record.get("stage")): return "康复阶段无效"
		for field in ["elapsed_quarters","route_quarters"]:
			var count = record.get(field)
			if not _is_number(count) or not is_finite(float(count)) or float(count) < 0.0 or float(count) != floorf(float(count)): return "康复时长必须为非负整数"
		if int(record.route_quarters) > int(record.elapsed_quarters): return "当前疗程时长超过累计康复时长"
		if record.has("dated_period_fraction") or record.has("dated_unsafe_load"):
			var fraction = record.get("dated_period_fraction")
			if not fraction is Dictionary or fraction.is_empty() or not record.get("dated_unsafe_load") is bool: return "康复日历时长记录无效"
			if not preload("res://src/simulation/dated_training_dose.gd").accrue_period(fraction,0,90).errors.is_empty(): return "康复日历时长余量无效"
		var progress = record.get("progress")
		if not _is_number(progress) or not is_finite(float(progress)) or float(progress) < 0.0 or float(progress) > 1.0: return "康复进度必须在0至1之间"
		if not record.get("receipts") is Array: return "康复确认凭据无效"
		for receipt in record.receipts:
			if not receipt is Dictionary: return "康复确认凭据无效"
			for field in ["id","injury_id","route_id"]:
				if not receipt.get(field) is String or str(receipt[field]).is_empty(): return "康复确认凭据字段无效"
			if str(receipt.injury_id) != str(injury_id): return "康复确认凭据与伤情不一致"
	var decision: Dictionary = career.condition_state.get("pending_decision",{})
	if not decision.is_empty():
		if not ["rehabilitation_initial","rehabilitation_review"].has(decision.get("kind")) or not injury_ids.has(str(decision.get("injury_id",""))): return "待处理治疗决策无效"
	return ""

static func _validate_function_limits(limits) -> String:
	if not limits is Dictionary: return "身体功能限制必须为对象"
	for function in limits:
		if not ["takeoff","coordination","landing","recovery"].has(str(function)): return "未知身体功能限制"
		var limit = limits[function]
		if not limit is Dictionary: return "身体功能限制条目无效"
		if limit.has("factor"):
			var factor = limit.factor
			if not _is_number(factor) or not is_finite(float(factor)) or float(factor) < 0.0 or float(factor) > 1.0: return "身体功能系数必须在0至1之间"
		if limit.has("blocked") and not limit.blocked is bool: return "身体功能禁用标记必须为布尔值"
		if limit.has("maximum_rotations"):
			var maximum = limit.maximum_rotations
			if not _is_number(maximum) or not is_finite(float(maximum)) or float(maximum) != floorf(float(maximum)) or int(maximum) < 0 or int(maximum) > 4: return "允许跳跃周数必须为0至4的整数"
		for field in ["review_condition","source_id"]:
			if limit.has(field) and not limit[field] is String: return "身体限制说明无效"
	return ""

static func _validate_version_fifteen_state(career: Dictionary) -> String:
	if not career.opening_stage is String or not ["history","handoff","complete"].has(str(career.opening_stage)):
		return "生涯字段 opening_stage 无效"
	for field in ["career_goal","training_period_state","coach_assignment","training_preferences","last_training_policy"]:
		if not career[field] is Dictionary: return "生涯字段 %s 必须是对象" % field
	var goal: Dictionary = career.career_goal
	if not goal.is_empty():
		if not ["love_the_sport","highest_stage","leave_a_mark"].has(str(goal.get("id",""))): return "生涯字段 career_goal.id 无效"
		if not goal.get("scoring_effect") is bool: return "生涯字段 career_goal.scoring_effect 必须是布尔值"
		if not goal.get("chosen_clock") is Dictionary: return "生涯字段 career_goal.chosen_clock 必须是对象"
		var goal_clock_error := _validate_clock(goal.chosen_clock)
		if not goal_clock_error.is_empty(): return "生涯字段 career_goal.chosen_clock.%s" % goal_clock_error
	var period: Dictionary = career.training_period_state
	if not period.is_empty():
		if not _is_integer(period.get("weeks_elapsed")) or int(period.weeks_elapsed) < 0 or int(period.weeks_elapsed) > 12: return "生涯字段 training_period_state.weeks_elapsed 必须是0至12的整数"
		if not period.get("intent") is Dictionary or TrainingIntent.from_dict(period.intent) == null: return "生涯字段 training_period_state.intent 无效"
		if not period.get("plan") is Dictionary or not _validate_plan_data(period.plan).is_empty(): return "生涯字段 training_period_state.plan 无效"
		if not period.get("started_clock") is Dictionary: return "生涯字段 training_period_state.started_clock 必须是对象"
		var period_clock_error := _validate_clock(period.started_clock)
		if not period_clock_error.is_empty(): return "生涯字段 training_period_state.started_clock.%s" % period_clock_error
		if period.has("stage_checkpoint"):
			var checkpoint_error := _validate_training_checkpoint(career,period.stage_checkpoint)
			if not checkpoint_error.is_empty(): return checkpoint_error
		if period.has("agreed_proposal"):
			if not period.agreed_proposal is Dictionary or not _validate_saved_plan(period.agreed_proposal).is_empty() or period.agreed_proposal.get("status") != "resolved": return "生涯字段 training_period_state.agreed_proposal 无效"
		if period.has("facts") and not _validate_dictionary_array(period.facts,"training_period_state.facts").is_empty(): return "生涯字段 training_period_state.facts 无效"
	var assignment: Dictionary = career.coach_assignment
	for field in ["club_id","coach_id"]:
		if not assignment.get(field) is String: return "生涯字段 coach_assignment.%s 必须是字符串" % field
	for field in ["known_strengths","known_concerns"]:
		if not assignment.get(field) is Array or not Array(assignment[field]).all(func(value): return value is String): return "生涯字段 coach_assignment.%s 必须是字符串数组" % field
	if not assignment.get("technical_tendencies") is Dictionary: return "生涯字段 coach_assignment.technical_tendencies 必须是对象"
	if not assignment.get("relationship") is Dictionary: return "生涯字段 coach_assignment.relationship 必须是对象"
	for metric in RELATIONSHIP_FIELDS:
		var value = assignment.relationship.get(metric)
		if not _is_number(value) or float(value) < 0.0 or float(value) > 100.0: return "生涯字段 coach_assignment.relationship.%s 必须在0至100之间" % metric
	var preferences: Dictionary = career.training_preferences
	for field in ["breakthrough_policy","minor_pain_policy","coach_strategy_policy"]:
		if not preferences.get(field) is String or not ["ask","summary"].has(str(preferences[field])): return "生涯字段 training_preferences.%s 无效" % field
	if not career.last_training_policy.is_empty():
		var policy: Dictionary = career.last_training_policy.duplicate(true)
		if not policy.get("target_rotations") is Dictionary: return "生涯字段 last_training_policy 无效"
		for jump_id in policy.target_rotations:
			if not _is_integer(policy.target_rotations[jump_id]): return "生涯字段 last_training_policy 无效"
			policy.target_rotations[jump_id] = int(policy.target_rotations[jump_id])
		if TrainingPolicy.from_dict(policy) == null: return "生涯字段 last_training_policy 无效"
	return ""

static func _validate_saved_plan(data) -> String:
	if not data is Dictionary: return "保存的训练安排必须是对象"
	if data.is_empty(): return ""
	if not data.has("desired"): return _validate_plan_data(data)
	for key in data:
		if not ["desired", "approved", "executed", "status", "training_efficiency", "conflicts", "decisions", "secret_practice_intent"].has(key): return "未知训练提案字段"
	for key in ["desired", "approved", "executed"]:
		var error := _validate_plan_data(data.get(key))
		if not error.is_empty(): return "训练提案%s：%s" % [key, error]
	if not ["draft", "needs_response", "resolved"].has(data.get("status")): return "训练提案状态无效"
	var efficiency = data.get("training_efficiency", 1.0)
	if not _is_number(efficiency) or not is_finite(float(efficiency)) or float(efficiency) <= 0.0 or float(efficiency) > 1.0: return "训练提案效率无效"
	for key in ["conflicts", "decisions"]:
		var error := _validate_dictionary_array(data.get(key), "训练提案.%s" % key)
		if not error.is_empty(): return error
	for conflict in data.conflicts:
		for key in ["id", "actor_id", "reason_code"]:
			if not conflict.get(key) is String: return "训练异议标识无效"
		for key in ["proposed_allocations", "proposed_shares", "proposed_jump_rotations"]:
			var allowed_keys = JumpCatalog.JUMP_IDS if key == "proposed_jump_rotations" else TrainingPlan.CATEGORY_IDS
			if not _validate_plan_values(conflict.get(key), allowed_keys).is_empty(): return "训练异议分配无效"
		# Percentage proposals retain the legacy map as an exact compatibility alias.
		if not conflict.proposed_shares.is_empty() and conflict.proposed_allocations != conflict.proposed_shares: return "训练异议存在冲突的分配表示"
		if conflict.proposed_shares.is_empty() and not conflict.proposed_jump_rotations.is_empty(): return "单位训练异议不能包含跳跃目标"
		var proposed := {"allocations":conflict.proposed_allocations} if conflict.proposed_shares.is_empty() else {"shares":conflict.proposed_shares, "jump_rotations":conflict.proposed_jump_rotations}
		if not _validate_plan_data(proposed).is_empty(): return "训练异议分配无效"
		if not _validate_dictionary_array(conflict.get("responses"), "训练异议回应").is_empty(): return "训练异议回应无效"
		for response in conflict.responses:
			if not response.get("id") is String or not response.get("label") is String: return "训练异议回应无效"
	var intent = data.get("secret_practice_intent")
	if not intent is Dictionary: return "私练意图必须是对象"
	if not intent.is_empty():
		if not JumpCatalog.JUMP_IDS.has(intent.get("jump_id")): return "私练动作无效"
		for key in ["rotations", "attempts", "units"]:
			if not _is_integer(intent.get(key)) or float(intent[key]) <= 0.0 or float(intent[key]) > 10000.0: return "私练数量无效"
		if float(intent.rotations) > 4.0: return "私练周数无效"
		for key in ["familiarity", "money_cost"]:
			if not _is_number(intent.get(key)) or not is_finite(float(intent[key])) or float(intent[key]) < 0.0: return "私练代价无效"
		for key in ["free_ice_access", "transport_available", "unmonitored_window"]:
			if not intent.get(key) is bool: return "私练可行性无效"
	return ""

static func _validate_plan_data(data) -> String:
	if not data is Dictionary: return "训练分配必须是对象"
	for key in data:
		if not ["shares", "allocations", "jump_rotations", "specialist_targets", "expression_share", "lesson_quality", "focus_lessons", "coach_decision"].has(key): return "未知训练分配字段"
	if data.has("shares") and data.has("allocations"): return "训练分配不能包含两种表示"
	if data.has("allocations") and data.has("jump_rotations"): return "单位训练分配不能包含跳跃目标"
	var values_key := "shares" if data.has("shares") else "allocations"
	if not data.get(values_key) is Dictionary: return "训练分配必须是对象"
	var normalized: Dictionary = data.duplicate(true)
	for key in ["shares", "allocations", "jump_rotations"]:
		if not normalized.has(key): continue
		var allowed_keys = JumpCatalog.JUMP_IDS if key == "jump_rotations" else TrainingPlan.CATEGORY_IDS
		var error := _validate_plan_values(normalized[key], allowed_keys)
		if not error.is_empty(): return error
		for category in normalized[key]:
			normalized[key][category] = int(normalized[key][category])
	return "训练分配不合法" if TrainingPlan.from_dict(normalized) == null else ""

static func _validate_plan_values(values, allowed_keys: Array) -> String:
	if not values is Dictionary: return "训练分配必须是对象"
	for key in values:
		if not allowed_keys.has(key): return "未知训练分配类别"
		var value = values[key]
		if not _is_integer(value) or not is_finite(float(value)) or float(value) < 0.0 or float(value) > 100.0: return "训练分配数值无效"
	return ""

static func _validate_version_thirteen_state(career: Dictionary) -> String:
	if not career.condition_state is Dictionary:
		return "生涯字段 condition_state 必须是对象"
	var condition: Dictionary = career.condition_state
	if condition.has("pending_training_events"):
		var pending_error := _validate_dictionary_array(condition.pending_training_events,"condition_state.pending_training_events")
		if not pending_error.is_empty(): return pending_error
		for event in condition.pending_training_events:
			for field in ["id","signature","title","description"]:
				if not event.get(field) is String: return "待处理训练事件缺少有效说明"
			if not event.get("choices") is Array or event.choices.is_empty(): return "待处理训练事件缺少有效选项"
			for choice in event.choices:
				if not choice is Dictionary or not choice.get("id") is String or not choice.get("label") is String: return "待处理训练事件选项无效"
	for key in ["growth_phase", "growth_signals", "injuries", "medical_opinions", "psychology"]:
		if not condition.has(key): return "生涯字段 condition_state.%s 缺失" % key
	if not condition.growth_phase is String: return "生涯字段 condition_state.growth_phase 必须是字符串"
	if not ["stable", "rapid", "adapted"].has(condition.growth_phase): return "生长阶段无效"
	if condition.has("growth_quarters") and (not _is_integer(condition.growth_quarters) or float(condition.growth_quarters) < 0.0 or float(condition.growth_quarters) > 4.0): return "生长阶段季度计数无效"
	for key in ["growth_signals", "injuries", "medical_opinions"]:
		var collection_error := _validate_dictionary_array(condition[key], "condition_state.%s" % key)
		if not collection_error.is_empty(): return collection_error
		for entry in condition[key]:
			if entry.has("clock") and (not entry.clock is Dictionary or not _validate_clock(entry.clock).is_empty()): return "身体观察时间无效"
			for field in ["id", "injury_id", "label"]:
				if entry.has(field) and not entry[field] is String: return "身体观察标识或说明无效"
	if not condition.psychology is Dictionary: return "生涯字段 condition_state.psychology 必须是对象"
	if condition.psychology.has("label") and not condition.psychology.label is String: return "心理状态说明无效"
	for injury in condition.injuries:
		if not injury.get("id") is String or not injury.get("site") is String: return "伤病缺少标识或部位"
		if not _is_number(injury.get("severity")) or not is_finite(float(injury.severity)) or float(injury.severity) < 0.0 or float(injury.severity) > 1.0: return "伤病严重程度必须在0至1之间"
		if not _is_integer(injury.get("remaining_quarters")) or float(injury.remaining_quarters) < 0.0: return "伤病恢复季度无效"
		if not ["active", "recovered"].has(injury.get("status")): return "伤病状态无效"
	if condition.psychology.has("stress"):
		var stress = condition.psychology.stress
		if not _is_number(stress) or not is_finite(float(stress)) or float(stress) < 0.0 or float(stress) > 100.0: return "心理压力状态无效"
	if condition.has("key_nodes"):
		var node_error := _validate_dictionary_array(condition.key_nodes, "condition_state.key_nodes")
		if not node_error.is_empty(): return node_error
		var node_ids: Array[String] = []
		for node in condition.key_nodes:
			if not node.get("id") is String or str(node.id).is_empty() or node_ids.has(node.id): return "关键节点标识无效"
			node_ids.append(node.id)
			if not node.get("kind") is String or not node.get("label") is String or not node.get("resolved") is bool: return "关键节点字段无效"
			if not ["growth_warning", "injury_review"].has(node.kind): return "关键节点种类无效"
			if not node.get("clock") is Dictionary or not _validate_clock(node.clock).is_empty(): return "关键节点时间无效"
			if node.has("resolved_clock") and (not node.resolved_clock is Dictionary or not _validate_clock(node.resolved_clock).is_empty()): return "关键节点处理时间无效"
			if bool(node.resolved) and not node.has("resolved_clock"): return "关键节点缺少处理时间"
			if node.has("response_id") and node.response_id != "acknowledge":
				var route_response: bool = node.kind == "injury_review" and bool(node.resolved) and node.response_id in ["conservative","full_rehabilitation"]
				if not condition.get("rehabilitation",{}) is Dictionary: return "康复记录无效"
				var treatment = condition.get("rehabilitation",{}).get(str(node.id),{})
				if not treatment is Dictionary or not treatment.get("receipts",[]) is Array: return "康复确认凭据无效"
				var has_receipt: bool = treatment.get("receipts",[]).any(func(receipt): return receipt is Dictionary and receipt.get("injury_id") == node.id and receipt.get("route_id") == node.response_id)
				if not route_response or not has_receipt: return "关键节点回应无效"
	if condition.has("secret_practice_blocked") and not condition.secret_practice_blocked is bool: return "私练监督状态无效"

	if not career.social_state is Dictionary:
		return "生涯字段 social_state 必须是对象"
	var social: Dictionary = career.social_state
	for key in ["friendships", "fan_climate", "media_events", "commercial_commitments"]:
		if not social.has(key): return "生涯字段 social_state.%s 缺失" % key
	if not social.friendships is Dictionary: return "生涯字段 social_state.friendships 必须是对象"
	if not social.fan_climate is String: return "生涯字段 social_state.fan_climate 必须是字符串"
	for key in ["media_events", "commercial_commitments"]:
		var collection_error := _validate_dictionary_array(social[key], "social_state.%s" % key)
		if not collection_error.is_empty(): return collection_error

	if not career.selection_state is Dictionary:
		return "生涯字段 selection_state 必须是对象"
	var selection: Dictionary = career.selection_state
	for key in ["applications", "assignments", "appeals"]:
		if not selection.has(key): return "生涯字段 selection_state.%s 缺失" % key
	for key in ["applications", "assignments"]:
		if not selection[key] is Dictionary: return "生涯字段 selection_state.%s 必须是对象" % key
	var appeals_error := _validate_dictionary_array(selection.appeals, "selection_state.appeals")
	if not appeals_error.is_empty(): return appeals_error
	for athlete_id in selection.assignments:
		if not selection.assignments[athlete_id] is Array: return "selection_state.assignments 必须保存赛事ID数组"
		var ids: Array = selection.assignments[athlete_id]
		for id in ids:
			if not id is String or str(id).is_empty() or ids.count(id) != 1: return "selection_state.assignments 赛事ID无效或重复"
	for application in selection.applications.values():
		if not application is Dictionary: return "selection_state.applications 申请必须是对象"
		if application.has("option_snapshot"):
			if not application.option_snapshot is Dictionary or not application.get("event_id") is String or not application.get("route_id") is String or not application.get("reason_codes") is Array: return "selection_state.applications 申请记录不完整"
	if selection.has("decisions"):
		if not selection.decisions is Dictionary: return "selection_state.decisions 必须是对象"
		for decision in selection.decisions.values():
			if not decision is Dictionary or not decision.get("inputs") is Array or not decision.get("decision") is Dictionary: return "selection_state.decisions 决议无效"
			var audit = decision.decision.get("audit")
			if not audit is Dictionary or audit.get("hidden_replacement") != false or not audit.get("candidate_rows") is Array or not audit.get("public_formula") is String: return "selection_state.decisions 审计无效"
	if selection.has("jgp"):
		if not selection.jgp is Dictionary or not selection.jgp.get("events") is Dictionary or not selection.jgp.get("standings") is Array or not selection.jgp.get("qualified_ids") is Array: return "selection_state.jgp 积分记录无效"
	if selection.has("jgp_second_start"):
		var second_error := preload("res://src/simulation/jgp_second_start_service.gd").validate(selection.jgp_second_start,career.season_state)
		if not second_error.is_empty(): return second_error

	var ledger_error := _validate_dictionary_array(career.event_ledger, "event_ledger")
	if not ledger_error.is_empty(): return ledger_error

	if not career.world_state is Dictionary:
		return "生涯字段 world_state 必须是对象"
	var world: Dictionary = career.world_state
	if world.has("world_seed") and (not _is_integer(world.world_seed) or float(world.world_seed) < 0):
		return "生涯字段 world_state.world_seed 必须为非负整数"
	if world.has("generated_seasons") and (not world.generated_seasons is Array or not Array(world.generated_seasons).all(func(value): return value is String)):
		return "生涯字段 world_state.generated_seasons 必须是字符串数组"
	for key in ["season_id", "generated_federations", "athlete_ids", "last_advanced_clock"]:
		if not world.has(key): return "生涯字段 world_state.%s 缺失" % key
	if not world.season_id is String: return "生涯字段 world_state.season_id 必须是字符串"
	for key in ["generated_federations", "athlete_ids"]:
		if not world[key] is Array or not Array(world[key]).all(func(value): return value is String):
			return "生涯字段 world_state.%s 必须是字符串数组" % key
	if not world.last_advanced_clock is Dictionary:
		return "生涯字段 world_state.last_advanced_clock 必须是对象"
	if not world.last_advanced_clock.is_empty():
		var clock_error := _validate_clock(world.last_advanced_clock)
		if not clock_error.is_empty(): return "生涯字段 world_state.last_advanced_clock.%s" % clock_error
	return ""

static func _validate_version_fourteen_state(career: Dictionary) -> String:
	if not career.pre_career_history is Dictionary:
		return "生涯字段 pre_career_history 必须是对象"
	var history: Dictionary = career.pre_career_history
	if history.is_empty():
		return ""
	for field in ["version", "skating_start_age", "training_quarters", "episodes", "coach_assessment", "known_observations", "source"]:
		if not history.has(field): return "启蒙史缺少字段：%s" % field
	if not _is_integer(history.version) or int(history.version) != 1:
		return "启蒙史版本必须为1"
	if not _is_integer(history.skating_start_age) or int(history.skating_start_age) < 3 or int(history.skating_start_age) > 6:
		return "启蒙史开始学滑年龄必须为3至6岁的整数"
	if not _is_integer(history.training_quarters) or int(history.training_quarters) < 0 or int(history.training_quarters) > 20:
		return "启蒙史训练时长必须为0至20个季度的整数"
	if not history.source is String or str(history.source) != "generated":
		return "启蒙史生成来源无效"
	if not history.coach_assessment is String or str(history.coach_assessment).strip_edges().is_empty():
		return "启蒙史教练评价必须是非空字符串"
	if not history.known_observations is Array or not Array(history.known_observations).all(func(value): return value is String):
		return "启蒙史已知观察必须是字符串数组"
	if not history.episodes is Array or history.episodes.size() < 3 or history.episodes.size() > 5:
		return "启蒙史关键经历必须为3至5条"
	var episode_ids: Array[String] = []
	for episode in history.episodes:
		if not episode is Dictionary: return "启蒙史关键经历必须是对象"
		for field in ["id", "kind", "text"]:
			if not episode.get(field) is String or str(episode.get(field)).strip_edges().is_empty():
				return "启蒙史关键经历缺少有效字段：%s" % field
		if not _is_integer(episode.get("age")) or int(episode.age) < 3 or int(episode.age) > 8:
			return "启蒙史关键经历年龄必须为3至8岁的整数"
		if episode_ids.has(str(episode.id)): return "启蒙史关键经历标识不能重复"
		episode_ids.append(str(episode.id))
	return ""

static func _validate_dictionary_array(value, path: String) -> String:
	if not value is Array:
		return "生涯字段 %s 必须是数组" % path
	for index in value.size():
		if not value[index] is Dictionary:
			return "生涯字段 %s.%d 必须是对象" % [path, index]
	return ""

static func _validate_season_state(season_state) -> String:
	if not season_state is Dictionary:
		return "生涯字段 season_state 必须是对象"
	if season_state.has("target_event_id") and (not season_state.target_event_id is String or season_state.target_event_id.length() > 160):
		return "赛季目标标识无效"
	if season_state.has("selection_policy"):
		if not season_state.get("season_id") is String or str(season_state.season_id).is_empty(): return "年度政策缺少所属赛季"
		var policy_error := preload("res://src/simulation/annual_selection_policy_service.gd").validate_snapshot(season_state.selection_policy,str(season_state.season_id))
		if not policy_error.is_empty(): return "赛季公告损坏："+policy_error
	if season_state.has("season_history"):
		if not season_state.season_history is Dictionary: return "season_state.season_history 必须是对象"
		for history_season in season_state.season_history:
			var snapshot = season_state.season_history[history_season]
			if not snapshot is Dictionary: return "赛季档案必须是对象"
			for field in ["season","record_book","ranking_state","clock"]:
				if not snapshot.get(field) is Dictionary: return "赛季档案缺少有效的%s" % field
			if snapshot.season.has("selection_policy"):
				if snapshot.season.get("season_id") != history_season: return "历史年度政策所属赛季不一致"
				var policy_error := preload("res://src/simulation/annual_selection_policy_service.gd").validate_snapshot(snapshot.season.selection_policy,str(history_season))
				if not policy_error.is_empty(): return "历史赛季公告损坏："+policy_error
	if season_state.has("coach_feedback") and not season_state.coach_feedback is String: return "赛季教练反馈必须是字符串"
	for key in ["season_id", "entry_plan", "qualification_state", "event_statuses"]:
		if not season_state.has(key):
			return "生涯字段 season_state.%s 缺失" % key
	if not season_state.season_id is String:
		return "生涯字段 season_state.season_id 必须是字符串"
	if not season_state.entry_plan is Dictionary:
		return "生涯字段 season_state.entry_plan 必须是对象"
	if not season_state.entry_plan.is_empty():
		var plan_errors := SeasonEntryPlan.validate(season_state.entry_plan)
		if not plan_errors.is_empty():
			return "生涯字段 season_state.entry_plan.%s" % plan_errors[0]
	if not season_state.qualification_state is Dictionary:
		return "生涯字段 season_state.qualification_state 必须是对象"
	for qualification_id in season_state.qualification_state:
		if not season_state.qualification_state[qualification_id] is bool:
			return "生涯字段 season_state.qualification_state.%s 必须是布尔值" % str(qualification_id)
	if not season_state.event_statuses is Dictionary:
		return "生涯字段 season_state.event_statuses 必须是对象"
	for event_id in season_state.event_statuses:
		if not SeasonEntryPlan.STATUS_IDS.has(str(season_state.event_statuses[event_id])):
			return "生涯字段 season_state.event_statuses.%s 无效" % str(event_id)
	return ""

static func _validate_world_record(athlete_id: String, record: Dictionary) -> String:
	if record.has("opponent_schedule"):
		var schedule_error := preload("res://src/simulation/opponent_season_schedule_service.gd").validate(record.opponent_schedule)
		if not schedule_error.is_empty(): return "NPC赛程无效："+schedule_error
		if record.opponent_schedule.athlete_id != athlete_id: return "NPC赛程身份不一致"
	if record.has("opponent_schedule_history"):
		if not record.opponent_schedule_history is Dictionary or record.opponent_schedule_history.size() > 8: return "NPC赛程历史必须为最多8季的对象"
		for season in record.opponent_schedule_history:
			var schedule = record.opponent_schedule_history[season]
			var schedule_error := preload("res://src/simulation/opponent_season_schedule_service.gd").validate(schedule)
			if not schedule_error.is_empty(): return "NPC历史赛程无效："+schedule_error
			if schedule.athlete_id != athlete_id or schedule.season_id != season: return "NPC历史赛程身份或赛季不一致"
	if record.has("opponent_decision"):
		var decision_error := preload("res://src/simulation/opponent_decision_service.gd").validate(record.opponent_decision)
		if not decision_error.is_empty(): return "world_athletes.%s.opponent_decision " % athlete_id + decision_error
	# Older saves may contain only names/results. Preserve those records;
	# enforce the deterministic contract for records generated by this service.
	if not record.has("world_record_version"): return ""
	var path := "生涯字段 world_athletes.%s" % athlete_id
	if not _is_integer(record.world_record_version) or int(record.world_record_version) != 1:
		return path + ".world_record_version 无效"
	if record.get("athlete_id") != athlete_id: return path + ".athlete_id 不匹配"
	for field in ["name", "federation", "nationality", "name_origin", "birth_date", "status", "club_id", "coach_id", "tier", "last_advanced_season"]:
		if not record.get(field) is String or str(record[field]).is_empty(): return path + "." + field + " 必须是非空字符串"
	if not _is_integer(record.get("career_seed")) or float(record.career_seed) < 0.0 or float(record.career_seed) > 4294967295.0:
		return path + ".career_seed 无效"
	for field in ["athlete", "physical_trajectory", "personality", "record_book", "ranking_points", "last_advanced_clock", "short_program", "free_program"]:
		if not record.get(field) is Dictionary: return path + "." + field + " 必须是对象"
	var clock_error := _validate_clock(record.last_advanced_clock)
	if not clock_error.is_empty(): return path + ".last_advanced_clock " + clock_error
	var athlete_error := _validate_athlete(record.athlete)
	if not athlete_error.is_empty(): return path + ".athlete " + athlete_error
	var birthday: String = record.birth_date
	if birthday.length() != 10 or birthday.substr(4, 1) != "-" or birthday.substr(7, 1) != "-":
		return path + ".birth_date 无效"
	if int(birthday.substr(0, 4)) != int(record.athlete.birth_year) or int(birthday.substr(5, 2)) < 1 or int(birthday.substr(5, 2)) > 12 or int(birthday.substr(8, 2)) < 1 or int(birthday.substr(8, 2)) > 31:
		return path + ".birth_date 无效"
	for field in ["elapsed_quarters", "age"]:
		if not _is_integer(record.physical_trajectory.get(field)) or float(record.physical_trajectory[field]) < 0:
			return path + ".physical_trajectory." + field + " 无效"
	for field in ["height_cm", "mature_height_cm", "volatility", "resource_level", "development_rate"]:
		if not _is_number(record.physical_trajectory.get(field)) or not is_finite(float(record.physical_trajectory[field])) or float(record.physical_trajectory[field]) < 0:
			return path + ".physical_trajectory." + field + " 无效"
	if not record.physical_trajectory.get("late_bloomer") is bool: return path + ".physical_trajectory.late_bloomer 无效"
	for field in ["discipline", "ambition"]:
		if not _is_number(record.personality.get(field)): return path + ".personality." + field + " 无效"
	for field in ["domestic", "isu_world", "season_world"]:
		if not _is_number(record.ranking_points.get(field)) or float(record.ranking_points[field]) < 0: return path + ".ranking_points." + field + " 无效"
	var history_error := _validate_dictionary_array(record.get("competition_history"), "world_athletes.%s.competition_history" % athlete_id)
	if not history_error.is_empty(): return history_error
	for segment in ["short", "free"]:
		var program = SkatingProgram.from_dict(record[segment + "_program"])
		if program == null or program.segment != segment: return path + "." + segment + "_program 无效"
	return ""

static func _validate_clock(clock: Dictionary) -> String:
	for key in ["year", "quarter"]:
		if not clock.has(key):
			return "生涯时钟缺少字段：%s" % key
		if not _is_integer(clock[key]):
			return "生涯时钟字段 %s 必须是整数" % key
	if int(clock.quarter) < 1 or int(clock.quarter) > 4:
		return "生涯时钟字段 quarter 必须在1至4之间"
	return ""

static func _validate_athlete(athlete: Dictionary) -> String:
	for key in ["name", "birth_year", "entry_id", "family_context_id", "technique", "skating", "jumps", "jump_foundation", "body", "mind", "resources"]:
		if not athlete.has(key):
			return "生涯选手数据缺少字段：%s" % key
	if not athlete.name is String:
		return "生涯字段 athlete.name 必须是字符串"
	if not _is_integer(athlete.birth_year):
		return "生涯字段 athlete.birth_year 必须是整数"
	if athlete.has("birth_date"):
		if not athlete.birth_date is Dictionary: return "生涯字段 athlete.birth_date 必须是对象"
		var date_errors: Array[String] = preload("res://src/domain/athlete_identity.gd").validate_birth_date(athlete.birth_date,int(athlete.birth_year))
		if not date_errors.is_empty(): return "生涯字段 athlete.birth_date：" + "；".join(date_errors)
	for key in ["entry_id", "family_context_id"]:
		if not athlete[key] is String:
			return "生涯字段 athlete.%s 必须是字符串" % key
	for key in ATHLETE_METRICS:
		if not athlete[key] is Dictionary:
			return "生涯字段 athlete.%s 必须是对象" % key
		var metrics: Dictionary = athlete[key]
		for metric_key in ATHLETE_METRICS[key]:
			if not metrics.has(metric_key):
				return "生涯字段 athlete.%s.%s 缺失" % [key, metric_key]
		for metric_key in metrics:
			if not _is_number(metrics[metric_key]):
				return "生涯字段 athlete.%s.%s 必须是数字" % [key, str(metric_key)]
			if float(metrics[metric_key]) < 0.0 or float(metrics[metric_key]) > 100.0:
				return "生涯字段 athlete.%s.%s 必须在0至100之间" % [key, str(metric_key)]
	if not athlete.jumps is Dictionary:
		return "生涯字段 athlete.jumps 必须是对象"
	for jump_id in JumpCatalog.JUMP_IDS:
		if not athlete.jumps.get(jump_id) is Dictionary:
			return "生涯字段 athlete.jumps.%s 必须是对象" % jump_id
		var jump_error := _validate_jump(athlete.jumps[jump_id], jump_id)
		if not jump_error.is_empty():
			return jump_error
	if not athlete.jump_foundation is Dictionary:
		return "生涯字段 athlete.jump_foundation 必须是对象"
	for metric in JUMP_FOUNDATION_METRICS:
		if not athlete.jump_foundation.has(metric):
			return "生涯字段 athlete.jump_foundation.%s 缺失" % metric
		if not _is_number(athlete.jump_foundation[metric]) or float(athlete.jump_foundation[metric]) < 0.0 or float(athlete.jump_foundation[metric]) > 100.0:
			return "生涯字段 athlete.jump_foundation.%s 必须在0至100之间" % metric
	return ""

static func _validate_jump(jump: Dictionary, jump_id: String) -> String:
	for key in ["jump_id", "unlocked_rotations", "attempts", "proficiency", "consistency", "takeoff", "air", "landing", "habits", "observations"]:
		if not jump.has(key):
			return "生涯字段 athlete.jumps.%s.%s 缺失" % [jump_id, key]
	if jump.jump_id != jump_id:
		return "生涯字段 athlete.jumps.%s.jump_id 必须等于%s" % [jump_id, jump_id]
	if not _is_integer(jump.unlocked_rotations) or int(jump.unlocked_rotations) < 0 or int(jump.unlocked_rotations) > 4:
		return "生涯字段 athlete.jumps.%s.unlocked_rotations 必须是0至4的整数" % jump_id
	if not _is_integer(jump.attempts) or int(jump.attempts) < 0:
		return "生涯字段 athlete.jumps.%s.attempts 必须是非负整数" % jump_id
	for group_name in ["proficiency", "consistency", "takeoff", "air", "landing", "habits"]:
		if not jump[group_name] is Dictionary:
			return "生涯字段 athlete.jumps.%s.%s 必须是对象" % [jump_id, group_name]
		for metric in jump[group_name]:
			if not _is_number(jump[group_name][metric]) or float(jump[group_name][metric]) < 0.0 or float(jump[group_name][metric]) > 100.0:
				return "生涯字段 athlete.jumps.%s.%s.%s 必须在0至100之间" % [jump_id, group_name, str(metric)]
	if not jump.observations is Array:
		return "生涯字段 athlete.jumps.%s.observations 必须是数组" % jump_id
	return ""

static func _validate_outcome(outcome: Dictionary, index: int) -> String:
	if outcome.get("category") == "dated_training":
		if not outcome.get("date") is String or not preload("res://src/simulation/dated_training_window.gd").plan(outcome.date,outcome.date).errors.is_empty(): return "日训练履历日期无效"
		var attempts = outcome.get("actual_jump_attempts")
		if not _is_integer(attempts) or not is_finite(float(attempts)) or float(attempts) < 0 or float(attempts) > 1000000: return "日训练履历实际次数无效"
		if outcome.get("target") != "elapsed_day" or not _is_number(outcome.get("delta")) or float(outcome.delta) != 1.0: return "日训练履历时长无效"
		for group in ["technique_deltas","fatigue_deltas"]:
			if not outcome.has(group): continue # Earlier unpublished dated QA records.
			if not outcome[group] is Dictionary: return "日训练履历变化摘要无效"
			var allowed := ["rotation","landing","single_jumps"] if group == "technique_deltas" else ["acute_fatigue","cumulative_fatigue"]
			for metric in outcome[group]:
				var amount = outcome[group][metric]
				if not metric in allowed or not _is_number(amount) or not is_finite(float(amount)) or absf(float(amount)) > 100.0: return "日训练履历变化摘要数值无效"
		if outcome.has("peak_fatigue") and (not _is_number(outcome.peak_fatigue) or not is_finite(float(outcome.peak_fatigue)) or float(outcome.peak_fatigue) < 0 or float(outcome.peak_fatigue) > 100): return "日训练履历疲劳峰值无效"
	if outcome.get("category") == "coach_training":
		for key in outcome:
			if not key in ["category","clock","decision"]: return "未知教练训练履历字段"
		if not outcome.get("clock") is Dictionary or not _validate_clock(outcome.clock).is_empty(): return "教练训练履历日期无效"
		var errors: Array[String] = preload("res://src/domain/coach_training_state.gd").validate_decision(outcome.get("decision"))
		return "；".join(errors)
	if outcome.get("category") == "season_summary":
		return _validate_season_summary(outcome, index)
	if outcome.get("category") == "quarter_plan":
		return _validate_quarter_plan(outcome, index)
	if outcome.get("category") == "jump_attempt_batch":
		return _validate_jump_attempt_batch(outcome, index)
	if outcome.get("category") == "jump_milestone":
		return _validate_jump_milestone(outcome, index)
	if outcome.get("category") == "roadmap_progress":
		return _validate_roadmap_progress(outcome, index)
	for key in OUTCOME_FIELDS:
		if not outcome.has(key):
			return "生涯字段 history.%d.%s 缺失" % [index, key]
	for key in ["category", "target", "summary_key"]:
		if not outcome[key] is String:
			return "生涯字段 history.%d.%s 必须是字符串" % [index, key]
	if not _is_number(outcome.delta):
		return "生涯字段 history.%d.delta 必须是数字" % index
	if not outcome.cause_codes is Array:
		return "生涯字段 history.%d.cause_codes 必须是数组" % index
	for cause_index in outcome.cause_codes.size():
		if not outcome.cause_codes[cause_index] is String:
			return "生涯字段 history.%d.cause_codes.%d 必须是字符串" % [index, cause_index]
	return ""

static func _validate_quarter_plan(record: Dictionary, index: int) -> String:
	for key in ["category", "desired", "approved", "executed", "decisions", "secret_practice", "cause_codes"]:
		if not record.has(key):
			return "生涯字段 history.%d.%s 缺失" % [index, key]
	var has_percentage_layers := record.has("desired_shares") or record.has("approved_shares") or record.has("executed_shares")
	for layer in ["desired", "approved", "executed"]:
		if not record[layer] is Dictionary:
			return "生涯字段 history.%d.%s 必须是对象" % [index, layer]
		if has_percentage_layers and record[layer].is_empty():
			continue
		var normalized: Dictionary = {}
		for category_id in record[layer]:
			var value = record[layer][category_id]
			normalized[category_id] = int(value) if _is_integer(value) else value
		var plan_result := TrainingPlan.create(normalized)
		if not plan_result.errors.is_empty():
			return "生涯字段 history.%d.%s 不是有效训练计划" % [index, layer]
	if has_percentage_layers:
		for layer in ["desired", "approved", "executed"]:
			var shares_key := "%s_shares" % layer
			var targets_key := "%s_jump_rotations" % layer
			if not record.get(shares_key) is Dictionary or not record.get(targets_key) is Dictionary:
				return "生涯字段 history.%d.%s 与 %s 必须是对象" % [index, shares_key, targets_key]
			var normalized_shares: Dictionary = {}
			for category_id in record[shares_key]:
				var value = record[shares_key][category_id]
				normalized_shares[category_id] = int(value) if _is_integer(value) else value
			var normalized_targets: Dictionary = {}
			for jump_id in record[targets_key]:
				var value = record[targets_key][jump_id]
				normalized_targets[jump_id] = int(value) if _is_integer(value) else value
			var percentage_result := TrainingPlan.create(normalized_shares, normalized_targets)
			if not percentage_result.errors.is_empty():
				return "生涯字段 history.%d.%s 不是有效百分比训练计划" % [index, shares_key]
	if not record.decisions is Array or not record.cause_codes is Array:
		return "生涯字段 history.%d 的决定与原因必须是数组" % index
	if not record.secret_practice is Dictionary:
		return "生涯字段 history.%d.secret_practice 必须是对象" % index
	for key in ["executed_units", "efficiency", "discovered", "reaction", "memories", "blocked_reasons"]:
		if not record.secret_practice.has(key):
			return "生涯字段 history.%d.secret_practice.%s 缺失" % [index, key]
	var secret: Dictionary = record.secret_practice
	if not _is_integer(secret.executed_units) or int(secret.executed_units) < 0:
		return "生涯字段 history.%d.secret_practice.executed_units 必须是非负整数" % index
	if not _is_number(secret.efficiency) or float(secret.efficiency) < 0.0 or float(secret.efficiency) > 1.0:
		return "生涯字段 history.%d.secret_practice.efficiency 必须在0至1之间" % index
	if not secret.discovered is bool or not secret.reaction is String or not secret.memories is Array or not secret.blocked_reasons is Array:
		return "生涯字段 history.%d.secret_practice 类型无效" % index
	return ""

static func _validate_jump_attempt_batch(record: Dictionary, index: int) -> String:
	for key in ["jump_id", "rotations", "attempts", "successes", "clean_successes", "falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded", "probability", "cause_codes"]:
		if not record.has(key): return "生涯字段 history.%d.%s 缺失" % [index, key]
	if not TrainingPlan.JUMP_LABELS.has(record.jump_id) or not _is_integer(record.rotations) or int(record.rotations) < 1 or int(record.rotations) > 4:
		return "生涯字段 history.%d 的跳跃目标无效" % index
	for key in ["attempts", "successes", "clean_successes", "falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]:
		if not _is_integer(record[key]) or int(record[key]) < 0: return "生涯字段 history.%d.%s 必须是非负整数" % [index, key]
	if not _is_number(record.probability) or float(record.probability) < 0.0 or float(record.probability) > 1.0 or not record.cause_codes is Array:
		return "生涯字段 history.%d 的跳跃尝试概率或原因无效" % index
	return ""

static func _validate_jump_milestone(record: Dictionary, index: int) -> String:
	for key in ["signature", "jump_id", "rotations", "clock"]:
		if not record.has(key): return "生涯字段 history.%d.%s 缺失" % [index, key]
	if not record.signature is String or not TrainingPlan.JUMP_LABELS.has(record.jump_id) or not _is_integer(record.rotations) or not record.clock is Dictionary:
		return "生涯字段 history.%d 的跳跃里程碑无效" % index
	return ""

static func _validate_roadmap_progress(record: Dictionary, index: int) -> String:
	for key in ["clock", "status_change", "forecast_change", "key_events", "revision_suggestion"]:
		if not record.has(key): return "生涯字段 history.%d.%s 缺失" % [index, key]
	if not record.clock is Dictionary or not record.status_change is Dictionary:
		return "生涯字段 history.%d 的路线时点或状态变化无效" % index
	if not record.forecast_change is Array or not record.key_events is Array or not record.revision_suggestion is String:
		return "生涯字段 history.%d 的路线预测、事件或建议类型无效" % index
	for event_index in record.key_events.size():
		var event = record.key_events[event_index]
		if not event is Dictionary:
			return "生涯字段 history.%d.key_events.%d 必须是对象" % [index, event_index]
		for key in ["id", "signature", "title", "description", "trigger_codes", "cause_ids", "choices"]:
			if not event.has(key): return "生涯字段 history.%d.key_events.%d.%s 缺失" % [index, event_index, key]
		if not event.id is String or not event.signature is String or not event.title is String or not event.description is String:
			return "生涯字段 history.%d.key_events.%d 的文本字段无效" % [index, event_index]
		if not event.trigger_codes is Array or not event.cause_ids is Array or not event.choices is Array:
			return "生涯字段 history.%d.key_events.%d 的原因或选项无效" % [index, event_index]
	return ""

static func _validate_season_summary(summary: Dictionary, index: int) -> String:
	for key in ["category", "year", "technique_deltas", "peak_fatigue", "cause_codes"]:
		if not summary.has(key):
			return "生涯字段 history.%d.%s 缺失" % [index, key]
	if not summary.category is String:
		return "生涯字段 history.%d.category 必须是字符串" % index
	if not _is_integer(summary.year) or int(summary.year) < 1 or int(summary.year) > 9999:
		return "生涯字段 history.%d.year 必须是1至9999的整数" % index
	if not summary.technique_deltas is Dictionary:
		return "生涯字段 history.%d.technique_deltas 必须是对象" % index
	for target in summary.technique_deltas:
		if not target is String:
			return "生涯字段 history.%d.technique_deltas 的键必须是字符串" % index
		if not _is_number(summary.technique_deltas[target]):
			return "生涯字段 history.%d.technique_deltas.%s 必须是数字" % [index, target]
		if float(summary.technique_deltas[target]) < -100.0 or float(summary.technique_deltas[target]) > 100.0:
			return "生涯字段 history.%d.technique_deltas.%s 必须在-100至100之间" % [index, target]
	if not _is_number(summary.peak_fatigue) or float(summary.peak_fatigue) < 0.0 or float(summary.peak_fatigue) > 100.0:
		return "生涯字段 history.%d.peak_fatigue 必须是0至100之间的数字" % index
	if not summary.cause_codes is Array:
		return "生涯字段 history.%d.cause_codes 必须是数组" % index
	for cause_index in summary.cause_codes.size():
		if not summary.cause_codes[cause_index] is String:
			return "生涯字段 history.%d.cause_codes.%d 必须是字符串" % [index, cause_index]
	return ""

static func _is_number(value: Variant) -> bool:
	return value is int or value is float

static func _validate_training_checkpoint(career: Dictionary, checkpoint) -> String:
	if not checkpoint is Dictionary: return "训练暂停点必须是对象"
	var next_stage = checkpoint.get("next_stage")
	if not _is_integer(next_stage) or not is_finite(float(next_stage)) or int(next_stage) < 1 or int(next_stage) > 3: return "训练暂停阶段必须为1至3的整数"
	if int(career.training_period_state.weeks_elapsed) != int(next_stage)*3: return "训练暂停阶段与已训练周数不一致"
	if not checkpoint.get("plan") is Dictionary or not _validate_plan_data(checkpoint.plan).is_empty(): return "训练暂停点原课程无效"
	if not checkpoint.get("shares_acc") is Dictionary or not checkpoint.get("category_volumes_acc") is Dictionary: return "训练暂停点缺少已完成课程"
	var expression_acc = checkpoint.get("expression_share_acc",0.0)
	if not checkpoint.get("focus_lessons_acc",{}) is Dictionary: return "训练专项累计必须为对象"
	for key in checkpoint.get("focus_lessons_acc",{}):
		var value = checkpoint.focus_lessons_acc[key]
		var category := "skating_foundation" if key == "steps" else "program_"+str(key).trim_prefix("connections_")
		if not key in ["steps","connections_short","connections_free"] or not (value is int or value is float) or not is_finite(float(value)) or float(value)<0 or float(value)>float(checkpoint.get("shares_acc",{}).get(category,0.0)): return "训练专项累计无效"
	if not _is_number(expression_acc) or not is_finite(float(expression_acc)) or float(expression_acc) < 0.0 or float(expression_acc) > float(next_stage)*1.25: return "训练暂停点已完成表演课程无效"
	if float(expression_acc) > float(checkpoint.shares_acc.get("skating_foundation",0.0)): return "训练暂停点表演课程超过已完成滑行课程"
	var expression_quality = checkpoint.get("expression_quality_acc",expression_acc)
	if not _is_number(expression_quality) or not is_finite(float(expression_quality)) or float(expression_quality) < float(expression_acc)*0.5 or float(expression_quality) > float(expression_acc)*1.15+0.000001: return "训练暂停点表演教学累计无效"
	if checkpoint.has("lesson_quality_acc"):
		if not checkpoint.lesson_quality_acc is Dictionary: return "训练暂停点教学累计必须为对象"
		for category in checkpoint.lesson_quality_acc:
			var weight = checkpoint.lesson_quality_acc[category]
			var share := float(checkpoint.shares_acc.get(category,0.0))
			if not TrainingPlan.CATEGORY_IDS.has(category) or not _is_number(weight) or not is_finite(float(weight)) or float(weight)<share*0.5 or float(weight)>share*1.15+0.000001: return "训练暂停点教学累计无效"
	var share_sum := 0.0
	for category in checkpoint.shares_acc:
		var count = checkpoint.shares_acc[category]
		if not TrainingPlan.CATEGORY_IDS.has(category) or not _is_number(count) or not is_finite(float(count)) or float(count) < 0.0 or float(count) > 100.0: return "训练暂停点已完成课程份额无效"
		share_sum += float(count)
	if absf(share_sum-float(next_stage)*25.0) > 0.000001: return "训练暂停点已完成份额与时长不一致"
	for category in checkpoint.category_volumes_acc:
		var count = checkpoint.category_volumes_acc[category]
		if not TrainingPlan.CATEGORY_IDS.has(category) or not _is_number(count) or not is_finite(float(count)) or float(count) < 0.0 or float(count) > 100000.0: return "训练暂停点已完成课程量无效"
	var identity := "%d:%d:%d" % [int(career.clock.year),int(career.clock.quarter),int(career.rng_step)]
	if checkpoint.get("identity") != identity: return "训练暂停点不属于当前季度或随机流"
	var state = checkpoint.get("rng_state")
	if not state is String or not str(state).is_valid_int() or str(int(state)) != state: return "训练暂停点随机状态无效"
	var offset = checkpoint.get("acute_offset")
	if not _is_number(offset) or not is_finite(float(offset)) or float(offset) < 0.0 or float(offset) > 100.0: return "训练暂停点疲劳记录无效"
	var volume = checkpoint.get("volume")
	if not volume is Dictionary: return "训练暂停点缺少已确认预算"
	if not volume.get("jump_attempts") is Dictionary or not volume.get("category_volumes") is Dictionary: return "训练暂停点预算类型无效"
	for jump_id in volume.jump_attempts:
		var count = volume.jump_attempts[jump_id]
		if not TrainingPlan.JUMP_LABELS.has(jump_id) or not _is_integer(count) or not is_finite(float(count)) or float(count) < 0.0 or float(count) > 100000.0: return "训练暂停点跳跃预算无效"
	for category in volume.category_volumes:
		var count = volume.category_volumes[category]
		if not TrainingPlan.CATEGORY_IDS.has(category) or not _is_number(count) or not is_finite(float(count)) or float(count) < 0.0 or float(count) > 100000.0: return "训练暂停点课程预算无效"
	var quality = volume.get("quality")
	if not _is_number(quality) or not is_finite(float(quality)) or float(quality) < 0.0 or float(quality) > 1.15: return "训练暂停点训练质量无效"
	if not volume.get("specialist_attempts",[]) is Array: return "训练暂停点专项预算无效"
	for target in volume.get("specialist_attempts",[]):
		if not target is Dictionary or not target.get("action") is Dictionary: return "训练暂停点专项动作无效"
		if preload("res://src/domain/technical_repertoire.gd").action_id(target.action).is_empty(): return "训练暂停点专项动作无效"
		var count = target.get("attempts")
		if not _is_integer(count) or not is_finite(float(count)) or float(count) < 0.0 or float(count) > 100000.0: return "训练暂停点专项次数无效"
	return ""

static func _is_integer(value: Variant) -> bool:
	return _is_number(value) and is_equal_approx(float(value), floorf(float(value)))

static func _remove_file_if_present(path: String) -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

static func _failure(error: String) -> Dictionary:
	return {"ok": false, "career": null, "errors": [error]}
