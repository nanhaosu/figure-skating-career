class_name CompetitionArchiveCodec
extends RefCounted

const MAX_RAW_BYTES := 32 * 1024 * 1024
const MAX_ENCODED_BYTES := 16 * 1024 * 1024
const BODY_FIELDS := ["roster","short_results","free_results"]
static var _validated_payloads: Dictionary = {}

# Scores, judge marks, calls, performances and source snapshots are lossless.
# Only duplicate score aliases and reproducible display trajectories are omitted.
static func compact(archive: Dictionary) -> Dictionary:
	if archive.has("packed_archive") or archive.get("status") != "complete": return archive
	if not archive.get("roster") is Array or not archive.get("short_results") is Dictionary or not archive.get("free_results") is Dictionary: return archive
	# A packed archive is immutable after commit. Freeze its source once so
	# later numeric passes can safely share it without repeatedly inflating
	# every historical protocol.
	var source := archive.duplicate()
	for field in ["short_results","free_results"]:
		var records: Dictionary = archive[field]
		var packed_records := {}
		for id in records:
			var record: Dictionary = records[id].duplicate()
			packed_records[id] = record
			if record.get("score",{}) == record.get("protocol",{}):
				record.erase("score"); record.score_from_protocol = true
			# The path is display-only and can be rebuilt exactly from the frozen
			# athlete/program snapshot, performance result, seed and duration.
			# Legacy records without that explicit contract keep their old path.
			if record.get("route_source",{}).get("version",0) == 1:
				record.erase("route_execution")
		source[field] = packed_records
	var raw := JSON.stringify(source,"",true,true)
	var bytes := raw.to_utf8_buffer()
	if bytes.size() > MAX_RAW_BYTES: return archive
	var index := _index(source)
	var payload := Marshalls.raw_to_base64(bytes.compress(FileAccess.COMPRESSION_GZIP))
	index.packed_archive = {"version":1,"encoding":"gzip_base64","raw_bytes":bytes.size(),"sha256":raw.sha256_text(),"payload":payload,"payload_sha256":payload.sha256_text()}
	_remember_valid(index)
	return index

static func canonical_copy(archive: Dictionary) -> Dictionary:
	if archive.has("packed_archive"): return archive
	var decoded := _decode(archive)
	# The repository validates before normalization; keep invalid input
	# invalid instead of repairing an untrusted index from a different source.
	if not decoded.error.is_empty(): return archive
	var source: Dictionary = decoded.data
	var canonical: Dictionary = load("res://src/persistence/numeric_state.gd").canonical_copy(source)
	if is_same(canonical,source): return archive
	return compact(canonical)

static func _index(source: Dictionary) -> Dictionary:
	var index := {}
	for key in source:
		if not key in BODY_FIELDS: index[key] = source[key].duplicate(true) if source[key] is Array or source[key] is Dictionary else source[key]
	index.roster = []
	for row in source.get("roster",[]):
		var identity: Dictionary = row.duplicate()
		for key in ["athlete","short_program","free_program"]: identity.erase(key)
		index.roster.append(identity.duplicate(true))
	for segment in ["short","free"]:
		index[segment+"_results"] = {}
		for id in source.get(segment+"_results",{}):
			var record: Dictionary = source[segment+"_results"][id]
			var score := {}
			for key in ["total","tes","pcs","deductions","domestic_bonus"]: score[key] = record.get("score",record.get("protocol",{})).get(key,0)
			index[segment+"_results"][id] = {"score":score}
	return index

static func _decode(archive: Dictionary, restore_body: bool = true) -> Dictionary:
	if not archive.has("packed_archive"): return {"data":archive.duplicate(true),"error":""}
	var packed = archive.packed_archive
	if not packed is Dictionary or packed.get("version") != 1 or packed.get("encoding") != "gzip_base64": return {"data":{},"error":"压缩比赛档案版本无效"}
	if not (packed.get("raw_bytes") is int or packed.get("raw_bytes") is float): return {"data":{},"error":"压缩比赛档案大小无效"}
	var size := int(packed.raw_bytes)
	if size <= 0 or size > MAX_RAW_BYTES or float(packed.raw_bytes) != size: return {"data":{},"error":"压缩比赛档案大小超限"}
	if not packed.get("payload") is String or packed.payload.length() > MAX_ENCODED_BYTES or not packed.get("sha256") is String: return {"data":{},"error":"压缩比赛档案载荷无效"}
	if packed.payload.sha256_text() != packed.get("payload_sha256",""): return {"data":{},"error":"压缩比赛档案载荷校验失败"}
	var compressed := Marshalls.base64_to_raw(packed.payload)
	if compressed.size() < 18 or compressed[0] != 31 or compressed[1] != 139: return {"data":{},"error":"压缩比赛档案载荷无效"}
	var bytes := compressed.decompress(size,FileAccess.COMPRESSION_GZIP)
	compressed = PackedByteArray()
	if bytes.size() != size: return {"data":{},"error":"压缩比赛档案解包失败"}
	var raw := bytes.get_string_from_utf8()
	bytes = PackedByteArray()
	if raw.sha256_text() != packed.sha256: return {"data":{},"error":"压缩比赛档案校验失败"}
	var parsed = JSON.parse_string(raw)
	raw = ""
	if not parsed is Dictionary: return {"data":{},"error":"压缩比赛档案内容无效"}
	if not parsed.get("roster") is Array: return {"data":{},"error":"压缩比赛档案缺少名单"}
	for row in parsed.roster:
		if not row is Dictionary: return {"data":{},"error":"压缩比赛档案名单无效"}
	for segment in ["short","free"]:
		if not parsed.get(segment+"_results") is Dictionary: return {"data":{},"error":"压缩比赛档案缺少成绩"}
		for record in parsed[segment+"_results"].values():
			if not record is Dictionary or not record.get("protocol") is Dictionary: return {"data":{},"error":"压缩比赛档案小分表无效"}
	var index: Dictionary = load("res://src/domain/career_state.gd")._restore_competition_state(archive)
	index.erase("packed_archive")
	var rebuilt := _index(parsed)
	# Validation compares only the public index. Restoring the complete private
	# protocol tree here used to clone it and walk all historical telemetry.
	# Extract first, then apply exactly the same integer rules to the index.
	rebuilt = load("res://src/domain/career_state.gd")._restore_competition_state(rebuilt,false)
	# Scores are numeric quantities; JSON's 0 -> 0.0 conversion is not an
	# altered score. Normalize only these known summaries on comparison copies,
	# leaving the payload, unknown fields and original public index untouched.
	_normalize_score_index(rebuilt)
	_normalize_score_index(index)
	if JSON.stringify(rebuilt) != JSON.stringify(index): return {"data":{},"error":"比赛档案索引与已提交来源不一致"}
	if restore_body:
		# JSON.parse_string owns this tree; callers cannot alias it. Expansion
		# still restores every original field, without a second complete copy.
		parsed = load("res://src/domain/career_state.gd")._restore_competition_state(parsed,false)
	return {"data":parsed,"error":""}

static func _normalize_score_index(index: Dictionary) -> void:
	for segment in ["short","free"]:
		var rows = index.get(segment+"_results",{})
		if not rows is Dictionary: continue
		for row in rows.values():
			if not row is Dictionary or not row.get("score") is Dictionary: continue
			for key in ["total","tes","pcs","deductions","domestic_bonus"]:
				var value = row.score.get(key)
				if (value is int or value is float) and is_finite(float(value)): row.score[key] = float(value)

static func validate(archive: Dictionary, deep: bool = true) -> String:
	if not archive.has("packed_archive"): return ""
	var packed = archive.packed_archive
	if not packed is Dictionary or packed.get("version") != 1 or packed.get("encoding") != "gzip_base64": return "压缩比赛档案版本无效"
	if not (packed.get("raw_bytes") is int or packed.get("raw_bytes") is float) or int(packed.raw_bytes) <= 0 or int(packed.raw_bytes) > MAX_RAW_BYTES: return "压缩比赛档案大小无效"
	if not packed.get("payload") is String or packed.payload.length() > MAX_ENCODED_BYTES or packed.payload.sha256_text() != packed.get("payload_sha256",""): return "压缩比赛档案载荷校验失败"
	for digest_field in ["sha256","payload_sha256"]:
		var digest = packed.get(digest_field)
		if not digest is String or digest.length() != 64 or not digest.is_valid_hex_number(): return "压缩比赛档案载荷校验失败"
	if not deep: return ""
	var key := _validation_key(archive)
	if _validated_payloads.has(key): return ""
	var error := str(_decode(archive,false).error)
	if error.is_empty(): _remember_valid(archive)
	return error

static func _validation_key(archive: Dictionary) -> String:
	var packed: Dictionary = archive.get("packed_archive",{})
	var public_index := archive.duplicate(false)
	public_index.erase("packed_archive")
	return "%s:%s:%s:%s" % [str(packed.get("payload_sha256","")),str(packed.get("sha256","")),str(packed.get("raw_bytes","")),JSON.stringify(public_index).sha256_text()]

static func _remember_valid(archive: Dictionary) -> void:
	if _validated_payloads.size() >= 512: _validated_payloads.clear()
	_validated_payloads[_validation_key(archive)] = true

static func expand(archive: Dictionary) -> Dictionary:
	var decoded := _decode(archive)
	if not decoded.error.is_empty(): return {}
	var source: Dictionary = decoded.data
	for segment in ["short","free"]:
		for record in source.get(segment+"_results",{}).values():
			if record.get("score_from_protocol",false): record.score = record.protocol.duplicate(true); record.erase("score_from_protocol")
	# Packed bodies were already detached and integer-restored by _decode().
	# Restoring them again traverses/copies every frozen athlete and protocol.
	# Legacy unpacked archives still need their original restoration path.
	return source if archive.has("packed_archive") else load("res://src/domain/career_state.gd")._restore_competition_state(source)

static func replay_record(record: Dictionary) -> Dictionary:
	var display := record.duplicate(true)
	if not display.has("route_source"): return display
	if display.route_source.get("version") != 1: return {}
	var snapshot: Dictionary = display.snapshot
	var athlete = load("res://src/domain/athlete_state.gd").from_dict(snapshot.athlete)
	var program = load("res://src/domain/skating_program.gd").from_dict(snapshot.program)
	var fatigue := float(snapshot.get("context",{}).get("starting_fatigue",0.0))
	var plan: Dictionary = load("res://src/simulation/competition_route_planner.gd").plan(athlete,program,{"complexity":program.route_complexity,"choreography_quality":program.choreography_quality,"starting_fatigue":fatigue},int(display.seed) ^ 0x31A5)
	# Display only: never call performance, technical review or judging again.
	display.route_execution = load("res://src/simulation/competition_route_executor.gd").execute(plan,display.performance,athlete,{"starting_fatigue":fatigue,"familiarity":program.whole_run_familiarity,"duration_seconds":display.route_source.duration_seconds})
	return display
