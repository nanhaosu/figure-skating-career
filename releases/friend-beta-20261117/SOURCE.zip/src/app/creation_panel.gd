class_name CreationPanel
extends VBoxContainer

const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")
const CareerState = preload("res://src/domain/career_state.gd")
const ClubCoachRepository = preload("res://src/content/club_coach_repository.gd")

signal career_created(career: CareerState)
signal guidance_selected(companion: bool)

var catalog: Dictionary = {}
var club_coach_repository := ClubCoachRepository.new()

@onready var display_name_input: LineEdit = %DisplayNameInput
@onready var birth_year_input: SpinBox = %BirthYearInput
@onready var skating_start_age_input: SpinBox = %SkatingStartAgeInput
@onready var entry_path_input: OptionButton = %EntryPathInput
@onready var family_profile_input: OptionButton = %FamilyProfileInput
@onready var club_input: OptionButton = %ClubInput
@onready var coach_input: OptionButton = %CoachInput
@onready var seed_input: SpinBox = %SeedInput
@onready var entry_description: Label = %EntryDescription
@onready var family_description: Label = %FamilyDescription
@onready var club_description: Label = %ClubDescription
@onready var coach_description: Label = %CoachDescription
@onready var selection_summary: RichTextLabel = %SelectionSummary
@onready var error_label: Label = %ErrorLabel
@onready var create_button: Button = %CreateButton
@onready var advanced_seed_toggle: CheckButton = %AdvancedSeedToggle
var _generated_seed := 1
var _wizard_step := 0
var _step_title: Label
var _back_step: Button
var _next_step: Button
var _guidance: OptionButton
var _review: Label
var _advanced_row: HBoxContainer

func _build_wizard() -> void:
	_step_title = Label.new()
	_step_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_step_title)
	move_child(_step_title, 1)
	_guidance = OptionButton.new()
	_guidance.add_item("陪伴引导")
	_guidance.add_item("简洁模式")
	add_child(_guidance)
	move_child(_guidance, $Form.get_index() + 1)
	_advanced_row = HBoxContainer.new()
	add_child(_advanced_row)
	move_child(_advanced_row, _guidance.get_index() + 1)
	advanced_seed_toggle.reparent(_advanced_row)
	%SeedLabel.reparent(_advanced_row)
	seed_input.reparent(_advanced_row)
	_review = Label.new()
	_review.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(_review)
	move_child(_review, selection_summary.get_index())
	var buttons := HBoxContainer.new()
	add_child(buttons)
	_back_step = Button.new()
	_back_step.text = "上一步"
	_back_step.pressed.connect(func(): show_step(_wizard_step - 1))
	buttons.add_child(_back_step)
	_next_step = Button.new()
	_next_step.text = "下一步"
	_next_step.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_next_step.pressed.connect(_advance_wizard)
	buttons.add_child(_next_step)
	create_button.reparent(buttons)
	create_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	create_button.text = "生成童年回顾"
	error_label.reparent(self)
	move_child(error_label, buttons.get_index())
	error_label.add_theme_color_override("font_color", Color("ffadad"))
	reset_wizard()

func reset_wizard() -> void:
	if _guidance == null: return
	_guidance.select(0 if preload("res://src/app/frontend_preferences.gd").read().guidance == "companion" else 1)
	show_step(0)

func show_step(index: int) -> void:
	_wizard_step = clampi(index, 0, 2)
	_step_title.text = "第 %d 步 / 3 · %s" % [_wizard_step + 1, ["身份与引导","学滑经历和训练环境","确认并开始生涯"][_wizard_step]]
	var identity := _wizard_step == 0
	var background := _wizard_step == 1
	$BirthDateRow.visible = identity
	$Subtitle.visible = identity
	_guidance.visible = identity
	$Form.visible = _wizard_step < 2
	for field in [$Form/DisplayNameLabel, display_name_input, $Form/BirthYearLabel, birth_year_input]:
		field.visible = identity
	for field in [$Form/SkatingStartAgeLabel, skating_start_age_input, $Form/EntryPathLabel, entry_path_input, $Form/FamilyProfileLabel, family_profile_input, $Form/ClubLabel, club_input, $Form/CoachLabel, coach_input]:
		field.visible = background
	_advanced_row.visible = background
	%SeedLabel.visible = background and advanced_seed_toggle.button_pressed
	seed_input.visible = %SeedLabel.visible
	_review.visible = _wizard_step == 2
	if _review.visible:
		_review.text = "%s · 女子单人滑 · %d年出生\n%d岁开始学滑 · %s · %s\n%s · %s\n童年回顾后，你可以与教练商议生涯目标。" % [
			display_name_input.text.strip_edges(), int(birth_year_input.value), int(skating_start_age_input.value),
			entry_path_input.get_item_text(entry_path_input.selected), family_profile_input.get_item_text(family_profile_input.selected),
			club_input.get_item_text(club_input.selected), coach_input.get_item_text(coach_input.selected)]
	selection_summary.visible = not identity
	selection_summary.scroll_to_line(0)
	error_label.text = ""
	_back_step.visible = not identity
	_next_step.visible = _wizard_step < 2
	create_button.visible = _wizard_step == 2

func _advance_wizard() -> void:
	if _wizard_step == 0:
		var name_text := display_name_input.text.strip_edges()
		if name_text.is_empty() or name_text.length() > 20:
			error_label.text = "请输入1至20个字符的姓名。"
			display_name_input.grab_focus()
			return
	show_step(_wizard_step + 1)

func companion_guidance() -> bool:
	return _guidance == null or _guidance.selected == 0

func _ready() -> void:
	_generated_seed = maxi(1,(int(Time.get_ticks_usec()) ^ int(Time.get_unix_time_from_system())) & 0x7fffffff)
	if catalog.is_empty():
		catalog = CatalogRepository.load_catalog()
	var catalog_errors: Array = catalog.get("errors", [])
	catalog_errors.append_array(club_coach_repository.errors())
	if not catalog_errors.is_empty():
		create_button.disabled = true
		error_label.text = "\n".join(catalog_errors)
		return
	_populate_background_choices()
	_populate_club_choices()
	entry_path_input.item_selected.connect(_update_descriptions)
	family_profile_input.item_selected.connect(_update_descriptions)
	club_input.item_selected.connect(_on_club_selected)
	coach_input.item_selected.connect(_update_descriptions)
	birth_year_input.value_changed.connect(_update_content_scope)
	_update_content_scope()
	create_button.pressed.connect(_on_create_pressed)
	advanced_seed_toggle.toggled.connect(func(enabled):
		%SeedLabel.visible = enabled
		seed_input.visible = enabled)
	%SeedLabel.visible = false
	seed_input.visible = false
	_build_wizard()

func _update_content_scope(_value: float = 0.0) -> void:
	var birth_year := int(birth_year_input.value)
	var subtitle: Label = $Subtitle
	if birth_year == 2006:
		subtitle.text = "含2014–2021—22生涯与北京周期；2022–23正式赛事逐场试点。\n2006年出生可依生日、成绩争取青年或成年资格，派遣另行选拔。"
	else:
		subtitle.text = "含2014–2021—22生涯与北京周期；2022–23正式赛事逐场试点。\n%d年出生可争取适龄青年赛事，但不满足北京冬奥成年年龄门槛。" % birth_year
	subtitle.tooltip_text = "出生年份不保证名额或奖牌，国际年龄按具体生日核对。个人年龄与国际技术分、国家席位、国内派遣分别判定；国内夺冠不自动获得国际名额。未核实历史细则会标注采用版本或游戏规则；已有存档不会被改写。"

func create_career(display_name: String, birth_year: int, entry_path_id: String, family_profile_id: String, seed: int, skating_start_age: int = 4, club_id: String = "__default__", coach_id: String = "__default__", birth_date: Dictionary = {}) -> Dictionary:
	var catalog_errors: Array = catalog.get("errors", [])
	if not catalog_errors.is_empty():
		if error_label != null:
			error_label.text = "\n".join(catalog_errors)
		return {"career": null, "errors": catalog_errors.duplicate()}
	if club_id == "__default__": club_id = str(club_input.get_selected_metadata())
	if coach_id == "__default__": coach_id = str(coach_input.get_selected_metadata())
	var result := CareerFactory.create_from_profile({
		"display_name": display_name, "birth_year": birth_year,
		"birth_date": birth_date,
		"entry_path_id": entry_path_id, "family_profile_id": family_profile_id,
		"skating_start_age": skating_start_age, "club_id": club_id, "coach_id": coach_id,
		"catalog": catalog,
	}, seed)
	if result.errors.is_empty():
		if error_label != null:
			error_label.text = ""
		career_created.emit(result.career)
	elif error_label != null:
		error_label.text = "\n".join(result.errors)
	return result

func _populate_background_choices() -> void:
	entry_path_input.clear()
	family_profile_input.clear()
	var backgrounds: Dictionary = catalog.get("backgrounds", {})
	var entry_paths: Dictionary = backgrounds.get("entry_paths", {})
	var family_profiles: Dictionary = backgrounds.get("family_profiles", {})
	for entry_id in entry_paths:
		entry_path_input.add_item(str(entry_paths[entry_id].name))
		entry_path_input.set_item_metadata(entry_path_input.item_count - 1, entry_id)
	for profile_id in family_profiles:
		family_profile_input.add_item(str(family_profiles[profile_id].name))
		family_profile_input.set_item_metadata(family_profile_input.item_count - 1, profile_id)
	if entry_path_input.item_count > 0:
		entry_path_input.select(0)
	if family_profile_input.item_count > 0:
		family_profile_input.select(0)
	_update_descriptions(0)

func _populate_club_choices() -> void:
	club_input.clear()
	for club in club_coach_repository.clubs():
		club_input.add_item(str(club.name))
		club_input.set_item_metadata(club_input.item_count - 1, str(club.id))
	if club_input.item_count > 0:
		club_input.select(0)
	_on_club_selected(0)

func _on_club_selected(_selected_index: int) -> void:
	coach_input.clear()
	var club_id := str(club_input.get_selected_metadata()) if club_input.item_count > 0 else ""
	for coach in club_coach_repository.coaches_for_club(club_id):
		coach_input.add_item(str(coach.name))
		coach_input.set_item_metadata(coach_input.item_count - 1, str(coach.id))
	if coach_input.item_count > 0:
		coach_input.select(0)
	_update_descriptions(0)

func _update_descriptions(_selected_index: int) -> void:
	var backgrounds: Dictionary = catalog.get("backgrounds", {})
	var entry_paths: Dictionary = backgrounds.get("entry_paths", {})
	var family_profiles: Dictionary = backgrounds.get("family_profiles", {})
	if entry_path_input.item_count > 0:
		var entry_id := str(entry_path_input.get_selected_metadata())
		entry_description.text = str(entry_paths.get(entry_id, {}).get("description", ""))
	if family_profile_input.item_count > 0:
		var profile_id := str(family_profile_input.get_selected_metadata())
		family_description.text = str(family_profiles.get(profile_id, {}).get("description", ""))
	if club_input.item_count > 0:
		var club := club_coach_repository.club_profile(str(club_input.get_selected_metadata()))
		var resources: Dictionary = club.get("resources", {})
		club_description.text = "%s\n冰时：%s · 医疗：%s · 赛事支持：%s · 个人关注：%s\n培养方式：%s · 内部竞争：%s" % [
			str(club.get("summary", "")), str(resources.get("ice", "未知")), str(resources.get("medical", "未知")),
			str(resources.get("competition_support", "未知")), str(resources.get("individual_attention", "未知")),
			str(club.get("support_model", "")), str(club.get("competition_pressure", "")),
		]
	if coach_input.item_count > 0:
		var coach := club_coach_repository.public_coach_summary(str(coach_input.get_selected_metadata()))
		var strengths: Array = coach.get("known_strengths", [])
		var concerns: Array = coach.get("known_concerns", [])
		var ratings: Dictionary = coach.get("visible_ratings", {})
		var rating_lines: Array[String] = []
		for field in ClubCoachRepository.RATING_FIELDS:
			rating_lines.append("%s：%s" % [field, str(ratings.get(field, "未知"))])
		coach_description.text = "%s\n%s\n%s\n擅长：%s%s" % [
			str(coach.get("style", "")), str(coach.get("history", "")), " · ".join(rating_lines),
			"、".join(strengths), ("\n需要观察：" + "、".join(concerns)) if not concerns.is_empty() else "",
		]
	selection_summary.text = "入门：%s\n家庭：%s\n俱乐部：%s\n教练：%s" % [
		entry_description.text, family_description.text, club_description.text, coach_description.text,
	]

func _on_create_pressed() -> void:
	var date := {}
	if %BirthMonthInput.value != 0 or %BirthDayInput.value != 0:
		date = {"year":int(birth_year_input.value),"month":int(%BirthMonthInput.value),"day":int(%BirthDayInput.value)}
	var result := create_career(
		display_name_input.text,
		int(birth_year_input.value),
		str(entry_path_input.get_selected_metadata()),
		str(family_profile_input.get_selected_metadata()),
		_seed_for_creation(),
		int(skating_start_age_input.value),
		str(club_input.get_selected_metadata()),
		str(coach_input.get_selected_metadata()),
		date,
	)
	if result.errors.is_empty():
		guidance_selected.emit(companion_guidance())

func _seed_for_creation() -> int:
	if advanced_seed_toggle.button_pressed: return int(seed_input.value)
	_generated_seed = int((int(_generated_seed) * 1103515245 + 12345) & 0x7fffffff)
	return maxi(1,_generated_seed)
