class_name CompetitionIceView
extends Control

const SkaterArt = preload("res://src/presentation/competition_skater_art.gd")
var _performance := {}
var _duration := 78.0
var _motion_windows: Array[Dictionary] = []
var _broadcast_art := false


const SUCCESS_COLOR := Color("42c98b")
const REVIEW_COLOR := Color("f0bd4f")
const ERROR_COLOR := Color("ef6672")
const ROUTE_COLOR := Color(0.12, 0.55, 0.72, 0.92)
const FUTURE_ROUTE_COLOR := Color(0.22, 0.49, 0.60, 0.10)

var visible_route_point_count := 0
var visible_action_count := 0
var skater_position := Vector2.ZERO
var combination_links: Array[Dictionary] = []
var action_node_colors: Dictionary = {}
var current_action_state: Dictionary = {}
var stage_preview := false

var _points: Array = []
var _anchors: Array = []
var _element_status: Dictionary = {}
var _action_phases: Array = []
var _progress := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	set_process(false)
	queue_redraw()

func load_timeline(route_execution: Dictionary, element_records: Array, duration := 0.0) -> void:
	_points = Array(route_execution.get("points", [])).duplicate(true)
	_anchors = Array(route_execution.get("action_anchors", [])).duplicate(true)
	_action_phases = Array(route_execution.get("action_phases", [])).duplicate(true)
	# Older committed records predate held route points. Adapt a private display copy only.
	if not route_execution.has("duration_seconds") and not _action_phases.is_empty():
		var points: Array[Dictionary] = []; points.assign(_points)
		var phases: Array[Dictionary] = []; phases.assign(_action_phases)
		_points = preload("res://src/simulation/competition_route_executor.gd")._hold_points(points,phases,_anchors)
	_broadcast_art = duration > 0.0
	_duration = maxf(duration, 1.0)
	_performance.clear()
	_motion_windows.clear()
	_element_status.clear()
	action_node_colors.clear()
	for record in element_records:
		var element_id := str(record.get("element_id", ""))
		var status := str(record.get("status", "success"))
		_performance[element_id] = record
		_element_status[element_id] = status
		action_node_colors[element_id] = _status_color(status)
	if _broadcast_art:
		_build_motion_windows()
	set_progress(0.0)

func set_progress(value: float) -> void:
	_progress = clampf(value, 0.0, 1.0)
	current_action_state = {}
	for raw_phase in _action_phases:
		var phase: Dictionary = Dictionary(raw_phase)
		if _progress >= float(phase.get("start", 0.0)) and _progress <= float(phase.get("end", 0.0)):
			current_action_state = phase
	visible_route_point_count = 0
	for point in _points:
		if float(point.get("progress", 0.0)) <= _progress + 0.0001:
			visible_route_point_count += 1
	visible_action_count = 0
	combination_links.clear()
	var previous_visible_anchor: Dictionary = {}
	for raw_anchor in _anchors:
		var anchor: Dictionary = Dictionary(raw_anchor)
		if float(anchor.get("progress", 0.0)) > _progress + 0.0001:
			continue
		visible_action_count += 1
		if (
			not previous_visible_anchor.is_empty()
			and str(previous_visible_anchor.get("element_id", "")) == str(anchor.get("element_id", ""))
		):
			combination_links.append({"from": previous_visible_anchor, "to": anchor})
		previous_visible_anchor = anchor
	skater_position = _position_at_progress(_progress)
	queue_redraw()

func update_element_status(element_id: String, status: String) -> void:
	_element_status[element_id] = status
	action_node_colors[element_id] = _status_color(status)
	queue_redraw()

func _build_motion_windows() -> void:
	for index in _anchors.size():
		var anchor: Dictionary = _anchors[index]
		var element: Dictionary = _performance.get(str(anchor.get("element_id", "")), {})
		if element.is_empty():
			continue
		var part_index := int(anchor.get("part_index", 0))
		var parts: Array = element.get("parts", [])
		if part_index > 0 and part_index >= parts.size():
			continue
		var part: Dictionary = parts[part_index] if part_index < parts.size() else element
		var center := float(anchor.get("progress", 0.5))
		var kind := str(element.get("kind", "jump"))
		var next_start := 1.0
		if index + 1 < _anchors.size():
			next_start = float(_anchors[index + 1].get("progress", 1.0)) - 0.35 / _duration
		var fall := bool(part.get("actual", {}).get("fall", false))
		var end := minf(next_start, center + (4.1 if fall else 1.05) / _duration)
		if kind == "spin":
			end = minf(next_start, center + 4.8 / _duration)
		elif kind != "jump":
			end = minf(next_start, center + 2.25 / _duration)
		_motion_windows.append({"start": center - 0.38 / _duration, "center": center, "end": maxf(center, end), "kind": kind, "part": part, "fall": fall, "element_id": str(anchor.get("element_id", ""))})

func completion_progress(element_id: String, fallback: float) -> float:
	var completion := fallback
	for window in _motion_windows:
		if window.element_id != element_id:
			continue
		var finish := float(window.end)
		if window.kind == "jump":
			finish = minf(finish, float(window.center) + (0.9 if window.fall else 0.6) / _duration)
		completion = maxf(completion, finish)
	return completion

func _draw_rink() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("dcebed"))
	var stands := minf(58.0, size.y * 0.19)
	draw_rect(Rect2(0, 0, size.x, stands), Color("71838d"))
	for row in 3:
		for x in range(12 + row * 7, int(size.x), 23):
			draw_rect(Rect2(x, 4 + row * stands / 3, 7, 5), Color("586f79"))
	draw_rect(Rect2(0, stands, size.x, 18), Color("eeeee7"))
	draw_rect(Rect2(0, stands + 17, size.x, 3), Color("c7b47b"))
	for offset in [0.29, 0.71]:
		var center := Vector2(size.x * offset, size.y * 0.62)
		draw_arc(center, minf(size.y * 0.19, size.x * 0.12), 0, TAU, 44, Color("c3d9df"), 1, true)

func _draw_skater() -> void:
	var point := skater_position
	var direction := _position_at_progress(minf(1.0, _progress + 0.002)) - _position_at_progress(maxf(0.0, _progress - 0.002))
	var mirror := direction.x < -0.002
	var sheet := 4
	var frame := 0
	var turns := 0.0
	var turn_frames: Array = []
	var lift := 0.0
	for window in _motion_windows:
		if _progress < window.start or _progress > window.end:
			continue
		var t := (_progress - float(window.center)) * _duration
		var part: Dictionary = window.part
		if window.kind == "jump":
			var jump := str(part.get("jump_id", ""))
			if jump.is_empty():
				var code := str(part.get("abbreviation", ""))
				for pair in [["Lz", "lutz"], ["Lo", "loop"], ["A", "axel"], ["F", "flip"], ["S", "salchow"], ["T", "toeloop"]]:
					if code.contains(pair[0]):
						jump = pair[1]
						break
			if t < 0:
				sheet = 2
				frame = int({"axel": 0, "salchow": 1, "loop": 2, "toe_loop": 3, "toeloop": 3, "flip": 4, "lutz": 5}.get(jump, 2))
			elif t < 0.6:
				sheet = 0
				turn_frames = SkaterArt.AIR
				var flight := t / 0.6
				var actual_turns := float(part.get("called_rotations", 1))
				var facts: Dictionary = part.get("facts", {})
				if facts.has("completed_rotation_ratio"):
					actual_turns = float(facts.get("planned_rotations", actual_turns)) * float(facts.completed_rotation_ratio)
				turns = flight * (actual_turns + (0.5 if jump == "axel" else 0.0))
				lift = 35.0 * 4.0 * flight * (1.0 - flight)
			elif window.fall:
				var span := maxf(0.02, (float(window.end) - float(window.center)) * _duration - 0.6)
				var recovery := clampf((t - 0.6) / span, 0.0, 1.0)
				var stop := float(window.center) + (0.6 + span * 0.34) / _duration
				var resume := float(window.center) + (0.6 + span * 0.78) / _duration
				var route_time := stop
				if _progress < stop:
					var incoming := float(window.center) + 0.6 / _duration
					var brake := clampf((_progress - incoming) / maxf(0.00001, stop - incoming), 0.0, 1.0)
					route_time = lerpf(incoming, stop, brake + brake * brake * (1.0 - brake))
				elif _progress > resume:
					var remaining := maxf(0.00001, float(window.end) - resume)
					var restart := clampf((_progress - resume) / remaining, 0.0, 1.0)
					var ratio := remaining / maxf(0.00001, float(window.end) - stop)
					route_time = lerpf(stop, float(window.end), restart * restart * ((ratio - 2.0) * restart + 3.0 - ratio))
				point = _position_at_progress(route_time)
				sheet = 4
				frame = 5 if recovery < 0.12 else (6 if recovery < 0.56 else (7 if recovery < 0.78 else 0))
			else:
				sheet = 1
				frame = 0
				mirror = not mirror
				if str(part.get("actual", {}).get("error_type", "")) == "two_foot":
					sheet = 0
					frame = 5
		elif window.kind == "spin" and t >= 0.0:
			var end := float(window.end)
			var blend_in := smoothstep(-0.15, 0.35, t)
			var blend_out := smoothstep(0.0, 0.45, (end - _progress) * _duration)
			point = point.lerp(_position_at_progress(float(window.center)), blend_in * blend_out)
			sheet = 3
			var code := str(part.get("abbreviation", ""))
			turn_frames = [0, 0, 0, 1]
			if code.contains("SSp"): turn_frames = [2, 2, 2, 3]
			elif code.contains("CSp"): turn_frames = [4, 4, 4, 5]
			elif code.contains("LSp"):
				sheet = 8
				turn_frames = [1, 0, 1, 2]
			elif code.contains("CoSp"):
				var form := t / maxf(.1, (end - float(window.center)) * _duration)
				turn_frames = [4, 4, 4, 5] if form < .33 else ([2, 2, 2, 3] if form < .66 else [0, 0, 0, 1])
			turns = t * 1.05
		else:
			sheet = 4
			frame = 1 if int(_progress * _duration * 2.0) % 2 else 0
		break
	if _progress <= 0.0 or _progress >= 1.0:
		sheet = 0
		frame = 5
	var foot := Vector2(
		28.0 + point.x * maxf(1.0, size.x - 56.0),
		125.0 + point.y * maxf(1.0, size.y - 155.0)
	)
	var zoom := clampf(size.y / 420.0, 0.65, 1.12) * lerpf(0.87, 1.04, point.y)
	draw_set_transform(foot, 0.0, Vector2(1.0, 0.22))
	draw_circle(Vector2.ZERO, 14.0 * zoom, Color("acc6cd"))
	draw_set_transform(Vector2.ZERO)
	foot.y -= lift * zoom
	if turn_frames.is_empty():
		SkaterArt.draw_frame(self, foot, sheet, frame, zoom, mirror)
	else:
		SkaterArt.draw_turn(self, foot, sheet, turn_frames, turns, zoom, mirror)

func _draw() -> void:
	if _broadcast_art and not _points.is_empty():
		_draw_rink()
		_draw_skater()
		return
	if stage_preview: _draw_stage()
	_draw_empty_ice_marks()
	if _points.is_empty():
		return
	var full_line := PackedVector2Array()
	for point in _points:
		full_line.append(_canvas_point(Vector2(float(point.get("x", 0.5)), float(point.get("y", 0.5)))))
	if full_line.size() >= 2:
		draw_polyline(full_line, FUTURE_ROUTE_COLOR, 1.7, true)
	var travelled := PackedVector2Array()
	for point in _points:
		if float(point.get("progress", 0.0)) <= _progress + 0.0001 and float(point.get("progress", 0.0)) >= _progress - 0.22:
			travelled.append(_canvas_point(Vector2(float(point.get("x", 0.5)), float(point.get("y", 0.5)))))
	travelled.append(_canvas_point(skater_position))
	if travelled.size() >= 2:
		draw_polyline(travelled, ROUTE_COLOR, 2.8, true)
	for link in combination_links:
		draw_line(_anchor_canvas_point(link.from), _anchor_canvas_point(link.to), Color(0.08, 0.25, 0.34, 0.8), 3.0, true)
	for raw_anchor in _anchors:
		var anchor: Dictionary = Dictionary(raw_anchor)
		if float(anchor.get("progress", 0.0)) > _progress + 0.0001:
			continue
		var element_id := str(anchor.get("element_id", ""))
		var center := _anchor_canvas_point(anchor)
		var color: Color = action_node_colors.get(element_id, SUCCESS_COLOR)
		draw_circle(center, 5.0, Color(0.02, 0.10, 0.14, 0.55))
		draw_circle(center, 3.0, color)
	var skater := _canvas_point(skater_position)
	_draw_action_phase(skater)
	var heading := (_canvas_point(_position_at_progress(minf(1.0,_progress+0.006))) - _canvas_point(_position_at_progress(maxf(0.0,_progress-0.006)))).normalized()
	if heading.length_squared() < 0.01: heading = Vector2.UP
	var side := Vector2(-heading.y, heading.x)
	draw_circle(skater+Vector2(2,3), 9.0, Color(0.02,0.12,0.18,0.16))
	var costume := Color("9d3458") if stage_preview else Color("214e66")
	draw_line(skater-side*9,skater+side*9,costume,3.0,true)
	draw_line(skater-heading*6,skater+heading*5,costume,6.0,true)
	draw_circle(skater+heading*8,3.8,Color("f7fcff"))
	draw_line(skater-heading*6-side*3,skater-heading*10-side*5,Color("214e66"),2.0,true)
	draw_line(skater-heading*6+side*3,skater-heading*10+side*5,Color("214e66"),2.0,true)

func _draw_stage() -> void:
	draw_rect(Rect2(Vector2.ZERO,size),Color("101f38"))
	var rink := Rect2(Vector2(10,10),size-Vector2(20,20))
	draw_rect(rink,Color("d8edf5"))
	for index in 18:
		var light := float(index)/17.0
		draw_rect(Rect2(Vector2(10,10+rink.size.y*light),Vector2(rink.size.x,rink.size.y/18.0)),Color(0.35,0.65,0.82,0.16*(1.0-light)))
	draw_rect(rink,Color("6f9ab1"),false,3.0)
	var spot := _canvas_point(skater_position)
	for radius in [43.0,32.0,21.0]:
		draw_circle(spot,radius,Color(1.0,1.0,0.95,0.11))

func _draw_action_phase(skater: Vector2) -> void:
	if current_action_state.is_empty(): return
	match str(current_action_state.get("kind", "")):
		"airborne":
			draw_arc(skater + Vector2(0, 5), 18.0, PI, TAU, 18, Color(0.16, 0.54, 0.78, 0.9), 2.0, true)
		"spin_hold":
			for radius in [12.0, 20.0, 28.0]: draw_arc(skater, radius, 0.0, TAU * 0.82, 32, Color(0.16, 0.55, 0.76, 0.38), 2.0, true)
		"step_run":
			for offset in [-24.0, -12.0, 12.0, 24.0]: draw_line(skater + Vector2(offset, -8), skater + Vector2(offset + 7, 0), Color(0.12, 0.42, 0.64, 0.7), 1.5, true)
		"fall_recovery", "recovery":
			draw_circle(skater, 18.0, Color(0.86, 0.18, 0.22, 0.28))
			draw_line(skater - Vector2(10, 10), skater + Vector2(10, 10), ERROR_COLOR, 3.0, true)
			draw_line(skater + Vector2(10, -10), skater - Vector2(10, 10), ERROR_COLOR, 3.0, true)

func _draw_empty_ice_marks() -> void:
	var center := size * 0.5
	draw_circle(center, minf(size.x, size.y) * 0.12, Color(0.25, 0.55, 0.64, 0.12), false, 2.0, true)
	draw_line(Vector2(20.0, center.y), Vector2(size.x - 20.0, center.y), Color(0.25, 0.55, 0.64, 0.08), 2.0)

func _position_at_progress(value: float) -> Vector2:
	if _points.is_empty(): return Vector2(0.5, 0.5)
	var first: Dictionary = Dictionary(_points.front())
	if value <= float(first.get("progress", 0.0)): return Vector2(float(first.get("x", 0.5)), float(first.get("y", 0.5)))
	for index in range(1, _points.size()):
		var previous: Dictionary = Dictionary(_points[index - 1])
		var current: Dictionary = Dictionary(_points[index])
		var current_progress := float(current.get("progress", 1.0))
		if value <= current_progress:
			var previous_progress := float(previous.get("progress", 0.0))
			var weight := inverse_lerp(previous_progress, current_progress, value)
			return Vector2(float(previous.get("x", 0.5)), float(previous.get("y", 0.5))).lerp(
				Vector2(float(current.get("x", 0.5)), float(current.get("y", 0.5))), weight
			)
	var last: Dictionary = Dictionary(_points.back())
	return Vector2(float(last.get("x", 0.5)), float(last.get("y", 0.5)))

func _anchor_canvas_point(anchor: Dictionary) -> Vector2:
	if anchor.has("x") and anchor.has("y"): return _canvas_point(Vector2(anchor.x,anchor.y))
	var normalized := _position_at_progress(float(anchor.get("progress", 0.0)))
	var part_index := int(anchor.get("part_index", 0))
	if part_index > 0:
		normalized += Vector2(0.012 * float(part_index), -0.012 * float(part_index))
	return _canvas_point(normalized)

func _canvas_point(normalized: Vector2) -> Vector2:
	var padding := Vector2(28.0, 24.0)
	return padding + normalized * (size - padding * 2.0)

func _status_color(status: String) -> Color:
	match status:
		"review": return REVIEW_COLOR
		"error": return ERROR_COLOR
		_: return SUCCESS_COLOR
