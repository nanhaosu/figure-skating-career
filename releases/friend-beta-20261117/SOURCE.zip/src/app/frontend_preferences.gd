extends RefCounted

const PATH := "user://frontend-preferences.cfg"
const WEB_KEY := "figure-skating-display-v1"
const DEFAULTS := {"font_size": 17, "guidance": "companion", "reduced_motion": false}

static func read() -> Dictionary:
	if OS.has_feature("web"):
		var raw = JavaScriptBridge.eval("try { localStorage.getItem('%s') || '{}' } catch (_) { '{}' }" % WEB_KEY, true)
		var parsed = JSON.parse_string(str(raw))
		return normalize(parsed) if parsed is Dictionary else DEFAULTS.duplicate()
	var config := ConfigFile.new()
	config.load(PATH)
	var values := {}
	for key in DEFAULTS:
		values[key] = config.get_value("display", key, DEFAULTS[key])
	return normalize(values)

static func write(values: Dictionary) -> bool:
	var settings := normalize(values)
	if OS.has_feature("web"):
		var code := "try { localStorage.setItem('%s', JSON.stringify(%s)); true } catch (_) { false }" % [WEB_KEY, JSON.stringify(settings)]
		return bool(JavaScriptBridge.eval(code, true))
	var config := ConfigFile.new()
	for key in settings:
		config.set_value("display", key, settings[key])
	return config.save(PATH) == OK

static func normalize(values: Dictionary) -> Dictionary:
	var size := int(values.get("font_size", 17))
	var guidance := str(values.get("guidance", "companion"))
	return {
		"font_size": size if size in [17, 19, 21] else 17,
		"guidance": "standard" if guidance == "standard" else "companion",
		"reduced_motion": bool(values.get("reduced_motion", false)),
	}
