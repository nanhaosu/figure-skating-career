extends Window

signal settings_changed(values: Dictionary)
signal help_requested
const Preferences = preload("res://src/app/frontend_preferences.gd")
var _font_size: OptionButton
var _guidance: CheckButton
var _motion: CheckButton
var _message: Label

func _ready() -> void:
	title = "游戏设置"
	transient = true
	exclusive = true
	close_requested.connect(hide)
	var panel := PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(panel)
	var column := VBoxContainer.new()
	panel.add_child(column)
	var title_label := Label.new()
	title_label.text = "文字大小"
	column.add_child(title_label)
	_font_size = OptionButton.new()
	for size_value in [17, 19, 21]:
		_font_size.add_item("%d px" % size_value, size_value)
	column.add_child(_font_size)
	_guidance = CheckButton.new()
	_guidance.text = "显示陪伴引导"
	column.add_child(_guidance)
	_motion = CheckButton.new()
	_motion.text = "减少动态效果（比赛直接显示成绩）"
	column.add_child(_motion)
	_message = Label.new()
	_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_message)
	var actions := HBoxContainer.new()
	column.add_child(actions)
	var save := Button.new()
	save.text = "保存设置"
	save.theme_type_variation = "PrimaryButton"
	save.pressed.connect(_save)
	actions.add_child(save)
	var restore := Button.new()
	restore.text = "恢复默认"
	restore.pressed.connect(func(): _show_values(Preferences.DEFAULTS))
	actions.add_child(restore)
	var help := Button.new()
	help.text = "花滑入门与帮助"
	help.pressed.connect(func(): hide(); help_requested.emit())
	actions.add_child(help)
	hide()

func present(values: Dictionary) -> void:
	_show_values(values)
	popup_centered(Vector2i(610, 388))

func _show_values(values: Dictionary) -> void:
	_font_size.select(_font_size.get_item_index(int(values.font_size)))
	_guidance.button_pressed = values.guidance == "companion"
	_motion.button_pressed = values.reduced_motion
	_message.text = ""

func _save() -> void:
	var values := {
		"font_size": _font_size.get_selected_id(),
		"guidance": "companion" if _guidance.button_pressed else "standard",
		"reduced_motion": _motion.button_pressed,
	}
	if not Preferences.write(values):
		_message.text = "设置无法保存，请重试。"
		return
	settings_changed.emit(values)
	_message.text = "设置已保存。"
