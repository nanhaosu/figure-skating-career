class_name PostCompetitionPresenter
extends RefCounted

static func build(career, archive: Dictionary = {}) -> Dictionary:
	var committed: Dictionary = archive
	if committed.is_empty() and not career.competition_archive.is_empty():
		committed = career.competition_archive.back()
	if committed.is_empty() and not career.competition_state.is_empty():
		committed = career.competition_state.get("archive",career.competition_state)
	var event_id := str(committed.get("event_id","competition"))
	var archive_ref := "competition:%s" % event_id
	var player := _player_result(committed)
	var rank := int(player.get("final_rank",player.get("rank",player.get("short_rank",committed.get("public_rank",0)))))
	var total := float(player.get("total_score",committed.get("total_score",0.0)))
	var result_title := "完成比赛" if rank <= 0 else "本场第%d名" % rank
	var result_text := "本场成绩已记录。" if rank <= 0 else "总分 %.2f。" % total
	if player.get("qualified",true) == false and not player.has("free_score") and player.has("short_score"):
		result_text = "短节目 %.2f，未晋级自由滑；没有两段总分。" % float(player.short_score)
	var memory_refs: Array = []
	var milestone_rows: Dictionary = career.experience_state.get("milestones",{})
	var debut: Dictionary = milestone_rows.get("first_jgp_start",{})
	var debut_here: bool = not debut.is_empty() and debut.get("event_id") == event_id
	if debut_here:
		var known_first: bool = debut.get("certainty") == "confirmed_first"
		result_title = ("JGP首秀" if known_first else "这次JGP国际出场")+(" · 第%d名" % rank if rank > 0 else "")
		var completed: bool = milestone_rows.get("first_jgp_complete",{}).get("event_id") == event_id
		result_text = "从争取派遣，到真正走上国际青年赛场，这次经历已留下记录。" if completed else "你已经在国际青年赛场出场；本次没有完成两套节目，原因与成绩按实际档案保留。"
		if rank > 0 and rank <= 3 and completed and str(committed.get("status","")) == "complete":
			result_text = "最终第%d名，你在这次国际出场中登上了JGP领奖台。从争取派遣到站上领奖台，这次成绩会留在你的履历里。" % rank
	for milestone in milestone_rows.values():
		if milestone.get("event_id") == event_id: memory_refs.append_array(milestone.get("evidence_refs",[]))
	var execution_title := "这次上场的表现"
	var execution_text := _execution_text(committed)
	var axel: Dictionary = milestone_rows.get("first_formal_3a",{})
	if not axel.is_empty() and axel.get("event_id") == event_id:
		execution_title = "3A · 从练习到正式兑现"
		var prefix := "首次在正式比赛中完成有效足周3A。" if axel.get("certainty") == "confirmed_first" else "本场已确认有效足周3A；现有旧档不足以确定更早的经历。"
		var contexts: Dictionary = career.technical_repertoire.entries.get("3A",{}).get("learned_history",{}).get("first_success_contexts",{})
		execution_text = prefix+("此前训练留下的完成记录，这次带到了赛场；一次完成不保证以后稳定。" if contexts.has("practice") or contexts.has("program") or contexts.has("program_late") else "这次落冰与最终技术认定已入档；以后仍要在不同身体状态下反复兑现。")
	else:
		var facts := preload("res://src/simulation/career_milestone_service.gd").inspect_archive(committed)
		var attempts: Array = facts.axel_attempts
		if not attempts.is_empty() and facts.axel_completed.is_empty():
			var attempt: Dictionary = attempts[0]
			var actual_code := str(attempt.get("actual_code",""))
			if actual_code.is_empty(): actual_code = str(attempt.get("executed_code",""))
			execution_title = "3A · 这次赛场尝试"
			execution_text = "本场尝试3A，"+("实际记录为%s；" % actual_code if not actual_code.is_empty() else "")+str(attempt.get("failure_reason","现有证据不足以确认"))+"，未记为有效足周完成。回到训练时，继续检验整套节目的转化，不把这次尝试抹去。"
	var training_refs := _history_refs(career,["training","jump_attempt_batch","roadmap_progress"],3)
	if training_refs.is_empty(): training_refs = [archive_ref]
	var consequence_refs := _history_refs(career,["competition_consequence","internal_competition","formal_competition"],3)
	if consequence_refs.is_empty(): consequence_refs = [archive_ref]
	return {
		"heading":"%s · 赛后记录" % str(committed.get("event_name","这场比赛")),
		"performance":{"title":result_title,"text":result_text,"evidence_refs":[archive_ref]},
		"training_evidence":{"title":execution_title,"text":execution_text,"evidence_refs":[archive_ref]},
		"consequences":{"title":"这场比赛改变了什么","text":_event_consequences(career,committed),"evidence_refs":[archive_ref]},
		"next_action":{"id":"return_home","label":"回到生涯主页","detail":"带着已经确认的结果，决定下一阶段做什么。","evidence_refs":[archive_ref]},
		"scoring_guide":_scoring_guide(committed),
		"programme_memory":_programme_memory(committed,career.competition_archive),
		"memory_refs":memory_refs,
		"meaning":{"debut":debut_here,"axel":not axel.is_empty() and axel.get("event_id") == event_id},
	}

static func _programme_memory(archive: Dictionary, history: Array) -> String:
	var lines: Array[String] = []
	for segment in ["short","free"]:
		var record: Dictionary = archive.get(segment+"_results",{}).get("player",{})
		var program: Dictionary = record.get("snapshot",{}).get("program",{})
		var revision = program.get("revision")
		var score = record.get("score",{}).get("total")
		if not (revision is int or revision is float) or int(revision) < 1: continue
		if not (score is int or score is float): continue
		var title := str(program.get("music",{}).get("title","")).strip_edges()
		var label := "短节目" if segment == "short" else "自由滑"
		var version := "第%d版" % int(revision)
		if not title.is_empty(): version = "《%s》%s" % [title,version]
		lines.append("%s · %s · %.2f分" % [label,version,float(score)])
		var best := _higher_programme_score(archive,history,segment,program,float(score))
		if not best.is_empty():
			lines.append("同版更高分 · %s · %.2f分" % [best.name,best.score])
	return "\n".join(lines)

static func _higher_programme_score(current: Dictionary, history: Array, segment: String, program: Dictionary, score: float) -> Dictionary:
	var id := str(program.get("program_id",""))
	if id.is_empty(): return {}
	var field := segment+"_results"
	var candidates: Array[Dictionary] = []
	for entry in history:
		if entry.get("status") != "complete" or entry.get("world_only",false) or entry.get("event_id") == current.get("event_id"): continue
		var total = entry.get(field,{}).get("player",{}).get("score",{}).get("total")
		if (total is int or total is float) and float(total) > score:
			candidates.append({"archive":entry,"score":float(total)})
	candidates.sort_custom(func(a,b): return a.score > b.score)
	for candidate in candidates:
		var entry: Dictionary = candidate.archive
		var detail := preload("res://src/persistence/competition_archive_codec.gd").expand(entry) if entry.has("packed_archive") else entry
		var previous: Dictionary = detail.get(field,{}).get("player",{}).get("snapshot",{}).get("program",{})
		if previous.get("program_id") == id and previous.get("revision") == program.revision:
			return {"name":str(entry.get("event_name",entry.get("event",{}).get("name","此前比赛"))),"score":candidate.score}
	return {}

static func _scoring_guide(archive: Dictionary) -> Dictionary:
	var segments: Array = []
	var lines: Array[String] = ["技术分TES来自动作基础分与完成质量GOE；内容分PCS评价滑行与节目呈现。负GOE不等于摔倒，摔倒等扣分另列。"]
	for segment in ["short","free"]:
		var score: Dictionary = archive.get(segment+"_results",{}).get("player",{}).get("score",{})
		if score.is_empty(): score = archive.get(segment,{}).get("score",{})
		if score.is_empty():
			var index := 0 if segment == "short" else 1
			var execution: Array = archive.get("execution_scores",[])
			if execution.size() > index and execution[index] is Dictionary: score = execution[index]
		var complete := true
		for key in ["tes","pcs","deductions","total"]:
			if not (score.get(key) is int or score.get(key) is float): complete = false
		if not complete: continue
		var row := {"segment":segment,"tes":float(score.tes),"pcs":float(score.pcs),"deductions":float(score.deductions),"domestic_bonus":float(score.get("domestic_bonus",0)),"total":float(score.total),"example":{}}
		var label := "短节目" if segment == "short" else "自由滑"
		var bonus := "＋国内奖励%.2f" % row.domestic_bonus if not is_zero_approx(row.domestic_bonus) else ""
		row.computed_total = snappedf(row.tes+row.pcs+row.domestic_bonus-row.deductions,0.01)
		row.arithmetic_matches = absf(row.computed_total-row.total) <= 0.011
		if row.arithmetic_matches:
			lines.append("%s：技术分%.2f＋内容分%.2f%s－扣分%.2f＝%.2f。" % [label,row.tes,row.pcs,bonus,row.deductions,row.total])
		else:
			lines.append("%s：档案总分%.2f；现存分项合计%.2f，与总分不一致，无法还原完整算式。保留原成绩，不自行改分。" % [label,row.total,row.computed_total])
		for element in score.get("element_scores",[]):
			if not element is Dictionary: continue
			if not element.has("base_value") or not element.has("goe") or not element.has("total"): continue
			row.example = {"action":_action_label(element),"base_value":float(element.base_value),"goe":float(element.goe),"total":float(element.total)}
			lines.append("本场例子：%s，基础分%.2f，GOE %+.2f，动作得分%.2f。这不是整套节目的分数。" % [row.example.action,row.example.base_value,row.example.goe,row.example.total])
			break
		segments.append(row)
	if segments.is_empty(): lines.append("这份比赛记录缺少完整分项，不能据此还原本场算式；没有把缺失数据当成零分。")
	return {"segments":segments,"text":"\n\n".join(lines)}

static func _execution_text(archive: Dictionary) -> String:
	var turning_lines: Array[String] = []
	for segment in ["short","free"]:
		var record: Dictionary = archive.get(segment+"_results",{}).get("player",archive.get(segment,{}))
		for turning in preload("res://src/presentation/competition_turning_point_presenter.gd").build(record):
			turning_lines.append(("短节目：" if segment == "short" else "自由滑：")+turning.text)
			if turning_lines.size() == 2: return " ".join(turning_lines)
	if not turning_lines.is_empty(): return " ".join(turning_lines)
	var best: Dictionary = {}
	var difficult: Dictionary = {}
	var scores: Array = Array(archive.get("execution_scores",[])).duplicate()
	for segment in ["short","free"]:
		var row: Dictionary = archive.get(segment,{})
		if row.has("score"): scores.append(row.score)
		var formal: Dictionary = Dictionary(archive.get(segment+"_results",{})).get("player",{})
		if formal.has("score"): scores.append(formal.score)
	for score in scores:
		if not score is Dictionary: continue
		for element in score.get("element_scores",[]):
			if not element is Dictionary: continue
			if best.is_empty() or float(element.get("goe",0))>float(best.get("goe",0)): best = element
			if difficult.is_empty() or float(element.get("goe",0))<float(difficult.get("goe",0)): difficult = element
	var lines: Array[String] = []
	if not best.is_empty(): lines.append("本场完成较好：%s，GOE %+.2f。" % [_action_label(best),float(best.get("goe",0))])
	if not difficult.is_empty() and difficult != best: lines.append("下次优先复盘：%s，GOE %+.2f。" % [_action_label(difficult),float(difficult.get("goe",0))])
	return " ".join(lines) if not lines.is_empty() else "这份旧记录没有逐项执行明细，可查看已保存的成绩。"

static func _action_label(element: Dictionary) -> String:
	var actual = element.get("actual_execution",element.get("final_call","动作"))
	if actual is Dictionary: return str(actual.get("abbreviation","动作"))
	return str(actual)

static func _event_consequences(career, archive: Dictionary) -> String:
	if archive.get("event",{}).get("event_family") == "beijing_trial":
		var api = load("res://src/simulation/beijing_trial_service.gd")
		var date := str(archive.get("event",{}).get("end_date",""))
		var table: Dictionary = api.standings(career,date)
		if not table.errors.is_empty(): return "本场选拔成绩已保存，系列总表暂不能核对：%s。不会据此宣布奥运入选。" % "；".join(table.errors)
		var player_rows: Array = table.rows.filter(func(row):return row.athlete_id == "player")
		if player_rows.is_empty(): return "本场没有完整两段完赛记录，不计为四场完赛要求中的一场；其他有效成绩保留。"
		var row: Dictionary = player_rows[0]
		var counted: Array = row.counted_event_ids.map(func(id):return str(api.event_ids().find(id)+1))
		var discarded: Array = row.discarded_event_ids.map(func(id):return str(api.event_ids().find(id)+1))
		var text := "系列暂列第%d，完成%d场；最好四场暂计%.2f（计入第%s场）。" % [row.rank,row.completed,row.total,"、".join(counted)]
		if not discarded.is_empty(): text += "舍弃第%s场，原成绩仍保留。" % "、".join(discarded)
		text += "至少四场完整比赛；个人国际TES、国家席位和最终派遣另行核对。"
		return text
	var changes: Dictionary = archive.get("applied_resource_changes",{})
	var lines: Array[String] = []
	for key in ["ice_access","coach_attention"]:
		var value := float(changes.get(key,0))
		if not is_zero_approx(value): lines.append("%s%+.1f" % [{"ice_access":"冰时保障","coach_attention":"教练关注"}[key],value])
	if archive.get("event",{}).get("event_family") == "jgp_stage":
		var receipt_id := "%s:%s" % [archive.get("season_id",""),archive.get("event_id","")]
		var receipt: Dictionary = career.ranking_state.get("applied_events",{}).get(receipt_id,{})
		var text := "本站已记入JGP履历，现有档案缺少完整积分回执；总决赛资格仍需按当季规则核对。"
		if receipt.has("jgp_points"):
			text = "本站JGP分站积分%d；总决赛资格按当季积分与同分规则确定，不因本站获牌自动入围。" % int(receipt.jgp_points)
		var dispatch: Dictionary = career.selection_state.get("jgp_second_start", {})
		var first_assignments := preload("res://src/simulation/jgp_second_start_service.gd").effective_first_assignments(career)
		if first_assignments.get("player", []).has(archive.get("event_id")):
			var selected := false
			var alternate_rank := 0
			for round in dispatch.get("rounds", []):
				if round.get("event_id") == archive.get("event_id"): continue
				var active_ids: Array = career.selection_state.get("assignments", {}).get("player", [])
				if active_ids.has(round.get("event_id")):
					selected = true
				var withdrawn: bool = career.selection_state.get("jgp_replacements", []).any(func(row): return row.get("event_id") == round.get("event_id") and row.get("removed_id") == "player")
				var index: int = round.get("alternate_ids", []).find("player")
				if index >= 0 and not withdrawn and alternate_rank == 0:
					alternate_rank = index + 1
			if selected:
				text += " 第二站名单已公布，你已入选。"
			elif alternate_rank > 0:
				text += " 第二站名单已公布，你排在候补第%d。" % alternate_rank
			elif receipt.has("jgp_points"):
				var needed := int(dispatch.get("policy", {}).get("minimum_first_points", 0))
				var points := int(receipt.jgp_points)
				if not dispatch.get("rounds", []).is_empty():
					text += " 已公布轮次中，你没有有效的第二站派遣。"
				else:
					text += " 第二站派遣名单待公布。"
				if needed > 0:
					text += "已达到本季国内游戏政策的%d分门槛。" % needed if points >= needed else "距本季国内游戏政策的%d分门槛还差%d分。" % [needed, needed - points]
		if not lines.is_empty(): text += " 已结算保障变化：%s。" % "，".join(lines)
		return text
	if not lines.is_empty(): return "本场结算：%s。" % "，".join(lines)
	var summary: Dictionary = archive.get("consequence_summary",{})
	if summary.has("domestic_points_awarded") and archive.get("event",{}).get("scope") == "domestic" and archive.get("event",{}).get("ranking_points_system") == "domestic":
		return "本场获得国内积分%d。名额仍需结合后续比赛和选拔结果。" % int(summary.domestic_points_awarded)
	var id := str(archive.get("event_id",""))
	for index in range(career.history.size()-1,-1,-1):
		var entry: Dictionary = career.history[index]
		if id.is_empty() or str(entry.get("event_id","")) != id: continue
		if str(entry.get("category","")) != "competition_consequence": continue
		var text := str(entry.get("summary",entry.get("summary_key",""))).strip_edges()
		if not text.is_empty(): return text
	return "本场成绩已经记录，暂无其他已记录的待遇变化。"

static func _player_result(archive: Dictionary) -> Dictionary:
	var direct: Dictionary = archive.get("player_result",{})
	if not direct.is_empty(): return direct
	for index in archive.get("final_standings",[]).size():
		var row: Dictionary = archive.final_standings[index]
		if bool(row.get("is_player",false)) or str(row.get("athlete_id","")) == "player":
			var copy := row.duplicate(true)
			copy.rank = int(row.get("rank",index+1))
			return copy
	return {}

static func _training_text(career) -> String:
	for index in range(career.history.size()-1,-1,-1):
		var entry: Dictionary = career.history[index]
		if str(entry.get("category","")) in ["training","jump_attempt_batch","roadmap_progress"]:
			var text := str(entry.get("summary",entry.get("summary_key",""))).strip_edges()
			if not text.is_empty(): return text
	return "这场比赛保留了实际执行和得分；没有证据的技术进步不在这里宣称。"

static func _consequence_text(career) -> String:
	for index in range(career.history.size()-1,-1,-1):
		var entry: Dictionary = career.history[index]
		if str(entry.get("category","")) in ["competition_consequence","internal_competition","formal_competition"]:
			var text := str(entry.get("summary",entry.get("summary_key",""))).strip_edges()
			if not text.is_empty(): return text
	return "结果已留下记录。没有新的名额、伤病或关系变化。"

static func _history_refs(career, categories: Array, limit: int) -> Array:
	var result: Array = []
	for index in range(career.history.size()-1,-1,-1):
		var entry: Dictionary = career.history[index]
		if not categories.has(str(entry.get("category",""))): continue
		result.append(str(entry.get("record_id",entry.get("id","history:%d" % index))))
		if result.size() == limit: break
	return result
