extends RefCounted

const ATLAS := preload("res://assets/competition/skater.png")
const CELL := 144
const AIR := [1, 2, 1, 3]

static func draw_frame(canvas: CanvasItem, foot: Vector2, sheet: int, frame: int, zoom: float, mirror := false, opacity := 1.0) -> void:
	var source := Rect2(frame * CELL, sheet * CELL, CELL, CELL)
	canvas.draw_set_transform(foot, 0.0, Vector2(-zoom if mirror else zoom, zoom))
	canvas.draw_texture_rect_region(ATLAS, Rect2(-72, -136, CELL, CELL), source, Color(1, 1, 1, opacity))
	canvas.draw_set_transform(Vector2.ZERO)

static func draw_turn(canvas: CanvasItem, foot: Vector2, sheet: int, frames: Array, turns: float, zoom: float, mirror: bool) -> void:
	var view := fposmod(turns * frames.size(), frames.size())
	var index := int(view)
	var blend := smoothstep(0.2, 0.8, view - index)
	draw_frame(canvas, foot, sheet, frames[index], zoom, (index == 2) != mirror, 1.0 - blend)
	if blend > 0.0:
		var next := (index + 1) % frames.size()
		draw_frame(canvas, foot, sheet, frames[next], zoom, (next == 2) != mirror, blend)
