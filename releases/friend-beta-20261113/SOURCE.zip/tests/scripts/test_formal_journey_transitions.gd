extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Formal = preload("res://src/simulation/formal_competition_simulator.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"journey keep awaits the saved free result without editor", "callable":free_transition.bind(false)},
		{"name":"journey explicit edit still confirms a real changed free programme", "callable":free_transition.bind(true)}]
func free_transition(edit: bool) -> void:
	var career = F.formal_acceptance_career("qualify")
	var event: Dictionary = F.u_series_event()
	var session := Formal.complete_practice(Formal.create_session(career,event,career.active_programs,"balanced",6040,34),"accept")
	career.competition_state = Formal.lock_short(career,session)
	T.assert_equal(career.competition_state.status,"free_adjustment")
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = career
	main.browser_saves = load("res://scripts/experience_memory_save.gd").new()
	main.autosave_path = main.browser_saves.slot_path("autosave")
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = main
	driver.check_roundtrips = edit
	var before: Dictionary = career.competition_state.short_results.duplicate(true)
	await driver._handle_node({"kind":"between_segments","event_id":event.event_id},{"calendar":{"events":[{"event_id":event.event_id,"scope":"international","event_family":"world_junior"}]}})
	T.assert_equal(driver.errors,[])
	T.assert_equal(career.competition_state.status,"complete")
	T.assert_equal(career.competition_state.short_results,before)
	T.assert_equal(driver.concrete_free_edit,edit)
	T.assert_equal(main.get_node("%ProgramEditorPanel").visible,false)
	main.free()
