extends RefCounted
const T = preload("res://tests/test_support.gd")
const R = preload("res://scripts/natural_fast_acceptance_report.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"synthetic readiness requires official stage and available repertoire","callable":readiness},{"name":"synthetic single free technical facts and compact archive remain distinct from union","callable":facts},{"name":"natural driver loads with bounded first season and no resume","callable":configuration},{"name":"actual free snapshot overrides roster and malformed values fail safely","callable":boundaries},{"name":"CLI destinations are canonical isolated and distinct","callable":paths},{"name":"natural diagnostics distinguish actual dates and current evidence without mutation","callable":diagnostics}]

func diagnostics() -> void:
	var c = load("res://tests/fixtures.gd").starting_career(42000)
	c.history.append({"category":"dated_training","date":"2018-06-28","actual_jump_attempts":2})
	c.history.append({"category":"dated_training","date":"2018-06-29","actual_jump_attempts":3})
	c.history.append({"category":"other","date":"2018-06-29","actual_jump_attempts":999})
	var before: Dictionary = c.to_dict()
	var reporter = R.new()
	T.assert_equal(reporter.has_method("training_diagnostics"),true)
	if not reporter.has_method("training_diagnostics"): return
	var result: Dictionary = reporter.call("training_diagnostics",c,"2018-06-30")
	T.assert_equal(result.actual_dated_days,2)
	T.assert_equal(result.actual_dated_jump_attempts,5)
	T.assert_equal(result.days_on_or_after_event,0)
	T.assert_equal(result.last_training_date,"2018-06-29")
	T.assert_equal(result.jumps.size(),5)
	T.assert_equal(c.to_dict(),before)
	T.assert_equal(reporter.has_method("allowed_seed"),true)
	if not reporter.has_method("allowed_seed"): return
	for seed_value in [42000,42001,42002]:
		T.assert_equal(reporter.call("allowed_seed",seed_value,"predeclared-v1"),true)
		T.assert_equal(reporter.call("allowed_seed",seed_value,""),seed_value == 42000)
	T.assert_equal(reporter.call("allowed_seed",42003,"predeclared-v1"),false)
	T.assert_equal(reporter.call("allowed_seed",42000,"unknown"),false)
func programme() -> Dictionary:
	var result := {"elements":[]}
	for id in R.IDS: result.elements.append({"kind":"jump","jump_id":id,"rotations":3,"combination_parts":[]})
	return result
func boundaries() -> void:
	var a := archive(R.CODES)
	a.roster = [{"athlete_id":"player","free_program":programme()}]
	var reduced := programme(); reduced.elements.pop_back()
	a.free_results.player.snapshot = {"program":reduced}
	T.assert_equal(R.inspect(a).submitted_programme_five,false)
	a.roster[0].free_program = reduced; a.free_results.player.snapshot.program = programme()
	T.assert_equal(R.inspect(a).submitted_programme_five,true)
	a.free_results.player.snapshot.program = 42
	T.assert_equal(R.inspect(a).submitted_programme_five,false)
	a.free_results = {}; a.short_results = {"player":{"protocol":{}}}; a.roster[0].free_program = 42
	T.assert_equal(R.inspect(a).submitted_programme_five,false)
	a.roster[0].free_program = programme(); a.roster[0].free_program.elements[0].rotations = {"bad":3}
	T.assert_equal(R.inspect(a).submitted_programme_five,false)
	a = archive(R.CODES); a.free_results.player.technical_review.final_elements[0].facts.rotation_ratio = []
	T.assert_equal(R.inspect(a).single_free_five,false)
	for field in ["planned_rotations","fall","invalid"]:
		a = archive(R.CODES); a.free_results.player.technical_review.final_elements[0].facts[field] = {"bad":3}
		T.assert_equal(R.inspect(a).single_free_five,false)
	a = archive(R.CODES); a.free_results.player.technical_review.final_elements[0].parts[0].called_rotations = 3.5
	T.assert_equal(R.inspect(a).single_free_five,false)
func paths() -> void:
	var cli = load("res://scripts/run_natural_fast_acceptance.gd")
	T.assert_equal(cli.validate_paths("user://same.json","user://same.json").ok,false)
	T.assert_equal(cli.validate_paths("user://folder/../same.json","user://same.json").ok,false)
	T.assert_equal(cli.validate_paths("user://../outside.json","user://snapshot.json").ok,false)
	T.assert_equal(cli.validate_paths("user://report-new.json","user://snapshot-new.json").ok,true)
	T.assert_equal(cli.validate_paths("user://snapshot-new.json.pre-event.json","user://snapshot-new.json").ok,false)
func configuration() -> void:
	T.assert_equal(R.semantic_equal({"a":[1,2.0]},{"a":[1.0,2]}),true)
	T.assert_equal(R.semantic_equal({"a":[1,2]},{"a":[2,1]}),false)
	T.assert_equal(R.semantic_equal({"a":1},{"a":1.1}),false)
	T.assert_equal(R.semantic_equal({"a":1},{"a":1,"b":2}),false)
	var script = load("res://scripts/natural_fast_acceptance.gd")
	T.assert_equal(script.can_instantiate(),true)
	if not script.can_instantiate(): return
	var driver = script.new()
	T.assert_equal(driver.end_season_year,2018)
	T.assert_equal(driver.initial_snapshot_path,"")
	T.assert_equal(driver.fast_confirmation,{})
func readiness() -> void:
	var rows := {}
	for code in R.CODES: rows[code] = {"stage_id":"training_stable","state":"available","proficiency":100}
	T.assert_equal(R.ready(rows),false)
	for code in rows: rows[code].stage_id = "official_ready"
	T.assert_equal(R.ready(rows),true)
	rows["3T"].state = "training"
	T.assert_equal(R.ready(rows),false)
func archive(codes: Array) -> Dictionary:
	var elements := []
	for code in codes: elements.append({"kind":"jump","abbreviation":code,"facts":{"planned_abbreviation":code,"planned_rotations":3,"rotation_ratio":1.0,"fall":false,"invalid":false},"parts":[{"called_rotations":3}]})
	return {"status":"complete","event_id":"formal","event":{"scope":"domestic","event_family":"national"},"roster":[],"short_results":{},"free_results":{"player":{"protocol":{},"technical_review":{"final_elements":elements}}}}
func facts() -> void:
	var a := archive(R.CODES)
	T.assert_equal(R.inspect(a).single_free_five,true)
	T.assert_equal(R.inspect(load("res://src/persistence/competition_archive_codec.gd").compact(a)).single_free_five,true)
	var combined := a.duplicate(true)
	var singles: Array = combined.free_results.player.technical_review.final_elements
	var lutz: Dictionary = singles[4].duplicate(true)
	var toe: Dictionary = singles[0].duplicate(true)
	lutz.called_rotations = 3; toe.called_rotations = 3
	singles.remove_at(4); singles.remove_at(0)
	singles.append({"kind":"jump","abbreviation":"3Lz+3T","facts":{"parts":[lutz.facts,toe.facts],"connection_held":true},"parts":[lutz,toe]})
	T.assert_equal(R.inspect(combined).single_free_five,true)
	singles.back().parts[1].facts.fall = true
	T.assert_equal(R.inspect(combined).single_free_five,false)
	for field in ["fall","invalid","rotation_ratio","planned_rotations"]:
		var bad := a.duplicate(true)
		bad.free_results.player.technical_review.final_elements[0].facts[field] = true if field in ["fall","invalid"] else 0
		T.assert_equal(R.inspect(bad).single_free_five,false)
	var bad := a.duplicate(true)
	bad.free_results.player.technical_review.final_elements[0].parts[0].called_rotations = 2
	T.assert_equal(R.inspect(bad).single_free_five,false)
	bad = a.duplicate(true); bad.free_results.player.technical_review.final_elements[0].erase("facts")
	T.assert_equal(R.inspect(bad).single_free_five,false)
	for override in [{"world_only":true},{"event":{"scope":"internal","event_family":"teaching"}},{"free_results":{}},{"free_results":{"player":"malformed"}}]:
		bad = a.duplicate(true); bad.merge(override,true)
		T.assert_equal(R.inspect(bad).single_free_five,false)
	var report := R.archives([archive(["3T","3S"]),archive(["3Lo","3F","3Lz"])])
	T.assert_equal(report.first_archive.single_free_five,false)
	T.assert_equal(report.across_event_five,true)
	var cut := archive([])
	cut.short_results = {"player":{"protocol":{}}}; cut.free_results = {}
	var programme := {"elements":[]}
	for id in R.IDS: programme.elements.append({"kind":"jump","jump_id":id,"rotations":3,"combination_parts":[]})
	cut.roster = [{"athlete_id":"player","free_program":programme}]
	T.assert_equal(R.inspect(cut).submitted_programme_five,true)
	T.assert_equal(R.inspect(cut).single_free_five,false)
