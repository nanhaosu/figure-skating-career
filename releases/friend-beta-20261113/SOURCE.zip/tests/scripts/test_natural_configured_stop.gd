extends RefCounted
const T = preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"synthetic configured stop excludes defaults pending and wrong first event","callable":boundaries}]
func boundaries() -> void:
	var base = load("res://scripts/calibrate_two_season_experience.gd").new()
	var driver = load("res://scripts/natural_fast_acceptance.gd").new()
	var fixture := {"competition_state":{},"competition_archive":[]}
	T.assert_equal(base._configured_stop(fixture),"")
	T.assert_equal(driver._configured_stop(fixture),"")
	driver.stop_after_first_formal_archive = true
	driver.first_attempt = {"event_id":"first"}
	var a := {"status":"complete","event_id":"first","event":{"scope":"domestic","event_family":"national"},"short_results":{"player":{}},"free_results":{}}
	fixture.competition_archive = [a]
	T.assert_equal(driver._configured_stop(fixture),"first-formal-archive")
	fixture.competition_state = {"status":"awaiting_result_acknowledgment"}
	T.assert_equal(driver._configured_stop(fixture),"")
	fixture.competition_state = {}
	for field in ["world_only","teaching","corrupt","wrong","incomplete"]:
		var changed := a.duplicate(true)
		if field == "world_only": changed.world_only = true
		if field == "teaching": changed.event.event_family = "teaching"
		if field == "corrupt": changed.short_results = 42
		if field == "wrong": changed.event_id = "other"
		if field == "incomplete": changed.status = "short_complete"
		fixture.competition_archive = [changed]
		T.assert_equal(driver._configured_stop(fixture),"")
