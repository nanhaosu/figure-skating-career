extends "res://tests/integration/test_first_international_season.gd"

var _journey_finished := false

func cases() -> Array[Dictionary]:
	return [
		{"name":"international assigned regression awaits its asynchronous journey", "callable":assigned_wait},
		{"name":"international rejected regression awaits its asynchronous journey", "callable":rejected_wait},
	]

func _journey(_assigned: bool) -> void:
	await Engine.get_main_loop().process_frame
	_journey_finished = true

func assigned_wait() -> void:
	_journey_finished = false
	await test_assigned()
	T.assert_equal(_journey_finished,true,"test must not pass before its asynchronous assertions finish")
	await Engine.get_main_loop().process_frame

func rejected_wait() -> void:
	_journey_finished = false
	await test_rejected()
	T.assert_equal(_journey_finished,true,"test must not pass before its asynchronous assertions finish")
	await Engine.get_main_loop().process_frame
