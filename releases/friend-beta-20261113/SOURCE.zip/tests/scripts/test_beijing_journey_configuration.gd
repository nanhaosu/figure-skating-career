extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"natural journey selects every season through Beijing instead of repeating the old two-season calendar", "callable":seasons},{"name":"natural event edit uses the real event editor instead of overwriting the primary programme", "callable":event_edit},
		{"name":"journey can load a preserved native checkpoint without resetting history or accepting the wrong seed", "callable":resume_source},
		{"name":"journey QA checkpoints preserve previous evidence instead of overwriting it", "callable":checkpoint}]

func resume_source() -> void:
	var c = F.starting_career(42115)
	c.clock.year = 2018;c.clock.quarter = 4
	c.athlete.resources.money = 37.0
	var repo = load("res://src/persistence/save_repository.gd")
	var path := "user://beijing-driver-resume-source.json"
	T.assert_equal(repo.save(c,path).ok,true)
	var before := FileAccess.get_sha256(path)
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	T.assert_equal(driver.has_method("_initial_career"),true)
	if not driver.has_method("_initial_career"): return
	driver.initial_snapshot_path = path
	var initial: Dictionary = driver._initial_career(42115)
	T.assert_equal(initial.errors,[])
	if initial.errors.is_empty():
		T.assert_equal(initial.career.clock.to_dict(),{"year":2018,"quarter":4})
		T.assert_equal(initial.career.athlete.resources.money,37.0)
		T.assert_equal(initial.career.to_dict(),repo.load_save(path).career.to_dict())
	T.assert_equal(driver._initial_career(42116).errors,["resume_seed_mismatch"])
	T.assert_equal(FileAccess.get_sha256(path),before)

func checkpoint() -> void:
	var c = F.starting_career(42115)
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	T.assert_equal(driver.has_method("_save_checkpoint"),true)
	if not driver.has_method("_save_checkpoint"): return
	driver.checkpoint_directory = "user://beijing-driver-checkpoints-%d" % Time.get_ticks_usec()
	var saved: Dictionary = driver._save_checkpoint(c,7)
	T.assert_equal(saved.ok,true)
	if not saved.ok: return
	var digest := FileAccess.get_sha256(saved.path)
	c.athlete.resources.money += 1
	T.assert_equal(driver._save_checkpoint(c,7).ok,false)
	T.assert_equal(FileAccess.get_sha256(saved.path),digest)

func event_edit() -> void:
	var fixture = load("res://tests/integration/test_dual_level_programs.gd").new()
	var c = fixture._career()
	if not fixture._ready(c): return
	var event: Dictionary = fixture._event("isu_gpusa2021")
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	var resolved: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_for_career(c,event)
	var primary := JSON.stringify(c.active_programs)
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	driver.main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(driver.main)
	driver.main.active_career = c
	driver.main.browser_saves = load("res://scripts/experience_memory_save.gd").new()
	driver.main.autosave_path = driver.main.browser_saves.slot_path("autosave")
	await driver._handle_node({"kind":"program_adjustment","event_id":event.event_id,"segment":"free","rules":resolved.rules.free.segment_rules},bundle)
	print("EVENT_EDIT_DIAGNOSTIC pending=",driver.main._pending_program_event_id," message=",driver.main.get_node("%GlobalMessage").text," trace=",driver.trace)
	T.assert_equal(driver.errors,[])
	T.assert_equal(JSON.stringify(driver.main.active_career.active_programs),primary,"secondary event edit must preserve the primary group")
	var program = load("res://src/domain/skating_program.gd").from_dict(driver.main.active_career.season_program_plan.programs_by_level.senior.free)
	T.assert_equal(program.draft_status,"locked","actual event group receives the confirmed edit")
	driver.main.free()
func seasons() -> void:
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	T.assert_equal(driver.has_method("_journey_year"),true)
	if not driver.has_method("_journey_year"): return
	T.assert_equal(driver.get("end_season_year"),2019,"existing two-season acceptance keeps its exact default scope")
	var c = F.starting_career(42115)
	T.assert_equal(driver._journey_year(c),2018)
	c.season_state.season_history = {"2018-19":{},"2019-20":{}}
	T.assert_equal(driver._journey_year(c),2020)
	c.season_state.season_history["2020-21"] = {}
	T.assert_equal(driver._journey_year(c),2021)
	c.season_state.season_history["2021-22"] = {}
	T.assert_equal(driver._journey_year(c),2022)
