$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$runner = Join-Path $projectRoot 'scripts/run_experience_cohort.ps1'
Push-Location -LiteralPath $projectRoot
try { $fromProject = & $runner -FingerprintOnly } finally { Pop-Location }
Push-Location -LiteralPath (Split-Path $projectRoot -Parent)
try { $fromParent = & $runner -FingerprintOnly } finally { Pop-Location }
if ($fromProject -ne $fromParent -or $fromProject -notmatch '^[A-F0-9]{64}$') { throw 'Candidate fingerprint depends on invocation directory' }
Write-Output 'PASS: candidate fingerprint is independent of invocation directory'
