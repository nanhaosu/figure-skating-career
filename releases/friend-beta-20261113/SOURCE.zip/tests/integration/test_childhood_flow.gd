extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "balanced childhood advances three seasons", "callable": test_balanced_childhood_advances_three_seasons},
	]

func test_balanced_childhood_advances_three_seasons() -> void:
	var career := Fixtures.starting_career(2014)
	var catalog := CatalogRepository.load_catalog()
	for index in range(12):
		var outcomes := CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), catalog)
		TestSupport.assert_equal(outcomes.is_empty(), false)
	TestSupport.assert_equal([career.clock.year, career.clock.quarter], [2017, 1])
	TestSupport.assert_equal(career.history.size() >= 12, true)
	TestSupport.assert_equal(career.athlete.body.cumulative_fatigue < 100.0, true)
	var season_summaries := career.history.filter(
		func(item: Dictionary) -> bool: return item.get("category") == "season_summary"
	)
	TestSupport.assert_equal(season_summaries.size(), 3)
