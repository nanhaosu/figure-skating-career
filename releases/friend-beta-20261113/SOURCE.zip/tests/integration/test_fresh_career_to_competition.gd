extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const ProgramDraftService = preload("res://src/simulation/program_draft_service.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const InternalInvitationService = preload("res://src/simulation/internal_invitation_service.gd")
const InternalCompetitionSimulator = preload("res://src/simulation/internal_competition_simulator.gd")
const CertificationService = preload("res://src/simulation/certification_service.gd")
const HistoricalRuleRepository = preload("res://src/content/historical_rule_repository.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const SeasonCalendarPlanner = preload("res://src/simulation/season_calendar_planner.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")

const MAIN_SCENE := "res://src/app/main.tscn"
const SAVE_PATH := "user://fresh-career-to-competition.json"
const AUTOSAVE_PATH := "user://fresh-career-to-competition-autosave.json"
const ELIGIBILITY_RULES := {
	"junior_min_age": 13,
	"junior_max_age": 18,
	"age_cutoff": {"month": 7, "day": 1},
}

func cases() -> Array[Dictionary]:
	return [{
		"name": "fresh career reaches teaching group and confirms 2018 U-series",
		"callable": test_fresh_career_reaches_competitions,
	}]

func teardown() -> void:
	for path in [SAVE_PATH, "%s.tmp" % SAVE_PATH, "%s.bak" % SAVE_PATH, AUTOSAVE_PATH, "%s.tmp" % AUTOSAVE_PATH, "%s.bak" % AUTOSAVE_PATH]:
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func test_fresh_career_reaches_competitions() -> void:
	var catalog := CatalogRepository.load_catalog()
	var created := CareerFactory.create("验收选手", 2006, "entry_interest_class", "family_supportive", 41041, catalog, 4)
	TestSupport.assert_equal(created.errors, [])
	var career = created.career
	TestSupport.assert_equal(career.active_programs, {"short":{}, "free":{}})
	TestSupport.assert_equal(int(career.certification_state.national_technical_grade), 0)

	var main = load(MAIN_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.save_path = SAVE_PATH
	main.autosave_path = AUTOSAVE_PATH
	main.offer_new_career(career)

	var single_plan = _single_jump_plan()
	for quarter in 4:
		CareerSimulator.advance_quarter(career, single_plan, catalog)
		if _jumps_unlocked(career, ["toe_loop", "salchow", "loop", "axel"], 1): break
	TestSupport.assert_equal(_jumps_unlocked(career, ["toe_loop", "salchow", "loop", "axel"], 1), true)

	for segment in ["short", "free"]:
		_save_draft(main, career, segment, InternalEventRules.for_teaching_group(segment), 0)
	var invitation := InternalInvitationService.ensure_offer(career)
	# The teaching event now follows a preparation period, not the first lesson.
	for preparation_quarter in 3:
		if invitation.ready: break
		CareerSimulator.advance_quarter(career, single_plan, catalog)
		invitation = InternalInvitationService.ensure_offer(career)
	TestSupport.assert_equal(invitation.ready, true)
	InternalInvitationService.accept(career)
	TestSupport.assert_equal(career.internal_invitation_state.status, "accepted")

	var short_program = SkatingProgram.from_dict(career.active_programs.short)
	var free_program = SkatingProgram.from_dict(career.active_programs.free)
	var session := InternalCompetitionSimulator.start_event(
		career, short_program, free_program, {"risk":"balanced"},
		{"event_name":"俱乐部教学组测试赛", "season_start_year":career.clock.year}, 41041, 5,
	)
	TestSupport.assert_equal(session.status, "awaiting_adjustment")
	var completed := InternalCompetitionSimulator.finish_event(career, session, "keep")
	TestSupport.assert_equal(completed.status, "complete")
	TestSupport.assert_equal(completed.standings.size(), 6)
	InternalInvitationService.complete(career)
	career.history.append({
		"category":"internal_competition",
		"target":"club_teaching_group",
		"delta":0.0,
		"cause_codes":["competition_completed"],
		"summary_key":"internal_competition_completed",
		"clock":career.clock.to_dict(),
	})
	var saved := SaveRepository.save(career, SAVE_PATH)
	TestSupport.assert_equal(saved.ok, true, str(saved.errors))
	if not saved.ok:
		main.free()
		return

	var recovery_steps := 0
	while career.clock.year < 2018 or career.clock.quarter < 3:
		recovery_steps += 1
		if recovery_steps > 80:
			TestSupport.assert_equal(false,true,"fresh career did not advance within bounded training steps")
			main.free()
			return
		var pending: Dictionary = career.condition_state.get("pending_decision",{})
		if not pending.is_empty():
			var treatment: Dictionary = load("res://src/simulation/rehabilitation_service.gd").choose(career,str(pending.injury_id),"full_rehabilitation","fresh:%d" % recovery_steps)
			TestSupport.assert_equal(treatment.ok,true)
		# Exercise actual automatic coaching, rather than indefinitely forcing
		# a fixed manual 50%-jump programme and calling it a coach-led journey.
		var coached: Dictionary = load("res://src/simulation/coach_training_plan_service.gd").build(career,load("res://src/domain/training_intent.gd").create("accept").intent)
		TestSupport.assert_equal(coached.errors,[])
		CareerSimulator.advance_quarter(career, coached.plan, catalog)
	var assessment := CertificationService.assess(career)
	TestSupport.assert_equal(assessment.status, "ready")
	CertificationService.process_quarter(career)
	TestSupport.assert_equal(int(career.certification_state.national_technical_grade), 7)

	var historical := HistoricalRuleRepository.load_season(2018, "women_singles")
	TestSupport.assert_equal(historical.errors, [])
	for segment in ["short", "free"]:
		var rules := HistoricalRuleRepository.rules_for(historical.rules, "junior", segment)
		_save_draft(main, career, segment, rules, 0)
		var stored = SkatingProgram.from_dict(career.active_programs[segment])
		TestSupport.assert_equal(ProgramValidator.validate(stored, career.athlete, rules), [])

	var calendar := SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles")
	TestSupport.assert_equal(calendar.errors, [])
	var proposal := SeasonCalendarPlanner.propose(career, calendar.calendar, ELIGIBILITY_RULES)
	TestSupport.assert_equal(proposal.errors, [])
	var event_id := "cn_grand_prix_u_series_2018"
	TestSupport.assert_equal(
		proposal.plan.entries[event_id].eligibility_snapshot.eligible,
		true,
		str(proposal.plan.entries[event_id].eligibility_snapshot),
	)
	var confirmed := SeasonCalendarPlanner.apply_adjustment(career, proposal.plan, event_id, "enter")
	TestSupport.assert_equal(confirmed.errors, [])
	if confirmed.plan != null:
		TestSupport.assert_equal(confirmed.plan.entries[event_id].status, "confirmed")
	var final_save := SaveRepository.save(career, SAVE_PATH)
	TestSupport.assert_equal(final_save.ok, true, str(final_save.errors))
	main.free()

func _save_draft(main, career, segment: String, rules: Dictionary, seed: int) -> void:
	var proposal := ProgramDraftService.propose(career.athlete, segment, rules, {"title":"验收练习曲"}, seed)
	TestSupport.assert_equal(proposal.errors, [])
	TestSupport.assert_equal(proposal.missing, [])
	var panel = main.get_node("%ProgramEditorPanel")
	panel.present(career, segment, rules, proposal)
	panel.refresh_coach_draft()
	panel.get_node("%LockButton").pressed.emit()
	TestSupport.assert_equal(Dictionary(career.active_programs[segment]).is_empty(), false)

func _jumps_unlocked(career, jump_ids: Array[String], rotations: int) -> bool:
	return jump_ids.all(func(jump_id): return int(career.athlete.jumps[jump_id].unlocked_rotations) >= rotations)

func _single_jump_plan() -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation":15,
		"jump_toe_loop":15, "jump_salchow":15, "jump_loop":15,
		"jump_flip":0, "jump_lutz":0, "jump_axel":15,
		"rotation":0, "conditioning":0, "rest":25,
		"program_short":0, "program_free":0,
	}, {"toe_loop":1, "salchow":1, "loop":1, "axel":1}).plan

func _double_and_program_plan() -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation":5,
		"jump_toe_loop":10, "jump_salchow":10, "jump_loop":10,
		"jump_flip":10, "jump_lutz":0, "jump_axel":10,
		"rotation":0, "conditioning":5, "rest":20,
		"program_short":10, "program_free":10,
	}, {"toe_loop":2, "salchow":2, "loop":2, "flip":2, "axel":2}).plan
