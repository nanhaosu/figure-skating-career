extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"birthday command persists exact date once without rewriting career facts", "callable":persist_once},
		{"name":"birthday replay is idempotent and cannot change an established date", "callable":replay},
		{"name":"invalid birthday and failed save preserve original career and disk file", "callable":invalid_and_failed},
	]

func _command(c) -> Dictionary:
	return {"type":"record_birth_date","birth_date":{"year":c.athlete.birth_year,"month":6,"day":30},"receipt_id":"birthday-first"}

func persist_once() -> void:
	var c = F.formal_junior_career(7091)
	var before := JSON.stringify(c.to_dict())
	var result := Commands.apply(c,_command(c))
	T.assert_equal(result.ok,true,str(result.error))
	T.assert_equal(JSON.stringify(c.to_dict()),before)
	if not result.ok: return
	T.assert_equal(result.career.athlete.birth_date,{"year":c.athlete.birth_year,"month":6,"day":30})
	for field in ["active_programs","technical_repertoire","record_book","ranking_state","history","competition_archive"]:
		T.assert_equal(result.career.to_dict()[field],c.to_dict()[field])
	T.assert_equal(Save.save(result.career,"user://birthday-once.json").ok,true)
	var read := Save.load_save("user://birthday-once.json")
	T.assert_equal(read.ok,true)
	if read.ok: T.assert_equal(read.career.athlete.birth_date,result.career.athlete.birth_date)

func replay() -> void:
	var c = F.formal_junior_career(7092)
	var command := _command(c)
	var first := Commands.apply(c,command)
	T.assert_equal(first.ok,true)
	if not first.ok: return
	var repeated := Commands.apply(first.career,command)
	T.assert_equal(repeated.ok,true)
	T.assert_equal(repeated.career.to_dict(),first.career.to_dict())
	command.birth_date.day = 29
	T.assert_equal(Commands.apply(first.career,command).ok,false)
	command.receipt_id = "new-receipt-cannot-change-date"
	T.assert_equal(Commands.apply(first.career,command).ok,false)

func invalid_and_failed() -> void:
	var c = F.formal_junior_career(7093)
	var command := _command(c)
	var before := JSON.stringify(c.to_dict())
	command.birth_date.day = 31
	T.assert_equal(Commands.apply(c,command).ok,false)
	T.assert_equal(JSON.stringify(c.to_dict()),before)
	T.assert_equal(Save.save(c,"user://birthday-original.json").ok,true)
	var disk_hash := FileAccess.get_sha256("user://birthday-original.json")
	var result := Commands.apply(c,_command(c))
	T.assert_equal(result.ok,true)
	if not result.ok: return
	# Save must fail on a directory, without replacing the source file or live c.
	T.assert_equal(Save.save(result.career,"user://").ok,false)
	T.assert_equal(c.athlete.birth_date,{})
	T.assert_equal(FileAccess.get_sha256("user://birthday-original.json"),disk_hash)
