extends RefCounted

const T = preload("res://tests/test_support.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const SAVE_PATH := "user://first-playable-loop.json"
const AUTO_PATH := "user://first-playable-loop-auto.json"

func cases() -> Array[Dictionary]:
	return [{"name":"new career reaches actual-call K&C and factual home return without requiring a win", "callable":test_first_loop}]

func teardown() -> void:
	for path in [SAVE_PATH,AUTO_PATH]:
		for suffix in ["",".tmp",".bak"]:
			var target: String = path+suffix
			if FileAccess.file_exists(target): DirAccess.remove_absolute(ProjectSettings.globalize_path(target))

func test_first_loop() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	main.save_path = SAVE_PATH; main.autosave_path = AUTO_PATH
	Engine.get_main_loop().root.add_child(main)
	var created: Dictionary = main.get_node("%CreationPanel").create_career(
		"验收小选手",2007,"entry_club_trial","family_supportive",15150,4,
		"club_north_star","coach_lin",
	)
	T.assert_equal(created.errors,[])
	T.assert_equal(main.active_career.coach_assignment.club_id,"club_north_star")
	T.assert_equal(main.active_career.coach_assignment.coach_id,"coach_lin")
	T.assert_equal(main.get_node("%PreCareerHistoryPanel").visible,true)
	await main.call("_on_pre_career_history_continued")
	T.assert_equal(main.get_node("%CoachHandoffPanel").visible,true)
	T.assert_equal(Save.load_save(AUTO_PATH).career.opening_stage,"handoff")
	await main.call("_on_career_goal_confirmed","love_the_sport")
	T.assert_equal(main.get_node("%CareerHomePanel").visible,true)
	main.get_node("%CareerHomePanel").get_node("%PrimaryAction").pressed.emit()
	var quarter = main.get_node("%QuarterPanel")
	T.assert_equal(quarter.visible,true)
	await quarter.continue_training()
	T.assert_equal(main.active_career.internal_invitation_state.status == "pending", false, "first training click must not immediately demand a competition")
	for preparation in 6:
		if main.active_career.internal_invitation_state.status == "pending": break
		if quarter.event_dialog.visible:
			var journey = load("res://scripts/international_season_journey.gd").new()
			journey.main = main
			journey._choose_events(quarter)
		if main.get_node("%SummaryPanel").visible:
			main.get_node("%SummaryPanel").get_node("%NextButton").pressed.emit()
		main.open_next_quarter()
		await quarter.continue_training()
	T.assert_equal(main.active_career.internal_invitation_state.status,"pending")
	T.assert_equal(main.active_career.world_state.early_peer_ids.size(),5)
	T.assert_equal(load("res://src/simulation/teaching_competition_service.gd").elapsed_week(main.active_career) >= 18,true)
	T.assert_equal(Save.load_save(AUTO_PATH).career.internal_invitation_state.status,"pending")
	for segment in ["short","free"]:
		main.open_program_editor(segment)
		var editor = main.get_node("%ProgramEditorPanel")
		editor.refresh_coach_draft()
		T.assert_equal(editor.get_node("%LockButton").disabled,false,editor.get_node("%StatusLabel").text)
		editor.get_node("%LockButton").pressed.emit()
		T.assert_equal(main.active_career.active_programs[segment].draft_status,"locked")
		T.assert_equal(main.active_career.active_programs[segment].locked_segments.has(segment),true)
	var draft_reload := Save.load_save(AUTO_PATH)
	T.assert_equal(draft_reload.ok,true)
	T.assert_equal(draft_reload.career.active_programs.short.draft_status,"locked")
	var started: Dictionary = await main.start_internal_competition()
	T.assert_equal(started.ok,true,str(started.errors))
	var panel = main.get_node("%CompetitionPanel")
	panel.settle_immediately()
	T.assert_equal(panel.get_node("%KissAndCryPanel").visible,true)
	panel.advance_time(3.0)
	T.assert_equal(main.active_career.competition_state.status,"awaiting_adjustment")
	await main.call("_on_competition_adjustment_selected","keep")
	panel.settle_immediately()
	T.assert_equal(panel.get_node("%KissAndCryPanel").visible,true)
	var protocol: Array = main.active_career.competition_state.free.get("score",{}).get("element_scores",[])
	T.assert_equal(protocol.is_empty(),false)
	T.assert_equal(protocol.all(func(row): return row.has("actual_execution") and row.has("final_call") and row.has("goe")),true)
	panel.advance_time(3.0)
	await main._on_competition_confirmed()
	T.assert_equal(main.get_node("%SummaryPanel").visible,true)
	T.assert_equal(main.get_node("%SummaryPanel").get_node("%StoryCards/ProgressCard/Box/BreakthroughHeading").text.contains("第"),true)
	T.assert_equal(main.active_career.internal_invitation_state.status,"completed")
	main.get_node("%SummaryPanel").get_node("%NextButton").pressed.emit()
	T.assert_equal(main.get_node("%CareerHomePanel").visible,true)
	T.assert_equal(main.get_node("%CareerHomePanel").get_node("%RecentStory").text.contains("内部赛第"),true)
	var completed_reload := Save.load_save(AUTO_PATH)
	T.assert_equal(completed_reload.ok,true,"settlement must leave a reloadable autosave")
	T.assert_equal(completed_reload.career.internal_invitation_state.status,"completed")
	T.assert_equal(FileAccess.file_exists(SAVE_PATH),false,"implicit progress must not create or overwrite a manual slot")
	main.free()
