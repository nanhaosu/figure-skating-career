extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const Simulator = preload("res://src/simulation/formal_competition_simulator.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"player can complete first formal qualifying route", "callable":test_qualifying_route},
		{"name":"player can be cut without a free skate action", "callable":test_cut_route},
	]

func test_qualifying_route() -> void:
	var career = Fixtures.formal_acceptance_career("qualify")
	var session := Simulator.create_session(career, Fixtures.u_series_event(), career.active_programs, "balanced", 12001, 34)
	session = Simulator.complete_practice(session, "accept")
	session = Simulator.lock_short(career, session)
	TestSupport.assert_equal(session.player_qualified, true)
	var complete := Simulator.lock_free(career, session, "keep")
	TestSupport.assert_equal(complete.status, "complete")
	TestSupport.assert_equal(complete.final_standings.size(), 34)
	TestSupport.assert_equal(complete.archive.short_results.size(), 34)

func test_cut_route() -> void:
	var career = Fixtures.formal_acceptance_career("cut")
	var session := Simulator.create_session(career, Fixtures.u_series_event(), career.active_programs, "balanced", 12002, 34)
	session = Simulator.complete_practice(session, "accept")
	session = Simulator.lock_short(career, session)
	TestSupport.assert_equal(session.player_qualified, false)
	TestSupport.assert_equal(session.status, "complete")
	TestSupport.assert_equal(session.player_result.short_rank > 24, true)
	TestSupport.assert_equal(session.free_results.has("player"), false)
