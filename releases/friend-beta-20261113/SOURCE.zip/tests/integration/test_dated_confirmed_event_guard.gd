extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const EVENT := "cn_grand_prix_u_series_2018"

func cases() -> Array[Dictionary]:
	return [
		{"name":"real confirmed U series stops dated training before its first competition day", "callable":confirmed},
		{"name":"withdrawn U series does not repeatedly stop a player's dated training", "callable":withdrawn},
		{"name":"actual completed U series consumes occupied dates without ordinary training or duplicate rewards", "callable":completed_dates},
		{"name":"later competition enrollment refunds unused overlapping external course without blocking dates", "callable":external_overlap},
		{"name":"season coordinator actually trains to confirmed race date before returning check-in", "callable":coordinator_date},
	]

func _started(external: bool = false):
	var c = F.formal_junior_career(98700)
	c.certification_state.national_technical_grade = 7
	if external:
		var prepared = load("res://tests/simulation/test_external_training_transactions.gd").new().prepared(98700)
		c.training_direction = prepared.training_direction.duplicate(true)
		c.athlete.resources.money = 100.0
		T.assert_equal(load("res://src/simulation/external_training_service.gd").book(c,"expression_lab","expression","pre-race-course").ok,true)
	var accepted: Dictionary = Commands.apply(c,{"type":"apply_entry","event_id":EVENT,"route_id":"enter"})
	T.assert_equal(accepted.ok,true,accepted.get("error",""))
	if not accepted.ok: return null
	c = accepted.career
	var base = F.percentage_balanced_plan(); var shares: Dictionary = base.shares
	for key in shares: shares[key] = 0
	shares.rest = 100
	var plan = load("res://src/domain/training_plan.gd").create(shares,base.jump_rotations).plan
	c.last_generated_plan = plan.to_dict()
	var begun: Dictionary = Commands.apply(c,{"type":"begin_dated_training"})
	T.assert_equal(begun.ok,true,begun.get("error",""))
	return begun.career if begun.ok else null

func confirmed() -> void:
	var c = _started()
	if c == null: return
	var result: Dictionary = Commands.apply(c,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	T.assert_equal(result.career.competition_timeline.date,"2018-09-13","published actual U series is Sep14-16, not the original announced dates")
	T.assert_equal(result.get("stop_node",{}).get("event_id"),EVENT)
	T.assert_equal(result.career.history.any(func(row):return row.get("category") == "dated_training" and str(row.get("date","")) >= "2018-09-14"),false)
	var replay: Dictionary = Commands.apply(result.career,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(replay.ok,true)
	if replay.ok: T.assert_equal(replay.career.to_dict(),result.career.to_dict())

func withdrawn() -> void:
	var c = _started()
	if c == null: return
	var withdrawn_entry: Dictionary = Commands.apply(c,{"type":"withdraw_entry","event_id":EVENT})
	T.assert_equal(withdrawn_entry.ok,true)
	if not withdrawn_entry.ok: return
	var result: Dictionary = Commands.apply(withdrawn_entry.career,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(result.ok,true,result.get("error",""))
	if result.ok: T.assert_equal(result.career.competition_timeline.date,"2018-09-20")

func completed_dates() -> void:
	var c = _started()
	if c == null: return
	var trained: Dictionary = Commands.apply(c,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(trained.ok,true)
	if not trained.ok: return
	c = trained.career
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var race: Dictionary = sim.create_session(c,F.u_series_event(),c.active_programs,"balanced",98701,34)
	race = sim.lock_short(c,sim.complete_practice(race,"accept"))
	if race.get("status") != "complete": race = sim.lock_free(c,race,"keep")
	T.assert_equal(race.get("errors",[]),[])
	T.assert_equal(race.get("status"),"complete")
	if race.get("status") != "complete": return
	c.competition_state = race
	# A completed, canonical player archive is a proven forward boundary for
	# a legacy save; adopting it must not award any of the earlier training.
	var legacy = c.transaction_copy()
	legacy.competition_timeline = load("res://src/domain/competition_timeline.gd").empty()
	var legacy_body: Dictionary = legacy.athlete.to_dict()
	var migrated: Dictionary = Commands.apply(legacy,{"type":"begin_dated_training"})
	T.assert_equal(migrated.ok,true,migrated.get("error",""))
	if migrated.ok:
		T.assert_equal(migrated.career.competition_timeline.date,"2018-09-16")
		T.assert_equal(migrated.career.competition_timeline.origin_date,"2018-09-16")
		T.assert_equal(migrated.career.competition_timeline.quarter_progress,78)
		T.assert_equal(migrated.career.athlete.to_dict(),legacy_body)
		T.assert_equal(migrated.career.history,legacy.history)
	var before: Dictionary = c.to_dict()
	# Transaction copies intentionally share immutable archives; this corrupt
	# fixture must own a deep decoded snapshot rather than mutate that archive.
	var background = load("res://src/domain/career_state.gd").from_dict(JSON.parse_string(JSON.stringify(c.to_dict())))
	for archive in background.competition_archive:
		if archive.get("event_id") == EVENT: archive.world_only = true
	var denied: Dictionary = Commands.apply(background,{"type":"consume_completed_competition_dates","event_id":EVENT})
	T.assert_equal(denied.ok,false,"world-only results cannot spend the player's competition days")
	var consumed: Dictionary = Commands.apply(c,{"type":"acknowledge_formal_result"})
	T.assert_equal(consumed.ok,true,consumed.get("error",""))
	if not consumed.ok: return
	T.assert_equal(consumed.career.competition_timeline.date,"2018-09-16")
	T.assert_equal(consumed.career.competition_state.is_empty(),true,"result acknowledgement must return to the career without leaving a pending race")
	T.assert_equal(consumed.career.athlete.to_dict(),c.athlete.to_dict(),"race body consequences must not be charged a second time")
	T.assert_equal(consumed.career.competition_archive,c.competition_archive)
	T.assert_equal(consumed.career.history,c.history,"no invented ordinary training on occupied dates")
	T.assert_equal(c.to_dict(),before)
	var replay: Dictionary = Commands.apply(consumed.career,{"type":"consume_completed_competition_dates","event_id":EVENT})
	T.assert_equal(replay.ok,true)
	if replay.ok: T.assert_equal(replay.career.to_dict(),consumed.career.to_dict())
	var repo = load("res://src/persistence/save_repository.gd")
	T.assert_equal(repo.save(consumed.career,"user://dated-competition-occupancy-v1.json").ok,true)
	var restored: Dictionary = repo.load_save("user://dated-competition-occupancy-v1.json")
	T.assert_equal(restored.ok,true)
	if restored.ok:
		var actual: Dictionary = restored.career.to_dict()
		# Nested programme/NPC dictionaries intentionally retain JSON numeric
		# representation; compare against the same canonical commit boundary.
		var expected: Dictionary = consumed.career.transaction_copy(true).to_dict()
		T.assert_equal(actual == expected,true,"occupied-date disk restore must preserve complete career state")
	var after: Dictionary = Commands.apply(consumed.career,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(after.ok,true,after.get("error",""))
	if after.ok: T.assert_equal(after.career.competition_timeline.date,"2018-09-20")

func external_overlap() -> void:
	var c = _started(true)
	if c == null: return
	var trained: Dictionary = Commands.apply(c,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(trained.ok,true,trained.get("error",""))
	if not trained.ok: return
	c = trained.career
	T.assert_equal(c.training_direction.external_schedule[0].executed_days,75)
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var race: Dictionary = sim.create_session(c,F.u_series_event(),c.active_programs,"balanced",98701,34)
	race = sim.lock_short(c,sim.complete_practice(race,"accept"))
	if race.get("status") != "complete": race = sim.lock_free(c,race,"keep")
	T.assert_equal(race.get("status"),"complete")
	if race.get("status") != "complete": return
	var money := float(c.athlete.resources.money)
	var result: Dictionary = Commands.apply(c,{"type":"consume_completed_competition_dates","event_id":EVENT})
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	var booking: Dictionary = result.career.training_direction.external_schedule[0]
	T.assert_equal(booking.status,"cancelled")
	T.assert_equal(booking.executed_days,75,"competition must not spend three external lessons")
	T.assert_equal(booking.refund,2,"six-unit course: floor(6*75/92)=4 spent, two unused refunded")
	T.assert_equal(float(result.career.athlete.resources.money),minf(100.0,money+2.0))
	T.assert_equal(result.career.last_generated_plan,c.last_generated_plan,"automatic refund must not replace the player's confirmed training plan")
	var replay: Dictionary = Commands.apply(result.career,{"type":"consume_completed_competition_dates","event_id":EVENT})
	T.assert_equal(replay.ok,true)
	if replay.ok: T.assert_equal(replay.career.to_dict(),result.career.to_dict())
	var resumed: Dictionary = Commands.apply(result.career,{"type":"advance_dated_training","target_date":"2018-09-20"})
	T.assert_equal(resumed.ok,true,resumed.get("error",""))

func coordinator_date() -> void:
	var c = _started()
	if c == null: return
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	# This case isolates occupied U-series dates. Full-calendar ordering and
	# actual earlier registration choices are exercised separately.
	bundle.calendar.events = bundle.calendar.events.filter(func(e):return e.event_id == EVENT)
	var commits: Array = []
	var progression = load("res://src/simulation/season_progression_service.gd")
	var before: Dictionary = c.to_dict()
	var denied: Dictionary = progression.advance_to_next_node(c,bundle,func(_candidate):return false)
	T.assert_equal(denied.errors,["save_failed"])
	T.assert_equal(denied.career.to_dict(),before,"failed durable boundary must not adopt seventy-five unsaved days")
	var result: Dictionary = progression.advance_to_next_node(c,bundle,func(candidate):commits.append(candidate);return true)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.career.competition_timeline.date,"2018-09-13","same-quarter clock alone must not send the athlete to September on July1")
	T.assert_equal(result.stop_node.get("event_id"),EVENT)
	T.assert_equal(result.stop_node.get("kind") in ["competition_check_in","program_replacement","program_adjustment","entry_revalidation"],true)
	T.assert_equal(commits.size(),1)
	T.assert_equal(c.to_dict(),before,"coordinator does not mutate the source live career")
	var replay_commits: Array = []
	var replay: Dictionary = progression.advance_to_next_node(result.career,bundle,func(candidate):replay_commits.append(candidate);return true)
	T.assert_equal(replay.errors,[])
	T.assert_equal(replay_commits.size(),0,"opening check-in twice cannot repeat the elapsed training")
	T.assert_equal(replay.career.to_dict(),result.career.to_dict())

