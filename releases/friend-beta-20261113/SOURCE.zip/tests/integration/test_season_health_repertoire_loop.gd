extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Career = preload("res://src/simulation/career_simulator.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Evaluate = preload("res://src/simulation/repertoire_evaluator.gd")
const Rehab = preload("res://src/simulation/rehabilitation_service.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"season goal earns real combo evidence then survives medical pause save and rehabilitation","callable":loop}]

func loop() -> void:
	var career = F.formal_junior_career(3302)
	F.set_competition_strength(career.athlete,85.0)
	var action := {"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":3},{"jump_id":"toe_loop","rotations":3}]}
	var service = load("res://src/simulation/season_program_service.gd")
	var draft: Dictionary = service.preview(career,"2019-20","retain",career.active_programs,{"free":[{"action":action}]})
	T.assert_equal(service.confirm(career,draft,"loop:season").ok,true)
	T.assert_equal(career.technical_repertoire.entries.has("3T+3T"),false)
	var catalog: Dictionary = load("res://src/content/catalog_repository.gd").load_catalog()
	for quarter in 8:
		var planned := Coach.build(career,Intent.create("accept").intent)
		Career.advance_quarter(career,planned.plan,catalog)
	T.assert_equal(career.technical_repertoire.entries.has("3T+3T"),true)
	if not career.technical_repertoire.entries.has("3T+3T"): return
	T.assert_equal(Evaluate.evaluate(career,"3T+3T").state,"available")
	var history_count: int = career.technical_repertoire.entries["3T+3T"].learned_history.record_count
	career.condition_state.injuries.append({"id":"loop-injury","site":"ankle","severity":0.8,"status":"active","remaining_quarters":8})
	career.condition_state.pending_decision = {"kind":"initial","injury_id":"loop-injury"}
	T.assert_equal(Evaluate.evaluate(career,"3T+3T").state,"unavailable")
	T.assert_equal(Rehab.choose(career,"loop-injury","full_rehabilitation","loop:treatment").ok,true)
	var repo = load("res://src/persistence/save_repository.gd")
	var saved: Dictionary = repo.save(career,"user://health-loop.json")
	T.assert_equal(saved.ok,true,str(saved.get("errors",[])))
	var loaded: Dictionary = repo.load_save("user://health-loop.json")
	T.assert_equal(loaded.ok,true)
	if not loaded.ok: return
	career = loaded.career
	for quarter in 12:
		var pending: Dictionary = career.condition_state.get("pending_decision",{})
		if not pending.is_empty(): T.assert_equal(Rehab.choose(career,str(pending.injury_id),"full_rehabilitation","loop:review:%d" % quarter).ok,true)
		var planned := Coach.build(career,Intent.create("accept").intent)
		Career.advance_quarter(career,planned.plan,catalog)
	T.assert_equal(career.condition_state.injuries.filter(func(injury): return injury.id == "loop-injury")[0].status,"recovered")
	T.assert_equal(career.technical_repertoire.entries["3T+3T"].learned_history.ever_learned,true)
	T.assert_equal(career.technical_repertoire.entries["3T+3T"].learned_history.record_count>=history_count,true)
	T.assert_equal(repo.save(career,"user://health-loop.json").ok,true)
