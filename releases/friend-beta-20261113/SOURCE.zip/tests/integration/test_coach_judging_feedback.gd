extends RefCounted

# Structural real-scoring fixture, not evidence of natural progression.
# Finalized player protocol feedback must reach later actual coaching.
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Sim = preload("res://src/simulation/formal_competition_simulator.gd")
const LESSON_PATH := "res://src/simulation/coach_lesson_service.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"coach feedback requires matching executed part and resolved part review","callable":matching_part},
		{"name":"real finalized edge call becomes known without immediate skill reward","callable":known_call},
		{"name":"next actual training can correct a newly judged edge problem","callable":next_training},
		{"name":"unfinished world-only and pending review cannot invent coach observations","callable":reject_unconfirmed},
		{"name":"resolved final call survives broadcast review color without duplicate observations","callable":resolved_idempotence},
	]

func matching_part() -> void:
	var result := _completed()
	if not _has_observer(): return
	var c = result.career
	var archive: Dictionary = result.archive.duplicate(true)
	archive.free_results = {}
	var record: Dictionary = archive.short_results.player
	var raw: Dictionary = record.performance.elements.filter(func(row): return row.get("parts",[]).any(func(part): return part.get("jump_id") == "lutz"))[0]
	var final: Dictionary = record.technical_review.final_elements.filter(func(row): return row.element_id == raw.element_id)[0]
	record.performance.elements = [raw]
	record.technical_review.final_elements = [final]
	for variant in ["mismatch","pending_part","no_execution"]:
		for id in ["lutz","flip"]: c.athlete.jumps[id].observations.clear()
		var candidate: Dictionary = archive.duplicate(true)
		var row: Dictionary = candidate.short_results.player
		if variant == "mismatch":
			row.technical_review.final_elements[0].parts[0].jump_id = "flip"
			row.technical_review.final_elements[0].parts[0].abbreviation = "3F"
		elif variant == "pending_part":
			row.technical_review.review_events = [{"element_id":raw.parts[0].element_id,"status":"pending"}]
		else: row.performance.elements[0].parts[0].actual = {}
		load(LESSON_PATH).call("observe_archive",c,candidate)
		T.assert_equal(_known(c),false,"reject invalid part evidence: "+variant)

func _completed() -> Dictionary:
	var c = F.formal_acceptance_career("qualify")
	for id in ["lutz","flip"]:
		c.athlete.jumps[id].observations.clear()
		c.athlete.jumps[id].takeoff.edge_quality = 0.0
	var session: Dictionary = Sim.complete_practice(Sim.create_session(c,F.u_series_event(),c.active_programs,"balanced",774,34),"accept")
	session = Sim.lock_short(c,session)
	if session.status != "complete": session = Sim.lock_free(c,session,"keep")
	T.assert_equal(session.errors,[])
	T.assert_equal(session.status,"complete")
	var calls: Array = session.get("archive",{}).get("short_results",{}).get("player",{}).get("technical_review",{}).get("final_elements",[])
	print("ACTUAL_EDGE_FIXTURE ",JSON.stringify({"status":session.status,"final_marks":calls.map(func(row): return {"code":str(row.get("abbreviation","")),"info":row.get("info",[])})}))
	T.assert_equal(calls.any(func(row): return str(row.get("abbreviation","")).contains("Lz") and Array(row.get("info",[])).has("e")),true,"fixture must really receive final e, not forge a judging record")
	return {"career":c,"archive":session.get("archive",{})}

func _known(c) -> bool:
	return c.athlete.jumps.lutz.observations.any(func(row): return row.get("kind") == "edge" and row.get("known") == true)

func _has_observer() -> bool:
	var lesson_script: Script = load(LESSON_PATH)
	var available: bool = lesson_script.get_script_method_list().any(func(row): return row.name == "observe_archive")
	T.assert_equal(available,true,"actual competition feedback needs a bounded observation consumer")
	return available

func known_call() -> void:
	var result := _completed()
	T.assert_equal(_known(result.career),true,"the judged problem cannot stay unknowable until retirement")
	T.assert_equal(float(result.career.athlete.jumps.lutz.takeoff.edge_quality),0.0,"receiving a symbol is knowledge, not a training reward")

func next_training() -> void:
	var result := _completed()
	var c = result.career
	var prior_archive: Dictionary = result.archive.duplicate(true)
	var plan = load("res://src/simulation/coach_training_plan_service.gd").build(c,load("res://src/domain/training_intent.gd").create("accept").intent).plan
	load("res://src/simulation/career_simulator.gd").advance_quarter(c,plan,load("res://src/content/catalog_repository.gd").load_catalog())
	T.assert_equal(float(c.athlete.jumps.lutz.takeoff.edge_quality)>0.0,true,"new finalized feedback must reach actual coaching settlement")
	T.assert_equal(result.archive,prior_archive,"training cannot rewrite already judged protocols")

func reject_unconfirmed() -> void:
	var result := _completed()
	if not _has_observer(): return
	var c = result.career
	for variant in ["unfinished","world","pending"]:
		for id in ["lutz","flip"]: c.athlete.jumps[id].observations.clear()
		var archive: Dictionary = result.archive.duplicate(true)
		if variant == "unfinished": archive.status = "in_progress"
		elif variant == "world": archive.world_only = true
		else:
			for segment in ["short","free"]:
				var record: Dictionary = archive.get(segment+"_results",{}).get("player",{})
				if record.is_empty(): continue
				for call in record.technical_review.final_elements:
					record.technical_review.review_events.append({"element_id":call.get("element_id",""),"status":"pending"})
		load(LESSON_PATH).call("observe_archive",c,archive)
		T.assert_equal(_known(c),false,"must reject "+variant)

func resolved_idempotence() -> void:
	var result := _completed()
	if not _has_observer(): return
	var c = result.career
	for id in ["lutz","flip"]: c.athlete.jumps[id].observations.clear()
	var archive: Dictionary = result.archive.duplicate(true)
	for segment in ["short","free"]:
		var record: Dictionary = archive.get(segment+"_results",{}).get("player",{})
		if record.is_empty(): continue
		for element in record.performance.elements: element.status = "review"
	load(LESSON_PATH).call("observe_archive",c,archive)
	T.assert_equal(_known(c),true,"broadcast color cannot negate resolved final technical evidence")
	var once: Array = c.athlete.jumps.lutz.observations.duplicate(true)
	load(LESSON_PATH).call("observe_archive",c,archive)
	T.assert_equal(c.athlete.jumps.lutz.observations,once,"replaying the archive cannot add repeated reports or rewards")
