extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const Save = preload("res://src/persistence/save_repository.gd")
var Service: Variant = load("res://src/simulation/olympic_quota_service.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"canonical packed Worlds archive determines country places with no caller quota input", "callable":canonical},
		{"name":"partial forged unresolved and inconsistent Worlds records cannot award country places", "callable":invalid},
		{"name":"country quota settlement persists across season closure and rejects changed receipt", "callable":durable},
		{"name":"old save migration keeps country qualification unknown without inventing missed Worlds", "callable":migration},
		{"name":"future Worlds results and corrupt stored country counts are rejected", "callable":future},
		{"name":"Milano canonical race receipts persist independently with a five-place D2 limit", "callable":milano_cycle},
	]

func _api() -> bool:
	T.assert_equal(Service.has_method("from_worlds"),true,"canonical full archive extraction is required")
	return Service.has_method("from_worlds")

# A complete protocol-shaped controlled table isolates quota extraction.
# Full naturally generated international fields are exercised separately.
func _archive() -> Dictionary:
	var event := B.competition_event({"event_id":"isu_wc2021","ruleset_season_start_year":2020,"competition_level":"senior"})
	T.assert_equal(event.errors,[])
	var rows := preload("res://tests/simulation/test_olympic_quota_service.gd").new()._rows([1,12,20])
	var archive := {"record_version":1,"status":"complete","event_id":"isu_wc2021","event":event.event,"season_id":"2020-21","world_only":true,"roster":[],"short_results":{},"free_results":{},"final_standings":[],"qualifiers":[]}
	for row in rows:
		var short_score := {"total":100.0-row.rank,"tes":40.0,"pcs":60.0-row.rank,"deductions":0.0}
		var free_score := {"total":200.0-row.rank,"tes":80.0,"pcs":120.0-row.rank,"deductions":0.0}
		archive.roster.append({"athlete_id":row.athlete_id,"federation":row.federation})
		archive.short_results[row.athlete_id] = {"score":short_score.duplicate(),"protocol":short_score.duplicate(),"technical_review":{"review_events":[]}}
		var standing: Dictionary = row.duplicate(true)
		standing.short_score = short_score.total
		if row.qualified:
			archive.qualifiers.append(row.athlete_id)
			archive.free_results[row.athlete_id] = {"score":free_score.duplicate(),"protocol":free_score.duplicate(),"technical_review":{"review_events":[]}}
			standing.free_score = free_score.total
			standing.total_score = short_score.total+free_score.total
		archive.final_standings.append(standing)
	# FormalCompetitionSimulator freezes this numeric representation before
	# compaction; use its real durable shape rather than an uncommitted table.
	return preload("res://src/domain/career_state.gd")._restore_competition_state(JSON.parse_string(JSON.stringify(archive)))

func canonical() -> void:
	if not _api(): return
	var archive := _archive()
	var result: Dictionary = Service.from_worlds(Codec.compact(archive))
	T.assert_equal(result.errors,[])
	if not result.errors.is_empty(): return
	T.assert_equal(result.countries.CHN,3)
	T.assert_equal(result.source_event_id,"isu_wc2021")
	T.assert_equal(result.ordinary_places,24)
	archive.event.competition_level = "junior"
	T.assert_equal(Service.from_worlds(archive).errors.is_empty(),false)

func invalid() -> void:
	if not _api(): return
	for mode in ["empty_roster","partial","pending","scope","date","score","country"]:
		var archive := _archive()
		match mode:
			"empty_roster": archive.roster = []
			"partial": archive.free_results.erase("a1")
			"pending": archive.short_results.a1.technical_review.review_events = [{"status":"pending"}]
			"scope": archive.event.scope = "domestic"
			"date": archive.event.end_date = "2021-03-25"
			"score": archive.final_standings[0].total_score = 999.0
			"country": archive.roster[0].federation = "RUS"
		T.assert_equal(Service.from_worlds(archive).errors.is_empty(),false,mode)

func durable() -> void:
	if not _api(): return
	var c = F.starting_career(770)
	c.clock.year = 2021
	c.clock.quarter = 2
	var archive := _archive()
	var result: Dictionary = Service.settle(c,archive)
	T.assert_equal(result.errors,[])
	var before := JSON.stringify(c.to_dict().get("olympic_quota_state",{}))
	T.assert_equal(Service.settle(c,Codec.compact(archive)).errors,[])
	T.assert_equal(JSON.stringify(c.to_dict().olympic_quota_state),before)
	T.assert_equal(Save.save(c,"user://olympic-quota-archive.json").ok,true)
	var read := Save.load_save("user://olympic-quota-archive.json")
	T.assert_equal(read.ok,true,str(read.errors))
	if not read.ok: return
	var bundle := B.load_bundle(2020,"women_singles","senior")
	preload("res://src/simulation/season_progression_service.gd")._close(read.career,bundle)
	T.assert_equal(read.career.to_dict().olympic_quota_state.current.countries.CHN,3)
	var changed := _archive()
	changed.short_results.a1.score.tes = 41.0
	changed.short_results.a1.protocol.tes = 41.0
	T.assert_equal(Service.settle(read.career,changed).errors.is_empty(),false,"changed source requires an explicit correction route")

func migration() -> void:
	var c = F.starting_career(771)
	var data: Dictionary = c.to_dict()
	data.erase("olympic_quota_state")
	data.schema_version = 22
	var payload := {"save_version":22,"saved_at_unix":0,"career":data}
	var decoded := Save.decode_payload(JSON.stringify(payload))
	T.assert_equal(decoded.ok,true,str(decoded.errors))
	if not decoded.ok: return
	var quota: Dictionary = decoded.data.career.get("olympic_quota_state",{})
	T.assert_equal(quota.get("status"),"unknown")
	T.assert_equal(quota.get("current"),{})
	T.assert_equal(quota.get("receipts"),{})
	T.assert_equal(decoded.data.career.competition_archive,data.competition_archive)

func future() -> void:
	if not _api(): return
	var c = F.starting_career(772)
	c.clock.year = 2020
	c.clock.quarter = 4
	T.assert_equal(Service.settle(c,_archive()).errors.is_empty(),false)
	c.clock.year = 2021
	c.clock.quarter = 2
	T.assert_equal(Service.settle(c,_archive()).errors,[])
	var data: Dictionary = c.to_dict()
	data.olympic_quota_state.current.countries.CHN = 4
	var payload := {"save_version":preload("res://src/persistence/save_schema.gd").CURRENT_VERSION,"saved_at_unix":0,"career":data}
	T.assert_equal(Save.decode_payload(JSON.stringify(payload)).ok,false)

func milano_cycle() -> void:
	var c = F.starting_career(773)
	var worlds := _archive()
	worlds.event_id = "isu_wc2025"
	worlds.event = B.competition_event({"event_id":worlds.event_id,"ruleset_season_start_year":2024,"competition_level":"senior"}).event
	worlds.season_id = "2024-25"
	worlds = preload("res://src/domain/career_state.gd")._restore_competition_state(JSON.parse_string(JSON.stringify(worlds)))
	c.clock.year = 2025
	c.clock.quarter = 1
	var worlds_settlement: Dictionary = Service.settle(c,Codec.compact(worlds))
	T.assert_equal(worlds_settlement.errors,[])
	if not worlds_settlement.errors.is_empty(): return
	T.assert_equal(c.milano_olympic_quota_state.status,"worlds_complete")
	T.assert_equal(c.olympic_quota_state.status,"unknown")
	var q_id := "isu_olympic_qualifier_beijing_2025"
	var q_event: Dictionary = B.competition_event({"event_id":q_id,"ruleset_season_start_year":2025,"competition_level":"senior"}).event
	var qualifier := {"record_version":1,"status":"complete","event_id":q_id,"event":q_event,"season_id":"2025-26","world_only":true,"roster":[],"short_results":{},"free_results":{},"final_standings":[],"qualifiers":[]}
	var federations := ["AIN","AIN","QAA","QAB","QAC","QAD"]
	for i in federations.size():
		var id := "q%d" % i
		var federation: String = federations[i]
		var score: Dictionary = worlds.short_results.values()[i].score
		qualifier.roster.append({"athlete_id":id,"federation":federation})
		for segment in ["short","free"]:
			qualifier[segment+"_results"][id] = {"score":score.duplicate(),"technical_review":{"review_events":[]}}
		qualifier.qualifiers.append(id)
		qualifier.final_standings.append({"athlete_id":id,"federation":federation,"rank":i+1,"qualified":true,"short_score":score.total,"free_score":score.total,"total_score":2.0*float(score.total)})
	c.clock.quarter = 3
	var settled: Dictionary = Service.settle(c,qualifier)
	T.assert_equal(settled.errors,[])
	if not settled.errors.is_empty(): return
	T.assert_equal(c.milano_olympic_quota_state.current.ordinary_places,29)
	T.assert_equal(c.milano_olympic_quota_state.current.neutral_awards.size(),2)
	T.assert_equal(c.milano_olympic_quota_state.current.standby[0].federation,"QAD")
	T.assert_equal(Service.settle(c,qualifier).changed,false)
	var dispatch := {"event_id":"isu_owg2026","policy_id":"milano2026_dispatch","selected":[{"federation":"CHN","athlete_id":"player"}],"audit":{"national_places":{"source_fingerprint":c.milano_olympic_quota_state.current.fingerprint}}}
	preload("res://src/simulation/senior_championship_service.gd").record_milano_dispatch(c,dispatch)
	var path := "user://milano-quota-archive-test.json"
	var saved := Save.save(c,path)
	T.assert_equal(saved.ok,true,str(saved.get("errors",[])))
	if not saved.ok: return
	var loaded := Save.load_save(path)
	T.assert_equal(loaded.ok,true,str(loaded.get("errors",[])))
	if not loaded.ok: return
	T.assert_equal(loaded.career.milano_olympic_quota_state.receipts.keys().size(),2)
	T.assert_equal(loaded.career.milano_olympic_quota_state.dispatch.selected_ids,["player"])
	T.assert_equal(loaded.career.olympic_quota_state.edition,2022)
