extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Fixture = preload("res://tests/simulation/test_international_personal_eligibility.gd")
const Entry = preload("res://src/simulation/entry_application_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Junior = preload("res://src/simulation/world_junior_eligibility_service.gd")
const Personal = preload("res://src/simulation/international_personal_eligibility.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"Olympic signup exposes personal evidence but TES never awards dispatch", "callable":olympic},
		{"name":"Olympic signup assigned athlete still needs personal TES", "callable":missing},
		{"name":"Tallinn actual signup uses approved junior cutoff and segmented TES", "callable":junior},
		{"name":"birthday uncertainty is actionable in actual senior signup", "callable":unknown_age},
		{"name":"real simulated junior archive survives save and qualifies Tallinn without senior credit", "callable":real_archive},
	]

func olympic() -> void:
	var fixture = Fixture.new()
	var c = fixture._career()
	c.season_program_plan.competitive_level = "senior"
	c.competition_archive.assign([fixture._archive("isu_gpusa2021",23,40)])
	var before := JSON.stringify(c.to_dict())
	var gate := Entry.current_eligibility(c,fixture._event("isu_owg2022"),Bundle.load_bundle(2021,"women_singles","senior"))
	T.assert_equal(gate.get("personal_eligibility",{}).get("eligible",false),true)
	T.assert_equal(gate.missing_qualification_ids.has("isu_senior_age"),false)
	T.assert_equal(gate.missing_qualification_ids.has("individual_entry_requirements"),false)
	T.assert_equal(gate.missing_qualification_ids.has("federation_championship_assignment"),true)
	T.assert_equal(gate.eligible,false)
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func missing() -> void:
	var fixture = Fixture.new()
	var c = fixture._career()
	c.season_program_plan.competitive_level = "senior"
	c.selection_state.assignments.player = ["isu_owg2022"]
	var gate := Entry.current_eligibility(c,fixture._event("isu_owg2022"),Bundle.load_bundle(2021,"women_singles","senior"))
	T.assert_equal(gate.eligible,false)
	T.assert_equal(gate.missing_qualification_ids.has("federation_championship_assignment"),false)
	T.assert_equal(gate.get("personal_eligibility",{}).get("eligible",true),false)
	T.assert_equal(gate.explanations.any(func(s):return "23" in s and "40" in s and "2022-01-24" in s),true)

func junior() -> void:
	var fixture = Fixture.new()
	var c = fixture._career()
	_prepare_programs(c,2021)
	c.selection_state.assignments.player = ["isu_world_junior_2022"]
	c.competition_archive.assign([fixture._archive("isu_jgp_courchevel_1_2021",23,38,2021,"junior")])
	var event := fixture._event("isu_world_junior_2022",2021,"junior")
	var minimum := Junior.evaluate_career(c,event)
	T.assert_equal(minimum.eligible,true)
	T.assert_equal(minimum.get("cutoff"),"2022-03-23")
	var gate := Entry.current_eligibility(c,event,Bundle.load_bundle(2021,"women_singles","junior"))
	T.assert_equal(gate.eligible,true,str(gate.explanations))
	T.assert_equal(gate.warnings.any(func(s):return "游戏截止日" in s),true)
	c.competition_archive[0].free_results.player.score.tes = 37.99
	c.competition_archive[0].free_results.player.protocol.tes = 37.99
	T.assert_equal(Entry.current_eligibility(c,event,Bundle.load_bundle(2021,"women_singles","junior")).eligible,false)

func unknown_age() -> void:
	var fixture = Fixture.new()
	var c = fixture._career()
	c.athlete.birth_date = {}
	c.season_program_plan.competitive_level = "senior"
	c.selection_state.assignments.player = ["isu_owg2022"]
	c.competition_archive.assign([fixture._archive("isu_gpusa2021",23,40)])
	var gate := Entry.current_eligibility(c,fixture._event("isu_owg2022"),Bundle.load_bundle(2021,"women_singles","senior"))
	T.assert_equal(gate.get("personal_eligibility",{}).get("status"),"unknown")
	T.assert_equal(gate.hard_gate_codes.has("international_age_unknown"),true)
	T.assert_equal(gate.hard_gate_codes.has("international_age_ineligible"),false)
	T.assert_equal(gate.explanations.any(func(s):return "生日" in s),true)

func real_archive() -> void:
	var fixture = Fixture.new()
	var c = F.formal_junior_career(891)
	c.clock.year = 2019
	c.clock.quarter = 3
	F.set_competition_strength(c.athlete,95.0)
	_prepare_programs(c,2019)
	var event := fixture._event("isu_jgp_courchevel_2019",2019,"junior")
	if event.is_empty(): return
	c.selection_state.assignments.player = [event.event_id]
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var session: Dictionary = sim.create_session(c,event,c.active_programs,"balanced",891,34)
	T.assert_equal(session.errors,[])
	if not session.errors.is_empty(): return
	session = sim.lock_short(c,sim.complete_practice(session,"accept"))
	T.assert_equal(session.errors,[])
	T.assert_equal(session.get("player_qualified",false),true)
	if not session.get("player_qualified",false): return
	session = sim.lock_free(c,session,"keep")
	T.assert_equal(session.errors,[])
	c.clock.year = 2022
	c.clock.quarter = 1
	var save := Save.save(c,"user://personal-eligibility-real-junior.json")
	T.assert_equal(save.ok,true,str(save.errors))
	if not save.ok: return
	var loaded := Save.load_save("user://personal-eligibility-real-junior.json")
	T.assert_equal(loaded.ok,true)
	if not loaded.ok: return
	var target := fixture._event("isu_world_junior_2022",2021,"junior")
	T.assert_equal(Junior.evaluate_career(loaded.career,target).eligible,true)
	var olympics := fixture._event("isu_owg2022")
	T.assert_equal(Personal.evaluate(loaded.career,olympics,Personal.policy_for(olympics)).eligible,false)

func _prepare_programs(career,year: int) -> void:
	F.set_competition_strength(career.athlete,95.0)
	for segment in ["short","free"]:
		var rules = load("res://src/content/internal_event_rules.gd").for_season(year,"junior",segment)
		var draft = load("res://src/simulation/program_draft_service.gd").propose(career.athlete,segment,rules,{},891)
		T.assert_equal(draft.errors,[])
		T.assert_equal(draft.missing,[])
		if draft.program != null: career.active_programs[segment] = draft.program.to_dict()
