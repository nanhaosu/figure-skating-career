extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"cohort cannot label shortened training as completed","callable":report_bounds}]

func report_bounds() -> void:
	var path := "res://scripts/connected_coaching_sample.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"paired growth needs a verifiable report driver")
	if not FileAccess.file_exists(path): return
	var driver = load(path).new()
	T.assert_equal(driver.validate_report({"completed":true,"requested_quarters":24,"executed_quarters":3,"trace":[{}, {}, {}],"errors":[]}).is_empty(),false)
	T.assert_equal(driver.validate_report({"completed":false,"requested_quarters":24,"executed_quarters":3,"trace":[{}, {}, {}],"errors":[],"stop_reason":"unknown"}).is_empty(),false)
	# Validator-only stopped shape from real complete snapshot. This mutation
	# is NOT natural injury evidence and is never included in cohort results.
	var stopped: Dictionary = driver.run_sample(42000,"coach_lin","balanced",1)
	stopped.completed = false
	stopped.requested_quarters = 24
	stopped.stop_reason = "major_medical_choice"
	stopped.pending_decision = {"kind":"rehabilitation_initial"}
	T.assert_equal(driver.validate_report(stopped).is_empty(),true)
