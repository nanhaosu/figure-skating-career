extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const Planner = preload("res://src/simulation/season_calendar_planner.gd")
const Entry = preload("res://src/simulation/entry_application_service.gd")
const Progression = preload("res://src/simulation/season_progression_service.gd")
const Journey = preload("res://src/app/season_journey_presenter.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"canceled junior2020 season offers no invented registration or execution stops","callable":_empty_season},
		{"name":"canceled nationals never appears as an actionable domestic checkbox","callable":_domestic_picker},
		{"name":"cancellation remains visible history but never becomes the next required decision","callable":_journey},
		{"name":"batch domestic schedule skips canceled identities without missing entry access","callable":_batch},
		{"name":"direct canceled entry reports cancellation even when other qualification is absent","callable":_direct},
	]

func _career(year:int):
	var career=F.formal_junior_career(772)
	career.clock.year=year
	career.clock.quarter=3
	career.season_state={"season_id":"%d-%02d"%[year,(year+1)%100],"entry_plan":{},"qualification_state":{},"event_statuses":{}}
	return career

func _empty_season() -> void:
	var career=_career(2020)
	var bundle=B.load_bundle(2020,"women_singles","junior")
	T.assert_equal(bundle.errors,[])
	if not bundle.errors.is_empty():return
	var before=career.to_dict()
	var proposed=Planner.propose(career,bundle.calendar,bundle.rules)
	T.assert_equal(proposed.errors,[])
	if not proposed.errors.is_empty():return
	T.assert_equal(proposed.plan.entries,{},"Canceling allJGP/WJC does not create skip-confirmation obligations")
	T.assert_equal(Progression._next_event(career,bundle),{},"Canceled events cannot consume calendar time or generate world matches")
	T.assert_equal(career.to_dict(),before,"Preview must preserve saves/history")

func _domestic_picker() -> void:
	var career=_career(2021)
	var bundle=B.load_bundle(2021,"women_singles","junior")
	T.assert_equal(bundle.errors,[])
	if not bundle.errors.is_empty():return
	var cancelled_ids:Array=bundle.calendar.events.filter(func(e):return e.get("status")=="cancelled").map(func(e):return e.event_id)
	T.assert_equal(cancelled_ids.is_empty(),false)
	var options=Entry.domestic_schedule_options(career,bundle)
	T.assert_equal(options.any(func(row):return cancelled_ids.has(row.event_id)),false)

func _journey() -> void:
	var career=_career(2020)
	var bundle=B.load_bundle(2020,"women_singles","junior")
	T.assert_equal(bundle.errors,[])
	if not bundle.errors.is_empty():return
	var view=Journey.build(career,bundle.calendar,{"entries":{}})
	T.assert_equal(view.events.size(),bundle.calendar.events.size(),"Canceled facts remain visible in fullcalendar")
	T.assert_equal(view.next_event_id,"")
	T.assert_equal(view.current_chain,[])
	for event in view.events:
		T.assert_equal(event.status,"cancelled")
		T.assert_equal(event.status_label,"已取消")
		T.assert_equal(event.has_entry_choice,false)

func _batch() -> void:
	var career=_career(2021)
	var result=Entry.apply_domestic_schedule(career,[])
	T.assert_equal(result.ok,true)
	var bundle=B.for_career(career)
	for event in bundle.calendar.events:
		if event.get("status")=="cancelled":T.assert_equal(career.season_state.entry_plan.entries.has(event.event_id),false)

func _direct() -> void:
	var career=_career(2020)
	var bundle=B.for_career(career)
	var event=bundle.calendar.events[0]
	var gate=Entry.current_eligibility(career,event,bundle)
	T.assert_equal(gate.eligible,false)
	T.assert_equal(gate.hard_gate_codes.has("event_cancelled"),true)
