extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"two routes change actual lessons not only text","callable":test_courses},
		{"name":"visible training summary includes focus review facts","callable":test_visible_feedback},
		{"name":"nonjump focus receives visible real progress","callable":test_nonjump_feedback}]

func test_visible_feedback() -> void:
	var before = F.starting_career(1013)
	var after = before.transaction_copy()
	after.training_direction.focuses = [{"id":"steps","kind":"steps","target":{}}]
	after.athlete.skating.turns += 2.0
	var facts: Array = load("res://src/presentation/training_focus_review_presenter.gd").build(before.to_dict(),after).facts
	var report: Dictionary = load("res://src/presentation/training_period_presenter.gd").build(before,{"career":after,"stop_reason":"quarter_complete","elapsed_weeks":12,"facts":facts})
	T.assert_equal(report.happened.any(func(row): return str(row.text).contains("步法") and str(row.text).contains("2.00")),true)
	T.assert_equal(report.changes.any(func(row): return str(row.text).contains("尚未结算")),false)
	T.assert_equal(report.plan.any(func(row): return str(row.text).contains("尚未开始")),false)

func test_courses() -> void:
	var a = F.formal_junior_career(1011)
	var b = a.transaction_copy()
	a.training_direction.focuses = [{"id":"combo","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"flip","rotations":3},{"jump_id":"toe_loop","rotations":3}]}},{"id":"expression","kind":"musical_expression","target":{}}]
	b.training_direction.focuses = [{"id":"execution","kind":"execution","target":{"segment":"free"}},{"id":"steps","kind":"steps","target":{}}]
	var coach = load("res://src/simulation/coach_training_plan_service.gd")
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var first: Dictionary = coach.build(a,intent)
	var second: Dictionary = coach.build(b,intent)
	T.assert_equal(first.errors,[])
	T.assert_equal(second.errors,[])
	T.assert_equal(first.plan.shares == second.plan.shares,false)
	for built in [first,second]:
		var total := 0
		for value in built.plan.shares.values(): total += int(value)
		T.assert_equal(total,100)
		T.assert_equal(int(built.plan.shares.rest) > 0,true)
		T.assert_equal(int(built.plan.shares.rotation) > 0,true)

func test_nonjump_feedback() -> void:
	var career = F.starting_career(1012)
	career.training_direction.focuses = [{"id":"steps","kind":"steps","target":{}}]
	var before: Dictionary = career.to_dict()
	career.athlete.skating.turns += 2.0
	var report: Dictionary = load("res://src/presentation/training_focus_review_presenter.gd").build(before,career)
	T.assert_equal(report.facts.size() <= 3,true)
	T.assert_equal(report.facts.any(func(row): return str(row.text).contains("步法") and str(row.text).contains("2.00")),true)
