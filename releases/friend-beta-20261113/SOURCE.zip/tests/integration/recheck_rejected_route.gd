extends RefCounted

var suite = preload("res://tests/integration/test_first_international_season.gd").new()

func cases() -> Array[Dictionary]:
	return [{"name":"public rejected route recheck with factual qualification", "callable":suite.test_rejected}]
