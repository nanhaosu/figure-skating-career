extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const B = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"career group selects actual junior or senior international calendar", "callable":calendars},
		{"name":"transition calendar merges both groups with unique domestic IDs", "callable":transition},
		{"name":"actual mixed domestic event uses senior rules while U2 stays junior", "callable":event_rules},
		{"name":"group calendar and event inspection preserve career and reject forged scope", "callable":pure},
	]

func _career(level: String):
	var c = F.formal_junior_career(4041)
	c.clock.year = 2021
	c.clock.quarter = 3
	c.season_program_plan.competitive_level = level
	return c

func calendars() -> void:
	for level in ["junior","senior"]:
		var b := B.for_career(_career(level))
		T.assert_equal(b.errors,[])
		if not b.errors.is_empty(): return
		var ids: Array = b.calendar.events.map(func(e):return e.event_id)
		T.assert_equal(ids.has("isu_owg2022"),level == "senior")
		T.assert_equal(ids.has("isu_jgp_courchevel_1_2021"),level == "junior")
		T.assert_equal(ids.has("cn_junior_u_series_2021_stage_2"),true)

func transition() -> void:
	var b := B.for_career(_career("transition"))
	T.assert_equal(b.errors,[])
	if not b.errors.is_empty(): return
	var seen := {}
	for event in b.calendar.events:
		T.assert_equal(seen.has(event.event_id),false)
		seen[event.event_id] = true
	T.assert_equal(seen.has("isu_owg2022") and seen.has("isu_world_junior_2022"),true)
	T.assert_equal(b.calendar.series_rules.has("club"),true)

func _resolved(c,event: Dictionary) -> Dictionary:
	var api = B.new()
	T.assert_equal(api.has_method("competition_for_career"),true,"actual group must reach the rule consumer")
	if not api.has_method("competition_for_career"): return {}
	return api.competition_for_career(c,event)

func event_rules() -> void:
	var c = _career("senior")
	var b := B.load_bundle(2021,"women_singles","junior")
	for id in ["cn_grand_prix_2021","cn_junior_u_series_2021_stage_2"]:
		var events: Array = b.calendar.events.filter(func(e):return e.event_id == id)
		T.assert_equal(events.size(),1)
		if events.is_empty(): return
		var result := _resolved(c,events[0])
		if result.is_empty(): return
		T.assert_equal(result.errors,[])
		if not result.errors.is_empty(): return
		var senior: bool = id == "cn_grand_prix_2021"
		T.assert_equal(result.event.competition_level,"senior" if senior else "junior")
		T.assert_equal(result.rules.free.segment_rules.get("choreographic_min"),1 if senior else 0)

func pure() -> void:
	var c = _career("transition")
	var before := JSON.stringify(c.to_dict())
	var b := B.for_career(c)
	if not b.errors.is_empty(): return
	T.assert_equal(b.calendar.events.any(func(e):return e.event_id == "isu_owg2022"),true)
	for event in b.calendar.events:
		if event.event_id != "isu_owg2022": continue
		var forged: Dictionary = event.duplicate(true)
		forged.scope = "domestic"
		var result := _resolved(c,forged)
		if not result.is_empty(): T.assert_equal(result.errors.is_empty(),false)
	T.assert_equal(JSON.stringify(c.to_dict()),before)
