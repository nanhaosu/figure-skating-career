extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"actual Olympic withdrawal promotes the qualified published alternate without rewriting trial results", "callable":replacement},{"name":"qualified persistent international Olympic field executes both real segments within actual country caps", "callable":international_execution}]

func international_execution() -> void:
	# Controlled earned-TES protocols isolate field and actual scoring consumers.
	# No claim that these minimums were naturally earned by the training route.
	var quota_archive: Dictionary = load("res://tests/integration/test_olympic_quota_archives.gd").new()._archive()
	for row in quota_archive.roster+quota_archive.final_standings:
		if row.federation == "N02": row.federation = "JPN"
	var c = load("res://tests/simulation/test_beijing_dispatch.gd").new()._controlled_ready(quota_archive)
	var caps: Dictionary = c.olympic_quota_state.current.countries
	for archive in c.competition_archive:
		if archive.get("event_id") != "isu_gpusa2021": continue
		for id in c.world_athletes:
			var record: Dictionary = c.world_athletes[id]
			if record.federation == "CHN" or int(caps.get(record.federation,0)) == 0: continue
			archive.short_results[id] = archive.short_results.player.duplicate(true)
			archive.free_results[id] = archive.free_results.player.duplicate(true)
	T.assert_equal(load("res://src/simulation/beijing_trial_service.gd").finalize(c,"2022-01-24").ok,true)
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event({"event_id":"isu_owg2022","ruleset_season_start_year":2021,"competition_level":"senior"}).event
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var programmes: Dictionary = load("res://src/simulation/season_program_service.gd").programs_for_event(c,event)
	var race: Dictionary = sim.create_session(c,event,programmes,"balanced",99246)
	T.assert_equal(race.get("errors",[]),[])
	if not race.get("errors",[]).is_empty(): return
	T.assert_equal(race.roster.any(func(row):return row.federation != "CHN"),true,"must exercise international competitors, not only the player")
	var counts := {}
	for row in race.roster: counts[row.federation] = int(counts.get(row.federation,0))+1
	for country in counts: T.assert_equal(int(counts[country]) <= int(caps.get(country,0)),true)
	race = sim.lock_short(c,sim.complete_practice(race,"accept"))
	T.assert_equal(race.get("errors",[]),[])
	if race.get("status") != "complete": race = sim.lock_free(c,race,"keep")
	T.assert_equal(race.get("errors",[]),[])
	T.assert_equal(race.get("status"),"complete")
	T.assert_equal(race.short_results.size(),race.roster.size())
	T.assert_equal(race.free_results.size()>0,true)
	T.assert_equal(race.final_standings.size(),race.roster.size())

func replacement() -> void:
	# Explicit controlled complete protocols isolate substitution. They are
	# not a claim that these athletes naturally earned international TES.
	var c = load("res://tests/simulation/test_beijing_dispatch.gd").new()._controlled_ready()
	var api = load("res://src/simulation/beijing_trial_service.gd")
	var ids: Array = c.beijing_trial_series.entrant_ids.filter(func(id):return id != "player").slice(0,4)
	T.assert_equal(ids.size(),4)
	if ids.size() != 4: return
	for archive in c.competition_archive:
		if api.event_ids().has(archive.get("event_id")):
			for index in ids.size():
				var id: String = ids[index]
				var sp := {"total":60.0-index,"tes":30.0,"pcs":30.0-index,"deductions":0.0}
				var fs := {"total":120.0-index,"tes":60.0,"pcs":60.0-index,"deductions":0.0}
				archive.roster.append({"athlete_id":id,"federation":"CHN"})
				archive.short_results[id] = {"score":sp,"protocol":sp.duplicate(),"technical_review":{"review_events":[]}}
				archive.free_results[id] = {"score":fs,"protocol":fs.duplicate(),"technical_review":{"review_events":[]}}
				archive.final_standings.append({"athlete_id":id,"federation":"CHN","total_score":sp.total+fs.total,"short_score":sp.total,"free_score":fs.total})
		elif archive.get("event_id") == "isu_gpusa2021":
			for id in ids:
				archive.short_results[id] = archive.short_results.player.duplicate(true)
				archive.free_results[id] = archive.free_results.player.duplicate(true)
	var prior_entries: Dictionary = c.season_state.entry_plan.entries.duplicate(true)
	var final: Dictionary = api.finalize(c,"2022-01-24")
	T.assert_equal(final.ok,true,final.get("error",""))
	for event_id in prior_entries:
		if event_id != "isu_owg2022": T.assert_equal(c.season_state.entry_plan.entries.get(event_id,{}) == prior_entries[event_id],true,"final Olympic dispatch must not recompute unrelated entry: "+event_id)
	T.assert_equal(final.selected_ids.size(),3)
	T.assert_equal(final.alternate_ids.size(),2)
	var frozen: Dictionary = c.beijing_trial_series.finalization.duplicate(true)
	var expected: Array = final.selected_ids.filter(func(id):return id != "player")
	expected.append(final.alternate_ids[0])
	var commands = load("res://src/simulation/career_command_service.gd")
	var withdrawn: Dictionary = commands.apply(c,{"type":"withdraw_entry","event_id":"isu_owg2022"})
	T.assert_equal(withdrawn.ok,true,withdrawn.get("error",""))
	if not withdrawn.ok: return
	var after = withdrawn.career
	T.assert_equal(after.olympic_quota_state.dispatch.selected_ids,expected)
	T.assert_equal(after.beijing_trial_series.finalization,frozen,"initial published selection and all best-four scores remain immutable")
	T.assert_equal(after.selection_state.assignments.get("player",[]).has("isu_owg2022"),false)
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event({"event_id":"isu_owg2022","ruleset_season_start_year":2021,"competition_level":"senior"}).event
	var field: Dictionary = load("res://src/simulation/formal_roster_generator.gd").build(after,event,99245,34,false)
	T.assert_equal(field.errors,[])
	var actual: Array = []
	for row in field.roster:
		if row.federation == "CHN": actual.append(row.athlete_id)
	actual.sort();expected.sort()
	T.assert_equal(actual,expected,"real Olympic field must consume replacement dispatch rather than stale original IDs")
	var replay: Dictionary = commands.apply(after,{"type":"withdraw_entry","event_id":"isu_owg2022"})
	T.assert_equal(replay.ok,true)
	if replay.ok: T.assert_equal(replay.career.to_dict()==after.to_dict(),true)
