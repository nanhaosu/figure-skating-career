extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Policy = preload("res://src/domain/training_policy.gd")
const Planner = preload("res://src/simulation/training_policy_planner.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Volume = preload("res://src/simulation/effective_training_calculator.gd")
const Stage = preload("res://src/simulation/quarter_training_stage_simulator.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"fast route adds real difficulty practice without secretly changing daily response","callable":test_fast_pace},
		{"name":"steady curriculum respects declared breadth without abandoning maintenance","callable":test_steady_breadth},
		{"name":"aggressive automatic policy preserves all jump families","callable":test_aggressive_policy_preserves_all_families},
		{"name":"aggressive policy actually practices nonfocus jump families","callable":test_policy_executed_batches},
		{"name":"daily coaching honors committed route priorities","callable":test_daily_route_priorities},
		{"name":"daily coaching with programme targets executes every jump family","callable":test_daily_program_execution},
		{"name":"following ordinary coach route avoids routine overload confirmations","callable":test_ordinary_route_load},
	]

func test_fast_pace() -> void:
	var c = F.triple_gap(73007)
	c.development_roadmap = {"route_id":"balanced","priority_jumps":["flip","lutz"],"risk_attitude":"normal"}
	var balanced = Coach.build(c,Intent.create("accept").intent).plan
	c.development_roadmap.route_id = "fast"
	var fast = Coach.build(c,Intent.create("accept").intent).plan
	T.assert_equal(int(fast.shares.jump_flip)+int(fast.shares.jump_lutz)>int(balanced.shares.jump_flip)+int(balanced.shares.jump_lutz),true)
	T.assert_equal(int(fast.shares.rest)>=20,true,"fast route is not the same as covertly selecting push every period")
	T.assert_equal(fast.total_share(),100)

func test_steady_breadth() -> void:
	var c = F.triple_gap(73006)
	c.development_roadmap = {"route_id":"steady","milestones":[{"age":15,"rotations":3,"count":3}],"priority_jumps":["toe_loop","salchow"],"risk_attitude":"cautious"}
	var plan = Coach.build(c,Intent.create("accept").intent).plan
	var advanced := 0
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		advanced += int(int(plan.jump_rotations[id]) >= 3)
		T.assert_equal(int(plan.shares["jump_"+id])>=5,true)
	T.assert_equal(advanced,3,"three-triple goal must not silently train five advanced families")
	var explicit = Coach.build(c,Intent.create("requested_element","jump:salchow:3").intent).plan
	T.assert_equal(int(explicit.jump_rotations.salchow),3,"a route is an automatic curriculum, not a hard difficulty lock")

func test_aggressive_policy_preserves_all_families() -> void:
	var career = F.triple_gap(73001)
	var policy = Policy.create("rotation_push",["flip","lutz"],{"flip":3,"lutz":3},"aggressive").policy
	var result := Planner.build(career,policy,{})
	T.assert_equal(result.plan.total_share(),100)
	for id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		T.assert_equal(int(result.plan.shares["jump_"+id]) >= 5,true,"automatic coaching must not abandon "+id)

func test_policy_executed_batches() -> void:
	var career = F.triple_gap(73002)
	var policy = Policy.create("rotation_push",["flip","lutz"],{"flip":3,"lutz":3},"aggressive").policy
	var plan = Planner.build(career,policy,{}).plan
	var rng := RandomNumberGenerator.new()
	rng.seed = 73002
	var result := Stage.simulate(career,plan,Volume.calculate(career,plan),rng)
	for id in ["toe_loop","salchow","loop"]:
		T.assert_equal(result.aggregate_batches.any(func(row): return row.get("jump_id") == id and int(row.get("attempts",0)) > 0),true,"planned foundations must reach real attempts for "+id)

func test_daily_route_priorities() -> void:
	var career = F.triple_gap(73003)
	var before = Coach.build(career,Intent.create("accept").intent).plan
	career.development_roadmap = {"route_id":"fast","milestones":[{"age":14,"rotations":3,"count":5}],"priority_jumps":["flip","lutz"],"deferred_jump":"","risk_attitude":"aggressive"}
	var after = Coach.build(career,Intent.create("accept").intent).plan
	T.assert_equal(int(after.shares.jump_flip)+int(after.shares.jump_lutz) > int(before.shares.jump_flip)+int(before.shares.jump_lutz),true,"route must affect the plan used by MeaningfulAdvanceService, not only hidden legacy controls")

func test_daily_program_execution() -> void:
	var career = F.triple_gap(73004)
	career.season_program_plan.targets = {"free":[{"action":{"kind":"jump","parts":[{"jump_id":"lutz","rotations":3}]}}]}
	var plan = Coach.build(career,Intent.create("more_aggressive").intent).plan
	var rng := RandomNumberGenerator.new()
	rng.seed = 73004
	var result := Stage.simulate(career,plan,Volume.calculate(career,plan),rng)
	for id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		T.assert_equal(result.aggregate_batches.any(func(row): return row.get("jump_id") == id and int(row.get("attempts",0)) > 0),true,id)

func test_ordinary_route_load() -> void:
	var c = F.triple_gap(73005)
	c.development_roadmap = {"route_id":"fast","priority_jumps":["flip","lutz"],"risk_attitude":"aggressive"}
	var plan = Coach.build(c,Intent.create("accept").intent).plan
	var proposal = load("res://src/simulation/authority_resolver.gd").preview(c,plan)
	T.assert_equal(proposal.conflicts.any(func(row): return row.reason_code in ["guardian_health_protection","coach_jump_load_safety"]),false,"automatic ordinary coaching should resolve routine load planning before asking the player")
	T.assert_equal(plan.coach_decision.allocated_gap_ids,["toe_loop"],"safety adjustment must preserve the shortfall lesson")
