extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"teaching invitation during a resumed stage cannot fabricate unexecuted weeks","callable":teaching_checkpoint},{"name":"quarter command commits only requested stages and resumes after real save", "callable":durable_stages}, {"name":"corrupt durable checkpoint is rejected before execution", "callable":invalid_checkpoint}, {"name":"failed checkpoint save leaves source untouched and retry repeats no random draws", "callable":failed_save_retry}, {"name":"recovery replan keeps completed foundations and excludes future jumps", "callable":safe_replan}, {"name":"continue training adapts unsafe paused curriculum without manual reconfiguration", "callable":coach_resume}, {"name":"limited continuation cannot settle beyond requested weeks", "callable":limited_resume}, {"name":"repeated same stage request cannot commit another stage", "callable":duplicate_stage}]

func teaching_checkpoint() -> void:
	var career = prepared()
	career.clock.quarter = 2
	career.training_period_state.started_clock = career.clock.to_dict()
	load("res://src/simulation/teaching_competition_service.gd").evaluate(career)
	career.internal_invitation_state.scheduled_week = 17
	var partial: Dictionary = Commands.apply(career,{"type":"advance_quarter","stage_limit":1,"bundle":load("res://src/content/season_bundle_repository.gd").for_career(career)})
	T.assert_equal(partial.ok,true)
	if not partial.ok: return
	var result: Dictionary = load("res://src/simulation/meaningful_advance_service.gd").advance(partial.career,load("res://src/domain/training_intent.gd").create("accept").intent,9)
	T.assert_equal(result.elapsed_weeks,3,"finish one actual three-week stage before presenting the due invitation")
	T.assert_equal(result.career.training_period_state.weeks_elapsed,6)
	T.assert_equal(result.pending_action.kind,"teaching_competition")
	# Advanced/manual plans enter through the same command without a coach period.
	var manual = prepared()
	manual.training_period_state = {"stage_limit":1}
	var plan = load("res://src/domain/training_plan.gd").from_dict(manual.last_generated_plan)
	load("res://src/simulation/career_simulator.gd").advance_quarter(manual,plan,load("res://src/content/catalog_repository.gd").load_catalog())
	manual.training_period_state.erase("stage_limit")
	var saved: Dictionary = load("res://src/persistence/save_repository.gd").save(manual,"user://manual-checkpoint.json")
	T.assert_equal(saved.ok,true,str(saved.get("errors",[])))
	# A second, pre-settlement pain event must retain the first actual stage.
	var interrupted = prepared()
	var first: Dictionary = Commands.apply(interrupted,{"type":"advance_quarter","stage_limit":1,"bundle":load("res://src/content/season_bundle_repository.gd").for_career(interrupted)})
	T.assert_equal(first.ok,true)
	if not first.ok: return
	first.career.athlete.body.impact_load = 16.0
	var checkpoint: Dictionary = first.career.training_period_state.stage_checkpoint.duplicate(true)
	var paused: Dictionary = load("res://src/simulation/meaningful_advance_service.gd").advance(first.career,load("res://src/domain/training_intent.gd").create("accept").intent)
	T.assert_equal(paused.pending_action.kind,"quarter_event")
	T.assert_equal(paused.career.training_period_state.get("stage_checkpoint",{}),checkpoint,"second interruption must preserve executed stage budget and RNG")

func duplicate_stage() -> void:
	var career = prepared()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var command := {"type":"advance_quarter","stage_limit":1,"expected_stage":0,"expected_clock":career.clock.to_dict(),"bundle":bundle}
	var first: Dictionary = Commands.apply(career,command)
	T.assert_equal(first.ok,true)
	if not first.ok: return
	var before: Dictionary = first.career.to_dict()
	var second: Dictionary = Commands.apply(first.career,command)
	T.assert_equal(second.ok,false,"replay of committed stage request must be refused")
	T.assert_equal(first.career.to_dict()==before,true)
	var stale: Dictionary = command.duplicate(true)
	stale.expected_stage = 1
	stale.expected_clock = {"year":2013,"quarter":1}
	T.assert_equal(Commands.apply(first.career,stale).ok,false,"matching stage index must not authorize a request from another quarter")

func limited_resume() -> void:
	var career = prepared()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var partial: Dictionary = Commands.apply(career,{"type":"advance_quarter","stage_limit":1,"bundle":bundle})
	T.assert_equal(partial.ok,true)
	if not partial.ok: return
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var result: Dictionary = load("res://src/simulation/meaningful_advance_service.gd").advance(partial.career,intent,3)
	T.assert_equal(result.career.clock.to_dict(),career.clock.to_dict())
	T.assert_equal(result.elapsed_weeks,3)
	T.assert_equal(result.career.training_period_state.get("weeks_elapsed"),6)

func coach_resume() -> void:
	var career = prepared()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var partial: Dictionary = Commands.apply(career,{"type":"advance_quarter","stage_limit":1,"bundle":bundle})
	T.assert_equal(partial.ok,true)
	if not partial.ok: return
	partial.career.condition_state.function_limits = {"landing":{"blocked":true}}
	var before := {}
	for jump_id in career.athlete.jumps: before[jump_id] = partial.career.athlete.jumps[jump_id].attempts
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var result: Dictionary = load("res://src/simulation/meaningful_advance_service.gd").advance(partial.career,intent,12)
	T.assert_equal(result.stop_reason,"quarter_complete",str(result.pending_action))
	T.assert_equal(result.errors,[])
	for jump_id in before: T.assert_equal(result.career.athlete.jumps[jump_id].attempts,before[jump_id])

func safe_replan() -> void:
	var career = prepared()
	var original_skating: float = career.athlete.skating.deep_edge
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var partial: Dictionary = Commands.apply(career,{"type":"advance_quarter","stage_limit":1,"bundle":bundle})
	T.assert_equal(partial.ok,true)
	if not partial.ok: return
	var paused = partial.career
	paused.condition_state.function_limits = {"landing":{"blocked":true}}
	var shares: Dictionary = paused.last_generated_plan.shares.duplicate()
	for key in shares: shares[key] = 0
	shares.rest = 100
	paused.last_generated_plan = load("res://src/domain/training_plan.gd").create(shares).plan.to_dict()
	var attempts := {}
	for jump_id in paused.athlete.jumps: attempts[jump_id] = paused.athlete.jumps[jump_id].attempts
	var resumed: Dictionary = Commands.apply(paused,{"type":"advance_quarter","bundle":bundle})
	T.assert_equal(resumed.ok,true,str(resumed.get("error",resumed.get("stop_node",{}))))
	if not resumed.ok: return
	for jump_id in attempts: T.assert_equal(resumed.career.athlete.jumps[jump_id].attempts,attempts[jump_id])
	T.assert_equal(float(resumed.career.athlete.skating.deep_edge)>original_skating,true,"the completed first stage's foundation practice must not disappear when the remaining plan changes")

func failed_save_retry() -> void:
	var career = prepared()
	var original: Dictionary = career.to_dict()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var command := {"type":"advance_quarter","stage_limit":1,"bundle":bundle}
	var first: Dictionary = Commands.apply(career,command)
	T.assert_equal(first.ok,true)
	if not first.ok: return
	var snapshot: Dictionary = first.career.to_dict()
	var saved: Dictionary = load("res://src/persistence/save_repository.gd").save(first.career,"user://stage-checkpoint-missing-directory-1810/career.json")
	T.assert_equal(saved.ok,false)
	T.assert_equal(career.to_dict()==original,true)
	T.assert_equal(first.career.to_dict()==snapshot,true)
	var retry: Dictionary = Commands.apply(career,command)
	T.assert_equal(retry.ok,true)
	if retry.ok:
		T.assert_equal(retry.career.to_dict()==snapshot,true,"retry must reproduce the same uncommitted stage rather than adding another")

func invalid_checkpoint() -> void:
	var career = prepared()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var partial: Dictionary = Commands.apply(career,{"type":"advance_quarter","stage_limit":1,"bundle":bundle})
	T.assert_equal(partial.ok,true)
	if not partial.ok: return
	var repo = load("res://src/persistence/save_repository.gd")
	T.assert_equal(repo._validate_payload({"save_version":19,"saved_at_unix":0,"career":partial.career.to_dict()},false),"","checkpoint corruption tests must start from an accepted current-version payload")
	for field in ["next_stage","rng_state","volume","identity","plan","shares_acc","category_volumes_acc"]:
		var data: Dictionary = partial.career.to_dict()
		data.training_period_state.stage_checkpoint.erase(field)
		T.assert_equal(repo._validate_payload({"save_version":19,"saved_at_unix":0,"career":data},false).is_empty(),false,"incomplete checkpoint must not be accepted")
	var bad: Dictionary = partial.career.to_dict()
	bad.training_period_state.stage_checkpoint.volume.jump_attempts.toe_loop = 2.5
	T.assert_equal(repo._validate_payload({"save_version":19,"saved_at_unix":0,"career":bad},false).is_empty(),false)
	bad = partial.career.to_dict()
	bad.training_period_state.stage_checkpoint.shares_acc.rest += 5.0
	T.assert_equal(repo._validate_payload({"save_version":19,"saved_at_unix":0,"career":bad},false).is_empty(),false,"completed allocations must match elapsed stage fraction")

func prepared():
	var career = F.starting_career(1601)
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var plan = load("res://src/simulation/coach_training_plan_service.gd").build(career,intent).plan.to_dict()
	career.last_generated_plan = plan.duplicate(true)
	career.training_period_state = {"weeks_elapsed":0,"intent":intent.to_dict(),"plan":plan,"started_clock":career.clock.to_dict()}
	return career

func durable_stages() -> void:
	var career = prepared()
	var original: Dictionary = career.to_dict()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var whole: Dictionary = Commands.apply(career,{"type":"advance_quarter","bundle":bundle})
	T.assert_equal(whole.ok,true,str(whole))
	var partial: Dictionary = Commands.apply(career,{"type":"advance_quarter","stage_limit":1,"bundle":bundle})
	T.assert_equal(partial.ok,true,str(partial.get("error",partial.get("stop_node",{}))))
	T.assert_equal(career.to_dict()==original,true,"command works on a transaction copy")
	if not partial.ok or not whole.ok: return
	T.assert_equal(partial.career.clock.to_dict(),career.clock.to_dict(),"unfinished quarter must not advance calendar")
	T.assert_equal(partial.career.training_period_state.get("stage_checkpoint",{}).get("next_stage"),1)
	T.assert_equal(partial.career.training_period_state.weeks_elapsed,3)
	if partial.career.training_period_state.get("stage_checkpoint",{}).is_empty(): return
	var repo = load("res://src/persistence/save_repository.gd")
	T.assert_equal(repo.save(partial.career,"user://stage-transaction.json").ok,true)
	var loaded: Dictionary = repo.load_save("user://stage-transaction.json")
	T.assert_equal(loaded.ok,true)
	if not loaded.ok: return
	var resumed: Dictionary = Commands.apply(loaded.career,{"type":"advance_quarter","bundle":bundle})
	T.assert_equal(resumed.ok,true,str(resumed.get("stop_node",{})))
	if not resumed.ok: return
	T.assert_equal(resumed.career.clock.to_dict(),whole.career.clock.to_dict())
	T.assert_equal(resumed.career.random_streams.to_dict(),whole.career.random_streams.to_dict())
	for jump_id in career.athlete.jumps:
		T.assert_equal(resumed.career.athlete.jumps[jump_id].attempts,whole.career.athlete.jumps[jump_id].attempts,"partial practice must not repeat")
