extends RefCounted
const T = preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"planned public journey completes the first teaching event and applies its actual club decision","callable":first_internal}]
func first_internal() -> void:
	var created: Dictionary = load("res://src/simulation/career_factory.gd").create("林澄",2006,"entry_club_trial","family_ambitious",41046,load("res://src/content/catalog_repository.gd").load_catalog(),4)
	T.assert_equal(created.errors,[])
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = load("res://src/app/main.tscn").instantiate()
	driver.main.save_path = "user://first-internal-public.json"
	driver.main.autosave_path = "user://first-internal-public-auto.json"
	Engine.get_main_loop().root.add_child(driver.main)
	driver._adopt(created.career)
	var completed := false
	for step in 8:
		var previous: float = driver.main.active_career.athlete.resources.ice_access
		await driver._train_quarter()
		T.assert_equal(driver.errors,[])
		var entries: Array = driver.main.active_career.history.filter(func(e): return e.get("category") == "internal_competition")
		if not entries.is_empty():
			completed = true
			T.assert_equal(entries.size(),1)
			T.assert_equal(entries[0].total_score > 0.0,true)
			T.assert_equal(entries[0].standings.size(),6)
			T.assert_equal(driver.main.active_career.athlete.resources.ice_access,previous+float(entries[0].club_decision.resource_changes.ice_access))
			T.assert_equal(driver.main.active_career.internal_invitation_state.status,"completed")
			T.assert_equal(int(driver.main.active_career.internal_invitation_state.offered_week) >= 18 and int(driver.main.active_career.internal_invitation_state.offered_week) <= 36,true)
			T.assert_equal(driver.main.active_career.internal_invitation_state.peer_ids.size(),5)
			for row in entries[0].standings:
				if not bool(row.is_player): T.assert_equal(driver.main.active_career.world_athletes.has(str(row.id)),true)
			T.assert_equal(driver.main.start_internal_competition().ok,false,"first-only event cannot be farmed")
			break
		if driver.main.active_career.clock.year >= 2015: break
	T.assert_equal(completed,true,"planned route must not unconditionally defer its only public teaching competition")
	driver.main.free()
