extends RefCounted

# Natural sample strategy, real stopped-state provenance and gap fairness.
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Gap = preload("res://src/simulation/training_gap_diagnoser.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"equal recency gap prefers stronger existing clean evidence","callable":evidence_order},
		{"name":"equal recency gap prefers executable work over unready preparation","callable":readiness_order},
		{"name":"older actual gap practice remains ahead of nearness preferences","callable":recency_guard},
		{"name":"primary fast route cohort actually follows coach rather than pushing every quarter","callable":response_strategy},
		{"name":"medical stopped report captures the actual interrupted body","callable":stopped_snapshot},
		{"name":"cohort rejects a report without final snapshot clock provenance","callable":snapshot_validation},
		{"name":"primary novice sample delegates optional jump priorities to coach","callable":unspecified_priorities},
	]

func evidence_order() -> void:
	var c = F.triple_gap(73641)
	c.athlete.jumps.salchow.attempt_evidence.double.clean_successes = 30
	c.athlete.jumps.loop.attempt_evidence.double.clean_successes = 25
	var ids: Array = Gap.inspect(c).candidates.map(func(row): return row.jump_id)
	T.assert_equal(ids,["salchow","loop","toe_loop"])

func readiness_order() -> void:
	var c = F.triple_gap(73642)
	c.athlete.jumps.toe_loop.proficiency.double = 1.0
	T.assert_equal(Gap.inspect(c).candidates[0].jump_id,"salchow")

func recency_guard() -> void:
	var c = F.triple_gap(73643)
	c.athlete.jumps.toe_loop.proficiency.double = 1.0
	c.athlete.jumps.salchow.attempt_evidence.double.clean_successes = 30
	c.coach_training_state.completed_periods = 3
	c.coach_training_state.last_practiced = {"toe_loop":1,"salchow":2,"loop":3}
	T.assert_equal(Gap.inspect(c).candidates[0].jump_id,"toe_loop","a ready rival cannot permanently displace an overdue gap")

func response_strategy() -> void:
	var driver = load("res://scripts/connected_coaching_sample.gd").new()
	var report: Dictionary = driver.run_sample(42000,"coach_lin","fast",1)
	T.assert_equal(report.errors,[])
	T.assert_equal(report.get("response"),"accept","route preference and daily response must be separate evidence")
	T.assert_equal(report.trace.size(),1)
	if report.trace.is_empty(): return
	T.assert_equal(int(report.trace[0].plan.shares.rest)>=20,true,"following the coach must not silently select the lower-rest push response")

func stopped_snapshot() -> void:
	# Reproduced natural stop: injury:2015:4:0 after seven completed periods.
	# Read-only boundary probe showed actual impact15.36 vs stale reported0.
	var driver = load("res://scripts/connected_coaching_sample.gd").new()
	var report: Dictionary = driver.run_sample(42010,"coach_lin","balanced",24)
	T.assert_equal(report.errors,[])
	T.assert_equal(report.completed,false,"keep this reproduced interrupted-stage regression fixture explicit")
	T.assert_equal(report.stop_reason,"major_medical_choice")
	T.assert_equal(float(report.final.body.impact_load)>0.0,true,"capture injury-stage state, not the previous completed quarter")
	T.assert_equal(report.final.get("clock"),{"year":2015,"quarter":4})

func snapshot_validation() -> void:
	var driver = load("res://scripts/connected_coaching_sample.gd").new()
	var report: Dictionary = driver.run_sample(42000,"coach_lin","balanced",1)
	T.assert_equal(driver.validate_report(report).is_empty(),true)
	var bad: Dictionary = report.duplicate(true)
	bad.final.erase("clock")
	T.assert_equal(driver.validate_report(bad).is_empty(),false,"missing provenance cannot be called a validated report")

func unspecified_priorities() -> void:
	var driver = load("res://scripts/connected_coaching_sample.gd").new()
	var report: Dictionary = driver.run_sample(42000,"coach_lin","fast",1)
	T.assert_equal(report.errors,[])
	if report.trace.is_empty(): T.assert_equal(false,true,"a real first period must execute"); return
	var actual: Dictionary = report.trace[0].plan.shares
	T.assert_equal(actual.jump_flip,5,"primary novice sample must not silently choose F/Lz instead of the player's unspecified priorities")
	T.assert_equal(actual.jump_lutz,5)
	T.assert_equal(int(actual.jump_toe_loop)>=10,true,"coach must actually resolve a basic priority")
