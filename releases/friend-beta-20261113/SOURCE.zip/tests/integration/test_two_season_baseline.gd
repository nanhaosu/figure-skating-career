extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"two season audit handles offseason through a real command","callable":test_offseason},
		{"name":"two seasons do not silently exit on unknown node","callable":test_unknown}]

func _driver():
	T.assert_equal(FileAccess.file_exists("res://scripts/audit_two_season_baseline.gd"),true,"audit consumer is not implemented")
	return load("res://scripts/audit_two_season_baseline.gd").new() if FileAccess.file_exists("res://scripts/audit_two_season_baseline.gd") else null

func test_offseason() -> void:
	var driver = _driver()
	if driver == null: return
	var career = F.starting_career(41046)
	career.clock.year = 2019
	career.clock.quarter = 3
	career.season_state.season_history = {"2018-19":{"season":{},"record_book":{},"ranking_state":{},"clock":{}}}
	var before: Dictionary = load("res://src/persistence/numeric_state.gd").canonical_copy(career.athlete.to_dict())
	driver.main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(driver.main)
	driver.main.autosave_path = "user://baseline-offseason.json"
	driver._adopt(career)
	var node: Dictionary = load("res://src/simulation/offseason_event_service.gd").pending(driver.main.active_career)
	await driver._handle_node(node,{})
	T.assert_equal(driver.errors,[])
	T.assert_equal(driver.main.active_career.athlete.to_dict(),before)
	T.assert_equal(driver.main.active_career.event_ledger.back().kind,"offseason_choice")
	T.assert_equal(driver.main.active_career.selection_state,career.selection_state)
	driver.main.free()

func test_unknown() -> void:
	var driver = _driver()
	if driver == null: return
	driver.main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(driver.main)
	driver.main.active_career = F.starting_career(41046)
	await driver._handle_node({"kind":"unsupported_probe"},{})
	T.assert_equal(driver.errors.size(),1)
	T.assert_equal(str(driver.errors[0]).contains("unhandled_node"),true)
	driver.main.free()
