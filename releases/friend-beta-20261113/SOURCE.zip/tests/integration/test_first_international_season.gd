extends RefCounted

const T = preload("res://tests/test_support.gd")
const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"public 2014 career earns first age-eligible international season", "callable":test_assigned},
		{"name":"public 2014 career survives rejection and closes alternative season", "callable":test_rejected},
	]

func test_assigned() -> void:
	await _journey(true)

func test_rejected() -> void:
	await _journey(false)

func _journey(assigned: bool) -> void:
	var created := Factory.create("林澄" if assigned else "陈雪",2006,"entry_club_trial" if assigned else "entry_interest_class","family_ambitious" if assigned else "family_supportive",41046 if assigned else 41042,Catalog.load_catalog(),4)
	T.assert_equal(created.errors,[])
	if created.career == null: return
	T.assert_equal(created.career.clock.to_dict(),{"year":2014,"quarter":1})
	T.assert_equal(created.career.athlete.birth_year,2006)
	# This positive route represents choosing a known pre-July birthday.
	# A year-only legacy identity cannot establish the age-thirteen boundary.
	created.career.athlete.birth_date = {"year":2006,"month":6,"day":30}
	# The 2014 age-eight start first meets the junior minimum in 2019.
	# A missing 2019 bundle must fail rather than silently reuse 2018 dates/rules.
	var bundle := Bundle.load_bundle(2019,"women_singles","junior")
	T.assert_equal(bundle.errors,[],"first age-eligible international season must be playable")
	if not bundle.errors.is_empty(): return
	var driver = load("res://scripts/international_season_journey.gd").new()
	var result: Dictionary = await driver.run(created.career,assigned)
	T.assert_equal(result.errors,[],"errors=%s trace=%s" % [str(result.errors),str(result.get("trace",[]))])
	if not result.errors.is_empty(): return
	var career = result.career
	T.assert_equal(career.event_ledger.any(func(e): return e.get("kind") == "season_closed" and e.get("season_id") == "2019-20"),true)
	T.assert_equal(career.season_state.season_history.has("2019-20"),true)
	var selections: Dictionary = career.selection_state.season_history["2019-20"]
	T.assert_equal(selections.decisions.has("jgp"),true)
	var assigned_event_ids: Array = selections.assignments.get("player",[])
	var entered: Array = career.competition_archive.filter(func(a): return a.season_id == "2019-20" and not a.get("world_only",false))
	for archive in career.competition_archive:
		T.assert_equal(archive.short_standings.any(func(r): return float(r.short_score)>0.0),true,"silent zero-score SP: "+archive.event_id)
		T.assert_equal(archive.final_standings.any(func(r): return float(r.get("total_score",0))>0.0),true,"silent zero-score final: "+archive.event_id)
	for archive in entered.filter(func(a): return a.event.event_family == "jgp_stage"):
		T.assert_equal(assigned_event_ids.has(archive.event_id),true,"every JGP start must name the same event in the published selection result")
	# The self-funded route explicitly keeps entry money by skipping optional
	# domestic starts. Its genuine prior domestic experience remains required;
	# the assigned merit route still requires current-season domestic results.
	var domestic_evidence: Array = entered if assigned else career.competition_archive.filter(func(a): return not a.get("world_only",false))
	T.assert_equal(domestic_evidence.any(func(a): return a.event.scope == "domestic"),true)
	T.assert_equal(entered.any(func(a): return a.event.scope == "international"),true)
	T.assert_equal(career.record_book.has("international"),true)
	T.assert_equal(career.ranking_state.has("isu_world"),true)
	T.assert_equal(result.mid_competition_reload_equal,true)
	T.assert_equal(result.archive_reload_equal,true)
	if assigned:
		var player_results: Array = entered.map(func(archive): return Dictionary(archive.get("player_result",{})))
		var completed_results: Array = player_results.filter(func(row): return float(row.get("total_score",0.0)) > 0.0)
		var domestic_results: Array = entered.filter(func(archive): return archive.event.scope == "domestic").map(func(archive): return Dictionary(archive.get("player_result",{})))
		T.assert_equal(domestic_results.any(func(row): return float(row.get("total_score",0.0)) >= 135.0),true,"a legitimate newcomer success route must show domestic competitiveness without protected results")
		T.assert_equal(domestic_results.any(func(row): return float(row.get("free_score",0.0)) >= 85.0),true,"a successful development route must be capable of a credible junior free skate")
		var international_results: Array = entered.filter(func(archive): return archive.event.scope == "international").map(func(archive): return Dictionary(archive.get("player_result",{})))
		T.assert_equal(international_results.any(func(row): return float(row.get("total_score",0.0)) >= 130.0),true,"the earned international season must contain a competitive complete result, not only an entry token")
	# The planned route may still lose selection and continue through a smaller
	# self-funded international. No acceptance seed receives a protected JGP.
	if not assigned:
		var any_cut: bool = career.competition_archive.any(func(archive): return not bool(archive.get("world_only",false)) and not bool(archive.get("player_qualified",false)))
		T.assert_equal(result.short_cut,any_cut,"whole-journey cut feedback must match actual results, not force a weaker route to miss free skating")
