extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const M = preload("res://tests/fixtures/first_meaning_fixtures.gd")
const Consequence = preload("res://src/simulation/formal_competition_consequence_service.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"formal consequence carries one durable first JGP and Axel state with idempotent receipt","callable":consequence},
		{"name":"failed storage cannot award milestone and retry persists exactly once","callable":storage},
		{"name":"uncertain legacy history records current achievement without inventing first ever","callable":unknown}]

func consequence() -> void:
	var c = F.formal_junior_career(1810)
	var before: Dictionary = c.experience_state.duplicate(true)
	var result: Dictionary = Consequence.apply(c,M.archive())
	T.assert_equal(result.errors,[])
	T.assert_equal(result.career_changes.has("experience_state"),true,"formal result must carry experience in the same transaction")
	if not result.career_changes.has("experience_state"): return
	T.assert_equal(result.career_changes.experience_state.milestones.size(),3)
	T.assert_equal(c.experience_state,before,"preview cannot publish into original career")
	var replay: Dictionary = Consequence.apply(c,result.career_changes.archive)
	T.assert_equal(replay.career_changes.experience_state,result.career_changes.experience_state)
	T.assert_equal(replay.career_changes.ranking_state,result.career_changes.ranking_state)

func storage() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(1811)
	var c = main.active_career.transaction_copy()
	var result: Dictionary = Consequence.apply(c,M.archive())
	if not result.career_changes.has("experience_state"):
		T.assert_equal(false,true,"no milestone candidate to save")
		main.free(); return
	c.experience_state = result.career_changes.experience_state
	var failed: Dictionary = await main._persist_candidate(c,"user://missing-milestone-%d/save.json" % Time.get_ticks_usec())
	T.assert_equal(failed.ok,false)
	T.assert_equal(main.active_career.experience_state.milestones,{})
	var path := "user://milestone-transaction.json"
	T.assert_equal((await main._persist_candidate(c,path)).ok,true)
	var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(path)
	T.assert_equal(loaded.ok,true)
	T.assert_equal(loaded.career.experience_state.milestones.size(),3)
	T.assert_equal(loaded.career.experience_state,main.active_career.experience_state)
	main.free()

func unknown() -> void:
	var c = F.formal_junior_career(1812)
	c.experience_state.milestone_history = {"status":"partial","checked_archive_count":1}
	var result: Dictionary = Consequence.apply(c,M.archive())
	T.assert_equal(result.career_changes.has("experience_state"),true)
	if result.career_changes.has("experience_state"):
		T.assert_equal(result.career_changes.experience_state.milestones.first_formal_3a.certainty,"observed")
