extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const S = preload("res://src/simulation/season_program_service.gd")
const Check = preload("res://src/app/pre_competition_checklist_service.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"transition confirms distinct junior and senior programmes without resetting skills", "callable":confirm_both},
		{"name":"event programme lookup survives disk save and returns a detached copy", "callable":restore},
		{"name":"senior checklist consumes senior mapping while active training programme remains junior", "callable":checklist},
		{"name":"missing second group programme never silently uses the wrong group", "callable":missing_group},
		{"name":"invalid group programme map is rejected without changing career", "callable":invalid_group},
		{"name":"primary programme training progress is not replaced by stale confirmation snapshot", "callable":trained_primary},
		{"name":"changing primary group in retain mode actually adopts that group programme", "callable":retain_promotion},
		{"name":"season confirmation covers secondary drafts but not later unconfirmed edits", "callable":secondary_confirmed},
		{"name":"secondary music revision uses the same familiarity and archive rules as primary editing", "callable":secondary_revision},
	]

func _career():
	var c = F.formal_junior_career(5051)
	c.clock.year = 2021
	c.clock.quarter = 3
	c.athlete.birth_year = 2004
	F.set_competition_strength(c.athlete,95.0)
	return c

func _programs(c,level: String) -> Dictionary:
	var programs := {}
	for segment in ["short","free"]:
		var rules = load("res://src/content/internal_event_rules.gd").for_season(2021,level,segment)
		var proposal = load("res://src/simulation/program_draft_service.gd").propose(c.athlete,segment,rules,{},5051)
		T.assert_equal(proposal.missing,[])
		T.assert_equal(proposal.errors,[])
		if proposal.program == null: return {}
		proposal.program.draft_status = "locked"
		proposal.program.locked_segments.assign([segment])
		programs[segment] = proposal.program.to_dict()
	return programs

func _ready(c) -> bool:
	var api = S.new()
	T.assert_equal(api.has_method("programs_for_event"),true)
	if not api.has_method("programs_for_event"): return false
	var maps := {"junior":_programs(c,"junior"),"senior":_programs(c,"senior")}
	var draft: Dictionary = api.call("preview",c,"2021-22","upgrade",maps.junior,{},"transition",maps)
	T.assert_equal(draft.errors,[])
	if not draft.errors.is_empty(): return false
	T.assert_equal(S.confirm(c,draft,"two-level-programmes").ok,true)
	return true

func _event(id: String) -> Dictionary:
	var c = _career()
	c.season_program_plan.competitive_level = "transition"
	for event in B.for_career(c).calendar.events:
		if event.event_id == id: return event
	T.assert_equal(false,true,"missing event "+id)
	return {}

func confirm_both() -> void:
	var c = _career()
	var skills := JSON.stringify(c.athlete.to_dict())
	if not _ready(c): return
	T.assert_equal(c.season_program_plan.programs_by_level.junior.free.elements.size(),11)
	T.assert_equal(c.season_program_plan.programs_by_level.senior.free.elements.size(),12)
	T.assert_equal(JSON.stringify(c.athlete.to_dict()),skills)
	T.assert_equal(c.season_program_plan.competitive_level,"transition")

func restore() -> void:
	var c = _career()
	if not _ready(c): return
	var saved := Save.save(c,"user://two-level-programmes.json")
	T.assert_equal(saved.ok,true,str(saved.errors))
	if not saved.ok: return
	var read := Save.load_save("user://two-level-programmes.json")
	T.assert_equal(read.ok,true)
	if not read.ok: return
	var api = S.new()
	var senior: Dictionary = api.programs_for_event(read.career,_event("isu_gpusa2021"))
	var junior: Dictionary = api.programs_for_event(read.career,_event("cn_junior_u_series_2021_stage_2"))
	T.assert_equal(senior.free.elements.size(),12)
	T.assert_equal(junior.free.elements.size(),11)
	senior.free.elements.clear()
	T.assert_equal(api.programs_for_event(read.career,_event("isu_gpusa2021")).free.elements.size(),12)

func checklist() -> void:
	var c = _career()
	if not _ready(c): return
	c.active_programs = c.season_program_plan.programs_by_level.junior.duplicate(true)
	var before := JSON.stringify(c.to_dict())
	var result := Check.inspect(c,_event("isu_gpusa2021"))
	T.assert_equal(result.ready,true,str(result.items))
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func missing_group() -> void:
	var c = _career()
	if not _ready(c): return
	c.season_program_plan.programs_by_level.erase("senior")
	var api = S.new()
	T.assert_equal(api.programs_for_event(c,_event("isu_gpusa2021")),{})
	T.assert_equal(Check.inspect(c,_event("isu_gpusa2021")).ready,false)

func invalid_group() -> void:
	var c = _career()
	if not _ready(c): return
	var before := JSON.stringify(c.to_dict())
	var api = S.new()
	var bad: Dictionary = api.call("preview",c,"2021-22","upgrade",c.active_programs,{},"transition",{"invalid":_programs(c,"senior")})
	T.assert_equal(bad.errors.is_empty(),false)
	T.assert_equal(S.confirm(c,bad,"invalid-level-map").ok,false)
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func trained_primary() -> void:
	var c = _career()
	if not _ready(c): return
	var second := JSON.stringify(c.season_program_plan.programs_by_level.senior)
	c.active_programs.free.whole_run_familiarity = 82.5
	var api = S.new()
	T.assert_equal(api.programs_for_event(c,_event("cn_junior_u_series_2021_stage_2")).free.whole_run_familiarity,82.5)
	T.assert_equal(JSON.stringify(c.season_program_plan.programs_by_level.senior),second)

func retain_promotion() -> void:
	var c = _career()
	if not _ready(c): return
	var junior: Dictionary = c.active_programs.duplicate(true)
	var senior: Dictionary = c.season_program_plan.programs_by_level.senior
	var draft := S.preview(c,"2021-22","retain",senior,{},"senior",c.season_program_plan.programs_by_level)
	T.assert_equal(S.confirm(c,draft,"promote-primary").ok,true)
	T.assert_equal(c.active_programs.free.elements.size(),12)
	# Confirming both groups may lock the previously primary draft. No other
	# programme field (content, identity, familiarity or revision) may change.
	for segment in junior:
		junior[segment].draft_status = "locked"
		junior[segment].locked_segments = [segment]
	T.assert_equal(c.season_program_plan.programs_by_level.junior,junior)
	T.assert_equal(S.programs_for_event(c,_event("isu_gpusa2021")).free.elements.size(),12)

func secondary_confirmed() -> void:
	var c = _career()
	var maps := {"junior":_programs(c,"junior"),"senior":_programs(c,"senior")}
	for segment in ["short","free"]:
		maps.senior[segment].draft_status = "draft"
		maps.senior[segment].locked_segments = []
	var draft := S.preview(c,"2021-22","upgrade",maps.junior,{},"transition",maps)
	T.assert_equal(S.confirm(c,draft,"confirm-secondary-draft").ok,true)
	T.assert_equal(Check.inspect(c,_event("isu_gpusa2021")).ready,true)
	var saved = load("res://src/domain/skating_program.gd").from_dict(c.season_program_plan.programs_by_level.senior.free)
	var revision = load("res://src/simulation/program_draft_service.gd").save_draft(saved,saved)
	c.season_program_plan.programs_by_level.senior.free = revision.program.to_dict()
	T.assert_equal(Check.inspect(c,_event("isu_gpusa2021")).ready,false,"editing returns the secondary programme to unconfirmed draft")

func secondary_revision() -> void:
	var c = _career()
	if not _ready(c): return
	var previous: Dictionary = c.season_program_plan.programs_by_level.senior.free.duplicate(true)
	previous.whole_run_familiarity = 75.0
	c.season_program_plan.programs_by_level.senior.free = previous.duplicate(true)
	var maps: Dictionary = c.season_program_plan.programs_by_level.duplicate(true)
	maps.senior.free.music = {"title":"A new senior performance"}
	var expected = load("res://src/simulation/program_draft_service.gd").save_draft(load("res://src/domain/skating_program.gd").from_dict(previous),load("res://src/domain/skating_program.gd").from_dict(maps.senior.free))
	T.assert_equal(expected.errors,[])
	var count: int = c.program_archive.size()
	var draft := S.preview(c,"2021-22","upgrade",c.active_programs,{},"transition",maps)
	T.assert_equal(S.confirm(c,draft,"revise-secondary").ok,true)
	T.assert_equal(c.season_program_plan.programs_by_level.senior.free.whole_run_familiarity,expected.program.whole_run_familiarity)
	T.assert_equal(c.season_program_plan.programs_by_level.senior.free.revision,expected.program.revision)
	T.assert_equal(c.program_archive.size(),count+1)
