extends RefCounted

var suite = preload("res://tests/integration/test_first_international_season.gd").new()

func cases() -> Array[Dictionary]:
	return [{"name":"public assigned route recheck without external save readers", "callable":suite.test_assigned}]
