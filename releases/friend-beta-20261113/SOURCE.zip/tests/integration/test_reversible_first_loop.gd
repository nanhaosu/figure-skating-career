extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name": "first career loop remains reversible until explicit commits", "callable": test_reversible_loop}]

func test_reversible_loop() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	var service = load("res://src/persistence/browser_save_service.gd").new("user://reversible-loop-%d" % Time.get_ticks_usec())
	var career = F.starting_career(96001)
	T.assert_equal((await service.save_slot("manual-1", career)).ok, true)
	main.browser_saves = service
	main.show_main_menu()
	T.assert_equal(main.get_node("%MainMenuPanel").visible, true)
	await main._on_menu_continue_requested("manual-1")
	T.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	var committed := JSON.stringify(main.active_career.to_dict())
	for section in ["records", "relationships"]:
		main.open_route(section, {}, main.screen_router.current())
		main.back_route()
		T.assert_equal(JSON.stringify(main.active_career.to_dict()), committed)
	main.open_program_editor("short")
	T.assert_equal(main.get_node("%ProgramEditorPanel").get_node("%CloseButton").text, "返回生涯主页")
	main.get_node("%ProgramEditorPanel").program.music.title = "只看不保存"
	main.get_node("%ProgramEditorPanel").discard_changes()
	T.assert_equal(JSON.stringify(main.active_career.to_dict()), committed)
	T.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	await main.exit_to_main_menu()
	T.assert_equal(main.get_node("%MainMenuPanel").visible, true)
	await main._on_menu_continue_requested("manual-1")
	T.assert_equal(JSON.stringify(main.active_career.to_dict()), committed)
	main.free()
