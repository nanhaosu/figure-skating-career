extends RefCounted
const T = preload("res://tests/test_support.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const Entry = preload("res://src/simulation/entry_application_service.gd")
const Trials = preload("res://src/simulation/beijing_trial_service.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"a medically prohibited trial opens medical handling before impossible programme replacement", "callable":medical_before_programme},
		{"name":"domestic schedule offers one Beijing series choice and actual entry confirms all five", "callable":one_choice},
		{"name":"declining Beijing series once declines all five without preventing NPC competition", "callable":decline_once},
		{"name":"withdrawing one trial retains series enrollment and other four entries", "callable":single_withdrawal},
		{"name":"trial check-in revalidates senior age without erasing the accepted series receipt", "callable":age_revalidation},
		{"name":"series enrollment automatically enables dated progression at a verified quarter boundary", "callable":automatic_dates},
		{"name":"legacy partial period is preserved for December trials then completed once before January dated mode", "callable":legacy_partial},
	]

func medical_before_programme() -> void:
	var c = _career()
	T.assert_equal(Trials.enroll(c,"beijing2022_women_trials","medical-check-in").ok,true)
	c.condition_state.injuries = [{"id":"trial-major-1","site":"ankle","severity":0.85,"remaining_quarters":2,"status":"active"}]
	var chosen: Dictionary = load("res://src/simulation/rehabilitation_service.gd").choose(c,"trial-major-1","full_rehabilitation","trial-treatment")
	T.assert_equal(chosen.ok,true)
	var functions = load("res://src/simulation/athlete_function_service.gd")
	T.assert_equal(functions.action_constraints(c,{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":1}]}).allowed,false)
	T.assert_equal(load("res://src/simulation/dated_training_service.gd").activate(c).ok,true)
	c.competition_timeline.date = "2021-12-17" # controlled check-in boundary, not natural-growth evidence
	c.competition_timeline.origin_date = "2021-12-17"
	c.competition_timeline.quarter_progress = 78
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.event_id == Trials.event_ids()[0])
	var programmes := JSON.stringify(c.season_program_plan)
	var result: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(c,bundle,func(_candidate):return true)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.stop_node.get("kind"),"medical_restriction","a treatment prohibition cannot be resolved by re-arranging jumps")
	T.assert_equal(result.stop_node.get("event_id"),Trials.event_ids()[0])
	T.assert_equal(JSON.stringify(result.career.season_program_plan),programmes,"medical handling must not rewrite either programme")

func _career():
	return load("res://tests/simulation/test_beijing_trial_service.gd").new()._entrant()

func one_choice() -> void:
	var c = _career()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	var offered: Array = Entry.domestic_schedule_options(c,bundle).filter(func(row):return Trials.event_ids().has(row.event_id))
	T.assert_equal(offered.size(),1,"five races must not require five registration clicks")
	var money := float(c.athlete.resources.money)
	var result: Dictionary = Commands.apply(c,{"type":"apply_entry","event_id":Trials.event_ids()[0],"route_id":"enter"})
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	T.assert_equal(result.career.beijing_trial_series.player_choice,"enrolled")
	T.assert_equal(float(result.career.athlete.resources.money),money,"routine series registration must not charge five upgrade purchases")
	for id in Trials.event_ids(): T.assert_equal(result.career.season_state.entry_plan.entries[id].status,"confirmed")

func decline_once() -> void:
	var c = _career()
	var result: Dictionary = Commands.apply(c,{"type":"apply_entry","event_id":Trials.event_ids()[0],"route_id":"skip"})
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	T.assert_equal(result.career.beijing_trial_series.player_choice,"declined")
	T.assert_equal(result.career.beijing_trial_series.entrant_ids.has("player"),false)
	T.assert_equal(result.career.beijing_trial_series.entrant_ids.size()>0,true)
	for id in Trials.event_ids(): T.assert_equal(result.career.season_state.entry_plan.entries[id].status,"declined")
	var replay: Dictionary = Commands.apply(result.career,{"type":"apply_entry","event_id":Trials.event_ids()[0],"route_id":"skip"})
	T.assert_equal(replay.ok,true)
	if replay.ok: T.assert_equal(replay.career.to_dict(),result.career.to_dict())

func single_withdrawal() -> void:
	var c = _career()
	T.assert_equal(Trials.enroll(c,"beijing2022_women_trials","withdraw-case").ok,true)
	var result: Dictionary = Commands.apply(c,{"type":"withdraw_entry","event_id":Trials.event_ids()[1]})
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	T.assert_equal(result.career.beijing_trial_series.player_choice,"enrolled")
	T.assert_equal(result.career.beijing_trial_series.withdrawals.get("player",[]),[Trials.event_ids()[1]])
	for index in [0,2,3,4]: T.assert_equal(result.career.season_state.entry_plan.entries[Trials.event_ids()[index]].status,"confirmed")

func age_revalidation() -> void:
	var c = _career()
	T.assert_equal(Trials.enroll(c,"beijing2022_women_trials","age-correction").ok,true)
	c.athlete.birth_year = 2008;c.athlete.birth_date = {}
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	var event: Dictionary = bundle.calendar.events.filter(func(e):return e.event_id == Trials.event_ids()[0])[0]
	var gate: Dictionary = Entry.current_eligibility(c,event,bundle,true)
	T.assert_equal(gate.eligible,false,"domestic scope must not bypass the explicitly adopted senior trial age")
	T.assert_equal(c.season_state.entry_plan.entries[event.event_id].status,"confirmed","revalidation stops at a visible node, not silent history deletion")

func automatic_dates() -> void:
	var c = _career()
	c.condition_state.growth_phase = "adapted"
	var selected: Dictionary = Commands.apply(c,{"type":"apply_domestic_schedule","event_ids":[Trials.event_ids()[0]]})
	T.assert_equal(selected.ok,true,selected.get("error",""))
	if not selected.ok: return
	c = selected.career
	var shares: Dictionary = load("res://tests/fixtures.gd").percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.rest = 100
	c.last_generated_plan = load("res://src/domain/training_plan.gd").create(shares).plan.to_dict()
	var before: Dictionary = c.to_dict()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	var service = load("res://src/simulation/season_progression_service.gd")
	var denied: Dictionary = service.advance_to_next_node(c,bundle,func(_candidate):return false)
	T.assert_equal(denied.errors,["save_failed"])
	T.assert_equal(denied.career.to_dict()==before,true)
	var result: Dictionary = service.advance_to_next_node(c,bundle,func(_candidate):return true)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.career.competition_timeline.mode,"dated","player should not need a hidden developer command to activate the real five-race timeline")
	T.assert_equal(result.career.competition_timeline.date,"2021-12-17")
	T.assert_equal(result.stop_node.get("event_id"),Trials.event_ids()[0])
	T.assert_equal(c.to_dict()==before,true)

func legacy_partial() -> void:
	var c = _career();c.condition_state.growth_phase = "adapted"
	var shares: Dictionary = load("res://tests/fixtures.gd").percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.rest = 95;shares.jump_toe_loop = 5
	var built: Dictionary = load("res://src/domain/training_plan.gd").create(shares,{"toe_loop":1})
	T.assert_equal(built.errors,[])
	if built.plan == null: return
	var plan = built.plan
	c.training_period_state.stage_limit = 1
	load("res://src/simulation/career_simulator.gd").advance_quarter(c,plan,load("res://src/content/catalog_repository.gd").load_catalog())
	c.training_period_state.erase("stage_limit")
	c.last_generated_plan = plan.to_dict()
	T.assert_equal(c.training_period_state.has("stage_checkpoint"),true,"fixture must be an actually settled partial period")
	if not c.training_period_state.has("stage_checkpoint"): return
	T.assert_equal(Trials.enroll(c,"beijing2022_women_trials","partial-legacy").ok,true)
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return Trials.event_ids().has(event.event_id))
	var service = load("res://src/simulation/season_progression_service.gd")
	var result: Dictionary = service.advance_to_next_node(c,bundle,func(_candidate):return true)
	T.assert_equal(result.errors,[],"legacy checkpoint cannot be trapped by mandatory early dated activation")
	if not result.errors.is_empty(): return
	T.assert_equal(result.stop_node.get("event_id"),Trials.event_ids()[0])
	T.assert_equal(result.career.training_period_state,c.training_period_state,"do not replay the settled stage before December check-in")
	# Complete protocol fixtures isolate the transition after both December
	# starts; the actual five-SPFS route is exercised in the simulation suite.
	var protocols = load("res://tests/simulation/test_beijing_dispatch.gd").new()._controlled_ready()
	var after = result.career
	for archive in protocols.competition_archive:
		if archive.get("event_id") in Trials.event_ids().slice(0,2): after.competition_archive.append(archive)
	var january: Dictionary = service.advance_to_next_node(after,bundle,func(_candidate):return true)
	T.assert_equal(january.errors,[])
	T.assert_equal(january.career.clock.to_dict(),{"year":2022,"quarter":1})
	T.assert_equal(january.career.competition_timeline.mode,"dated")
	T.assert_equal(january.career.competition_timeline.date,"2021-12-31")
	T.assert_equal(january.career.training_period_state.has("stage_checkpoint"),false)
	T.assert_equal(january.stop_node.get("event_id"),Trials.event_ids()[2])
