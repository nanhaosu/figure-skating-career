extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"calibration respects a calendar gate instead of training behind its window","callable":test_calendar_gate},{"name":"calibration counts executed quarters independently of optional curriculum summaries","callable":test_quarter_count},{"name":"continuous training can durably resolve an event before the first stage","callable":test_fresh_event},{"name":"calibration waits for the real event continuation before advancing calendar","callable":test_driver_waits}]

func test_calendar_gate() -> void:
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	driver.main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(driver.main)
	driver.main.browser_saves = load("res://scripts/experience_memory_save.gd").new()
	driver.main.autosave_path = driver.main.browser_saves.slot_path("autosave")
	driver.main.active_career = load("res://tests/fixtures.gd").formal_junior_career(1790)
	driver.main.active_career.season_program_plan.season_id = "2018-19"
	driver.main.active_career.internal_invitation_state.status = "completed"
	driver.main._open_career_home()
	var before: Dictionary = driver.main.active_career.to_dict()
	await driver._train_quarter()
	T.assert_equal(driver.main.quarter_panel.event_dialog.visible,false,"calendar decisions must not run a hidden training period")
	T.assert_equal(driver.main.active_career.clock.to_dict(),before.clock)
	T.assert_equal(driver.main.active_career.training_period_state,before.training_period_state)
	driver.main.free()

func test_quarter_count() -> void:
	var career = load("res://tests/fixtures.gd").starting_career(1790)
	career.event_ledger.append_array([
		{"kind":"quarter_advanced","from_clock":{"year":2018,"quarter":3}},
		{"kind":"quarter_advanced","from_clock":{"year":2018,"quarter":4}},
		{"kind":"quarter_advanced","from_clock":{"year":2018,"quarter":4}},
		{"kind":"quarter_advanced","from_clock":{"year":2013,"quarter":4}},
		{"kind":"coach_curriculum","clock":{"year":2019,"quarter":1},"executed_plan":{}}])
	var result: Dictionary = load("res://scripts/calibrate_two_season_experience.gd").new()._report(career)
	T.assert_equal(result.training_quarters,2,"calendar/staged curricula are real training even without optional coach summary receipts")

func test_driver_waits() -> void:
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	driver.main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(driver.main)
	driver.main.browser_saves = load("res://scripts/experience_memory_save.gd").new()
	driver.main.autosave_path = driver.main.browser_saves.slot_path("autosave")
	var career = load("res://tests/fixtures.gd").starting_career(1790)
	career.internal_invitation_state.status = "completed"
	career.season_state.season_history = {"2013-14":{"season":{},"record_book":{},"ranking_state":{},"clock":{}}}
	career.athlete.body.acute_fatigue = 20.0
	driver.main.active_career = career
	await driver._train_quarter()
	T.assert_equal(career.memories.any(func(m):return m.get("signature") == "fatigue_breakdown"),true,"real event response must succeed before checking its async continuation")
	T.assert_equal(driver.main.quarter_panel._continuous_running,false,"calendar must not race an unfinished event continuation")
	while driver.main.quarter_panel._continuous_running: await Engine.get_main_loop().process_frame
	driver.main.free()

func test_fresh_event() -> void:
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = load("res://tests/fixtures.gd").starting_career(1790)
	career.internal_invitation_state.status = "completed"
	career.season_state.season_history = {"2013-14":{"season":{},"record_book":{},"ranking_state":{},"clock":{}}}
	career.athlete.body.acute_fatigue = 20.0
	panel.setup(career,load("res://src/content/catalog_repository.gd").load_catalog())
	var repo = load("res://src/persistence/save_repository.gd")
	var stage_rest: Array = []
	panel.persist = func(candidate):
		if candidate.training_period_state.has("stage_checkpoint"):
			stage_rest.append(candidate.training_period_state.stage_checkpoint.plan.shares.rest)
		return repo.save(candidate,"user://fresh-continuous-event.json")
	await panel.continue_training()
	T.assert_equal(panel.event_dialog.visible,true,"a real fatigue choice must be reached")
	await panel.resolve_event_choice("rest_now")
	T.assert_equal(career.memories.any(func(m):return m.get("signature") == "fatigue_breakdown" and m.get("choice_id") == "rest_now"),true,panel.plan_error_label.text)
	T.assert_equal(stage_rest.is_empty(),false,"the chosen rest plan must actually reach training")
	if not stage_rest.is_empty(): T.assert_equal(int(stage_rest[0]) >= 40,true,"automatic continuation cannot silently replace the chosen recovery allocation")
	var restored: Dictionary = repo.load_save("user://fresh-continuous-event.json")
	T.assert_equal(restored.ok,true,"the response must be a valid real disk save")
	if restored.ok: T.assert_equal(restored.career.memories.any(func(m):return m.get("signature") == "fatigue_breakdown"),true)
	panel.free()
