extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Sim = preload("res://src/simulation/career_simulator.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"accepted safer coaching does not trigger obsolete desired load warning","callable":accepted_load},{"name":"actual completed coaching records gap rotation once","callable":completed},
		{"name":"coaching partial save reload matches uninterrupted state","callable":resumed},
		{"name":"failed save retry neither consumes coaching memory nor duplicates learning","callable":failed_save}]

func accepted_load() -> void:
	var c = F.starting(73404)
	var desired = Coach.build(c,Intent.create("accept").intent).plan
	# Concentrated 45% request, approved down to distributed 40% actual work.
	desired._shares.skating_foundation -= 15
	desired._shares.jump_toe_loop += 15
	var approved = load("res://src/domain/training_plan.gd").from_dict(desired.to_dict())
	approved._shares.jump_toe_loop -= 5
	approved._shares.rest += 5
	var proposal = load("res://src/domain/plan_proposal.gd").create(desired)
	proposal.executed = approved
	proposal.approved = approved
	proposal.status = "resolved"
	var conflicts: Array = load("res://src/simulation/conflict_scanner.gd").scan(c,proposal)
	T.assert_equal(conflicts.any(func(row): return row.signature == "jump_load_conflict"),false,"risk warning must use the actually accepted curriculum")

func completed() -> void:
	var c = F.triple_gap(73401)
	var plan = Coach.build(c,Intent.create("accept").intent).plan
	Sim.advance_quarter(c,plan,Catalog.load_catalog())
	T.assert_equal(c.coach_training_state.completed_periods,1)
	T.assert_equal(c.coach_training_state.last_practiced.get("toe_loop",0),1)
	T.assert_equal(c.history.any(func(row): return row.get("category") == "coach_training"),true)
	var saved: Dictionary = load("res://src/persistence/save_repository.gd").save(c,"user://coaching-complete.json")
	T.assert_equal(saved.ok,true,str(saved.get("errors",[])))

func resumed() -> void:
	var c = F.starting(73402)
	c.condition_state.psychology.stress = 30.0
	var plan = Coach.build(c,Intent.create("accept").intent).plan
	var whole = c.transaction_copy()
	Sim.advance_quarter(whole,plan,Catalog.load_catalog())
	c.training_period_state.stage_limit = 1
	Sim.advance_quarter(c,plan,Catalog.load_catalog())
	T.assert_equal(c.coach_training_state.completed_periods,0)
	var repo = load("res://src/persistence/save_repository.gd")
	var saved: Dictionary = repo.save(c,"user://coaching-partial.json")
	T.assert_equal(saved.ok,true,str(saved.get("errors",[])))
	if not saved.ok: return
	var restored: Dictionary = repo.load_save("user://coaching-partial.json")
	T.assert_equal(restored.ok,true)
	if not restored.ok: return
	var next = restored.career
	next.training_period_state.stage_limit = 3
	Sim.advance_quarter(next,plan,Catalog.load_catalog())
	T.assert_equal(next.coach_training_state,whole.coach_training_state)
	T.assert_equal(next.condition_state.psychology,whole.condition_state.psychology)
	T.assert_equal(next.athlete.jumps.toe_loop.attempt_evidence,whole.athlete.jumps.toe_loop.attempt_evidence)
	for key in ["single","double","triple","quad"]:
		T.assert_equal(absf(float(next.athlete.jumps.toe_loop.proficiency[key])-float(whole.athlete.jumps.toe_loop.proficiency[key]))<0.000001,true,"JSON precision must not change gameplay learning")
	T.assert_equal(next.coach_training_state.completed_periods,1)

func failed_save() -> void:
	var c = load("res://tests/integration/test_training_stage_transactions.gd").new().prepared()
	var command := {"type":"advance_quarter","stage_limit":1,"bundle":load("res://src/content/season_bundle_repository.gd").for_career(c)}
	var original := JSON.stringify(c.to_dict())
	var commands = load("res://src/simulation/career_command_service.gd")
	var first: Dictionary = commands.apply(c,command)
	T.assert_equal(first.ok,true,str(first.get("error","")))
	if not first.ok: return
	var failed: Dictionary = load("res://src/persistence/save_repository.gd").save(first.career,"user://absent-coach-directory-73403/save.json")
	T.assert_equal(failed.ok,false)
	T.assert_equal(JSON.stringify(c.to_dict()),original)
	var retry: Dictionary = commands.apply(c,command)
	T.assert_equal(retry.ok,true)
	if retry.ok: T.assert_equal(retry.career.to_dict(),first.career.to_dict())
