extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"continuous training cannot cross an unclosed season and skip next season entries","callable":test_season_close_stop},
		{"name":"continuous training settles live Worlds quota event before crossing its quarter","callable":test_live_background_stop},
		{"name":"Main season transition durably archives the old season without another training stage","callable":test_main_transition},
		{"name":"major medical decision blocks continuous training before persistence","callable":test_medical_stop},
		{"name":"continuous run can stop at a saved stage without rewinding","callable":test_pause},
		{"name":"failed stage persistence cannot publish training progress","callable":test_save_failure}]

func test_live_background_stop() -> void:
	var c = F.formal_junior_career(1795)
	c.clock.year = 2021
	c.clock.quarter = 1
	c.internal_invitation_state.status = "completed"
	c.season_program_plan.season_id = "2020-21"
	c.season_program_plan.status = "confirmed"
	c.season_state = {"season_id":"2020-21","season_history":{},"entry_plan":{},"event_statuses":{},"qualification_state":{}}
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(c)
	var before := JSON.stringify(c.to_dict())
	var gate := preload("res://src/simulation/season_progression_service.gd").quarter_gate(c,bundle)
	T.assert_equal(gate.get("kind"),"season_transition","live background Worlds must settle before training makes it look like missing legacy history")
	T.assert_equal(gate.get("event_id"),"isu_wc2021")
	T.assert_equal(JSON.stringify(c.to_dict()),before,"inspection must not manufacture a result or country quota")
	# A genuinely past legacy event must remain unexamined, never backfilled.
	c.clock.quarter = 3
	var historical := preload("res://src/simulation/season_progression_service.gd")._background_bundle(c,bundle)
	var worlds: Array = historical.calendar.events.filter(func(event):return event.event_id == "isu_wc2021")
	T.assert_equal(worlds.size(),1)
	if worlds.size() == 1: T.assert_equal(worlds[0].background_no_retroactive,true)

func test_main_transition() -> void:
	var c = F.formal_junior_career(1794)
	c.clock.year = 2021
	c.clock.quarter = 3
	c.season_program_plan.season_id = "2020-21"
	c.season_state = {"season_id":"2020-21","season_history":{},"entry_plan":{},"event_statuses":{},"qualification_state":{}}
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(c)
	var world := preload("res://src/simulation/season_progression_service.gd")._background_bundle(c,bundle)
	# Controlled already-settled season boundary; no scores or eligibility are
	# fabricated. The complete actual race path is tested independently.
	for event in preload("res://src/content/season_calendar_repository.gd").playable_events(world.calendar):
		c.event_ledger.append({"kind":"season_event","season_id":"2020-21","event_id":event.event_id,"clock":c.clock.to_dict()})
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = c
	main.autosave_path = "user://season-transition-ui.json"
	var rng_before: int = c.rng_step
	var stage_count: int = c.event_ledger.filter(func(e):return e.kind == "training_stage_committed").size()
	await main._present_season_node({"kind":"season_transition"})
	T.assert_equal(main.active_career.clock.to_dict(),{"year":2021,"quarter":3})
	T.assert_equal(main.active_career.season_state.season_history.has("2020-21"),true)
	T.assert_equal(main.active_career.season_state.season_id,"2021-22")
	T.assert_equal(main.active_career.rng_step,rng_before)
	T.assert_equal(main.active_career.event_ledger.filter(func(e):return e.kind == "training_stage_committed").size(),stage_count)
	var read := preload("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
	T.assert_equal(read.ok,true,str(read.errors))
	if read.ok: T.assert_equal(read.career.season_state.season_history.has("2020-21"),true)
	main.free()

func test_season_close_stop() -> void:
	var c = F.formal_junior_career(1793)
	c.clock.year = 2021
	c.clock.quarter = 3
	c.season_program_plan.season_id = "2020-21"
	c.season_state = {"season_id":"2020-21","season_history":{},"entry_plan":{},"event_statuses":{},"qualification_state":{}}
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(c)
	var gate := preload("res://src/simulation/season_progression_service.gd").quarter_gate(c,bundle)
	T.assert_equal(gate.get("kind"),"season_transition","end-of-season must be settled before any new training")
	var before := JSON.stringify(c.to_dict())
	var saves := [0]
	var result: Dictionary = await load("res://src/simulation/focus_training_run_service.gd").advance(c,load("res://src/domain/training_intent.gd").create("accept").intent,func(_candidate):saves[0]+=1;return true,Callable())
	T.assert_equal(result.stop_reason,"pending_action")
	T.assert_equal(result.pending_action.get("kind"),"season_transition")
	T.assert_equal(result.elapsed_weeks,0)
	T.assert_equal(saves[0],0,"season closure must not secretly train another stage")
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func test_medical_stop() -> void:
	var career = F.starting_career(1792)
	career.internal_invitation_state.status = "completed"
	career.condition_state.pending_decision = {"id":"major","kind":"major_injury"}
	var saves := [0]
	var result: Dictionary = await load("res://src/simulation/focus_training_run_service.gd").advance(career,load("res://src/domain/training_intent.gd").create("accept").intent,func(_candidate): saves[0]+=1; return true,Callable())
	T.assert_equal(result.stop_reason,"pending_action")
	T.assert_equal(result.elapsed_weeks,0)
	T.assert_equal(saves[0],0)

func test_pause() -> void:
	T.assert_equal(FileAccess.file_exists("res://src/simulation/focus_training_run_service.gd"),true)
	if not FileAccess.file_exists("res://src/simulation/focus_training_run_service.gd"): return
	var career = F.starting_career(1790)
	career.internal_invitation_state.status = "completed"
	var count := [0]
	var service = load("res://src/simulation/focus_training_run_service.gd")
	var result: Dictionary = await service.advance(career,load("res://src/domain/training_intent.gd").create("accept").intent,func(_candidate): count[0]+=1; return true,func(): return count[0]>=1)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.stop_reason,"user_pause")
	T.assert_equal(int(result.career.training_period_state.weeks_elapsed),3)
	T.assert_equal(career.training_period_state,{})

func test_save_failure() -> void:
	if not FileAccess.file_exists("res://src/simulation/focus_training_run_service.gd"): return
	var career = F.starting_career(1791)
	career.internal_invitation_state.status = "completed"
	var before := JSON.stringify(career.transaction_copy().to_dict())
	var result: Dictionary = await load("res://src/simulation/focus_training_run_service.gd").advance(career,load("res://src/domain/training_intent.gd").create("accept").intent,func(_candidate): return false,Callable())
	T.assert_equal(result.stop_reason,"save_failed")
	T.assert_equal(JSON.stringify(result.career.to_dict()) == before,true,"failed save must retain the normalized original, not executed stage history")
