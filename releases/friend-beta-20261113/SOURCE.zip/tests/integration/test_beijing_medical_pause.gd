extends RefCounted
const T = preload("res://tests/test_support.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const Entry = preload("res://src/simulation/entry_application_service.gd")
const Trials = preload("res://src/simulation/beijing_trial_service.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"past trial medical pause is unavailable and rejected atomically before producing an invalid save", "callable":late_request},
		{"name":"explicit medical series pause preserves other entries and survives save replay", "callable":choice_and_save},
		{"name":"accepted medical pause automatically proposes later unavailable trial without a repeated prompt and rolls back failed save", "callable":coordinator},
		{"name":"medical pause never blocks recovery or silently covers a new unrelated injury", "callable":recovery},
		{"name":"medical pause advances actual recovery time and simulates the absent-player trial without another medical prompt", "callable":world_continuation},
		{"name":"actual season option signal commits medical pause through Main and native autosave", "callable":main_ui}]

func world_continuation() -> void:
	var chosen := _pause(_career())
	T.assert_equal(chosen.ok,true)
	if not chosen.ok: return
	var c = chosen.career
	c.competition_timeline.date = "2021-12-29"
	c.competition_timeline.origin_date = "2021-12-29"
	c.competition_timeline.quarter_progress = 90
	c.event_ledger.append({"kind":"season_event","season_id":"2021-22","event_id":"isu_olympic_qualifier_nebelhorn_2021","outcome":"unexamined","reason":"controlled unavailable prior source, no invented results"})
	var shares: Dictionary = load("res://tests/fixtures.gd").percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.rest = 100
	c.last_generated_plan = load("res://src/domain/training_plan.gd").create(shares).plan.to_dict()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	var event_id: String = Trials.event_ids()[1]
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.event_id == event_id)
	var accepted: Array = []
	var world_candidates: Array = []
	var result: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(c,bundle,func(candidate):
		if candidate.competition_archive.any(func(a):return a.get("event_id") == event_id):
			world_candidates.append(candidate)
			return false # isolate a deliberate failure at the next actual archive commit
		accepted.append(candidate)
		return true)
	T.assert_equal(result.errors,["save_failed"])
	T.assert_equal(accepted.size() >= 2,true,"medical withdrawal and the actual elapsed recovery day must both commit")
	T.assert_equal(world_candidates.size(),1,"must reach actual NPC competition, not stop at another medical confirmation")
	T.assert_equal(result.career.competition_timeline.date,"2021-12-30")
	T.assert_equal(result.career.condition_state.rehabilitation["pause-injury"].dated_period_fraction,{"n":1,"d":92})
	T.assert_equal(result.career.condition_state.rehabilitation["pause-injury"].elapsed_quarters,0)
	if world_candidates.size() != 1: return
	var candidate = world_candidates[0]
	var archive: Dictionary = candidate.competition_archive.filter(func(a):return a.get("event_id") == event_id)[0]
	T.assert_equal(archive.status,"complete")
	T.assert_equal(archive.short_results.has("player"),false)
	T.assert_equal(archive.free_results.has("player"),false)
	T.assert_equal(archive.short_results.size() > 0 and archive.free_results.size() > 0,true)
	T.assert_equal(Save.save(candidate,"user://beijing-medical-world-continuation.json").ok,true)
	var read := Save.load_save("user://beijing-medical-world-continuation.json")
	T.assert_equal(read.ok,true)
	if read.ok: T.assert_equal(read.career.beijing_trial_series,candidate.beijing_trial_series)

func late_request() -> void:
	var c = _career()
	c.competition_timeline.date = "2021-12-19"
	c.competition_timeline.origin_date = "2021-12-19"
	c.competition_timeline.quarter_progress = 80
	var before := JSON.stringify(c.to_dict())
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event({"event_id":Trials.event_ids()[0],"ruleset_season_start_year":2021,"competition_level":"senior"}).event
	T.assert_equal(Entry.options(c,event,{}).any(func(row):return row.id == "medical_pause" and row.available),false)
	T.assert_equal(_pause(c).ok,false,"reject at the command boundary, not later as a save error")
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func main_ui() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.browser_saves = load("res://src/persistence/browser_save_service.gd").new("user://beijing-medical-ui-slots")
	main.autosave_path = main.browser_saves.slot_path("autosave")
	main.save_path = main.browser_saves.slot_path("manual-1")
	main.active_career = _career()
	main._open_career_home()
	var panel = main.season_overview_panel
	panel.entry_adjustment_requested.emit(Trials.event_ids()[0])
	var index: int = panel._adjustment_ids.find("medical_pause")
	print("MEDICAL_UI_DIAGNOSTIC event_present=",panel._events_by_id.has(Trials.event_ids()[0])," route_ids=",panel._adjustment_ids," message=",main.get_node("%GlobalMessage").text)
	T.assert_equal(index >= 0,true,"real existing options dialog must expose the new route")
	if index < 0: main.free();return
	T.assert_equal(panel.adjustment_option.is_item_disabled(index),false)
	panel.adjustment_option.select(index)
	panel.adjustment_dialog.confirmed.emit()
	for frame in 600:
		if main.active_career.selection_state.applications.has(Trials.event_ids()[0]+":medical_pause:choice"): break
		await Engine.get_main_loop().process_frame
	T.assert_equal(main.active_career.season_state.entry_plan.entries[Trials.event_ids()[0]].status,"declined",main.get_node("%GlobalMessage").text)
	var read := Save.load_save(main.autosave_path)
	T.assert_equal(read.ok,true,str(read.get("errors",[])))
	if read.ok: T.assert_equal(read.career.beijing_trial_series,main.active_career.beijing_trial_series)
	main.free()

func _career():
	var c = load("res://tests/integration/test_beijing_trial_enrollment_flow.gd").new()._career()
	T.assert_equal(Trials.enroll(c,"beijing2022_women_trials","medical-pause-enroll").ok,true)
	c.condition_state.injuries = [{"id":"pause-injury","site":"ankle","severity":0.85,"remaining_quarters":2,"status":"active"}]
	T.assert_equal(load("res://src/simulation/rehabilitation_service.gd").choose(c,"pause-injury","full_rehabilitation","pause-treatment").ok,true)
	T.assert_equal(load("res://src/simulation/dated_training_service.gd").activate(c).ok,true)
	c.competition_timeline.date = "2021-12-17" # controlled boundary, not a natural injury claim
	c.competition_timeline.origin_date = "2021-12-17"
	c.competition_timeline.quarter_progress = 78
	return c

func _pause(c) -> Dictionary:
	return Commands.apply(c,{"type":"apply_entry","event_id":Trials.event_ids()[0],"route_id":"medical_pause"})

func choice_and_save() -> void:
	var c = _career()
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event({"event_id":Trials.event_ids()[0],"ruleset_season_start_year":2021,"competition_level":"senior"}).event
	var before := JSON.stringify(c.to_dict())
	var offered: Array = Entry.options(c,event,{})
	T.assert_equal(offered.any(func(row):return row.id == "medical_pause" and row.available),true)
	T.assert_equal(offered.any(func(row):return row.id == "withdraw" and row.available),true,"single-event withdrawal remains separate")
	T.assert_equal(JSON.stringify(c.to_dict()),before)
	var chosen := _pause(c)
	T.assert_equal(chosen.ok,true,chosen.get("error",""))
	if not chosen.ok: return
	var next = chosen.career
	T.assert_equal(next.season_state.entry_plan.entries[Trials.event_ids()[0]].status,"declined")
	for id in Trials.event_ids().slice(1): T.assert_equal(next.season_state.entry_plan.entries[id].status,"confirmed")
	T.assert_equal(next.selection_state.applications[Trials.event_ids()[0]+":medical_pause"].reason_codes,["medical_unavailable_after_accepted_pause"])
	T.assert_equal(next.event_ledger.any(func(row):return row.get("kind") == "entry_withdrawn" and row.get("event_id") == Trials.event_ids()[0]),false)
	var replay := _pause(next)
	T.assert_equal(replay.ok,true)
	if replay.ok: T.assert_equal(replay.career.to_dict(),next.to_dict())
	T.assert_equal(Save.save(next,"user://beijing-medical-pause-v1.json").ok,true)
	var read := Save.load_save("user://beijing-medical-pause-v1.json")
	T.assert_equal(read.ok,true)
	if read.ok: T.assert_equal(read.career.beijing_trial_series,next.beijing_trial_series)
	for bad in ["bad",{"injury_ids":[]},next.beijing_trial_series.medical_pause.merged({"event_id":"not-a-trial"},true),next.beijing_trial_series.medical_pause.merged({"selected_on":"2021-12-19"},true)]:
		var altered = next.transaction_copy()
		altered.beijing_trial_series.medical_pause = bad
		T.assert_equal(Save.save(altered,"user://beijing-medical-pause-invalid.json").ok,false)

func coordinator() -> void:
	var chosen := _pause(_career())
	T.assert_equal(chosen.ok,true)
	if not chosen.ok: return
	var c = chosen.career
	c.competition_timeline.date = "2021-12-29"
	c.competition_timeline.origin_date = "2021-12-29"
	c.competition_timeline.quarter_progress = 90
	c.event_ledger.append({"kind":"season_event","season_id":"2021-22","event_id":"isu_olympic_qualifier_nebelhorn_2021","outcome":"unexamined","reason":"controlled unavailable historical source; no invented results"})
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.event_id == Trials.event_ids()[1])
	var before := JSON.stringify(c.to_dict())
	var proposed: Array = []
	var result: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(c,bundle,func(candidate):proposed.append(candidate);return false)
	T.assert_equal(result.errors,["save_failed"])
	T.assert_equal(proposed.size(),1)
	if proposed.size() == 1:
		T.assert_equal(proposed[0].season_state.entry_plan.entries[Trials.event_ids()[1]].status,"declined")
		T.assert_equal(proposed[0].selection_state.applications[Trials.event_ids()[1]+":medical_pause"].reason_codes,["medical_unavailable_after_accepted_pause"])
		T.assert_equal(proposed[0].competition_archive,c.competition_archive,"withdrawal cannot fabricate a player result")
	T.assert_equal(JSON.stringify(c.to_dict()),before)
	T.assert_equal(result.career.to_dict(),c.to_dict())

func recovery() -> void:
	var chosen := _pause(_career())
	T.assert_equal(chosen.ok,true)
	if not chosen.ok: return
	var c = chosen.career
	var api = load("res://src/simulation/entry_application_service.gd")
	T.assert_equal(api.new().has_method("medical_pause_applies"),true)
	if not api.new().has_method("medical_pause_applies"): return
	T.assert_equal(api.medical_pause_applies(c,Trials.event_ids()[1]),true)
	c.condition_state.injuries[0].status = "recovered"
	c.condition_state.injuries[0].function_limits = {}
	T.assert_equal(api.medical_pause_applies(c,Trials.event_ids()[1]),false)
	T.assert_equal(c.season_state.entry_plan.entries[Trials.event_ids()[1]].status,"confirmed")
	c.condition_state.injuries.append({"id":"different-injury","site":"ankle","severity":0.9,"remaining_quarters":2,"status":"active"})
	T.assert_equal(api.medical_pause_applies(c,Trials.event_ids()[1]),false,"a different injury needs its own explicit handling")
	c.condition_state.injuries[0].status = "active"
	c.condition_state.injuries[0].severity = 0.2
	c.condition_state.injuries[0].function_limits = {"landing":{"blocked":false,"factor":0.9}}
	T.assert_equal(api.medical_pause_applies(c,Trials.event_ids()[1]),false,"a still-active but non-prohibiting old injury cannot authorize skipping for a new injury")
	T.assert_equal(api.medical_pause_applies(c,"isu_owg2022"),false)
