extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const GameClock = preload("res://src/domain/game_clock.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const SeasonCalendarPlanner = preload("res://src/simulation/season_calendar_planner.gd")
const EventEligibilityEvaluator = preload("res://src/simulation/event_eligibility_evaluator.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")

const ELIGIBILITY_RULES := {"junior_min_age": 13, "junior_max_age": 18, "age_cutoff": {"month": 7, "day": 1}}
const SAVE_PATHS := ["user://calendar-eligible.json", "user://calendar-young.json", "user://calendar-underqualified.json"]

func cases() -> Array[Dictionary]:
	return [
		{"name": "eligible athlete choice and explanations survive save", "callable": test_eligible_athlete_round_trip},
		{"name": "international age does not block domestic club events", "callable": test_domestic_and_international_age_are_separate},
		{"name": "underqualified athlete keeps blocked events and permitted skip", "callable": test_underqualified_round_trip},
	]

func teardown() -> void:
	for path in SAVE_PATHS:
		_delete(path)
		_delete("%s.tmp" % path)
		_delete("%s.bak" % path)

func test_eligible_athlete_round_trip() -> void:
	var career = _career(2005, 20181)
	var proposal := _proposal(career)
	var event_id := "cn_club_league_2018_stage_1"
	TestSupport.assert_equal(proposal.plan.entries[event_id].eligibility_snapshot.eligible, true)
	var changed := SeasonCalendarPlanner.apply_adjustment(career, proposal.plan, event_id, "enter")
	_store_season(career, changed.plan.to_dict())
	_assert_saved_plan_unchanged(career, SAVE_PATHS[0])

func test_domestic_and_international_age_are_separate() -> void:
	var career = _career(2007, 20182)
	var calendar := _calendar()
	var proposal := SeasonCalendarPlanner.propose(career, calendar, ELIGIBILITY_RULES)
	var event_id := "cn_club_league_2018_stage_1"
	TestSupport.assert_equal(proposal.plan.entries[event_id].eligibility_snapshot.eligible, true)
	var international_event: Dictionary = calendar.events[0].duplicate(true)
	international_event.event_id = "age_boundary_probe"
	international_event.scope = "international"
	var international := EventEligibilityEvaluator.evaluate(
		career.athlete, international_event, 2018, ["junior"],
		SeasonCalendarPlanner.qualification_state_for(career), ELIGIBILITY_RULES,
	)
	TestSupport.assert_equal(international.eligible, false)
	TestSupport.assert_equal(international.hard_gate_codes.has("international_age_ineligible"), true)
	var changed := SeasonCalendarPlanner.apply_adjustment(career, proposal.plan, event_id, "enter")
	_store_season(career, changed.plan.to_dict())
	_assert_saved_plan_unchanged(career, SAVE_PATHS[1])

func test_underqualified_round_trip() -> void:
	var career = _career(2005, 20183)
	var proposal := _proposal(career)
	var event_id := "cn_grand_prix_u_series_2018"
	var entry: Dictionary = proposal.plan.entries[event_id]
	TestSupport.assert_equal(entry.status, "blocked")
	TestSupport.assert_equal(entry.eligibility_snapshot.missing_qualification_ids.has("national_technical_minimum"), true)
	var changed := SeasonCalendarPlanner.apply_adjustment(career, proposal.plan, event_id, "skip")
	TestSupport.assert_equal(changed.errors, [])
	_store_season(career, changed.plan.to_dict())
	_assert_saved_plan_unchanged(career, SAVE_PATHS[2])

func _career(birth_year: int, seed: int):
	var career = Fixtures.starting_career(seed)
	career.athlete.birth_year = birth_year
	career.clock = GameClock.new(2018, 3)
	return career

func _calendar() -> Dictionary:
	return SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles").calendar

func _proposal(career) -> Dictionary:
	return SeasonCalendarPlanner.propose(career, _calendar(), ELIGIBILITY_RULES)

func _store_season(career, plan: Dictionary) -> void:
	var statuses := {}
	for event_id in plan.entries: statuses[event_id] = plan.entries[event_id].status
	career.season_state = {
		"season_id": "2018-19", "entry_plan": plan.duplicate(true),
		"qualification_state": SeasonCalendarPlanner.qualification_state_for(career),
		"event_statuses": statuses,
	}

func _assert_saved_plan_unchanged(career, path: String) -> void:
	var expected: Dictionary = career.season_state.duplicate(true)
	TestSupport.assert_equal(SaveRepository.save(career, path).ok, true)
	var loaded := SaveRepository.load_save(path)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.season_state, expected)

func _delete(path: String) -> void:
	if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
