extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"sample final snapshot includes actual whole curriculum metrics","callable":report_components},
		{"name":"healthy automatic six coach curricula protect spin and skating lessons","callable":essential_lessons},
		{"name":"ordinary foundation coaches develop reliable graded teenage spins","callable":graded_progression},
		{"name":"automatic foundations coexist with two chosen goals and artist expression","callable":chosen_focuses},
		{"name":"foundation floors do not override manual allocation or medical recovery","callable":manual_and_recovery},
		{"name":"cohort validation rejects missing actual component evidence","callable":component_validation},
		{"name":"final course does not claim a route bonus reassigned to chosen foundations","callable":truthful_reallocation},
		{"name":"novice fast route with unspecified optional jumps changes the actual course","callable":default_fast_route},
		{"name":"coach selected route priority does not target a deferred jump","callable":default_deferred_priority},
		{"name":"deferred automatic difficulty preserves learned work and explicit player requests","callable":deferred_difficulty},
	]

func report_components() -> void:
	var report: Dictionary = load("res://scripts/connected_coaching_sample.gd").new().run_sample(42000,"coach_he","balanced",1)
	T.assert_equal(report.errors,[])
	for field in ["technique","spins","spin_foundation"]:
		T.assert_equal(not Dictionary(report.final.get(field,{})).is_empty(),true,"actual final snapshot missing "+field)

func essential_lessons() -> void:
	for coach_id in ["coach_lin","coach_zhao","coach_he","coach_tang","coach_sun","coach_qiao"]:
		for route in ["balanced","fast"]:
			var c = F.starting(42000)
			c.coach_assignment.technical_tendencies = load("res://src/content/club_coach_repository.gd").new().coach_profile(coach_id).technical_tendencies.duplicate(true)
			c.development_roadmap = {"route_id":route,"priority_jumps":["flip","lutz"]}
			var programs = preload("res://tests/fixtures.gd").formal_junior_career(42000).active_programs
			c.active_programs = programs.duplicate(true)
			var built: Dictionary = Coach.build(c,Intent.create("accept").intent)
			T.assert_equal(built.errors,[])
			if built.plan == null: continue
			var shares: Dictionary = built.plan.shares
			for field in ["rotation","skating_foundation"]:
				T.assert_equal(int(shares[field])>=10,true,"%s/%s starved %s: %s" % [coach_id,route,field,shares])
			for field in ["conditioning","program_short","program_free"]:
				T.assert_equal(int(shares[field])>=5,true,"essential lesson missing: "+field)
			var total := 0
			for value in shares.values(): total += int(value)
			T.assert_equal(total,100)
			for id in c.athlete.jumps: T.assert_equal(int(shares["jump_"+id])>=5,true)

func graded_progression() -> void:
	# Real 24-period growth, then controlled healthy/familiar graded execution.
	# No direct skill awards and no judging-threshold alterations in the fixture.
	for coach_id in ["coach_he","coach_tang","coach_sun"]:
		for route in ["balanced","fast"]:
			var report: Dictionary = load("res://scripts/connected_coaching_sample.gd").new().run_sample(42000,coach_id,route,24)
			T.assert_equal(report.errors,[])
			T.assert_equal(report.completed,true,"ordinary progression fixture must complete")
			if not report.final.has("spins"): T.assert_equal(false,true,"missing actual component snapshot"); continue
			var athlete = F.starting(42000).athlete
			athlete.technique = report.final.technique.duplicate(true)
			athlete.spins = report.final.spins.duplicate(true)
			athlete.spin_foundation = report.final.spin_foundation.duplicate(true)
			athlete.skating = report.final.skating.duplicate(true)
			var rules: Dictionary = load("res://src/content/formal_scoring_repository.gd").load_catalog(2019,"women_singles").catalog
			for code in ["CCoSp","FCSp","LSp"]:
				var program = load("res://src/domain/skating_program.gd").new()
				var element = load("res://src/domain/program_element.gd").create("audit-"+code,"spin").element
				element.spin_code = code; element.target_level = 4
				program.slot_familiarity[element.element_id] = 85.0
				var level4 := 0
				for seed_value in range(10000,10032):
					var rng := RandomNumberGenerator.new(); rng.seed = seed_value
					var execution: Dictionary = load("res://src/simulation/program_performance_simulator.gd")._simulate_non_jump(athlete,program,element,0,0.0,rng)
					var final: Dictionary = load("res://src/simulation/formal_technical_panel.gd").resolve({"elements":[execution]},rules,{}, {},seed_value)
					if int(final.final_elements[0].final_level) == 4: level4 += 1
				T.assert_equal(level4>=24,true,"%s/%s/%s healthy familiar L4 only %d/32" % [coach_id,route,code,level4])

func chosen_focuses() -> void:
	var c = F.triple_gap(42001)
	c.development_roadmap = {"route_id":"fast","priority_jumps":["flip","lutz"]}
	c.coach_assignment.technical_tendencies = load("res://src/content/club_coach_repository.gd").new().coach_profile("coach_tang").technical_tendencies.duplicate(true)
	c.training_direction.focuses = [{"id":"axel","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}},{"id":"expression","kind":"musical_expression","target":{}}]
	c.athlete.jumps.axel.proficiency.double = 1.0
	var p = Coach.build(c,Intent.create("accept").intent).plan
	T.assert_equal(p.total_share(),100)
	T.assert_equal(p.expression_share,5,"artist and chosen expression must execute real lessons")
	T.assert_equal(int(p.shares.jump_axel)>=10,true,"chosen Axel can reuse an unselected bonus, not spin foundations")
	T.assert_equal(int(p.shares.rotation)>=10,true)
	T.assert_equal(int(p.shares.skating_foundation)>=10,true)
	T.assert_equal(int(p.jump_rotations.axel)<3,true,"unready target is preparation, not a free 3A")

func manual_and_recovery() -> void:
	var c = F.starting(42002)
	var shares: Dictionary = Coach.BASE_SHARES.duplicate(true)
	shares.rotation = 5; shares.skating_foundation += 10
	var targets := {}
	for id in c.athlete.jumps: targets[id] = 1
	var manual = load("res://src/domain/training_plan.gd").create(shares,targets).plan
	T.assert_equal(Coach.review_load(c,manual).adjusted_plan.shares.rotation,5,"explicit manual plan remains player-owned")
	c.active_programs = preload("res://tests/fixtures.gd").formal_junior_career(42002).active_programs.duplicate(true)
	var recovery: Dictionary = Coach.build(c,Intent.create("accept").intent,{"policy_id":"recovery"})
	T.assert_equal(int(recovery.plan.shares.rest)>=40,true,"explicit recovery may trade regular foundation lessons for rest")
	c.condition_state.function_limits = {"coordination":{"blocked":true,"review_condition":"复评转体功能"}}
	# Existing medical service is authoritative; no floor may add forbidden work.
	var limits = load("res://src/simulation/athlete_function_service.gd")
	T.assert_equal(limits.action_constraints(c,{"kind":"spin"}).allowed,false)
	T.assert_equal(Coach.build(c,Intent.create("accept").intent).plan.shares.rotation,0)

func component_validation() -> void:
	var driver = load("res://scripts/connected_coaching_sample.gd").new()
	var r: Dictionary = driver.run_sample(42000,"coach_he","balanced",1)
	T.assert_equal(driver.validate_report(r).is_empty(),true)
	r.final.erase("spins")
	T.assert_equal(driver.validate_report(r).is_empty(),false,"jump-only sample is insufficient for whole curriculum validation")

func truthful_reallocation() -> void:
	var c = preload("res://tests/fixtures.gd").formal_junior_career(42003)
	c.coach_assignment.technical_tendencies = load("res://src/content/club_coach_repository.gd").new().coach_profile("coach_tang").technical_tendencies.duplicate(true)
	c.development_roadmap = {"route_id":"fast","priority_jumps":["toe_loop","salchow"]}
	c.training_direction.focuses = [{"id":"spin","kind":"spin","target":{}},{"id":"steps","kind":"steps","target":{}}]
	var result: Dictionary = Coach.build(c,Intent.create("accept").intent)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.plan.shares.jump_toe_loop,5,"real selected foundations have replaced at least this route bonus")
	T.assert_equal(int(result.plan.shares.jump_salchow)>=5,true)
	T.assert_equal(result.reasons.any(func(reason): return "增加现有专项课时" in str(reason)),false,"do not describe removed jump supplements as part of the final course")

func default_fast_route() -> void:
	# Real dialog defaults: a novice chooses route only, not two jump menus.
	var c = F.starting(42004)
	var dialog = load("res://src/app/development_roadmap_dialog.gd").new()
	Engine.get_main_loop().root.add_child(dialog)
	dialog.career = c
	var budgets := {}
	for route in ["balanced","fast"]:
		dialog.select_route(route)
		var roadmap = dialog._build_roadmap()
		T.assert_equal(roadmap.priority_jumps.is_empty(),true,"keep optional UI choices truly unspecified")
		c.development_roadmap = roadmap.to_dict()
		var built: Dictionary = Coach.build(c,Intent.create("accept").intent)
		T.assert_equal(built.errors,[])
		var total_jump := 0
		for id in c.athlete.jumps: total_jump += int(built.plan.shares["jump_"+id])
		budgets[route] = total_jump
		T.assert_equal(int(built.plan.shares.rotation)>=10,true)
		T.assert_equal(int(built.plan.shares.skating_foundation)>=10,true)
		T.assert_equal(int(built.plan.shares.rest)>=20,true)
		T.assert_equal(built.plan.total_share(),100)
	T.assert_equal(int(budgets.fast)>int(budgets.balanced),true,"automatic coach must resolve unspecified priorities, not disable the fast route")
	dialog.free()

func default_deferred_priority() -> void:
	var c = F.starting(42005)
	var dialog = load("res://src/app/development_roadmap_dialog.gd").new()
	Engine.get_main_loop().root.add_child(dialog)
	dialog.career = c
	dialog.select_route("fast")
	dialog.set_deferred_jump("toe_loop")
	c.development_roadmap = dialog._build_roadmap().to_dict()
	var built: Dictionary = Coach.build(c,Intent.create("accept").intent)
	T.assert_equal(built.errors,[])
	T.assert_equal(built.plan.shares.jump_toe_loop,5,"deferred still receives base maintenance, not an automatic route bonus")
	T.assert_equal(int(built.plan.shares.jump_salchow)>=10,true)
	T.assert_equal(built.plan.total_share(),100)
	dialog.free()

func deferred_difficulty() -> void:
	var c = F.triple_gap(42006)
	c.development_roadmap = {"route_id":"fast","priority_jumps":[],"deferred_jump":"toe_loop"}
	var automatic: Dictionary = Coach.build(c,Intent.create("accept").intent)
	T.assert_equal(automatic.plan.jump_rotations.toe_loop,2,"defer automatic new difficulty, not maintenance of learned doubles")
	var requested: Dictionary = Coach.build(c,Intent.create("requested_element","jump:toe_loop:3").intent)
	T.assert_equal(requested.errors,[])
	T.assert_equal(requested.plan.jump_rotations.toe_loop,3,"a later explicit request can override a deferred automatic goal")
	c.athlete.jumps.toe_loop.unlocked_rotations = 3
	T.assert_equal(Coach.build(c,Intent.create("accept").intent).plan.jump_rotations.toe_loop,3,"deferral never takes away an already learned triple")
