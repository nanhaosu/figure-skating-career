extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const H = preload("res://src/content/historical_rule_repository.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Validator = preload("res://src/simulation/program_validator.gd")
const Candidates = preload("res://src/presentation/program_candidate_presenter.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2020 allowed sit spin survives actual program save and restore","callable":test_sit_roundtrip},
		{"name":"2021 does not silently accept previous season sit spin alternative","callable":test_season_alternative},
		{"name":"2020 sit spin choice explains the movement instead of bare SSp code","callable":test_readable_choice},
		{"name":"actual advanced spin selector also displays a readable sit spin name","callable":test_editor_selector},
	]

func _program(year:int) -> Dictionary:
	var career = F.formal_junior_career(1221)
	var loaded = H.load_season(year,"women_singles")
	T.assert_equal(loaded.errors,[])
	var rules = H.rules_for(loaded.rules,"junior","short")
	var draft = Draft.legal_draft(career.athlete,"short",rules,{"title":"赛季节目"},1221)
	T.assert_equal(draft.errors,[])
	return {"career":career,"rules":rules,"program":draft.program}

func test_sit_roundtrip() -> void:
	var context = _program(2020)
	if context.program == null:return
	for element in context.program.elements:
		if element.kind == "spin" and element.spin_code == "LSp": element.spin_code = "SSp"
	T.assert_equal(Validator.validate(context.program,context.career.athlete,context.rules),[])
	var saved = Program.from_dict(context.program.to_dict())
	T.assert_equal(saved != null,true,"A legal2020 sit-spin programme must not disappear during persistence")
	if saved == null:return
	var result = Draft.save_draft(null,saved)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.program.elements.any(func(e):return e.kind == "spin" and e.spin_code == "SSp"),true)
	T.assert_equal(Validator.validate(result.program,context.career.athlete,context.rules),[])

func test_season_alternative() -> void:
	var context = _program(2021)
	if context.program == null:return
	for element in context.program.elements:
		if element.kind == "spin" and element.spin_code == "LSp": element.spin_code = "SSp"
	T.assert_equal(Validator.validate(context.program,context.career.athlete,context.rules).is_empty(),false)

func test_readable_choice() -> void:
	var context = _program(2020)
	if context.program == null:return
	for index in context.program.elements.size():
		if context.program.elements[index].kind != "spin":continue
		var choices = Candidates.for_slot(context.career,context.program,index,context.rules)
		var sit = choices.filter(func(choice):return choice.get("spin_code","") == "SSp")
		T.assert_equal(sit.size(),1)
		if not sit.is_empty():T.assert_equal(str(sit[0].label).contains("蹲踞"),true,"A novice should see the movement's Chinese name")
		return

func test_editor_selector() -> void:
	var context = _program(2020)
	if context.program == null:return
	var panel = load("res://src/app/program_editor_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(context.career,"short",context.rules,{"program":context.program,"errors":[],"missing":[]})
	var selector = panel.get_node("%SpinChoice")
	var found := false
	for index in selector.item_count:
		if selector.get_item_metadata(index) == "SSp":
			found = selector.get_item_text(index).contains("蹲踞")
	T.assert_equal(found,true,"Advanced selector cannot fall back to an unexplained code when normal candidates have names")
	panel.free()
