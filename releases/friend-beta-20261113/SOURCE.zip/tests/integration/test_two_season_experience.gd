extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"three real coach and focus routes close two seasons without invented ability","callable":test_routes}]

func test_routes() -> void:
	T.assert_equal(FileAccess.file_exists("res://scripts/calibrate_two_season_experience.gd"),true)
	if not FileAccess.file_exists("res://scripts/calibrate_two_season_experience.gd"): return
	var courses := {}
	for route in ["coach","combo_expression","programme_steps"]:
		var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
		var result: Dictionary = await driver.run_sample(42000,route)
		T.assert_equal(result.errors.is_empty(),true,str(result.errors))
		T.assert_equal(result.completed,true,str(result.get("last_node","")))
		T.assert_equal(result.closed_seasons,["2018-19","2019-20"])
		T.assert_equal(result.get("durability_evidence",true),false)
		T.assert_equal(result.get("training_quarters",0) >= 24,true)
		courses[route] = result.courses
	T.assert_equal(courses.coach != courses.combo_expression,true)
	T.assert_equal(courses.combo_expression != courses.programme_steps,true)
