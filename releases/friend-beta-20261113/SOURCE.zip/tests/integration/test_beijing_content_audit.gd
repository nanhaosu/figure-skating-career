extends RefCounted
const T=preload("res://tests/test_support.gd")
const F=preload("res://tests/fixtures.gd")
const B=preload("res://src/content/season_bundle_repository.gd")
const C=preload("res://src/content/season_calendar_repository.gd")
const E=preload("res://src/content/historical_evidence_repository.gd")
const Q=preload("res://src/content/beijing_qualification_policy.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2019 through Beijing both divisions load without changing an existing career","callable":_seasons},
		{"name":"every cancellation stays nonexecutable and cannot award official records or points","callable":_cancellations},
		{"name":"source final uncertainty remains unknown while approved adopted policy is usable","callable":_qualification},
		{"name":"canonical Beijing competition carries its approved policy and visible version caveat","callable":_event_policy},
	]

func _seasons() -> void:
	var career=F.formal_junior_career(771)
	var before=career.to_dict()
	for year in [2019,2020,2021]:
		for level in ["junior","senior"]:
			#2019 only has the legacy international junior catalog; domestic
			# senior rules remain covered by the explicit resolver tests.
			if year==2019 and level=="senior":continue
			var loaded=B.load_bundle(year,"women_singles",level)
			T.assert_equal(loaded.errors,[])
			T.assert_equal(loaded.federation_profiles.is_empty(),false)
	T.assert_equal(career.to_dict(),before,"Content audit cannot migrate or invent career history")

func _cancellations() -> void:
	for year in [2020,2021]:
		for level in ["junior","senior"]:
			var loaded=B.load_bundle(year,"women_singles",level)
			T.assert_equal(loaded.errors,[])
			if not loaded.errors.is_empty():return
			var playable=C.playable_events(loaded.calendar).map(func(e):return e.event_id)
			for event in loaded.calendar.events:
				if event.get("status")!="cancelled":continue
				T.assert_equal(playable.has(event.event_id),false)
				T.assert_equal(event.ranking_points_system,"none")
				T.assert_equal(event.record_eligibility,"none")
				T.assert_equal(B.rules_for_event_level(event,"short","women_singles",event.level_options[0]).errors.is_empty(),false)

func _qualification() -> void:
	var loaded=E.load_catalog("res://data/qualification/beijing_2022_evidence.json")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	T.assert_equal(E.resolve(loaded.catalog,"beijing_women_tes_final","2022-01-24").status,"unknown")
	T.assert_equal(E.resolve(loaded.catalog,"beijing_tes_validity_window_final","2022-01-24").value,null)
	var adopted=Q.load_policy()
	T.assert_equal(adopted.errors,[])
	if not adopted.errors.is_empty():return
	T.assert_equal(adopted.policy.minimum_tes,{"short":23.0,"free":40.0})
	T.assert_equal(adopted.policy.final_historical_verification,"unknown")
	var copied=adopted.policy.duplicate(true)
	copied.minimum_tes.short=0.0
	T.assert_equal(Q.load_policy().policy.minimum_tes.short,23.0)

func _event_policy() -> void:
	var loaded=C.load_international_calendar(2021,"women_singles","senior")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	var event=loaded.calendar.events.filter(func(e):return e.event_family=="olympic_games")[0]
	var resolved=B.competition_event(event)
	T.assert_equal(resolved.errors,[])
	if not resolved.errors.is_empty():return
	T.assert_equal(resolved.event.has("qualification_policy"),true,"The approved rule must reach the real competition boundary")
	if not resolved.event.has("qualification_policy"):return
	T.assert_equal(resolved.event.qualification_policy.minimum_tes,{"short":23.0,"free":40.0})
	T.assert_equal(str(resolved.event.gameplay_note).contains("最终修订未核实"),true)
	var forged=event.duplicate(true)
	forged.qualification_policy_id="waive_all"
	T.assert_equal(B.competition_event(forged).errors.is_empty(),false)
