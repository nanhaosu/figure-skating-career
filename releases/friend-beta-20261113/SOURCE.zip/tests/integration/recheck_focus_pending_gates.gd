extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"continuous training preserves active competition before any training save","callable":competition_stop},
		{"name":"continuous training preserves unanswered training choice before any training save","callable":choice_stop}]

func competition_stop() -> void:
	var career = F.starting_career(1793)
	career.internal_invitation_state.status = "completed"
	career.competition_state = {"kind":"formal","status":"short_ready","event_id":"cn_club_league_2018_stage_1"}
	await _assert_stop(career,"competition_short")

func choice_stop() -> void:
	var career = F.starting_career(1794)
	career.internal_invitation_state.status = "completed"
	career.condition_state.pending_training_events = [{"id":"unanswered","choices":[{"id":"tell_coach"}]}]
	await _assert_stop(career,"training_decision")

func _assert_stop(career, kind: String) -> void:
	var before := JSON.stringify(career.transaction_copy().to_dict())
	var saves := [0]
	var result: Dictionary = await load("res://src/simulation/focus_training_run_service.gd").advance(career,load("res://src/domain/training_intent.gd").create("accept").intent,func(_candidate): saves[0]+=1; return true,Callable())
	T.assert_equal(result.errors,[])
	T.assert_equal(result.stop_reason,"pending_action")
	T.assert_equal(result.pending_action.kind,kind)
	T.assert_equal(result.elapsed_weeks,0)
	T.assert_equal(saves[0],0)
	T.assert_equal(JSON.stringify(result.career.to_dict()),before)
