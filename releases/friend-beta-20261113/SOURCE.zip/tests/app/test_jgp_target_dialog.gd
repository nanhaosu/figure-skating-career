extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"mounted JGP target dialog retains domestic board across competitor filters without writes","callable":mounted_board}]

func mounted_board() -> void:
	var career = F.starting_career(924)
	career.season_state["target_event_id"] = "second"
	career.selection_state["jgp_second_start"] = {"season_id":"2022-23","policy":{"minimum_first_points":3,"label":"非官方游戏政策：赛前3天国内确认。"},"first_assignments":{"player":["first"]},"reserved_event_ids":["second"],"rounds":[{"event_id":"second","cutoff":"2022-09-25","candidate_rows":[{"athlete_id":"player","name":"你","score":187.27,"points":9,"first_event_id":"first","reason_codes":[]}],"selected_ids":["player"],"alternate_ids":[],"assignments":{"player":["second"]}}]}
	var calendar := {"season_id":"2022-23","events":[{"event_id":"second","name":"测试JGP","event_family":"jgp_stage","scope":"international"}]}
	var before: Dictionary = career.to_dict().duplicate(true)
	var window = load("res://src/app/season_target_dialog.gd").new()
	var emitted: Array = []
	window.target_selected.connect(func(id):emitted.append(id))
	window.event_requested.connect(func(id):emitted.append(id))
	window.auto_requested.connect(func():emitted.append("auto"))
	Engine.get_main_loop().root.add_child(window)
	window.present(career,calendar,{})
	await Engine.get_main_loop().process_frame
	var body: RichTextLabel = window.find_child("TargetDetails",true,false)
	var filter: OptionButton = window.find_child("CompetitionFilter",true,false)
	for index in [0,1,2,0]:
		filter.select(index)
		filter.item_selected.emit(index)
		T.assert_equal(body.text.contains("国内JGP第二站竞争"),true,"domestic dispatch board survives competitor filtering")
		T.assert_equal(body.text.contains("187.27"),true,"actual first result reaches mounted Window text")
		T.assert_equal(body.text.contains("赛前3天"),true)
	T.assert_equal(emitted,[])
	T.assert_equal(career.to_dict(),before)
	window.hide()
	window.queue_free()
	await Engine.get_main_loop().process_frame
