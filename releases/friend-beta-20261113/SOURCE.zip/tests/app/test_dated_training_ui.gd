extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"existing coach continue button uses dated training instead of premature quarterly race check-in", "callable":coach_continue},
		{"name":"dated coach continue does not adopt a plan or training days when persistence fails", "callable":failed_save},
		{"name":"enrolled player's normal coach button activates dated training without developer setup", "callable":automatic_coach_continue},
	]

func _panel(activate: bool = true):
	var c = load("res://tests/simulation/test_beijing_trial_service.gd").new()._entrant()
	c.condition_state.growth_phase = "adapted"
	T.assert_equal(load("res://src/simulation/beijing_trial_service.gd").enroll(c,"beijing2022_women_trials","dated-ui").ok,true)
	if activate:
		var begun: Dictionary = load("res://src/simulation/career_command_service.gd").apply(c,{"type":"begin_dated_training"})
		T.assert_equal(begun.ok,true)
		if begun.ok: c = begun.career
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.setup(c,load("res://src/content/catalog_repository.gd").load_catalog())
	# Isolate the five already-enrolled trials; unrelated earlier registrations
	# must remain real decisions in the full-calendar natural route.
	panel.season_bundle.calendar.events = panel.season_bundle.calendar.events.filter(func(e):return e.event_family == "beijing_trial")
	return panel

func coach_continue() -> void:
	var panel = _panel()
	var nodes: Array = []
	panel.advance_blocked.connect(func(node):nodes.append(node))
	panel.persist = func(_candidate):return true
	await panel.continue_training()
	T.assert_equal(str(panel.career.competition_timeline.date)>"2021-09-30",true,"the coach button cannot jump straight from October1 to December check-in")
	T.assert_equal(str(panel.career.competition_timeline.date)<="2021-12-17",true,"training stops before the first actual race or an earlier necessary decision")
	T.assert_equal(panel.plan_error_label.text.contains("不能重复领取旧季度训练"),false)
	T.assert_equal(panel.career.history.any(func(row):return row.get("category") == "dated_training"),true)
	panel.free()

func failed_save() -> void:
	var panel = _panel()
	var before: Dictionary = panel.career.to_dict()
	panel.persist = func(_candidate):return false
	await panel.continue_training()
	T.assert_equal(panel.career.to_dict()==before,true,"failed durable boundary must preserve the live career")
	panel.free()

func automatic_coach_continue() -> void:
	var panel = _panel(false)
	var before: Dictionary = panel.career.to_dict()
	panel.persist = func(_candidate):return false
	await panel.continue_training()
	T.assert_equal(panel.career.to_dict()==before,true)
	panel.persist = func(_candidate):return true
	await panel.continue_training()
	T.assert_equal(panel.career.competition_timeline.mode,"dated")
	T.assert_equal(panel.career.history.any(func(row):return row.get("category") == "dated_training"),true)
	panel.free()
