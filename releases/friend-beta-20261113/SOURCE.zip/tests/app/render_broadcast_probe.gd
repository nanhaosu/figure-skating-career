extends SceneTree

func _initialize() -> void:
	call_deferred("capture")

func capture() -> void:
	var fixture = load("res://tests/app/test_broadcast_playback.gd").new()
	var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
	panel.theme = load("res://src/app/theme_factory.gd").create()
	root.add_child(panel)
	panel.present_session(fixture._session())
	var career = load("res://tests/fixtures.gd").formal_junior_career(7002)
	var program = load("res://src/domain/skating_program.gd").from_dict(career.active_programs.short)
	var rules: Dictionary = load("res://tests/simulation/test_formal_segment_simulator.gd").new()._rules("short")
	var record: Dictionary = load("res://src/simulation/formal_segment_simulator.gd").simulate(career.athlete, program, {}, {}, rules, 702)
	panel.show_segment(record)
	panel.get_node("%CompetitionIceView").set_progress(0.7)
	panel._elapsed = 0.7
	panel._reveal_due_elements()
	for frame in 8: await process_frame
	await RenderingServer.frame_post_draw
	var args := OS.get_cmdline_user_args()
	if args.is_empty(): quit(2); return
	var result := root.get_texture().get_image().save_png(args[0])
	print("CAPTURE_RESULT ", result)
	quit(0 if result == OK else 1)
