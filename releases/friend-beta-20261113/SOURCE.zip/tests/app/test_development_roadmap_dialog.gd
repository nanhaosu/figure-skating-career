extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")

const SCENE := "res://src/app/development_roadmap_dialog.tscn"

func cases() -> Array[Dictionary]:
	return [{"name":"fast UI confirms five ordinary triple families","callable":test_fast_five},
		{"name": "roadmap dialog has three compact steps", "callable": test_three_steps},
		{"name": "balanced route is default", "callable": test_balanced_default},
		{"name": "dialog exposes two priorities and one deferred jump", "callable": test_compact_jump_controls},
		{"name": "invalid custom milestone disables confirmation", "callable": test_invalid_custom_milestone},
		{"name": "evaluation page shows coach feasibility", "callable": test_evaluation_page},
	]

func test_three_steps() -> void:
	var dialog = _dialog()
	TestSupport.assert_equal(dialog.step_count(), 3)
	TestSupport.assert_equal(dialog.find_children("YearlyJump*", "Control", true, false).size(), 0)
	dialog.free()

func test_balanced_default() -> void:
	var dialog = _dialog(); dialog.begin(Fixtures.starting_career(301))
	TestSupport.assert_equal(dialog.selected_route_id(), "balanced")
	dialog.free()

func test_compact_jump_controls() -> void:
	var dialog = _dialog()
	TestSupport.assert_equal(dialog.find_children("PriorityJump*", "OptionButton", true, false).size(), 2)
	TestSupport.assert_equal(dialog.find_child("DeferredJump", true, false) != null, true)
	dialog.free()

func test_invalid_custom_milestone() -> void:
	var dialog = _dialog(); dialog.begin(Fixtures.starting_career(302)); dialog.select_route("custom")
	dialog.set_milestone(0, 5, 3, 4)
	TestSupport.assert_equal(dialog.find_child("ConfirmButton", true, false).disabled, true)
	dialog.free()

func test_evaluation_page() -> void:
	var dialog = _dialog(); dialog.begin(Fixtures.starting_career(303)); dialog.show_evaluation()
	TestSupport.assert_equal(dialog.find_child("EvaluationText", true, false).text.contains("教练评估"), true)
	TestSupport.assert_equal(dialog.current_step, 2)
	dialog.free()

func _dialog():
	TestSupport.assert_equal(ResourceLoader.exists(SCENE), true)
	var dialog = load(SCENE).instantiate()
	Engine.get_main_loop().root.add_child(dialog)
	return dialog

func test_fast_five() -> void:
	var dialog = _dialog(); var career := Fixtures.starting_career(990)
	dialog.begin(career); dialog.select_route("fast")
	var confirmed: Array = []
	dialog.roadmap_confirmed.connect(func(roadmap): confirmed.append(roadmap.to_dict()))
	dialog._confirm()
	TestSupport.assert_equal(confirmed.size(),1)
	TestSupport.assert_equal(confirmed[0].milestones[1].count,5)
	TestSupport.assert_equal(confirmed[0].milestones[1].rotations,3)
	TestSupport.assert_equal(confirmed[0].milestones[1].age,maxi(11,career.clock.age_on(career.athlete.birth_year)+4))
	dialog.free()
