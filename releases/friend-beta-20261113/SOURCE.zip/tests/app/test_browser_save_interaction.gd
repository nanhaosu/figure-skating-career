extends RefCounted

const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"save manager disables mutating actions while persistence is busy", "callable":test_busy_feedback},
		{"name":"save manager exposes clear success and retry feedback", "callable":test_result_feedback},
	]

func _panel():
	var panel = load("res://src/app/save_manager_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	return panel

func test_busy_feedback() -> void:
	var panel = _panel()
	panel._import_ready = true
	panel.confirm_button.disabled = false
	panel._on_busy_changed(true)
	T.assert_equal(panel.message.text.contains("请勿重复点击"), true)
	T.assert_equal(panel._action_buttons.all(func(button): return button.disabled), true)
	T.assert_equal(panel._close_button.disabled, false)
	panel._on_busy_changed(false)
	T.assert_equal(panel._action_buttons.any(func(button): return button.disabled), false)
	T.assert_equal(panel.confirm_button.disabled, false, "a validated import must remain retryable after persistence returns")
	panel.free()

func test_result_feedback() -> void:
	var panel = _panel()
	panel._result({"ok":true,"errors":[]})
	T.assert_equal(panel.message.text.contains("成功"), true)
	panel._result({"ok":false,"errors":["空间不足"]})
	T.assert_equal(panel.message.text.contains("可重试"), true)
	T.assert_equal(panel.message.text.contains("空间不足"), true)
	panel.free()
