extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"birthday view and cancel do not advance or edit a career", "callable":view_cancel},
		{"name":"birthday UI durably commits once and failed save keeps live date unknown", "callable":commit_or_fail},
		{"name":"season page exposes optional birthday action without forced popups", "callable":season_action},
		{"name":"creation forwards explicitly chosen month day and leaves omitted date unknown", "callable":creation_date},
	]

func _main():
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(7094)
	return main

func view_cancel() -> void:
	var main = _main()
	T.assert_equal(main.has_method("_present_birth_date"),true)
	if not main.has_method("_present_birth_date"): main.free(); return
	var before := JSON.stringify(main.active_career.to_dict())
	main._present_birth_date()
	T.assert_equal(main._decision_dialog.visible,true)
	main._decision_dialog.close_requested.emit()
	T.assert_equal(main._decision_dialog.visible,false)
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	main.free()

func commit_or_fail() -> void:
	var main = _main()
	T.assert_equal(main.has_method("_record_birth_date"),true)
	if not main.has_method("_record_birth_date"): main.free(); return
	main.autosave_path = "user://birthday-ui-original.json"
	T.assert_equal(Save.save(main.active_career,main.autosave_path).ok,true)
	var hash_before := FileAccess.get_sha256(main.autosave_path)
	var before := JSON.stringify(main.active_career.to_dict())
	main.autosave_path = "user://"
	main._present_birth_date()
	await main._record_birth_date(6,30)
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	T.assert_equal(FileAccess.get_sha256("user://birthday-ui-original.json"),hash_before)
	T.assert_equal(main._decision_dialog.visible,true,"failed save must leave retry available")
	main.autosave_path = "user://birthday-ui-original.json"
	await main._record_birth_date(6,30)
	T.assert_equal(main.active_career.athlete.birth_date,{"year":main.active_career.athlete.birth_year,"month":6,"day":30})
	T.assert_equal(main._decision_dialog.visible,false)
	var read := Save.load_save(main.autosave_path)
	T.assert_equal(read.ok,true)
	if read.ok: T.assert_equal(read.career.athlete.birth_date,main.active_career.athlete.birth_date)
	main.free()

func season_action() -> void:
	var panel = load("res://src/app/season_overview_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var c = F.formal_junior_career(7095)
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	panel.present(c,bundle.calendar,{"entries":{}})
	var button = panel.find_child("BirthDateButton",true,false)
	T.assert_equal(button != null,true)
	T.assert_equal(panel.has_signal("birth_date_requested"),true)
	if button != null and panel.has_signal("birth_date_requested"):
		var clicks: Array = []
		panel.birth_date_requested.connect(func():clicks.append(true))
		button.pressed.emit()
		T.assert_equal(clicks,[true])
		T.assert_equal(c.athlete.birth_date,{})
	for child in panel.get_children():
		if child is Window: T.assert_equal(child.visible,false)
	panel.free()

func creation_date() -> void:
	var panel = load("res://src/app/creation_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var month = panel.find_child("BirthMonthInput",true,false)
	var day = panel.find_child("BirthDayInput",true,false)
	T.assert_equal(month != null and day != null,true)
	if month == null or day == null: panel.free(); return
	var emitted: Array = []
	panel.career_created.connect(func(c):emitted.append(c))
	panel.display_name_input.text = "生日测试"
	T.assert_equal(month.value,0.0)
	T.assert_equal(day.value,0.0)
	panel._on_create_pressed()
	T.assert_equal(emitted.size(),1)
	if emitted.size() == 1: T.assert_equal(emitted[0].athlete.birth_date,{})
	month.value = 6
	day.value = 31
	panel._on_create_pressed()
	T.assert_equal(emitted.size(),1,"invalid explicit date must not become unknown or silently correct")
	day.value = 30
	panel._on_create_pressed()
	T.assert_equal(emitted.size(),2)
	if emitted.size() == 2: T.assert_equal(emitted[1].athlete.birth_date,{"year":int(panel.birth_year_input.value),"month":6,"day":30})
	panel.free()
