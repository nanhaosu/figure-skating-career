extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const Presenter = preload("res://src/presentation/coach_handoff_presenter.gd")
const PANEL_SCENE := "res://src/app/coach_handoff_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"Chinese handoff bullet stays on the first text line", "callable":test_bullet_layout},
		{"name": "handoff panel renders coach assessment without raw dictionaries", "callable": test_readable_handoff},
		{"name": "career goal must be chosen and confirms once", "callable": test_goal_confirmed_once},
		{"name": "handoff panel fits the minimum viewport", "callable": test_minimum_viewport},
	]

func test_bullet_layout() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960,540)
	Engine.get_main_loop().root.add_child(viewport)
	var panel = load(PANEL_SCENE).instantiate()
	panel.theme = load("res://src/app/theme_factory.gd").create()
	viewport.add_child(panel)
	var career = load("res://src/simulation/career_factory.gd").create("验收",2006,"entry_club_trial","family_supportive",712010990,load("res://src/content/catalog_repository.gd").load_catalog(),3).career
	panel.present(career,Presenter.build(career))
	for i in 3: await Engine.get_main_loop().process_frame
	var paragraph: Label = panel.assessment_columns.get_child(0).get_child(1)
	TestSupport.assert_equal(paragraph.get_character_bounds(2).size.y > 0,true,"real Chinese glyph layout is required for this check")
	TestSupport.assert_equal(paragraph.get_character_bounds(0).position.y,paragraph.get_character_bounds(2).position.y,"a bullet must not consume an empty line before Chinese text")
	viewport.free()

func test_readable_handoff() -> void:
	var career = Fixtures.starting_career(431)
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(career, Presenter.build(career))
	var text := _all_label_text(panel)
	TestSupport.assert_equal(text.contains(Presenter.build(career).coach.name), true)
	TestSupport.assert_equal(text.contains("现阶段会什么"), true)
	TestSupport.assert_equal(text.contains("第一阶段怎么练"), true)
	TestSupport.assert_equal(text.contains("{"), false)
	TestSupport.assert_equal(text.contains("technical_tendencies"), false)
	panel.free()

func test_goal_confirmed_once() -> void:
	var career = Fixtures.starting_career(432)
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var goals: Array[String] = []
	panel.goal_confirmed.connect(func(goal_id: String): goals.append(goal_id))
	panel.present(career, Presenter.build(career))
	TestSupport.assert_equal(panel.get_node("%ConfirmGoalButton").disabled, true)
	panel.get_node("%GoalHighestStage").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%ConfirmGoalButton").disabled, false)
	panel.get_node("%ConfirmGoalButton").pressed.emit()
	panel.get_node("%ConfirmGoalButton").pressed.emit()
	TestSupport.assert_equal(goals, ["highest_stage"])
	panel.free()

func test_minimum_viewport() -> void:
	var career = Fixtures.starting_career(433)
	var panel: Control = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(career, Presenter.build(career))
	await panel.get_tree().process_frame
	TestSupport.assert_equal(panel.get_combined_minimum_size().x <= 960.0, true)
	TestSupport.assert_equal(panel.get_combined_minimum_size().y <= 540.0, true)
	TestSupport.assert_equal(panel.get_node("%HandoffScroll") is ScrollContainer, true)
	panel.free()

func _all_label_text(node: Node) -> String:
	var result := ""
	if node is Label: result += "%s\n" % node.text
	for child in node.get_children(): result += _all_label_text(child)
	return result
