extends RefCounted
const T = preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"public journey closes stale authority dialog before adopting a saved command","callable":transition},
		{"name":"screen navigation closes outgoing independent decision windows without resolving choices","callable":screen_windows}]

func screen_windows() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var main = state.main
	var before: Dictionary = main.active_career.to_dict()
	main._on_domestic_schedule_requested()
	var schedule = main.season_overview_panel.find_child("DomesticScheduleDialog",true,false)
	T.assert_equal(schedule.visible,true)
	main._show_screen(main.quarter_panel)
	T.assert_equal(schedule.visible,false,"an outgoing schedule Window must not survive its Control being hidden")
	# Hide the stale dialog before opening another, even in the RED run.
	schedule.hide()
	main.quarter_panel.event_dialog.present({"id":"inspection","title":"训练沟通","description":"仅查看","choices":[]})
	main._show_screen(main.season_overview_panel)
	T.assert_equal(main.quarter_panel.event_dialog.visible,false,"a training Window must not survive navigation to the calendar")
	T.assert_equal(main.active_career.to_dict(),before,"closing a view must not answer a pending event")
	main.free()
func transition() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = state.main
	var dialog = state.main.get_node("%QuarterPanel").authority_confirmation
	dialog.popup_centered()
	driver._handle_node({"kind":"registration","event_id":"cn_club_league_2018_stage_1","choices":[{"id":"skip","available":true}]},{})
	T.assert_equal(driver.errors,[])
	T.assert_equal(dialog.visible,false,"stale exclusive dialog must not survive public career adoption")
	T.assert_equal(state.main.active_career.season_state.entry_plan.entries.cn_club_league_2018_stage_1.status,"declined")
	state.main.free()
