extends RefCounted

const T = preload("res://tests/test_support.gd")
const Guidance = preload("res://src/app/player_guidance_service.gd")
const Fixtures = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"unresolved medical choice is the home priority without advancing time","callable":medical_priority},
		{"name":"new childhood career has one clear training action","callable":childhood_training},
		{"name":"pending internal invitation replaces routine training action","callable":internal_invitation},
		{"name":"active formal competition has a resume action","callable":active_competition},
		{"name":"junior season without an active competition points to season work","callable":junior_season},
		{"name":"guidance never exposes internal identifiers","callable":localized_copy},
	]

func medical_priority() -> void:
	var career = Fixtures.formal_junior_career(93006)
	career.condition_state.pending_decision = {"injury_id":"ankle","kind":"initial"}
	var before: Dictionary = career.to_dict()
	var view: Dictionary = Guidance.build(career)
	T.assert_equal(view.next_action.id,"review_health_decision")
	T.assert_equal(view.goal,"先确认治疗与康复安排")
	T.assert_equal(career.to_dict(),before)

func childhood_training() -> void:
	var view: Dictionary = Guidance.build(Fixtures.starting_career(93001))
	T.assert_equal(view.next_action.id,"open_training")
	T.assert_equal(view.next_action.label,"与教练安排训练")
	T.assert_equal(view.key_states.size(),3)
	T.assert_equal(str(view.goal).is_empty(),false)

func internal_invitation() -> void:
	var career = Fixtures.starting_career(93002)
	career.internal_invitation_state = {"status":"pending","offered_clock":career.clock.to_dict()}
	var view: Dictionary = Guidance.build(career)
	T.assert_equal(view.next_action.id,"review_internal_invitation")
	T.assert_equal(view.next_action.label,"回应俱乐部内部赛")

func active_competition() -> void:
	var career = Fixtures.formal_junior_career(93003)
	career.competition_state = {"kind":"formal","status":"short_ready","event_id":"cn_u_series"}
	var view: Dictionary = Guidance.build(career)
	T.assert_equal(view.next_action.id,"resume_competition")
	T.assert_equal(view.next_action.label,"开始短节目")
	T.assert_equal(view.goal,"完成当前比赛")

func junior_season() -> void:
	var career = Fixtures.formal_junior_career(93004)
	career.internal_invitation_state.status = "deferred"
	var view: Dictionary = Guidance.build(career)
	T.assert_equal(view.next_action.id,"open_season")
	T.assert_equal(view.next_action.label,"查看赛季安排")
	T.assert_equal(view.stage_title,"国内青年组·争取机会")

func localized_copy() -> void:
	var career = Fixtures.formal_junior_career(93005)
	career.competition_state = {"kind":"formal","status":"free_adjustment","event_id":"cn_u_series"}
	var serialized := JSON.stringify(Guidance.build(career))
	T.assert_equal(serialized.contains("free_adjustment"),false)
	T.assert_equal(serialized.contains("cn_u_series"),false)
