extends RefCounted
const T=preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
 return [{"name":"target window remains hidden until explicitly presented","callable":hidden}]
func hidden():
 var panel=load("res://src/app/season_overview_panel.tscn").instantiate()
 Engine.get_main_loop().root.add_child(panel)
 T.assert_equal(panel._target_dialog.visible,false,"constructing the season screen must not claim an exclusive child window")
 panel.queue_free();await Engine.get_main_loop().process_frame
