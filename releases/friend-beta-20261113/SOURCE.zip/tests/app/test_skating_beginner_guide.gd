extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"help opens readable guide without requiring a career","callable":test_help},
		{"name":"programme jump choices explain their Chinese names","callable":test_jump_names}]

func test_jump_names() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = load("res://tests/fixtures.gd").starting_career(920)
	main.open_program_editor("free")
	var choices = main.program_editor_panel.get_node("%JumpChoice")
	T.assert_equal(choices.item_count > 0,true)
	if choices.item_count > 0:
		T.assert_equal(choices.get_item_tooltip(0).is_empty(),false)
	main.free()

func test_help() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.main_menu_panel.settings_requested.emit()
	var dialog = main.find_child("SkatingInformationDialog",true,false)
	T.assert_equal(dialog != null,true)
	if dialog != null:
		T.assert_equal(dialog.find_child("GuideNext",true,false) != null,true)
		var close = dialog.find_child("GuideClose",true,false)
		T.assert_equal(close != null,true)
		if close != null: close.pressed.emit()
		T.assert_equal(dialog.visible,false)
	T.assert_equal(main.active_career,null)
	main.free()
