extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const M = preload("res://tests/fixtures/first_meaning_fixtures.gd")
const Facts = preload("res://src/simulation/career_milestone_service.gd")
const Post = preload("res://src/presentation/post_competition_presenter.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"one summary joins JGP debut and first Axel while retaining actual consequences","callable":joined},
		{"name":"career record keeps milestone after losing difficulty with optional archive link","callable":record},
		{"name":"ordinary JGP debut is meaningful without inventing a medal or first ever from partial history","callable":ordinary},
		{"name":"popped 3A result retains the failed attempt and reconnects to training without granting success","callable":failed_axel},
		{"name":"repeated valid 3A is not mislabeled as unsuccessful merely because its first milestone is older","callable":repeated_axel},
		{"name":"unsuccessful 3A feedback distinguishes an actual fall from a rotation problem","callable":axel_reason}]

func axel_reason() -> void:
	for variant in ["fall","rotation"]:
		var c = F.formal_junior_career(1835)
		var a := M.archive()
		if variant == "fall":
			a.free_results.player.performance.elements[0].actual = {"success":false,"fall":true}
		else:
			a.free_results.player.technical_review.final_elements[0].info = ["<"]
		var text := str(Post.build(c,a).training_evidence.text)
		T.assert_equal(text.contains("摔倒" if variant == "fall" else "周数"),true,"actual failure reason must remain understandable")

func repeated_axel() -> void:
	var c = F.formal_junior_career(1834)
	var a := M.archive()
	c.experience_state = Facts.preview(c.experience_state,a).next_state
	c.experience_state.milestones.first_formal_3a.event_id = "earlier_formal_event"
	var report := Post.build(c,a)
	T.assert_equal(report.training_evidence.text.contains("未记为有效足周完成"),false)

func failed_axel() -> void:
	var c = F.formal_junior_career(1833)
	var a := M.popped_axel_archive()
	c.experience_state = Facts.preview(c.experience_state,a).next_state
	var before := JSON.stringify(c.to_dict())
	var report := Post.build(c,a)
	T.assert_equal(c.experience_state.milestones.has("first_formal_3a"),false)
	T.assert_equal(report.training_evidence.text.contains("3A"),true)
	T.assert_equal(report.training_evidence.text.contains("2A"),true,"failed attempt feedback must show the actual executed jump")
	T.assert_equal(report.training_evidence.text.contains("尚未完成"),false,"final 2A call is resolved even when landing color was yellow")
	T.assert_equal(report.meaning.axel,false)
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func joined() -> void:
	var c = F.formal_junior_career(1830)
	var a := M.archive()
	c.experience_state = Facts.preview(c.experience_state,a).next_state
	var report := Post.build(c,a)
	T.assert_equal(report.get("memory_refs",[]).size(),3)
	T.assert_equal(report.performance.title.contains("JGP首秀"),true)
	T.assert_equal(report.training_evidence.text.contains("3A"),true)
	T.assert_equal(report.next_action.id,"return_home")
	var panel = load("res://src/app/summary_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var before := JSON.stringify(c.to_dict())
	panel.present_post_competition(c,a)
	T.assert_equal(JSON.stringify(c.to_dict()),before)
	T.assert_equal(panel.get_node("%Breakthroughs").text.contains("国际"),true)
	panel.free()

func record() -> void:
	var c = F.formal_junior_career(1831)
	var a := M.archive()
	c.experience_state = Facts.preview(c.experience_state,a).next_state
	c.technical_repertoire.entries = {}
	var panel = load("res://src/app/career_reference_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var before := JSON.stringify(c.to_dict())
	panel.present(c,"records")
	var button = panel.find_child("MilestoneArchive_0",true,false)
	T.assert_equal(button != null,true,"retained milestone must offer existing archive navigation")
	if button != null:
		var requested: Array = []
		panel.archive_requested.connect(func(id): requested.append(id))
		button.pressed.emit()
		T.assert_equal(requested,["isu_jgp_riga_2019"])
	T.assert_equal(JSON.stringify(c.to_dict()),before)
	panel.free()

func ordinary() -> void:
	var c = F.formal_junior_career(1832)
	c.experience_state.milestone_history.status = "partial"
	var a := M.archive()
	c.experience_state = Facts.preview(c.experience_state,a).next_state
	var report := Post.build(c,a)
	T.assert_equal(report.training_evidence.text.contains("首次"),false)
	T.assert_equal(report.performance.text.contains("奖牌"),false)
	T.assert_equal(report.performance.text.contains("国际"),true)
