extends RefCounted

const T = preload("res://tests/test_support.gd")
const ThemeFactory = preload("res://src/app/theme_factory.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"disabled button roles cannot resemble available primary actions","callable":test_disabled_roles},{"name": "career theme exposes semantic surfaces and button roles", "callable": test_semantic_theme},
		{"name":"custom windows paint a full content surface without intercepting input", "callable":test_custom_window_content},
		{"name":"embedded dialogs share career surfaces instead of default gray chrome", "callable":test_dialog_surfaces},
		{"name":"new-career overwrite dialog distinguishes risky and safe actions", "callable":test_overwrite_actions}]

func test_custom_window_content() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main._set_persistence_pending(true)
	await Engine.get_main_loop().process_frame
	main._set_persistence_pending(false)
	var event = load("res://src/app/event_dialog.tscn").instantiate()
	event.theme = ThemeFactory.create()
	main.add_child(event)
	var save_window = load("res://src/app/save_manager_panel.tscn").instantiate()
	var roadmap_window = load("res://src/app/development_roadmap_dialog.tscn").instantiate()
	main.add_child(save_window)
	main.add_child(roadmap_window)
	event.popup_centered(Vector2i(620,380))
	# Headless popup centering clamps to its virtual 1px screen; test the
	# actual content geometry at the sizes used by the application.
	event.size = Vector2i(620,380)
	main._persistence_wait.size = Vector2i(560,170)
	save_window.size = Vector2i(900,560)
	roadmap_window.size = Vector2i(800,500)
	await Engine.get_main_loop().process_frame
	for window in [event, main._persistence_wait, save_window, roadmap_window]:
		var surface = window.get_node_or_null("ContentSurface")
		T.assert_equal(surface != null, true, "custom dialog must paint its content")
		if surface == null: continue
		T.assert_equal(surface.size, Vector2(window.size))
		T.assert_equal(surface.mouse_filter, Control.MOUSE_FILTER_IGNORE)
		T.assert_equal(surface.get_theme_stylebox("panel").bg_color, ThemeFactory.SURFACE_PRIMARY)
	main.free()

func test_overwrite_actions() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	var dialog: ConfirmationDialog = main.new_career_confirmation
	T.assert_equal(dialog.get_ok_button().theme_type_variation,"DangerButton")
	T.assert_equal(dialog.get_cancel_button().theme_type_variation,"SecondaryButton")
	T.assert_equal(dialog.dialog_autowrap,true)
	main.free()

func test_dialog_surfaces() -> void:
	var theme := ThemeFactory.create()
	for item in [["panel","AcceptDialog"],["panel","PopupMenu"],["panel","ItemList"],["embedded_border","Window"],["embedded_unfocused_border","Window"]]:
		T.assert_equal(theme.has_stylebox(item[0],item[1]),true,"missing dialog surface " + item[0])
		if not theme.has_stylebox(item[0],item[1]): continue
		var style = theme.get_stylebox(item[0],item[1])
		T.assert_equal(style is StyleBoxFlat,true)
		if style is StyleBoxFlat:
			T.assert_equal(style.bg_color,ThemeFactory.SURFACE_PRIMARY)
	T.assert_equal(theme.get_constant("buttons_min_height","AcceptDialog") >= 40,true)

func test_semantic_theme() -> void:
	var palette: Dictionary = ThemeFactory.semantic_palette()
	for key in ["background", "surface_primary", "surface_secondary", "divider", "text", "text_muted", "ice_blue", "gold", "danger"]:
		T.assert_equal(palette.has(key), true, "missing semantic color " + key)
	var theme := ThemeFactory.create()
	for variation in ["PrimaryButton", "SecondaryButton", "GhostButton", "DangerButton", "NavButton", "SelectedNavButton"]:
		T.assert_equal(theme.get_type_variation_base(variation), "Button")

func test_disabled_roles() -> void:
	var theme := ThemeFactory.create()
	var primary_normal: StyleBoxFlat = theme.get_stylebox("normal","PrimaryButton")
	var primary_disabled: StyleBoxFlat = theme.get_stylebox("disabled","PrimaryButton")
	T.assert_equal(primary_disabled.bg_color != primary_normal.bg_color,true,"disabled primary must differ from available gold action")
	T.assert_equal(primary_disabled.bg_color != ThemeFactory.GOLD,true,"disabled primary must not remain gold")
	for variation in ["PrimaryButton","SecondaryButton","GhostButton","DangerButton","NavButton","SelectedNavButton"]:
		var disabled: StyleBoxFlat = theme.get_stylebox("disabled",variation)
		T.assert_equal(disabled.bg_color,Color("22303a"))
		T.assert_equal(disabled.border_color,Color("31414d"))
		T.assert_equal(theme.get_color("font_disabled_color",variation),ThemeFactory.MUTED)
