extends RefCounted
const T = preload("res://tests/test_support.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"2019 spring public editor can select next published season without modifying programme","callable":spring_choice},
		{"name":"next-season required edits retain order and charge ordinary familiarity","callable":incremental_save},
		{"name":"unsupported next season is not offered through compatibility fallback","callable":unsupported},
		{"name":"newly published 2020 season is offered without changing the saved programme","callable":newly_supported},
		{"name":"active competition locks target season selection","callable":locked},
		{"name":"public journey selects next-season rules during spring preparation","callable":journey_spring}]

func journey_spring() -> void:
	var s := setup()
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = s.main
	T.assert_equal(driver.has_method("_prepare_next_season"),true,"journey must prepare new rules before Q3 competitions")
	if not driver.has_method("_prepare_next_season"): s.main.free(); return
	var selected: Array = []
	s.editor.get_node("%TargetSeasonChoice").item_selected.connect(func(index): selected.append(s.editor.get_node("%TargetSeasonChoice").get_item_metadata(index)))
	driver._prepare_next_season()
	T.assert_equal(driver.errors,[])
	T.assert_equal(selected,[2019,2019],"SP and FS must use the same public target-season control")
	T.assert_equal(s.main.active_career.clock.to_dict(),{"year":2019,"quarter":1},"preparation must leave both spring quarters available for rehearsal")
	var saved: Dictionary = s.main.active_career.active_programs.short
	T.assert_equal(saved.elements.any(func(e): return e.spin_code == "FSSp"),true)
	T.assert_equal(saved.slot_familiarity.FSSp,0.0,"early preparation still pays ordinary edit cost")
	s.main.free()

func setup() -> Dictionary:
	var s = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	s.main.active_career.clock.year = 2019
	s.main.active_career.clock.quarter = 1
	s.main.open_program_editor("short")
	s.editor = s.main.get_node("%ProgramEditorPanel")
	return s

func choice(editor):
	var control = editor.get_node_or_null("%TargetSeasonChoice")
	T.assert_equal(control != null,true,"players need the same public next-season preparation choice as the journey")
	return control

func select_year(control, year: int) -> void:
	var index := -1
	for i in control.item_count:
		if int(control.get_item_metadata(i)) == year: index = i
	T.assert_equal(index >= 0,true,"published target season must be available")
	if index >= 0: control.select(index); control.item_selected.emit(index)

func spring_choice() -> void:
	var s := setup()
	var control = choice(s.editor)
	if control == null: s.main.free(); return
	var before := JSON.stringify(s.editor.program.to_dict())
	var career_before := JSON.stringify(s.main.active_career.to_dict())
	select_year(control,2019)
	T.assert_equal(s.editor.rules.season_start_year,2019)
	T.assert_equal(s.editor.status_label.text.contains("FSSp"),true,"new-season missing required spin must be explained")
	var spins: Array = []
	for i in s.editor.get_node("%SpinChoice").item_count: spins.append(s.editor.get_node("%SpinChoice").get_item_metadata(i))
	T.assert_equal(spins.has("CSp") and not spins.has("FCSp"),true,"spin menu must use the selected 2019 junior SP rules")
	T.assert_equal(JSON.stringify(s.editor.program.to_dict()),before,"rule selection must not redraft or charge familiarity")
	T.assert_equal(JSON.stringify(s.main.active_career.to_dict()),career_before)
	s.main.free()

func incremental_save() -> void:
	var s := setup()
	var control = choice(s.editor)
	if control == null: s.main.free(); return
	var before: Dictionary = s.main.active_career.active_programs.short.duplicate(true)
	select_year(control,2019)
	T.assert_equal(s.editor.replace_jump(2,"loop",2,[]),[])
	T.assert_equal(s.editor.set_spin_type(4,"FSSp"),[])
	s.editor.get_node("%SaveButton").pressed.emit()
	var saved: Dictionary = s.main.active_career.active_programs.short
	T.assert_equal(saved.program_id,before.program_id)
	T.assert_equal(saved.elements.map(func(e): return e.element_id),before.elements.map(func(e): return e.element_id))
	T.assert_equal(saved.slot_familiarity.axel,80.0)
	T.assert_equal(saved.slot_familiarity.get("solo",-1),0.0,"changed prescribed-jump slot must pay the normal revision cost")
	T.assert_equal(saved.slot_familiarity.FSSp,0.0)
	T.assert_equal(saved.whole_run_familiarity < 80.0 and saved.whole_run_familiarity > 70.0,true,"two seasonal requirement changes should create a limited, not total, familiarity cost")
	T.assert_equal(load("res://src/simulation/program_validator.gd").validate(load("res://src/domain/skating_program.gd").from_dict(saved),s.main.active_career.athlete,Rules.for_season(2019,"junior","short")),[])
	s.main.free()

func unsupported() -> void:
	var s := setup()
	s.main.active_career.clock.year = 2025
	s.main.active_career.clock.quarter = 3
	T.assert_equal(preload("res://src/content/season_bundle_repository.gd").load_bundle(2025,"women_singles","junior").errors,[],"fixture current season must be published")
	T.assert_equal(preload("res://src/content/season_bundle_repository.gd").load_bundle(2026,"women_singles","junior").errors.is_empty(),false,"fixture next season must lack a published bundle")
	T.assert_equal(Rules.for_season(2026,"junior","short").get("rule_origin"),"compatibility_generated","compatibility rules alone must not offer an unsupported season")
	s.main.open_program_editor("short")
	var control = choice(s.editor)
	if control != null:
		T.assert_equal(control.item_count,1)
		T.assert_equal(int(control.get_item_metadata(0)),2025)
	s.main.free()

func newly_supported() -> void:
	var s := setup()
	s.main.active_career.clock.quarter = 3
	var before := JSON.stringify(s.main.active_career.to_dict())
	s.main.open_program_editor("short")
	var control = choice(s.editor)
	if control != null:
		T.assert_equal(control.item_count,2)
		T.assert_equal(int(control.get_item_metadata(1)),2020)
		select_year(control,2020)
		T.assert_equal(int(s.editor.rules.season_start_year),2020)
		T.assert_equal(JSON.stringify(s.main.active_career.to_dict()),before,"previewing published rules must not commit programme edits")
	s.main.free()

func locked() -> void:
	var s := setup()
	var free_program = load("res://src/domain/skating_program.gd").from_dict(s.main.active_career.active_programs.free)
	s.editor.present(s.main.active_career,"free",Rules.for_season(2018,"junior","free"),{"program":free_program,"original_between_program":free_program})
	var control = choice(s.editor)
	if control != null:
		T.assert_equal(not control.is_visible_in_tree() or control.disabled,true)
		var before := JSON.stringify(s.editor.rules)
		if control.item_count>1: control.item_selected.emit(1)
		T.assert_equal(JSON.stringify(s.editor.rules),before,"between-segment rules cannot change after the event was locked")
	s.main.free()
