extends RefCounted

const T = preload("res://tests/test_support.gd")
const SCENE := "res://src/app/kiss_and_cry_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"kiss and cry reveals technical components and final in order", "callable":test_stages},
		{"name":"kiss and cry final stage exposes every safe exit", "callable":test_final_exits},
		{"name":"kiss and cry has no emotional choice controls", "callable":test_no_choices},
	]

func test_final_exits() -> void:
	var panel = load(SCENE).instantiate(); Engine.get_main_loop().root.add_child(panel)
	var actions := []
	panel.view_protocol_requested.connect(func(): actions.append("protocol"))
	panel.return_requested.connect(func(): actions.append("return"))
	panel.main_menu_requested.connect(func(): actions.append("menu"))
	panel.setup({})
	panel.advance_reveal(); panel.advance_reveal(); panel.advance_reveal()
	for name in ["ProtocolButton", "ReturnButton", "MainMenuButton"]:
		T.assert_equal(panel.get_node("%" + name).visible, true)
	panel.get_node("%ProtocolButton").pressed.emit()
	panel.get_node("%ReturnButton").pressed.emit()
	panel.get_node("%MainMenuButton").pressed.emit()
	T.assert_equal(actions, ["protocol", "return", "menu"])
	panel.free()

func test_stages() -> void:
	var panel = load(SCENE).instantiate(); Engine.get_main_loop().root.add_child(panel)
	panel.setup({"athlete_reaction":"我在等分。","revealed_athlete_reaction":"我完成了。","coach_reaction":"教练在身边。","pending_reviews":1,"tes":38.2,"pcs":31.4,"deductions":1.0,"segment_score":68.6,"total_score":121.4,"current_rank":5})
	T.assert_equal(panel.reveal_stage,"waiting"); T.assert_equal(panel.get_node("%ScoreBlock").visible,false)
	panel.advance_reveal(); T.assert_equal(panel.reveal_stage,"technical_confirmed"); T.assert_equal(panel.get_node("%TesValue").visible,true); T.assert_equal(panel.get_node("%PcsValue").visible,false)
	panel.advance_reveal(); T.assert_equal(panel.reveal_stage,"components_confirmed"); T.assert_equal(panel.get_node("%PcsValue").visible,true); T.assert_equal(panel.get_node("%FinalBlock").visible,false)
	panel.advance_reveal(); T.assert_equal(panel.reveal_stage,"final"); T.assert_equal(panel.get_node("%FinalBlock").visible,true)
	panel.free()

func test_no_choices() -> void:
	var panel = load(SCENE).instantiate(); Engine.get_main_loop().root.add_child(panel)
	T.assert_equal(panel.find_children("*Choice*","Button",true,false).size(),0)
	panel.free()
