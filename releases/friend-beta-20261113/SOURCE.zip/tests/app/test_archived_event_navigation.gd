extends RefCounted
const T = preload("res://tests/test_support.gd")
const Save = preload("res://src/persistence/save_repository.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"season calendar opens saved archive protocols without changing career or pending competition","callable":open_archive}]
func open_archive() -> void:
	var career = load("res://tests/persistence/test_compact_competition_archive.gd").new()._career()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	career.competition_state = load("res://src/simulation/formal_competition_simulator.gd").create_session(career,bundle.calendar.events[1],career.active_programs,"balanced",411,30)
	T.assert_equal(career.competition_state.get("errors",[]),[])
	T.assert_equal(Save.save(career,"user://archive-navigation.json").ok,true)
	var loaded := Save.load_save("user://archive-navigation.json")
	T.assert_equal(loaded.ok,true)
	var main = load("res://src/app/main.tscn").instantiate()
	main.save_path = "user://archive-navigation.json"; main.autosave_path = "user://archive-navigation-auto.json"
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(loaded.career); main.confirm_new_career_replacement()
	main.get_node("%CareerHomePanel").get_node("%SeasonNavButton").pressed.emit()
	var before := JSON.stringify(main.active_career.to_dict())
	var archive: Dictionary = main.active_career.competition_archive[0]
	var overview = main.get_node("%SeasonOverviewPanel")
	overview.select_event(archive.event_id)
	var button = overview.get_node("%LaunchEventButton")
	T.assert_equal(button.disabled,false,"completed event must be viewable, not launchable again")
	T.assert_equal(button.text,"查看比赛档案")
	button.pressed.emit()
	var panel = main.get_node("%FormalCompetitionPanel")
	T.assert_equal(panel.visible,true)
	_layout_now(panel)
	print("ARCHIVE_LAYOUT main=",main.size," panel=",panel.size," scroll=",panel.get_node("%StandingsList").get_parent().size)
	T.assert_equal(panel.size.x >= main.size.x*0.9,true,"archive must fill the career viewport, not shrink to its heading")
	T.assert_equal(panel.get_node("%StandingsList").get_parent().size.y >= 300,true,"archive standings need visible scroll space for the full field")
	if panel.visible:
		T.assert_equal(panel.get_node("%StandingsList").get_child_count(),archive.final_standings.size())
		var expanded: Dictionary = load("res://src/persistence/competition_archive_codec.gd").expand(archive)
		for row in archive.final_standings:
			panel.standing_button_for(row.athlete_id).pressed.emit()
			T.assert_equal(panel.get_node("%ProtocolOverlay").visible,true)
			T.assert_equal(panel._archive.short_results[row.athlete_id].protocol,expanded.short_results[row.athlete_id].protocol)
			if expanded.free_results.has(row.athlete_id): T.assert_equal(panel._archive.free_results[row.athlete_id].protocol,expanded.free_results[row.athlete_id].protocol)
		panel.archive_confirmed.emit()
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),before,"view and return must not mutate pending session, random streams, records, ranking or archive")
	T.assert_equal(overview.visible,true)
	if panel.visible == false and not button.disabled:
		overview.select_event(archive.event_id)
		button.pressed.emit()
		T.assert_equal(main.load_active_career().ok,true)
		panel.practice_response_selected.emit("accept")
		if main.active_career.competition_state.get("status") == "free_adjustment":
			await main._on_formal_adjustment_selected("keep")
		T.assert_equal(main.active_career.competition_state.get("status"),"complete")
		panel.archive_confirmed.emit()
		T.assert_equal(main.active_career.competition_state.is_empty(),true,"loading an active event must leave read-only archive mode and permit normal acknowledgement")
	main.free()

func _layout_now(node: Node) -> void:
	if node is Container: node.notification(Container.NOTIFICATION_SORT_CHILDREN)
	for child in node.get_children(): _layout_now(child)
