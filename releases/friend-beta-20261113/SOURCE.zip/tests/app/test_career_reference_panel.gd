extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "records and relationships are real read-only career screens", "callable": test_reference_sections},
		{"name": "long dated training history stays inside 960 viewport with reachable archive", "callable": func(): test_long_history(Vector2(760,480))},
		{"name": "long dated training history stays inside 1280 viewport with reachable archive", "callable": func(): test_long_history(Vector2(1040,640))},
		{"name": "Olympic selection explanation wraps within the compact home card", "callable": test_selection_explanation},
	]

func test_selection_explanation() -> void:
	var panel = load("res://src/app/career_home_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.size = Vector2(800,500)
	var career = F.starting_career(94005)
	career.clock.year = 2022; career.clock.quarter = 1
	career.beijing_trial_series.status = "finalized"
	career.beijing_trial_series.finalization = {"status":"confirmed","places":3,"selected_ids":["player"]}
	panel.present(career)
	for pass_index in 6: _layout(panel)
	var detail: Label = panel.get_node("%CurrentEventDetail")
	T.assert_equal(detail.text.contains("奥运报名"),true)
	T.assert_equal(detail.get_line_count() > 1,true,"full dispatch explanation must wrap, not draw behind the right rail")
	T.assert_equal(detail.get_global_rect().end.x <= panel.get_node("%RightRail").get_global_rect().position.x,true)
	panel.free()

func test_long_history(view_size: Vector2) -> void:
	var panel = load("res://src/app/career_reference_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.size = view_size
	var career = F.starting_career(94004)
	for day in 500:
		career.history.append({"category":"dated_training","summary_key":"dated_training_day","date":"2022-01-01"})
	career.experience_state.milestones = {"first_jgp_complete":{"certainty":"confirmed_first","event_date":"2019-08-30","event_id":"test_archive","event_name":"测试比赛"}}
	var before := JSON.stringify(career.to_dict())
	panel.present(career,"records")
	for pass_index in 4: _layout(panel)
	T.assert_equal(panel.get_combined_minimum_size().y <= view_size.y,true,"history must scroll instead of enlarging the entire career screen")
	var button = panel.find_child("MilestoneArchive_0",true,false)
	T.assert_equal(button != null,true)
	if button != null:
		var requests: Array = []
		panel.archive_requested.connect(func(id): requests.append(id))
		button.pressed.emit()
		T.assert_equal(requests,["test_archive"])
		var scroll: ScrollContainer = null
		var ancestor = button.get_parent()
		while ancestor != null and ancestor != panel:
			if ancestor is ScrollContainer: scroll = ancestor; break
			ancestor = ancestor.get_parent()
		T.assert_equal(scroll != null,true,"archive and complete history need a bounded scroll viewport")
	T.assert_equal(panel.get_node("%FactsText").text.count("2022-01-01 · 按日训练"),500,"daily history must retain dates and readable meaning instead of internal codes")
	T.assert_equal(JSON.stringify(career.to_dict()),before)
	panel.free()

func _layout(node: Node) -> void:
	if node is Container: node.notification(Container.NOTIFICATION_SORT_CHILDREN)
	for child in node.get_children(): _layout(child)

func test_reference_sections() -> void:
	T.assert_equal(ResourceLoader.exists("res://src/app/career_reference_panel.tscn"), true)
	if not ResourceLoader.exists("res://src/app/career_reference_panel.tscn"): return
	var panel = load("res://src/app/career_reference_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = F.starting_career(94003)
	career.history.append({"summary_key": "第一次完整滑完节目"})
	panel.present(career, "records")
	T.assert_equal(panel.get_node("%SectionTitle").text, "生涯履历")
	T.assert_equal(panel.get_node("%FactsText").text.contains("第一次完整滑完节目"), true)
	panel.present(career, "relationships")
	T.assert_equal(panel.get_node("%SectionTitle").text, "关系与支持")
	T.assert_equal(panel.get_node("%FactsText").text.is_empty(), false)
	panel.free()
