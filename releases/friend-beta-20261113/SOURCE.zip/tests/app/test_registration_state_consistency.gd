extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Clock = preload("res://src/domain/game_clock.gd")
const Calendar = preload("res://src/content/season_calendar_repository.gd")
const Planner = preload("res://src/simulation/season_calendar_planner.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"refresh keeps timeline card details and action on one status", "callable":test_refresh_consistency}]

func test_refresh_consistency() -> void:
	var career = F.starting_career(1818)
	career.clock = Clock.new(2018, 3)
	var loaded := Calendar.load_calendar(2018, "CHN", "women_singles")
	var proposal := Planner.propose(career, loaded.calendar, {"junior_min_age":13,"junior_max_age":18,"age_cutoff":{"month":7,"day":1}})
	var plan: Dictionary = proposal.plan.to_dict()
	var event_id := "cn_grand_prix_u_series_2018"
	plan.entries[event_id].status = "confirmed"
	plan.entries[event_id].eligibility_snapshot.eligible = true
	var panel = load("res://src/app/season_overview_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(career, loaded.calendar, plan)
	panel.select_event(event_id)
	T.assert_equal(panel.get_node("%EligibilityDetails").text.contains("已报名"), true)
	T.assert_equal(panel.get_node("%LaunchEventButton").text, "前往比赛")
	plan.entries[event_id].status = "blocked"
	panel.refresh_entry_plan(plan)
	panel.select_event(event_id)
	T.assert_equal(panel.get_node("%EligibilityDetails").text.contains("暂不可报名"), true)
	T.assert_equal(panel.get_node("%LaunchEventButton").disabled, true)
	for card in panel.get_node("%EventList").get_children():
		if card.get_meta("event_id", "") == event_id:
			T.assert_equal(card.get_node("CardLayout/StatusLabel").text.contains("暂不可报名"), true)
	panel.free()
