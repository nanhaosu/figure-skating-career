extends SceneTree

func _initialize() -> void:
	call_deferred("probe")

func probe() -> void:
	var failed := false
	for dimensions in [Vector2i(1024,768),Vector2i(1280,960)]:
		failed = _setup(dimensions) or failed
		for i in 8: await process_frame
		failed = _check(dimensions) or failed
		_viewport.free()
	quit(1 if failed else 0)

var _viewport: SubViewport
var _panel: Control

func _setup(dimensions: Vector2i) -> bool:
	var viewport := SubViewport.new()
	_viewport = viewport
	viewport.size = dimensions
	root.add_child(viewport)
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://no-layout-autosave.json"
	viewport.add_child(main)
	# UI-only protocol fixture; this probe never creates or scores a career.
	var rows: Array = []
	for i in 30: rows.append({"athlete_id":"npc-%d" % i,"rank":i+1,"name":"布局选手%d" % i,"short_score":40.0,"total_score":110.0})
	var protocol := {"tes":20.0,"pcs":20.0,"total":40.0,"element_scores":[]}
	var archive := {"final_standings":rows,"short_results":{"npc-0":{"protocol":protocol}},"free_results":{},"roster":[],"consequence_summary":{}}
	var panel = main.get_node("%FormalCompetitionPanel")
	_panel = panel
	panel.present_session(archive.merged({"archive":archive}))
	panel.present_final_archive(archive)
	main._show_screen(panel)
	panel.standing_button_for("npc-0").pressed.emit()
	return false

func _check(dimensions: Vector2i) -> bool:
	var panel = _panel
	var scroll: Control = panel.get_node("%StandingsList").get_parent()
	print("ARCHIVE_BOUNDS viewport=",dimensions," panel=",panel.size," scroll=",scroll.size," rows=",panel.get_node("%StandingsList").get_child_count())
	var failed: bool = panel.size.x < dimensions.x or panel.size.y < dimensions.y or scroll.size.y < 300
	var overlay: Control = panel.get_node("%ProtocolOverlay")
	print("PROTOCOL_BOUNDS ",overlay.get_global_rect()," visible=",overlay.is_visible_in_tree())
	failed = failed or not overlay.is_visible_in_tree() or overlay.size.y < 500 or not panel.get_node("%ProtocolView").get_node("%ProtocolTotal").text.contains("40.00")
	if failed: push_error("archive must expose scrollable standings and readable protocols at 1024x768")
	return failed
