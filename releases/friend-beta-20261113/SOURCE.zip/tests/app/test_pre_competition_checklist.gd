extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Checklist = preload("res://src/app/pre_competition_checklist_service.gd")
const Validator = preload("res://src/simulation/program_validator.gd")
const Program = preload("res://src/domain/skating_program.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"transition event health uses the actual secondary group programmes", "callable":test_secondary_health},
		{"name":"confirmed season programme is reused without another per-event lock","callable":test_season_confirmation},
		{"name":"missing programs produce repair edit and return paths","callable":test_missing_program_paths},
		{"name":"coach repair creates legal programs without mutating career","callable":test_repair_is_legal_and_read_only},
		{"name":"insufficient technique explains why auto repair is unavailable","callable":test_unrepairable_program},
		{"name":"legal drafts still require an explicit competition lock","callable":test_legal_draft_requires_lock},
	]

func test_secondary_health() -> void:
	var career = F.formal_junior_career(936)
	career.season_program_plan.competitive_level = "transition"
	var event: Dictionary = Bundle.load_bundle(2018,"women_singles","junior").calendar.events.filter(func(e):return e.event_id == "cn_national_championships_2018")[0]
	var resolved := Bundle.competition_for_career(career,event)
	T.assert_equal(resolved.errors,[])
	var secondary := {}
	for segment in ["short","free"]:
		var draft := preload("res://src/simulation/program_draft_service.gd").legal_draft(career.athlete,segment,resolved.rules[segment].segment_rules,{},936)
		T.assert_equal(draft.program != null,true)
		if draft.program == null: return
		secondary[segment] = draft.program.to_dict()
		secondary[segment].draft_status = "locked"
		secondary[segment].locked_segments = [segment]
	career.season_program_plan.programs_by_level = {"junior":career.active_programs.duplicate(true),"senior":secondary}
	career.active_programs.short.elements[1].rotations = 4
	career.condition_state.function_limits = {"landing":{"maximum_rotations":3}}
	var before := JSON.stringify(career.to_dict())
	var result := Checklist.inspect(career,event)
	T.assert_equal(result.items.filter(func(item):return item.id == "health")[0].status,"ready","unused primary quad must not block safe secondary senior programme")
	T.assert_equal(result.ready,true)
	T.assert_equal(JSON.stringify(career.to_dict()),before)

func test_season_confirmation() -> void:
	var career = F.formal_junior_career(935)
	for segment in ["short","free"]:
		career.active_programs[segment].draft_status = "draft"
		career.active_programs[segment].locked_segments = []
	career.season_program_plan.programs = career.active_programs.duplicate(true)
	var before: Dictionary = career.to_dict()
	T.assert_equal(Checklist.inspect(career,_event()).ready,true)
	T.assert_equal(career.to_dict(),before)

func test_legal_draft_requires_lock() -> void:
	var career = F.formal_junior_career(934)
	for segment in ["short","free"]:
		career.active_programs[segment].draft_status = "draft"
		career.active_programs[segment].locked_segments = []
	var result: Dictionary = Checklist.inspect(career,_event())
	T.assert_equal(result.ready,false)
	var short: Dictionary = result.items.filter(func(item): return item.id == "program_short")[0]
	T.assert_equal(short.status,"repairable")
	T.assert_equal(str(short.reason).contains("仍是草稿"),true)
	for segment in ["short","free"]:
		career.active_programs[segment].draft_status = "locked"
		career.active_programs[segment].locked_segments = [segment]
	result = Checklist.inspect(career,_event())
	T.assert_equal(result.ready,true)

func _event() -> Dictionary:
	var bundle := Bundle.load_bundle(2018,"women_singles","junior")
	return bundle.calendar.events[0]

func test_missing_program_paths() -> void:
	var career = F.formal_junior_career(931)
	career.active_programs = {}
	var result: Dictionary = Checklist.inspect(career,_event())
	T.assert_equal(result.ready,false)
	var short: Dictionary = result.items.filter(func(item): return item.id == "program_short")[0]
	T.assert_equal(short.status,"repairable")
	T.assert_equal(short.actions.map(func(action): return action.id).has("adopt_coach_program"),true)
	T.assert_equal(result.actions.map(func(action): return action.id).has("return_to_season"),true)

func test_repair_is_legal_and_read_only() -> void:
	var career = F.formal_junior_career(932)
	career.active_programs = {}
	var before := career.to_dict()
	var repaired: Dictionary = Checklist.repair(career,_event())
	T.assert_equal(repaired.errors,[])
	T.assert_equal(career.to_dict(),before)
	var resolved := Bundle.competition_event(_event())
	for segment in ["short","free"]:
		T.assert_equal(Validator.validate(Program.from_dict(repaired.programs[segment]),career.athlete,resolved.rules[segment].segment_rules),[])

func test_unrepairable_program() -> void:
	var career = F.formal_junior_career(933)
	for jump in career.athlete.jumps.values(): jump.unlocked_rotations = 1
	career.active_programs = {}
	var result: Dictionary = Checklist.inspect(career,_event())
	var short: Dictionary = result.items.filter(func(item): return item.id == "program_short")[0]
	T.assert_equal(short.status,"blocked")
	T.assert_equal(short.actions.map(func(action): return action.id).has("adopt_coach_program"),false)
	T.assert_equal(str(short.reason).contains("已掌握动作"),true)
