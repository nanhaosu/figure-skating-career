extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")

const PANEL_SCENE := "res://src/app/pre_career_history_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name": "history panel presents the complete generated childhood", "callable": test_present_complete_history},
		{"name": "history panel continues only once per presentation", "callable": test_continue_once},
		{"name": "history panel keeps a reachable footer at minimum viewport", "callable": test_minimum_viewport_layout},
	]

func test_present_complete_history() -> void:
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = _career()
	panel.present(career)
	var rendered := _all_label_text(panel)
	TestSupport.assert_equal(rendered.contains(career.athlete.display_name), true)
	TestSupport.assert_equal(rendered.contains("4岁"), true)
	TestSupport.assert_equal(rendered.contains("累计训练3年"), true)
	for episode in career.pre_career_history.episodes:
		TestSupport.assert_equal(rendered.contains(str(episode.text)), true)
	TestSupport.assert_equal(rendered.contains(str(career.pre_career_history.coach_assessment)), true)
	TestSupport.assert_equal(rendered.contains("暂无已经明确的技术提醒"), true)
	panel.free()

func test_continue_once() -> void:
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var continued: Array[int] = []
	panel.continued.connect(func(): continued.append(1))
	panel.present(_career())
	panel.get_node("%ContinueButton").pressed.emit()
	panel.get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(continued.size(), 1)
	panel.free()

func test_minimum_viewport_layout() -> void:
	var panel: Control = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(_career())
	await panel.get_tree().process_frame
	TestSupport.assert_equal(panel.get_combined_minimum_size().y <= 540.0, true, "history panel minimum is %s" % panel.get_combined_minimum_size())
	TestSupport.assert_equal(panel.get_node("%HistoryScroll") is ScrollContainer, true)
	TestSupport.assert_equal(panel.get_node("%ContinueButton").visible, true)
	panel.free()

func _career():
	return CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, CatalogRepository.load_catalog(), 4).career

func _all_label_text(node: Node) -> String:
	var result := ""
	if node is Label: result += "%s\n" % node.text
	for child in node.get_children(): result += _all_label_text(child)
	return result
