extends RefCounted

const T = preload("res://tests/test_support.gd")
const BroadcastFixture = preload("res://tests/app/test_broadcast_playback.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"broadcast exposes rink live scoring level commentary and speed", "callable":test_broadcast_information},
		{"name":"broadcast geometry fits supported web viewports", "callable":test_web_geometry},
		{"name":"normal playback keeps short and free program rule durations", "callable":test_segment_durations},
		{"name":"short cut and complete free archive remain inspectable", "callable":test_cut_and_archive},
	]

func test_web_geometry() -> void:
	var output: Array = []
	var code := OS.execute(OS.get_executable_path(), ["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/app/broadcast_layout_probe.gd"], output, true)
	T.assert_equal(code, 0, "broadcast geometry probe: %s" % "".join(output))

func _panel():
	var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var fixture = BroadcastFixture.new()
	panel.present_session(fixture._session())
	return panel

func test_broadcast_information() -> void:
	var panel = _panel()
	var fixture = BroadcastFixture.new()
	panel.show_segment(fixture._record())
	panel._elapsed = 1.0
	panel._reveal_due_elements()
	panel._finalize_technical_calls()
	var technical = panel.get_node("%TechnicalPanel")
	var row: Control = technical.get_node("%ElementList").get_child(0)
	var score_text := str(row.get_node("Score").text)
	T.assert_equal(score_text.contains("CCoSp3"), true)
	T.assert_equal(score_text.contains("基础分"), true)
	T.assert_equal(score_text.contains("GOE"), true)
	T.assert_equal(panel.get_node_or_null("%CompetitionIceView") != null, true)
	T.assert_equal(panel.get_node("%CommentaryDesk").text.contains("解说台"), true)
	for path in ["%Speed1x","%Speed15x","%Speed2x","%QuickButton"]:
		T.assert_equal(panel.get_node_or_null(path) != null, true)
	panel.free()

func test_segment_durations() -> void:
	var panel = _panel()
	var fixture = BroadcastFixture.new()
	panel.show_segment(fixture._record("short"))
	T.assert_equal(panel._normal_duration, 160.0)
	panel.show_segment(fixture._record("free"))
	T.assert_equal(panel._normal_duration, 210.0)
	T.assert_equal(panel.playback_duration_seconds("normal", {"duration_seconds":210}), 210.0)
	panel.free()

func test_cut_and_archive() -> void:
	var panel = _panel()
	var fixture = BroadcastFixture.new()
	var session := fixture._session()
	var rows: Array = []
	for index in 25:
		rows.append({"athlete_id":"player" if index == 24 else "npc-%d" % index,"name":"选手%d" % index,"rank":index+1,"short_score":60.0-index,"qualified":index<24,"is_player":index==24})
	panel.present_short_standings(rows)
	T.assert_equal(panel.get_node("%StandingsHeading").text.contains("前24名"), true)
	T.assert_equal(panel.get_node("%AdjustmentChoices").visible, false)
	var archive: Dictionary = Dictionary(session.archive).duplicate(true)
	archive.final_standings = rows.slice(0,24)
	archive.short_standings = rows
	panel.present_final_archive(archive)
	T.assert_equal(panel.get_node("%StandingsList").get_child_count(), 25)
	T.assert_equal(panel.standing_button_for("npc-0") != null, true)
	panel.free()
