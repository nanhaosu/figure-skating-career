extends RefCounted

const T = preload("res://tests/test_support.gd")
const ScreenRoute = preload("res://src/app/screen_route.gd")
const CareerScreenRouter = preload("res://src/app/career_screen_router.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "career router restores screens in last-opened order", "callable": test_push_and_back},
		{"name": "screen routes isolate mutable context", "callable": test_context_isolation},
		{"name": "replace changes the current screen without adding history", "callable": test_replace},
		{"name": "back without history falls back to career home", "callable": test_empty_history_fallback},
		{"name": "unknown saved screen resolves to the supplied safe fallback", "callable": test_stale_route_fallback},
	]

func test_push_and_back() -> void:
	var router = CareerScreenRouter.new(["career_home", "training", "program"])
	router.reset(ScreenRoute.create("career_home"))
	router.open(ScreenRoute.create("training"))
	router.open(ScreenRoute.create("program", {"segment": "short"}))
	T.assert_equal(router.can_back(), true)
	T.assert_equal(router.back().screen_id, "training")
	T.assert_equal(router.back().screen_id, "career_home")

func test_context_isolation() -> void:
	var context := {"event_id": "club_test", "elements": ["2A"]}
	var return_route := ScreenRoute.create("training", {"quarter": 2})
	var route := ScreenRoute.create("program", context, return_route)
	context.elements.append("3T")
	return_route.context.quarter = 4
	T.assert_equal(route.context.elements, ["2A"])
	T.assert_equal(route.return_route.context.quarter, 2)
	var router = CareerScreenRouter.new(["career_home", "program", "training"])
	router.reset(route)
	var exposed: Dictionary = router.current()
	exposed.context.elements.append("4T")
	T.assert_equal(router.current().context.elements, ["2A"])

func test_replace() -> void:
	var router = CareerScreenRouter.new(["career_home", "training", "season"])
	router.reset(ScreenRoute.create("career_home"))
	router.open(ScreenRoute.create("training"))
	router.replace(ScreenRoute.create("season"))
	T.assert_equal(router.current().screen_id, "season")
	T.assert_equal(router.back().screen_id, "career_home")

func test_empty_history_fallback() -> void:
	var router = CareerScreenRouter.new(["career_home", "training"])
	router.reset(ScreenRoute.create("training"))
	T.assert_equal(router.can_back(), false)
	T.assert_equal(router.back().screen_id, "career_home")

func test_stale_route_fallback() -> void:
	var router = CareerScreenRouter.new(["career_home", "training"])
	var safe := ScreenRoute.create("training", {"quarter": 3})
	router.reset(ScreenRoute.create("removed_screen"), safe)
	T.assert_equal(router.current(), safe)
