extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"mounted target board previews preparation costs without writes and only emits explicit choice","callable":board},{"name":"preparation main handler commits target and training only after durable save and allows retry","callable":atomic_save}]
func board() -> void:
	var c = F.formal_junior_career(966)
	c.season_state.season_id = "2018-19"
	c.season_state.target_event_id = F.u_series_event().event_id
	c.competition_timeline.mode = "dated"
	c.competition_timeline.date = "2018-07-01"
	c.competition_timeline.origin_date = "2018-07-01"
	c.competition_timeline.quarter_progress = 1
	var calendar: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(c).calendar
	var before: Dictionary = c.to_dict().duplicate(true)
	var window = load("res://src/app/season_target_dialog.gd").new()
	Engine.get_main_loop().root.add_child(window)
	window.present(c,calendar,{})
	await Engine.get_main_loop().process_frame
	var picker = window.find_child("PreparationRouteChoice",true,false)
	var confirm = window.find_child("ApplyPreparationButton",true,false)
	T.assert_equal(picker != null and confirm != null,true,"real target window must expose preparation choice")
	if picker != null and confirm != null:
		var emitted: Array = []
		window.preparation_requested.connect(func(route,event,revision):emitted.append([route,event,revision]))
		for i in [1,2,0]:
			picker.select(i); picker.item_selected.emit(i)
			T.assert_equal(window.find_child("TargetDetails",true,false).text.contains("实际课时"),true)
		T.assert_equal(emitted,[])
		T.assert_equal(confirm.disabled,false)
		confirm.pressed.emit()
		T.assert_equal(emitted.size(),1)
		if emitted.size() == 1: T.assert_equal(emitted[0][0],"combination")
	var edits: Array=[]
	window.preparation_program_requested.connect(func(event,segment):edits.append([event,segment]))
	for segment in ["Short","Free"]:
		var button=window.find_child("PreparationEdit"+segment,true,false)
		T.assert_equal(button!=null,true,"early rule-aware programme editor must be reachable")
		if button!=null:button.pressed.emit()
	T.assert_equal(edits,[[F.u_series_event().event_id,"short"],[F.u_series_event().event_id,"free"]])
	T.assert_equal(c.to_dict(),before)
	window.hide(); window.queue_free()
	await Engine.get_main_loop().process_frame

func atomic_save() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	var c = F.formal_junior_career(967)
	c.season_state.season_id = "2018-19"
	c.competition_timeline.mode = "dated"
	c.competition_timeline.date = "2018-07-01"
	c.competition_timeline.origin_date = "2018-07-01"
	c.competition_timeline.quarter_progress = 1
	main.active_career = c
	main.season_overview_panel.present(c,preload("res://src/content/season_bundle_repository.gd").for_career(c).calendar,{})
	var before: Dictionary = c.to_dict().duplicate(true)
	main.autosave_path = "user://preparation-missing-parent-967/slot.json"
	await main._on_preparation_route_selected("programme",F.u_series_event().event_id,0)
	T.assert_equal(main.active_career.to_dict(),before,"failed write must preserve target direction and programme together")
	T.assert_equal(main._decision_busy,false)
	main.autosave_path = "user://preparation-main-atomic.json"
	await main._on_preparation_route_selected("programme",F.u_series_event().event_id,0)
	T.assert_equal(main.active_career.training_direction.revision,1)
	T.assert_equal(main.active_career.season_state.target_event_id,F.u_series_event().event_id)
	T.assert_equal(main.active_career.active_programs,before.active_programs)
	var loaded: Dictionary = preload("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true)
	if loaded.ok:
		T.assert_equal(loaded.career.training_direction,main.active_career.training_direction)
		T.assert_equal(loaded.career.season_program_plan.preparation,main.active_career.season_program_plan.preparation)
	main.queue_free()
	await Engine.get_main_loop().process_frame
