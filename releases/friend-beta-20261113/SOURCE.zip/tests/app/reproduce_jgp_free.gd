extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var loaded = load("res://src/persistence/save_repository.gd").load_save("C:/Users/25775/Desktop/figure_skating/qa-runs/remediation-final-long-20261008/Godot/app_userdata/花样滑冰生涯/journey-planned-41046-autosave.json")
	print("LOAD ",loaded.get("errors",[]))
	var main = load("res://src/app/main.tscn").instantiate()
	main.save_path = "user://reproduce-main.json"
	main.autosave_path = "user://reproduce-auto.json"
	root.add_child(main)
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = main
	driver._adopt(loaded.career)
	await main._on_formal_adjustment_selected("keep")
	print("KEEP_EDITOR_VISIBLE ",main.get_node("%ProgramEditorPanel").visible)
	print("STATUS ",main.active_career.competition_state.get("status"))
	print("MESSAGE ",main.get_node("%GlobalMessage").text)
	main.free()
	quit()
