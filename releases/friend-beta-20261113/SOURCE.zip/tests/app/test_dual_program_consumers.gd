extends RefCounted
const T = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/integration/test_dual_level_programs.gd")
const B = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"secondary safe programme reaches actual Main competition start despite unused primary quad", "callable":medical_main_start},
		{"name":"secondary safe programme passes chronological check in despite unused primary quad", "callable":medical_progression},
		{"name":"event adjustment opens the saved event group programme not the primary group", "callable":open_event_group},
		{"name":"editing secondary event programme durably preserves primary training programme", "callable":edit_secondary},
		{"name":"season progression checks actual senior programme before other entry gates", "callable":progression},
		{"name":"between segment senior free revision preserves junior programme on disk", "callable":between_segments},
		{"name":"secondary medical fallback updates only its event group and rejects stale source", "callable":medical_fallback},
	]

func _medical_entrant():
	var fixture = Fixtures.new()
	var c = fixture._career()
	if not fixture._ready(c): return null
	c.clock.quarter = 4
	c.certification_state.national_technical_grade = 7
	c.competition_archive.assign([preload("res://tests/simulation/test_senior_gp_invitation.gd").new()._prior()])
	var applied: Dictionary = load("res://src/simulation/career_command_service.gd").apply(c,{"type":"apply_entry","event_id":"isu_gpusa2021","route_id":"enter"})
	T.assert_equal(applied.ok,true,str(applied.get("error","")))
	if not applied.ok: return null
	c = applied.career
	c.active_programs.short.elements.filter(func(e):return e.kind == "jump")[0].rotations = 4
	c.condition_state.function_limits = {"landing":{"maximum_rotations":3}}
	return c

func medical_main_start() -> void:
	var c = _medical_entrant()
	if c == null: return
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = c
	main.autosave_path = "user://secondary-medical-start.json"
	var primary := _program_hash(c.active_programs)
	var started: Dictionary = await main.start_formal_competition("isu_gpusa2021")
	T.assert_equal(started.ok,true,str(started.get("errors",[])))
	if started.ok:
		T.assert_equal(main.active_career.competition_state.status,"practice_ready")
		T.assert_equal(main._competition_medically_blocked(),false,"active formal practice and replay must use the locked actual roster programme")
		T.assert_equal(_program_hash(main.active_career.active_programs),primary)
		var read: Dictionary = load("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
		T.assert_equal(read.ok,true,str(read.errors))
		if read.ok: T.assert_equal(read.career.competition_state.event_id,"isu_gpusa2021")
	main.free()

func medical_progression() -> void:
	var c = _medical_entrant()
	if c == null: return
	_at_gp_check_in(c)
	var b := B.for_career(c)
	b.calendar.events = [Fixtures.new()._event("isu_gpusa2021")]
	var before := JSON.stringify(c.to_dict())
	var result: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(c,b,func(_candidate):return false)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.stop_node.kind,"competition_check_in",str(result.stop_node))
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func open_event_group() -> void:
	var fixture = Fixtures.new()
	var c = fixture._career()
	if not fixture._ready(c): return
	c.season_program_plan.programs_by_level.senior.free.music = {"title":"独立成年自由滑"}
	var event := fixture._event("isu_gpusa2021")
	var resolved := B.competition_for_career(c,event)
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = c
	main._present_program_adjustment({"event_id":event.event_id,"segment":"free","rules":resolved.rules.free.segment_rules})
	main._decision_dialog.find_child("EditProgram",true,false).pressed.emit()
	T.assert_equal(main.program_editor_panel.program.music.get("title"),"独立成年自由滑")
	T.assert_equal(main.program_editor_panel.program.elements.size(),12)
	main.free()

func edit_secondary() -> void:
	var fixture = Fixtures.new()
	var c = fixture._career()
	if not fixture._ready(c): return
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = c
	main.autosave_path = "user://secondary-edit-route.json"
	main._pending_program_event_id = "isu_gpusa2021"
	var primary := _program_hash(c.active_programs)
	var edited: Dictionary = c.season_program_plan.programs_by_level.senior.free.duplicate(true)
	edited.music = {"title":"成年自由滑新版本"}
	await main._on_program_saved("free",edited)
	T.assert_equal(_program_hash(main.active_career.active_programs),primary,"secondary edit must not overwrite the primary programme")
	T.assert_equal(main.active_career.season_program_plan.programs_by_level.senior.free.music.get("title"),"成年自由滑新版本")
	var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true)
	if loaded.ok:
		T.assert_equal(_program_hash(loaded.career.active_programs),primary,"primary programme persists unchanged")
		T.assert_equal(loaded.career.season_program_plan.programs_by_level.senior.free.elements.size(),12)
	main.free()

func progression() -> void:
	var fixture = Fixtures.new()
	var c = fixture._career()
	if not fixture._ready(c): return
	c.clock.quarter = 4
	var event := fixture._event("isu_gpusa2021")
	var b := B.for_career(c)
	b.calendar.events = [event]
	# Valid historical acceptance; live eligibility must still be rechecked.
	c.season_state.season_id = b.calendar.season_id
	c.season_state.entry_plan = {"season_id":b.calendar.season_id,"proposal_version":1,"entries":{"isu_gpusa2021":{"status":"confirmed","requested_levels":["senior"],"route":"federation_assignment","funding_source":"association","coach_recommendation":"historical acceptance","player_override":"","available_adjustment_ids":[],"eligibility_snapshot":{"eligible":true},"reason_codes":[]}}}
	T.assert_equal(preload("res://src/domain/season_entry_plan.gd").validate(c.season_state.entry_plan),[])
	_at_gp_check_in(c)
	c.season_state.event_statuses = {"isu_gpusa2021":"confirmed"}
	c.selection_state.assignments.player = ["isu_gpusa2021"]
	var before := JSON.stringify(c.to_dict())
	var result: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(c,b,func(_candidate):return false)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.stop_node.kind in ["entry_revalidation","competition_check_in"],true,str(result.stop_node))
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func _program_hash(programs: Dictionary) -> String:
	var normalized := {}
	for segment in programs:
		var program = load("res://src/domain/skating_program.gd").from_dict(programs[segment])
		if program != null: normalized[segment] = program.to_dict()
	return JSON.stringify(normalized).sha256_text()

func between_segments() -> void:
	var fixture = Fixtures.new()
	var c = fixture._career()
	if not fixture._ready(c): return
	# This test isolates secondary programme persistence. GP invitations now
	# require a prior international result, independently exercised with a real
	# full field in test_senior_gp_invitation::real_results.
	c.competition_archive.assign([preload("res://tests/simulation/test_senior_gp_invitation.gd").new()._prior()])
	var event := fixture._event("isu_gpusa2021")
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	c.selection_state.assignments.player = [event.event_id]
	var programs: Dictionary = c.season_program_plan.programs_by_level.senior
	var session: Dictionary = sim.create_session(c,event,programs,"balanced",6013)
	T.assert_equal(session.get("errors",[]),[])
	if not session.get("errors",[]).is_empty(): return
	# This isolates the actual between-segment consumer; roster acceptance is
	# tested independently. Both player segments still execute real scoring.
	session.roster = session.roster.filter(func(row): return row.is_player)
	session.status = "short_ready"
	session = sim.lock_short(c,session)
	T.assert_equal(session.get("errors",[]),[])
	T.assert_equal(session.status,"free_adjustment")
	if session.status != "free_adjustment": return
	c.competition_state = session
	var primary := _program_hash(c.active_programs)
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = c
	main.autosave_path = "user://secondary-between-segments.json"
	main._pending_free_adjustment = "keep"
	await main._confirm_formal_free(programs.free)
	T.assert_equal(main.active_career.competition_state.status,"complete")
	T.assert_equal(_program_hash(main.active_career.active_programs),primary,"senior free skate must not replace junior training programme")
	var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true)
	if loaded.ok:
		T.assert_equal(_program_hash(loaded.career.active_programs),primary)
		T.assert_equal(loaded.career.season_program_plan.programs_by_level.senior.free.elements.size(),12)
	main.free()

func medical_fallback() -> void:
	var fixture = Fixtures.new()
	var c = fixture._career()
	if not fixture._ready(c): return
	c.condition_state.function_limits = {"landing":{"maximum_rotations":2}}
	var event := fixture._event("isu_gpusa2021")
	var resolved := B.competition_for_career(c,event)
	var rules := {"free":resolved.rules.free.segment_rules}
	var service = load("res://src/simulation/program_fallback_service.gd")
	var proposal: Dictionary = service.propose(c,{"free":c.season_program_plan.programs_by_level.senior.free},rules)
	T.assert_equal(proposal.changed,true)
	T.assert_equal(proposal.legal,true)
	if not proposal.legal: return
	proposal.event = resolved.event.duplicate(true)
	proposal.source_hash = service._hash(c.season_program_plan.programs_by_level.senior)
	var original := _program_hash(c.active_programs)
	var command := {"type":"confirm_program_replacement","proposal":proposal,"receipt_id":"secondary-medical"}
	var commands = load("res://src/simulation/career_command_service.gd")
	var result: Dictionary = commands.apply(c,command)
	T.assert_equal(result.ok,true,str(result.get("error","")))
	if not result.ok: return
	T.assert_equal(_program_hash(result.career.active_programs),original)
	var revised: Dictionary = result.career.season_program_plan.programs_by_level.senior.free
	T.assert_equal(revised.elements.size(),12)
	for element in revised.elements:
		if element.kind == "jump": T.assert_equal(int(element.rotations) <= 2,true)
	T.assert_equal(commands.apply(result.career,command).career.to_dict(),result.career.to_dict(),"receipt is idempotent")
	var stale = c.transaction_copy()
	stale.season_program_plan.programs_by_level.senior.free.music = {"title":"changed after proposal"}
	T.assert_equal(commands.apply(stale,command).ok,false,"secondary edits invalidate stale advice")

func _at_gp_check_in(c) -> void:
	# This consumer starts at the real check-in; it is not a training/save test.
	c.competition_timeline = {"version":1,"mode":"dated","date":"2021-10-22","origin_date":"2021-10-22","quarter_progress":22,"applied_intervals":[],"attempt_remainders":{}}
	T.assert_equal(preload("res://src/domain/competition_timeline.gd").validate(c.competition_timeline,c.clock.to_dict()),"")
