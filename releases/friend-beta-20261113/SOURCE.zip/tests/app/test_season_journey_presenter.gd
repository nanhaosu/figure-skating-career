extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Clock = preload("res://src/domain/game_clock.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Planner = preload("res://src/simulation/season_calendar_planner.gd")
const PresenterPath := "res://src/app/season_journey_presenter.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"dated calendar allows competition only inside actual day window","callable":test_actual_day_window},
		{"name":"journey uses one confirmed registration state everywhere", "callable":test_confirmed},
		{"name":"player archive overrides stale registration as completed", "callable":test_completed},
		{"name":"active formal competition is the next resumable step", "callable":test_active},
		{"name":"declined international entry never hides later domestic route", "callable":test_domestic_route},
		{"name":"unavailable international entries remain readable but never become next tasks", "callable":test_unavailable_international},
		{"name":"international skip-only routes do not open a confirmation dialog", "callable":test_no_skip_only_dialog},
		{"name":"available self-funded international entry retains its decision dialog", "callable":test_available_international_dialog},
	]

func test_actual_day_window() -> void:
	var fixture := _fixture()
	var id := "cn_grand_prix_u_series_2018"
	fixture.plan.entries[id].status = "confirmed"
	fixture.plan.entries[id].eligibility_snapshot.eligible = true
	for sample in [{"date":"2018-09-12","kind":"prepare"},{"date":"2018-09-13","kind":"compete"},{"date":"2018-09-15","kind":"compete"},{"date":"2018-09-16","kind":"prepare"}]:
		fixture.career.competition_timeline.date = sample.date
		fixture.career.competition_timeline.mode = "dated"
		fixture.career.competition_timeline.origin_date = sample.date
		fixture.career.competition_timeline.quarter_progress = {"2018-09-12":74,"2018-09-13":75,"2018-09-15":77,"2018-09-16":78}[sample.date]
		T.assert_equal(_row(_build(fixture),id).action_kind,sample.kind,"a shared quarter is not an actual event day")

func _fixture() -> Dictionary:
	var career = F.starting_career(1818)
	career.clock = Clock.new(2018, 3)
	var loaded := Bundle.load_bundle(2018, "women_singles", "junior")
	var proposed := Planner.propose(career, loaded.calendar, loaded.rules)
	return {"career":career,"calendar":loaded.calendar,"plan":proposed.plan.to_dict()}

func _build(fixture: Dictionary) -> Dictionary:
	T.assert_equal(ResourceLoader.exists(PresenterPath), true, "season journey presenter missing")
	if not ResourceLoader.exists(PresenterPath): return {}
	return load(PresenterPath).build(fixture.career, fixture.calendar, fixture.plan)

func _first_event(fixture: Dictionary) -> Dictionary:
	return fixture.calendar.events[0]

func _row(journey: Dictionary, event_id: String) -> Dictionary:
	return Dictionary(journey.get("events_by_id", {}).get(event_id, {}))

func test_confirmed() -> void:
	var fixture := _fixture()
	var event: Dictionary = _first_event(fixture)
	var date_parts := str(event.start_date).split("-")
	fixture.career.clock = Clock.new(int(date_parts[0]), int((int(date_parts[1]) - 1) / 3) + 1)
	fixture.plan.entries[event.event_id].status = "confirmed"
	fixture.plan.entries[event.event_id].eligibility_snapshot.eligible = true
	var row := _row(_build(fixture), event.event_id)
	T.assert_equal(row.get("status"), "confirmed")
	T.assert_equal(row.get("status_label"), "已报名")
	T.assert_equal(row.get("action_kind"), "compete")
	T.assert_equal(row.get("action_label"), "前往比赛")

func test_completed() -> void:
	var fixture := _fixture()
	var event: Dictionary = _first_event(fixture)
	fixture.plan.entries[event.event_id].status = "confirmed"
	fixture.career.competition_archive.append({"event_id":event.event_id,"status":"complete","world_only":false})
	var row := _row(_build(fixture), event.event_id)
	T.assert_equal(row.get("status"), "completed")
	T.assert_equal(row.get("action_kind"), "view_archive")
	T.assert_equal(row.get("action_label"), "查看比赛档案")

func test_active() -> void:
	var fixture := _fixture()
	var event: Dictionary = _first_event(fixture)
	fixture.plan.entries[event.event_id].status = "confirmed"
	fixture.career.competition_state = {"kind":"formal","event_id":event.event_id,"status":"short_ready"}
	var journey := _build(fixture)
	var row := _row(journey, event.event_id)
	T.assert_equal(row.get("status"), "in_progress")
	T.assert_equal(row.get("action_kind"), "resume")
	T.assert_equal(journey.get("next_event_id"), event.event_id)

func test_domestic_route() -> void:
	var fixture := _fixture()
	var international_id := ""
	for event in fixture.calendar.events:
		var id := str(event.event_id)
		if str(event.get("scope", "")) == "domestic" and str(event.get("event_family", "")) in ["club_league_stage", "club_league_final"]:
			fixture.career.competition_archive.append({"event_id":id,"status":"complete","world_only":false})
		elif str(event.get("event_family", "")).contains("jgp"):
			international_id = str(event.event_id)
			fixture.plan.entries[international_id].status = "blocked"
	var journey := _build(fixture)
	T.assert_equal(journey.events.size(), fixture.calendar.events.size())
	var domestic_after := Array(journey.current_chain).any(func(row): return str(row.get("scope", "")) == "domestic")
	T.assert_equal(domestic_after, true, "blocked JGP entries must not hide the domestic fallback route")
	T.assert_equal(journey.next_event_id,"cn_grand_prix_u_series_2018","unavailable international entries are not player decisions; retain the next domestic task")
	T.assert_equal(Array(journey.get("current_chain", [])).is_empty(), false)

func test_unavailable_international() -> void:
	var career = F.formal_junior_career(701)
	career.selection_state["decisions"] = {"jgp":{}}
	var bundle := Bundle.for_career(career)
	bundle.calendar.events = bundle.calendar.events.filter(func(event): return event.event_family in ["jgp_stage","national_championship"])
	var proposed := Planner.propose(career,bundle.calendar,bundle.rules)
	var journey: Dictionary = load(PresenterPath).build(career,bundle.calendar,proposed.plan.to_dict())
	T.assert_equal(journey.events.size(),bundle.calendar.events.size(),"unavailable events must stay inspectable")
	T.assert_equal(journey.next_event_id,"cn_national_championships_2018","blocked JGP is not a player task")
	T.assert_equal(journey.current_chain.any(func(row): return row.get("scope") == "international"),false)

func test_no_skip_only_dialog() -> void:
	var career = F.formal_junior_career(701)
	career.athlete.resources.money = 0.0
	career.selection_state["decisions"] = {"jgp":{}}
	var bundle := Bundle.for_career(career)
	var proposal := Planner.propose(career,bundle.calendar,bundle.rules)
	var panel = load("res://src/app/season_overview_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(career,bundle.calendar,proposal.plan.to_dict())
	for event in bundle.calendar.events.filter(func(row): return row.event_family in ["jgp_stage","world_junior","international_open"]):
		panel.select_event(event.event_id)
		T.assert_equal(panel.get_node("%AdjustEntryButton").disabled,true,"no meaningful decision for "+event.event_id)
		panel.present_adjustment_options(event.event_id,preload("res://src/simulation/entry_application_service.gd").options(career,event,bundle))
		T.assert_equal(panel.get_node("%AdjustmentDialog").visible,false,"do not ask players to confirm the only available action is not participating")
	panel.free()

func test_available_international_dialog() -> void:
	var career = F.formal_junior_career(701)
	career.athlete.resources.money = 90.0
	var bundle := Bundle.for_career(career)
	var event: Dictionary = bundle.calendar.events.filter(func(row): return row.event_id == "golden_spin_junior_2018")[0]
	var choices := preload("res://src/simulation/entry_application_service.gd").options(career,event,bundle)
	T.assert_equal(choices[0].available,true,"fixture must offer a real international entry")
	var proposal := Planner.propose(career,bundle.calendar,bundle.rules)
	var panel = load("res://src/app/season_overview_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(career,bundle.calendar,proposal.plan.to_dict())
	panel.select_event(event.event_id)
	T.assert_equal(panel.get_node("%AdjustEntryButton").disabled,false)
	panel.present_adjustment_options(event.event_id,choices)
	T.assert_equal(panel.get_node("%AdjustmentDialog").visible,true)
	panel.free()
