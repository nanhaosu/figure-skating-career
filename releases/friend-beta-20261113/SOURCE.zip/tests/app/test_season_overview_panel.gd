extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const GameClock = preload("res://src/domain/game_clock.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const SeasonCalendarPlanner = preload("res://src/simulation/season_calendar_planner.gd")

const PANEL_SCENE := "res://src/app/season_overview_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"annual policy opens complete scrollable read only dialog at both sizes","callable":test_policy_dialog},
		{"name":"populated schedule has one intro then visible choices before compact impact at 1280","callable":func(): await test_populated_schedule_geometry(Vector2i(1280,720))},
		{"name":"populated schedule has one intro then visible choices before compact impact at 960","callable":func(): await test_populated_schedule_geometry(Vector2i(960,540))},
		{"name":"unoffered required events remain recoverable and confirmed choices stay protected","callable":test_unoffered_policy_preview},
		{"name":"schedule dialog confirm controls fit 960 by 540 window","callable":test_schedule_dialog_small_window},
		{"name":"annual announcement roles and live schedule opportunity preview are read only","callable":test_policy_preview},
		{"name":"expanded full calendar remains usable inside 1280 career viewport","callable":func(): await test_calendar_viewport(Vector2i(1096,664))},
		{"name":"expanded full calendar remains usable inside 960 career viewport","callable":func(): await test_calendar_viewport(Vector2i(822,498))},
		{"name":"approved pandemic game handling is visible inline without new confirmations","callable":test_pandemic_notes},
		{"name":"domestic season picker submits several events with one confirmation", "callable":test_domestic_picker},
		{"name": "season overview exposes timeline calendar athlete and details", "callable": test_scene_contract},
		{"name": "full calendar shows every event with textual status", "callable": test_full_calendar_status_text},
		{"name": "event selection presents recommendation and allowed adjustments", "callable": test_event_details_and_adjustments},
		{"name": "only confirmed due eligible event can launch", "callable": test_formal_launch_gate},
		{"name": "season overview explains grade and assessment readiness", "callable": test_certification_summary},
		{"name": "long event details keep entry and launch controls visible without scrolling", "callable": test_fixed_event_controls},
	]

func test_calendar_viewport(dimensions: Vector2i) -> void:
	var career = Fixtures.starting_career(1821)
	career.clock = GameClock.new(2021,3)
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	TestSupport.assert_equal(bundle.errors,[])
	if not bundle.errors.is_empty(): return
	var viewport := SubViewport.new()
	viewport.size = dimensions
	Engine.get_main_loop().root.add_child(viewport)
	var panel = load(PANEL_SCENE).instantiate()
	panel.theme = load("res://src/app/theme_factory.gd").create()
	viewport.add_child(panel)
	var before := JSON.stringify(career.to_dict())
	panel.present(career,bundle.calendar,{"entries":{}})
	panel.get_node("%FullCalendarButton").pressed.emit()
	for frame in 8: await Engine.get_main_loop().process_frame
	var list: VBoxContainer = panel.get_node("%EventList")
	var scroll: ScrollContainer = list.get_parent()
	print("CALENDAR_LAYOUT ",dimensions," list=",scroll.size," hero=",panel.get_node("%HeroPanel").size," columns=",panel.get_node("Layout/Columns").size)
	TestSupport.assert_equal(list.get_child_count(),bundle.calendar.events.size())
	TestSupport.assert_equal(scroll.size.y >= 120,true,"the actual calendar list needs visible room, not only a visible heading")
	for control in [panel.get_node("%AdvanceButton"),panel.get_node("%LaunchEventButton"),scroll]:
		var rect: Rect2 = control.get_global_rect()
		TestSupport.assert_equal(rect.position.x >= 0 and rect.end.x <= dimensions.x+1 and rect.end.y <= dimensions.y+1,true,"calendar actions and list must remain inside the viewport")
	TestSupport.assert_equal(JSON.stringify(career.to_dict()),before)
	panel.present(career,bundle.calendar,{"entries":{}})
	TestSupport.assert_equal(panel.get_node("%EventListRegion").visible,false)
	viewport.free()

func test_pandemic_notes() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(fixture.career,fixture.calendar,fixture.plan)
	var domestic=SeasonCalendarRepository.load_calendar(2020,"CHN","women_singles")
	TestSupport.assert_equal(domestic.errors,[])
	if not domestic.errors.is_empty():panel.free();return
	fixture.career.clock=GameClock.new(2020,3)
	panel.present(fixture.career,domestic.calendar,{"entries":{}})
	TestSupport.assert_equal(panel.season_heading.text.contains("游戏处理"),true)
	TestSupport.assert_equal(panel.next_event_meta.text.contains("继续训练"),true)
	TestSupport.assert_equal(panel.event_details.text.contains("未核实"),true,"An empty schedule must not retain last season's event details")
	var bundle=load("res://src/content/season_bundle_repository.gd").load_bundle(2020,"women_singles","senior")
	TestSupport.assert_equal(bundle.errors,[])
	if not bundle.errors.is_empty():panel.free();return
	panel.present(fixture.career,bundle.calendar,{"entries":{}})
	panel.select_event("isu_gpchn2020")
	TestSupport.assert_equal(panel.event_details.text.contains("7人模拟裁判组"),true)
	TestSupport.assert_equal(panel.event_details.text.contains("历史人数未核实"),true)
	for child in panel.get_children():
		if child is Window:TestSupport.assert_equal(child.visible,false,"These labels must not create another forced dialog")
	panel.free()

func test_domestic_picker() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(fixture.career, fixture.calendar, fixture.plan)
	TestSupport.assert_equal(panel.has_method("present_domestic_schedule"), true)
	if not panel.has_method("present_domestic_schedule"):
		panel.free()
		return
	var submitted: Array = []
	panel.domestic_schedule_selected.connect(func(ids): submitted.append(ids))
	panel.present_domestic_schedule([
		{"event_id":"one", "name":"国内赛一", "date":"2018-05-01", "available":true, "selected":false, "reasons":[]},
		{"event_id":"two", "name":"国内赛二", "date":"2018-06-01", "available":true, "selected":false, "reasons":[]},
	])
	panel.get_node("DomesticScheduleDialog/ScheduleLayout/ScheduleScroll/Content/Events/one").button_pressed = true
	panel.get_node("DomesticScheduleDialog/ScheduleLayout/ScheduleScroll/Content/Events/two").button_pressed = true
	panel.get_node("DomesticScheduleDialog").confirmed.emit()
	TestSupport.assert_equal(submitted, [["one", "two"]])
	panel.free()

func test_fixed_event_controls() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	panel.size = Vector2(960,540)
	panel.present(fixture.career,fixture.calendar,fixture.plan)
	panel.get_node("%EventDetails").text += "\n" + "完整赛事规则说明\n".repeat(60)
	await Engine.get_main_loop().process_frame
	await Engine.get_main_loop().process_frame
	for button in [panel.get_node("%AdjustEntryButton"),panel.get_node("%LaunchEventButton")]:
		var ancestor = button.get_parent()
		while ancestor != panel:
			if ancestor is ScrollContainer:
				TestSupport.assert_equal(ancestor.get_global_rect().encloses(button.get_global_rect()),true,"primary event control is clipped by long scrolling rules")
			ancestor = ancestor.get_parent()
		TestSupport.assert_equal(panel.get_global_rect().encloses(button.get_global_rect()),true,"event control must remain inside the minimum panel")
	panel.free()

func test_certification_summary() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(fixture.career, fixture.calendar, fixture.plan)
	var summary: Label = panel.get_node_or_null("%CertificationSummary")
	TestSupport.assert_equal(summary != null, true)
	if summary != null:
		TestSupport.assert_equal(summary.text.contains("等级"), true)
		TestSupport.assert_equal(summary.text.contains("跳跃"), true)
	panel.free()

func test_formal_launch_gate() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate(); Engine.get_main_loop().root.add_child(panel)
	var event_id := "cn_grand_prix_u_series_2018"
	fixture.plan.entries[event_id].status = "confirmed"
	fixture.plan.entries[event_id].eligibility_snapshot.eligible = true
	panel.present(fixture.career, fixture.calendar, fixture.plan)
	panel.select_event(event_id)
	var launched: Array[String] = []; panel.event_launch_requested.connect(func(id): launched.append(id))
	panel.get_node("%LaunchEventButton").pressed.emit()
	TestSupport.assert_equal(launched, [event_id])
	fixture.plan.entries[event_id].status = "blocked"
	panel.refresh_entry_plan(fixture.plan); panel.select_event(event_id)
	TestSupport.assert_equal(panel.get_node("%LaunchEventButton").disabled, true)
	panel.free()

func test_scene_contract() -> void:
	var panel = load(PANEL_SCENE).instantiate()
	for path in ["%KeyTimeline", "%FullCalendarButton", "%AthleteSummary", "%EventList", "%EventDetails", "%AdvanceButton"]:
		TestSupport.assert_equal(panel.get_node_or_null(path) != null, true, "missing %s" % path)
	panel.free()

func test_full_calendar_status_text() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(fixture.career, fixture.calendar, fixture.plan)
	TestSupport.assert_equal(panel.get_node("%KeyTimeline").get_child_count() > 0, true)
	panel.show_full_calendar()
	var list: VBoxContainer = panel.get_node("%EventList")
	TestSupport.assert_equal(list.get_child_count(), fixture.calendar.events.size())
	for card in list.get_children():
		var status_label: Label = card.get_node("CardLayout/StatusLabel")
		TestSupport.assert_equal(status_label.text.is_empty(), false)
		TestSupport.assert_equal(status_label.text.contains("状态"), true)
	panel.free()

func test_event_details_and_adjustments() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(fixture.career, fixture.calendar, fixture.plan)
	var event_id := str(fixture.calendar.events[0].event_id)
	panel.select_event(event_id)
	TestSupport.assert_equal(panel.get_node("%EventDetails").text.contains("北京站"), true)
	TestSupport.assert_equal(panel.get_node("%CoachRecommendation").text.contains("教练建议"), true)
	panel.present_adjustment_options(event_id, SeasonCalendarPlanner.available_adjustments(fixture.career, fixture.plan, event_id))
	TestSupport.assert_equal(panel.get_node("%AdjustmentOption").item_count, 2)
	TestSupport.assert_equal(panel.get_node("%AdjustmentDialog").visible, true)
	panel.free()

func _fixture() -> Dictionary:
	var career = Fixtures.starting_career(1818)
	career.clock = GameClock.new(2018, 3)
	var calendar_result := SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles")
	var rules := {"junior_min_age": 13, "junior_max_age": 18, "age_cutoff": {"month": 7, "day": 1}}
	var proposal := SeasonCalendarPlanner.propose(career, calendar_result.calendar, rules)
	return {"career": career, "calendar": calendar_result.calendar, "plan": proposal.plan.to_dict()}

func test_policy_preview() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var before := JSON.stringify(fixture.career.to_dict())
	panel.present(fixture.career,fixture.calendar,fixture.plan)
	panel.get_node("%AnnualPolicyButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("AnnualPolicyDialog").find_child("GuideBody",true,false).text.contains("70%"),true)
	panel.get_node("AnnualPolicyDialog").close_button.pressed.emit()
	panel.select_event("cn_national_championships_2018")
	TestSupport.assert_equal(panel.event_details.text.contains("必要成绩"),true)
	panel.present_domestic_schedule([{"event_id":"cn_national_championships_2018","name":"全国锦标赛","date":"2018-12-01","available":true,"selected":false,"reasons":[]}])
	var impact = panel.get_node("DomesticScheduleDialog/ScheduleLayout/ScheduleScroll/Content/ScheduleImpact")
	TestSupport.assert_equal(impact.text.contains("失去本目标"),true)
	var choice = panel.get_node("DomesticScheduleDialog/ScheduleLayout/ScheduleScroll/Content/Events").get_child(0)
	choice.button_pressed = true
	TestSupport.assert_equal(impact.text.contains("失去本目标"),false)
	panel.present(fixture.career,fixture.calendar,fixture.plan)
	TestSupport.assert_equal(JSON.stringify(fixture.career.to_dict()),before)
	panel.free()

func test_unoffered_policy_preview() -> void:
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(fixture.career,fixture.calendar,fixture.plan)
	var row := {"event_id":"cn_national_championships_2018","name":"全国锦标赛","date":"2018-12-01","available":false,"selected":false,"reasons":["资格待修复"]}
	panel.present_domestic_schedule([row])
	var impact = panel.get_node("DomesticScheduleDialog/ScheduleLayout/ScheduleScroll/Content/ScheduleImpact")
	TestSupport.assert_equal(impact.text.contains("失去本目标"),false,"unoffered required row is not a choice to forgo")
	var choices = panel.get_node("DomesticScheduleDialog/ScheduleLayout/ScheduleScroll/Content/Events")
	TestSupport.assert_equal(choices.get_child(0).disabled,true)
	row.available = true
	panel.present_domestic_schedule([row])
	TestSupport.assert_equal(choices.get_child(0).disabled,false,"eligibility recovery reopens the actual choice")
	TestSupport.assert_equal(impact.text.contains("失去本目标"),true)
	row.selected = true
	panel.present_domestic_schedule([row])
	TestSupport.assert_equal(choices.get_child(0).disabled,true)
	TestSupport.assert_equal(choices.get_child(0).button_pressed,true)
	TestSupport.assert_equal(impact.text.contains("失去本目标"),false)
	panel.free()

func test_schedule_dialog_small_window() -> void:
	var root = Engine.get_main_loop().root
	var old_size: Vector2i = root.size
	var old_scale: Vector2i = root.content_scale_size
	var old_embed: bool = root.gui_embed_subwindows
	root.size = Vector2i(960,540)
	root.content_scale_size = Vector2i(960,540)
	root.gui_embed_subwindows = true
	var fixture := _fixture()
	var panel = load(PANEL_SCENE).instantiate()
	root.add_child(panel)
	panel.present(fixture.career,fixture.calendar,fixture.plan)
	var rows: Array = []
	for event in fixture.calendar.events:
		rows.append({"event_id":event.event_id,"name":event.name,"date":event.start_date,"available":true,"selected":false,"reasons":[]})
	panel.present_domestic_schedule(rows)
	for frame in 4: await Engine.get_main_loop().process_frame
	var dialog: ConfirmationDialog = panel.get_node("DomesticScheduleDialog")
	print("SCHEDULE_LAYOUT window=",root.size," position=",dialog.position," size=",dialog.size," confirm=",dialog.get_ok_button().get_global_rect())
	TestSupport.assert_equal(Rect2i(Vector2i.ZERO,root.size).encloses(Rect2i(dialog.position,dialog.size)),true,"dialog including confirmation must fit small window")
	for button in [dialog.get_ok_button(),dialog.get_cancel_button()]:
		TestSupport.assert_equal(Rect2(Vector2.ZERO,Vector2(dialog.size)).encloses(button.get_global_rect()),true,"confirm/cancel must be inside dialog")
	panel.free()
	root.size = old_size
	root.content_scale_size = old_scale
	root.gui_embed_subwindows = old_embed

func test_populated_schedule_geometry(dimensions: Vector2i) -> void:
	var root = Engine.get_main_loop().root
	var old_size: Vector2i = root.size
	var old_scale: Vector2i = root.content_scale_size
	var old_embed: bool = root.gui_embed_subwindows
	root.size = dimensions
	root.content_scale_size = dimensions
	root.gui_embed_subwindows = true
	var c = Fixtures.starting_career(1821)
	c.clock = GameClock.new(2021,3)
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","senior")
	TestSupport.assert_equal(bundle.errors,[])
	var panel = load(PANEL_SCENE).instantiate()
	root.add_child(panel)
	panel.present(c,bundle.calendar,{"entries":{}})
	var rows: Array = []
	for event in bundle.calendar.events:
		if event.get("scope") != "domestic": continue
		rows.append({"event_id":event.event_id,"name":event.name,"date":event.start_date,"available":true,"selected":false,"reasons":[]})
	panel.present_domestic_schedule(rows)
	for frame in 5: await Engine.get_main_loop().process_frame
	var dialog: ConfirmationDialog = panel.get_node("DomesticScheduleDialog")
	var content = dialog.get_node("ScheduleLayout/ScheduleScroll/Content")
	var choices = content.get_node("Events")
	var impact = content.get_node("ScheduleImpact")
	var scroll: ScrollContainer = dialog.get_node("ScheduleLayout/ScheduleScroll")
	TestSupport.assert_equal(dialog.dialog_text,"","native intro overlaps custom content in AcceptDialog")
	TestSupport.assert_equal(choices.get_index() < impact.get_index(),true,"actual races must precede opportunity details")
	var intro = content.get_node_or_null("ScheduleIntroduction")
	TestSupport.assert_equal(intro != null,true,"one introduction must belong to the content layout")
	if intro != null:
		TestSupport.assert_equal(intro.get_global_rect().end.y <= choices.get_global_rect().position.y,true)
	TestSupport.assert_equal(scroll.get_global_rect().encloses(choices.get_child(0).get_global_rect()),true,"first actual race must be visible immediately")
	for choice in choices.get_children():
		TestSupport.assert_equal(choice.get_global_rect().position.x >= scroll.get_global_rect().position.x and choice.get_global_rect().end.x <= scroll.get_global_rect().end.x,true,"race labels cannot clip horizontally")
		var label: Label = choice.get_node("RaceLabel")
		TestSupport.assert_equal(label.get_line_count()*label.get_line_height() <= choice.size.y,true,"full race name and date must fit its checkbox row")
		TestSupport.assert_equal(choice.get_global_rect().encloses(label.get_global_rect()),true,"wrapping label belongs inside its actual checkbox")
	var summary: Label = dialog.get_node("ScheduleLayout/ScheduleSummary")
	TestSupport.assert_equal(Rect2i(Vector2i.ZERO,dimensions).encloses(Rect2i(dialog.position,dialog.size)),true,"populated dialog and summary fit real window")
	TestSupport.assert_equal(summary.text.contains("保存影响"),true)
	TestSupport.assert_equal(summary.get_line_count() <= 3,true,"fixed impact must remain a brief summary")
	TestSupport.assert_equal(Rect2(Vector2.ZERO,Vector2(dialog.size)).encloses(summary.get_global_rect()),true,"key impact summary must stay visible outside the race scroll")
	TestSupport.assert_equal(summary.get_global_rect().end.y <= dialog.get_ok_button().get_global_rect().position.y,true,"impact precedes primary confirmation")
	TestSupport.assert_equal(impact.text.contains("isu_"),false,"human target labels rather than internal IDs")
	TestSupport.assert_equal(impact.text.split("\n").size() <= 8,true,"impact must group repeated unknown targets")
	print("POPULATED_SCHEDULE ",dimensions," dialog=",dialog.size," first=",choices.get_child(0).get_global_rect()," scroll=",scroll.get_global_rect()," impact_lines=",impact.text.split("\n").size())
	panel.free()
	root.size = old_size
	root.content_scale_size = old_scale
	root.gui_embed_subwindows = old_embed

func test_policy_dialog() -> void:
	var fixture := _fixture()
	var root = Engine.get_main_loop().root
	var original_size: Vector2i = root.size
	for dimensions in [Vector2i(960,540),Vector2i(1280,720)]:
		var viewport := SubViewport.new()
		viewport.size = dimensions
		viewport.gui_embed_subwindows = true
		root.add_child(viewport)
		var panel = load(PANEL_SCENE).instantiate()
		panel.theme = load("res://src/app/theme_factory.gd").create()
		viewport.add_child(panel)
		panel.present(fixture.career,fixture.calendar,fixture.plan)
		panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		var before := JSON.stringify(fixture.career.to_dict())
		var selected: String = panel._selected_event_id
		var button = panel.find_child("AnnualPolicyButton",true,false)
		TestSupport.assert_equal(button != null,true,"annual announcement must be directly clickable")
		if button == null: viewport.free(); continue
		for frame in 4: await Engine.get_main_loop().process_frame
		TestSupport.assert_equal(button.get_global_rect().end.x <= dimensions.x+1 and button.get_global_rect().end.y <= dimensions.y+1,true)
		button.pressed.emit()
		for frame in 4: await Engine.get_main_loop().process_frame
		var dialog = panel.get_node("AnnualPolicyDialog")
		var body = dialog.find_child("GuideBody",true,false)
		TestSupport.assert_equal(dialog.visible,true)
		TestSupport.assert_equal(body.text,str(panel._journey.annual_policy.announcements))
		TestSupport.assert_equal(body.scroll_active and not body.fit_content,true)
		print("POLICY_LAYOUT ",dimensions," button=",button.get_global_rect()," dialog=",dialog.size," body=",body.size," viewport=",viewport.get_visible_rect())
		TestSupport.assert_equal(body.size.y >= 200,true)
		TestSupport.assert_equal(dialog.size.x <= dimensions.x and dialog.size.y <= dimensions.y,true)
		TestSupport.assert_equal(dialog.close_button.get_global_rect().end.y <= dialog.size.y,true)
		# Stress the same reader with a future longer published notice.
		body.text = (body.text+"\n").repeat(12)
		for frame in 4: await Engine.get_main_loop().process_frame
		var scrollbar = body.get_v_scroll_bar()
		TestSupport.assert_equal(scrollbar.max_value > scrollbar.page,true,"full policy must actually overflow into a scrollable document")
		scrollbar.value = scrollbar.max_value
		await Engine.get_main_loop().process_frame
		TestSupport.assert_equal(scrollbar.value > 0,true)
		dialog.close_button.pressed.emit()
		TestSupport.assert_equal(dialog.visible,false)
		TestSupport.assert_equal(panel._selected_event_id,selected)
		TestSupport.assert_equal(JSON.stringify(fixture.career.to_dict()),before)
		viewport.free()
	root.size = original_size
