extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "career shell keeps global navigation and exits visible", "callable": test_shell_contract},
		{"name": "failed persisted exit keeps the career screen open", "callable": test_failed_exit},
	]

func test_shell_contract() -> void:
	T.assert_equal(ResourceLoader.exists("res://src/app/career_shell_panel.tscn"), true)
	if not ResourceLoader.exists("res://src/app/career_shell_panel.tscn"): return
	var shell = load("res://src/app/career_shell_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(shell)
	var navigation := []
	shell.navigation_requested.connect(func(screen_id: String): navigation.append(screen_id))
	shell.present(F.starting_career(94001), {"screen_id": "training", "context": {}, "return_route": {}}, "已自动保存")
	T.assert_equal(shell.get_node("%TrainingNavButton").disabled, true)
	T.assert_equal(shell.get_node("%MainMenuButton").visible, true)
	T.assert_equal(shell.get_node("%SaveManagerButton").visible, true)
	shell.get_node("%RecordsNavButton").pressed.emit()
	T.assert_equal(navigation, ["records"])
	shell.free()

func test_failed_exit() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(94002)
	main.has_unsaved_changes = true
	main.autosave_path = "user://missing-shell-parent/fail.json"
	main._open_player_home()
	await main.exit_to_main_menu()
	T.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	T.assert_equal(main.get_node("%MainMenuPanel").visible, false)
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("保存失败"), true)
	main.free()
