extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"opening the next season preserves archived season history and outlook","callable":reopen},
		{"name":"published Beijing seasons reopen their actual calendars after archived history","callable":published_beijing},
		{"name":"last supported season closes to outlook without recycling old calendar","callable":last_season}]

func published_beijing() -> void:
	for year in [2020,2021]:
		var career = F.formal_junior_career(197+year)
		career.clock.year = year; career.clock.quarter = 3
		career.season_state = {"season_id":"%d-%02d" % [year,(year+1)%100],"entry_plan":{},"qualification_state":{},"event_statuses":{},"season_history":{"2019-20":{"season":{"season_id":"2019-20"}}}}
		var history: Dictionary = career.season_state.season_history.duplicate(true)
		var main = load("res://src/app/main.tscn").instantiate()
		main.autosave_path = "user://history-beijing-%d.json" % year
		Engine.get_main_loop().root.add_child(main)
		main.offer_new_career(career); main.confirm_new_career_replacement()
		main.get_node("%CareerHomePanel").get_node("%PrimaryAction").pressed.emit()
		T.assert_equal(main.get_node("%SeasonOverviewPanel").visible,true,"published season %d must not fall back to old outlook or training" % year)
		T.assert_equal(main.active_career.season_state.get("season_id",""),"%d-%02d" % [year,(year+1)%100])
		T.assert_equal(main.active_career.season_state.season_history,history)
		main.free()

func last_season() -> void:
	var career = F.formal_junior_career(196)
	career.clock.year = 2026; career.clock.quarter = 3
	career.season_state = {"season_id":"2026-27","entry_plan":{},"qualification_state":{},"event_statuses":{},"season_history":{"2025-26":{"season":{"season_id":"2025-26"}}},"coach_feedback":"本季归档，请讨论下一赛季"}
	var before: Dictionary = career.season_state.duplicate(true)
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://history-last.json"
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(career); main.confirm_new_career_replacement()
	main.get_node("%CareerHomePanel").get_node("%PrimaryAction").pressed.emit()
	T.assert_equal(main.active_career.season_state,before)
	T.assert_equal(main.get_node("%SummaryPanel").visible,true)
	T.assert_equal(load("res://src/content/season_bundle_repository.gd").for_career(career).errors.is_empty(),false)
	main.free()

func reopen() -> void:
	var career = F.formal_junior_career(195)
	career.clock.year = 2019; career.clock.quarter = 3
	career.season_state = {"season_id":"2019-20","entry_plan":{},"qualification_state":{},"event_statuses":{},"season_history":{"2018-19":{"clock":{"year":2019,"quarter":3},"season":{"season_id":"2018-19"}}},"coach_feedback":"讨论下一赛季"}
	var history: Dictionary = career.season_state.season_history.duplicate(true)
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://history-reopen.json"
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(career); main.confirm_new_career_replacement()
	main.get_node("%CareerHomePanel").get_node("%PrimaryAction").pressed.emit()
	T.assert_equal(main.active_career.season_state.get("season_history",{}),history)
	T.assert_equal(main.active_career.season_state.get("coach_feedback",""),"讨论下一赛季")
	T.assert_equal(main.active_career.season_state.entry_plan.is_empty(),false)
	main.free()
