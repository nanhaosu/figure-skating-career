extends "res://tests/app/test_main_flow.gd"

class DelayedSaveMain:
	extends "res://src/app/main.gd"
	var saves := 0
	func _save_career(career, path: String) -> Dictionary:
		saves += 1
		await get_tree().process_frame
		return await super._save_career(career,path)

func cases() -> Array[Dictionary]:
	return [
		{"name":"explicit coach acceptance persists without editor", "callable":test_launch_shows_actionable_checklist},
		{"name":"manual editing remains available", "callable":test_missing_program_opens_manual_editing},
		{"name":"failed acceptance rolls back and retries", "callable":test_rollback},
		{"name":"stale acceptance cannot change formal session", "callable":test_active_session},
		{"name":"secondary adoption preserves junior and other segment", "callable":test_secondary},
		{"name":"insufficient skills cannot be repaired through adoption", "callable":test_insufficient},
		{"name":"async duplicate acceptance commits only once", "callable":test_reentry},
	]

func test_rollback() -> void:
	var main = _instantiate_main()
	main.active_career = Fixtures.formal_acceptance_career("qualify")
	main.active_career.active_programs.short.elements.clear()
	var event_id := str(Fixtures.u_series_event().event_id)
	var other := JSON.stringify(main.active_career.active_programs.free)
	var athlete: Dictionary = main.active_career.athlete.to_dict().duplicate(true)
	var path: String = main.autosave_path
	TestSupport.assert_equal(SaveRepository.save(main.active_career,path).ok,true)
	var bytes := FileAccess.get_file_as_string(path)
	var before := JSON.stringify(main.active_career.to_dict())
	main.autosave_path = "user://missing-coach-directory-%d/save.json" % Time.get_ticks_usec()
	await main._on_pre_competition_action_requested(event_id,"adopt_coach_program","short")
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	TestSupport.assert_equal(FileAccess.get_file_as_string(path),bytes)
	main.autosave_path = path
	await main._on_pre_competition_action_requested(event_id,"adopt_coach_program","short")
	TestSupport.assert_equal(main.active_career.active_programs.short.draft_status,"locked")
	TestSupport.assert_equal(JSON.stringify(main.active_career.active_programs.free),other)
	TestSupport.assert_equal(_same_data(main.active_career.athlete.to_dict(),athlete),true)
	TestSupport.assert_equal(main.active_career.program_archive.size(),1)
	TestSupport.assert_equal(main.active_career.active_programs.short.revision,2)
	var loaded := SaveRepository.load_save(path)
	TestSupport.assert_equal(loaded.ok,true)
	if loaded.ok:
		TestSupport.assert_equal(_same_data(loaded.career.active_programs,main.active_career.active_programs),true,"programme content must survive disk JSON numeric conversion")
		TestSupport.assert_equal(_same_data(loaded.career.program_archive,main.active_career.program_archive),true,"archive must survive disk JSON numeric conversion")
	var adopted := JSON.stringify(main.active_career.to_dict())
	await main._on_pre_competition_action_requested(event_id,"adopt_coach_program","short")
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),adopted,"repeated acceptance must not create another revision")
	main.free()

func test_active_session() -> void:
	var main = _instantiate_main()
	main.active_career = Fixtures.formal_acceptance_career("qualify")
	main.active_career.competition_state = {"kind":"formal","status":"preparation","event_id":str(Fixtures.u_series_event().event_id)}
	var before := JSON.stringify(main.active_career.to_dict())
	await main._on_pre_competition_action_requested(str(Fixtures.u_series_event().event_id),"adopt_coach_program","short")
	TestSupport.assert_equal(main.get_node("%ProgramEditorPanel").visible,false)
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	TestSupport.assert_equal(main.get_node("%GlobalMessage").text.contains("比赛"),true)
	main.free()

func test_secondary() -> void:
	var main = _instantiate_main()
	main.active_career = Fixtures.formal_junior_career(936)
	main.active_career.season_program_plan.competitive_level = "transition"
	var before := JSON.stringify(main.active_career.active_programs)
	await main._on_pre_competition_action_requested("cn_national_championships_2018","adopt_coach_program","short")
	TestSupport.assert_equal(JSON.stringify(main.active_career.active_programs),before)
	var secondary: Dictionary = main.active_career.season_program_plan.get("programs_by_level",{}).get("senior",{})
	TestSupport.assert_equal(secondary.get("short",{}).get("draft_status"),"locked")
	TestSupport.assert_equal(secondary.has("free"),false)
	main.free()

func test_insufficient() -> void:
	var main = _instantiate_main()
	main.active_career = Fixtures.formal_junior_career(933)
	for jump in main.active_career.athlete.jumps.values(): jump.unlocked_rotations = 1
	main.active_career.active_programs = {}
	var before := JSON.stringify(main.active_career.to_dict())
	await main._on_pre_competition_action_requested(str(Fixtures.u_series_event().event_id),"adopt_coach_program","short")
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	TestSupport.assert_equal(FileAccess.file_exists(main.autosave_path),false)
	TestSupport.assert_equal(main.get_node("%GlobalMessage").text.contains("无法修复"),true)
	main.free()

func test_reentry() -> void:
	var main = load(MAIN_SCENE).instantiate()
	main.set_script(DelayedSaveMain)
	main.autosave_path = "user://test-coach-delay-%d.json" % Time.get_ticks_usec()
	_isolated_autosaves.append(main.autosave_path)
	Engine.get_main_loop().root.add_child(main)
	main.active_career = Fixtures.formal_acceptance_career("qualify")
	main.active_career.active_programs.short.elements.clear()
	var before := JSON.stringify(main.active_career.to_dict())
	var event_id := str(Fixtures.u_series_event().event_id)
	main._on_pre_competition_action_requested(event_id,"adopt_coach_program","short")
	TestSupport.assert_equal(main.saves,1)
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),before,"pending save cannot publish working programme")
	await main._on_pre_competition_action_requested(event_id,"adopt_coach_program","short")
	TestSupport.assert_equal(main.saves,1,"duplicate must not begin another save")
	await Engine.get_main_loop().process_frame
	TestSupport.assert_equal(main.active_career.active_programs.short.draft_status,"locked")
	TestSupport.assert_equal(main.active_career.program_archive.size(),1)
	main.free()

func _same_data(a, b, path: String = "root") -> bool:
	if (a is float or a is int) and (b is float or b is int):
		if absf(float(a)-float(b)) <= 0.00000001: return true
	elif a is Dictionary and b is Dictionary:
		if a.size() != b.size(): print("DATA DIFF ",path," size ",a.size()," / ",b.size()); return false
		for key in a:
			if not b.has(key) or not _same_data(a[key],b[key],path+"."+str(key)): return false
		return true
	elif a is Array and b is Array:
		if a.size() != b.size(): return false
		for i in a.size():
			if not _same_data(a[i],b[i],path+"["+str(i)+"]"): return false
		return true
	elif a == b: return true
	print("DATA DIFF ",path," ",a," / ",b)
	return false
