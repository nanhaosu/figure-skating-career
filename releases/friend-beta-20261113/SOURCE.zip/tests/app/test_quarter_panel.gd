extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const ProgramDraftService = preload("res://src/simulation/program_draft_service.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")

const PANEL_SCENE := "res://src/app/quarter_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
        {"name":"dated coach button retains full teaching metadata without publishing failed save","callable":test_dated_coach_metadata},
		{"name":"fresh coach period event response persists a complete training checkpoint", "callable":test_coach_period_event_resume.bind("report_pain",true)},
		{"name":"reopening a partial period restores its chosen attitude and cannot silently change its plan", "callable":test_partial_attitude_restore},
		{"name":"coach led settlement exposes pain decision and resumes the same period once", "callable":test_coach_period_event_resume},
		{"name":"reporting pain during coach led settlement remains actionable", "callable":test_coach_period_event_resume.bind("report_pain")},
		{"name":"replacing a disputed plan with an accepted plan closes stale authority window", "callable":test_revised_plan_closes_conflict},
		{"name": "quarter panel disables an invalid ninety five percent plan", "callable": test_quarter_panel_disables_an_invalid_thirteen_unit_plan},
		{"name": "quarter panel shows authority conflict during allocation", "callable": test_quarter_panel_shows_authority_conflict_during_allocation},
		{"name": "jump overload waits for event choice before advancing", "callable": test_jump_overload_waits_for_event_choice},
		{"name": "supportive family conflict remains visible in the panel", "callable": test_supportive_family_conflict_is_visible},
		{"name": "quarter panel presents individual jump mastery", "callable": test_quarter_panel_presents_jump_mastery},
		{"name": "quarter panel selects jump rotations", "callable": test_quarter_panel_selects_jump_rotations},
		{"name": "policy mode is default and advanced editor is collapsed", "callable": test_policy_mode_is_default},
		{"name": "coach led mode shows one proposal and four responses", "callable": test_coach_led_mode_has_four_responses},
		{"name": "visible advance button press starts training", "callable": test_visible_advance_button_press_starts_training},
		{"name": "first training click presents actionable teaching invitation", "callable": test_first_click_presents_invitation},
		{"name": "blocked advance button click surfaces the pending decision", "callable": test_blocked_button_surfaces_pending_decision},
		{"name": "coach led continue commits one meaningful period", "callable": test_coach_led_continue_commits_period},
		{"name": "beginner mode offers three coach plans and hides custom controls", "callable": test_beginner_recommendations},
		{"name": "choosing a coach recovery plan applies a complete allocation", "callable": test_choose_recommendation},
		{"name": "policy mode exposes exactly two focus slots", "callable": test_policy_mode_has_two_focus_slots},
		{"name": "policy generation produces one hundred percent plan", "callable": test_policy_generates_complete_plan},
		{"name": "reuse last plan restores exact shares", "callable": test_reuse_last_plan},
		{"name": "quarter panel shows roadmap entry when unconfigured", "callable": test_roadmap_entry_visible},
		{"name": "confirmed roadmap generates quarterly plan", "callable": test_roadmap_generates_plan},
		{"name": "post quarter roadmap event does not simulate twice", "callable": test_post_quarter_roadmap_event_does_not_simulate_twice},
		{"name": "program practice controls follow active programs", "callable": test_program_practice_controls_follow_active_programs},
		{"name": "new career can request both program editors", "callable": test_program_entry_buttons},
		{"name": "legal teaching programs enable internal competition invitation", "callable": test_internal_invitation_buttons},
	]

func test_partial_attitude_restore() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(515)
	career.clock.quarter = 2
	load("res://src/simulation/teaching_competition_service.gd").evaluate(career)
	career.internal_invitation_state["scheduled_week"] = 22
	var catalog := CatalogRepository.load_catalog()
	panel.setup(career,catalog)
	panel.select_training_intent("safer")
	panel.persist = func(_candidate): return true
	await panel.continue_training()
	TestSupport.assert_equal(career.training_period_state.intent.mode,"safer")
	panel.setup(career,catalog)
	TestSupport.assert_equal(panel._training_intent.mode,"safer","opening training must restore the saved period instead of switching it to accept")
	var elapsed := int(career.training_period_state.get("weeks_elapsed",0))
	TestSupport.assert_equal(panel.date_label.text.contains("已练%d周" % elapsed),true,"a paused period must show time already spent")
	TestSupport.assert_equal(panel.date_label.text.contains("剩余%d周" % (12-elapsed)),true,"remaining weeks cannot disappear when leaving and returning")
	TestSupport.assert_equal(panel.advance_button.text.contains("剩余"),true,"resume action must distinguish the remaining period from a new quarter")
	panel.select_training_intent("more_aggressive")
	TestSupport.assert_equal(panel._training_intent.mode,"safer","the existing period cannot be retrospectively replaced")
	TestSupport.assert_equal(panel.plan_error_label.text.contains("本期"),true,"a refused mid-period change must explain how to continue")
	TestSupport.assert_equal(panel.plan_error_label.is_visible_in_tree(),true,"coach-mode explanations cannot stay inside the hidden advanced editor")
	panel.free()

func test_coach_period_event_resume(choice_id: String = "hide_pain", fresh_period: bool = false) -> void:
	var catalog := CatalogRepository.load_catalog()
	var created = load("res://src/simulation/career_factory.gd").create("验收",2006,"entry_club_trial","family_supportive",712010990,catalog,3)
	TestSupport.assert_equal(created.errors, [])
	if created.career == null: return
	var career = created.career
	career.opening_stage = "complete"
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var first = load("res://src/simulation/meaningful_advance_service.gd").advance(career,intent)
	career.commit_from(first.career)
	load("res://src/simulation/internal_invitation_service.gd").defer(career)
	if fresh_period:
		career.training_period_state = {}
		career.internal_invitation_state.status = "completed"
		career.clock.quarter = 3
	var starting_quarter: int = career.clock.quarter
	var panel = _instantiate_panel()
	panel.setup(career,catalog)
	var save_path := "user://test-coach-event-%s-%s.json" % [choice_id,str(fresh_period)]
	var persistence_errors: Array = []
	panel.persist = func(candidate):
		var saved = load("res://src/persistence/save_repository.gd").save(candidate,save_path)
		if not saved.ok: persistence_errors.append_array(saved.errors)
		return saved.ok
	var completions: Array = []
	panel.training_period_completed.connect(func(result): completions.append(result))
	await panel.continue_training()
	TestSupport.assert_equal(panel.event_dialog.visible,true,"coach-led quarter stop must expose the pain choice instead of silently stopping")
	TestSupport.assert_equal(career.clock.quarter,starting_quarter)
	if panel.event_dialog.visible:
		await panel.resolve_event_choice(choice_id)
		TestSupport.assert_equal(persistence_errors,[],"responding to a coach event must produce a valid durable checkpoint: "+str(persistence_errors))
		for i in 4:
			if not panel.authority_confirmation.visible: break
			await panel._on_authority_response("accept")
		TestSupport.assert_equal(career.clock.quarter,starting_quarter+1)
		TestSupport.assert_equal(career.training_period_state,{})
		TestSupport.assert_equal(completions.size(),1)
		await panel.resolve_event_choice(choice_id)
		TestSupport.assert_equal(career.clock.quarter,starting_quarter+1)
		TestSupport.assert_equal(completions.size(),1)
	panel.free()
	for suffix in ["",".bak",".tmp"]:
		if FileAccess.file_exists(save_path+suffix): DirAccess.remove_absolute(ProjectSettings.globalize_path(save_path+suffix))

func test_revised_plan_closes_conflict() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.career_with_guardian(90.0,90.0)
	panel.setup(career,CatalogRepository.load_catalog())
	panel.set_allocations(Fixtures.jump_heavy_plan().allocations)
	TestSupport.assert_equal(panel.authority_confirmation.visible,true)
	panel.set_allocations(Fixtures.balanced_plan().allocations)
	TestSupport.assert_equal(panel._active_proposal.status,"resolved")
	TestSupport.assert_equal(panel.authority_confirmation.visible,false,"accepted replacement plan must release the exclusive authority window")
	TestSupport.assert_equal(career.clock.quarter,1,"changing a proposal does not advance the career")
	panel.free()

func test_internal_invitation_buttons() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(40)
	panel.setup(career, CatalogRepository.load_catalog())
	var start_button: Button = panel.find_child("InternalStartButton", true, false)
	TestSupport.assert_equal(start_button != null, true)
	if start_button == null: panel.free(); return
	TestSupport.assert_equal(start_button.disabled, true)
	for jump_id in ["toe_loop", "salchow", "loop"]: career.athlete.jumps[jump_id].unlocked_rotations = 1
	for segment in ["short", "free"]:
		var rules := InternalEventRules.for_teaching_group(segment)
		var proposal = ProgramDraftService.propose(career.athlete, segment, rules, {}, 40)
		var locked: Dictionary = ProgramDraftService.lock_for_competition(proposal.program,career.athlete,rules)
		TestSupport.assert_equal(Array(locked.errors).is_empty(),true)
		career.active_programs[segment] = locked.program.to_dict()
	panel.setup(career, CatalogRepository.load_catalog())
	TestSupport.assert_equal(start_button.disabled, true, "legal programs alone cannot create an invitation before week four")
	career.clock.quarter = 4
	panel.setup(career, CatalogRepository.load_catalog())
	TestSupport.assert_equal(start_button.disabled, false)
	TestSupport.assert_equal(panel.find_child("InternalStatusLabel", true, false).text.contains("教学赛"), true)
	var requests := [0]
	panel.internal_competition_requested.connect(func(): requests[0] += 1)
	start_button.pressed.emit()
	TestSupport.assert_equal(requests[0], 1)
	panel.free()

func test_program_entry_buttons() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(39), CatalogRepository.load_catalog())
	var short_button: Button = panel.find_child("ProgramShortButton", true, false)
	var free_button: Button = panel.find_child("ProgramFreeButton", true, false)
	TestSupport.assert_equal(short_button != null and free_button != null, true)
	TestSupport.assert_equal(panel.has_signal("program_requested"), true)
	if short_button != null and free_button != null and panel.has_signal("program_requested"):
		var requests: Array[String] = []
		panel.program_requested.connect(func(segment): requests.append(segment))
		short_button.pressed.emit()
		free_button.pressed.emit()
		TestSupport.assert_equal(requests, ["short", "free"])
	panel.free()

func test_program_practice_controls_follow_active_programs() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(38)
	panel.setup(career, CatalogRepository.load_catalog())
	var short_input: SpinBox = panel.find_child("ProgramShortInput", true, false)
	var free_input: SpinBox = panel.find_child("ProgramFreeInput", true, false)
	TestSupport.assert_equal(short_input != null and not short_input.editable, true)
	TestSupport.assert_equal(free_input != null and not free_input.editable, true)
	career.active_programs.short = SkatingProgram.create("short-2014", "short", [ProgramElement.create("spin", "spin").element]).program.to_dict()
	panel.setup(career, CatalogRepository.load_catalog())
	TestSupport.assert_equal(short_input.editable, true)
	TestSupport.assert_equal(free_input.editable, false)
	panel.free()

func test_quarter_panel_disables_an_invalid_thirteen_unit_plan() -> void:
	var panel = _instantiate_panel()
	if panel == null:
		return
	panel.setup(Fixtures.starting_career(51), CatalogRepository.load_catalog())
	panel.set_allocations({
		"skating_foundation": 20,
		"jump_toe_loop": 10, "jump_salchow": 10, "jump_loop": 5,
		"jump_flip": 5, "jump_lutz": 5, "jump_axel": 5,
		"rotation": 10, "conditioning": 10, "rest": 15,
	})
	TestSupport.assert_equal(panel.find_child("AllocationTotal", true, false).text, "已分配 95% / 100%")
	TestSupport.assert_equal(panel.get_node("%AdvanceButton").disabled, true)
	TestSupport.assert_equal(
		panel.find_child("PlanErrorLabel", true, false).text,
		"训练比例总和必须为100%，当前为95%",
	)
	panel.free()

func test_quarter_panel_selects_jump_rotations() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(19)
	career.athlete.jumps.lutz.unlocked_rotations = 1
	panel.setup(career, CatalogRepository.load_catalog())
	TestSupport.assert_equal(panel.available_rotations("lutz"), [1, 2])
	panel.set_jump_rotation("lutz", 2)
	TestSupport.assert_equal(panel.get_jump_rotation("lutz"), 2)
	TestSupport.assert_equal(panel.find_child("AllocationTotal", true, false).text, "已分配 100% / 100%")
	panel.free()

func test_quarter_panel_shows_authority_conflict_during_allocation() -> void:
	var panel = _instantiate_panel()
	if panel == null:
		return
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	panel.setup(career, CatalogRepository.load_catalog())
	panel.set_allocations(Fixtures.jump_heavy_plan().allocations)
	TestSupport.assert_equal(panel.get_node("%AuthorityConfirmation").visible, true)
	TestSupport.assert_equal(panel.get_node("%AuthorityConfirmation").find_child("Response_ask_reason", true, false) != null, true)
	TestSupport.assert_equal(career.clock.to_dict(), {"year": 2014, "quarter": 1})
	var emitted: Array = []
	panel.quarter_advanced.connect(func(outcomes): emitted.append(outcomes))
	TestSupport.assert_equal(
		panel.get_node("%AuthorityConfirmation").dialog_text.contains("监护人因健康优先调整计划"),
		true,
	)
	panel.confirm_authority_adjustment()
	panel.request_advance()
	panel.resolve_event_choice("reduce_load")
	TestSupport.assert_equal(career.clock.to_dict(), {"year": 2014, "quarter": 2})
	TestSupport.assert_equal(emitted.size(), 1)
	panel.free()

func test_jump_overload_waits_for_event_choice() -> void:
	var panel = _instantiate_panel()
	if panel == null: return
	var career := Fixtures.starting_career(14)
	career.relationships.guardian.control = 0.0
	career.relationships.coach.professional_trust = 80.0
	panel.setup(career, CatalogRepository.load_catalog())
	# Still concentrated after the accepted five-point safety reduction.
	panel.set_allocations({"skating_foundation":10,"jump_toe_loop":35,"jump_salchow":5,"jump_loop":5,"jump_flip":5,"jump_lutz":5,"jump_axel":5,"rotation":5,"conditioning":10,"rest":15,"program_short":0,"program_free":0})
	panel.confirm_authority_adjustment()
	panel.request_advance()
	TestSupport.assert_equal(career.clock.quarter, 1)
	TestSupport.assert_equal(panel.get_node("%EventDialog").visible, true)
	panel.resolve_event_choice("continue_training")
	TestSupport.assert_equal(career.clock.quarter, 2)
	panel.free()

func test_supportive_family_conflict_is_visible() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(14)
	panel.setup(career, CatalogRepository.load_catalog())
	panel.set_allocations(Fixtures.jump_heavy_plan().allocations)
	TestSupport.assert_equal(panel.find_child("AuthorityStatusLabel", true, false).text.contains("监护人"), true)
	TestSupport.assert_equal(panel.get_node("%AuthorityConfirmation").visible, true)
	panel.free()

func test_quarter_panel_presents_jump_mastery() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(14)
	Fixtures.clear_jump_progress(career, ["lutz"])
	career.athlete.jumps.lutz.unlocked_rotations = 1
	career.athlete.jumps.lutz.attempts = 50
	career.athlete.jumps.lutz.proficiency.single = 9.0
	career.athlete.jumps.lutz.attempt_evidence.single.attempts = 20
	career.athlete.jumps.lutz.attempt_evidence.single.successes = 5
	panel.setup(career, CatalogRepository.load_catalog())
	var text: String = panel.get_node("%JumpMasterySummary").text
	TestSupport.assert_equal(text.contains("勾手跳·单周"), true)
	TestSupport.assert_equal(text.contains("偶尔成功"), true)
	TestSupport.assert_equal(text.contains("100%"), false)
	panel.free()

func test_policy_mode_is_default() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(31), CatalogRepository.load_catalog())
	TestSupport.assert_equal(panel.find_child("PolicyModeContainer", true, false).visible, true)
	TestSupport.assert_equal(panel.find_child("AdvancedEditorContainer", true, false).visible, false)
	panel.free()

func test_coach_led_mode_has_four_responses() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(3110), CatalogRepository.load_catalog())
	var proposal: Label = panel.find_child("CoachProposalSummary", true, false)
	var responses: Control = panel.find_child("TrainingIntentResponses", true, false)
	TestSupport.assert_equal(proposal != null and not proposal.text.is_empty(), true)
	TestSupport.assert_equal(responses != null and responses.get_child_count() == 4, true)
	TestSupport.assert_equal(panel.get_node("%AdvanceButton").text, "按这个方向训练本期（12周）")
	TestSupport.assert_equal(panel.get_node("%AdvanceButton").disabled, false, "training-decision gate must not disable its own action")
	TestSupport.assert_equal(panel.find_child("AdvancedEditorContainer", true, false).visible, false)
	panel.free()

func test_visible_advance_button_press_starts_training() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(3112)
	career.internal_invitation_state.status = "completed"
	panel.setup(career, CatalogRepository.load_catalog())
	panel.persist = func(_candidate): return true
	var results: Array = []
	panel.training_period_completed.connect(func(result): results.append(result))
	panel.get_node("%AdvanceButton").pressed.emit()
	await Engine.get_main_loop().process_frame
	TestSupport.assert_equal(career.clock.quarter, 2)
	TestSupport.assert_equal(results.size(), 1)
	panel.free()

func test_blocked_button_surfaces_pending_decision() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(3113)
	career.condition_state.pending_training_events = [{
		"id": "test-progress", "signature": "roadmap_progress", "title": "讨论目标",
		"description": "训练后讨论", "trigger_codes": [], "cause_ids": [],
		"choices": [{"id": "roadmap_accept_revision", "label": "接受调整"}],
	}]
	panel.setup(career, CatalogRepository.load_catalog())
	var blocked: Array = []
	panel.advance_blocked.connect(func(node): blocked.append(node))
	TestSupport.assert_equal(panel.get_node("%AdvanceButton").disabled, false, "a blocker must remain clickable so it can explain the next action")
	panel.get_node("%AdvanceButton").pressed.emit()
	await Engine.get_main_loop().process_frame
	TestSupport.assert_equal(blocked.size(), 1)
	TestSupport.assert_equal(blocked[0].kind, "training_decision")
	panel.free()

func test_first_click_presents_invitation() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(722)
	career.clock.quarter = 2
	load("res://src/simulation/teaching_competition_service.gd").evaluate(career)
	career.internal_invitation_state["scheduled_week"] = 22
	career.internal_invitation_state.status = "not_ready"
	panel.setup(career, CatalogRepository.load_catalog())
	panel.persist = func(_candidate): return true
	await panel.continue_training()
	TestSupport.assert_equal(career.internal_invitation_state.status, "pending")
	TestSupport.assert_equal(panel.teaching_invitation_dialog.visible, true)
	TestSupport.assert_equal(panel.teaching_invitation_dialog.dialog_text.contains("准备节目"), true)
	var proposal = ProgramDraftService.propose(career.athlete,"short",InternalEventRules.for_teaching_group("short"),{},722)
	var locked = ProgramDraftService.lock_for_competition(proposal.program,career.athlete,InternalEventRules.for_teaching_group("short"))
	career.active_programs.short = locked.program.to_dict()
	panel._present_teaching_invitation()
	TestSupport.assert_equal(panel.teaching_invitation_dialog.ok_button_text,"准备自由滑")
	var requests: Array = []
	panel.program_requested.connect(func(segment): requests.append(segment))
	panel.teaching_invitation_dialog.confirmed.emit()
	TestSupport.assert_equal(requests,["free"])
	panel.free()

func test_coach_led_continue_commits_period() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(3111)
	career.internal_invitation_state.status = "completed"
	panel.setup(career, CatalogRepository.load_catalog())
	panel.persist = func(_candidate): return true
	var results: Array = []
	panel.training_period_completed.connect(func(result): results.append(result))
	await panel.continue_training()
	TestSupport.assert_equal(career.clock.quarter, 2)
	TestSupport.assert_equal(results.size(), 1)
	TestSupport.assert_equal(results[0].stop_reason, "quarter_complete")
	TestSupport.assert_equal(Array(results[0].facts).is_empty(), false)
	panel.free()

func test_beginner_recommendations() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(3101),CatalogRepository.load_catalog())
	var list = panel.find_child("RecommendationList",true,false)
	TestSupport.assert_equal(list != null,true)
	TestSupport.assert_equal(list.get_child_count(),3)
	TestSupport.assert_equal(list.get_child(0).text.contains("推荐"),true)
	TestSupport.assert_equal(panel.find_child("CustomPolicyContainer",true,false).visible,false)
	panel.free()

func test_choose_recommendation() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(3102),CatalogRepository.load_catalog())
	panel.choose_recommendation("recovery")
	TestSupport.assert_equal(panel._current_allocations().rest,40)
	TestSupport.assert_equal(panel.find_child("AllocationTotal",true,false).text,"已分配 100% / 100%")
	TestSupport.assert_equal(panel.find_child("PolicyForecast",true,false).text.contains("恢复"),true)
	panel.free()

func test_policy_mode_has_two_focus_slots() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(32), CatalogRepository.load_catalog())
	TestSupport.assert_equal(panel.find_children("FocusJump*", "OptionButton", true, false).size(), 2)
	panel.free()

func test_policy_generates_complete_plan() -> void:
	var panel = _instantiate_panel()
	panel.setup(Fixtures.starting_career(33), CatalogRepository.load_catalog())
	panel.set_policy("rotation_push")
	panel.set_focus_jump(0, "toe_loop", 2)
	TestSupport.assert_equal(panel.find_child("AllocationTotal", true, false).text, "已分配 100% / 100%")
	TestSupport.assert_equal(panel.find_child("PolicyForecast", true, false).text.is_empty(), false)
	panel.free()

func test_reuse_last_plan() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(34)
	panel.setup(career, CatalogRepository.load_catalog())
	panel.set_policy("recovery")
	var remembered: Dictionary = career.last_generated_plan.duplicate(true)
	panel.set_allocations(Fixtures.percentage_balanced_plan().shares)
	panel.reuse_last_plan()
	TestSupport.assert_equal(panel._current_allocations(), remembered.shares)
	panel.free()

func test_roadmap_entry_visible() -> void:
	var panel = _instantiate_panel(); panel.setup(Fixtures.starting_career(35), CatalogRepository.load_catalog())
	TestSupport.assert_equal(panel.find_child("RoadmapStatus", true, false).text.contains("尚未制定"), true)
	TestSupport.assert_equal(panel.find_child("RoadmapButton", true, false).text, "制定成长路线")
	panel.free()

func test_roadmap_generates_plan() -> void:
	var panel = _instantiate_panel(); var career := Fixtures.starting_career(36); panel.setup(career, CatalogRepository.load_catalog())
	var DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
	var roadmap = DevelopmentRoadmap.create("balanced", [{"age": 10, "rotations": 2, "count": 6}, {"age": 13, "rotations": 3, "count": 4}], ["toe_loop"], "", "normal").roadmap
	await panel.apply_roadmap(roadmap)
	TestSupport.assert_equal(career.development_roadmap.is_empty(), false)
	TestSupport.assert_equal(career.roadmap_revision_history.size(), 1)
	TestSupport.assert_equal(panel.find_child("AllocationTotal", true, false).text, "已分配 100% / 100%")
	panel.free()

func test_post_quarter_roadmap_event_does_not_simulate_twice() -> void:
	var panel = _instantiate_panel(); var career := Fixtures.starting_career(37)
	Fixtures.clear_jump_progress(career)
	Fixtures.clear_pre_career_load(career)
	panel.setup(career, CatalogRepository.load_catalog())
	var DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
	var roadmap = DevelopmentRoadmap.create("balanced", [{"age": 10, "rotations": 2, "count": 4}], ["toe_loop"], "", "normal").roadmap
	await panel.apply_roadmap(roadmap)
	# This fixture tests post-training event idempotence, not bypassing a newly
	# required guardian approval for the actual concentrated curriculum.
	# Route confirmation no longer manipulates the hidden advanced editor.
	# This legacy-quarter test explicitly opens that separate policy path.
	panel.set_policy("balanced_foundation")
	for response in 4:
		if panel._active_proposal.status == "resolved": break
		await panel._on_authority_response("accept")
	career.athlete.body.growth_trend = 75.0
	var emitted := [0]
	panel.quarter_advanced.connect(func(_outcomes): emitted[0] += 1)
	var before_step: int = career.rng_step
	panel._apply_pending_plan()
	TestSupport.assert_equal(career.rng_step, before_step + 1,"legacy quarter result: "+panel.plan_error_label.text)
	TestSupport.assert_equal(emitted[0], 0)
	if panel._pending_events.is_empty():
		TestSupport.assert_equal(false,true,"roadmap reassessment must remain actionable: "+panel.plan_error_label.text)
		panel.free()
		return
	TestSupport.assert_equal(panel._pending_events[0].signature, "roadmap_body_reassessment")
	panel.resolve_event_choice("roadmap_temporary_safety")
	TestSupport.assert_equal(career.rng_step, before_step + 1)
	TestSupport.assert_equal(emitted[0], 1)
	panel.free()

func _instantiate_panel():
	TestSupport.assert_equal(ResourceLoader.exists(PANEL_SCENE), true)
	if not ResourceLoader.exists(PANEL_SCENE):
		return null
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	return panel

func test_dated_coach_metadata() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(9901)
	career.internal_invitation_state.status = "completed"
	TestSupport.assert_equal(load("res://src/simulation/dated_training_service.gd").activate(career).ok,true)
	panel.setup(career,CatalogRepository.load_catalog())
	var built: Dictionary = panel._actual_coach_course()
	TestSupport.assert_equal(not built.plan.coach_decision.is_empty(),true,"fixture must have actual teaching metadata")
	var before := career.to_dict()
	var candidates: Array = []
	panel.persist = func(candidate): candidates.append(candidate.to_dict()); return false
	await panel.continue_training()
	if candidates.is_empty():
		panel._pending_events.clear()
		await panel._apply_pending_plan()
	TestSupport.assert_equal(panel._active_proposal.desired.to_dict(),built.plan.to_dict(),"dated button must submit complete coach plan")
	TestSupport.assert_equal(candidates.size(),1,"configured course must reach the existing persistence boundary: "+panel.plan_error_label.text)
	if not candidates.is_empty():
		TestSupport.assert_equal(candidates[0].last_generated_plan.desired,built.plan.to_dict())
	TestSupport.assert_equal(career.to_dict(),before,"failed save must not publish configured course")
	var edited: Dictionary = built.plan.shares
	edited.skating_foundation -= 5
	edited.rest += 5
	panel.set_allocations(edited)
	panel.request_advance()
	TestSupport.assert_equal(panel._active_proposal.desired.shares,edited,"manual course edits must still use player allocations")
	TestSupport.assert_equal(panel._active_proposal.desired.coach_decision,{},"manual edits must not reuse stale coach metadata")
	panel.free()





