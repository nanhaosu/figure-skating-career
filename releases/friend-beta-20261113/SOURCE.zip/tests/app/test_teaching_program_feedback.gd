extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const E = preload("res://src/domain/program_element.gd")
const P = preload("res://src/domain/skating_program.gd")
const R = preload("res://src/content/internal_event_rules.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"legal teaching Axel combination has no contradictory slot warning","callable":teaching},
		{"name":"formal prescribed Axel still warns when used in combination","callable":formal}]

func _panel(rules: Dictionary):
	var c = F.formal_junior_career(731)
	var axel = E.create("a","jump","axel",1).element
	axel.set_combination_parts([{"jump_id":"toe_loop","rotations":2}])
	var p = P.create("teaching-feedback","short",[axel,E.create("l","jump","lutz",1).element,E.create("s","spin").element,E.create("st","step_sequence").element]).program
	c.active_programs.short = p.to_dict()
	var panel = load("res://src/app/program_editor_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(c,"short",rules,{})
	return panel

func teaching() -> void:
	var panel = _panel(R.for_teaching_group("short"))
	T.assert_equal(panel.lock_button.disabled,false,"the teaching programme must actually be legal")
	T.assert_equal(panel.action_list.get_item_text(0).contains("⚠"),false,"a legal teaching Axel combination must not be labeled as an illegal formal solo Axel")
	panel.free()

func formal() -> void:
	var panel = _panel(R.for_season(2019,"junior","short"))
	T.assert_equal(panel.lock_button.disabled,true)
	T.assert_equal(panel.action_list.get_item_text(0).contains("⚠"),true)
	panel.free()
