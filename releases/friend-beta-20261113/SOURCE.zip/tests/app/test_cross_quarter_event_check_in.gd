extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"cross-quarter event permits check-in through its final quarter","callable":overlap}]
func overlap() -> void:
	var c = F.formal_acceptance_career("qualify")
	var applied: Dictionary = load("res://src/simulation/career_command_service.gd").apply(c,{"type":"apply_entry","event_id":"cn_club_league_2018_stage_1","route_id":"enter"})
	T.assert_equal(applied.ok,true)
	if not applied.ok: return
	for quarter in [1,3,4]:
		var candidate = applied.career.transaction_copy()
		candidate.clock.quarter = quarter
		var main = load("res://src/app/main.tscn").instantiate()
		Engine.get_main_loop().root.add_child(main)
		main.offer_new_career(candidate); main.confirm_new_career_replacement()
		var started: Dictionary = main.start_formal_competition("cn_club_league_2018_stage_1")
		T.assert_equal(started.ok,quarter == 3,"June30–July2 event check-in boundary, quarter=%d: %s" % [quarter,str(started.get("errors",[]))])
		main.free()
