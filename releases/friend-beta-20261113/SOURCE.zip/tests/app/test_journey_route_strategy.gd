extends RefCounted
const T = preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"fresh planned journey uses balanced from its first formal start","callable":planned},{"name":"steady journey can retain conservative early choices","callable":steady},{"name":"fresh planned route does not inherit old continuation attack choices","callable":later},{"name":"meaningful public practice chooses an offered response","callable":practice_response},{"name":"planned short program prepares solo loop early and combination last","callable":layout}]
func planned() -> void:
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.assigned_route = true
	for stage in range(1,6): T.assert_equal(driver._event_strategy("cn_club_league_2018_stage_%d" % stage),"balanced")
func steady() -> void:
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.assigned_route = false
	T.assert_equal(driver._event_strategy("cn_club_league_2018_stage_1"),"safe")
func later() -> void:
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.assigned_route = true
	for stage in range(1,6): T.assert_equal(driver._event_strategy("cn_club_league_2019_stage_%d" % stage),"balanced")
func practice_response() -> void:
	var driver = load("res://scripts/international_season_journey.gd").new()
	T.assert_equal(driver._practice_response({"practice":{"meaningful":false,"response_options":[]}}),"accept")
	T.assert_equal(driver._practice_response({"practice":{"meaningful":true,"response_options":["simplify_combination","focused_runthrough"]}}),"simplify_combination")
func layout() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var driver = load("res://scripts/international_season_journey.gd").new(); driver.main = state.main
	driver._edit_program("short",load("res://src/content/internal_event_rules.gd").for_season(2018,"junior","short"),true)
	T.assert_equal(driver.errors,[])
	var elements: Array = state.main.active_career.active_programs.short.elements
	var jumps: Array = elements.filter(func(element): return element.kind == "jump")
	var saved = load("res://src/domain/skating_program.gd").from_dict(state.main.active_career.active_programs.short)
	var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(2018,"junior","short")
	T.assert_equal(load("res://src/simulation/program_validator.gd").validate(saved,state.main.active_career.athlete,rules),[],"the explicit layout must satisfy the published season rules")
	T.assert_equal(jumps.any(func(element): return not element.combination_parts.is_empty()),true,"the short programme must retain one combination")
	state.main.free()
