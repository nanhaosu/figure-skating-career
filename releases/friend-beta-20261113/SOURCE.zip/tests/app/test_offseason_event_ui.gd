extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"offseason event can be inspected and returned without committing","callable":test_return},
		{"name":"offseason memory survives a failed save and one durable retry","callable":test_retry},
		{"name":"summer memory is optional and returning leaves training unblocked","callable":test_optional_home_entry}]

func test_optional_home_entry() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(913)
	main.active_career.clock.year = 2019
	main.active_career.season_program_plan.season_id = "2019-20"
	main.active_career.season_state.season_history = {"2018-19":{"season":{},"record_book":{},"ranking_state":{},"clock":{}}}
	main._open_player_home()
	var optional = main.career_home_panel.find_child("OffseasonOptional",true,false)
	T.assert_equal(optional != null,true,"summer memories need a discoverable optional home entry")
	if optional != null:
		T.assert_equal(optional.visible,true)
		var before: Dictionary = main.active_career.to_dict()
		optional.pressed.emit()
		T.assert_equal(main._decision_dialog.visible,true)
		main._decision_dialog.find_child("OffseasonReturn",true,false).pressed.emit()
		T.assert_equal(main.active_career.to_dict(),before)
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(main.active_career)
	bundle.calendar.events = []
	T.assert_equal(preload("res://src/simulation/season_progression_service.gd").quarter_gate(main.active_career,bundle),{},"unread memories must not gate training")
	main.free()

func test_retry() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = load("res://tests/simulation/test_offseason_events.gd").new()._career()
	var before: Dictionary = main.active_career.to_dict()
	var event: Dictionary = load("res://src/simulation/offseason_event_service.gd").pending(main.active_career)
	main._present_season_node(event)
	main.autosave_path = "user://missing-memory-directory-%d/autosave.json" % Time.get_ticks_usec()
	await main._resolve_offseason_event(event.id,"personal")
	T.assert_equal(main.active_career.to_dict() == before,true)
	T.assert_equal(main.get_node("CareerDecisionDialog").visible,true)
	main.autosave_path = "user://test-offseason-retry.json"
	await main._resolve_offseason_event(event.id,"personal")
	T.assert_equal(main.active_career.experience_state.relationship_memories.size(),1)
	var after: Dictionary = main.active_career.to_dict()
	await main._resolve_offseason_event(event.id,"personal")
	T.assert_equal(main.active_career.to_dict() == after,true)
	main.free()

func test_return() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(913)
	main.active_career.clock.year = 2019
	main.active_career.clock.quarter = 3
	main.active_career.season_state.season_history = {"2018-19":{"season":{},"record_book":{},"ranking_state":{},"clock":{}}}
	var before: Dictionary = main.active_career.to_dict()
	var event: Dictionary = load("res://src/simulation/offseason_event_service.gd").pending(main.active_career)
	main._present_season_node(event)
	var dialog = main.get_node("CareerDecisionDialog")
	T.assert_equal(dialog.find_child("OffseasonChoice_personal",true,false) != null,true)
	var back = dialog.find_child("OffseasonReturn",true,false)
	T.assert_equal(back != null,true)
	if back != null: back.pressed.emit()
	T.assert_equal(dialog.visible,false)
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()
