extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const PANEL_SCENE := "res://src/app/realtime_technical_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name": "technical panel shows abbreviation base value and live goe", "callable": test_live_element_display},
		{"name": "review element changes from yellow to final red", "callable": test_review_resolution},
		{"name": "technical row shows final element score", "callable": test_element_score},
	]

func test_element_score() -> void:
	var panel = _panel()
	panel.push_element({"element_id":"j1", "abbreviation":"3F+3T", "base_value":9.5, "live_goe":0.4, "element_score":9.9, "status":"review"})
	panel.finalize_review("j1", {"abbreviation":"3F!+3T<", "base_value":8.7, "live_goe":-1.8, "element_score":6.9, "status":"error"})
	TestSupport.assert_equal(panel.get_node("%ElementList").get_child_count(), 1)
	TestSupport.assert_equal(panel.find_child("Score", true, false).text.contains("得分 6.90"), true)
	panel.free()

func test_live_element_display() -> void:
	var panel = _panel()
	panel.reset_segment("短节目")
	panel.push_element({"element_id": "jump-1", "abbreviation": "2Lz", "base_value": 2.10, "live_goe": 0.42, "status": "success"})
	var row: Control = panel.find_child("Element_jump-1", true, false)
	TestSupport.assert_equal(row.find_child("Score", true, false).text, "2Lz  ·  GOE +0.42\n基础分 2.10")
	TestSupport.assert_equal(row.find_child("Status", true, false).text, "完成")
	TestSupport.assert_equal(row.find_child("StatusBar", true, false).color, panel.SUCCESS_COLOR)
	panel.free()

func test_review_resolution() -> void:
	var panel = _panel()
	panel.reset_segment("自由滑")
	panel.push_element({"element_id": "jump-2", "abbreviation": "3Lz", "base_value": 5.90, "live_goe": -0.59, "status": "review"})
	var row: Control = panel.find_child("Element_jump-2", true, false)
	TestSupport.assert_equal(row.find_child("Status", true, false).text, "技术组复核中")
	TestSupport.assert_equal(row.find_child("StatusBar", true, false).color, panel.REVIEW_COLOR)
	panel.finalize_review("jump-2", {"abbreviation": "3Lz<", "base_value": 4.72, "live_goe": -1.18, "status": "error"})
	TestSupport.assert_equal(row.find_child("Score", true, false).text, "3Lz<  ·  GOE -1.18\n基础分 4.72")
	TestSupport.assert_equal(row.find_child("Status", true, false).text, "扣分")
	TestSupport.assert_equal(row.find_child("StatusBar", true, false).color, panel.ERROR_COLOR)
	panel.free()

func _panel():
	TestSupport.assert_equal(ResourceLoader.exists(PANEL_SCENE), true)
	if not ResourceLoader.exists(PANEL_SCENE): return null
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	return panel
