extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "program editor returns to the page that opened it", "callable": test_program_sources},
		{"name": "read-only route round trips do not mutate career state", "callable": test_read_only_round_trip},
		{"name": "unsaved program return offers keep discard and cancel", "callable": test_unsaved_return_choices},
	]

func test_program_sources() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(95001)
	main._open_player_home()
	main.open_program_editor("short")
	main.get_node("%ProgramEditorPanel").closed.emit()
	T.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	main.open_next_quarter()
	main.open_program_editor("short")
	main.get_node("%ProgramEditorPanel").closed.emit()
	T.assert_equal(main.get_node("%QuarterPanel").visible, true)
	main.free()

func test_read_only_round_trip() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(95002)
	main._open_player_home()
	var before := JSON.stringify(main.active_career.to_dict())
	main.open_route("records", {}, main.screen_router.current())
	main.back_route()
	T.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	T.assert_equal(JSON.stringify(main.active_career.to_dict()), before)
	main.free()

func test_unsaved_return_choices() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(95003)
	main._open_player_home()
	main.open_program_editor("short")
	var editor = main.get_node("%ProgramEditorPanel")
	editor.program.music.title = "临时修改"
	editor.get_node("%CloseButton").pressed.emit()
	T.assert_equal(editor.get_node("%UnsavedReturnDialog").visible, true)
	T.assert_equal(editor.visible, true)
	editor.cancel_return()
	T.assert_equal(editor.visible, true)
	editor.get_node("%CloseButton").pressed.emit()
	editor.discard_changes()
	T.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	main.free()
