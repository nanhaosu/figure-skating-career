extends SceneTree

func _initialize() -> void:
	call_deferred("probe")

func probe() -> void:
	var failed := false
	var fixture = load("res://tests/app/test_broadcast_playback.gd").new()
	for dimensions in [Vector2i(1280,720),Vector2i(960,540)]:
		var width: int = dimensions.x
		var viewport := SubViewport.new()
		viewport.size = dimensions
		root.add_child(viewport)
		var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
		viewport.add_child(panel)
		panel.present_session(fixture._session())
		panel.show_segment(fixture._record())
		panel._elapsed = 0.7
		panel._reveal_due_elements()
		for i in 8: await process_frame
		var ice: Rect2 = panel.get_node("%CompetitionIceView").get_global_rect()
		var tech: Rect2 = panel.get_node("%TechnicalPanel").get_global_rect()
		var end: Rect2 = panel.get_node("%StartPlaybackButton").get_global_rect()
		var commentary: Rect2 = panel.get_node("%CommentaryDesk").get_global_rect()
		var technical_clear_of_ice := not ice.intersects(tech)
		var dominant_ice := ice.size.x >= float(width) * 0.58
		var all_visible: bool = panel.get_node("%BroadcastView").visible and panel.get_node("%CompetitionIceView").visible and panel.get_node("%TechnicalPanel").visible and panel.get_node("%CommentaryDesk").visible
		if not technical_clear_of_ice or not dominant_ice or tech.end.x > width or commentary.end.y > dimensions.y or end.end.y > dimensions.y or not all_visible:
			push_error("layout %s ice %s tech %s end %s" % [dimensions,ice,tech,end])
			failed = true
		var row: Control = panel.get_node("%TechnicalPanel").get_node("%ElementList").get_child(0)
		if row.get_global_rect().end.x > tech.end.x: failed = true
		print("BOUNDS %d ice %s tech %s controls_end %s" % [width,ice,tech,end.end])
		viewport.free()
		var internal_viewport := SubViewport.new(); internal_viewport.size = dimensions; root.add_child(internal_viewport)
		var internal = load("res://src/app/internal_competition_panel.tscn").instantiate(); internal_viewport.add_child(internal)
		internal.present({"event_name":"俱乐部内部选拔赛","segment_name":"自由滑","segment":"free","athlete_name":"欧阳娜塔莉娅·很长的运动员姓名","music_title":"一首名字同样很长的自由滑曲目"})
		internal.load_segment(fixture._record("free"))
		for i in 8: await process_frame
		var internal_ice: Rect2 = internal.get_node("%CompetitionIceView").get_global_rect()
		var internal_tech: Rect2 = internal.get_node("%TechnicalPanel").get_global_rect()
		var internal_controls: Rect2 = internal.get_node("%SettleButton").get_global_rect()
		if internal_ice.intersects(internal_tech) or internal_ice.size.x < float(width)*0.58 or internal_controls.end.y > dimensions.y:
			push_error("internal layout %s ice %s tech %s controls %s" % [dimensions,internal_ice,internal_tech,internal_controls]); failed = true
		internal_viewport.free()
	quit(1 if failed else 0)
