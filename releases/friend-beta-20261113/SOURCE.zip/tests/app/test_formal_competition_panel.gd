extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const BroadcastFixture = preload("res://tests/app/test_broadcast_playback.gd")
const PANEL_SCENE := "res://src/app/formal_competition_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"return from replay restores pending score acknowledgment and reveal stage","callable":test_return_pending_score},
		{"name":"international archive never presents domestic zero or junior candidate band as its consequence","callable":test_international_archive_consequence},
		{"name": "formal event shell presents real event metadata", "callable": test_event_shell},
		{"name": "formal event metadata follows senior and junior discipline", "callable": test_event_level},
		{"name": "formal roster lists every entrant", "callable": test_complete_roster},
		{"name": "formal strategy is a single choice", "callable": test_strategy_choice},
		{"name": "practice choices appear only for meaningful observation", "callable": test_practice_visibility},
		{"name": "formal broadcast exposes automatic playback controls", "callable": test_broadcast_controls},
		{"name": "short standings mark top twenty four cut", "callable": test_short_cut_line},
		{"name": "final archive exposes clickable protocol for every entrant", "callable": test_final_archive_protocols},
		{"name": "broadcast holds credited spin and step levels before standings", "callable": test_credited_levels_visible_before_standings},
		{"name": "formal playback stages kiss and cry without changing committed score", "callable": test_staged_kiss_and_cry},
	]

func test_international_archive_consequence() -> void:
	var panel = _panel()
	var career = load("res://tests/fixtures.gd").starting_career(1839)
	for event in [{"event_id":"isu_owg2022","scope":"international","event_family":"olympic","ranking_points_system":"isu_world_standings"},{"event_id":"cn_test","scope":"domestic","event_family":"national_junior","ranking_points_system":"domestic"}]:
		var archive := {"event_id":event.event_id,"event":event,"consequence_summary":{"domestic_points_awarded":9 if event.scope == "domestic" else 0,"candidate_band":"leading"},"final_standings":[],"short_standings":[]}
		panel.present_final_archive(archive)
		var text: String = panel.get_node("%ConsequenceLabel").text
		var post: Dictionary = load("res://src/presentation/post_competition_presenter.gd").build(career,archive)
		if event.scope == "international":
			TestSupport.assert_equal(not text.contains("国内积分") and not text.contains("候选观察档"),true,"Olympic result is not a domestic junior selection receipt")
			TestSupport.assert_equal(not str(post.consequences.text).contains("国内积分"),true,"the post-race consumer must not repeat a default domestic zero")
		else:
			TestSupport.assert_equal(text.contains("国内积分 +9"),true,"real domestic receipts must not be removed")
			TestSupport.assert_equal(str(post.consequences.text).contains("国内积分9"),true)
	panel.free()

func test_staged_kiss_and_cry() -> void:
	var fixture = BroadcastFixture.new(); var panel = load(PANEL_SCENE).instantiate(); Engine.get_main_loop().root.add_child(panel)
	panel.present_session(fixture._session()); var record := fixture._record(); var before := JSON.stringify(record); var completed: Array[String] = []
	panel.playback_completed.connect(func(segment): completed.append(segment))
	panel.show_segment(record); panel._begin_confirmation()
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,true)
	TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"waiting")
	panel._process(0.7); TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"technical_confirmed")
	panel._process(0.7); TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"components_confirmed")
	panel._process(0.7); TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"final")
	panel._process(0.4)
	TestSupport.assert_equal(completed,[],"score reveal must not advance standings")
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,true)
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,false)
	TestSupport.assert_equal(completed,["short"])
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(completed,["short"],"acknowledgment emits exactly once")
	TestSupport.assert_equal(JSON.stringify(record),before)
	panel.free()

func test_event_level() -> void:
	var panel = _panel()
	var bundle := preload("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	for event_id in ["cn_national_championships_2018","cn_club_league_2018_stage_1"]:
		var session := _session(0,false)
		for event in bundle.calendar.events:
			if event.event_id == event_id: session.event = event
		panel.present_session(session)
		TestSupport.assert_equal(panel.get_node("%EventMeta").text.contains("成年组女子单人滑" if event_id == "cn_national_championships_2018" else "青年组女子单人滑"),true)
		var expected_level := "成年组" if event_id == "cn_national_championships_2018" else "青年组"
		TestSupport.assert_equal(panel.get_node("PreparationView/Eyebrow").text.contains(expected_level),true)
		TestSupport.assert_equal(panel.get_node("PreparationView/Eligibility").text.contains(expected_level),true)
	var men := _session(0,false)
	men.event.level_options = ["senior"]; men.event.discipline = "men_singles"
	panel.present_session(men)
	TestSupport.assert_equal(panel.get_node("%EventMeta").text.contains("成年组男子单人滑"),true)
	panel.free()

func test_credited_levels_visible_before_standings() -> void:
	var panel = _panel()
	panel.present_session(_session(30, false))
	panel.show_segment({
		"segment":"free",
		"performance":{"elements":[
			{"element_id":"spin", "kind":"spin", "abbreviation":"FCSp", "base_value":2.5, "live_goe":0.1, "status":"review"},
			{"element_id":"steps", "kind":"step_sequence", "abbreviation":"StSq", "base_value":2.6, "live_goe":0.1, "status":"review"},
		]},
		"technical_review":{"final_elements":[
			{"element_id":"spin", "abbreviation":"FCSp3", "base_value":2.8, "status":"success", "call_confidence":"clear"},
			{"element_id":"steps", "abbreviation":"StSq2", "base_value":2.6, "status":"success", "call_confidence":"clear"},
		]},
		"protocol":{"element_scores":[{"element_id":"spin", "goe":0.28, "total":3.08}, {"element_id":"steps", "goe":0.12, "total":2.72}]},
		"route_execution":{"points":[], "action_anchors":[], "action_phases":[]},
	})
	var completed: Array[String] = []
	panel.playback_completed.connect(func(segment): completed.append(segment))
	TestSupport.assert_equal(panel._live_elements()[0].abbreviation, "FCSp3")
	TestSupport.assert_equal(panel._live_elements()[1].abbreviation, "StSq2")
	panel._elapsed = 1.0
	panel._reveal_due_elements()
	panel._begin_confirmation()
	TestSupport.assert_equal(panel.get_node("%BroadcastView").visible, true)
	TestSupport.assert_equal(completed, [])
	var rows: Array = panel.get_node("%TechnicalPanel").get_node("%ElementList").get_children()
	TestSupport.assert_equal(rows[0].get_node("Score").text.contains("FCSp3  ·  GOE +0.28\n基础分 2.80"), true)
	TestSupport.assert_equal(rows[1].get_node("Score").text.contains("StSq2  ·  GOE +0.12\n基础分 2.60"), true)
	panel._process(3.0)
	TestSupport.assert_equal(completed, [])
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(completed, ["free"])
	panel.free()

func test_short_cut_line() -> void:
	var panel = _panel()
	panel.present_short_standings(_standing_rows(34))
	TestSupport.assert_equal(panel.cut_after_rank, 24)
	TestSupport.assert_equal(panel.standing_button_for("athlete-24").text.contains("晋级"), true)
	TestSupport.assert_equal(panel.standing_button_for("athlete-25").text.contains("未晋级"), true)
	panel.free()

func test_final_archive_protocols() -> void:
	var panel = _panel()
	var rows := _standing_rows(30)
	var short_results := {}; var free_results := {}
	for row in rows:
		short_results[row.athlete_id] = {"protocol":{"element_scores":[], "component_scores":{}, "total":row.short_score}}
	panel.present_final_archive({"final_standings":rows, "short_standings":rows, "short_results":short_results, "free_results":free_results})
	TestSupport.assert_equal(panel.get_node("%StandingsList").get_child_count(), 30)
	panel.standing_button_for("athlete-29").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%ProtocolOverlay").visible, true)
	panel.free()

func _standing_rows(count: int) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	for i in count:
		rows.append({"rank":i + 1, "athlete_id":"athlete-%d" % i, "name":"选手%02d" % i, "federation":"CHN", "club_id":"club", "short_score":60.0-i, "free_score":100.0-i, "total_score":160.0-i, "qualified":i < 24, "is_player":i == 0})
	return rows

func test_broadcast_controls() -> void:
	var panel = _panel()
	panel.present_session(_session(30, false))
	panel.show_segment({"segment":"short", "performance":{"elements":[]}, "route_execution":{"points":[], "action_anchors":[], "action_phases":[]}})
	TestSupport.assert_equal(panel.get_node("%BroadcastView").visible, true)
	TestSupport.assert_equal(panel.get_node("%Speed1x").text, "1×")
	TestSupport.assert_equal(panel.get_node("%Speed15x").text, "1.5×")
	TestSupport.assert_equal(panel.get_node("%Speed2x").text, "2×")
	TestSupport.assert_equal(panel.get_node("%CommentaryDesk") != null, true)
	panel.free()

func test_event_shell() -> void:
	var panel = _panel()
	if panel == null: return
	panel.present_session(_session(34, false))
	TestSupport.assert_equal(panel.get_node("%EventTitle").text.contains("U系列"), true)
	TestSupport.assert_equal(panel.get_node("%EventMeta").text.contains("2018-09-12"), true)
	TestSupport.assert_equal(panel.get_node("%RosterCount").text.contains("34"), true)
	panel.free()

func test_complete_roster() -> void:
	var panel = _panel()
	if panel == null: return
	panel.present_session(_session(34, false))
	panel.show_roster()
	TestSupport.assert_equal(panel.get_node("%RosterList").get_child_count(), 34)
	TestSupport.assert_equal(panel.get_node("%RosterOverlay").visible, true)
	panel.free()

func test_strategy_choice() -> void:
	var panel = _panel()
	if panel == null: return
	var selected: Array[String] = []
	panel.strategy_selected.connect(func(id): selected.append(id))
	panel.present_session(_session(34, false))
	panel.get_node("%BalancedStrategyButton").pressed.emit()
	TestSupport.assert_equal(panel.selected_strategy_id, "balanced")
	TestSupport.assert_equal(selected, ["balanced"])
	TestSupport.assert_equal(panel.get_node("%BalancedStrategyButton").button_pressed, true)
	TestSupport.assert_equal(panel.get_node("%SafeStrategyButton").button_pressed, false)
	panel.free()

func test_practice_visibility() -> void:
	var panel = _panel()
	if panel == null: return
	panel.present_session(_session(30, false))
	panel.show_practice()
	TestSupport.assert_equal(panel.get_node("%PracticeOverlay").visible, false)
	panel.present_session(_session(30, true))
	panel.show_practice()
	TestSupport.assert_equal(panel.get_node("%PracticeOverlay").visible, true)
	TestSupport.assert_equal(panel.get_node("%PracticeChoices").get_child_count() > 0, true)
	panel.free()

func _session(count: int, meaningful: bool) -> Dictionary:
	var roster: Array[Dictionary] = []
	for index in count:
		roster.append({"athlete_id": "athlete-%d" % index, "name": "选手%02d" % index, "federation": "CHN", "club_id": "club-%d" % (index % 5), "is_player": index == 0})
	return {
		"event": {"name": "2018中国花样滑冰俱乐部联赛U系列", "start_date": "2018-09-12", "end_date": "2018-09-16", "location": "哈尔滨", "level_options": ["青年组女子单人滑"]},
		"roster": roster, "strategy_id": "balanced",
		"practice": {"meaningful": meaningful, "headline": "公开训练中勾手跳用刃受到关注", "response_options": [{"id":"accept", "label":"维持方案"}, {"id":"protect", "label":"降低风险"}]},
	}

func _panel():
	TestSupport.assert_equal(ResourceLoader.exists(PANEL_SCENE), true)
	if not ResourceLoader.exists(PANEL_SCENE): return null
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	return panel

func test_return_pending_score() -> void:
	var fixture = BroadcastFixture.new()
	for awaiting in [false, true]:
		var panel = _panel()
		panel.present_session(fixture._session())
		panel.show_segment(fixture._record())
		if awaiting: panel._skip_result()
		else: panel._begin_confirmation(); panel._process(0.7)
		var stage: String = panel.get_node("%KissAndCryPanel").reveal_stage
		panel._return_from_kiss_and_cry()
		panel.set_focus_skater("npc-9",true)
		TestSupport.assert_equal(panel.show_replay("npc-9","short"),true)
		panel._return_from_replay()
		TestSupport.assert_equal(panel.get_node("%OpenKissAndCryButton").visible,true,"pending score must remain reachable after rival replay")
		panel.get_node("%OpenKissAndCryButton").pressed.emit()
		TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,stage,"return must restore player score reveal")
		if not awaiting: panel._process(2.0)
		var completed: Array[String] = []
		panel.playback_completed.connect(func(segment): completed.append(segment))
		panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
		TestSupport.assert_equal(completed,["short"])
		panel.free()

