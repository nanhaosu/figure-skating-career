extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const TrainingIntent = preload("res://src/domain/training_intent.gd")
const MeaningfulAdvanceService = preload("res://src/simulation/meaningful_advance_service.gd")

const PANEL_SCENE := "res://src/app/summary_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"physical overview fills second line with ordinary progress once","callable":test_physical_overview_no_duplicate},
		{"name":"default training card preserves late physical cost and recovery","callable":test_late_physical_summary},
		{"name": "summary panel localizes nonzero deltas and causes", "callable": test_summary_panel_localizes_nonzero_deltas_and_causes},
		{"name": "summary panel groups conditioning recovery with body", "callable": test_summary_panel_groups_conditioning_recovery_with_body},
		{"name": "summary panel groups year end growth observation", "callable": test_summary_panel_groups_year_end_growth_observation},
		{"name": "summary localizes dynamic jump and event cause codes", "callable": test_summary_localizes_dynamic_codes},
		{"name": "summary uses two readable columns", "callable": test_summary_uses_two_readable_columns},
		{"name": "summary presents aggregate jump attempts", "callable": test_summary_presents_aggregate_jump_attempts},
		{"name": "meaningful sections precede collapsed details", "callable": test_meaningful_sections_precede_collapsed_details},
		{"name": "beginner summary uses four story cards", "callable": test_beginner_summary_uses_four_story_cards},
		{"name": "adult training decisions appear in the relationship card", "callable": test_relationship_card_explains_adult_decisions},
		{"name": "milestone appears in primary breakthrough section", "callable": test_milestone_appears_in_breakthroughs},
		{"name": "summary exposes optional milestone advance and ledger", "callable": test_milestone_advance_controls},
		{"name": "coach led summary separates plan actual changes and next step", "callable": test_training_period_factual_cards},
		{"name": "training overview stays compact while complete records remain expandable", "callable": test_training_overview_compact},
		{"name": "post competition summary reports an ordinary result before returning home", "callable": test_post_competition_factual_return},
	]

func test_physical_overview_no_duplicate() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(796)
	var facts: Array = [
		{"kind":"state_change","target":"impact_load","delta":8.0,"evidence_refs":["outcomes.impact_load"]},
		{"kind":"state_change","target":"toe_loop.single.proficiency","delta":1.0,"evidence_refs":["outcomes.toe_loop"]},
	]
	panel.present_training_period(career,{"career":career,"before":career,"facts":facts,"stop_reason":"quarter_complete"})
	var text: String = panel.get_node("%RelationshipSummary").text
	TestSupport.assert_equal(text.count("冲击负荷"),1,"physical summary must not repeat its source row")
	TestSupport.assert_equal(text.contains("后外点冰跳单周熟练度"),true,"ordinary progress fills the remaining line")
	TestSupport.assert_equal(text.split("\n").size() <= 2,true)
	panel.free()

func test_late_physical_summary() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(795)
	var facts: Array = []
	for id in ["toe_loop","salchow","loop"]:
		facts.append({"kind":"state_change","target":id+".single.proficiency","delta":1.0,"evidence_refs":["outcomes."+id]})
	facts.append({"kind":"state_change","target":"impact_load","delta":8.0,"evidence_refs":["outcomes.impact_load"]})
	facts.append({"kind":"state_change","target":"acute_fatigue","delta":-4.0,"evidence_refs":["outcomes.acute_fatigue"]})
	panel.present_training_period(career,{"career":career,"before":career,"facts":facts,"stop_reason":"quarter_complete"})
	var visible_text: String = panel.get_node("%RelationshipSummary").text
	TestSupport.assert_equal(visible_text.contains("冲击负荷") and visible_text.contains("+8.00"),true)
	TestSupport.assert_equal(visible_text.contains("即时疲劳") and visible_text.contains("-4.00"),true)
	TestSupport.assert_equal(visible_text.split("\n").size() <= 2,true)
	TestSupport.assert_equal(panel.get_node("%DetailsText").text.contains("后内结环跳单周熟练度"),true)
	TestSupport.assert_equal(panel.get_node("%DetailsText").text.contains("冲击负荷变化+8.00"),true)
	panel.free()

func test_training_overview_compact() -> void:
	var panel = _instantiate_panel()
	var before := Fixtures.starting_career(793)
	var result := MeaningfulAdvanceService.advance(before, TrainingIntent.create("accept").intent)
	result.facts = [
		{"kind":"coach_plan", "text":"完整课程", "evidence_refs":["training.plan"]},
		{"kind":"jump_attempts", "jump_id":"toe_loop", "rotations":2, "attempts":12, "successes":4},
		{"kind":"jump_attempts", "jump_id":"salchow", "rotations":2, "attempts":12, "successes":5},
		{"kind":"jump_attempts", "jump_id":"loop", "rotations":2, "attempts":12, "successes":3},
	]
	result.before = before
	panel.present_training_period(result.career, result)
	TestSupport.assert_equal(panel.get_node("%SetbacksCosts").text.contains("各动作成功/尝试"), false)
	TestSupport.assert_equal(panel.get_node("%SetbacksCosts").text.split("\n").size() <= 3, true)
	TestSupport.assert_equal(panel.get_node("%DetailsText").text.contains("各动作成功/尝试"), true)
	panel.get_node("%DetailsButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%DetailsContainer").visible, true)
	panel.free()

func test_training_period_factual_cards() -> void:
	var panel = _instantiate_panel()
	var before := Fixtures.starting_career(793)
	var intent = TrainingIntent.create("accept").intent
	var result := MeaningfulAdvanceService.advance(before, intent)
	result.before = before
	panel.present_training_period(result.career, result)
	TestSupport.assert_equal(panel.get_node("%StoryCards/ProgressCard/Box/BreakthroughHeading").text,"原定计划")
	TestSupport.assert_equal(panel.get_node("%StoryCards/CostCard/Box/SetbacksCostsHeading").text,"实际发生")
	TestSupport.assert_equal(panel.get_node("%StoryCards/RelationshipCard/Box/RelationshipHeading").text,"状态变化")
	TestSupport.assert_equal(panel.get_node("%StoryCards/SuggestionCard/Box/CoachAdviceHeading").text,"接下来")
	TestSupport.assert_equal(panel.get_node("%DetailsButton").text, "查看训练证据")
	TestSupport.assert_equal(panel.get_node("%NextButton").text,"带着结果回到主页")
	panel.present(result.career, [])
	TestSupport.assert_equal(panel.get_node("%StoryCards/ProgressCard/Box/BreakthroughHeading").text, "进步与突破")
	panel.free()

func test_post_competition_factual_return() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(794)
	var returned := [false]
	panel.home_requested.connect(func(): returned[0] = true)
	panel.present_post_competition(career,{"event_id":"teaching","event_name":"俱乐部教学赛","player_result":{"rank":5,"total_score":48.25}})
	TestSupport.assert_equal(panel.get_node("%Breakthroughs").text.contains("48.25"),true)
	TestSupport.assert_equal(panel.get_node("%Breakthroughs").text.contains("冠军"),false)
	TestSupport.assert_equal(panel.get_node("%DetailsText").text.contains("competition:teaching"),true)
	panel.get_node("%NextButton").pressed.emit()
	TestSupport.assert_equal(returned[0],true)
	panel.free()

func test_milestone_advance_controls() -> void:
	var panel = _instantiate_panel()
	var requested := [false]
	panel.milestone_advance_requested.connect(func(): requested[0] = true)
	var button: Button = panel.get_node_or_null("%AdvanceMilestoneButton")
	TestSupport.assert_equal(button != null, true)
	if button != null: button.pressed.emit()
	TestSupport.assert_equal(requested[0], true)
	panel.present_milestone(Fixtures.starting_career(791), {"quarters":[{"clock":{"year":2014,"quarter":1},"outcomes":[],"history":[]}], "stop_reason":"max_quarters"})
	TestSupport.assert_equal(panel.get_node("%ActionMessage").text.contains("1个季度"), true)
	panel.free()

func test_milestone_appears_in_breakthroughs() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(63)
	career.history.append({"category": "jump_milestone", "signature": "first_jump_success:toe_loop:2", "jump_id": "toe_loop", "rotations": 2})
	career.history.append({"category": "quarter_plan"})
	panel.present(career, [])
	TestSupport.assert_equal(panel.get_node("%Breakthroughs").text.contains("首次完成后外点冰跳·双周"), true)
	panel.free()

func test_meaningful_sections_precede_collapsed_details() -> void:
	var panel = _instantiate_panel()
	panel.present(Fixtures.starting_career(62), [])
	var primary = panel.get_node("%PrimarySections")
	TestSupport.assert_equal(primary.get_node("StoryCards").get_index() < primary.get_node("DetailsButton").get_index(), true)
	TestSupport.assert_equal(panel.get_node("%DetailsContainer").visible, false)
	panel.get_node("%DetailsButton").emit_signal("pressed")
	TestSupport.assert_equal(panel.get_node("%DetailsContainer").visible, true)
	panel.free()

func test_beginner_summary_uses_four_story_cards() -> void:
	var panel = _instantiate_panel()
	panel.present(Fixtures.starting_career(621), [])
	var cards: GridContainer = panel.get_node("%StoryCards")
	TestSupport.assert_equal(cards.columns, 2)
	TestSupport.assert_equal(cards.get_child_count(), 4)
	TestSupport.assert_equal(panel.get_node("%DetailsContainer").visible, false)
	panel.free()

func test_relationship_card_explains_adult_decisions() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	var outcomes := CareerSimulator.advance_quarter(career, Fixtures.jump_heavy_plan(), CatalogRepository.load_catalog())
	panel.present(career, outcomes)
	TestSupport.assert_equal(panel.get_node("%RelationshipSummary").text.contains("监护人"), true)
	panel.free()

func test_summary_presents_aggregate_jump_attempts() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(61)
	career.history.append({"category":"jump_attempt_batch", "jump_id":"lutz", "rotations":2, "attempts":16, "successes":3, "falls":4, "pops":2, "two_foot":1, "hand_down":0, "underrotated":3, "downgraded":3})
	career.history.append({"category":"quarter_plan"})
	panel.present(career, [])
	var text: String = panel.get_node("%TechniqueChanges").text
	TestSupport.assert_equal(text.contains("勾手跳·双周：尝试16次，成功3次，摔倒4次"), true)
	panel.free()

func test_summary_panel_localizes_nonzero_deltas_and_causes() -> void:
	var panel = _instantiate_panel()
	if panel == null:
		return
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	var outcomes := CareerSimulator.advance_quarter(
		career,
		Fixtures.jump_heavy_plan(),
		CatalogRepository.load_catalog(),
	)
	panel.present(career, outcomes)
	var technique_text: String = panel.get_node("%TechniqueChanges").text
	var body_text: String = panel.get_node("%BodyChanges").text
	var people_text: String = panel.get_node("%PeopleDecisions").text
	TestSupport.assert_equal(technique_text.contains("后外点冰跳·单周熟练度 +"), true)
	TestSupport.assert_equal(technique_text.contains("原因：后外点冰跳训练"), true)
	TestSupport.assert_equal(body_text.contains("即时疲劳 +"), true)
	TestSupport.assert_equal(body_text.contains("原因：训练负荷"), true)
	TestSupport.assert_equal(people_text.contains("监护人优先保护健康"), true)
	panel.free()

func test_summary_panel_groups_conditioning_recovery_with_body() -> void:
	var panel = _instantiate_panel()
	if panel == null:
		return
	var career := Fixtures.starting_career(52)
	var outcomes := CareerSimulator.advance_quarter(
		career,
		Fixtures.balanced_plan(),
		CatalogRepository.load_catalog(),
	)
	panel.present(career, outcomes)
	var technique_text: String = panel.get_node("%TechniqueChanges").text
	var body_text: String = panel.get_node("%BodyChanges").text
	TestSupport.assert_equal(technique_text.contains("恢复能力"), false)
	TestSupport.assert_equal(body_text.contains("恢复能力 +"), true)
	TestSupport.assert_equal(body_text.contains("原因：体能与力量训练"), true)
	panel.free()

func test_summary_panel_groups_year_end_growth_observation() -> void:
	var panel = _instantiate_panel()
	if panel == null:
		return
	var career := Fixtures.starting_career(53)
	career.clock.quarter = 4
	var outcomes := CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	panel.present(career, outcomes)
	var growth_text: String = panel.get_node("%GrowthObservations").text
	TestSupport.assert_equal(growth_text.contains("身体成长趋势 +"), true)
	TestSupport.assert_equal(growth_text.contains("原因：年末身体成长观察"), true)
	panel.free()

func test_summary_localizes_dynamic_codes() -> void:
	var panel = _instantiate_panel()
	var career := Fixtures.starting_career(8)
	var OutcomeRecord = preload("res://src/domain/outcome_record.gd")
	panel.present(career, [OutcomeRecord.new("jump_training", "lutz.single.proficiency", 0.2, ["lutz_practice", "2_rotation_attempt", "event:2014:1:jump_load_conflict"], "jump_proficiency_change")])
	var text: String = panel.get_node("%TechniqueChanges").text
	TestSupport.assert_equal(text.contains("勾手跳·单周熟练度"), true)
	TestSupport.assert_equal(text.contains("双周跳尝试"), true)
	TestSupport.assert_equal(text.contains("季度事件"), true)
	TestSupport.assert_equal(text.contains("lutz.single.proficiency"), false)
	panel.free()

func test_summary_uses_two_readable_columns() -> void:
	var panel = _instantiate_panel()
	TestSupport.assert_equal(panel.get_node("%SummaryColumns").columns, 2)
	TestSupport.assert_equal(panel.get_node("%TechniqueChanges").get_theme_font_size("font_size") >= 17, true)
	panel.free()

func _instantiate_panel():
	TestSupport.assert_equal(ResourceLoader.exists(PANEL_SCENE), true)
	if not ResourceLoader.exists(PANEL_SCENE):
		return null
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	return panel
