extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CreationPanel = preload("res://src/app/creation_panel.gd")

const CREATION_PANEL_SCENE := "res://src/app/creation_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"opening discloses Beijing-cycle scope and later births retain junior routes without Olympic age promises", "callable": test_supported_opening_scope},
		{"name": "creation panel emits each valid career once", "callable": test_creation_panel_previews_before_emitting_once},
		{"name": "creation panel exposes and forwards skating start age", "callable": test_skating_start_age_input},
		{"name": "failed creation cannot emit a stale career", "callable": test_failed_replacement_clears_candidate},
		{"name": "creation panel disables creation for invalid catalog", "callable": test_creation_panel_disables_invalid_catalog},
		{"name": "hidden seed creates varied worlds while advanced seed stays exact", "callable": test_seed_choice},
		{"name": "club selection filters coaches and both choices are required", "callable": test_club_selection_filters_coaches_and_requires_both},
		{"name": "club and coach descriptions show qualitative public evidence", "callable": test_club_and_coach_descriptions_show_public_evidence},
	]

func test_supported_opening_scope() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	TestSupport.assert_equal(2019 - int(panel.birth_year_input.value) >= 13,true,"default career must reach junior age within the published calendar")
	TestSupport.assert_equal(panel.get_node("Subtitle").text.contains("2021—22"),true,"opening must not advertise the obsolete 2019 scope")
	panel.birth_year_input.value = 2007
	TestSupport.assert_equal(panel.get_node("Subtitle").text.contains("2007"),true)
	TestSupport.assert_equal(panel.get_node("Subtitle").text.contains("尚未开放"),false,"the published 2020 junior season is now available")
	panel.birth_year_input.value = 2008
	TestSupport.assert_equal(panel.get_node("Subtitle").text.contains("2008"),true)
	TestSupport.assert_equal(panel.get_node("Subtitle").text.contains("尚未开放"),false,"the published 2021 junior season is now available")
	panel.birth_year_input.value = 2006
	TestSupport.assert_equal(panel.get_node("Subtitle").text.contains("争取"),true,"age eligibility must not promise an international assignment")
	TestSupport.assert_equal(panel.birth_year_input.min_value,2006.0)
	TestSupport.assert_equal(panel.birth_year_input.max_value,2008.0)
	panel.free()

func test_club_and_coach_descriptions_show_public_evidence() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	TestSupport.assert_equal(panel.club_description.text.contains("医疗：可靠"), true)
	TestSupport.assert_equal(panel.club_description.text.contains("内部竞争：很高"), true)
	TestSupport.assert_equal(panel.coach_description.text.contains("心理支持：突出"), true)
	TestSupport.assert_equal(panel.coach_description.text.contains("勾手跳教学方式在业内存在不同评价"), true)
	TestSupport.assert_equal(panel.coach_description.text.contains("lutz_edge_guidance"), false)
	TestSupport.assert_equal(panel.coach_description.text.contains("-0.18"), false)
	panel.free()

func test_club_selection_filters_coaches_and_requires_both() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	TestSupport.assert_equal(panel.club_input.item_count >= 3, true)
	panel.club_input.select(2)
	panel._on_club_selected(2)
	TestSupport.assert_equal(panel.coach_input.item_count >= 2, true)
	var selected_club_id := str(panel.club_input.get_selected_metadata())
	for index in panel.coach_input.item_count:
		var coach_id := str(panel.coach_input.get_item_metadata(index))
		TestSupport.assert_equal(panel.club_coach_repository.coach_profile(coach_id).club_id, selected_club_id)
	var missing := panel.create_career("林澄", 2007, "entry_interest_class", "family_supportive", 1, 4, "", "")
	TestSupport.assert_equal(missing.errors.has("请选择俱乐部"), true)
	TestSupport.assert_equal(missing.errors.has("请选择教练"), true)
	var created := panel.create_career(
		"林澄", 2007, "entry_interest_class", "family_supportive", 1, 4,
		selected_club_id, str(panel.coach_input.get_selected_metadata()),
	)
	TestSupport.assert_equal(created.errors, [])
	TestSupport.assert_equal(created.career.coach_assignment.club_id, selected_club_id)
	panel.free()

func test_seed_choice() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.advanced_seed_toggle.button_pressed = false
	var first: int = panel._seed_for_creation()
	var second: int = panel._seed_for_creation()
	TestSupport.assert_equal(first != second, true)
	panel.seed_input.value = 123456
	panel.advanced_seed_toggle.button_pressed = true
	TestSupport.assert_equal(panel._seed_for_creation(), 123456)
	TestSupport.assert_equal(panel._seed_for_creation(), 123456)
	panel.advanced_seed_toggle.button_pressed = false
	TestSupport.assert_equal(panel._seed_for_creation() != 123456, true)
	panel.free()

func test_creation_panel_previews_before_emitting_once() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var emitted: Array = []
	panel.career_created.connect(func(career): emitted.append(career))
	panel.create_career("", 2007, "entry_interest_class", "family_supportive", 1, 4)
	TestSupport.assert_equal(emitted.size(), 0)
	panel.create_career("林澄", 2007, "entry_interest_class", "family_supportive", 1, 4)
	TestSupport.assert_equal(emitted.size(), 1)
	panel.free()

func test_skating_start_age_input() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var input: SpinBox = panel.get_node("%SkatingStartAgeInput")
	TestSupport.assert_equal([input.min_value, input.max_value, input.value], [3.0, 6.0, 4.0])
	input.value = 5.0
	panel.birth_year_input.value = 2008.0
	TestSupport.assert_equal(input.value, 5.0)
	var result := panel.create_career("林澄", 2008, "entry_interest_class", "family_supportive", 1, int(input.value))
	TestSupport.assert_equal(result.career.pre_career_history.skating_start_age, 5)
	panel.free()

func test_failed_replacement_clears_candidate() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var emitted: Array = []
	panel.career_created.connect(func(career): emitted.append(career))
	panel.create_career("第一位", 2007, "entry_interest_class", "family_supportive", 1, 4)
	panel.create_career("", 2007, "entry_interest_class", "family_supportive", 1, 4)
	TestSupport.assert_equal(emitted.size(), 1)
	TestSupport.assert_equal(emitted[0].athlete.display_name, "第一位")
	panel.free()

func test_creation_panel_disables_invalid_catalog() -> void:
	var panel: CreationPanel = load(CREATION_PANEL_SCENE).instantiate()
	panel.catalog = {"backgrounds": {}, "training": {}, "errors": ["catalog unavailable"]}
	Engine.get_main_loop().root.add_child(panel)
	TestSupport.assert_equal(panel.create_button.disabled, true)
	TestSupport.assert_equal(panel.error_label.text, "catalog unavailable")
	var result := panel.create_career("林澄", 2007, "entry_interest_class", "family_supportive", 1, 4)
	TestSupport.assert_equal(result.errors, ["catalog unavailable"])
	panel.free()
