extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"post competition score explanation is optional and does not change career","callable":test_explanation}]

func test_explanation() -> void:
	var panel = load("res://src/app/summary_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = F.starting_career(951)
	var player_short := {
		"score":{"tes":30.0,"pcs":20.0,"deductions":1.0,"domestic_bonus":2.0,"total":51.0},
		"snapshot":{"program":{"program_id":"winter","revision":2,"music":{"title":"冬日"}}},
	}
	var previous := player_short.duplicate(true)
	previous.score.total = 54.0
	career.competition_archive.append({"event_id":"previous","event_name":"上场比赛","status":"complete","short_results":{"player":previous}})
	var other_revision := previous.duplicate(true)
	other_revision.snapshot.program.revision = 1
	other_revision.score.total = 60.0
	career.competition_archive.append({"event_id":"old-version","status":"complete","short_results":{"player":other_revision}})
	var before: Dictionary = career.to_dict()
	panel.present_post_competition(career,{"event_id":"explain-ui","short_results":{"player":player_short}})
	T.assert_equal(panel.details_container.visible,false)
	T.assert_equal(panel.details_text.text.contains("51.00"),true)
	T.assert_equal(panel.details_text.text.contains("短节目 · 《冬日》第2版 · 51.00分"),true)
	T.assert_equal(panel.details_text.text.contains("同版更高分 · 上场比赛 · 54.00分"),true)
	T.assert_equal(panel.details_text.text.contains("自由滑 ·"),false)
	panel.details_button.pressed.emit()
	T.assert_equal(panel.details_container.visible,true)
	panel.details_button.pressed.emit()
	T.assert_equal(panel.details_container.visible,false)
	T.assert_equal(career.to_dict(),before)
	panel.free()
