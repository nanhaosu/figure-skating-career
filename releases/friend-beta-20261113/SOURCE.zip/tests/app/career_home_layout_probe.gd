extends SceneTree

func _initialize() -> void:
	call_deferred("probe")

func probe() -> void:
	var failed := false
	for dimensions in [Vector2i(1280,720),Vector2i(960,540)]:
		var viewport := SubViewport.new()
		viewport.size = dimensions
		root.add_child(viewport)
		var panel = load("res://src/app/career_home_panel.tscn").instantiate()
		viewport.add_child(panel)
		var career = load("res://tests/fixtures.gd").starting_career(1000+dimensions.x)
		career.athlete.display_name = "欧阳娜塔莉娅·一位名字很长的年轻运动员"
		for index in 8:
			career.history.append({"category":"warning","record_id":"warning-%d" % index,"summary":"这是一条较长但必须保持可读的事实记录 %d" % index})
		panel.present(career)
		for i in 6: await process_frame
		var action: Rect2 = panel.get_node("%PrimaryAction").get_global_rect()
		var nav: Rect2 = panel.get_node("%RecordsNavButton").get_global_rect()
		var body: Rect2 = panel.get_node("Content/Body").get_global_rect()
		var current: Rect2 = panel.get_node("%CurrentEventTitle").get_global_rect()
		var scrolls: Array[Node] = panel.find_children("*","ScrollContainer",true,false)
		if action.end.x > dimensions.x or action.end.y > dimensions.y or action.size.y < 44.0:
			push_error("primary action outside %s: %s" % [dimensions,action]); failed = true
		if nav.intersects(action) or body.size.y < 180.0 or current.end.x > dimensions.x:
			push_error("home overlap at %s nav=%s action=%s body=%s" % [dimensions,nav,action,body]); failed = true
		if not scrolls.is_empty():
			push_error("career home must not require main-page scrolling at %s" % dimensions); failed = true
		print("HOME BOUNDS %s body=%s action=%s" % [dimensions,body,action])
		viewport.free()
	quit(1 if failed else 0)
