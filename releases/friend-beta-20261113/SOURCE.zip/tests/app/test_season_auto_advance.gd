extends RefCounted
const T = preload("res://tests/test_support.gd")
const A = preload("res://src/app/season_auto_advance.gd")
const F = preload("res://tests/fixtures.gd")

class StubMain extends Node:
	var active_career
	var autosave_path: String = "user://unused-auto-test.json"

func cases() -> Array[Dictionary]:
	return [{"name":"auto progression stage dispatch never replays locked segments", "callable":stages},{"name":"auto progression preserves manual or target sessions and RNG on retry", "callable":session_guard},{"name":"cancelled auto progression performs no save or simulation", "callable":cancelled},{"name":"auto progression requires a selected target before any mutation", "callable":no_target}]

func no_target() -> void:
	var main = StubMain.new()
	main.active_career = F.starting_career(995)
	var before: Dictionary = main.active_career.to_dict().duplicate(true)
	var result: Dictionary = await A.run(main,func():return true,Callable())
	T.assert_equal(result.reason,"no_target")
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()

func stages() -> void:
	T.assert_equal(A._session_action({"kind":"formal","status":"practice_ready","practice":{"meaningful":true}}),"meaningful_practice")
	T.assert_equal(A._session_action({"kind":"formal","status":"practice_ready"}),"practice")
	T.assert_equal(A._session_action({"kind":"formal","status":"free_adjustment"}),"free")
	T.assert_equal(A._session_action({"kind":"formal","status":"complete"}),"archive")
	T.assert_equal(A._session_action({"kind":"formal","status":"short_ready"}),"unsupported_session")

func session_guard() -> void:
	var main = StubMain.new()
	main.active_career = F.starting_career(992)
	main.active_career.competition_state = {"kind":"formal","event_id":"test","status":"practice_ready","seed":12993}
	var original: Dictionary = main.active_career.to_dict().duplicate(true)
	for retry in 2:
		var result: Dictionary = await A.run(main,func():return true,Callable())
		T.assert_equal(result.reason,"existing_manual_competition")
		T.assert_equal(main.active_career.to_dict(),original)
		T.assert_equal(result.initial_record_count,result.final_record_count)
	main.active_career.season_state.target_event_id = "test"
	var target_result: Dictionary = await A.run(main,func():return true,Callable())
	T.assert_equal(target_result.reason,"target_event")
	main.free()

func cancelled() -> void:
	var main = StubMain.new()
	main.active_career = F.starting_career(993)
	var before: Dictionary = main.active_career.to_dict().duplicate(true)
	var result: Dictionary = await A.run(main,func():return false,Callable())
	T.assert_equal(result.reason,"cancelled")
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()

