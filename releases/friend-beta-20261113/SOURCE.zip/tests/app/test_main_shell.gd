extends RefCounted

const T = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"startup waits at the main menu without loading a career","callable":startup_waits_at_menu},
		{"name":"career home presents identity goal and one primary action","callable":home_content},
		{"name":"new career enters the career home before detailed training","callable":main_enters_home},
		{"name":"loaded quiet career resumes at the career home","callable":loaded_career_enters_home},
		{"name":"career home season navigation remains available beside the primary action","callable":season_navigation},
		{"name":"career home keeps primary action visible at minimum viewport","callable":minimum_viewport},
		{"name":"career home owns an unclipped save entry at minimum viewport","callable":home_save_entry},
	]

func startup_waits_at_menu() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	T.assert_equal(main.get_node("%MainMenuPanel").visible, true)
	T.assert_equal(main.get_node("%CreationScreen").visible, false)
	T.assert_equal(main.active_career, null)
	main.get_node("%MainMenuPanel").get_node("%NewCareerButton").pressed.emit()
	T.assert_equal(main.get_node("%CreationScreen").visible, false)
	var skip = main.get_node("CareerDecisionDialog").find_child("SkipSkatingIntro",true,false)
	T.assert_equal(skip != null,true)
	if skip != null: skip.pressed.emit()
	T.assert_equal(main.get_node("%CreationScreen").visible, true)
	await Engine.get_main_loop().process_frame
	var save_button: Button = main.get_node("%SaveManagerButton")
	T.assert_equal(save_button.get_global_rect().end.y <= main.get_global_rect().end.y,true,"creation save button must not be clipped by the viewport after themed minimum height")
	main.free()

func home_content() -> void:
	var panel = load("res://src/app/career_home_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(Fixtures.starting_career(93010))
	T.assert_equal(panel.get_node("%AthleteName").text,"林澄")
	T.assert_equal(panel.get_node("%GoalText").text.is_empty(),false)
	T.assert_equal(panel.get_node("%PrimaryAction").text,"与教练安排训练")
	T.assert_equal(panel.get_node("%PrimaryAction").visible,true)
	panel.free()

func main_enters_home() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://test-main-shell-home-%d.json" % Time.get_ticks_usec()
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(Fixtures.starting_career(93011))
	T.assert_equal(main.get_node("%CareerHomePanel").visible,true)
	T.assert_equal(main.get_node("%QuarterPanel").visible,false)
	main.get_node("%CareerHomePanel").get_node("%PrimaryAction").pressed.emit()
	T.assert_equal(main.get_node("%QuarterPanel").visible,true)
	main.free()

func minimum_viewport() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960,540)
	Engine.get_main_loop().root.add_child(viewport)
	var panel = load("res://src/app/career_home_panel.tscn").instantiate()
	viewport.add_child(panel)
	panel.present(Fixtures.starting_career(93012))
	var action: Button = panel.get_node("%PrimaryAction")
	T.assert_equal(action.get_global_rect().end.y <= 540.0,true)
	T.assert_equal(action.get_global_rect().size.y >= 44.0,true)
	viewport.free()

func home_save_entry() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960,540)
	Engine.get_main_loop().root.add_child(viewport)
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://test-main-shell-layout-%d.json" % Time.get_ticks_usec()
	viewport.add_child(main)
	main.offer_new_career(Fixtures.starting_career(93015))
	await Engine.get_main_loop().process_frame
	var save_entry: Button = main.get_node("%CareerShellPanel").get_node("%SaveManagerButton")
	T.assert_equal(save_entry.visible,true)
	T.assert_equal(save_entry.get_global_rect().end.y <= 540.0,true)
	T.assert_equal(main.get_node("%SaveManagerButton").visible,false,"the global corner button must not overlap the home footer")
	T.assert_equal(main.get_node("%CareerHomePanel").get_node("%Navigation").visible,false,"home must not duplicate global navigation")
	save_entry.pressed.emit()
	T.assert_equal(main.get_node("%SaveManagerPanel").visible,true)
	main.get_node("%SaveManagerPanel").hide()
	viewport.free()

func loaded_career_enters_home() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = Fixtures.starting_career(93013)
	main._open_loaded_career()
	T.assert_equal(main.get_node("%CareerHomePanel").visible,true)
	T.assert_equal(main.get_node("%QuarterPanel").visible,false)
	main.free()

func season_navigation() -> void:
	var career = Fixtures.formal_junior_career(93014)
	career.competition_state = {"kind":"formal","status":"short_ready","event_id":"cn_u_series"}
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = career
	main._open_player_home()
	main.get_node("%CareerHomePanel").get_node("%SeasonNavButton").pressed.emit()
	T.assert_equal(main.get_node("%SeasonOverviewPanel").visible,true)
	main.free()
