extends RefCounted

const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "main menu presents explicit career entry choices", "callable": test_entry_choices},
		{"name": "main menu continues the most recent readable slot", "callable": test_continue_slot},
		{"name": "broken metadata never disables new career", "callable": test_broken_slot},
	]

func test_entry_choices() -> void:
	T.assert_equal(ResourceLoader.exists("res://src/app/main_menu_panel.tscn"), true)
	if not ResourceLoader.exists("res://src/app/main_menu_panel.tscn"): return
	var panel = load("res://src/app/main_menu_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present([])
	T.assert_equal(panel.get_node("%ContinueButton").disabled, true)
	T.assert_equal(panel.get_node("%NewCareerButton").disabled, false)
	T.assert_equal(panel.get_node("%LoadButton").disabled, false)
	T.assert_equal(panel.get_node("%SettingsButton").disabled, false)
	panel.free()

func test_continue_slot() -> void:
	if not ResourceLoader.exists("res://src/app/main_menu_panel.tscn"): return
	var panel = load("res://src/app/main_menu_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var requested := []
	panel.continue_requested.connect(func(slot_id: String): requested.append(slot_id))
	panel.present([
		{"id": "manual-1", "status": "saved", "athlete": "旧存档", "clock": {"year": 2018, "quarter": 2}, "saved_at_unix": 10},
		{"id": "autosave", "status": "saved", "athlete": "林澄", "clock": {"year": 2019, "quarter": 3}, "saved_at_unix": 20},
	])
	T.assert_equal(panel.get_node("%CareerSummary").text.contains("林澄"), true)
	T.assert_equal(panel.get_node("%CareerSummary").text.contains("第3季度"), true)
	panel.get_node("%ContinueButton").pressed.emit()
	T.assert_equal(requested, ["autosave"])
	panel.free()

func test_broken_slot() -> void:
	if not ResourceLoader.exists("res://src/app/main_menu_panel.tscn"): return
	var panel = load("res://src/app/main_menu_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present([{"id": "autosave", "status": "unreadable", "athlete": ""}])
	T.assert_equal(panel.get_node("%ContinueButton").disabled, true)
	T.assert_equal(panel.get_node("%NewCareerButton").disabled, false)
	T.assert_equal(panel.get_node("%StatusText").text.contains("无法读取"), true)
	panel.free()
