extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const ICE_VIEW_SCENE := "res://src/app/competition_ice_view.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name": "ice view follows route playback progress", "callable": test_route_progress},
		{"name": "ice view groups combination anchors", "callable": test_combination_anchors},
		{"name": "ice view colors action nodes from technical status", "callable": test_action_status_colors},
		{"name": "ice view exposes current action phase", "callable": test_current_action_phase},
	]

func test_current_action_phase() -> void:
	var view = _view()
	view.load_timeline({"points": _route().points, "action_anchors": _route().action_anchors, "action_phases":[{"kind":"airborne", "element_id":"combo", "start":0.44, "end":0.50}]}, _elements())
	view.set_progress(0.47)
	TestSupport.assert_equal(view.current_action_state.kind, "airborne")
	view.set_progress(0.7)
	TestSupport.assert_equal(view.current_action_state.is_empty(), true)
	view.free()

func test_route_progress() -> void:
	var view = _view()
	if view == null: return
	view.load_timeline(_route(), _elements())
	view.set_progress(0.55)
	TestSupport.assert_equal(view.visible_route_point_count, 2)
	TestSupport.assert_equal(view.visible_action_count, 1)
	TestSupport.assert_equal(view.skater_position.distance_to(Vector2(0.596, 0.5)) < 0.001, true)
	view.free()

func test_combination_anchors() -> void:
	var view = _view()
	if view == null: return
	view.load_timeline(_route(), _elements())
	view.set_progress(0.7)
	TestSupport.assert_equal(view.visible_action_count, 2)
	TestSupport.assert_equal(view.combination_links.size(), 1)
	view.free()

func test_action_status_colors() -> void:
	var view = _view()
	if view == null: return
	view.load_timeline(_route(), _elements())
	view.set_progress(1.0)
	TestSupport.assert_equal(view.action_node_colors["combo"], view.REVIEW_COLOR)
	TestSupport.assert_equal(view.action_node_colors["spin"], view.ERROR_COLOR)
	view.free()

func _view():
	TestSupport.assert_equal(ResourceLoader.exists(ICE_VIEW_SCENE), true)
	if not ResourceLoader.exists(ICE_VIEW_SCENE): return null
	var view = load(ICE_VIEW_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(view)
	return view

func _route() -> Dictionary:
	return {
		"points": [
			{"x": 0.1, "y": 0.2, "progress": 0.0},
			{"x": 0.55, "y": 0.45, "progress": 0.5},
			{"x": 0.78, "y": 0.7, "progress": 0.75},
			{"x": 0.9, "y": 0.8, "progress": 1.0},
		],
		"action_anchors": [
			{"element_id": "combo", "part_index": 0, "progress": 0.45, "point_index": 1},
			{"element_id": "combo", "part_index": 1, "progress": 0.6, "point_index": 2},
			{"element_id": "spin", "part_index": 0, "progress": 0.8, "point_index": 3},
		],
	}

func _elements() -> Array:
	return [
		{"element_id": "combo", "status": "review"},
		{"element_id": "spin", "status": "error"},
	]
