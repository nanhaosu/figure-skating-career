extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"annual rule adjustment preserves unchanged trained slots and charges changed spin","callable":preserve},{"name":"whole coach redraft remains an explicit available choice","callable":redraft},{"name":"annual adjustment upgrades only required single-jump menu differences","callable":required_jumps},{"name":"annual adjustment moves old Axel combination to an independent prescribed Axel","callable":axel_menu},{"name":"missing prescribed double becomes a visible qualification gap rather than ending the career","callable":qualification_gap}]
func setup(single_jumps: bool = false, axel_combination: bool = false) -> Dictionary:
	var c = F.formal_junior_career(77)
	var p = load("res://tests/simulation/test_2019_junior_program_rules.gd").new()._program()
	p.elements[2].jump_id = "flip"
	p.elements[4].spin_code = "FCSp"
	if single_jumps:
		for e in p.elements:
			if e.kind == "jump":
				e.rotations = 1
				for part in e.combination_parts: part.rotations = 1
	if axel_combination:
		p.elements[0].set_combination_parts([{"jump_id":"toe_loop","rotations":2}])
		p.elements[1].set_combination_parts([])
	p.whole_run_familiarity = 80.0
	for id in p.slot_familiarity: p.slot_familiarity[id] = 80.0
	c.active_programs.short = p.to_dict()
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://annual-adjust-autosave.json"; main.save_path = "user://annual-adjust.json"
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(c); main.confirm_new_career_replacement()
	return {"main":main,"original":p}
func preserve() -> void:
	var state := setup()
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = state.main
	driver._handle_node({"kind":"program_adjustment","segment":"short","rules":Rules.for_season(2019,"junior","short")},{})
	T.assert_equal(driver.errors,[])
	var saved: Dictionary = state.main.active_career.active_programs.short
	T.assert_equal(saved.slot_familiarity.get("axel",-1),80.0,"unchanged trained axel must retain slot identity and familiarity")
	T.assert_equal(saved.slot_familiarity.get("FSSp",-1),0.0,"changed spin must pay the normal revision cost")
	T.assert_equal(saved.whole_run_familiarity < 80.0 and saved.whole_run_familiarity > 70.0,true,"the two seasonal requirement changes should create a limited, not total, familiarity cost")
	T.assert_equal(saved.elements[0],state.original.elements[0].to_dict())
	state.main.free()
func required_jumps() -> void:
	var state := setup()
	T.assert_equal(load("res://src/simulation/program_validator.gd").validate(state.original,state.main.active_career.athlete,Rules.for_season(2018,"junior","short")),[])
	var driver = load("res://scripts/international_season_journey.gd").new(); driver.main = state.main
	driver._handle_node({"kind":"program_adjustment","segment":"short","rules":Rules.for_season(2019,"junior","short")},{})
	T.assert_equal(driver.errors,[])
	var saved: Dictionary = state.main.active_career.active_programs.short
	T.assert_equal(saved.elements[2].jump_id,"loop")
	T.assert_equal(saved.elements[1].rotations,2)
	T.assert_equal(saved.elements[1].combination_parts[0].rotations,2)
	T.assert_equal(saved.slot_familiarity.get("LSp",-1),80.0)
	state.main.free()
func axel_menu() -> void:
	var state := setup(false,true)
	var driver = load("res://scripts/international_season_journey.gd").new(); driver.main = state.main
	driver._handle_node({"kind":"program_adjustment","segment":"short","rules":Rules.for_season(2019,"junior","short")},{})
	T.assert_equal(driver.errors,[])
	var saved: Dictionary = state.main.active_career.active_programs.short
	T.assert_equal(saved.elements[0].combination_parts,[])
	T.assert_equal(saved.elements[0].rotations,2)
	T.assert_equal(saved.elements[1].combination_parts,[{"jump_id":"toe_loop","rotations":2}])
	T.assert_equal(saved.slot_familiarity.get("LSp",-1),80.0)
	state.main.free()
func redraft() -> void:
	var state := setup()
	var editor = state.main.get_node("%ProgramEditorPanel")
	var rules := Rules.for_season(2019,"junior","short")
	editor.present(state.main.active_career,"short",rules,{})
	T.assert_equal(editor.program.program_id,"legal-2019")
	editor.get_node("%RefreshDraftButton").pressed.emit()
	T.assert_equal(editor.program.program_id != "legal-2019",true)
	state.main.free()

func qualification_gap() -> void:
	var state := setup(true)
	state.main.active_career.athlete.jumps.toe_loop.unlocked_rotations = 1
	var before: Dictionary = state.main.active_career.active_programs.short.duplicate(true)
	var driver = load("res://scripts/international_season_journey.gd").new(); driver.main = state.main
	driver._handle_node({"kind":"program_adjustment","segment":"short","rules":Rules.for_season(2019,"junior","short")},{})
	T.assert_equal(driver.errors,[],"a rule-change gap must keep the season playable")
	T.assert_equal(state.main.active_career.active_programs.short,before,"an impossible edit must not destroy the last trained programme")
	T.assert_equal(driver.trace.has("program:qualification_gap:2019:short"),true,"the coach route must explain why formal entry is not ready")
	state.main.free()
