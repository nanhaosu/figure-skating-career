extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"health and repertoire inspection can return without advancing or changing programme","callable":test_read_only},{"name":"major treatment node presents route choices instead of dead end summary","callable":test_treatment},{"name":"unready formal programme offers edit withdraw and safe return","callable":test_unready},{"name":"persistence owns exclusive input while a decision remains recoverable","callable":test_persistence_modal}]

func test_persistence_modal() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(2903)
	var before: Dictionary = main.active_career.to_dict()
	main._new_decision_dialog("保存前的决策")
	var dialog = main.get_node("CareerDecisionDialog")
	main._set_persistence_pending(true)
	T.assert_equal(dialog.exclusive,false,"a waiting save must not compete with an exclusive sibling")
	T.assert_equal(dialog.visible,true,"failed save must retain its decision and retry choices")
	T.assert_equal(main.get_node("PersistenceWait").exclusive,true)
	main._set_persistence_pending(false)
	T.assert_equal(dialog.exclusive,true,"restore the original decision after storage acknowledgement")
	T.assert_equal(main.get_node("PersistenceWait").visible,false)
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()
func test_unready() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(2902)
	var before: Dictionary = main.active_career.to_dict()
	main._present_season_node({"kind":"program_adjustment","reason":"短节目尚未准备好","event_id":"test-event","segment":"short","rules":{}})
	var dialog = main.get_node_or_null("CareerDecisionDialog")
	T.assert_equal(dialog != null,true)
	if dialog != null:
		for action in ["EditProgram","WithdrawEvent","InspectReturn"]:
			T.assert_equal(dialog.find_child(action,true,false) != null,true)
		var back = dialog.find_child("InspectReturn",true,false)
		if back != null: back.pressed.emit()
		T.assert_equal(dialog.visible,false)
		T.assert_equal(main.get_node("%CareerHomePanel").visible,true)
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()
func test_read_only() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(2900)
	main._open_player_home()
	var before: Dictionary = main.active_career.to_dict()
	for route in ["health","repertoire"]:
		main.open_route(route,{},main.screen_router.current())
		T.assert_equal(main.screen_router.current().screen_id,route)
		main.back_route()
		T.assert_equal(main.active_career.to_dict(),before)
		T.assert_equal(main.get_node("%CareerHomePanel").visible,true)
	main.free()
func test_treatment() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(2901)
	main.active_career.condition_state.injuries = [{"id":"test-major","site":"ankle","severity":0.85,"remaining_quarters":2,"status":"active"}]
	main.active_career.condition_state.pending_decision = {"kind":"rehabilitation_initial","injury_id":"test-major"}
	main._present_season_node(load("res://src/simulation/season_progression_service.gd")._pending(main.active_career))
	var dialog = main.get_node_or_null("CareerDecisionDialog")
	T.assert_equal(dialog != null,true)
	if dialog != null:
		T.assert_equal(dialog.visible,true)
		T.assert_equal(dialog.find_child("Route_conservative",true,false) != null,true)
		T.assert_equal(dialog.find_child("Route_full_rehabilitation",true,false) != null,true)
	main.free()
