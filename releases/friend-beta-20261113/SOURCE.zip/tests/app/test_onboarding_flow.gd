extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const ServicePath := "res://src/app/onboarding_service.gd"
const OverlayPath := "res://src/app/onboarding_overlay.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"first contextual lesson appears once and survives reload data", "callable":test_seen_once},
		{"name":"skip all suppresses every later contextual lesson", "callable":test_skip_all},
		{"name":"overlay explains the moment and exposes continue and skip", "callable":test_overlay_contract},
		{"name":"main presents intro then the first training lesson without repeating", "callable":test_main_checkpoints},
		{"name":"onboarding card fits the minimum browser viewport", "callable":test_minimum_viewport},
	]

func test_minimum_viewport() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960,540)
	Engine.get_main_loop().root.add_child(viewport)
	var overlay = load(OverlayPath).instantiate()
	viewport.add_child(overlay)
	overlay.present("competition")
	for i in 3: await Engine.get_main_loop().process_frame
	var card: Rect2 = overlay.get_node("Card").get_global_rect()
	T.assert_equal(card.position.x >= 0 and card.position.y >= 0, true, str(card))
	T.assert_equal(card.end.x <= 960 and card.end.y <= 540, true, str(card))
	T.assert_equal(overlay.get_node("%OnboardingContinue").visible, true)
	for stage in ["intro","training","program","registration","competition"]:
		overlay.present(stage)
		for i in 3: await Engine.get_main_loop().process_frame
		var body: Label = overlay.get_node("%OnboardingBody")
		T.assert_equal(body.get_line_count()>1,true,"Chinese body must wrap inside its card: " + stage)
	viewport.free()

func test_main_checkpoints() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	main.browser_saves = load("res://src/persistence/browser_save_service.gd").new("user://onboarding-%d" % Time.get_ticks_usec())
	main.autosave_path = main.browser_saves.slot_path("autosave")
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(F.starting_career(9203))
	var overlay = main.get_node("%OnboardingOverlay")
	T.assert_equal(overlay.visible, true)
	T.assert_equal(overlay.get_node("%OnboardingTitle").text.contains("不是从零"), true)
	var saved_results: Array = []
	main.onboarding_state_saved.connect(func(stage,ok): saved_results.append([stage,ok]))
	overlay.get_node("%OnboardingContinue").pressed.emit()
	while saved_results.is_empty(): await Engine.get_main_loop().process_frame
	T.assert_equal(saved_results,[["intro",true]])
	T.assert_equal(load(ServicePath).should_show(main.active_career,"intro"), false)
	main.open_next_quarter()
	T.assert_equal(overlay.visible, true)
	T.assert_equal(overlay.get_node("%OnboardingTitle").text.contains("方向"), true)
	main.free()

func _service():
	T.assert_equal(ResourceLoader.exists(ServicePath), true, "onboarding service missing")
	return load(ServicePath) if ResourceLoader.exists(ServicePath) else null

func test_seen_once() -> void:
	var service = _service()
	if service == null: return
	var career = F.starting_career(9201)
	T.assert_equal(service.should_show(career,"training"), true)
	service.mark_seen(career,"training",false)
	T.assert_equal(service.should_show(career,"training"), false)
	T.assert_equal(service.should_show(career,"program"), true)
	var restored = load("res://src/domain/career_state.gd").from_dict(career.to_dict())
	T.assert_equal(service.should_show(restored,"training"), false)

func test_skip_all() -> void:
	var service = _service()
	if service == null: return
	var career = F.starting_career(9202)
	service.mark_seen(career,"intro",true)
	for stage in ["intro","training","program","registration","competition"]:
		T.assert_equal(service.should_show(career,stage), false, stage)

func test_overlay_contract() -> void:
	T.assert_equal(ResourceLoader.exists(OverlayPath), true, "onboarding overlay missing")
	if not ResourceLoader.exists(OverlayPath): return
	var overlay = load(OverlayPath).instantiate()
	Engine.get_main_loop().root.add_child(overlay)
	var shown: bool = overlay.present("registration")
	T.assert_equal(shown, true)
	T.assert_equal(overlay.visible, true)
	T.assert_equal(overlay.get_node("%OnboardingTitle").text.is_empty(), false)
	T.assert_equal(overlay.get_node("%OnboardingBody").text.contains("报名"), true)
	T.assert_equal(overlay.get_node("%OnboardingContinue").text.is_empty(), false)
	T.assert_equal(overlay.get_node("%OnboardingSkipAll").text.contains("跳过"), true)
	var dismissed: Array = []
	overlay.dismissed.connect(func(stage,skip): dismissed.append([stage,skip]))
	overlay.get_node("%OnboardingContinue").pressed.emit()
	T.assert_equal(dismissed, [["registration",false]])
	T.assert_equal(overlay.visible, false)
	overlay.free()
