extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const QuarterEvent = preload("res://src/domain/quarter_event.gd")
const DIALOG_SCENE := "res://src/app/event_dialog.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name": "event dialog starts hidden and close request hides it", "callable": test_dialog_lifecycle},
		{"name": "event dialog shows choices and emits selected id", "callable": test_dialog_shows_choices_and_emits_selection},
	]

func test_dialog_lifecycle() -> void:
	var dialog = load(DIALOG_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(dialog)
	TestSupport.assert_equal(dialog.visible, false)
	dialog.show()
	dialog.close_requested.emit()
	TestSupport.assert_equal(dialog.visible, false)
	dialog.free()

func test_dialog_shows_choices_and_emits_selection() -> void:
	TestSupport.assert_equal(ResourceLoader.exists(DIALOG_SCENE), true)
	if not ResourceLoader.exists(DIALOG_SCENE): return
	var dialog = load(DIALOG_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(dialog)
	var event = QuarterEvent.new()
	event.id = "event:test"
	event.title = "训练后的不适"
	event.description = "落冰后，脚踝出现了和平时不同的感觉。"
	event.choices.assign([{"id": "report", "label": "告诉教练"}, {"id": "hide", "label": "暂时隐瞒"}])
	var selected: Array[String] = []
	dialog.event_choice.connect(func(_event_id, choice_id): selected.append(choice_id))
	dialog.present(event)
	TestSupport.assert_equal(dialog.get_node("%EventTitle").text, "训练后的不适")
	TestSupport.assert_equal(dialog.get_node("%ChoiceButtons").get_child_count(), 2)
	dialog.get_node("%ChoiceButtons").get_child(0).pressed.emit()
	TestSupport.assert_equal(selected, ["report"])
	dialog.free()
