extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"season advance reaches registration and shows existing application dialog","callable":test_registration},
		{"name":"summary manual quarter cannot bypass pending body decision","callable":test_manual_pending},
		{"name":"summary manual quarter cannot bypass current registration","callable":test_manual_registration},
		{"name":"already open manual quarter rechecks newly pending node","callable":test_manual_stale},
		{"name":"manual quarter commits player world and autosave together","callable":test_manual_success},
		{"name":"manual quarter failed save leaves player and world unchanged","callable":test_manual_failure},
		{"name":"saved training decision resumes without repeating the quarter","callable":test_training_decision},
		{"name":"season save failure retains active career","callable":test_failed_save}]

func _manual_panel(main):
	main.get_node("%SummaryPanel").present(main.active_career,[])
	main._show_screen(main.get_node("%SummaryPanel"))
	main.get_node("%SummaryPanel").get_node("%NextButton").pressed.emit()
	var quarter = main.get_node("%QuarterPanel")
	if quarter.visible:
		quarter.set_allocations(load("res://tests/simulation/test_season_progression_service.gd").new()._quiet_plan().shares)
	return quarter

func test_manual_pending() -> void:
	var main = _main()
	main.active_career.clock.quarter = 2
	load("res://src/simulation/key_node_service.gd").add(main.active_career,"growth_warning","growth_warning","需要回应")
	var before: Dictionary = main.active_career.to_dict()
	var quarter = _manual_panel(main)
	if quarter.visible: quarter.get_node("%AdvanceButton").pressed.emit()
	T.assert_equal(main.active_career.clock.to_dict(),before.clock,"pending decision cannot be skipped by manual quarter")
	T.assert_equal(main.active_career.rng_step,before.rng_step)
	T.assert_equal(not quarter.visible or quarter.get_node("%AdvanceButton").disabled,true)
	main.free()

func test_manual_registration() -> void:
	var main = _main(); main.active_career.clock.quarter = 2
	var quarter = _manual_panel(main)
	if quarter.visible: quarter.get_node("%AdvanceButton").pressed.emit()
	T.assert_equal(main.active_career.clock.to_dict(),{"year":2018,"quarter":2})
	T.assert_equal(main.get_node("%SeasonOverviewPanel").visible,true)
	T.assert_equal(main.get_node("%SeasonOverviewPanel").find_child("DomesticScheduleDialog",true,false).visible,true)
	main.free()

func test_manual_success() -> void:
	var main = _main(); var quarter = _manual_panel(main)
	quarter.request_advance()
	T.assert_equal(main.active_career.clock.to_dict(),{"year":2018,"quarter":2})
	T.assert_equal(main.active_career.world_state.last_advanced_clock,{"year":2018,"quarter":2})
	var saved: Dictionary = load("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
	T.assert_equal(saved.ok,true)
	T.assert_equal(saved.career.to_dict(),main.active_career.to_dict())
	main.free()

func test_manual_stale() -> void:
	var main = _main(); var quarter = _manual_panel(main)
	load("res://src/simulation/key_node_service.gd").add(main.active_career,"growth_warning","late-growth","需要回应")
	var before: Dictionary = main.active_career.to_dict()
	await quarter.request_advance()
	T.assert_equal(main.active_career.to_dict(),before,"a previously enabled manual button must recheck pending decisions")
	T.assert_equal(main.get_node("%SummaryPanel").visible,true)
	main.free()

func test_manual_failure() -> void:
	var main = _main(); var quarter = _manual_panel(main)
	main.autosave_path = "res://missing-task10-directory/save.json"
	var before: Dictionary = main.active_career.to_dict()
	await quarter.continue_training()
	T.assert_equal(main.active_career.to_dict(),before,"failed persistence cannot publish any part of a quarter")
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("保存失败"),true)
	main.free()

func test_training_decision() -> void:
	var main = _main()
	main.active_career.condition_state.pending_training_events = [{"id":"test-progress","signature":"roadmap_progress","title":"讨论目标","description":"训练后讨论","trigger_codes":[],"cause_ids":[],"choices":[{"id":"roadmap_accept_revision","label":"接受调整"}]}]
	var clock: Dictionary = main.active_career.clock.to_dict()
	main.open_next_quarter()
	var quarter = main.get_node("%QuarterPanel")
	T.assert_equal(quarter._pending_events.size(),1)
	quarter.resolve_event_choice("roadmap_accept_revision")
	T.assert_equal(main.active_career.clock.to_dict(),clock)
	T.assert_equal(main.active_career.condition_state.get("pending_training_events",[]),[])
	T.assert_equal(main.active_career.roadmap_revision_history.size(),1)
	main.free()

func _main():
	for suffix in ["",".tmp",".bak",".meta"]:
		var path := "user://task10-ui.json" + str(suffix)
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.autosave_path = "user://task10-ui.json"
	var career = F.formal_junior_career(8190)
	career.clock.quarter = 1; career.condition_state.growth_phase = "adapted"
	career.event_ledger.append({"kind":"onboarding_seen","stage":"intro","skip_all":true,"clock":career.clock.to_dict()})
	career.last_generated_plan = load("res://tests/simulation/test_season_progression_service.gd").new()._quiet_plan().to_dict()
	main.active_career = career; main._open_career_home()
	return main

func test_registration() -> void:
	var main = _main()
	main.get_node("%SeasonOverviewPanel").get_node("%AdvanceButton").pressed.emit()
	T.assert_equal(main.active_career.clock.quarter,2)
	T.assert_equal(main.get_node("%SeasonOverviewPanel").visible,true)
	T.assert_equal(main.get_node("%SeasonOverviewPanel").find_child("DomesticScheduleDialog",true,false).visible,true)
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("报名"),true)
	main.free()

func test_failed_save() -> void:
	var main = _main(); var before: Dictionary = main.active_career.to_dict()
	main.autosave_path = "res://missing-task10-directory/save.json"
	main.get_node("%SeasonOverviewPanel").get_node("%AdvanceButton").pressed.emit()
	T.assert_equal(main.active_career.to_dict(),before)
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("保存失败"),true)
	main.free()
