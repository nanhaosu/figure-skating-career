extends RefCounted
const T = preload("res://tests/test_support.gd")
const Fixture = preload("res://tests/simulation/test_program_upgrade_service.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"programme suggestion can return without changing or saving","callable":test_inspect},
		{"name":"explicit programme review reopens a declined suggestion","callable":test_reopen},
		{"name":"failed programme upgrade save keeps decision and retries once","callable":test_save_retry}]

func test_reopen() -> void:
	var main = _main()
	var proposal: Dictionary = load("res://src/simulation/program_upgrade_service.gd").propose(main.active_career,"free",Fixture.new()._rules())
	main.autosave_path = "user://test-upgrade-reconsider.json"
	main._review_program_upgrade()
	await main._resolve_program_upgrade(proposal,"decline")
	T.assert_equal(main._decision_dialog.visible,false)
	var before: Dictionary = main.active_career.to_dict()
	main._review_program_upgrade()
	T.assert_equal(main._decision_dialog.visible,true)
	T.assert_equal(main.active_career.to_dict() == before,true)
	main.free()

func _main():
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = Fixture.new()._career()
	return main

func test_inspect() -> void:
	var main = _main()
	var before: Dictionary = main.active_career.to_dict()
	T.assert_equal(main.has_method("_review_program_upgrade"),true)
	if main.has_method("_review_program_upgrade"):
		main._review_program_upgrade()
		var dialog = main.get_node("CareerDecisionDialog")
		T.assert_equal(dialog.visible,true)
		dialog.find_child("UpgradeReturn",true,false).pressed.emit()
		T.assert_equal(dialog.visible,false)
		T.assert_equal(main.active_career.to_dict() == before,true)
	main.free()

func test_save_retry() -> void:
	var main = _main()
	T.assert_equal(main.has_method("_review_program_upgrade"),true)
	if not main.has_method("_review_program_upgrade"): main.free(); return
	var before: Dictionary = main.active_career.to_dict()
	var proposal: Dictionary = load("res://src/simulation/program_upgrade_service.gd").propose(main.active_career,"free",Fixture.new()._rules())
	main._review_program_upgrade()
	main.autosave_path = "user://missing-upgrade-directory-%d/autosave.json" % Time.get_ticks_usec()
	await main._resolve_program_upgrade(proposal,"accept")
	T.assert_equal(main.active_career.to_dict() == before,true)
	T.assert_equal(main.get_node("CareerDecisionDialog").visible,true)
	main.autosave_path = "user://test-program-upgrade-retry.json"
	await main._resolve_program_upgrade(proposal,"accept")
	T.assert_equal(main.active_career.active_programs.free != before.active_programs.free,true)
	var after: Dictionary = main.active_career.to_dict()
	await main._resolve_program_upgrade(proposal,"accept")
	T.assert_equal(main.active_career.to_dict() == after,true)
	main.free()
