extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"between-segment editor retains the actual senior event rule menu","callable":senior_menu}]
func senior_menu() -> void:
	var career = F.formal_acceptance_career("qualify")
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	var event: Dictionary = bundle.calendar.events.filter(func(e): return e.event_id == "cn_national_championships_2018")[0]
	career.active_programs.free.elements.append(load("res://src/domain/program_element.gd").create("senior-choreo","choreographic_sequence").element.to_dict())
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var session: Dictionary = sim.create_session(career,event,career.active_programs,"balanced",913)
	session = sim.complete_practice(session,"accept")
	session = sim.lock_short(career,session)
	T.assert_equal(session.errors,[])
	T.assert_equal(session.status,"free_adjustment")
	if session.status != "free_adjustment": return
	career.competition_state = session
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(career); main.confirm_new_career_replacement()
	main.get_node("%FormalCompetitionPanel").adjustment_selected.emit("protect")
	var editor = main.get_node("%ProgramEditorPanel")
	T.assert_equal(editor.rules.level,"senior")
	T.assert_equal(editor.get_node("%SaveButton").disabled,false)
	main.free()
