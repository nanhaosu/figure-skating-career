extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const ProgramDraftService = preload("res://src/simulation/program_draft_service.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const SCENE_PATH := "res://src/app/program_editor_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"beginner editor explains jump codes with visible names and a dismissible guide","callable":test_action_guide},
		{"name":"jump rows use skating codes instead of internal identifiers","callable":test_jump_row_codes},
		{"name":"program editor saves an incomplete coach draft without invented jumps", "callable":test_partial_draft_save},
		{"name":"advanced jump choices exclude locked rotations", "callable":test_advanced_jump_choices},
		{"name":"advanced editor reorders and replaces only learned actions", "callable":test_advanced_action_edit},
		{"name":"advanced controls change order and refresh an obsolete draft", "callable":test_advanced_controls_and_refresh},
		{"name":"advanced controls apply unlocked jump combinations and spin variants", "callable":test_advanced_choice_controls},
		{"name":"music catalog selection and base preview update the draft", "callable":test_music_and_base_preview},
		{"name":"advanced editor can add and remove action slots with rule feedback", "callable":test_add_remove_action},
		{"name":"beginner can replace an illegal program with one coach action", "callable":test_one_click_coach_repair},
		{"name":"coach repair keeps the current draft when legal content is not learned", "callable":test_blocked_coach_repair},
		{"name":"missing prescribed spin identifies its action slot", "callable":test_prescribed_spin_slot_issue},
		{"name":"default editor shows action candidates without raw level or coordinate fields", "callable":test_action_row_default_ui},
		{"name":"save keeps an incomplete draft while lock requires a legal program", "callable":test_save_and_lock_are_separate},
		{"name":"editor keeps primary actions visible without horizontal scrolling at supported sizes", "callable":test_supported_layouts},
		{"name":"action-row editor keeps direct control of combination followers", "callable":test_action_row_combination_choice},
		{"name":"program editor is a fixed single-screen grouped workspace", "callable":test_fixed_grouped_workspace},
	]

func test_action_guide() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(100104)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career,"short",rules,ProgramDraftService.propose(career.athlete,"short",rules,{},100104))
	panel.get_node("%ActionList").select(0)
	panel.get_node("%ActionList").item_selected.emit(0)
	var choices: ItemList = panel.get_node("%CandidateList")
	var found := false
	for index in choices.item_count:
		var candidate: Dictionary = choices.get_item_metadata(index)
		if candidate.get("jump_id","") == "toe_loop" and candidate.get("rotations",0) == 3:
			found = choices.get_item_text(index).contains("后外点冰跳") and choices.get_item_text(index).contains("3T")
	TestSupport.assert_equal(found,true,"codes must have visible Chinese names without requiring a hover")
	var help_button = panel.get_node_or_null("%ActionGuideButton")
	TestSupport.assert_equal(help_button != null,true,"beginner explanations must be discoverable by clicking")
	if help_button == null: panel.free(); return
	var before := JSON.stringify(panel.program.to_dict())
	help_button.pressed.emit()
	var guide = panel.get_node("%ActionGuideDialog")
	TestSupport.assert_equal(guide.visible,true)
	TestSupport.assert_equal(guide.dialog_text.contains("连跳"),true)
	TestSupport.assert_equal(guide.dialog_text.contains("等级"),true)
	guide.hide()
	TestSupport.assert_equal(JSON.stringify(panel.program.to_dict()),before,"opening and closing help must not edit or advance the program")
	panel.free()

func test_jump_row_codes() -> void:
	var panel = load(SCENE_PATH).instantiate()
	var element = preload("res://src/domain/program_element.gd").create("j","jump","lutz",3).element
	element.combination_parts.append({"jump_id":"toe_loop","rotations":3})
	TestSupport.assert_equal(panel._element_label(element),"3Lz+3T")
	panel.free()

func test_fixed_grouped_workspace() -> void:
	var viewport := SubViewport.new(); viewport.size = Vector2i(960, 540); Engine.get_main_loop().root.add_child(viewport)
	var panel = load(SCENE_PATH).instantiate(); viewport.add_child(panel)
	var career = Fixtures.formal_junior_career(726)
	var rules := InternalEventRules.for_season(2018, "junior", "free")
	var proposal := ProgramDraftService.propose(career.athlete, "free", rules, {}, 726)
	panel.present(career, "free", rules, proposal)
	await Engine.get_main_loop().process_frame
	TestSupport.assert_equal(panel.get_node("%BodyScroll") is ScrollContainer, false,"normal editor cannot scroll the whole page")
	TestSupport.assert_equal(panel.get_node("%JumpGroupButton").visible, true)
	TestSupport.assert_equal(panel.get_node("%SpinStepGroupButton").visible, true)
	for action_name in ["CloseButton", "SaveButton", "LockButton"]:
		var button: Button = panel.get_node("%" + action_name)
		TestSupport.assert_equal(button.get_global_rect().end.y <= 540.0, true, action_name + " must remain visible")
	viewport.free()

func test_action_row_combination_choice() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(734)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.salchow.unlocked_rotations = 1
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 734))
	panel.get_node("%ActionList").select(0)
	panel.get_node("%ActionList").item_selected.emit(0)
	var candidate_list: ItemList = panel.get_node("%CandidateList")
	for index in candidate_list.item_count:
		var candidate: Dictionary = candidate_list.get_item_metadata(index)
		if candidate.get("jump_id", "") == "salchow" and int(candidate.get("rotations", 0)) == 1: candidate_list.select(index); candidate_list.item_selected.emit(index)
	var first: OptionButton = panel.get_node("%Connection1Choice")
	for index in first.item_count:
		var candidate: Dictionary = first.get_item_metadata(index)
		if candidate.get("jump_id", "") == "toe_loop" and int(candidate.get("rotations", 0)) == 1: first.select(index)
	panel.get_node("%CandidateApplyButton").pressed.emit()
	TestSupport.assert_equal(panel.program.elements[0].jump_id, "salchow")
	TestSupport.assert_equal(panel.program.elements[0].combination_parts, [{"jump_id":"toe_loop", "rotations":1}])
	panel.free()

func test_supported_layouts() -> void:
	var viewport := SubViewport.new()
	Engine.get_main_loop().root.add_child(viewport)
	var panel = load(SCENE_PATH).instantiate()
	viewport.add_child(panel)
	var career = Fixtures.starting_career(733)
	for jump in career.athlete.jumps.values(): jump.unlocked_rotations = 1
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 733))
	for dimensions in [Vector2i(1280,720), Vector2i(960,540)]:
		viewport.size = dimensions
		await Engine.get_main_loop().process_frame
		await Engine.get_main_loop().process_frame
		var minimum: Vector2 = panel.get_combined_minimum_size()
		TestSupport.assert_equal(minimum.x <= dimensions.x and minimum.y <= dimensions.y, true, "editor minimum %s exceeds %s" % [minimum, dimensions])
		for button_name in ["CloseButton", "SaveButton", "LockButton"]:
			var button: Button = panel.get_node("%%%s" % button_name)
			var rect: Rect2 = button.get_global_rect()
			TestSupport.assert_equal(button.visible and rect.end.x <= dimensions.x and rect.end.y <= dimensions.y, true, "%s is outside %s: %s" % [button_name, dimensions, rect])
		TestSupport.assert_equal(panel.get_node("%BodyScroll") is ScrollContainer, false)
	viewport.free()

func test_action_row_default_ui() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(731)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.toe_loop.attempt_evidence.double.attempts = 4
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 731))
	TestSupport.assert_equal(panel.get_node("%AdvancedToggle").visible, false)
	TestSupport.assert_equal(panel.get_node("%ActionList").visible, true)
	TestSupport.assert_equal(panel.get_node("%DetailInputs").visible, false)
	panel.get_node("%ActionList").select(0)
	panel.get_node("%ActionList").item_selected.emit(0)
	var candidate_list: ItemList = panel.get_node("%CandidateList")
	TestSupport.assert_equal(candidate_list.item_count > 0, true)
	var joined := ""
	for index in candidate_list.item_count: joined += candidate_list.get_item_text(index)
	TestSupport.assert_equal(joined.contains("稳定") or joined.contains("冒险") or joined.contains("尚不可用"), true)
	TestSupport.assert_equal(panel.get_node("%CandidateReasonLabel").text.is_empty(), false)
	panel.free()

func test_save_and_lock_are_separate() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(732)
	Fixtures.clear_jump_progress(career)
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 732))
	var saved: Array = []
	panel.program_saved.connect(func(_segment, data): saved.append(data))
	panel.get_node("%SaveButton").pressed.emit()
	TestSupport.assert_equal(saved.size(), 1)
	TestSupport.assert_equal(saved[0].draft_status, "draft")
	TestSupport.assert_equal(panel.get_node("%LockButton").disabled, true)
	for jump in career.athlete.jumps.values(): jump.unlocked_rotations = 1
	panel.refresh_coach_draft()
	TestSupport.assert_equal(panel.get_node("%LockButton").disabled, false)
	panel.get_node("%LockButton").pressed.emit()
	TestSupport.assert_equal(saved.size(), 2)
	TestSupport.assert_equal(saved[1].draft_status, "locked")
	TestSupport.assert_equal(saved[1].locked_segments, ["short"])
	panel.free()

func test_prescribed_spin_slot_issue() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.formal_junior_career(730)
	var rules := InternalEventRules.for_season(2018,"junior","short")
	var program = ProgramDraftService.legal_draft(career.athlete,"short",rules,{},730).program
	var changed_index := -1
	for index in program.elements.size():
		if program.elements[index].kind == "spin" and program.elements[index].spin_code == "FCSp":
			program.elements[index].spin_code = "FSSp"
			changed_index = index
	career.active_programs.short = program.to_dict()
	panel.present(career,"short",rules,{})
	TestSupport.assert_equal(changed_index >= 0,true)
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("第%d槽" % (changed_index + 1)),true)
	TestSupport.assert_equal(panel.get_node("%ActionList").get_item_text(changed_index).begins_with("⚠"),true)
	panel.free()

func test_blocked_coach_repair() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.formal_junior_career(729)
	career.athlete.jumps.axel.unlocked_rotations = 1
	var rules := InternalEventRules.for_season(2018,"junior","short")
	var proposal := ProgramDraftService.propose(career.athlete,"short",rules,{},729)
	panel.present(career,"short",rules,proposal)
	var before := JSON.stringify(panel.program.to_dict())
	panel.get_node("%CoachRepairButton").pressed.emit()
	TestSupport.assert_equal(JSON.stringify(panel.program.to_dict()),before,"blocked repair must not replace the visible draft with another illegal draft")
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("无法生成合规方案"),true)
	panel.free()

func test_one_click_coach_repair() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.formal_junior_career(727)
	var rules := InternalEventRules.for_season(2018,"junior","short")
	var illegal = ProgramDraftService.propose(career.athlete,"short",rules,{},727).program
	illegal.elements[0].set_combination_parts([{"jump_id":"flip","rotations":2}])
	career.active_programs.short = illegal.to_dict()
	panel.present(career,"short",rules,ProgramDraftService.propose(career.athlete,"short",rules,{},728))
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("暂不可参赛"),true)
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("第1槽"),true,"rule errors should identify the action slot the player must repair")
	var repair_button: Button = panel.get_node("%CoachRepairButton")
	TestSupport.assert_equal(repair_button.visible,true)
	repair_button.pressed.emit()
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("符合比赛规则"),true)
	TestSupport.assert_equal(panel.get_node("%CloseButton").visible,true)
	panel.free()

func test_add_remove_action() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(726)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.salchow.unlocked_rotations = 1
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 726))
	var add_button = panel.get_node_or_null("%AddJumpButton")
	TestSupport.assert_equal(add_button != null, true)
	if add_button == null: panel.free(); return
	add_button.pressed.emit()
	TestSupport.assert_equal(panel.program.elements.size(), 5)
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("暂不可参赛"), true)
	panel.get_node("%RemoveActionButton").pressed.emit()
	TestSupport.assert_equal(panel.program.elements.size(), 4)
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("符合比赛规则"), true)
	panel.free()

func test_music_and_base_preview() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(725)
	Fixtures.clear_jump_progress(career)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.salchow.unlocked_rotations = 1
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 725))
	var music_choice = panel.get_node_or_null("%MusicPresetChoice")
	var base_label = panel.get_node_or_null("%BasePreviewLabel")
	TestSupport.assert_equal(music_choice != null and base_label != null, true)
	if music_choice == null or base_label == null: panel.free(); return
	TestSupport.assert_equal(base_label.text.contains("6.30"), true)
	for index in music_choice.item_count:
		if music_choice.get_item_metadata(index) == "swan_lake": music_choice.select(index)
	music_choice.item_selected.emit(music_choice.selected)
	TestSupport.assert_equal(panel.get_node("%MusicTitleInput").text, "天鹅湖")
	var saved: Array = []
	panel.program_saved.connect(func(_segment, data): saved.append(data))
	panel.get_node("%SaveButton").pressed.emit()
	TestSupport.assert_equal(saved[0].music.title, "天鹅湖")
	panel.free()

func test_advanced_choice_controls() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(724)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.salchow.unlocked_rotations = 1
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 724))
	var jump_choice = panel.get_node_or_null("%JumpChoice")
	TestSupport.assert_equal(jump_choice != null, true)
	if jump_choice == null: panel.free(); return
	var combo_choice = panel.get_node("%Combo1Choice")
	for index in jump_choice.item_count:
		if jump_choice.get_item_metadata(index) == {"jump_id":"salchow", "rotations":1}: jump_choice.select(index)
	for index in combo_choice.item_count:
		if combo_choice.get_item_metadata(index) == {"jump_id":"toe_loop", "rotations":1}: combo_choice.select(index)
	panel.get_node("%ActionList").select(0)
	panel.get_node("%ApplyJumpButton").pressed.emit()
	TestSupport.assert_equal(panel.program.elements[0].jump_id, "salchow")
	TestSupport.assert_equal(panel.program.elements[0].combination_parts, [{"jump_id":"toe_loop", "rotations":1}])
	TestSupport.assert_equal(panel.get_node("%LoadLabel").text.contains("连跳完成率参考"),true,"the coach should explain the consequence without adding another training control")
	panel.get_node("%ActionList").select(2)
	var spin_choice = panel.get_node("%SpinChoice")
	for index in spin_choice.item_count:
		if spin_choice.get_item_metadata(index) == "FCSp": spin_choice.select(index)
	panel.get_node("%ApplySpinButton").pressed.emit()
	TestSupport.assert_equal(panel.program.elements[2].spin_code, "FCSp")
	panel.free()

func test_advanced_controls_and_refresh() -> void:
	var panel = load(SCENE_PATH).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(723)
	var rules := InternalEventRules.for_teaching_group("short")
	panel.present(career, "short", rules, ProgramDraftService.propose(career.athlete, "short", rules, {}, 723))
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.salchow.unlocked_rotations = 1
	var refresh_button = panel.get_node_or_null("%RefreshDraftButton")
	TestSupport.assert_equal(refresh_button != null, true)
	if refresh_button == null: panel.free(); return
	refresh_button.pressed.emit()
	TestSupport.assert_equal(panel.program.elements.any(func(element): return element.kind == "jump"), true)
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("符合比赛规则"), true)
	panel.get_node("%ActionList").select(0)
	panel.get_node("%MoveDownButton").pressed.emit()
	TestSupport.assert_equal(panel.program.elements[0].combination_parts.is_empty(), true)
	panel.free()

func test_advanced_action_edit() -> void:
	var scene = load(SCENE_PATH)
	var panel = scene.instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(722)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	career.athlete.jumps.salchow.unlocked_rotations = 1
	var proposal := ProgramDraftService.propose(career.athlete, "short", InternalEventRules.for_teaching_group("short"), {}, 722)
	panel.present(career, "short", InternalEventRules.for_teaching_group("short"), proposal)
	TestSupport.assert_equal(panel.has_method("move_element"), true)
	if not panel.has_method("move_element"): panel.free(); return
	panel.call("move_element", 0, 1)
	TestSupport.assert_equal(panel.program.elements[0].combination_parts.is_empty(), true)
	TestSupport.assert_equal(panel.call("replace_jump", 0, "lutz", 3, []), ["3Lz尚未解锁"])
	TestSupport.assert_equal(panel.program.elements[0].jump_id == "lutz", false)
	TestSupport.assert_equal(panel.call("replace_jump", 0, "toe_loop", 1, [{"jump_id":"salchow","rotations":1}]).is_empty(), false)
	TestSupport.assert_equal(panel.call("replace_jump", 0, "toe_loop", 1, []), [])
	TestSupport.assert_equal(panel.call("set_spin_type", 2, "FCSp"), [])
	TestSupport.assert_equal(panel.program.elements[2].spin_code, "FCSp")
	panel.free()

func test_partial_draft_save() -> void:
	var scene = load(SCENE_PATH)
	TestSupport.assert_equal(scene != null, true)
	if scene == null: return
	var panel = scene.instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(720)
	Fixtures.clear_jump_progress(career)
	var proposal := ProgramDraftService.propose(career.athlete, "short", InternalEventRules.for_teaching_group("short"), {"title":"自选练习曲"}, 720)
	panel.present(career, "short", InternalEventRules.for_teaching_group("short"), proposal)
	TestSupport.assert_equal(panel.get_node("%StatusLabel").text.contains("草案"), true)
	var saved: Array = []
	panel.program_saved.connect(func(segment, data): saved.append({"segment":segment, "data":data}))
	panel.get_node("%SaveButton").pressed.emit()
	TestSupport.assert_equal(saved.size(), 1)
	TestSupport.assert_equal(saved[0].segment, "short")
	TestSupport.assert_equal(saved[0].data.elements.any(func(element): return element.kind == "jump"), false)
	panel.free()

func test_advanced_jump_choices() -> void:
	var scene = load(SCENE_PATH)
	TestSupport.assert_equal(scene != null, true)
	if scene == null: return
	var panel = scene.instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(721)
	Fixtures.clear_jump_progress(career)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	var proposal := ProgramDraftService.propose(career.athlete, "short", InternalEventRules.for_teaching_group("short"), {}, 721)
	panel.present(career, "short", InternalEventRules.for_teaching_group("short"), proposal)
	TestSupport.assert_equal(panel.available_jump_options(), [{"jump_id":"toe_loop", "rotations":1}])
	panel.free()
