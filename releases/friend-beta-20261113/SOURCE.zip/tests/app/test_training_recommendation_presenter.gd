extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Presenter = preload("res://src/app/training_recommendation_presenter.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"coach offers three understandable plans with one recommendation","callable":three_options},
		{"name":"high fatigue makes recovery the recommended plan","callable":recovery_first},
		{"name":"recommendation preview does not mutate the career","callable":read_only},
		{"name":"every offered plan is complete and executable","callable":valid_plans},
	]

func three_options() -> void:
	var result: Dictionary = Presenter.for_career(F.starting_career(93101),Catalog.load_catalog())
	T.assert_equal(result.options.size(),3)
	T.assert_equal(result.options.filter(func(option): return bool(option.recommended)).size(),1)
	for option in result.options:
		T.assert_equal(str(option.title).is_empty(),false)
		T.assert_equal(str(option.benefit).is_empty(),false)
		T.assert_equal(str(option.tradeoff).is_empty(),false)

func recovery_first() -> void:
	var career = F.starting_career(93102)
	career.athlete.body.acute_fatigue = 82.0
	career.athlete.body.impact_load = 76.0
	var result: Dictionary = Presenter.for_career(career,Catalog.load_catalog())
	T.assert_equal(result.options[0].id,"recovery")
	T.assert_equal(result.options[0].recommended,true)
	T.assert_equal(str(result.coach_note).contains("恢复"),true)

func read_only() -> void:
	var career = F.starting_career(93103)
	var before := JSON.stringify(career.to_dict())
	Presenter.for_career(career,Catalog.load_catalog())
	T.assert_equal(JSON.stringify(career.to_dict()),before)

func valid_plans() -> void:
	var result: Dictionary = Presenter.for_career(F.starting_career(93104),Catalog.load_catalog())
	for option in result.options:
		var sum := 0
		for value in Dictionary(option.plan.shares).values(): sum += int(value)
		T.assert_equal(sum,100)
		T.assert_equal(TrainingPlan.from_dict(option.plan) != null,true)
