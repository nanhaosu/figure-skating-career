extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const PANEL_SCENE := "res://src/app/internal_competition_panel.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"between-segment modal can exit without choosing an adjustment", "callable":test_overlay_exit.bind(false)},
		{"name":"final-result modal can exit without settling the career", "callable":test_overlay_exit.bind(true)},
		{"name":"teaching broadcast always exposes an exit to main menu", "callable":test_main_menu_exit},
		{"name":"internal broadcast fills its actual main-window viewport","callable":test_main_viewport},
		{"name": "competition panel uses broadcast layout", "callable": test_broadcast_layout},
		{"name": "competition panel feeds live technical elements", "callable": test_live_technical_feed},
		{"name": "competition panel exposes three playback speeds", "callable": test_viewing_speeds},
		{"name": "one click starts automatic route playback", "callable": test_automatic_playback},
		{"name": "pause freezes automatic route playback", "callable": test_pause_playback},
		{"name": "cached performance reveals without rerolling", "callable": test_cached_performance_reveal},
		{"name": "technical review updates yellow element in place", "callable": test_review_updates_in_place},
		{"name": "competition panel presents separated final score", "callable": test_final_score_strip},
		{"name": "between segment adjustment emits player choice", "callable": test_adjustment_choice},
		{"name": "playback button resolves cached segment exactly once", "callable": test_playback_completion},
		{"name": "final standings separate public result and club decision", "callable": test_final_standings},
		{"name": "internal segment waits through staged kiss and cry before completion", "callable": test_staged_kiss_and_cry},
	]

func test_overlay_exit(final_result: bool) -> void:
	var panel = _panel()
	panel.present({"segment":"short"})
	if final_result: panel.present_final_result({"public_rank":1,"standings":[]})
	else: panel.present_adjustment_options([{"id":"keep","label":"保留节目"}])
	var button = panel.find_child("ResultMainMenuButton" if final_result else "AdjustmentMainMenuButton",true,false)
	TestSupport.assert_equal(button != null,true,"a modal cannot block every exit behind its overlay")
	if button != null:
		var calls := [0,0]
		panel.main_menu_requested.connect(func(): calls[0] += 1)
		panel.competition_confirmed.connect(func(): calls[1] += 1)
		panel.adjustment_selected.connect(func(_option): calls[1] += 1)
		TestSupport.assert_equal(button.is_visible_in_tree(),true)
		button.pressed.emit()
		TestSupport.assert_equal(calls,[1,0],"exit cannot select an adjustment or settle the competition")
	panel.free()

func test_main_menu_exit() -> void:
	var panel = _panel()
	panel.present({"segment":"short"})
	var button = panel.find_child("BroadcastMainMenuButton",true,false)
	TestSupport.assert_equal(button != null,true,"exit must be available before skating, not only inside K&C")
	if button != null:
		var calls := [0]
		panel.main_menu_requested.connect(func(): calls[0] += 1)
		TestSupport.assert_equal(button.is_visible_in_tree(),true)
		button.pressed.emit()
		TestSupport.assert_equal(calls[0],1)
	panel.free()

func test_main_viewport() -> void:
	var host = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(host)
	host.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	host.size = Vector2(1280,720)
	var panel = host.get_node("%CompetitionPanel")
	host._show_screen(panel)
	for i in 3: await Engine.get_main_loop().process_frame
	TestSupport.assert_equal(panel.size,host.size,"the teaching broadcast must not fall back to its minimum content size")
	TestSupport.assert_equal(panel.get_node("Layout").size.x >= 1200,true,"broadcast content must use the available width")
	host.free()

func test_staged_kiss_and_cry() -> void:
	var panel = _panel(); var completed: Array[String] = []
	panel.segment_completed.connect(func(segment): completed.append(segment))
	panel.present({"event_name":"内部赛","segment_name":"短节目","segment":"short","athlete_name":"很长很长的运动员姓名","music_title":"月光"})
	panel.present_score({"tes":99.0,"total":120.0})
	panel.present({"segment":"free","total_score":50.0,"current_rank":2})
	TestSupport.assert_equal(panel.get_node("%TotalValue").text,"0.00","new segment must clear old segment score")
	panel.load_segment(_route_segment())
	var before := JSON.stringify(panel._segment_record)
	panel.settle_immediately()
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,true)
	TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"waiting")
	TestSupport.assert_equal(completed,[])
	TestSupport.assert_equal(panel.is_processing(),true,"K&C reveal must continue automatically after skating stops")
	panel.advance_time(0.7); TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"technical_confirmed")
	panel.advance_time(0.7); TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"components_confirmed")
	panel.advance_time(0.7); TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").reveal_stage,"final")
	TestSupport.assert_equal(panel.get_node("%KissAndCryPanel").view_model.total_score,50.0)
	panel.advance_time(0.5)
	TestSupport.assert_equal(completed,[],"revealing scores must not advance the career behind the overlay")
	var kc = panel.get_node("%KissAndCryPanel")
	kc.get_node("%ProtocolButton").pressed.emit()
	TestSupport.assert_equal(panel._protocol_dialog.visible,true)
	TestSupport.assert_equal(panel._protocol_dialog.dialog_text.contains("GOE"),true)
	panel._protocol_dialog.hide()
	kc.get_node("%ReturnButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,false)
	TestSupport.assert_equal(completed,[])
	panel.get_node("%PlaybackButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,true)
	var menu_requests: Array = []
	panel.main_menu_requested.connect(func(): menu_requests.append(true))
	kc.get_node("%MainMenuButton").pressed.emit()
	TestSupport.assert_equal(menu_requests,[true])
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(completed,["free"])
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,false)
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(completed,["free"],"confirmation is idempotent")
	TestSupport.assert_equal(JSON.stringify(panel._segment_record),before)
	panel.free()

func test_playback_completion() -> void:
	var panel = _panel()
	var completed: Array[String] = []
	panel.segment_completed.connect(func(segment): completed.append(segment))
	panel.present({"event_name": "内部赛", "segment_name": "短节目", "segment": "short", "athlete_name": "林澄", "music_title": "月光"})
	panel.load_segment({
		"performance": {"elements": [{"element_id": "j1", "abbreviation": "2A", "base_value": 3.3, "live_goe": 0.2, "status": "success"}]},
		"technical_review": {"final_elements": [{"element_id": "j1", "abbreviation": "2A", "base_value": 3.3, "live_goe": 0.2, "status": "success"}]},
		"score": {"tes": 3.5, "pcs": 10.0, "deductions": 0.0, "total": 13.5},
	})
	panel.get_node("%PlaybackButton").pressed.emit()
	panel.advance_time(100.0)
	panel.advance_time(3.0)
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(completed, ["short"])
	TestSupport.assert_equal(panel.get_node("%TotalValue").text, "13.50")
	panel.free()

func test_final_standings() -> void:
	var panel = _panel()
	var finished := []
	panel.competition_confirmed.connect(func(): finished.append(true))
	panel.present_final_result({
		"public_rank": 2, "total_score": 62.1,
		"standings": [
			{"rank": 1, "name": "周星澜", "short_total": 23.0, "free_total": 41.0, "total": 64.0, "is_player": false},
			{"rank": 2, "name": "林澄", "short_total": 22.0, "free_total": 40.1, "total": 62.1, "is_player": true},
		],
		"club_decision": {"summary": "进入外赛观察名单", "resource_changes": {"ice_access": 3.0}},
	})
	TestSupport.assert_equal(panel.get_node("%ResultOverlay").visible, true)
	TestSupport.assert_equal(panel.get_node("%ResultTitle").text.contains("第 2 名"), true)
	TestSupport.assert_equal(panel.get_node("%ClubDecisionText").text.contains("俱乐部决定"), true)
	panel.get_node("%ConfirmResultButton").pressed.emit()
	TestSupport.assert_equal(finished, [true])
	panel.free()

func test_adjustment_choice() -> void:
	var panel = _panel()
	var selected: Array[String] = []
	panel.adjustment_selected.connect(func(option_id): selected.append(option_id))
	panel.present_adjustment_options([
		{"id": "keep", "label": "保持原方案", "reason": "不增加临时代价"},
		{"id": "protect", "label": "降低难度", "reason": "保护体能"},
	])
	TestSupport.assert_equal(panel.get_node("%AdjustmentOverlay").visible, true)
	var protect: Button = panel.find_child("Adjustment_protect", true, false)
	protect.pressed.emit()
	TestSupport.assert_equal(selected, ["protect"])
	TestSupport.assert_equal(panel.get_node("%AdjustmentOverlay").visible, false)
	panel.free()

func test_final_score_strip() -> void:
	var panel = _panel()
	panel.present_score({"tes": 24.35, "pcs": 22.10, "deductions": 1.0, "total": 45.45, "internal_advantage": 1.25})
	TestSupport.assert_equal(panel.get_node("%TesValue").text, "24.35")
	TestSupport.assert_equal(panel.get_node("%PcsValue").text, "22.10")
	TestSupport.assert_equal(panel.get_node("%DeductionValue").text, "-1.00")
	TestSupport.assert_equal(panel.get_node("%TotalValue").text, "45.45")
	TestSupport.assert_equal(panel.get_node("%InternalAdvantageNote").text.contains("内部评分环境"), true)
	panel.free()

func test_review_updates_in_place() -> void:
	var panel = _panel()
	panel.present({"event_name": "内部赛", "segment_name": "短节目", "athlete_name": "林澄", "music_title": "月光"})
	panel.reveal_element({"element_id": "j1", "abbreviation": "2Lz", "base_value": 2.10, "live_goe": -0.20, "status": "review"})
	panel.apply_technical_review({"final_elements": [
		{"element_id": "j1", "abbreviation": "2Lze", "base_value": 2.10, "live_goe": -0.95, "status": "error"},
	]})
	var row: Control = panel.find_child("Element_j1", true, false)
	TestSupport.assert_equal(row.find_child("Score", true, false).text, "2Lze  ·  GOE -0.95\n基础分 2.10")
	TestSupport.assert_equal(row.find_child("StatusBar", true, false).color, panel.technical_panel.ERROR_COLOR)
	panel.free()

func test_cached_performance_reveal() -> void:
	var panel = _panel()
	panel.present({"event_name": "内部赛", "segment_name": "短节目", "athlete_name": "林澄", "music_title": "月光"})
	var performance := {"elements": [
		{"element_id": "j1", "abbreviation": "2A", "base_value": 3.30, "live_goe": 0.44, "status": "success"},
		{"element_id": "j2", "abbreviation": "2Lz", "base_value": 2.10, "live_goe": -0.42, "status": "review"},
	]}
	panel.load_performance(performance)
	TestSupport.assert_equal(panel.find_child("Element_j1", true, false), null)
	panel.advance_playback()
	panel.advance_time(4.0)
	TestSupport.assert_equal(panel.find_child("Element_j1", true, false) != null, true)
	panel.set_view_mode("fast")
	panel.advance_time(100.0)
	TestSupport.assert_equal(panel.find_child("Element_j2", true, false) != null, true)
	TestSupport.assert_equal(panel.cached_performance, performance)
	panel.free()

func test_broadcast_layout() -> void:
	var panel = _panel()
	panel.present({"event_name": "俱乐部内部选拔", "segment_name": "短节目", "athlete_name": "林澄", "music_title": "月光"})
	TestSupport.assert_equal(panel.get_node("%EventTitle").text, "俱乐部内部选拔 · 短节目")
	TestSupport.assert_equal(panel.get_node("%AthleteLowerThird").text.contains("林澄"), true)
	TestSupport.assert_equal(panel.get_node("%AthleteLowerThird").text.contains("月光"), true)
	TestSupport.assert_equal(panel.get_node("%IceView").size_flags_horizontal, Control.SIZE_EXPAND_FILL)
	TestSupport.assert_equal(panel.get_node("%TechnicalPanel").custom_minimum_size.x >= 300.0, true)
	TestSupport.assert_equal(panel.get_node("%TechnicalPanel").get_parent(), panel.get_node("%IceView").get_parent(), "technical panel must sit beside the rink rather than cover it")
	panel.free()

func test_live_technical_feed() -> void:
	var panel = _panel()
	panel.present({"event_name": "内部赛", "segment_name": "短节目", "athlete_name": "林澄", "music_title": "月光"})
	panel.reveal_element({"element_id": "j1", "abbreviation": "2A", "base_value": 3.30, "live_goe": 0.44, "status": "success"})
	TestSupport.assert_equal(panel.find_child("Element_j1", true, false) != null, true)
	TestSupport.assert_equal(panel.get_node("%ProgressLabel").text, "1 / 1")
	panel.free()

func test_viewing_speeds() -> void:
	var panel = _panel()
	TestSupport.assert_equal(panel.find_children("Speed*", "Button", true, false).size(), 3)
	panel.set_view_mode("fast")
	TestSupport.assert_equal(panel.view_mode, "fast")
	TestSupport.assert_equal(panel.get_node("%SpeedFast").button_pressed, true)
	panel.free()

func test_automatic_playback() -> void:
	var panel = _panel()
	panel.present({"event_name": "内部赛", "segment_name": "短节目", "segment": "short", "athlete_name": "林澄", "music_title": "月光"})
	panel.load_segment(_route_segment())
	panel.get_node("%PlaybackButton").pressed.emit()
	TestSupport.assert_equal(panel.playback_state, "playing")
	panel.advance_time(5.0)
	TestSupport.assert_equal(panel.get_node("%CompetitionIceView").visible_route_point_count > 1, true)
	TestSupport.assert_equal(panel.find_child("Element_j1", true, false) != null, true)
	panel.free()

func test_pause_playback() -> void:
	var panel = _panel()
	panel.present({"event_name": "内部赛", "segment_name": "短节目"})
	panel.load_segment(_route_segment())
	panel.advance_playback()
	panel.advance_time(1.0)
	var before: Vector2 = panel.get_node("%CompetitionIceView").skater_position
	panel.advance_playback()
	TestSupport.assert_equal(panel.playback_state, "paused")
	panel.advance_time(5.0)
	TestSupport.assert_equal(panel.get_node("%CompetitionIceView").skater_position, before)
	panel.free()

func _route_segment() -> Dictionary:
	return {
		"performance": {"elements": [
			{"element_id": "j1", "abbreviation": "2A", "base_value": 3.3, "live_goe": 0.2, "status": "success"},
			{"element_id": "j2", "abbreviation": "2Lz+2T", "base_value": 3.4, "live_goe": -0.1, "status": "review"},
		]},
		"route_execution": {
			"points": [
				{"x": 0.1, "y": 0.2, "progress": 0.0},
				{"x": 0.5, "y": 0.6, "progress": 0.5},
				{"x": 0.9, "y": 0.3, "progress": 1.0},
			],
			"action_anchors": [
				{"element_id": "j1", "part_index": 0, "progress": 0.3},
				{"element_id": "j2", "part_index": 0, "progress": 0.7},
				{"element_id": "j2", "part_index": 1, "progress": 0.72},
			],
		},
		"technical_review": {"final_elements": []},
		"score": {"tes": 6.8, "pcs": 10.0, "deductions": 0.0, "total": 16.8},
	}

func _panel():
	TestSupport.assert_equal(ResourceLoader.exists(PANEL_SCENE), true)
	if not ResourceLoader.exists(PANEL_SCENE): return null
	var panel = load(PANEL_SCENE).instantiate()
	Engine.get_main_loop().root.add_child(panel)
	return panel
