extends RefCounted

const T = preload("res://tests/test_support.gd")
var _paths: Array[String] = []

func cases() -> Array[Dictionary]:
	return [
		{"name":"opening history can exit and resume without advancing", "callable":test_return.bind("history")},
		{"name":"coach handoff can exit and resume without choosing a goal", "callable":test_return.bind("handoff")},
	]

func test_return(stage: String) -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = "user://test-opening-return-%s-%d.json" % [stage,Time.get_ticks_usec()]
	_paths.append(main.autosave_path)
	Engine.get_main_loop().root.add_child(main)
	var created = load("res://src/simulation/career_factory.gd").create("QA",2006,"entry_interest_class","family_supportive",932,main.catalog,4)
	T.assert_equal(created.errors,[])
	var career = created.career
	career.opening_stage = stage
	main.offer_new_career(career)
	var panel = main.pre_career_history_panel if stage == "history" else main.coach_handoff_panel
	var button = panel.find_child("OpeningMainMenuButton",true,false)
	T.assert_equal(button != null,true,"opening inspection needs an exit without a forced next stage")
	if button == null:
		main.free()
		return
	T.assert_equal(button.is_visible_in_tree(),true)
	# Saving publishes the canonical numeric representation. Compare that
	# representation so float/int serialization is not mistaken for progression.
	var numeric = load("res://src/persistence/numeric_state.gd")
	var original := JSON.stringify(numeric.canonical_copy(career.to_dict()))
	button.pressed.emit()
	for i in 3: await Engine.get_main_loop().process_frame
	T.assert_equal(main.main_menu_panel.visible,true)
	T.assert_equal(FileAccess.file_exists(main.autosave_path),true)
	T.assert_equal(JSON.stringify(numeric.canonical_copy(main.active_career.to_dict())),original,"exit saves but cannot advance or select a goal")
	var resumed: Dictionary = main.try_resume_career()
	T.assert_equal(resumed.ok,true)
	T.assert_equal(main.active_career.opening_stage,stage)
	T.assert_equal(panel.visible,true,"resume must return to the same unfinished opening stage")
	main.free()

func teardown() -> void:
	for path in _paths:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	_paths.clear()
