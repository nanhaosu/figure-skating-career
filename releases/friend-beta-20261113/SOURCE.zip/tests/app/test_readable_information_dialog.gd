extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"help over a decision preserves the original decision and career","callable":test_decision},
		{"name":"help over programme preserves edited draft and return location","callable":test_programme},
		{"name":"guide can skip and reopen without creating a save","callable":test_skip_reopen},
		{"name":"long intro keeps close and navigation visible","callable":test_long_text}]

func test_decision() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(1071)
	var before: Dictionary = main.active_career.to_dict()
	main._new_decision_dialog("尚未保存的赛季安排")
	var original = main.get_node("CareerDecisionDialog")
	main._present_skating_guide(0)
	await Engine.get_main_loop().process_frame
	T.assert_equal(is_instance_valid(original),true,"help must not destroy the waiting decision window")
	var guide = main.find_child("SkatingInformationDialog",true,false)
	T.assert_equal(guide != null,true)
	if guide != null:
		guide.close_button.pressed.emit()
		T.assert_equal(original.visible,true)
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()

func test_programme() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(1072)
	main.open_program_editor("free")
	main.program_editor_panel.program.music.title = "尚未保存的音乐"
	var before: Dictionary = main.program_editor_panel.program.to_dict()
	var saved: Dictionary = main.active_career.to_dict()
	main._present_skating_guide(2)
	var guide = main.find_child("SkatingInformationDialog",true,false)
	T.assert_equal(guide != null,true)
	if guide != null: guide.close_button.pressed.emit()
	T.assert_equal(main.program_editor_panel.visible,true)
	T.assert_equal(main.program_editor_panel.program.to_dict() == before,true)
	T.assert_equal(main.active_career.to_dict() == saved,true)
	main.free()

func test_skip_reopen() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.autosave_path = "user://help-must-not-save-%d.json" % Time.get_ticks_usec()
	main._offer_skating_intro()
	main._decision_dialog.find_child("SkipSkatingIntro",true,false).pressed.emit()
	T.assert_equal(main.creation_screen.visible,true)
	main._present_skating_guide()
	var guide = main.find_child("SkatingInformationDialog",true,false)
	T.assert_equal(guide != null,true)
	if guide != null: guide.close_button.pressed.emit()
	T.assert_equal(main.creation_screen.visible,true)
	T.assert_equal(main.active_career,null)
	T.assert_equal(FileAccess.file_exists(main.autosave_path),false)
	main.free()

func test_long_text() -> void:
	T.assert_equal(FileAccess.file_exists("res://src/app/readable_information_dialog.tscn"),true)
	if not FileAccess.file_exists("res://src/app/readable_information_dialog.tscn"): return
	for viewport_size in [Vector2i(960,540),Vector2i(1280,720)]:
		var viewport := SubViewport.new()
		viewport.size = viewport_size
		viewport.gui_embed_subwindows = true
		Engine.get_main_loop().root.add_child(viewport)
		var window = load("res://src/app/readable_information_dialog.tscn").instantiate()
		viewport.add_child(window)
		window.present("长说明",[{"heading":"动作与规则","body":"这是可重看的花滑规则说明。\n".repeat(80)}])
		for frame in 4: await Engine.get_main_loop().process_frame
		var close = window.find_child("GuideClose",true,false)
		T.assert_equal(close != null,true)
		if close != null:
			T.assert_equal(close.get_global_rect().end.y <= window.size.y,true)
			T.assert_equal(close.get_global_rect().end.x <= window.size.x,true)
		T.assert_equal(window.size.x <= viewport_size.x and window.size.y <= viewport_size.y,true)
		T.assert_equal(window.find_child("GuideBody",true,false).size.y >= 200,true)
		window.hide()
		await Engine.get_main_loop().process_frame
		viewport.free()
