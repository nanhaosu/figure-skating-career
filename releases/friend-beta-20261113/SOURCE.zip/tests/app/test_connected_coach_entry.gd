extends RefCounted

# Actual route confirmation, storage boundary and executed course regressions.
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Roadmap = preload("res://src/domain/development_roadmap.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"successful route retry clears the actual main shell failure message","callable":main_retry_message},
		{"name":"opening training does not publish an unconfirmed coaching plan","callable":entry_preview},
		{"name":"route confirmation persists without hidden legacy approval","callable":route_confirmation},
		{"name":"failed route persistence leaves coaching choice unchanged","callable":route_rollback},
		{"name":"repeated identical route confirmation does not duplicate history","callable":route_idempotence},
		{"name":"partial agreed course does not acquire new roadmap promises","callable":partial_agreement},
		{"name":"fast route follow coach reaches real six family practice","callable":actual_follow_coach},
	]

func main_retry_message() -> void:
	var c = F.starting(73617)
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = c
	var panel = main.get_node("%QuarterPanel")
	panel.setup(c,Catalog.load_catalog())
	main.autosave_path = "user://absent-coach-route-73617/save.json"
	await panel.apply_roadmap(_route())
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("保存失败"),true)
	T.assert_equal(c.development_roadmap.is_empty(),true)
	main.autosave_path = "user://coach-route-main-retry-73617.json"
	await panel.apply_roadmap(_route())
	var loaded: Dictionary = Save.load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true)
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("保存失败"),false,"the shell must not keep saying the successful retry was rejected")
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("已保存"),true)
	main.free()

func _panel(career):
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.setup(career,Catalog.load_catalog())
	return panel

func _route():
	return Roadmap.create("fast",[{"age":14,"rotations":3,"count":5}],["flip","lutz"],"","aggressive").roadmap

func entry_preview() -> void:
	var c = F.starting(73611)
	var plan: Dictionary = c.last_generated_plan.duplicate(true)
	var policy: Dictionary = c.last_training_policy.duplicate(true)
	var memory: Dictionary = c.coach_training_state.duplicate(true)
	var before_clock: Dictionary = c.clock.to_dict()
	var panel = _panel(c)
	# Existing lazy world/invitation initialization is not a training outcome.
	T.assert_equal(c.last_generated_plan,plan,"looking cannot publish a training plan as agreed")
	T.assert_equal(c.last_training_policy,policy,"looking cannot silently choose a policy")
	T.assert_equal(c.coach_training_state,memory)
	T.assert_equal(c.clock.to_dict(),before_clock)
	panel.free()

func route_confirmation() -> void:
	var c = F.triple_gap(73612)
	var profile: Dictionary = load("res://src/content/club_coach_repository.gd").new().coach_profile("coach_zhao")
	c.coach_assignment.coach_id = str(profile.id)
	c.coach_assignment.club_id = str(profile.club_id)
	c.coach_assignment.technical_tendencies = profile.technical_tendencies.duplicate(true)
	c.coach_assignment.known_strengths.assign(profile.known_strengths)
	c.coach_assignment.known_concerns.assign(profile.known_concerns)
	var panel = _panel(c)
	var saved: Array = []
	panel.persist = func(candidate):
		saved.append(candidate.development_roadmap.duplicate(true))
		return Save.save(candidate,"user://coaching-route-confirmed-73612.json")
	var before: String = panel.find_child("CoachProposalSummary",true,false).text
	await panel.apply_roadmap(_route())
	T.assert_equal(saved.size(),1,"route confirmation must reach the real persistence boundary")
	T.assert_equal(panel.get_node("%AuthorityConfirmation").visible,false,"ordinary route confirmation must not manipulate hidden advanced controls")
	T.assert_equal(panel.find_child("CoachProposalSummary",true,false).text != before,true,"the actual next course must refresh")
	T.assert_equal(c.development_roadmap.get("priority_jumps",[]),["flip","lutz"])
	if saved.size() == 1:
		var loaded: Dictionary = Save.load_save("user://coaching-route-confirmed-73612.json")
		T.assert_equal(loaded.ok,true)
		if loaded.ok: T.assert_equal(loaded.career.development_roadmap,c.development_roadmap)
	panel.free()

func route_rollback() -> void:
	var c = F.starting(73613)
	var panel = _panel(c)
	var before: Dictionary = c.to_dict()
	panel.persist = func(_candidate): return {"ok":false,"errors":["injected storage failure"]}
	await panel.apply_roadmap(_route())
	T.assert_equal(c.development_roadmap,before.development_roadmap)
	T.assert_equal(c.roadmap_revision_history,before.roadmap_revision_history)
	T.assert_equal(c.training_period_state,before.training_period_state)
	T.assert_equal(c.coach_training_state,before.coach_training_state)
	T.assert_equal(c.clock.to_dict(),before.clock)
	T.assert_equal(panel.plan_error_label.text.contains("保存失败"),true)
	panel.free()

func route_idempotence() -> void:
	var c = F.starting(73614)
	var panel = _panel(c)
	await panel.apply_roadmap(_route())
	var history_size: int = c.roadmap_revision_history.size()
	await panel.apply_roadmap(_route())
	T.assert_equal(c.roadmap_revision_history.size(),history_size,"reopening and confirming unchanged route cannot duplicate its receipt")
	panel.free()

func partial_agreement() -> void:
	var c = F.triple_gap(73615)
	var plan = Coach.build(c,Intent.create("accept").intent).plan
	plan.coach_decision = {}
	for id in plan._jump_rotations: plan._jump_rotations[id] = 1
	c.training_period_state = {"weeks_elapsed":3,"intent":Intent.create("accept").intent.to_dict(),"plan":plan.to_dict(),"started_clock":c.clock.to_dict()}
	var panel = _panel(c)
	var agreement: Dictionary = c.training_period_state.duplicate(true)
	await panel.apply_roadmap(_route())
	T.assert_equal(c.training_period_state,agreement,"route preferences cannot rewrite already executed training")
	panel._show_coach_courses()
	var body: String = panel.get_node("CoachCourseDialog").find_child("GuideBody",true,false).text
	T.assert_equal(body.contains("教练发现"),false,"old single-rotation agreement must not inherit a fresh triple-gap promise")
	T.assert_equal(body.contains("原有"),true)
	panel.free()

func actual_follow_coach() -> void:
	var c = F.starting(73616)
	var panel = _panel(c)
	panel.persist = func(candidate): return Save.save(candidate,"user://coaching-route-actual-73616.json")
	await panel.apply_roadmap(_route())
	var modal: bool = panel.get_node("%AuthorityConfirmation").visible
	T.assert_equal(modal,false,"automatic course must be reachable without legacy confirmation")
	if modal:
		panel.free()
		return
	var history_start: int = c.history.size()
	await panel.continue_training()
	var attempted := {}
	for row in c.history.slice(history_start):
		if row.get("category") == "jump_attempt_batch": attempted[row.jump_id] = int(attempted.get(row.jump_id,0))+int(row.attempts)
	for id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		T.assert_equal(int(attempted.get(id,0))>0,true,"daily entry must execute "+id)
	T.assert_equal(int(attempted.get("flip",0))>int(attempted.get("loop",0)),true)
	T.assert_equal(int(attempted.get("lutz",0))>int(attempted.get("loop",0)),true)
	T.assert_equal(c.clock.to_dict(),{"year":2014,"quarter":2},panel.plan_error_label.text)
	panel.free()
