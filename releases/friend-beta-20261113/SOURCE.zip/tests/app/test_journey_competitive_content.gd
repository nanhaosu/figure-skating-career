extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"public journey begins training flip and lutz rather than omitting them", "callable":training_coverage},
		{"name":"competitive training keeps a sustainable recovery budget", "callable":sustainable_allocations},
		{"name":"coach distinguishes emerging competition triples from newly unlocked triples", "callable":competition_readiness_band},
		{"name":"new-star short program uses a triple-triple only after the second jump is ready", "callable":planned_short_combo},
		{"name":"journey records triple-triple as an explicit player programme choice", "callable":explicit_combo_choice},
		{"name":"resumed journey recognizes persisted preseason programme choices", "callable":persisted_preseason_choice},
		{"name":"planned free program reserves triples for competition ready jumps", "callable":planned},
		{"name":"steady free program actively upgrades all mastered jumps", "callable":steady},
		{"name":"preseason upgrade preserves programme identity order and unchanged familiarity", "callable":preseason}]

func training_coverage() -> void:
	var catalog: Dictionary = load("res://src/content/catalog_repository.gd").load_catalog()
	var c = load("res://src/simulation/career_factory.gd").create("林澄",2006,"entry_club_trial","family_ambitious",41046,catalog,4).career
	var d = load("res://scripts/international_season_journey.gd").new()
	d._clear_save_family("user://coverage-auto.json"); d._clear_save_family("user://coverage.json")
	d.main = load("res://src/app/main.tscn").instantiate()
	d.main.autosave_path = "user://coverage-auto.json"; d.main.save_path = "user://coverage.json"
	Engine.get_main_loop().root.add_child(d.main); d._adopt(c)
	var rotation_before: float = d.main.active_career.athlete.technique.rotation
	await d._train_quarter()
	T.assert_equal(d.errors,[])
	for id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		T.assert_equal(d.main.active_career.athlete.jumps[id].attempt_evidence.single.attempts > 0,true,"public training must include "+id)
	T.assert_equal(d.main.active_career.athlete.technique.rotation > rotation_before,true,"balanced development must not omit spin technique")
	d.main.free()

func sustainable_allocations() -> void:
	var d = load("res://scripts/international_season_journey.gd").new()
	var catalog: Dictionary = load("res://src/content/catalog_repository.gd").load_catalog()
	var career = load("res://src/simulation/career_factory.gd").create("林澄",2006,"entry_club_trial","family_ambitious",41046,catalog,4).career
	career.athlete.jumps.axel.proficiency.double = 80.0
	var allocations: Dictionary = d._competitive_allocations(career)
	var total := 0
	for value in allocations.values():
		total += int(value)
		T.assert_equal(int(value) % 5,0,"the public plan must fit the five-percent controls without silent rounding")
	T.assert_equal(total,100,"the quarterly plan must use the complete budget")
	T.assert_equal(int(allocations.get("rest",0)) >= 25,true,"an adolescent competition plan must reserve meaningful recovery")
	T.assert_equal(int(allocations.get("rotation",0)) > 0,true,"spin technique must remain in the plan")
	T.assert_equal(int(allocations.get("program_short",0)) > 0 and int(allocations.get("program_free",0)) > 0,true,"both programmes need whole-run rehearsal")
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		T.assert_equal(int(allocations.get("jump_"+id,0)) > 0,true,"all jump families need supervised practice: "+id)
	T.assert_equal(int(allocations.jump_axel),0,"a stable 2A should be maintained through shared foundations instead of triggering a preventable load conflict")
	T.assert_equal(["toe_loop","salchow","loop","flip","lutz","axel"].reduce(func(total,id): return total + int(allocations.get("jump_"+id,0)),0),35,"the normal plan must remain below the ordinary guardian intervention threshold")
	T.assert_equal(int(allocations.jump_toe_loop) > int(allocations.jump_flip),true,"the newcomer plan must consolidate the short-program combination before polishing every edge triple equally")
	T.assert_equal(int(allocations.jump_loop) > int(allocations.jump_lutz),true,"the season's required solo jump must receive a deliberate reliability focus")
	career.athlete.jumps.axel.proficiency.double = 20.0
	var early: Dictionary = d._competitive_allocations(career)
	T.assert_equal(int(early.jump_axel),5,"2A must keep direct training before it is stable")
	T.assert_equal(int(early.jump_flip),0,"the compressed early plan should pause one secondary triple rather than exceed the safe total load")
	career.athlete.jumps.axel.proficiency.double = 80.0
	var action := {"kind":"jump","parts":[{"jump_id":"axel","rotations":2}]}
	var item: Dictionary = load("res://src/domain/technical_repertoire.gd").entry(action)
	item.state = "unavailable"
	item.learned_history.ever_learned = true
	career.technical_repertoire.entries["2A"] = item
	T.assert_equal(int(d._competitive_allocations(career).jump_axel),5,"a recovered high proficiency 2A still needs actual revalidation")

func competition_readiness_band() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var career = state.main.active_career
	career.athlete.jumps.lutz.unlocked_rotations = 3
	career.athlete.jumps.lutz.proficiency.triple = 25.0
	career.athlete.jumps.lutz.consistency.official = 25.0
	career.athlete.jumps.lutz.attempt_evidence.triple.attempts = 80
	career.athlete.jumps.lutz.attempt_evidence.triple.successes = 20
	career.athlete.jumps.flip.unlocked_rotations = 3
	career.athlete.jumps.flip.proficiency.triple = 30.0
	career.athlete.jumps.flip.consistency.official = 28.0
	var d = load("res://scripts/international_season_journey.gd").new()
	T.assert_equal(d._competition_rotation(career,"lutz",3),3,"an emerging but evidenced triple should be available as a calculated risk")
	T.assert_equal(d._competition_rotation(career,"flip",3),2,"a high-looking training number without attempt evidence must not make a triple competition-ready")
	state.main.free()

func planned() -> void: _programme(true)
func steady() -> void: _programme(false)

func planned_short_combo() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var c = state.main.active_career
	for profile in c.athlete.jumps.values():
		profile.unlocked_rotations = 3
		profile.proficiency.triple = 25.0
		profile.consistency.official = 25.0
		profile.attempt_evidence.triple = {"attempts":80,"successes":20,"clean_successes":5}
		profile.proficiency.double = 60.0
		profile.attempt_evidence.double = {"attempts":80,"successes":50,"clean_successes":30}
	var toe = c.athlete.jumps.toe_loop
	toe.proficiency.triple = 55.0; toe.consistency.official = 45.0
	toe.attempt_evidence.triple.attempts = 120; toe.attempt_evidence.triple.successes = 40
	var d = load("res://scripts/international_season_journey.gd").new(); d.main = state.main; d.assigned_route = true
	d._edit_program("short",load("res://src/content/internal_event_rules.gd").for_season(2019,"junior","short"),true)
	T.assert_equal(d.errors,[],"the cautious draft must actually be legal before checking its combination")
	var jumps: Array = c.active_programs.short.elements.filter(func(e): return e.kind == "jump")
	T.assert_equal(jumps.any(func(e): return int(e.rotations) == 3 and e.combination_parts.any(func(part): return part.jump_id == "toe_loop" and int(part.rotations) == 3)),false,"a coach draft must not silently choose a high-risk triple-triple for the player")
	state.main.free()

func explicit_combo_choice() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var c = state.main.active_career
	for profile in c.athlete.jumps.values():
		profile.unlocked_rotations = 3
		profile.proficiency.triple = 25.0
		profile.consistency.official = 25.0
		profile.attempt_evidence.triple = {"attempts":80,"successes":20,"clean_successes":5}
		profile.proficiency.double = 60.0
		profile.attempt_evidence.double = {"attempts":80,"successes":50,"clean_successes":30}
	var d = load("res://scripts/international_season_journey.gd").new(); d.main = state.main; d.assigned_route = true
	d._edit_program("short",load("res://src/content/internal_event_rules.gd").for_season(2019,"junior","short"),true)
	T.assert_equal(d.errors,[],"the player must start from a successfully committed legal draft")
	var before: Dictionary = c.active_programs.short
	T.assert_equal(before.elements.any(func(e): return e.combination_parts.any(func(part): return int(part.rotations) == 3)),false)
	var toe = c.athlete.jumps.toe_loop
	toe.proficiency.triple = 55.0; toe.consistency.official = 45.0
	toe.attempt_evidence.triple.attempts = 120; toe.attempt_evidence.triple.successes = 40
	T.assert_equal(d._apply_player_combo_choice("short",load("res://src/content/internal_event_rules.gd").for_season(2019,"junior","short")),true,"player combo choice failed: %s" % JSON.stringify(d.errors))
	T.assert_equal(c.active_programs.short.elements.any(func(e): return e.combination_parts.any(func(part): return int(part.rotations) == 3)),true)
	T.assert_equal(d.trace.has("program:player_combo_choice:2019:short"),true)
	state.main.free()

func persisted_preseason_choice() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var c = state.main.active_career
	for profile in c.athlete.jumps.values():
		profile.unlocked_rotations = 3
		profile.proficiency.triple = 60.0
		profile.consistency.official = 50.0
		profile.attempt_evidence.triple.attempts = 120
		profile.attempt_evidence.triple.successes = 40
		profile.attempt_evidence.triple.clean_successes = 5
		profile.proficiency.double = 60.0
		profile.attempt_evidence.double = {"attempts":80,"successes":50,"clean_successes":30}
	var d = load("res://scripts/international_season_journey.gd").new(); d.main = state.main; d.assigned_route = true
	for segment in ["short","free"]:
		var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(2019,"junior",segment)
		d._edit_program(segment,rules,true)
		T.assert_equal(d.errors,[],"preseason programme must be legally committed: "+segment)
		T.assert_equal(d._apply_player_combo_choice(segment,rules),true,"player choice must be committed: "+segment)
	T.assert_equal(d._season_content_already_prepared(c,2019),true,"a checkpoint must not revise the same preseason programmes again")
	state.main.free()

func _programme(assigned: bool) -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	for profile in state.main.active_career.athlete.jumps.values():
		profile.unlocked_rotations = 3
		profile.proficiency.triple = 25.0
		profile.consistency.official = 25.0
	state.main.active_career.athlete.jumps.toe_loop.proficiency.triple = 55.0
	state.main.active_career.athlete.jumps.toe_loop.consistency.official = 45.0
	state.main.active_career.athlete.technique.rotation = 35.0
	var d = load("res://scripts/international_season_journey.gd").new(); d.main = state.main; d.assigned_route = assigned
	d._edit_program("free",load("res://src/content/internal_event_rules.gd").for_season(2019,"junior","free"),true)
	T.assert_equal(d.errors,[])
	var p: Dictionary = state.main.active_career.active_programs.free
	T.assert_equal(p.elements.any(func(e): return e.kind == "jump" and ((e.jump_id == "toe_loop" and e.rotations == 3) or e.combination_parts.any(func(part): return part.jump_id == "toe_loop" and int(part.rotations) == 3))),true,"competition-ready triple must be represented")
	for id in ["salchow","loop","flip","lutz"]:
		T.assert_equal(p.elements.any(func(e): return e.kind == "jump" and e.jump_id == id and e.rotations == 3),false,"newly unlocked triple must not be forced into the programme: "+id)
	T.assert_equal(p.elements.any(func(e): return e.jump_id == "axel" and e.rotations == 2),true)
	T.assert_equal(p.elements.filter(func(e): return e.kind == "jump" and not e.combination_parts.is_empty()).size(),3,"a competitive junior free skate should use all three available combination groups")
	for element in p.elements:
		if element.kind == "spin": T.assert_equal(element.target_level <= 2,true,"target spin level must reflect current rotation technique")
	T.assert_equal(p.route_complexity,"standard" if assigned else "simple")
	state.main.free()

func preseason() -> void:
	var state: Dictionary = load("res://tests/app/test_annual_program_adjustment.gd").new().setup()
	var c = state.main.active_career
	for profile in c.athlete.jumps.values(): profile.unlocked_rotations = 2
	var d = load("res://scripts/international_season_journey.gd").new(); d.main = state.main; d.assigned_route = false
	d._edit_program("free",load("res://src/content/internal_event_rules.gd").for_season(2018,"junior","free"),true)
	for profile in c.athlete.jumps.values(): profile.unlocked_rotations = 3
	c.clock.year = 2018; c.clock.quarter = 1
	var before: Dictionary = c.active_programs.free.duplicate(true)
	before.whole_run_familiarity = 80.0
	for id in before.slot_familiarity: before.slot_familiarity[id] = 80.0
	c.active_programs.free = before.duplicate(true)
	await d._train_quarter()
	T.assert_equal(d.errors,[])
	var after: Dictionary = state.main.active_career.active_programs.free
	T.assert_equal(after.program_id,before.program_id)
	T.assert_equal(after.elements.map(func(e): return e.element_id),before.elements.map(func(e): return e.element_id))
	for e in after.elements:
		if e.kind == "jump" and e.jump_id != "axel":
			T.assert_equal(e.rotations,3)
			T.assert_equal(after.slot_familiarity[e.element_id] < 20,true)
		elif e.kind == "spin": T.assert_equal(after.slot_familiarity[e.element_id] >= 80,true)
	T.assert_equal(after.whole_run_familiarity >= 64 and after.whole_run_familiarity < 90,true,"a revised programme loses some polish but months of rehearsal can restore most of the run")
	state.main.free()
