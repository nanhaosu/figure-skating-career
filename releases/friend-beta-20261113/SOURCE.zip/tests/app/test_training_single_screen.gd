extends RefCounted
const T = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const ThemeFactory = preload("res://src/app/theme_factory.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"optional coaching details return without changing progress","callable":test_coach_details},{"name":"all coach responses fit without scrolling at compact viewport","callable":test_responses}, {"name":"long Chinese result paragraphs wrap instead of clipping","callable":test_result_wrap}, {"name":"training summary stays within compact career shell","callable":test_shell_result}]

func test_coach_details() -> void:
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = Fixtures.starting_career(73504)
	panel.setup(career,Catalog.load_catalog())
	T.assert_equal(panel.get_node("%AuthorityConfirmation").visible,false,"opening coach training must not ask approval for hidden legacy controls")
	var before := JSON.stringify(career.to_dict())
	var button = panel.find_child("CoachCourseDetails",true,false)
	T.assert_equal(button != null,true)
	if button == null: panel.free(); return
	button.pressed.emit()
	await Engine.get_main_loop().process_frame
	var dialog = panel.get_node("CoachCourseDialog")
	T.assert_equal(dialog.visible,true)
	dialog.close_button.pressed.emit()
	T.assert_equal(dialog.visible,false)
	T.assert_equal(JSON.stringify(career.to_dict()),before)
	panel.free()

func test_shell_result() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	main.size = Vector2(960,540)
	main.active_career = Fixtures.starting_career(3110)
	var panel = main.get_node("%SummaryPanel")
	panel.present_training_period(main.active_career,{"career":main.active_career,"before":main.active_career,"stop_reason":"quarter_complete","facts":[]})
	main._show_screen(panel)
	await Engine.get_main_loop().process_frame
	await Engine.get_main_loop().process_frame
	T.assert_equal(Rect2(Vector2.ZERO,Vector2(960,540)).encloses(panel.get_node("%NextButton").get_global_rect()),true,"summary's main action must fit alongside persistent sidebar: %s" % panel.get_node("%NextButton").get_global_rect())
	main.free()

func test_result_wrap() -> void:
	var panel = load("res://src/app/summary_panel.tscn").instantiate()
	panel.theme = ThemeFactory.create()
	Engine.get_main_loop().root.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.size = Vector2(960,540)
	var label: Label = panel.get_node("%Breakthroughs")
	label.text = "• 教练安排覆盖滑行、六类跳跃、旋转、体能和恢复；本期不是只推进一个动作。"
	await Engine.get_main_loop().process_frame
	await Engine.get_main_loop().process_frame
	T.assert_equal(label.get_line_count()>1,true,"long Chinese paragraphs must wrap inside their card")
	T.assert_equal(label.get_global_rect().size.x<=panel.get_node("%StoryCards").size.x/2,true,"result labels must stay in their column")
	panel.free()
func test_responses() -> void:
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	panel.theme = ThemeFactory.create()
	Engine.get_main_loop().root.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.size = Vector2(760,480)
	panel.setup(Fixtures.starting_career(3110),Catalog.load_catalog())
	await Engine.get_main_loop().process_frame
	await Engine.get_main_loop().process_frame
	var scroll: Control = panel.find_child("PlanScroll",true,false)
	var responses: Control = panel.find_child("TrainingIntentResponses",true,false)
	T.assert_equal(scroll.get_global_rect().encloses(responses.get_global_rect()),true,"coach responses must be visible without scrolling: viewport=%s responses=%s panel=%s" % [scroll.get_global_rect(),responses.get_global_rect(),panel.size])
	panel.free()
