extends SceneTree

func _initialize() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960, 540)
	root.add_child(viewport)
	var panel = load("res://src/app/program_editor_panel.tscn").instantiate()
	viewport.add_child(panel)
	await process_frame
	for name in ["CloseButton", "SaveButton", "LockButton"]:
		var button: Button = panel.get_node("%" + name)
		if button.get_global_rect().end.y > 540.0:
			push_error("%s is outside 960x540" % name)
			quit(1)
			return
	quit(0)
