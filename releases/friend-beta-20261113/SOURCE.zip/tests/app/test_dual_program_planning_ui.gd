extends RefCounted
const T = preload("res://tests/test_support.gd")
const Fixture = preload("res://tests/integration/test_dual_level_programs.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"transition UI edits two groups separately and commits both with one save", "callable":edit_and_confirm},
		{"name":"changing group proposes legal layout without changing live career before confirmation", "callable":propose_and_cancel},
	]

func _main():
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	var fixture = Fixture.new()
	main.active_career = fixture._career()
	fixture._ready(main.active_career)
	main.autosave_path = "user://planning-both-ui.json"
	main._present_season_planning("2021-22")
	return main

func edit_and_confirm() -> void:
	var main = _main()
	var selector = main._decision_dialog.find_child("ProgramLevelChoice",true,false)
	T.assert_equal(selector != null,true)
	if selector == null: main.free(); return
	var junior := JSON.stringify(main.active_career.active_programs)
	selector.item_selected.emit(1)
	T.assert_equal(main._season_planning_draft.get("editing_level"),"senior")
	var button = main._decision_dialog.find_child("SeasonEditFree",true,false)
	T.assert_equal(button != null,true)
	if button == null: main.free(); return
	button.pressed.emit()
	var program: Dictionary = main.active_career.season_program_plan.programs_by_level.senior.free.duplicate(true)
	program.music = {"title":"成年专用音乐"}
	await main._on_program_saved("free",program)
	T.assert_equal(JSON.stringify(main.active_career.active_programs),junior)
	T.assert_equal(main._season_planning_draft.programs_by_level.senior.free.music.title,"成年专用音乐")
	await main._confirm_season_planning()
	var loaded := Save.load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true,str(loaded.errors))
	if loaded.ok:
		T.assert_equal(JSON.parse_string(JSON.stringify(loaded.career.active_programs)),JSON.parse_string(junior),"JSON integral number representation must not disguise a changed programme")
		T.assert_equal(loaded.career.season_program_plan.programs_by_level.senior.free.music.title,"成年专用音乐")
	main.free()

func propose_and_cancel() -> void:
	var main = _main()
	main._season_planning_draft = {}
	main.active_career.season_program_plan.competitive_level = "junior"
	main.active_career.season_program_plan.programs_by_level.erase("senior")
	var before := JSON.stringify(main.active_career.to_dict())
	main._present_season_planning("2021-22")
	main._decision_dialog.find_child("CompetitiveLevelChoice",true,false).item_selected.emit(2)
	T.assert_equal(main._season_planning_draft.get("programs",{}).get("free",{}).get("elements",[]).size(),12)
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	main._decision_dialog.close_requested.emit()
	T.assert_equal(main._decision_dialog.visible,false)
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),before)
	main.free()
