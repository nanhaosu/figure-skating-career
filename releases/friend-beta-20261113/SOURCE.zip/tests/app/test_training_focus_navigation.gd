extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"reopening season planning refreshes changed training direction before atomic confirmation","callable":test_season_reopen},
		{"name":"focus and external windows fit their themed content without clipping buttons","callable":test_window_fit},
		{"name":"focus editor returns without advancing or saving a draft","callable":test_return},
		{"name":"external training failure preserves money and leaves cancellable window","callable":test_external_failure},
		{"name":"failed focus save keeps career and editor open","callable":test_failed_save}]

func test_season_reopen() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(1774)
	main.autosave_path = "user://season-focus-reopened.json"
	main._present_season_planning("2018-19")
	var direction: Dictionary = main.active_career.training_direction.duplicate(true)
	direction.focuses = [{"id":"expression","kind":"musical_expression","target":{}}]
	var changed: Dictionary = load("res://src/simulation/career_command_service.gd").apply(main.active_career,{"type":"set_training_direction","direction":direction,"receipt_id":"season-reopen-direction"})
	T.assert_equal(changed.ok,true,str(changed.get("error","")))
	if not changed.ok: main.free();return
	main.active_career = changed.career
	var before := JSON.stringify(main.active_career.to_dict())
	main._decision_dialog.hide()
	main._present_season_planning("2018-19")
	T.assert_equal(main._season_planning_draft.direction.revision,main.active_career.training_direction.revision,"reopening must actually read the new direction revision")
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),before,"reopening is not a commit")
	await main._confirm_season_planning()
	T.assert_equal(main._decision_dialog.visible,false,"fresh planning must no longer loop on stale direction")
	var read := preload("res://src/persistence/save_repository.gd").load_save(main.autosave_path)
	T.assert_equal(read.ok,true,str(read.errors))
	if read.ok: T.assert_equal(read.career.training_direction.focuses,direction.focuses)
	main.free()

func test_window_fit() -> void:
	var career = F.starting_career(1773)
	career.training_direction.focuses = [{"id":"expression","kind":"musical_expression","target":{}},{"id":"axel","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}}]
	var booked: Dictionary = load("res://src/simulation/career_command_service.gd").apply(career,{"type":"book_external_training","offer_id":"expression_lab","focus_id":"expression","receipt_id":"layout:booked"})
	T.assert_equal(booked.ok,true)
	if booked.ok: career = booked.career
	for scene in ["training_focus_panel","external_training_panel"]:
		var dialog = load("res://src/app/"+scene+".tscn").instantiate()
		dialog.theme = load("res://src/app/theme_factory.gd").create()
		Engine.get_main_loop().root.add_child(dialog)
		dialog.present(career)
		for frame in 4: await Engine.get_main_loop().process_frame
		T.assert_equal(dialog.get_child(0).get_combined_minimum_size().y <= dialog.size.y,true,scene+" content must fit window height")
		dialog.free()

func test_external_failure() -> void:
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var career = F.starting_career(1772)
	career.training_direction.focuses = [{"id":"expression","kind":"musical_expression","target":{}}]
	panel.setup(career,load("res://src/content/catalog_repository.gd").load_catalog())
	panel.persist = func(_candidate): return false
	panel.open_external_training()
	var money := float(career.athlete.resources.money)
	await panel._on_external_training_requested({"type":"book_external_training","offer_id":"expression_lab","focus_id":"expression","receipt_id":"ui:external:test"})
	T.assert_equal(float(career.athlete.resources.money),money)
	T.assert_equal(career.training_direction.external_schedule,[])
	T.assert_equal(panel.get_node("ExternalTrainingPanel").visible,true)
	panel.get_node("ExternalTrainingPanel").hide()
	panel.free()

func test_return() -> void:
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.setup(F.starting_career(1770),load("res://src/content/catalog_repository.gd").load_catalog())
	T.assert_equal(panel.has_method("open_training_focus"),true)
	if not panel.has_method("open_training_focus"): panel.free(); return
	var before := JSON.stringify(panel.career.to_dict())
	panel.open_training_focus()
	var dialog = panel.get_node("TrainingFocusPanel")
	T.assert_equal(dialog.visible,true)
	dialog.hide()
	T.assert_equal(JSON.stringify(panel.career.to_dict()),before)
	panel.free()

func test_failed_save() -> void:
	var panel = load("res://src/app/quarter_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.setup(F.starting_career(1771),load("res://src/content/catalog_repository.gd").load_catalog())
	if not panel.has_method("open_training_focus"): panel.free(); return
	panel.persist = func(_candidate): return false
	panel.open_training_focus()
	var dialog = panel.get_node("TrainingFocusPanel")
	var direction: Dictionary = panel.career.training_direction.duplicate(true)
	direction.focuses = [{"id":"expression","kind":"musical_expression","target":{}}]
	await panel._on_training_direction_requested(direction)
	T.assert_equal(panel.career.training_direction.focuses,[])
	T.assert_equal(dialog.visible,true)
	panel.free()
