extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Planner = preload("res://src/simulation/competition_route_planner.gd")
const Executor = preload("res://src/simulation/competition_route_executor.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Element = preload("res://src/domain/program_element.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"steady playback reuses prepared action records and replaces them for a new segment", "callable":test_prepared_actions},
		{"name":"broadcast freezes landing and spin without jumping along route", "callable":test_holds},
		{"name":"broadcast timestamps every combo part and step with rules duration", "callable":test_phases},
		{"name":"route geometry responds to choreography transitions familiarity and skating", "callable":test_geometry},
		{"name":"broadcast normal clock uses resolved SP and FS rules", "callable":test_clock},
		{"name":"focus suggestions prioritize rivals and expose complete candidates", "callable":test_focus},
		{"name":"watched replay and playback controls preserve committed archive", "callable":test_replay},
		{"name":"quick mode preserves action holds while compressing travel", "callable":test_quick},
		{"name":"broadcast desktop and narrow bounds contain live rows and controls", "callable":test_layout},
		{"name":"combo route stays in a connected corridor during all parts", "callable":test_combo_corridor},
		{"name":"auto slow triggers on review and can be disabled without changing archive", "callable":test_auto_slow},
		{"name":"real committed NPC replays repeat without resimulation or player advancement", "callable":test_real_archive},
		{"name":"return from rival replay restores the player's paused program", "callable":test_return_player},
		{"name":"slow motion recognizes archived final levels and actual PB evidence", "callable":test_record_cues},
		{"name":"focus recognizes a persistent world record threat", "callable":test_record_focus},
		{"name":"negative committed GOE is red even with a clear technical call", "callable":test_negative_goe},
		{"name":"focus cut relevance obeys the event's resolved free cut", "callable":test_cut_focus},
		{"name":"default focus refreshes with standings but preserves player selections", "callable":test_focus_refresh},
		{"name":"pre-broadcast committed routes gain visual holds without archive mutation", "callable":test_legacy_route},
		{"name":"ready and paused seeks refresh player and NPC broadcast clocks immediately", "callable":test_seek_clock},
		{"name":"returning from NPC replay restores the player's clock and mode label", "callable":test_restore_clock},
		{"name":"playback speed preference survives segment reopen outside committed results", "callable":test_speed_preference_is_separate},
	]

func test_prepared_actions() -> void:
	var panel = _panel()
	var record := _record("short")
	var original := JSON.stringify(record)
	panel.show_segment(record)
	var prepared: Array = panel._live_elements()
	T.assert_equal(prepared[0].abbreviation,"CCoSp3")
	for frame in 20:
		panel._elapsed = float(frame) / 25.0
		panel._refresh_progress()
		panel._slow_candidate("spin")
		T.assert_equal(is_same(panel._live_elements(),prepared),true,"steady playback must not rebuild or deep-copy the prepared records")
	T.assert_equal(JSON.stringify(record),original,"display cache must not mutate committed results")
	var next := _record("free")
	next.technical_review.final_elements[0].abbreviation = "CCoSp4"
	panel.show_segment(next)
	T.assert_equal(panel._live_elements()[0].abbreviation,"CCoSp4","a new program must replace old prepared calls")
	T.assert_equal(prepared[0].abbreviation,"CCoSp3","old prepared records must remain unchanged")
	panel.free()

func test_speed_preference_is_separate() -> void:
	var panel = _panel(); var before := JSON.stringify(panel._session)
	panel.show_segment(_record("short")); panel._set_speed(2.0)
	panel.show_segment(_record("free"))
	T.assert_equal(panel.playback_speed,2.0)
	T.assert_equal(panel.get_node("%Speed2x").button_pressed,true)
	T.assert_equal(JSON.stringify(panel._session),before)
	panel.free()

func _program():
	var combo = Element.create("combo", "jump", "lutz", 2).element
	combo.set_combination_parts([{"jump_id":"toe_loop", "rotations":2}])
	return Program.create("broadcast", "short", [combo, Element.create("spin", "spin").element, Element.create("steps", "step_sequence").element]).program

func _route(duration: float = 160.0) -> Dictionary:
	var athlete = F.starting_career(92).athlete
	var program = _program()
	var plan := Planner.plan(athlete, program, {}, 92)
	return Executor.execute(plan, {"elements":[{"element_id":"combo","kind":"jump","actual":{"fall":true}}, {"element_id":"spin","kind":"spin"}, {"element_id":"steps","kind":"step_sequence"}]}, athlete, {"duration_seconds":duration})

func test_holds() -> void:
	var view = load("res://src/app/competition_ice_view.tscn").instantiate()
	Engine.get_main_loop().root.add_child(view)
	var route := _route()
	view.load_timeline(route, [])
	for phase in route.action_phases:
		if not phase.kind in ["landing_hold", "spin_hold"]: continue
		view.set_progress(lerpf(phase.start, phase.end, 0.2))
		var first: Vector2 = view.skater_position
		view.set_progress(lerpf(phase.start, phase.end, 0.8))
		T.assert_equal(first.distance_to(view.skater_position) < 0.002, true, "hold must stop the marker")
	view.free()

func test_phases() -> void:
	for seconds in [160.0, 210.0]:
		var route := _route(seconds)
		T.assert_equal(route.get("duration_seconds", 0), seconds)
		var end := 0.0
		for phase in route.action_phases:
			T.assert_equal(float(phase.start) >= end - 0.00001, true, "phases cannot overlap")
			T.assert_equal(phase.get("end_seconds", -1.0), phase.end * seconds)
			T.assert_equal(phase.end <= 1.0 and phase.end > phase.start, true)
			end = phase.end
		T.assert_equal(route.action_phases.any(func(p): return p.kind == "takeoff" and p.get("part_index", 0) == 1), true)
		T.assert_equal(route.action_phases.any(func(p): return p.kind == "step_run" and p.end - p.start >= 0.06), true)
		T.assert_equal(route.get("action_anchors", []).all(func(a): return a.has("x") and a.has("y") and a.has("entry_edge")), true)

func test_geometry() -> void:
	var athlete = F.starting_career(92).athlete
	var program = _program()
	var low := Planner.plan(athlete, program, {}, 92)
	program.choreography_quality = 90
	program.whole_run_familiarity = 90
	program.elements[0].entry_difficulty = 0.9
	var high := Planner.plan(athlete, program, {}, 92)
	T.assert_equal(low.points != high.points, true)
	T.assert_equal(float(high.complexity_assessment.get("effective", 0)) > float(low.complexity_assessment.get("effective", 0)), true)
	var tired := Planner.plan(athlete, program, {"starting_fatigue":90.0}, 92)
	T.assert_equal(float(tired.complexity_assessment.get("effective", 0)) < float(high.complexity_assessment.get("effective", 0)), true)
	program.elements[0].ice_anchor = {"x":0.2,"y":0.8}
	var anchored := Planner.plan(athlete, program, {}, 92)
	T.assert_equal(anchored.points != high.points, true)
	T.assert_equal(anchored.action_anchors[0].get("x", -1), 0.2)

func _record(segment: String = "short") -> Dictionary:
	return {"segment":segment, "performance":{"elements":[{"element_id":"spin","kind":"spin","abbreviation":"CCoSp","base_value":2.0,"live_goe":0.1,"status":"review"}]}, "technical_review":{"final_elements":[{"element_id":"spin","abbreviation":"CCoSp3","base_value":3.0,"status":"error","call_confidence":"review"}]}, "protocol":{"element_scores":[{"element_id":"spin","goe":-0.3,"total":2.7}]}, "route_execution":_route(160.0 if segment == "short" else 210.0)}

func _session() -> Dictionary:
	var roster: Array = [{"athlete_id":"player","name":"林晓","is_player":true,"federation":"CHN"}]
	var records := {"player":_record()}
	for i in 10:
		var id := "npc-%d" % i
		roster.append({"athlete_id":id,"name":"陈晨%d" % i,"federation":"JPN"})
		records[id] = _record()
	return {"roster":roster, "resolved_rules":{"short":{"segment_rules":{"duration_seconds":160}},"free":{"segment_rules":{"duration_seconds":210}}}, "short_results":records,"free_results":records.duplicate(true),"archive":{"short_results":records.duplicate(true),"free_results":records.duplicate(true)}}

func _panel():
	var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present_session(_session())
	return panel

func test_clock() -> void:
	var panel = _panel()
	for segment in ["short","free"]:
		panel.show_segment(_record(segment))
		panel._start_playback()
		panel._process(10.0)
		var expected := 10.0 / (160.0 if segment == "short" else 210.0)
		T.assert_equal(is_equal_approx(panel._elapsed, expected), true, "normal playback must follow rules duration")
		panel._toggle_playback()
		panel._process(20.0)
		T.assert_equal(is_equal_approx(panel._elapsed, expected), true)
	panel.free()

func test_focus() -> void:
	var path := "res://src/simulation/focus_skater_service.gd"
	T.assert_equal(ResourceLoader.exists(path), true, "focus service missing")
	if not ResourceLoader.exists(path): return
	var service = load(path)
	var career = F.starting_career(92)
	career.social_state.rival_ids = ["npc-9"]
	var session := _session()
	var ids: Array = service.select(session, career)
	T.assert_equal(ids.size() >= 3 and ids.size() <= 5, true)
	T.assert_equal(ids.has("npc-9"), true)
	T.assert_equal(ids.has("player"), false)
	T.assert_equal(ids, service.select(session, career))

func test_replay() -> void:
	var panel = _panel()
	T.assert_equal(panel.has_method("show_replay"), true, "archive replay entry missing")
	if not panel.has_method("show_replay"): panel.free(); return
	var before := JSON.stringify(panel._session)
	var completions: Array = []
	panel.playback_completed.connect(func(segment): completions.append(segment))
	panel.show_roster()
	T.assert_equal(panel.get_node("%RosterList").get_child_count(), 11)
	T.assert_equal(panel.show_replay("npc-9", "short"), false, "unfocused field must not animate")
	panel.set_focus_skater("npc-9", true)
	T.assert_equal(panel.show_replay("npc-9", "short"), true)
	panel._start_playback()
	panel._set_speed(2.0)
	panel._next_action()
	panel._skip_result()
	T.assert_equal(panel.playback_state, "awaiting_acknowledgment")
	T.assert_equal(completions, [], "NPC replay must wait without advancing player competition")
	T.assert_equal(before, JSON.stringify(panel._session), "replay before acknowledgment must preserve archive")
	panel.get_node("%KissAndCryPanel").continue_requested.emit()
	T.assert_equal(panel.playback_state, "complete")
	T.assert_equal(completions, [], "NPC replay must not advance player competition")
	T.assert_equal(before, JSON.stringify(panel._session))
	T.assert_equal(panel.get_node("%TechnicalPanel")._records.spin.abbreviation, "CCoSp3")
	T.assert_equal(panel.get_node("%TechnicalPanel")._records.spin.live_goe, -0.3)
	T.assert_equal(panel.show_replay("npc-9", "short"), true)
	T.assert_equal(panel._segment_record.protocol.element_scores[0].total, 2.7)
	panel.free()

func test_quick() -> void:
	var panel = _panel()
	T.assert_equal(panel.has_method("set_playback_mode"), true)
	if not panel.has_method("set_playback_mode"): panel.free(); return
	panel.show_segment(_record())
	panel.set_playback_mode("quick")
	panel.auto_slow_enabled = false
	panel._start_playback()
	var seconds := 0.0
	while panel.playback_state == "playing" and seconds < 160.0:
		panel._process(0.1)
		seconds += 0.1
	T.assert_equal(absf(seconds - 67.2) < 0.3, true, "quick clock should take 42 percent of SP")
	T.assert_equal(panel._session, _session())
	panel.free()

func _sort(node: Node) -> void:
	if node is Container: node.notification(Container.NOTIFICATION_SORT_CHILDREN)
	for child in node.get_children(): _sort(child)

func test_layout() -> void:
	# Container minimum-size invalidation runs on deferred frames, not manual sort notifications.
	var output: Array = []
	var code := OS.execute(OS.get_executable_path(),["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/app/broadcast_layout_probe.gd"],output,true)
	T.assert_equal(code,0,"layout probe: %s" % "".join(output))

func test_combo_corridor() -> void:
	var athlete = F.starting_career(92).athlete
	for seed_value in 20:
		var plan := Planner.plan(athlete,_program(),{},seed_value)
		var route := Executor.execute(plan,{"elements":[{"element_id":"combo","kind":"jump"}]},athlete,{})
		var a: Dictionary = route.action_anchors[0]
		var b: Dictionary = route.action_anchors[1]
		T.assert_equal(Vector2(a.x,a.y).distance_to(Vector2(b.x,b.y)) < 0.1,true,"combo anchors stay connected")
		for point in route.points:
			if point.progress >= a.progress and point.progress <= b.progress:
				T.assert_equal(Vector2(point.x,point.y).distance_to(Vector2(a.x,a.y)) < 0.1,true,"combo must not travel to another rink lobe")

func test_auto_slow() -> void:
	var panel = _panel()
	panel.show_segment(_record())
	panel._start_playback()
	panel._elapsed = 0.51
	panel._process(1.0)
	T.assert_equal(is_equal_approx(panel._elapsed,0.513125),true)
	panel.auto_slow_enabled = false
	panel._elapsed = 0.51
	panel._process(1.0)
	T.assert_equal(is_equal_approx(panel._elapsed,0.51625),true)
	T.assert_equal(panel._session,_session())
	panel.free()

func test_real_archive() -> void:
	var helper = load("res://tests/simulation/test_event_general_competition.gd").new()
	var event: Dictionary = helper._event("jgp_stage")
	var career = helper._career(event)
	var session: Dictionary = helper._finish(career,event)
	var before := JSON.stringify(career.to_dict())
	var panel = _panel()
	panel.present_session(session,career)
	panel.present_final_archive(session.archive)
	var id: String = panel.focus_skater_ids[0]
	for segment in ["short","free"]:
		for repeat in 2:
			T.assert_equal(panel.show_replay(id,segment),true)
			panel._skip_result()
			T.assert_equal(panel._segment_record.protocol,session.archive[segment+"_results"][id].protocol)
			var prior := {}
			for anchor in panel._segment_record.route_execution.action_anchors:
				if prior.get("element_id","") == anchor.element_id:
					T.assert_equal(Vector2(prior.x,prior.y).distance_to(Vector2(anchor.x,anchor.y)) < 0.12,true,"real combination must remain in local corridor")
				prior = anchor
	T.assert_equal(JSON.stringify(career.to_dict()),before)
	T.assert_equal(panel._archive,session.archive)
	panel.free()

func test_return_player() -> void:
	var panel = _panel()
	panel.show_segment(_record())
	panel._start_playback()
	panel._elapsed = 0.4
	panel._toggle_playback()
	panel.set_focus_skater("npc-9",true)
	panel.show_replay("npc-9","short")
	panel._skip_result()
	panel._return_from_replay()
	T.assert_equal(panel.get_node("%BroadcastView").visible,true)
	T.assert_equal(panel.playback_state,"paused")
	T.assert_equal(panel._elapsed,0.4)
	panel.free()

func test_record_cues() -> void:
	var panel = _panel()
	var record := _record()
	record.performance.elements[0].facts = {"attempted_features":4}
	record.technical_review.final_elements[0].final_level = 1
	record.technical_review.final_elements[0].call_confidence = "clear"
	record.technical_review.final_elements[0].status = "success"
	panel.show_segment(record)
	T.assert_equal(panel._slow_candidate("spin"),true,"read final_level and attempted_features from real schema")
	var career = F.starting_career(92)
	career.record_book = {"all_formal":{"era":{"short":{"pb":50.0,"pb_meta":{"event_id":"old"}}}}}
	panel.present_session(_session(),career)
	record.performance.elements[0].facts.attempted_features = 1
	record.protocol.total = 60.0
	panel.show_segment(record)
	T.assert_equal(panel._slow_candidate("spin"),true,"compare committed total with career PB")
	panel.free()

func test_record_focus() -> void:
	var career = F.starting_career(92)
	career.record_book = {"international":{"era":{"total":{"pb":150.0}}}}
	career.world_athletes["npc-9"] = {"record_book":{"international":{"era":{"total":{"pb":170.0}}}}}
	var service = load("res://src/simulation/focus_skater_service.gd")
	T.assert_equal(service.select(_session(),career).has("npc-9"),true)

func test_negative_goe() -> void:
	var panel = _panel()
	var record := _record()
	record.technical_review.final_elements[0].status = "success"
	record.technical_review.final_elements[0].call_confidence = "clear"
	panel.show_segment(record)
	panel._skip_result()
	T.assert_equal(panel.get_node("%TechnicalPanel")._records.spin.status,"error")
	T.assert_equal(panel.get_node("%CompetitionIceView").action_node_colors.spin,panel.get_node("%CompetitionIceView").ERROR_COLOR)
	panel.free()

func test_cut_focus() -> void:
	var session := _session()
	session.event = {"competition_policy":{"free_cut":0}}
	session.short_standings = []
	for i in 10: session.short_standings.append({"athlete_id":"npc-%d" % i,"rank":i+1 if i<9 else 24})
	var service = load("res://src/simulation/focus_skater_service.gd")
	T.assert_equal(service.select(session).has("npc-9"),false,"JGP has no invented 24th-place cut")
	session.event.competition_policy.free_cut = 24
	T.assert_equal(service.select(session).has("npc-9"),true)

func test_focus_refresh() -> void:
	var panel = _panel()
	var session := _session()
	session.short_standings = [{"athlete_id":"npc-9","rank":1}]
	panel.present_session(session)
	T.assert_equal(panel.focus_skater_ids.has("npc-9"),true)
	panel.set_focus_skater("npc-8",true)
	var chosen: Array = panel.focus_skater_ids.duplicate()
	panel.present_session(_session())
	T.assert_equal(panel.focus_skater_ids,chosen)
	panel.free()

func test_legacy_route() -> void:
	var route := {"points":[{"x":0.1,"y":0.1,"progress":0.0},{"x":0.9,"y":0.9,"progress":1.0}],"action_anchors":[],"action_phases":[{"kind":"spin_hold","element_id":"spin","start":0.4,"end":0.5}]}
	var before := JSON.stringify(route)
	var view = load("res://src/app/competition_ice_view.tscn").instantiate()
	Engine.get_main_loop().root.add_child(view)
	view.load_timeline(route,[])
	view.set_progress(0.42)
	var start: Vector2 = view.skater_position
	view.set_progress(0.48)
	T.assert_equal(start.distance_to(view.skater_position) < 0.001,true)
	T.assert_equal(JSON.stringify(route),before)
	view.free()

func test_seek_clock() -> void:
	for id in ["player","npc-9"]:
		for paused in [false,true]:
			var panel = _panel()
			var before := JSON.stringify(panel._session)
			if id == "player": panel.show_segment(_record("free"))
			else:
				panel.set_focus_skater(id,true)
				panel.show_replay(id,"free")
			if paused:
				panel._start_playback()
				panel._toggle_playback()
			panel._next_action()
			T.assert_equal(panel.get_node("%ClockLabel").text,"0:52 / 3:30  ·  实时时长")
			T.assert_equal(panel.playback_state,"paused" if paused else "ready")
			panel._skip_result()
			T.assert_equal(panel.get_node("%ClockLabel").text,"3:30 / 3:30  ·  实时时长")
			T.assert_equal(JSON.stringify(panel._session),before)
			panel.free()

func test_restore_clock() -> void:
	var panel = _panel()
	panel.show_segment(_record())
	panel._start_playback()
	panel._process(20.0)
	panel._toggle_playback()
	panel.set_focus_skater("npc-9",true)
	panel.show_replay("npc-9","free")
	panel._skip_result()
	panel._return_from_replay()
	T.assert_equal(panel.get_node("%ClockLabel").text,"0:20 / 2:40  ·  实时时长")
	T.assert_equal(panel.playback_state,"paused")
	panel.set_playback_mode("quick")
	T.assert_equal(panel.get_node("%ClockLabel").text,"0:20 / 2:40  ·  快速")
	panel.free()
