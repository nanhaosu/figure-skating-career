extends RefCounted
const T = preload("res://tests/test_support.gd")

class StopGuard extends "res://scripts/international_season_journey.gd":
	func _handle_node(_node: Dictionary, _bundle: Dictionary) -> void:
		errors.append("screen_advanced_past_visible_checkpoint")

func cases() -> Array[Dictionary]:
	return [{"name":"spring screening stops before advancing the Q2 checkpoint","callable":checkpoint},
		{"name":"screening keeps the fixed free order after a genuine short qualification","callable":fixed_free},
		{"name":"final acceptance still makes its concrete public free edit","callable":acceptance_free},
		{"name":"later acceptance events keep the already saved free order","callable":later_acceptance_free}]

func fixed_free() -> void:
	_free(false)

func acceptance_free() -> void:
	_free(true)

func later_acceptance_free() -> void:
	_free(true,true)

func _free(acceptance: bool,already_edited: bool = false) -> void:
	var c = load("res://tests/fixtures.gd").formal_acceptance_career("qualify")
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var event: Dictionary = bundle.calendar.events[0]
	var session: Dictionary = sim.create_session(c,event,c.active_programs,"balanced",8192)
	session = sim.lock_short(c,sim.complete_practice(session,"accept"))
	T.assert_equal(session.status,"free_adjustment")
	if session.status != "free_adjustment": return
	if acceptance:
		# The fixture's domestic session is already known to reach a free skate;
		# mark the matching calendar row international to exercise only the
		# journey driver's timing policy, not international eligibility here.
		bundle = bundle.duplicate(true)
		for row in bundle.calendar.events:
			if row.event_id == event.event_id: row.scope = "international"
	c.competition_state = session
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.check_roundtrips = acceptance
	driver.concrete_free_edit = already_edited
	driver.main = load("res://src/app/main.tscn").instantiate()
	driver.main.save_path = "user://spring-fixed-free.json"
	driver.main.autosave_path = "user://spring-fixed-free-auto.json"
	Engine.get_main_loop().root.add_child(driver.main)
	driver._adopt(c)
	var original_ids: Array = c.active_programs.free.elements.map(func(e): return e.element_id)
	if acceptance and not already_edited:
		var first = original_ids[0]
		original_ids[0] = original_ids[1]
		original_ids[1] = first
	driver._handle_node({"kind":"between_segments","event_id":event.event_id},bundle)
	T.assert_equal(driver.errors,[])
	T.assert_equal(driver.main.active_career.competition_state.status,"complete","screening must still execute the full free skate")
	var saved: Dictionary = driver.main.active_career.competition_state.free_revision.program
	T.assert_equal(saved.elements.map(func(e): return e.element_id),original_ids,"qualifying must not change the frozen plan")
	T.assert_equal(driver.concrete_free_edit,acceptance,"only final acceptance may claim its concrete edit")
	driver.main.free()

func checkpoint() -> void:
	# This tests the stop boundary, not a competitive acceptance athlete.
	var c = load("res://tests/fixtures.gd").starting_career(8194)
	c.clock.year = 2019
	c.clock.quarter = 2
	var driver = StopGuard.new()
	var result := await driver.run(c,true,"spring_ready")
	T.assert_equal(result.errors,[],"screening must never advance into future event nodes")
	T.assert_equal(result.trace,[])
	T.assert_equal(result.career.clock.to_dict(),{"year":2019,"quarter":2})
	T.assert_equal(driver.check_roundtrips,false,"reachability screening must not claim final save acceptance")
