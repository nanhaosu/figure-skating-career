extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramDraftService = preload("res://src/simulation/program_draft_service.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")
const DemoGenerator = preload("res://scripts/create_internal_competition_demo.gd")

const MAIN_SCENE := "res://src/app/main.tscn"
const MAIN_SAVE_PATH := "user://test-main-career.json"
const MAIN_AUTOSAVE_PATH := "user://test-main-autosave.json"
var _isolated_autosaves: Array[String] = []

func cases() -> Array[Dictionary]:
	return [
		{"name":"direct formal launch cannot bypass an existing dated competition window","callable":test_formal_day_window},
		{"name":"acknowledged teaching short score resumes at the pending adjustment", "callable":test_internal_playback_resume.bind(true,true)},
		{"name":"teaching K&C exit and reload preserves the unconfirmed score checkpoint", "callable":test_internal_playback_resume.bind(true)},
		{"name":"teaching score confirmation autosaves before browser refresh without menu exit", "callable":test_internal_playback_resume.bind(true,true,false)},
		{"name":"failed teaching score save retains K&C and allows one durable retry", "callable":test_internal_acknowledgement_retry},
		{"name":"teaching playback exit and reload resumes paused at the saved position", "callable":test_internal_playback_resume.bind(false)},
		{"name":"new career requires consent before replacing an existing autosave", "callable":test_existing_autosave_confirmation},
		{"name": "creation inspection returns to main menu without replacing career", "callable": test_creation_returns_to_menu},
		{"name": "main connects creation quarter and summary screens", "callable": test_main_connects_creation_quarter_and_summary_screens},
		{"name": "fresh career resumes through history handoff goal and home", "callable": test_fresh_career_opening_flow},
		{"name": "main confirms replacing an unsaved career", "callable": test_main_confirms_replacing_an_unsaved_career},
		{"name": "failed load keeps the active career", "callable": test_failed_load_keeps_the_active_career},
		{"name": "save then load restores the saved quarter state", "callable": test_save_then_load_restores_the_saved_quarter_state},
		{"name": "playable panels fit the minimum viewport", "callable": test_playable_panels_fit_the_minimum_viewport},
		{"name": "playable panels reserve the global message footer", "callable": test_playable_panels_reserve_the_global_message_footer},
		{"name": "completed quarter is autosaved and can be resumed", "callable": test_quarter_autosaves_and_resumes},
		{"name": "default training action autosaves and opens factual result", "callable": test_coach_led_training_flow},
		{"name": "first coach led advance stops on the scheduled teaching invitation", "callable": test_first_teaching_invitation_stop},
		{"name": "competition screen is mounted without replacing career flow", "callable": test_competition_screen_is_mounted},
		{"name": "saved competition route resumes without rerolling", "callable": test_saved_route_resume},
		{"name": "acceptance demo programs include combinations", "callable": test_demo_program_combinations},
		{"name": "2018 career opens persistent season overview", "callable": test_2018_career_opens_persistent_season_overview},
		{"name": "season adjustment autosaves and hard gates do not mutate", "callable": test_season_adjustment_autosaves_and_respects_hard_gate},
		{"name": "formal competition mounts and resumes locked roster", "callable": test_formal_competition_resume},
		{"name": "formal event completes from strategy through archive", "callable": test_formal_full_ui_flow},
		{"name": "formal keep and acknowledgment save failures retain progress and retry", "callable": test_formal_full_ui_flow.bind(true)},
		{"name": "cut player sees archive without free adjustment", "callable": test_formal_cut_ui_flow},
		{"name": "new career saves and reloads an incomplete short program draft", "callable": test_new_career_program_editor_flow},
		{"name": "pre-competition program repair can return to season overview", "callable": test_program_repair_can_return_to_season},
		{"name": "launching with an illegal program shows actionable pre-competition repair", "callable": test_launch_shows_actionable_checklist},
		{"name": "missing program can open manual editing from pre-competition checklist", "callable": test_missing_program_opens_manual_editing},
		{"name": "opening and saving a program keeps the current training allocation", "callable": test_program_editor_preserves_training_allocation},
		{"name": "internal competition rejects partial drafts but starts legal programs", "callable": test_internal_competition_legality_from_new_career},
		{"name": "internal competition completes once and stays complete after reload", "callable": test_internal_competition_settles_once},
		{"name": "stale formal entry snapshot cannot bypass missing technical grade", "callable": test_stale_formal_entry_is_rechecked},
		{"name": "summary milestone button advances quiet quarters with autosave", "callable": test_summary_milestone_advance},
	]

func test_formal_day_window() -> void:
	for date in ["2018-09-12","2018-09-16","2018-09-13"]:
		var career := Fixtures.formal_acceptance_career("qualify")
		var event_id := "cn_grand_prix_u_series_2018"
		career.season_state = _confirmed_formal_season(event_id)
		career.competition_timeline.date = date
		career.competition_timeline.mode = "dated"
		career.competition_timeline.origin_date = date
		career.competition_timeline.quarter_progress = {"2018-09-12":74,"2018-09-13":75,"2018-09-16":78}[date]
		TestSupport.assert_equal(load("res://src/domain/competition_timeline.gd").validate(career.competition_timeline,career.clock.to_dict()),"")
		var main = _instantiate_main()
		main.active_career = career
		var before := JSON.stringify(career.to_dict())
		var result: Dictionary = await main.start_formal_competition(event_id)
		print("FORMAL_DAY_GATE ",date," ",result)
		if date == "2018-09-13":
			TestSupport.assert_equal(result.ok,true,"settled training through Sep13 must allow the actual Sep14 check-in without claiming Sep14 ordinary training")
			main.free()
			continue
		TestSupport.assert_equal(result.ok,false,"direct UI launch must not skip days of scheduled training or reopen a past event")
		TestSupport.assert_equal("；".join(Array(result.get("errors",[]))).contains("赛事日期范围"),true,"the direct guard must explain the actual date boundary, not an unrelated failed precondition")
		TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()) == before,true,"a rejected dated launch must leave the career unchanged")
		main.free()

func test_creation_returns_to_menu() -> void:
	var main = _instantiate_main()
	main.active_career = Fixtures.starting_career(91)
	var before := JSON.stringify(main.active_career.to_dict())
	main.get_node("%MainMenuPanel").new_career_requested.emit()
	TestSupport.assert_equal(main.get_node("%CreationScreen").visible, false)
	var skip = main.get_node("CareerDecisionDialog").find_child("SkipSkatingIntro",true,false)
	TestSupport.assert_equal(skip != null,true)
	if skip != null: skip.pressed.emit()
	TestSupport.assert_equal(main.get_node("%CreationScreen").visible, true)
	var back = main.get_node_or_null("%CreationBackButton")
	TestSupport.assert_equal(back != null, true, "new career inspection needs a visible return to main menu")
	if back != null:
		back.pressed.emit()
		TestSupport.assert_equal(main.get_node("%MainMenuPanel").visible, true)
		TestSupport.assert_equal(main.get_node("%CreationScreen").visible, false)
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()), before)
	main.free()

func test_missing_program_opens_manual_editing() -> void:
	var career := Fixtures.formal_acceptance_career("qualify")
	var event_id := str(Fixtures.u_series_event().event_id)
	career.season_state = _confirmed_formal_season(event_id)
	career.active_programs.short = {}
	var main = _instantiate_main()
	main.active_career = career
	main.call("_on_formal_event_launch_requested",event_id)
	var buttons: Array = main.get_node("%SeasonOverviewPanel").get_node("%ChecklistActions").get_children()
	var edit_buttons: Array = buttons.filter(func(button): return button.text.contains("自己调整") and button.text.contains("短节目"))
	TestSupport.assert_equal(edit_buttons.is_empty(),false)
	if not edit_buttons.is_empty(): edit_buttons[0].pressed.emit()
	var editor = main.get_node("%ProgramEditorPanel")
	TestSupport.assert_equal(editor.visible,true)
	TestSupport.assert_equal(editor.program != null,true,"manual edit must open a partial coach draft instead of an empty dead end")
	main.free()

func test_launch_shows_actionable_checklist() -> void:
	var career := Fixtures.formal_acceptance_career("qualify")
	var event_id := str(Fixtures.u_series_event().event_id)
	career.season_state = _confirmed_formal_season(event_id)
	career.active_programs.short.elements[0].combination_parts = [{"jump_id":"flip","rotations":2}]
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	main.active_career = career
	main.call("_on_formal_event_launch_requested",event_id)
	var season_panel = main.get_node("%SeasonOverviewPanel")
	TestSupport.assert_equal(season_panel.get_node("%PreCompetitionDialog").visible,true,"the launch button must show the checklist instead of only returning an invisible error")
	var action_buttons: Array = season_panel.get_node("%ChecklistActions").get_children()
	var repair_buttons: Array = action_buttons.filter(func(button): return button.text.contains("教练") and button.text.contains("短节目"))
	TestSupport.assert_equal(repair_buttons.is_empty(),false)
	if not repair_buttons.is_empty():
		await main._on_pre_competition_action_requested(event_id,"adopt_coach_program","short")
	TestSupport.assert_equal(main.get_node("%ProgramEditorPanel").visible,false)
	TestSupport.assert_equal(main.active_career.active_programs.short.draft_status,"locked")
	TestSupport.assert_equal(main.active_career.competition_state,{})
	TestSupport.assert_equal(SaveRepository.load_save(main.autosave_path).ok,true)
	main.free()

func test_program_repair_can_return_to_season() -> void:
	var career := Fixtures.formal_junior_career(1291)
	var main = _instantiate_main()
	main.active_career = career
	main.call("_present_season_node", {"kind":"program_adjustment","event_id":"cn_grand_prix_u_series_2018","segment":"short","rules":InternalEventRules.for_season(2018,"junior","short")})
	var decision = main.get_node("CareerDecisionDialog")
	TestSupport.assert_equal(decision.visible,true,"inspectable choices precede editing; do not force a player into the editor")
	TestSupport.assert_equal(main.get_node("%ProgramEditorPanel").visible,false)
	decision.find_child("EditProgram",true,false).pressed.emit()
	TestSupport.assert_equal(main.get_node("%ProgramEditorPanel").visible,true)
	main.get_node("%ProgramEditorPanel").get_node("%CloseButton").pressed.emit()
	TestSupport.assert_equal(main.get_node("%SeasonOverviewPanel").visible,true)
	main.free()

func test_summary_milestone_advance() -> void:
	var main = _instantiate_main()
	_use_empty_test_autosave(main)
	main.offer_new_career(Fixtures.starting_career(792))
	_open_primary_action(main)
	var quarter = main.get_node("%QuarterPanel")
	var quiet: Dictionary = {"skating_foundation":20,"jump_toe_loop":0,"jump_salchow":0,"jump_loop":0,"jump_flip":0,"jump_lutz":0,"jump_axel":0,"rotation":10,"conditioning":10,"rest":60,"program_short":0,"program_free":0}
	quarter.set_allocations(quiet)
	quarter.request_advance()
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible, true)
	TestSupport.assert_equal(main.active_career.last_generated_plan.get("shares", {}), quiet)
	var first_clock: Dictionary = main.active_career.clock.to_dict()
	main.get_node("%SummaryPanel").get_node("%AdvanceMilestoneButton").pressed.emit()
	TestSupport.assert_equal(main.active_career.clock.year > int(first_clock.year) or main.active_career.clock.quarter > int(first_clock.quarter), true, main.get_node("%GlobalMessage").text)
	var decision = main.get_node_or_null("CareerDecisionDialog")
	TestSupport.assert_equal(main.get_node("%SummaryPanel").get_node("%ActionMessage").text.contains("已安全推进") or (decision != null and decision.visible), true,"advance stops at an explained key node or inspectable season decision")
	TestSupport.assert_equal(FileAccess.file_exists(MAIN_AUTOSAVE_PATH), true)
	main.free()

func test_stale_formal_entry_is_rechecked() -> void:
	var career := Fixtures.formal_acceptance_career("qualify")
	var event_id := str(Fixtures.u_series_event().event_id)
	career.certification_state.national_technical_grade = 0
	career.season_state = _confirmed_formal_season(event_id)
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	main.active_career = career
	var launch: Dictionary = main.start_formal_competition(event_id)
	TestSupport.assert_equal(launch.ok, false)
	TestSupport.assert_equal(career.competition_state.is_empty(), true)
	main.free()

func test_internal_competition_settles_once() -> void:
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	TestSupport.assert_equal(SaveRepository.save(Fixtures.starting_career(818),MAIN_SAVE_PATH).ok,true)
	var manual_snapshot := FileAccess.get_file_as_string(MAIN_SAVE_PATH)
	var career := Fixtures.starting_career(817)
	career.clock.quarter = 4
	main.offer_new_career(career)
	for jump_id in ["toe_loop", "salchow", "loop"]: career.athlete.jumps[jump_id].unlocked_rotations = 1
	for segment in ["short", "free"]:
		var program = ProgramDraftService.propose(career.athlete, segment, InternalEventRules.for_teaching_group(segment), {}, 817).program
		program.draft_status = "locked"
		program.locked_segments.append(segment)
		career.active_programs[segment] = program.to_dict()
	TestSupport.assert_equal(main.start_internal_competition().ok, true)
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"starting teaching competition cannot overwrite a manual save")
	TestSupport.assert_equal(FileAccess.file_exists(main.autosave_path),true)
	TestSupport.assert_equal(career.competition_state.rivals.map(func(r): return str(r.id)), career.internal_invitation_state.peer_ids)
	main._on_competition_adjustment_selected("keep")
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"teaching free skate adjustment must only autosave")
	TestSupport.assert_equal(str(career.competition_state.get("status", "")), "complete")
	var expected_evidence = career.transaction_copy()
	for segment in ["short","free"]:
		preload("res://src/simulation/repertoire_evidence_service.gd").record_competition(expected_evidence,career.competition_state.get(segment,{}).get("performance",{}),"internal:%s:%d:%d:%s" % [str(career.competition_state.get("event_id","first_internal")),career.clock.year,career.clock.quarter,segment])
	main._on_competition_confirmed()
	TestSupport.assert_equal(career.technical_repertoire == expected_evidence.technical_repertoire,true,"teaching results must record actual competition evidence only at durable settlement")
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"teaching settlement must preserve manual save bytes")
	TestSupport.assert_equal(career.internal_invitation_state.status, "completed")
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible,true,"settled competition must show its factual return before another decision")
	TestSupport.assert_equal(main.get_node("%SummaryPanel").get_node("%NextButton").text,"回到生涯主页")
	TestSupport.assert_equal(career.history.filter(func(entry): return str(entry.get("category", "")) == "internal_competition").size(), 1)
	TestSupport.assert_equal(main.start_internal_competition().ok, false)
	main.save_path = main.autosave_path
	TestSupport.assert_equal(main.load_active_career().ok, true)
	TestSupport.assert_equal(main.active_career.internal_invitation_state.status, "completed")
	TestSupport.assert_equal(main.active_career.history.filter(func(entry): return str(entry.get("category", "")) == "internal_competition").size(), 1)
	TestSupport.assert_equal(main.active_career.technical_repertoire == expected_evidence.technical_repertoire,true)
	main.free()

func test_internal_competition_legality_from_new_career() -> void:
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	var career := Fixtures.starting_career(816)
	career.clock.quarter = 4
	main.offer_new_career(career)
	# This regression needs an intentionally incomplete draft. New V14 careers
	# legitimately arrive with single jumps already learned, so remove them only
	# inside this test before asking the proposal service for the blocked draft.
	for jump in career.athlete.jumps.values(): jump.unlocked_rotations = 0
	for segment in ["short", "free"]:
		career.active_programs[segment] = ProgramDraftService.propose(career.athlete, segment, InternalEventRules.for_teaching_group(segment), {}, 816).program.to_dict()
	var blocked: Dictionary = main.start_internal_competition()
	TestSupport.assert_equal(blocked.ok, false)
	TestSupport.assert_equal(main.active_career.competition_state.is_empty(), true)
	for jump_id in ["toe_loop", "salchow", "loop"]: career.athlete.jumps[jump_id].unlocked_rotations = 1
	for segment in ["short", "free"]:
		var program = ProgramDraftService.propose(career.athlete, segment, InternalEventRules.for_teaching_group(segment), {}, 816).program
		program.draft_status = "locked"
		program.locked_segments.append(segment)
		career.active_programs[segment] = program.to_dict()
	TestSupport.assert_equal(main.start_internal_competition().ok, true)
	TestSupport.assert_equal(main.get_node("%CompetitionPanel").visible, true)
	main.free()

func test_program_editor_preserves_training_allocation() -> void:
	var main = _instantiate_main()
	_use_empty_test_autosave(main)
	main.offer_new_career(Fixtures.starting_career(815))
	var quarter = main.get_node("%QuarterPanel")
	var allocation: Dictionary = quarter._current_allocations()
	allocation.skating_foundation = int(allocation.skating_foundation) - 5
	allocation.rest = int(allocation.rest) + 5
	quarter.set_allocations(allocation)
	main.open_program_editor("short")
	main.get_node("%ProgramEditorPanel").get_node("%SaveButton").pressed.emit()
	TestSupport.assert_equal(quarter._current_allocations(), allocation)
	main.open_program_editor("short")
	main.get_node("%ProgramEditorPanel").get_node("%CloseButton").pressed.emit()
	TestSupport.assert_equal(quarter._current_allocations(), allocation)
	main.free()

func test_new_career_program_editor_flow() -> void:
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	_use_empty_test_autosave(main)
	main.offer_new_career(Fixtures.starting_career(814))
	TestSupport.assert_equal(main.has_method("open_program_editor"), true)
	if not main.has_method("open_program_editor"): main.free(); return
	main.call("open_program_editor", "short")
	var panel = main.get_node_or_null("%ProgramEditorPanel")
	TestSupport.assert_equal(panel != null and panel.visible, true)
	if panel == null: main.free(); return
	panel.get_node("%SaveButton").pressed.emit()
	TestSupport.assert_equal(Dictionary(main.active_career.active_programs.short).is_empty(), false)
	TestSupport.assert_equal(main.get_node("%CareerHomePanel").visible, true,"saving returns to the page that opened the editor")
	# The editor explicitly saves a draft to autosave, not the manual slot left
	# behind by another case. Reload the artifact produced by this action.
	main.save_path = main.autosave_path
	TestSupport.assert_equal(main.load_active_career().ok, true)
	TestSupport.assert_equal(Dictionary(main.active_career.active_programs.short).is_empty(), false)
	main.free()

func test_formal_cut_ui_flow() -> void:
	var career := Fixtures.formal_acceptance_career("cut")
	var event_id := str(Fixtures.u_series_event().event_id)
	career.season_state = _confirmed_formal_season(event_id)
	var main = _instantiate_main(); main.save_path = MAIN_SAVE_PATH; main.active_career = career
	TestSupport.assert_equal(main.start_formal_competition(event_id).ok, true)
	var panel = main.get_node("%FormalCompetitionPanel")
	panel.get_node("%BalancedStrategyButton").pressed.emit()
	if panel.get_node("%PracticeOverlay").visible: panel.get_node("%PracticeChoices").get_child(0).pressed.emit()
	panel.get_node("%SkipResultButton").pressed.emit()
	panel._process(3.0)
	TestSupport.assert_equal(main.active_career.competition_state.player_qualified, false)
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%AdjustmentChoices").is_visible_in_tree(), false)
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible, true,"cut K&C continues directly to saved review")
	TestSupport.assert_equal(main.active_career.competition_state.is_empty(), true)
	main.open_archived_competition(event_id)
	TestSupport.assert_equal(panel.get_node("%StandingsList").get_child_count(), 34)
	panel.get_node("%ArchiveConfirmButton").pressed.emit()
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible, true,"optional rankings return to review")
	main.free()

func _confirmed_formal_season(event_id: String) -> Dictionary:
	return {"season_id":"2018-19","entry_plan":{"season_id":"2018-19","proposal_version":1,"entries":{event_id:{"status":"confirmed","requested_levels":["junior"],"route":"federation_approved_unit","funding_source":"club","coach_recommendation":"建议参赛","player_override":"enter","available_adjustment_ids":["enter","skip"],"eligibility_snapshot":{"eligible":true,"hard_gate_codes":[],"warnings":[]},"reason_codes":["formal_debut"]}}},"qualification_state":{"cfsa_registered":true,"club_final_top_six":false},"event_statuses":{event_id:"confirmed"}}

func test_formal_full_ui_flow(fail_saves: bool = false) -> void:
	var career := Fixtures.formal_acceptance_career("qualify")
	var event_id := str(Fixtures.u_series_event().event_id)
	career.season_state = _confirmed_formal_season(event_id)
	var main = _instantiate_main(); main.save_path = MAIN_SAVE_PATH; main.active_career = career
	TestSupport.assert_equal(SaveRepository.save(Fixtures.starting_career(819),MAIN_SAVE_PATH).ok,true)
	var manual_snapshot := FileAccess.get_file_as_string(MAIN_SAVE_PATH)
	TestSupport.assert_equal(main.start_formal_competition(event_id).ok, true)
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"formal event launch cannot replace a manual save")
	var panel = main.get_node("%FormalCompetitionPanel")
	panel.get_node("%BalancedStrategyButton").pressed.emit()
	if panel.get_node("%PracticeOverlay").visible:
		panel.get_node("%PracticeChoices").get_child(0).pressed.emit()
	TestSupport.assert_equal(panel.get_node("%BroadcastView").visible, true)
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"strategy and practice must only autosave")
	panel.get_node("%SkipResultButton").pressed.emit()
	panel._process(3.0)
	panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(panel.get_node("%StandingsView").visible, true)
	TestSupport.assert_equal(panel.get_node("%AdjustmentChoices").visible, true)
	var short_snapshot := JSON.stringify(main.active_career.competition_state.short_results)
	var original_free: Dictionary = main.active_career.competition_state.roster.filter(func(row): return row.is_player)[0].free_program.duplicate(true)
	# An unrelated draft must never replace the accepted session programme.
	main.active_career.active_programs.free.program_id = "unconfirmed-replacement"
	var durable_path: String = main.autosave_path
	if fail_saves:
		var before_keep := JSON.stringify(main.active_career.to_dict())
		var saved_before_keep := FileAccess.get_file_as_string(durable_path)
		main.autosave_path = "user://missing-formal-keep-%d/autosave.json" % Time.get_ticks_usec()
		await main._on_formal_adjustment_selected("keep")
		TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),before_keep,"failed keep must leave the career unchanged")
		TestSupport.assert_equal(FileAccess.get_file_as_string(durable_path),saved_before_keep)
		TestSupport.assert_equal(main._pending_free_adjustment,"keep","failed keep retains retry intent")
		main.autosave_path = durable_path
	await main._on_formal_adjustment_selected("keep")
	TestSupport.assert_equal(main.get_node("%ProgramEditorPanel").visible, false,"keep bypasses the editor")
	TestSupport.assert_equal(panel.get_node("%BroadcastView").visible, true)
	TestSupport.assert_equal(JSON.stringify(main.active_career.competition_state.short_results),short_snapshot)
	if main.active_career.competition_state.has("free_revision"):
		TestSupport.assert_equal(main.active_career.competition_state.free_revision.program.program_id,original_free.program_id)
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"formal free skate lock must preserve manual save bytes")
	panel.get_node("%SkipResultButton").pressed.emit()
	panel._process(3.0)
	if fail_saves:
		var before_ack := JSON.stringify(main.active_career.to_dict())
		var saved_before_ack := FileAccess.get_file_as_string(durable_path)
		main.autosave_path = "user://missing-formal-ack-%d/autosave.json" % Time.get_ticks_usec()
		panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
		TestSupport.assert_equal(main.get_node("%SummaryPanel").visible,false,"failed acknowledgment cannot show review")
		TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),before_ack)
		TestSupport.assert_equal(FileAccess.get_file_as_string(durable_path),saved_before_ack)
		TestSupport.assert_equal(panel.get_node("%ArchiveConfirmButton").visible,true,"failed final save exposes retry")
		main.autosave_path = durable_path
		await main._on_formal_archive_confirmed()
	else:
		panel.get_node("%KissAndCryPanel").get_node("%ContinueButton").pressed.emit()
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible,true,"final K&C continues directly to review")
	TestSupport.assert_equal(main.active_career.competition_archive.size(), 1)
	var acknowledged_snapshot := JSON.stringify(main.active_career.to_dict())
	await main._on_formal_archive_confirmed()
	TestSupport.assert_equal(JSON.stringify(main.active_career.to_dict()),acknowledged_snapshot,"repeated acknowledgment is a no-op")
	TestSupport.assert_equal(main.active_career.competition_state.is_empty(), true)
	TestSupport.assert_equal(FileAccess.get_file_as_string(MAIN_SAVE_PATH),manual_snapshot,"archive confirmation must preserve manual save bytes")
	var saved := SaveRepository.load_save(main.autosave_path)
	TestSupport.assert_equal(saved.ok,true)
	if saved.ok:
		TestSupport.assert_equal(saved.career.competition_state.is_empty(),true)
		TestSupport.assert_equal(saved.career.competition_archive.size(),1)
	main.free()

func test_formal_competition_resume() -> void:
	var career := Fixtures.formal_acceptance_career("qualify")
	var event := Fixtures.u_series_event(); var event_id := str(event.event_id)
	career.season_state = _confirmed_formal_season(event_id)
	var main = _instantiate_main(); main.save_path = MAIN_SAVE_PATH; main.active_career = career
	var started: Dictionary = main.start_formal_competition(event_id)
	TestSupport.assert_equal(started.ok, true)
	TestSupport.assert_equal(main.get_node("%FormalCompetitionPanel").visible, true)
	var locked_roster: Array = Array(main.active_career.competition_state.roster).duplicate(true)
	main.active_career.competition_state = load("res://src/simulation/formal_competition_simulator.gd").complete_practice(main.active_career.competition_state,"accept")
	TestSupport.assert_equal(str(main.active_career.competition_state.status), "short_ready")
	TestSupport.assert_equal(SaveRepository.save(main.active_career, MAIN_SAVE_PATH).ok, true)
	var resumed = _instantiate_main(); resumed.save_path = MAIN_SAVE_PATH
	TestSupport.assert_equal(resumed.load_active_career().ok, true)
	TestSupport.assert_equal(Array(resumed.active_career.competition_state.roster).map(func(row): return str(row.athlete_id)), locked_roster.map(func(row): return str(row.athlete_id)))
	TestSupport.assert_equal(resumed.get_node("%FormalCompetitionPanel").get_node("%BroadcastView").visible, true, "short_ready resume must return to the player's short-program broadcast")
	TestSupport.assert_equal(resumed.get_node("%FormalCompetitionPanel").get_node("%BroadcastTitle").text.contains("短节目"), true)
	main.free(); resumed.free()

func test_season_adjustment_autosaves_and_respects_hard_gate() -> void:
	var career := Fixtures.starting_career(1820)
	career.clock.year = 2018
	career.clock.quarter = 3
	var main = _instantiate_main()
	_use_empty_test_autosave(main)
	main.offer_new_career(career)
	main._on_season_adjustment_selected("cn_club_league_2018_stage_1", "enter")
	TestSupport.assert_equal(main.active_career.season_state.entry_plan.entries.cn_club_league_2018_stage_1.status, "confirmed")
	TestSupport.assert_equal(FileAccess.file_exists(MAIN_AUTOSAVE_PATH), true)
	var blocked_before: Dictionary = main.active_career.season_state.entry_plan.entries.cn_club_league_2018_final.duplicate(true)
	main._on_season_adjustment_selected("cn_club_league_2018_final", "enter")
	TestSupport.assert_equal(main.active_career.season_state.entry_plan.entries.cn_club_league_2018_final, blocked_before)
	TestSupport.assert_equal(main.get_node("%GlobalMessage").text.contains("不允许"), true, main.get_node("%GlobalMessage").text)
	main.free()

func test_2018_career_opens_persistent_season_overview() -> void:
	var career := Fixtures.starting_career(1819)
	career.clock.year = 2018
	career.clock.quarter = 3
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	main.offer_new_career(career)
	_open_primary_action(main)
	TestSupport.assert_equal(main.get_node_or_null("%SeasonOverviewPanel") != null, true)
	TestSupport.assert_equal(main.get_node("%SeasonOverviewPanel").visible, true)
	var saved_plan: Dictionary = main.active_career.season_state.entry_plan.duplicate(true)
	TestSupport.assert_equal(saved_plan.is_empty(), false)
	TestSupport.assert_equal(main.save_active_career().ok, true)
	main.active_career.season_state.entry_plan = {}
	TestSupport.assert_equal(main.load_active_career().ok, true)
	TestSupport.assert_equal(main.active_career.season_state.entry_plan, saved_plan)
	main.free()

func test_demo_program_combinations() -> void:
	var generator = DemoGenerator.new()
	var has_builder := generator.get_method_list().any(func(method: Dictionary): return str(method.get("name", "")) == "build_demo_programs")
	TestSupport.assert_equal(has_builder, true)
	if not has_builder:
		generator.free()
		return
	var programs: Dictionary = generator.call("build_demo_programs")
	for segment in ["short", "free"]:
		var program = programs[segment]
		TestSupport.assert_equal(program.elements.any(func(element): return element.combination_parts.size() > 0), true)
	generator.free()

func test_saved_route_resume() -> void:
	var career := Fixtures.starting_career(913)
	var short_program = SkatingProgram.create("short", "short", [ProgramElement.create("j1", "jump", "toe_loop", 2).element]).program
	var free_program = SkatingProgram.create("free", "free", [ProgramElement.create("f1", "jump", "salchow", 2).element]).program
	career.active_programs = {"short": short_program.to_dict(), "free": free_program.to_dict()}
	var route := {"points": [{"x": 0.13, "y": 0.27, "progress": 0.0}, {"x": 0.87, "y": 0.73, "progress": 1.0}], "action_anchors": [{"element_id": "j1", "part_index": 0, "progress": 0.5}]}
	career.competition_state = {
		"status": "awaiting_adjustment", "event_name": "续赛测试", "provisional_rank": 2,
		"available_adjustments": [],
		"short": {"performance": {"elements": [{"element_id": "j1", "abbreviation": "2T", "base_value": 1.3, "live_goe": 0.1, "status": "success"}]}, "route_execution": route, "technical_review": {"final_elements": []}, "score": {"total": 5.0}},
	}
	TestSupport.assert_equal(SaveRepository.save(career, MAIN_SAVE_PATH).ok, true)
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	TestSupport.assert_equal(main.load_active_career().ok, true)
	TestSupport.assert_equal(main.get_node("%CompetitionPanel")._segment_record.route_execution, route)
	TestSupport.assert_equal(main.get_node("%CompetitionPanel").cached_performance.elements[0].live_goe, 0.1)
	main.free()

func test_competition_screen_is_mounted() -> void:
	var main = _instantiate_main()
	TestSupport.assert_equal(main.get_node_or_null("%CompetitionPanel") != null, true)
	TestSupport.assert_equal(main.get_node("%CompetitionPanel").visible, false)
	main.free()

func teardown() -> void:
	for path in _isolated_autosaves:
		_delete_file(path)
		_delete_file(path + ".tmp")
	_isolated_autosaves.clear()
	_delete_file(MAIN_SAVE_PATH)
	_delete_file("%s.tmp" % MAIN_SAVE_PATH)
	_delete_file("user://career-01.json")
	_delete_file("user://career-01.json.tmp")
	_delete_file(MAIN_AUTOSAVE_PATH)
	_delete_file("%s.tmp" % MAIN_AUTOSAVE_PATH)
	_delete_file("user://career-autosave.json")
	_delete_file("user://career-autosave.json.tmp")

func test_main_connects_creation_quarter_and_summary_screens() -> void:
	var main = _instantiate_main()
	if not _supports_playable_flow(main):
		return
	main.offer_new_career(Fixtures.starting_career(61))
	TestSupport.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	_open_primary_action(main)
	TestSupport.assert_equal(main.get_node("%QuarterPanel").visible, true)
	main.get_node("%QuarterPanel").request_advance()
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible, true)
	TestSupport.assert_equal(main.active_career.clock.to_dict(), {"year": 2014, "quarter": 2})
	main.free()

func test_fresh_career_opening_flow() -> void:
	var main = _instantiate_main()
	_use_empty_test_autosave(main)
	var fresh = preload("res://src/simulation/career_factory.gd").create("林澄", 2007, "entry_interest_class", "family_supportive", 611, preload("res://src/content/catalog_repository.gd").load_catalog(), 4).career
	main.offer_new_career(fresh)
	TestSupport.assert_equal(main.get_node("%PreCareerHistoryPanel").visible, true)
	await main.call("_on_pre_career_history_continued")
	TestSupport.assert_equal(main.active_career.opening_stage, "handoff")
	TestSupport.assert_equal(main.get_node("%CoachHandoffPanel").visible, true)
	main.active_career = null
	TestSupport.assert_equal(main.try_resume_career().ok, true)
	TestSupport.assert_equal(main.get_node("%CoachHandoffPanel").visible, true)
	await main.call("_on_career_goal_confirmed", "highest_stage")
	TestSupport.assert_equal(main.active_career.opening_stage, "complete")
	TestSupport.assert_equal(main.active_career.career_goal.id, "highest_stage")
	TestSupport.assert_equal(main.active_career.career_goal.get("scoring_effect", true), false)
	TestSupport.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	main.free()

func test_main_confirms_replacing_an_unsaved_career() -> void:
	var main = _instantiate_main()
	if not _supports_playable_flow(main):
		return
	var first := Fixtures.starting_career(63)
	var replacement := Fixtures.starting_career(64)
	main.offer_new_career(first)
	main.offer_new_career(replacement)
	TestSupport.assert_equal(main.active_career, first)
	TestSupport.assert_equal(main.get_node("%NewCareerConfirmation").visible, true)
	main.confirm_new_career_replacement()
	TestSupport.assert_equal(main.active_career, replacement)
	main.free()

func test_failed_load_keeps_the_active_career() -> void:
	var main = _instantiate_main()
	if not _supports_playable_flow(main):
		return
	_delete_file(MAIN_SAVE_PATH)
	var active := Fixtures.starting_career(65)
	main.save_path = MAIN_SAVE_PATH
	main.offer_new_career(active)
	var result: Dictionary = main.load_active_career()
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(main.active_career, active)
	TestSupport.assert_equal(
		main.get_node("%GlobalMessage").text,
		"存档文件不存在：user://test-main-career.json",
	)
	main.free()

func test_save_then_load_restores_the_saved_quarter_state() -> void:
	var main = _instantiate_main()
	if not _supports_playable_flow(main):
		return
	main.save_path = MAIN_SAVE_PATH
	main.offer_new_career(Fixtures.starting_career(67))
	_open_primary_action(main)
	main.get_node("%QuarterPanel").request_advance()
	var saved_state: Dictionary = main.active_career.to_dict()
	TestSupport.assert_equal(main.save_active_career().ok, true)
	main.open_next_quarter()
	main.get_node("%QuarterPanel").request_advance()
	TestSupport.assert_equal(main.active_career.clock.quarter, 3)
	TestSupport.assert_equal(main.load_active_career().ok, true)
	TestSupport.assert_equal(
		JSON.stringify(main.active_career.to_dict()),
		JSON.stringify(saved_state),
	)
	TestSupport.assert_equal(main.get_node("%CareerHomePanel").visible, true)
	main.free()

func test_playable_panels_fit_the_minimum_viewport() -> void:
	var main = _instantiate_main()
	for panel_path in ["%CreationPanel", "%QuarterPanel", "%SummaryPanel", "%SeasonOverviewPanel"]:
		var panel: Control = main.get_node(panel_path)
		var minimum := panel.get_combined_minimum_size()
		TestSupport.assert_equal(
			minimum.x <= 960.0 and minimum.y <= 540.0,
			true,
			"%s minimum size %s exceeds 960x540" % [panel_path, minimum],
		)
	main.free()

func test_playable_panels_reserve_the_global_message_footer() -> void:
	var main = _instantiate_main()
	var message: Control = main.get_node("%GlobalMessage")
	var reserved_bottom := absf(message.offset_top)
	var creation_panel: Control = main.get_node("%CreationPanel")
	TestSupport.assert_equal(
		creation_panel.offset_bottom <= 270.0 - reserved_bottom,
		true,
		"CreationPanel does not reserve the GlobalMessage footer at 960x540",
	)
	for panel_path in ["%QuarterPanel", "%SummaryPanel", "%SeasonOverviewPanel"]:
		var panel: Control = main.get_node(panel_path)
		TestSupport.assert_equal(
			panel.get_theme_constant("margin_bottom") >= reserved_bottom,
			true,
			"%s does not reserve the GlobalMessage footer at 960x540" % panel_path,
		)
	main.free()

func test_quarter_autosaves_and_resumes() -> void:
	_delete_file(MAIN_SAVE_PATH)
	var main = _instantiate_main()
	main.save_path = MAIN_SAVE_PATH
	_use_empty_test_autosave(main)
	main.offer_new_career(Fixtures.starting_career(72))
	_open_primary_action(main)
	main.get_node("%QuarterPanel").request_advance()
	TestSupport.assert_equal(FileAccess.file_exists(MAIN_AUTOSAVE_PATH), true)
	var saved_quarter: int = main.active_career.clock.quarter
	main.active_career = null
	TestSupport.assert_equal(main.try_resume_career().ok, true)
	TestSupport.assert_equal(main.active_career.clock.quarter, saved_quarter)
	main.free()

func test_coach_led_training_flow() -> void:
	_delete_file(MAIN_AUTOSAVE_PATH)
	var main = _instantiate_main()
	_use_empty_test_autosave(main)
	var career := Fixtures.starting_career(721)
	career.internal_invitation_state.status = "completed"
	main.offer_new_career(career)
	_open_primary_action(main)
	await main.get_node("%QuarterPanel").continue_training()
	TestSupport.assert_equal(main.active_career.clock.quarter, 2)
	TestSupport.assert_equal(FileAccess.file_exists(MAIN_AUTOSAVE_PATH), true)
	TestSupport.assert_equal(main.get_node("%SummaryPanel").visible, true)
	TestSupport.assert_equal(main.get_node("%SummaryPanel").get_node("%SummaryHeading").text.contains("训练结果"), true)
	TestSupport.assert_equal(main.get_node("%SummaryPanel").get_node("%DetailsButton").text, "查看训练证据")
	main.free()

func test_first_teaching_invitation_stop() -> void:
	_delete_file(MAIN_AUTOSAVE_PATH)
	var main = _instantiate_main()
	_use_empty_test_autosave(main)
	var career := Fixtures.starting_career(722)
	career.clock.quarter = 3
	main.offer_new_career(career)
	_open_primary_action(main)
	await main.get_node("%QuarterPanel").continue_training()
	TestSupport.assert_equal(main.active_career.clock.quarter, 3)
	TestSupport.assert_equal(load("res://src/simulation/teaching_competition_service.gd").elapsed_week(main.active_career) >= 18, true)
	TestSupport.assert_equal(main.active_career.internal_invitation_state.status, "pending")
	TestSupport.assert_equal(main.active_career.world_state.early_peer_ids.size(), 5)
	TestSupport.assert_equal(main.get_node("%QuarterPanel").visible, true)
	TestSupport.assert_equal(main.get_node("%QuarterPanel").find_child("InternalStatusLabel", true, false).text.contains("教学赛邀请已到"), true)
	TestSupport.assert_equal(FileAccess.file_exists(MAIN_AUTOSAVE_PATH), true)
	main.free()

func test_internal_playback_resume(at_score: bool, acknowledged: bool = false, exit_before_reload: bool = true) -> void:
	var main = _instantiate_main()
	main.save_path = "user://test-internal-checkpoint-manual.json"
	_isolated_autosaves.append(main.save_path)
	var career := Fixtures.starting_career(922)
	career.clock.quarter = 4
	main.offer_new_career(career)
	for segment in ["short","free"]:
		var proposal = ProgramDraftService.propose(career.athlete,segment,InternalEventRules.for_teaching_group(segment),{},922)
		proposal.program.draft_status = "locked"
		proposal.program.locked_segments.append(segment)
		career.active_programs[segment] = proposal.program.to_dict()
	TestSupport.assert_equal(main.start_internal_competition({"rival_count":1}).ok,true)
	var panel = main.competition_panel
	if at_score:
		panel.settle_immediately()
		panel.advance_time(2.0)
		if acknowledged: panel._confirm_segment_score()
	else:
		panel.advance_playback()
		panel.advance_time(2.0)
	var elapsed: float = panel._playback_elapsed
	var record := JSON.stringify(career.competition_state.short)
	if exit_before_reload: await main.exit_to_main_menu()
	TestSupport.assert_equal(panel.is_processing(),false,"hidden competition playback must stop while the main menu is open")
	TestSupport.assert_equal(FileAccess.file_exists(main.autosave_path),true,"leaving playback must durably save its presentation checkpoint")
	var resumed = _instantiate_main()
	resumed.save_path = main.autosave_path if FileAccess.file_exists(main.autosave_path) else main.save_path
	TestSupport.assert_equal(resumed.load_active_career().ok,true)
	TestSupport.assert_equal(JSON.stringify(resumed.active_career.competition_state.short),record,"restore cannot reroll the segment")
	TestSupport.assert_equal(resumed.competition_panel.playback_state,"segment_complete" if acknowledged else ("awaiting_confirmation" if at_score else "paused"))
	TestSupport.assert_equal(resumed.competition_panel.get_node("%KissAndCryOverlay").visible,at_score and not acknowledged)
	TestSupport.assert_equal(resumed.competition_panel.get_node("%AdjustmentOverlay").visible,acknowledged)
	TestSupport.assert_equal(resumed.competition_panel._playback_elapsed,elapsed)
	TestSupport.assert_equal(resumed.active_career.history.filter(func(row): return row.get("category","") == "internal_competition").size(),0)
	main.free()
	resumed.free()

func test_internal_acknowledgement_retry() -> void:
	var main = _instantiate_main()
	var career := Fixtures.starting_career(923)
	career.clock.quarter = 4
	main.offer_new_career(career)
	for segment in ["short","free"]:
		var proposal = ProgramDraftService.propose(career.athlete,segment,InternalEventRules.for_teaching_group(segment),{},923)
		proposal.program.draft_status = "locked"
		proposal.program.locked_segments.append(segment)
		career.active_programs[segment] = proposal.program.to_dict()
	TestSupport.assert_equal(main.start_internal_competition({"rival_count":1}).ok,true)
	var panel = main.competition_panel
	panel.settle_immediately()
	panel.advance_time(2.0)
	var durable_path: String = main.autosave_path
	var saved_before := FileAccess.get_file_as_string(durable_path)
	var career_before := JSON.stringify(career.to_dict())
	var score_before := JSON.stringify(career.competition_state.short)
	main.autosave_path = "user://missing-ack-directory-%d/autosave.json" % Time.get_ticks_usec()
	panel._confirm_segment_score()
	TestSupport.assert_equal(panel.playback_state,"awaiting_confirmation")
	TestSupport.assert_equal(panel.get_node("%KissAndCryOverlay").visible,true)
	TestSupport.assert_equal(panel.get_node("%AdjustmentOverlay").visible,false)
	TestSupport.assert_equal(panel._completion_emitted,false)
	TestSupport.assert_equal(JSON.stringify(career.to_dict()),career_before)
	TestSupport.assert_equal(FileAccess.get_file_as_string(durable_path),saved_before)
	main.autosave_path = durable_path
	panel._confirm_segment_score()
	TestSupport.assert_equal(panel.get_node("%AdjustmentOverlay").visible,true)
	var resumed = _instantiate_main()
	resumed.save_path = durable_path
	TestSupport.assert_equal(resumed.load_active_career().ok,true)
	TestSupport.assert_equal(resumed.competition_panel.get_node("%AdjustmentOverlay").visible,true)
	TestSupport.assert_equal(JSON.stringify(resumed.active_career.competition_state.short),score_before)
	TestSupport.assert_equal(resumed.active_career.history.filter(func(row): return row.get("category","") == "internal_competition").size(),0)
	main.free()
	resumed.free()

func test_existing_autosave_confirmation() -> void:
	var path := "user://test-new-career-consent.json"
	var previous := Fixtures.starting_career(920)
	TestSupport.assert_equal(SaveRepository.save(previous,path).ok,true)
	var original := FileAccess.get_file_as_string(path)
	var main = _instantiate_main()
	main.autosave_path = path
	var replacement := Fixtures.starting_career(921)
	main.offer_new_career(replacement)
	TestSupport.assert_equal(main.active_career,null,"an existing autosave requires consent even when no career is loaded")
	TestSupport.assert_equal(main.new_career_confirmation.visible,true)
	TestSupport.assert_equal(main.new_career_confirmation.dialog_text.contains("自动存档"),true)
	TestSupport.assert_equal(FileAccess.get_file_as_string(path),original,"offering a new career cannot overwrite the saved career")
	main.new_career_confirmation.get_cancel_button().pressed.emit()
	TestSupport.assert_equal(main._pending_new_career,null,"cancel must discard the pending replacement")
	main.confirm_new_career_replacement()
	TestSupport.assert_equal(main.active_career,null,"a stale confirm after cancel cannot start a replacement")
	main.offer_new_career(replacement)
	main.confirm_new_career_replacement()
	TestSupport.assert_equal(main.active_career,replacement)
	TestSupport.assert_equal(FileAccess.get_file_as_string(path),original,"activation alone does not write the autosave")
	main.free()
	_delete_file(path)

func _use_empty_test_autosave(main) -> void:
	_delete_file(MAIN_AUTOSAVE_PATH)
	main.autosave_path = MAIN_AUTOSAVE_PATH

func _instantiate_main():
	var main = load(MAIN_SCENE).instantiate()
	# Most cases start a new career. Never borrow a real/default autosave or
	# another case's saved career now that overwrite consent is enforced.
	var path := "user://test-main-isolated-%d-%d.json" % [Time.get_ticks_usec(),_isolated_autosaves.size()]
	_isolated_autosaves.append(path)
	main.autosave_path = path
	Engine.get_main_loop().root.add_child(main)
	return main

func _open_primary_action(main) -> void:
	if main.get_node("%CareerHomePanel").visible:
		main.get_node("%CareerHomePanel").get_node("%PrimaryAction").pressed.emit()

func _supports_playable_flow(main) -> bool:
	var supported: bool = (
		main.has_method("offer_new_career")
		and main.has_method("confirm_new_career_replacement")
		and main.has_method("load_active_career")
		and main.has_method("save_active_career")
		and main.has_method("open_next_quarter")
	)
	TestSupport.assert_equal(supported, true)
	if not supported:
		main.free()
	return supported

func _delete_file(path: String) -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
