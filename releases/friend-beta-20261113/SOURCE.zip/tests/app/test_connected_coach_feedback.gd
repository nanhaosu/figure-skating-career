extends RefCounted

# Actual coach identity and settlement-backed visible feedback.
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"settlement plan facts report actual execution instead of fresh preview promises","callable":actual_plan_facts},
		{"name":"relationship screen identifies the actual coach without changing career","callable":identity},
		{"name":"main training result retains actual coaching beside a breakthrough","callable":summary},
		{"name":"settlement facts retain actual coaching outcome provenance","callable":provenance},
		{"name":"actual correction and support are explained without invented recovery","callable":review},
	]

func actual_plan_facts() -> void:
	var c = F.starting(73635)
	var service = load("res://src/simulation/meaningful_advance_service.gd")
	var result: Dictionary = service.advance(c,Intent.create("accept").intent)
	T.assert_equal(result.stop_reason,"quarter_complete","fixture must really settle the normal entry")
	T.assert_equal(result.career.last_generated_plan.is_empty(),false)
	var facts: Array = service._facts_from_settlement(c,result.career,[],[],{"reasons":["UNEXECUTED_FUTURE_LESSON"]})
	var plan_facts: Array = facts.filter(func(row): return row.get("kind") == "coach_plan")
	T.assert_equal(plan_facts.size(),1)
	if plan_facts.is_empty(): return
	T.assert_equal(plan_facts[0].get("executed_plan"),result.career.last_generated_plan,"actual saved course is the evidence, not a newly generated route preview")
	T.assert_equal(str(plan_facts[0].text).contains("UNEXECUTED_FUTURE_LESSON"),false)

func identity() -> void:
	var c = F.starting(73631)
	var profile: Dictionary = load("res://src/content/club_coach_repository.gd").new().coach_profile("coach_tang")
	c.coach_assignment.coach_id = str(profile.id)
	c.coach_assignment.club_id = str(profile.club_id)
	c.coach_assignment.known_strengths.assign(profile.known_strengths)
	c.coach_assignment.known_concerns.assign(profile.known_concerns)
	var before: Dictionary = c.to_dict().duplicate(true)
	var panel = load("res://src/app/career_reference_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(c,"relationships")
	var text: String = panel.get_node("%FactsText").text
	T.assert_equal(text.contains(str(profile.name)),true,"the selected coach cannot remain an anonymous trust number")
	T.assert_equal(text.contains("coach ·"),false)
	T.assert_equal(text.contains("guardian ·"),false)
	T.assert_equal(c.to_dict(),before,"coach information is read only, not a stat reward")
	panel.free()

func summary() -> void:
	var c = F.triple_gap(73632)
	var result := {"career":c,"before":c.transaction_copy(),"stop_reason":"quarter_complete","facts":[
		{"kind":"coach_training","decision":{"allocated_gap_ids":["toe_loop"]}},
		{"kind":"jump_milestone","signature":"first_jump_success:toe_loop:3","jump_id":"toe_loop","rotations":3},
		{"kind":"jump_attempts","jump_id":"toe_loop","rotations":3,"attempts":20,"successes":3},
		{"kind":"jump_attempts","jump_id":"salchow","rotations":2,"attempts":20,"successes":12},
		{"kind":"jump_attempts","jump_id":"loop","rotations":2,"attempts":20,"successes":11}
	]}
	var panel = load("res://src/app/summary_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present_training_period(c,result)
	var text: String = panel.get_node("%SetbacksCosts").text
	T.assert_equal(text.contains("补练"),true,"actual coaching must not be hidden whenever a milestone exists")
	T.assert_equal(text.contains("首次完成"),true)
	T.assert_equal(text.split("\n").size()<=3,true)
	panel.free()

func _settlement(seed_value: int) -> Dictionary:
	var c = F.triple_gap(seed_value)
	c.condition_state.psychology.stress = 40.0
	c.athlete.jumps.lutz.takeoff.edge_quality = 40.0
	c.athlete.jumps.lutz.observations.assign([{"kind":"edge","text":"勾手用刃问题","known":true}])
	var before = c.transaction_copy()
	var start: int = c.history.size()
	var built: Dictionary = Coach.build(c,Intent.create("accept").intent)
	var outcomes: Array = load("res://src/simulation/career_simulator.gd").advance_quarter(c,built.plan,load("res://src/content/catalog_repository.gd").load_catalog())
	var facts: Array = load("res://src/simulation/meaningful_advance_service.gd")._facts_from_settlement(before,c,c.history.slice(start),outcomes,built)
	return {"facts":facts,"outcomes":outcomes,"career":c,"before":before}

func provenance() -> void:
	var result := _settlement(73633)
	T.assert_equal(result.outcomes.any(func(row): return row.category == "coach_correction"),true,"fixture must contain real executed correction")
	T.assert_equal(result.outcomes.any(func(row): return row.category == "coach_support"),true,"fixture must contain real executed support")
	T.assert_equal(result.facts.any(func(row): return row.get("category") == "coach_correction"),true)
	T.assert_equal(result.facts.any(func(row): return row.get("category") == "coach_support"),true)

func review() -> void:
	var result := _settlement(73634)
	var lines: Array = load("res://src/presentation/coach_training_presenter.gd").review(result.facts)
	var rendered := ""
	for line in lines: rendered += str(line.text)+"\n"
	T.assert_equal(rendered.contains("用刃"),true,"name the actually observed technique that improved")
	T.assert_equal(rendered.contains("压力"),true,"actual support must be visible without a precise personality meter")
	var absent: Array = load("res://src/presentation/coach_training_presenter.gd").review([])
	T.assert_equal(absent.is_empty(),true,"no actual facts means no invented encouragement reward")
