extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"senior season opens senior free programme editor","callable":test_editor},{"name":"season level inspection leaves career unchanged","callable":test_choice},
		{"name":"season planning keeps confirm and return reachable at supported sizes","callable":test_planning_geometry},
		{"name":"season planning close preserves draft and durable confirmation clears gate","callable":test_planning_confirmation},
		{"name":"season planning save failure keeps choices for a durable retry","callable":test_planning_retry},
		{"name":"desktop season plan shows both selected curriculum states before confirmation","callable":test_focus_preview_visible},
		{"name":"season programme and two focuses commit together once and survive reload","callable":test_combined_focus_confirmation}]

func test_combined_focus_confirmation() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(425)
	main._present_season_planning("2018-19")
	var before: Dictionary = main.active_career.to_dict()
	var first = main._decision_dialog.find_child("SeasonFocus0",true,false)
	var second = main._decision_dialog.find_child("SeasonFocus1",true,false)
	T.assert_equal(first != null and second != null,true,"one season plan must include both existing training focuses")
	if first == null or second == null: main.free(); return
	for selection in [[first,"explore:3A"],[second,"musical_expression"]]:
		var index := -1
		for item in selection[0].item_count:
			if selection[0].get_item_metadata(item).get("id","") == selection[1]: index = item
		T.assert_equal(index >= 0,true,"missing existing focus option: "+selection[1])
		if index >= 0:
			selection[0].select(index)
			selection[0].item_selected.emit(index)
	T.assert_equal(main.active_career.to_dict(),before,"drafting directions must not train or save")
	main.autosave_path = "user://missing-combined-%d/autosave.json" % Time.get_ticks_usec()
	await main._confirm_season_planning()
	T.assert_equal(main.active_career.to_dict(),before,"failed save must commit neither half")
	main.autosave_path = "user://combined-season-%d.json" % Time.get_ticks_usec()
	await main._confirm_season_planning()
	var loaded: Dictionary = SaveRepository.load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true)
	if loaded.ok:
		T.assert_equal(loaded.career.training_direction.focuses.size(),2)
		T.assert_equal(loaded.career.training_direction.focuses[0].target.parts,[{"jump_id":"axel","rotations":3}])
		T.assert_equal(loaded.career.training_direction.focuses[1].kind,"musical_expression")
		T.assert_equal(loaded.career.season_program_plan.targets.free.size(),1,"programme targets derive from the same choice, not a second form")
		var built := CoachTrainingPlanService.build(loaded.career,TrainingIntent.create("accept").intent)
		T.assert_equal(built.errors,[])
		T.assert_equal(built.plan.expression_share,5)
		T.assert_equal(loaded.career.clock.to_dict(),before.clock)
	main.free()

func test_focus_preview_visible() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1280,720)
	viewport.gui_embed_subwindows = true
	Engine.get_main_loop().root.add_child(viewport)
	var main = load("res://src/app/main.tscn").instantiate()
	viewport.add_child(main)
	main.active_career = F.starting_career(426)
	main.active_career.clock.year = 2017
	main.active_career.training_direction.focuses = [{"id":"explore:3A","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}},{"id":"musical_expression","kind":"musical_expression","target":{}}]
	main._present_season_planning("2018-19")
	var dialog = main._decision_dialog
	var panel: Control = dialog.get_child(0)
	panel.theme = main.theme
	dialog.hide()
	dialog.remove_child(panel)
	viewport.add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.size = Vector2(880,600)
	await Engine.get_main_loop().process_frame
	await Engine.get_main_loop().process_frame
	var scroll: ScrollContainer = panel.find_child("DecisionScroll",true,false)
	var preview: Label = panel.find_child("SeasonTrainingPreview",true,false)
	T.assert_equal(preview.text.contains("3A") and preview.text.contains("音乐表达"),true)
	T.assert_equal(scroll.get_global_rect().encloses(preview.get_global_rect()),true,"the chosen curriculum must be readable before confirming, without scrolling on normal desktop")
	viewport.free()

func test_editor() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(420)
	main.active_career.clock.year = 2019
	main.active_career.clock.quarter = 3
	main.active_career.season_program_plan.competitive_level = "senior"
	main.open_program_editor("free")
	T.assert_equal(main.program_editor_panel.rules.get("level"),"senior")
	T.assert_equal(main.program_editor_panel.rules.get("choreographic_min"),1)
	main.free()

func test_choice() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(421)
	main.active_career.athlete.birth_year = 2005
	var before: Dictionary = main.active_career.to_dict()
	main._present_season_planning("2019-20")
	var choices = main.get_node("CareerDecisionDialog").find_child("CompetitiveLevelChoice",true,false)
	T.assert_equal(choices != null,true)
	if choices != null:
		T.assert_equal(choices.is_item_disabled(1),true)
		T.assert_equal(choices.is_item_disabled(2),true)
	T.assert_equal(main.active_career.to_dict(),before)
	main.free()

func _button(dialog: Node, caption: String) -> Button:
	for child in dialog.find_children("*","Button",true,false):
		if child.text == caption: return child
	return null

func test_planning_geometry() -> void:
	var root = Engine.get_main_loop().root
	for dimensions in [Vector2i(960,540),Vector2i(1280,720)]:
		var viewport := SubViewport.new()
		viewport.size = dimensions
		viewport.gui_embed_subwindows = true
		root.add_child(viewport)
		var main = load("res://src/app/main.tscn").instantiate()
		viewport.add_child(main)
		main.active_career = F.starting_career(422)
		main.active_career.clock.year = 2017
		main._present_season_planning("2018-19")
		var dialog: Window = main.get_node("CareerDecisionDialog")
		# Headless native windows report a 1x1 dummy surface. Exercise the real
		# production controls in a sized viewport; actual window positioning is
		# also checked in the exported browser, not inferred from this model.
		var panel: Control = dialog.get_child(0)
		panel.theme = main.theme
		dialog.hide()
		dialog.remove_child(panel)
		viewport.add_child(panel)
		panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
		var client_size := Vector2(720,430) if dimensions.x == 960 else Vector2(880,600)
		panel.size = client_size
		await Engine.get_main_loop().process_frame
		await Engine.get_main_loop().process_frame
		var visible_area := Rect2(Vector2.ZERO,client_size)
		T.assert_equal(panel.get_combined_minimum_size().x <= client_size.x and panel.get_combined_minimum_size().y <= client_size.y,true,"planning contents must fit bounded modal client area")
		for caption in ["确认本季方案","清空专项目标","先返回（不保存草稿）"]:
			var action := _button(panel,caption)
			T.assert_equal(action != null,true,"missing planning action: "+caption)
			if action != null: T.assert_equal(visible_area.encloses(action.get_global_rect()),true,"planning action clipped: %s client=%s action=%s" % [caption,client_size,action.get_global_rect()])
		var scroll = panel.find_child("DecisionScroll",true,false)
		T.assert_equal(scroll != null,true,"long planning body needs its own bounded scrolling region")
		if scroll != null:
			scroll.scroll_vertical = 10000
			await Engine.get_main_loop().process_frame
			if dimensions.x == 960: T.assert_equal(scroll.scroll_vertical > 0,true,"overflowing compact body must remain reachable")
			T.assert_equal(visible_area.encloses(_button(panel,"确认本季方案").get_global_rect()),true,"body scrolling must not move confirm away")
		viewport.free()

func test_planning_confirmation() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(423)
	main.active_career.clock.year = 2017
	main.autosave_path = "user://planning-confirm-%d.json" % Time.get_ticks_usec()
	var before: Dictionary = main.active_career.to_dict()
	main._present_season_planning("2018-19")
	main._season_planning_draft.mode = "upgrade"
	main._decision_dialog.close_requested.emit()
	T.assert_equal(main._decision_dialog.visible,false)
	T.assert_equal(main.active_career.to_dict(),before,"close must not save or advance the career")
	main._present_season_planning("2018-19")
	T.assert_equal(main._season_planning_draft.mode,"upgrade","reopening preserves unconfirmed choices")
	await main._confirm_season_planning()
	T.assert_equal(main._decision_dialog.visible,false,main.global_message.text)
	var loaded: Dictionary = SaveRepository.load_save(main.autosave_path)
	T.assert_equal(loaded.ok,true)
	if loaded.ok:
		T.assert_equal(loaded.career.season_program_plan.status,"confirmed")
		T.assert_equal(loaded.career.season_program_plan.season_id,"2018-19")
		T.assert_equal(SeasonProgramService.planning_node(loaded.career,{"calendar":{"season_id":"2018-19","events":[{"start_date":"2018-07-01"}]}}),{},"durable confirmation must not reopen the same planning gate")
	main.free()

func test_planning_retry() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(424)
	main.active_career.clock.year = 2017
	main._present_season_planning("2018-19")
	main._season_planning_draft.mode = "upgrade"
	var before: Dictionary = main.active_career.to_dict()
	main.autosave_path = "user://missing-planning-%d/autosave.json" % Time.get_ticks_usec()
	await main._confirm_season_planning()
	T.assert_equal(main.active_career.to_dict(),before)
	T.assert_equal(main._decision_dialog.visible,true)
	T.assert_equal(main._season_planning_draft.mode,"upgrade")
	main.autosave_path = "user://planning-retry-%d.json" % Time.get_ticks_usec()
	await main._confirm_season_planning()
	T.assert_equal(main.active_career.season_program_plan.status,"confirmed")
	T.assert_equal(main._decision_dialog.visible,false)
	main.free()
