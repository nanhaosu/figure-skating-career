extends RefCounted
const T = preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"public practice decision commits before the journey advances","callable":practice_commit},{"name":"short cut is not mislabeled as a between-segment save checkpoint","callable":cut},{"name":"reachability matrix can omit additional roundtrip without changing career","callable":matrix},{"name":"qualifying journey verifies a real between-segment checkpoint only once","callable":qualifying}]

func practice_commit() -> void:
	var c = load("res://tests/fixtures.gd").formal_acceptance_career("practice-commit")
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior").calendar.events[0]
	c.competition_state = load("res://src/simulation/formal_competition_simulator.gd").create_session(c,event,c.active_programs,"balanced",8192)
	var main = load("res://src/app/main.tscn").instantiate()
	main.save_path = "user://practice-commit.json"
	main.autosave_path = "user://practice-commit-auto.json"
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(c)
	main.confirm_new_career_replacement()
	T.assert_equal(main.active_career.competition_state.status,"practice_ready")
	await main._on_formal_practice_response_selected("accept")
	T.assert_equal(main.active_career.competition_state.status != "practice_ready",true,main.get_node("%GlobalMessage").text)
	main.free()
func setup(route: String) -> Dictionary:
	var c = load("res://tests/fixtures.gd").formal_acceptance_career(route)
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior").calendar.events[0]
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var session: Dictionary = sim.create_session(c,event,c.active_programs,"balanced",8192)
	session = sim.lock_short(c,sim.complete_practice(session,"accept"))
	c.competition_state = session
	var driver = load("res://scripts/international_season_journey.gd").new()
	driver.main = load("res://src/app/main.tscn").instantiate()
	driver.main.save_path = "user://roundtrip-checkpoint-%s.json" % route
	driver.main.autosave_path = "user://roundtrip-checkpoint-%s-auto.json" % route
	Engine.get_main_loop().root.add_child(driver.main)
	driver._adopt(c)
	return {"driver":driver,"status":session.status}
func cut() -> void:
	var s := setup("cut")
	T.assert_equal(s.status,"complete")
	s.driver._reload(true)
	T.assert_equal(s.driver.errors,[])
	T.assert_equal(s.driver.mid_competition_reload_equal,false,"a cut has already auto-completed the event, not SP-to-FS")
	s.driver.main.free()
func matrix() -> void:
	var s := setup("qualify")
	s.driver.check_roundtrips = false
	var before := JSON.stringify(s.driver.main.active_career.to_dict())
	s.driver._reload(true)
	T.assert_equal(s.driver.mid_competition_reload_equal,false,"matrix reachability does not claim save acceptance")
	T.assert_equal(JSON.stringify(s.driver.main.active_career.to_dict()) == before,true)
	s.driver.main.free()
func qualifying() -> void:
	var s := setup("qualify")
	T.assert_equal(s.status,"free_adjustment")
	s.driver._reload(true)
	T.assert_equal(s.driver.errors,[])
	T.assert_equal(s.driver.mid_competition_reload_equal,true)
	s.driver.main.save_path = "user://nonexistent-directory/never-save-again.json"
	s.driver._reload(true)
	T.assert_equal(s.driver.errors,[],"a verified checkpoint need not repeat on every later event")
	s.driver.main.free()
