extends "res://tests/app/test_main_flow.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"checklist summary wraps unbroken Chinese and long programme identifiers", "callable":test_unbroken_summary},
		{"name":"actual emitting coach button refresh removes every old action safely", "callable":test_button_refresh},
		{"name":"populated checklist keeps all actions and return inside 1280 viewport", "callable":test_geometry.bind(Vector2i(1280,720))},
		{"name":"populated checklist keeps all actions and return inside 960 viewport", "callable":test_geometry.bind(Vector2i(960,540))},
	]

func test_button_refresh() -> void:
	var main = _instantiate_main()
	main.active_career = Fixtures.formal_acceptance_career("qualify")
	var event_id := str(Fixtures.u_series_event().event_id)
	main.active_career.season_state = _confirmed_formal_season(event_id)
	main.active_career.active_programs.short.elements[0].combination_parts = [{"jump_id":"flip","rotations":2}]
	await main._on_formal_event_launch_requested(event_id)
	var panel = main.get_node("%SeasonOverviewPanel")
	var actions: VBoxContainer = panel.get_node("%ChecklistActions")
	var old: Array = actions.get_children().map(func(button):return weakref(button))
	var coach: Array = actions.get_children().filter(func(button):return button.text.contains("教练") and button.text.contains("短节目"))
	TestSupport.assert_equal(coach.size(),1)
	if coach.is_empty(): main.free(); return
	coach[0].pressed.emit()
	for frame in 8: await Engine.get_main_loop().process_frame
	TestSupport.assert_equal(main.active_career.active_programs.short.draft_status,"locked")
	TestSupport.assert_equal(main.get_node("%ProgramEditorPanel").visible,false)
	TestSupport.assert_equal(main.active_career.competition_state,{})
	for ref in old: TestSupport.assert_equal(ref.get_ref() == null,true,"refresh must retire every old action, including the emitting sender")
	var seen := {}
	for button in actions.get_children():
		TestSupport.assert_equal(seen.has(button.text),false,"old and new controls must not coexist")
		seen[button.text] = true
	TestSupport.assert_equal(actions.get_children().filter(func(button):return button.text.contains("教练") and button.text.contains("短节目")).size(),0,"accepted segment must not retain its stale coach action")
	TestSupport.assert_equal(panel.get_node("%PreCompetitionDialog").visible,true)
	main.free()

func test_geometry(dimensions: Vector2i) -> void:
	var viewport := SubViewport.new()
	viewport.size = dimensions
	viewport.gui_embed_subwindows = true
	Engine.get_main_loop().root.add_child(viewport)
	var panel = load("res://src/app/season_overview_panel.tscn").instantiate()
	panel.theme = load("res://src/app/theme_factory.gd").create()
	viewport.add_child(panel)
	var career := Fixtures.formal_acceptance_career("qualify")
	career.active_programs.short.elements.clear()
	career.active_programs.free.elements.clear()
	var result := preload("res://src/app/pre_competition_checklist_service.gd").inspect(career,Fixtures.u_series_event())
	panel.present_pre_competition_checklist(str(Fixtures.u_series_event().event_id),result)
	for frame in 8: await Engine.get_main_loop().process_frame
	var dialog: AcceptDialog = panel.get_node("%PreCompetitionDialog")
	print("CHECKLIST_SETTLED ",dimensions," dialog=",dialog.position," ",dialog.size," actions=",panel.get_node("%ChecklistActions").get_global_rect())
	TestSupport.assert_equal(dialog.position.x >= 0 and dialog.position.y >= 0 and dialog.position.x+dialog.size.x <= dimensions.x and dialog.position.y+dialog.size.y <= dimensions.y,true,"settled populated checklist must fit the viewport")
	var all_buttons: Array = panel.get_node("%ChecklistActions").get_children()+[dialog.get_ok_button()]
	TestSupport.assert_equal(all_buttons.filter(func(button):return button.text.contains("返回")).size(),1,"built-in return must be the only return control")
	var content := Rect2(Vector2.ZERO,Vector2(dialog.size))
	for button in panel.get_node("%ChecklistActions").get_children()+[dialog.get_ok_button()]:
		TestSupport.assert_equal(content.encloses(button.get_global_rect()),true,"every actual programme/return action must be reachable inside the dialog")
	var summary: Label = panel.get_node("%ChecklistSummary")
	TestSupport.assert_equal(summary.size.x >= 300,true,"summary must wrap at a usable width rather than one character")
	viewport.free()

func test_unbroken_summary() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960,540)
	viewport.gui_embed_subwindows = true
	Engine.get_main_loop().root.add_child(viewport)
	var panel = load("res://src/app/season_overview_panel.tscn").instantiate()
	panel.theme = load("res://src/app/theme_factory.gd").create()
	viewport.add_child(panel)
	# CJK needs smart fallback on Web; an unbroken programme identifier also
	# reproduces the same missing fallback in the native text backend.
	var reason := "当前短节目尚未满足赛事规定需要检查并调整跳跃组合旋转步法后重新锁定参赛版本".repeat(8)+"program_"+"x".repeat(160)
	panel.present_pre_competition_checklist("event",{"items":[{"label":"短节目","status":"repairable","reason":reason,"actions":[]}],"actions":[]})
	for frame in 8: await Engine.get_main_loop().process_frame
	var summary: Label = panel.get_node("%ChecklistSummary")
	var scroll: ScrollContainer = summary.get_parent()
	var font: Font = summary.get_theme_font("font")
	var text_width: float = font.get_string_size(summary.text,HORIZONTAL_ALIGNMENT_LEFT,-1,summary.get_theme_font_size("font_size")).x
	var required_lines := int(ceil(text_width/summary.size.x))
	print("CHECKLIST_WRAP width=",summary.size.x," text_width=",text_width," lines=",summary.get_line_count()," required=",required_lines)
	TestSupport.assert_equal(summary.size.x <= scroll.size.x,true,"summary must remain within the scroll width")
	TestSupport.assert_equal(summary.get_line_count() >= required_lines,true,"long unbroken content must form real lines rather than horizontal clipping")
	TestSupport.assert_equal(summary.size.y > scroll.size.y,true,"long reasons must remain vertically scrollable")
	viewport.free()
