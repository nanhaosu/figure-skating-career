extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"save manager validates before confirmation and preserves retry context","callable":test_panel}, {"name":"saving another manual slot updates the active save destination","callable":test_active_destination}]

func test_panel() -> void:
	T.assert_equal(ResourceLoader.exists("res://src/app/save_manager_panel.tscn"),true,"save manager is required")
	if not ResourceLoader.exists("res://src/app/save_manager_panel.tscn"): return
	var panel = load("res://src/app/save_manager_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var service = load("res://src/persistence/browser_save_service.gd").new("user://panel-%d" % Time.get_ticks_usec())
	var career = F.starting_career(812)
	panel.present(service,career)
	T.assert_equal(panel.confirm_button.disabled,true)
	panel.preview_payload("{broken")
	T.assert_equal(panel.confirm_button.disabled,true)
	T.assert_equal(panel.message.text.is_empty(),false)
	service.save_slot("manual-1",career)
	panel.preview_payload(FileAccess.get_file_as_string(service.slot_path("manual-1")))
	T.assert_equal(panel.confirm_button.disabled,false)
	T.assert_equal(panel.message.text.contains(career.athlete.display_name),true)
	var good_root: String = service.root
	service.root = "user://missing-panel-parent/subdir"
	panel.confirm_import()
	T.assert_equal(panel.confirm_button.disabled,false,"failed confirmation can be retried")
	service.root = good_root
	panel.confirm_import()
	T.assert_equal(panel.confirm_button.disabled,true)
	T.assert_equal(panel.slot_list.item_count,4)
	panel.free()

func test_active_destination() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.browser_saves = load("res://src/persistence/browser_save_service.gd").new("user://destination-%d" % Time.get_ticks_usec())
	main.active_career = F.starting_career(813)
	main.has_unsaved_changes = true
	var panel = main.get_node("%SaveManagerPanel")
	panel.present(main.browser_saves,main.active_career)
	panel.slot_list.select(2)
	panel.save_current()
	T.assert_equal(main.save_path,main.browser_saves.slot_path("manual-2"))
	T.assert_equal(main.has_unsaved_changes,false)
	main.free()
