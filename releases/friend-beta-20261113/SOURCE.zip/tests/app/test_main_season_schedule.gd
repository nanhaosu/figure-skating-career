extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const SAVE_PATH := "user://season-schedule-ui-remediation.json"

func cases() -> Array[Dictionary]:
	return [{"name":"main season batch can be inspected cancelled and saved without advancing time", "callable":test_schedule_flow},
		{"name":"cached unchanged qualifications do not hide a legacy unavailable U-series", "callable":test_legacy_cached_repair},
		{"name":"unavailable U-series notice offers real programme repair without entering competition", "callable":test_unavailable_repair}]

func test_unavailable_repair() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(7702)
	main.active_career.clock.year = 2019
	main.active_career.certification_state.national_technical_grade = 7
	main.active_career.season_program_plan.season_id = "2019-20"
	main.active_career.season_state.domestic_schedule_selected = true
	preload("res://src/app/onboarding_service.gd").mark_seen(main.active_career,"registration",true)
	main._open_career_home()
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(main.active_career)
	var event: Dictionary = bundle.calendar.events.filter(func(row): return row.event_id == "cn_grand_prix_u_series_2019")[0]
	var options := preload("res://src/simulation/entry_application_service.gd").options(main.active_career,event,bundle)
	T.assert_equal(options[0].available,false)
	var before: Dictionary = main.active_career.to_dict()
	main._present_season_node({"kind":"registration","event_id":event.event_id,"choices":options})
	T.assert_equal(main.season_overview_panel.get_node("%PreCompetitionDialog").visible,true,"show a repair path, not just skip/cancel")
	T.assert_equal(main.season_overview_panel.get_node("%AdjustmentDialog").visible,false)
	var actions = main.season_overview_panel.get_node("%ChecklistActions")
	T.assert_equal(actions.get_child_count() > 2,true,"coach and manual programme repairs must be available")
	T.assert_equal(main.active_career.to_dict(),before,"inspection cannot enter a competition or alter eligibility")
	main._on_pre_competition_action_requested(event.event_id,"edit_program","short")
	T.assert_equal(main.program_editor_panel.visible,true)
	T.assert_equal(main.program_editor_panel.rules.season_start_year,2019)
	T.assert_equal(main.active_career.competition_state,{})
	main._close_program_editor()
	T.assert_equal(main.active_career.competition_state,{})
	main.free()

func test_legacy_cached_repair() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = load("res://tests/simulation/test_season_schedule_remediation.gd").new()._legacy_decline()
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(main.active_career)
	main.active_career.season_state.season_id = bundle.calendar.season_id
	main.active_career.season_state.qualification_state = preload("res://src/simulation/season_calendar_planner.gd").qualification_state_for(main.active_career)
	var result: Dictionary = main._ensure_2018_season_plan()
	T.assert_equal(result.ok,true)
	T.assert_equal(main.active_career.season_state.entry_plan.entries.cn_grand_prix_u_series_2019.status,"blocked","unchanged eligibility cache must not preserve the old automatic decline")
	main.free()

func teardown() -> void:
	for suffix in ["", ".tmp", ".bak"]:
		if FileAccess.file_exists(SAVE_PATH+suffix): DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH+suffix))

func test_schedule_flow() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	main.autosave_path = SAVE_PATH
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.formal_junior_career(7701)
	main.active_career.certification_state.national_technical_grade = 7
	main.active_career.athlete.resources.money = 90.0
	main._open_career_home()
	var before: Dictionary = main.active_career.to_dict()
	main._on_domestic_schedule_requested()
	var dialog = main.season_overview_panel.find_child("DomesticScheduleDialog", true, false)
	T.assert_equal(dialog.visible, true)
	dialog.get_cancel_button().pressed.emit()
	dialog.hide()
	T.assert_equal(main.active_career.to_dict(), before, "inspection and cancellation must not commit the schedule")
	await main._on_domestic_schedule_selected(["cn_club_league_2018_stage_1"])
	T.assert_equal(main.active_career.clock.to_dict(), before.clock)
	T.assert_equal(main.active_career.season_state.get("domestic_schedule_selected", false), true)
	T.assert_equal(main.active_career.season_state.entry_plan.entries.cn_club_league_2018_stage_1.status, "confirmed")
	var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(SAVE_PATH)
	T.assert_equal(loaded.ok, true)
	T.assert_equal(loaded.career.season_state.entry_plan.entries.cn_club_league_2018_stage_1.status, "confirmed")
	# A due entry goes to actual pre-flight checks, not another application.
	main.active_career.active_programs = {}
	dialog.hide()
	main._present_season_node({"kind":"competition_check_in", "event_id":"cn_club_league_2018_stage_1"})
	T.assert_equal(dialog.visible, false)
	T.assert_equal(main.get_node("%GlobalMessage").text.contains("赛前检查"), true, "confirmed entries must automatically reach preparation without another registration click")
	main.free()
