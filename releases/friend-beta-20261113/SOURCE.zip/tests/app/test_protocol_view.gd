extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const SCENE := "res://src/app/protocol_view.tscn"

func cases() -> Array[Dictionary]:
	return [
		{"name":"protocol shows every technical and judge column", "callable":test_public_columns},
		{"name":"protocol shows five components and totals", "callable":test_components_and_totals},
	]

func test_public_columns() -> void:
	var view = _view()
	view.present({"name":"林心宁", "federation":"CHN"}, {"short":_protocol(7)})
	TestSupport.assert_equal(view.get_node("%ElementRows").get_child_count(), 7)
	TestSupport.assert_equal(view.get_node("%JudgeHeader").text.contains("J9"), true)
	TestSupport.assert_equal(view.get_node("%AthleteHeading").text.contains("林心宁"), true)
	view.free()

func test_components_and_totals() -> void:
	var view = _view()
	view.present({"name":"林心宁"}, {"short":_protocol(3)})
	TestSupport.assert_equal(view.get_node("%ComponentRows").get_child_count(), 5)
	TestSupport.assert_equal(view.get_node("%DomesticBonus").text.contains("国内奖励"), true)
	TestSupport.assert_equal(view.get_node("%ProtocolTotal").text.contains("60.00"), true)
	view.free()

func _protocol(count: int) -> Dictionary:
	var elements: Array[Dictionary] = []
	for i in count: elements.append({"abbreviation":"E%d" % i, "info":["<"] if i == 0 else [], "base_value":2.0, "goe":0.2, "judge_goes":[0,1,1,0,1,1,0,1,1], "total":2.2})
	var components := {}
	for id in ["skating_skills", "transitions", "performance", "composition", "interpretation"]: components[id] = {"judge_marks":[6.0,6.25,6.5,6.0,6.25,6.5,6.0,6.25,6.5], "average":6.25, "factor":0.8, "factored":5.0}
	return {"element_scores":elements, "component_scores":components, "pcs_factor":0.8, "tes":25.0, "pcs":25.0, "deductions":1.0, "domestic_bonus":11.0, "total":60.0}

func _view():
	TestSupport.assert_equal(ResourceLoader.exists(SCENE), true)
	if not ResourceLoader.exists(SCENE): return null
	var view = load(SCENE).instantiate(); Engine.get_main_loop().root.add_child(view); return view
