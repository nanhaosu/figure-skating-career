extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const TrainingPolicy = preload("res://src/domain/training_policy.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "valid policy accepts up to two focus jumps", "callable": test_valid_policy},
		{"name": "unknown policy and risk are rejected", "callable": test_unknown_values_rejected},
		{"name": "more than two focus jumps are rejected", "callable": test_too_many_focus_jumps},
		{"name": "focus jump requires valid rotation target", "callable": test_focus_target_required},
	]

func test_valid_policy() -> void:
	var result := TrainingPolicy.create("balanced_foundation", ["toe_loop", "salchow"], {"toe_loop": 2, "salchow": 2}, "normal")
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.policy.focus_jumps, ["toe_loop", "salchow"])

func test_unknown_values_rejected() -> void:
	var result := TrainingPolicy.create("magic", [], {}, "reckless")
	TestSupport.assert_equal(result.policy, null)
	TestSupport.assert_equal(result.errors.size(), 2)

func test_too_many_focus_jumps() -> void:
	var result := TrainingPolicy.create("rotation_push", ["toe_loop", "salchow", "loop"], {"toe_loop": 2, "salchow": 2, "loop": 2}, "normal")
	TestSupport.assert_equal(result.policy, null)
	TestSupport.assert_equal(result.errors.has("重点跳跃最多选择两个"), true)

func test_focus_target_required() -> void:
	var result := TrainingPolicy.create("rotation_push", ["toe_loop"], {"toe_loop": 5}, "aggressive")
	TestSupport.assert_equal(result.policy, null)
	TestSupport.assert_equal(result.errors.is_empty(), false)
