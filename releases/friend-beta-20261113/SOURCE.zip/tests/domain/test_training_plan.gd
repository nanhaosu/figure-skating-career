extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")

const VALID := {
	"skating_foundation": 3,
	"jump_toe_loop": 1,
	"jump_salchow": 1,
	"jump_loop": 0,
	"jump_flip": 0,
	"jump_lutz": 0,
	"jump_axel": 1,
	"rotation": 2,
	"conditioning": 2,
	"rest": 2,
}
const VALID_SHARES := {
	"skating_foundation": 25,
	"jump_toe_loop": 10, "jump_salchow": 10, "jump_loop": 5,
	"jump_flip": 5, "jump_lutz": 5, "jump_axel": 5,
	"rotation": 10,
	"conditioning": 10,
	"rest": 15,
}
const SINGLE_TARGETS := {
	"toe_loop": 1, "salchow": 1, "loop": 1,
	"flip": 1, "lutz": 1, "axel": 1,
}

func cases() -> Array[Dictionary]:
	return [
		{"name": "valid plan has twelve units", "callable": test_valid_plan_has_twelve_units},
		{"name": "overallocated plan is rejected", "callable": test_overallocated_plan_is_rejected},
		{"name": "underallocated plan is rejected", "callable": test_underallocated_plan_is_rejected},
		{"name": "missing category is rejected", "callable": test_missing_category_is_rejected},
		{"name": "unknown category is rejected", "callable": test_unknown_category_is_rejected},
		{"name": "non integer allocation is rejected", "callable": test_non_integer_allocation_is_rejected},
		{"name": "negative allocation is rejected", "callable": test_negative_allocation_is_rejected},
		{"name": "rest below one is rejected", "callable": test_rest_below_one_is_rejected},
		{"name": "plan allocations are immutable copies", "callable": test_plan_allocations_are_immutable_copies},
		{"name": "percentage plan totals one hundred", "callable": test_percentage_plan_totals_one_hundred},
		{"name": "percentage shares use five percent steps", "callable": test_percentage_shares_use_five_percent_steps},
		{"name": "nonzero jump share requires rotation target", "callable": test_nonzero_jump_requires_rotation_target},
		{"name": "percentage plan exports immutable copies", "callable": test_percentage_plan_exports_immutable_copies},
		{"name": "percentage plan accepts short and free program practice", "callable": test_program_practice_shares},
		{"name": "legacy percentage plan defaults program practice to zero", "callable": test_program_practice_defaults},
	]

func test_valid_plan_has_twelve_units() -> void:
	var result := TrainingPlan.create(VALID)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.plan.total_units(), 12)

func test_overallocated_plan_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations["skating_foundation"] = 4
	allocations["jump_toe_loop"] = 2
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.errors, ["每季度必须正好分配12个训练单位，当前为14"])

func test_underallocated_plan_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations["rest"] = 1
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.errors, ["每季度必须正好分配12个训练单位，当前为11"])

func test_missing_category_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations.erase("rotation")
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.plan, null)
	TestSupport.assert_equal(result.errors.size() > 0, true)

func test_unknown_category_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations["unknown"] = 0
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.plan, null)
	TestSupport.assert_equal(result.errors.size() > 0, true)

func test_non_integer_allocation_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations["rotation"] = 1.5
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.plan, null)
	TestSupport.assert_equal(result.errors.size() > 0, true)

func test_negative_allocation_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations["rotation"] = -1
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.plan, null)
	TestSupport.assert_equal(result.errors.size() > 0, true)

func test_rest_below_one_is_rejected() -> void:
	var allocations := VALID.duplicate()
	allocations["rest"] = 0
	allocations["conditioning"] = 4
	var result := TrainingPlan.create(allocations)
	TestSupport.assert_equal(result.plan, null)
	TestSupport.assert_equal(result.errors.size() > 0, true)

func test_plan_allocations_are_immutable_copies() -> void:
	var source := VALID.duplicate()
	var result := TrainingPlan.create(source)
	source["rest"] = 10
	var exported: Dictionary = result.plan.to_dict()
	exported["allocations"]["rest"] = 10
	TestSupport.assert_equal(result.plan.total_units(), 12)
	TestSupport.assert_equal(result.plan.to_dict()["allocations"]["rest"], 2)

func test_percentage_plan_totals_one_hundred() -> void:
	var result := TrainingPlan.create(VALID_SHARES, SINGLE_TARGETS)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.plan.total_share(), 100)

func test_percentage_shares_use_five_percent_steps() -> void:
	var shares := VALID_SHARES.duplicate()
	shares.skating_foundation = 26
	shares.rotation = 9
	var result := TrainingPlan.create(shares, SINGLE_TARGETS)
	TestSupport.assert_equal(result.errors.has("所有训练比例必须以5%为步长"), true)

func test_nonzero_jump_requires_rotation_target() -> void:
	var targets := SINGLE_TARGETS.duplicate()
	targets.erase("lutz")
	var result := TrainingPlan.create(VALID_SHARES, targets)
	TestSupport.assert_equal(result.errors.has("勾手跳有训练比例但未选择目标周数"), true)

func test_percentage_plan_exports_immutable_copies() -> void:
	var shares := VALID_SHARES.duplicate()
	var targets := SINGLE_TARGETS.duplicate()
	var result := TrainingPlan.create(shares, targets)
	shares.rest = 100
	targets.lutz = 4
	var exported: Dictionary = result.plan.to_dict()
	exported.shares.rest = 100
	exported.jump_rotations.lutz = 4
	TestSupport.assert_equal(result.plan.shares.rest, 15)
	TestSupport.assert_equal(result.plan.jump_rotations.lutz, 1)

func test_program_practice_shares() -> void:
	var shares := VALID_SHARES.duplicate()
	shares.skating_foundation -= 20
	shares.program_short = 10
	shares.program_free = 10
	var result := TrainingPlan.create(shares, SINGLE_TARGETS)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.plan.shares.program_short, 10)
	TestSupport.assert_equal(result.plan.shares.program_free, 10)

func test_program_practice_defaults() -> void:
	var result := TrainingPlan.create(VALID_SHARES, SINGLE_TARGETS)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.plan.shares.program_short, 0)
	TestSupport.assert_equal(result.plan.shares.program_free, 0)
