extends RefCounted

const T = preload("res://tests/test_support.gd")
const TrainingIntent = preload("res://src/domain/training_intent.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"training intent validates four player responses", "callable":test_modes},
		{"name":"requested element is explicit and round trips", "callable":test_requested_element},
	]

func test_modes() -> void:
	for mode in ["accept", "safer", "more_aggressive"]:
		var result := TrainingIntent.create(mode)
		T.assert_equal(result.errors, [])
		T.assert_equal(result.intent.mode, mode)
	T.assert_equal(TrainingIntent.create("unknown").errors.is_empty(), false)
	T.assert_equal(TrainingIntent.create("requested_element").errors.is_empty(), false)

func test_requested_element() -> void:
	var result := TrainingIntent.create("requested_element", "jump:toe_loop:2")
	T.assert_equal(result.errors, [])
	T.assert_equal(TrainingIntent.from_dict(result.intent.to_dict()).to_dict(), result.intent.to_dict())
