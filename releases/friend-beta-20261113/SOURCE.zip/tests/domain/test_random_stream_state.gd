extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const RandomStreamState = preload("res://src/domain/random_stream_state.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "random streams do not shift each other", "callable": test_streams_do_not_shift_each_other},
		{"name": "taking a stream advances only that cursor", "callable": test_taking_stream_advances_only_that_cursor},
		{"name": "peeking a stream does not advance its cursor", "callable": test_peek_does_not_advance_cursor},
		{"name": "random stream round trip preserves next result", "callable": test_round_trip_preserves_next_result},
		{"name": "random stream restores JSON numbers as integers", "callable": test_json_numbers_restore_as_integers},
		{"name": "training stream preserves legacy seed formula", "callable": test_training_stream_preserves_legacy_seed_formula},
		{"name": "random stream validation rejects invalid seed and steps", "callable": test_invalid_seed_and_steps},
		{"name": "random stream validation rejects invalid cursor entries", "callable": test_invalid_cursor_entries},
	]

func test_streams_do_not_shift_each_other() -> void:
	var untouched = RandomStreamState.new(42)
	var interleaved = RandomStreamState.new(42)
	var expected_training: int = untouched.take_rng("training").randi()
	interleaved.take_rng("world").randi()
	var actual_training: int = interleaved.take_rng("training").randi()
	TestSupport.assert_equal(actual_training, expected_training)

func test_taking_stream_advances_only_that_cursor() -> void:
	var state = RandomStreamState.new(42)
	state.take_rng("training")
	TestSupport.assert_equal(state.steps, {"training": 1})

func test_peek_does_not_advance_cursor() -> void:
	var state = RandomStreamState.new(42)
	var first: int = state.peek_rng("events").randi()
	var second: int = state.peek_rng("events").randi()
	TestSupport.assert_equal(first, second)
	TestSupport.assert_equal(state.steps, {})

func test_round_trip_preserves_next_result() -> void:
	var state = RandomStreamState.new(42)
	state.take_rng("events")
	var restored = RandomStreamState.from_dict(state.to_dict())
	TestSupport.assert_equal(restored.take_rng("events").randi(), state.take_rng("events").randi())

func test_json_numbers_restore_as_integers() -> void:
	var restored = RandomStreamState.from_dict({"base_seed": 42.0, "steps": {"training": 1.0}})
	TestSupport.assert_equal(typeof(restored.base_seed), TYPE_INT)
	TestSupport.assert_equal(typeof(restored.steps.training), TYPE_INT)
	TestSupport.assert_equal(restored.to_dict(), {"base_seed": 42, "steps": {"training": 1}})

func test_training_stream_preserves_legacy_seed_formula() -> void:
	var state = RandomStreamState.new(42, {"training": 3})
	var expected := RandomNumberGenerator.new()
	expected.seed = 42 + 3 * 104729
	TestSupport.assert_equal(state.take_rng("training").randi(), expected.randi())

func test_invalid_seed_and_steps() -> void:
	TestSupport.assert_equal(RandomStreamState.validate({"base_seed": -1, "steps": {}}), "随机流 base_seed 必须是非负整数")
	TestSupport.assert_equal(RandomStreamState.validate({"base_seed": 1.5, "steps": {}}), "随机流 base_seed 必须是非负整数")
	TestSupport.assert_equal(RandomStreamState.validate({"base_seed": 1, "steps": []}), "随机流 steps 必须是对象")

func test_invalid_cursor_entries() -> void:
	TestSupport.assert_equal(RandomStreamState.validate({"base_seed": 1, "steps": {"": 0}}), "随机流名称必须是非空字符串")
	TestSupport.assert_equal(RandomStreamState.validate({"base_seed": 1, "steps": {"events": -1}}), "随机流 events 的推进位置必须是非负整数")
	TestSupport.assert_equal(RandomStreamState.validate({"base_seed": 1, "steps": {"events": 1.5}}), "随机流 events 的推进位置必须是非负整数")
