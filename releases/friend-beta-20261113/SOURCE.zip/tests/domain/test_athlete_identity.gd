extends RefCounted

const T = preload("res://tests/test_support.gd")
const Athlete = preload("res://src/domain/athlete_state.gd")
const IDENTITY_PATH := "res://src/domain/athlete_identity.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"senior age uses June thirtieth not July first", "callable":cutoff},
		{"name":"year only age is a conservative interval not a guessed birthday", "callable":unknown_interval},
		{"name":"junior upper age boundary preserves uncertainty", "callable":upper_boundary},
		{"name":"identity validates Gregorian dates including century leap years", "callable":calendar_dates},
		{"name":"identity rejects fractional nonfinite and partial birthdays", "callable":date_types},
		{"name":"invalid age inputs never grant eligibility", "callable":invalid_age},
		{"name":"birth date survives JSON athlete copy without shared mutation", "callable":roundtrip},
	]

func _identity():
	T.assert_equal(FileAccess.file_exists(IDENTITY_PATH),true,"persistent precision-aware identity is required")
	return load(IDENTITY_PATH) if FileAccess.file_exists(IDENTITY_PATH) else null

func cutoff() -> void:
	var identity = _identity()
	if identity == null: return
	for row in [
		[{"year":2006,"month":6,"day":30},"eligible",15],
		[{"year":2006,"month":7,"day":1},"ineligible",14],
		[{"year":2006,"month":7,"day":2},"ineligible",14],
	]:
		var result: Dictionary = identity.age_gate(2006,row[0],2021,15,1000)
		T.assert_equal(result.status,row[1])
		T.assert_equal(result.age,row[2])

func unknown_interval() -> void:
	var identity = _identity()
	if identity == null: return
	for row in [[2006,"unknown",14,15],[2005,"eligible",15,16],[2007,"ineligible",13,14]]:
		var result: Dictionary = identity.age_gate(row[0],{},2021,15,1000)
		T.assert_equal(result.status,row[1])
		T.assert_equal(result.minimum_possible_age,row[2])
		T.assert_equal(result.maximum_possible_age,row[3])
		T.assert_equal(result.age,null,"year precision does not claim one exact age")

func upper_boundary() -> void:
	var identity = _identity()
	if identity == null: return
	T.assert_equal(identity.age_gate(2002,{},2021,13,18).status,"unknown")
	T.assert_equal(identity.age_gate(2002,{"year":2002,"month":7,"day":1},2021,13,18).status,"eligible")
	T.assert_equal(identity.age_gate(2002,{"year":2002,"month":6,"day":30},2021,13,18).status,"ineligible")
	T.assert_equal(identity.age_gate(2001,{},2021,13,18).status,"ineligible")

func calendar_dates() -> void:
	var identity = _identity()
	if identity == null: return
	for date in [{"year":2008,"month":2,"day":29},{"year":2000,"month":2,"day":29},{"year":2007,"month":12,"day":31}]:
		T.assert_equal(identity.validate_birth_date(date,date.year).is_empty(),true)
	for date in [{"year":2007,"month":2,"day":29},{"year":1900,"month":2,"day":29},{"year":2007,"month":13,"day":1},{"year":2007,"month":1,"day":0},{"year":2007,"month":4,"day":31}]:
		T.assert_equal(identity.validate_birth_date(date,date.year).is_empty(),false, str(date))
	T.assert_equal(identity.validate_birth_date({"year":2006,"month":6,"day":30},2007).is_empty(),false)
	T.assert_equal(identity.validate_birth_date({},2007).is_empty(),true)

func date_types() -> void:
	var identity = _identity()
	if identity == null: return
	var date: Dictionary = JSON.parse_string('{"year":2008,"month":2,"day":29}')
	T.assert_equal(identity.validate_birth_date(date,2008).is_empty(),true,"JSON integer values must remain usable")
	for bad in [2.5,"2",true,NAN,INF]:
		T.assert_equal(identity.validate_birth_date({"year":2008,"month":bad,"day":28},2008).is_empty(),false)
	T.assert_equal(identity.validate_birth_date({"year":2008,"month":2},2008).is_empty(),false)
	T.assert_equal(identity.validate_birth_date({"year":2008,"month":2,"day":28,"certainty":"guessed"},2008).is_empty(),false)

func invalid_age() -> void:
	var identity = _identity()
	if identity == null: return
	T.assert_equal(identity.age_gate(0,{},2021,15,1000).status,"unknown")
	T.assert_equal(identity.age_gate(2006,{},0,15,1000).status,"unknown")
	T.assert_equal(identity.age_gate(2006,{},2021,18,13).status,"unknown")
	T.assert_equal(identity.age_gate(2006,{"year":2006,"month":2,"day":30},2021,15,1000).status,"unknown")

func roundtrip() -> void:
	var data: Dictionary = Athlete.new("生日测试",2008).to_dict()
	data.birth_date = {"year":2008,"month":2,"day":29}
	var restored = Athlete.from_dict(JSON.parse_string(JSON.stringify(data)))
	T.assert_equal(restored.to_dict().get("birth_date",{}),data.birth_date)
	var copy: Dictionary = restored.to_dict()
	if not copy.has("birth_date"): return
	copy.birth_date.day = 28
	T.assert_equal(restored.to_dict().birth_date.day,29)
	data.birth_date.day = 27
	T.assert_equal(restored.to_dict().birth_date.day,29)
