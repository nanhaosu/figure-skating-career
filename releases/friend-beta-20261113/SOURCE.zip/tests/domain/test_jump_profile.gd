extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const JumpProfile = preload("res://src/domain/jump_profile.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "new athletes own six independent jump profiles", "callable": test_six_independent_profiles},
		{"name": "skating skill cannot repair lutz takeoff edge", "callable": test_skating_does_not_change_lutz_edge},
		{"name": "jump profile round trips all nested technique", "callable": test_jump_profile_round_trip},
		{"name": "jump profile round trips attempt evidence", "callable": test_attempt_evidence_round_trip},
	]

func test_six_independent_profiles() -> void:
	var athlete := AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	TestSupport.assert_equal(athlete.jumps.keys().size(), 6)
	athlete.jumps["lutz"].takeoff["edge_quality"] = 12.0
	TestSupport.assert_equal(athlete.jumps["flip"].takeoff["edge_quality"], 50.0)

func test_skating_does_not_change_lutz_edge() -> void:
	var athlete := AthleteState.new()
	var original_edge: float = athlete.jumps["lutz"].takeoff["edge_quality"]
	athlete.skating["speed"] = 90.0
	athlete.skating["deep_edge"] = 90.0
	TestSupport.assert_equal(athlete.jumps["lutz"].takeoff["edge_quality"], original_edge)

func test_jump_profile_round_trip() -> void:
	var profile = JumpProfile.create("flip")
	profile.unlocked_rotations = 1
	profile.attempts = 18
	profile.takeoff["edge_stability"] = 37.0
	profile.observations.append({"source": "coach", "key": "edge_unstable", "confidence": 0.6})
	var restored = JumpProfile.from_dict(profile.to_dict())
	TestSupport.assert_equal(restored.to_dict(), profile.to_dict())

func test_attempt_evidence_round_trip() -> void:
	var profile = JumpProfile.create("salchow")
	profile.attempt_evidence.double.attempts = 20
	profile.attempt_evidence.double.successes = 3
	profile.attempt_evidence.double.first_success_clock = {"year": 2016, "quarter": 2}
	var restored = JumpProfile.from_dict(profile.to_dict())
	TestSupport.assert_equal(restored.attempt_evidence, profile.attempt_evidence)
	var legacy: Dictionary = profile.to_dict(); legacy.erase("attempt_evidence")
	TestSupport.assert_equal(JumpProfile.from_dict(legacy).attempt_evidence.double.attempts, 0)
