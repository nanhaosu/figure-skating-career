extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const PlanProposal = preload("res://src/domain/plan_proposal.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "proposal preserves desired approved and executed plans", "callable": test_three_plan_layers_round_trip},
		{"name": "proposal preserves percentage shares and rotation targets", "callable": test_percentage_plan_layers_round_trip},
	]

func test_three_plan_layers_round_trip() -> void:
	var desired = Fixtures.jump_heavy_plan()
	var proposal = PlanProposal.create(desired)
	proposal.approved = Fixtures.balanced_plan()
	proposal.executed = Fixtures.balanced_plan()
	proposal.status = "resolved"
	var restored = PlanProposal.from_dict(proposal.to_dict())
	TestSupport.assert_equal(restored.to_dict(), proposal.to_dict())
	TestSupport.assert_equal(restored.desired.jump_units(), 6)
	TestSupport.assert_equal(restored.approved.jump_units(), 3)

func test_percentage_plan_layers_round_trip() -> void:
	var desired = Fixtures.percentage_balanced_plan()
	var proposal = PlanProposal.create(desired)
	proposal.status = "resolved"
	var restored = PlanProposal.from_dict(proposal.to_dict())
	TestSupport.assert_equal(restored.to_dict(), proposal.to_dict())
	TestSupport.assert_equal(restored.desired.total_share(), 100)
	TestSupport.assert_equal(restored.desired.jump_rotations.lutz, 1)
