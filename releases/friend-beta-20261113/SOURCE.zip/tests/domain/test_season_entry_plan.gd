extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const SeasonEntryPlan = preload("res://src/domain/season_entry_plan.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "season entry plan round trips independent copies", "callable": test_round_trip},
		{"name": "season entry plan rejects unknown status", "callable": test_unknown_status},
		{"name": "season entry plan rejects duplicate levels", "callable": test_duplicate_levels},
		{"name": "season entry plan rejects unavailable override", "callable": test_unavailable_override},
		{"name": "season entry plan rejects confirmed hard gate", "callable": test_confirmed_hard_gate},
	]

func test_round_trip() -> void:
	var source := {"event_a": _entry()}
	var result := SeasonEntryPlan.create("2018-19", source, 1)
	TestSupport.assert_equal(result.errors, [])
	var saved: Dictionary = result.plan.to_dict()
	source.event_a.status = "declined"
	var restored = SeasonEntryPlan.from_dict(saved)
	TestSupport.assert_equal(restored.to_dict(), saved)
	TestSupport.assert_equal(restored.entries.event_a.status, "proposed")

func test_unknown_status() -> void:
	var entry := _entry(); entry.status = "mystery"
	TestSupport.assert_equal(SeasonEntryPlan.create("2018-19", {"event_a": entry}).errors.has("entries.event_a.status 无效"), true)

func test_duplicate_levels() -> void:
	var entry := _entry(); entry.requested_levels = ["junior", "junior"]
	TestSupport.assert_equal(SeasonEntryPlan.create("2018-19", {"event_a": entry}).errors.has("entries.event_a.requested_levels 不能重复"), true)

func test_unavailable_override() -> void:
	var entry := _entry(); entry.player_override = "enter"; entry.available_adjustment_ids = []
	TestSupport.assert_equal(SeasonEntryPlan.create("2018-19", {"event_a": entry}).errors.has("entries.event_a.player_override 不在可选调整中"), true)

func test_confirmed_hard_gate() -> void:
	var entry := _entry(); entry.status = "confirmed"; entry.eligibility_snapshot.hard_gate_codes = ["age"]
	TestSupport.assert_equal(SeasonEntryPlan.create("2018-19", {"event_a": entry}).errors.has("entries.event_a 有硬性门槛，不能确认报名"), true)

func _entry() -> Dictionary:
	return {"status":"proposed","requested_levels":["junior"],"route":"club_nomination","funding_source":"club","coach_recommendation":"建议参赛","player_override":"","available_adjustment_ids":["enter","skip"],"eligibility_snapshot":{"eligible":true,"hard_gate_codes":[],"warnings":[]},"reason_codes":["development_value"]}
