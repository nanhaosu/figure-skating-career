extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"legacy fast preset corrects five-triple goal without editing custom goals","callable":test_legacy_fast_preset},
		{"name": "valid custom roadmap preserves compact goals", "callable": test_valid_custom_roadmap},
		{"name": "milestone ages must increase", "callable": test_milestone_ages_increase},
		{"name": "roadmap permits at most two unique priority jumps", "callable": test_priority_limit},
		{"name": "deferred jump must be valid and distinct", "callable": test_deferred_jump_validation},
		{"name": "roadmap round trips", "callable": test_round_trip},
	]

func test_legacy_fast_preset() -> void:
	var raw := {"route_id":"fast","milestones":[{"age":10,"rotations":2,"count":6},{"age":12,"rotations":3,"count":4}],"priority_jumps":[],"deferred_jump":"","risk_attitude":"aggressive"}
	var before: Dictionary = raw.duplicate(true)
	var restored = DevelopmentRoadmap.from_dict(raw)
	TestSupport.assert_equal(restored.milestones[1].count,5)
	TestSupport.assert_equal(restored.milestones[1].age,12)
	TestSupport.assert_equal(raw,before)
	raw.route_id = "custom"
	TestSupport.assert_equal(DevelopmentRoadmap.from_dict(raw).milestones[1].count,4)

func test_valid_custom_roadmap() -> void:
	var result := DevelopmentRoadmap.create("custom", [{"age": 10, "rotations": 2, "count": 6}, {"age": 12, "rotations": 3, "count": 3}], ["toe_loop", "salchow"], "lutz", "normal")
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.roadmap.priority_jumps, ["toe_loop", "salchow"])

func test_milestone_ages_increase() -> void:
	var result := DevelopmentRoadmap.create("custom", [{"age": 12, "rotations": 3, "count": 3}, {"age": 10, "rotations": 2, "count": 6}], [], "", "normal")
	TestSupport.assert_equal(result.roadmap, null)
	TestSupport.assert_equal(result.errors.has("成长节点年龄必须严格递增"), true)

func test_priority_limit() -> void:
	var result := DevelopmentRoadmap.create("fast", [{"age": 11, "rotations": 3, "count": 3}], ["toe_loop", "salchow", "loop"], "", "aggressive")
	TestSupport.assert_equal(result.roadmap, null)
	TestSupport.assert_equal(result.errors.has("优先跳跃最多选择两个"), true)

func test_deferred_jump_validation() -> void:
	var result := DevelopmentRoadmap.create("steady", [{"age": 10, "rotations": 2, "count": 5}], ["lutz"], "lutz", "cautious")
	TestSupport.assert_equal(result.roadmap, null)
	TestSupport.assert_equal(result.errors.has("暂缓跳跃不能同时是优先跳跃"), true)

func test_round_trip() -> void:
	var roadmap = DevelopmentRoadmap.create("balanced", [{"age": 10, "rotations": 2, "count": 6}, {"age": 13, "rotations": 3, "count": 4}], ["toe_loop"], "", "normal").roadmap
	TestSupport.assert_equal(DevelopmentRoadmap.from_dict(roadmap.to_dict()).to_dict(), roadmap.to_dict())
