extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "program preserves player element order", "callable": test_preserves_element_order},
		{"name": "short and free familiarity round trip independently", "callable": test_segment_familiarity_round_trip},
		{"name": "program rejects unknown segment", "callable": test_rejects_unknown_segment},
		{"name": "combination parts round trip on one jump unit", "callable": test_combination_round_trip},
		{"name": "program route design round trips", "callable": test_route_design_round_trip},
		{"name": "spin type survives save and old programs default to combination spin", "callable": test_spin_type_round_trip},
	]

func test_spin_type_round_trip() -> void:
	var spin = ProgramElement.from_dict({"element_id":"flying", "kind":"spin", "spin_code":"FCSp"})
	var program = SkatingProgram.create("typed-spins", "free", [spin]).program
	var restored = SkatingProgram.from_dict(program.to_dict())
	TestSupport.assert_equal(restored.elements[0].to_dict().get("spin_code", ""), "FCSp")
	var legacy = ProgramElement.from_dict({"element_id":"legacy", "kind":"spin"})
	TestSupport.assert_equal(legacy.to_dict().get("spin_code", ""), "CCoSp")

func test_route_design_round_trip() -> void:
	var program = SkatingProgram.create("route", "short", [ProgramElement.create("jump", "jump", "toe_loop", 1).element]).program
	program.route_complexity = "rich"
	program.choreography_quality = 73.0
	var restored = SkatingProgram.from_dict(program.to_dict())
	TestSupport.assert_equal(restored.route_complexity, "rich")
	TestSupport.assert_equal(restored.choreography_quality, 73.0)

func test_combination_round_trip() -> void:
	var jump = ProgramElement.create("combo", "jump", "lutz", 2).element
	TestSupport.assert_equal(jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 2}]), [])
	var program = SkatingProgram.create("combo-short", "short", [jump]).program
	var restored = SkatingProgram.from_dict(program.to_dict())
	TestSupport.assert_equal(restored.elements.size(), 1)
	TestSupport.assert_equal(restored.elements[0].combination_parts, [{"jump_id": "toe_loop", "rotations": 2}])

func test_preserves_element_order() -> void:
	var elements := [
		ProgramElement.create("spin-1", "spin").element,
		ProgramElement.create("jump-1", "jump", "toe_loop", 2).element,
		ProgramElement.create("step-1", "step_sequence").element,
	]
	var result := SkatingProgram.create("short-2014", "short", elements)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.program.elements[0].element_id, "spin-1")
	TestSupport.assert_equal(result.program.elements[1].element_id, "jump-1")
	TestSupport.assert_equal(result.program.elements[2].element_id, "step-1")

func test_segment_familiarity_round_trip() -> void:
	var short_program = SkatingProgram.create("short-2014", "short", [ProgramElement.create("s-jump", "jump", "salchow", 1).element]).program
	var free_program = SkatingProgram.create("free-2014", "free", [ProgramElement.create("f-jump", "jump", "toe_loop", 2).element]).program
	short_program.whole_run_familiarity = 42.0
	short_program.slot_familiarity = {"s-jump": 55.0}
	free_program.whole_run_familiarity = 18.0
	free_program.slot_familiarity = {"f-jump": 21.0}
	var restored_short = SkatingProgram.from_dict(short_program.to_dict())
	var restored_free = SkatingProgram.from_dict(free_program.to_dict())
	TestSupport.assert_equal(restored_short.to_dict(), short_program.to_dict())
	TestSupport.assert_equal(restored_free.to_dict(), free_program.to_dict())
	TestSupport.assert_equal(restored_short.whole_run_familiarity, 42.0)
	TestSupport.assert_equal(restored_free.whole_run_familiarity, 18.0)

func test_rejects_unknown_segment() -> void:
	var result := SkatingProgram.create("gala-2014", "gala", [])
	TestSupport.assert_equal(result.program, null)
	TestSupport.assert_equal(result.errors, ["未知节目分段：gala"])
