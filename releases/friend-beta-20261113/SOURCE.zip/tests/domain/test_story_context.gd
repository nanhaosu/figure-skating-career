extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const StoryContext = preload("res://src/domain/story_context.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "story context creates canonical 2014 women singles start", "callable": test_default_start},
		{"name": "story context round trips", "callable": test_round_trip},
		{"name": "story context rejects unsupported discipline", "callable": test_invalid_discipline},
		{"name": "story context rejects malformed federation", "callable": test_invalid_federation},
		{"name": "story context rejects fractional start year", "callable": test_fractional_year},
		{"name": "story context rejects non story time rules", "callable": test_invalid_rule_mode},
	]

func test_default_start() -> void:
	var context = StoryContext.women_singles_2014("CHN")
	TestSupport.assert_equal(context.to_dict(), {
		"discipline": "women_singles",
		"home_federation": "CHN",
		"start_year": 2014,
		"rule_mode": "story_time",
	})

func test_round_trip() -> void:
	var context = StoryContext.women_singles_2014("HKG")
	TestSupport.assert_equal(StoryContext.from_dict(context.to_dict()).to_dict(), context.to_dict())

func test_invalid_discipline() -> void:
	TestSupport.assert_equal(StoryContext.validate({"discipline": "pairs"}), "故事背景 discipline 目前只支持 women_singles")

func test_invalid_federation() -> void:
	var data: Dictionary = StoryContext.women_singles_2014("CHN").to_dict()
	data.home_federation = "China"
	TestSupport.assert_equal(StoryContext.validate(data), "故事背景 home_federation 必须是三位协会代码")

func test_fractional_year() -> void:
	var data: Dictionary = StoryContext.women_singles_2014("CHN").to_dict()
	data.start_year = 2014.5
	TestSupport.assert_equal(StoryContext.validate(data), "故事背景 start_year 必须是整数")

func test_invalid_rule_mode() -> void:
	var data: Dictionary = StoryContext.women_singles_2014("CHN").to_dict()
	data.rule_mode = "computer_date"
	TestSupport.assert_equal(StoryContext.validate(data), "故事背景 rule_mode 目前只支持 story_time")
