extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const CoachAssignment = preload("res://src/domain/coach_assignment.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "coach assignment round trip preserves private and visible facts", "callable": test_round_trip_preserves_private_and_visible_facts},
	]

func test_round_trip_preserves_private_and_visible_facts() -> void:
	var relationship := RelationshipState.new(42.0, 51.0, 35.0, 78.0)
	var assignment := CoachAssignment.new(
		"club_north_star",
		"coach_lin",
		relationship,
		["心理支持", "基础滑行"],
		["勾手跳教学在业内存在不同评价"],
		{"lutz_edge_guidance": -0.18, "psychological_attunement": 0.82},
	)
	var restored: RefCounted = CoachAssignment.from_dict(assignment.to_dict())
	TestSupport.assert_equal(restored.club_id, "club_north_star")
	TestSupport.assert_equal(restored.coach_id, "coach_lin")
	TestSupport.assert_equal(restored.known_strengths, ["心理支持", "基础滑行"])
	TestSupport.assert_equal(restored.known_concerns, ["勾手跳教学在业内存在不同评价"])
	TestSupport.assert_equal(restored.technical_tendencies, {"lutz_edge_guidance": -0.18, "psychological_attunement": 0.82})
	TestSupport.assert_equal(restored.relationship.to_dict(), relationship.to_dict())
	var public_data: Dictionary = restored.public_dict()
	TestSupport.assert_equal(public_data.has("technical_tendencies"), false)
	TestSupport.assert_equal(public_data.relationship, relationship.to_dict())
