extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const GameClock = preload("res://src/domain/game_clock.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const CareerState = preload("res://src/domain/career_state.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "quarter rolls into next year", "callable": test_quarter_rollover},
		{"name": "rule season changes at the third quarter", "callable": test_rule_season_boundary},
		{"name": "career state round trips", "callable": test_round_trip},
		{"name": "career foundation round trips", "callable": test_foundation_round_trip},
		{"name": "opening stage and non-scoring career goal round trip", "callable": test_opening_goal_round_trip},
		{"name": "training interruption preferences round trip", "callable": test_training_preferences_round_trip},
		{"name": "partial training period round trips without advancing the career clock", "callable": test_training_period_round_trip},
		{"name": "staged jump batch round trips integer stage", "callable": test_staged_batch_round_trip},
		{"name": "active and archived programs round trip", "callable": test_program_library_round_trip},
		{"name": "season entry state has stable defaults and round trips", "callable": test_season_state_round_trip},
		{"name": "formal competition world and record state round trips", "callable": test_formal_state_round_trip},
		{"name": "version thirteen state boundaries have exact defaults", "callable": test_version_thirteen_defaults},
		{"name": "version thirteen state boundaries survive two round trips", "callable": test_version_thirteen_round_trip_twice},
	]

func test_quarter_rollover() -> void:
	var clock := GameClock.new(2014, 4)
	clock.advance_quarter()
	TestSupport.assert_equal([clock.year, clock.quarter], [2015, 1])

func test_rule_season_boundary() -> void:
	TestSupport.assert_equal(GameClock.new(2018, 2).season_start_year(), 2017)
	TestSupport.assert_equal(GameClock.new(2018, 3).season_start_year(), 2018)
	TestSupport.assert_equal(GameClock.new(2018, 2).season_id(), "2017-18")
	TestSupport.assert_equal(GameClock.new(2018, 3).season_id(), "2018-19")

func test_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	career.relationships = {"guardian": RelationshipState.new(70, 55, 65, 35)}
	career.rng_step = 3
	career.history = [{"category": "body", "target": "acute_fatigue", "delta": 1.0, "cause_codes": ["training_load"], "summary_key": "fatigue_change"}]
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.to_dict(), career.to_dict())

func test_foundation_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	var serialized := career.to_dict()
	TestSupport.assert_equal(serialized.has("story_context"), true)
	TestSupport.assert_equal(serialized.has("random_streams"), true)
	if not serialized.has("story_context") or not serialized.has("random_streams"):
		return
	var restored := CareerState.from_dict(serialized)
	TestSupport.assert_equal(restored.story_context.to_dict(), serialized.story_context)
	TestSupport.assert_equal(restored.random_streams.to_dict(), serialized.random_streams)

func test_opening_goal_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007)
	career.opening_stage = "handoff"
	career.career_goal = {"id":"highest_stage", "chosen_clock":{"year":2014, "quarter":1}, "scoring_effect":false}
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.opening_stage, "handoff")
	TestSupport.assert_equal(restored.career_goal, career.career_goal)

func test_training_preferences_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	career.training_preferences.breakthrough_policy = "ask"
	career.training_preferences.minor_pain_policy = "ask"
	career.training_preferences.coach_strategy_policy = "summary"
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.training_preferences, career.training_preferences)

func test_training_period_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	career.training_period_state = {
		"weeks_elapsed": 5,
		"intent": {"mode":"safer", "requested_element_id":""},
		"plan": {"shares":{"rest":30}, "jump_rotations":{}},
		"started_clock": {"year":2014, "quarter":1},
	}
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.training_period_state, career.training_period_state)
	TestSupport.assert_equal(restored.clock.to_dict(), {"year":2014, "quarter":1})

func test_staged_batch_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	career.history = [{"category": "jump_attempt_batch", "jump_id": "toe_loop", "rotations": 2, "stage": 3.0, "attempts": 12, "successes": 2, "clean_successes": 1, "falls": 1, "pops": 2, "two_foot": 2, "hand_down": 1, "underrotated": 2, "downgraded": 2, "probability": 0.2, "cause_codes": []}]
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(typeof(restored.history[0].stage), TYPE_INT)
	TestSupport.assert_equal(restored.history[0].stage, 3)

func test_program_library_round_trip() -> void:
	var career := CareerState.new()
	career.clock = GameClock.new(2014, 1)
	career.athlete = AthleteState.new("林澄", 2007, "entry_interest_class", "family_supportive")
	var short_program = SkatingProgram.create("short-current", "short", [ProgramElement.create("spin", "spin").element]).program
	short_program.whole_run_familiarity = 35.0
	var old_program = SkatingProgram.create("short-old", "short", [ProgramElement.create("old-spin", "spin").element]).program
	career.active_programs = {"short": short_program.to_dict(), "free": {}}
	career.program_archive = [old_program.to_dict()]
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.active_programs, career.active_programs)
	TestSupport.assert_equal(restored.program_archive, career.program_archive)

func test_season_state_round_trip() -> void:
	var career := CareerState.new()
	TestSupport.assert_equal(career.season_state, {
		"season_id": "", "entry_plan": {}, "qualification_state": {}, "event_statuses": {},
	})
	career.season_state = {
		"season_id": "2018-19",
		"entry_plan": {
			"season_id": "2018-19", "proposal_version": 1,
			"entries": {"chn_club_beijing": {
				"status": "confirmed", "requested_levels": ["junior"],
				"route": "club_nomination", "funding_source": "club",
				"coach_recommendation": "建议参赛", "player_override": "enter",
				"available_adjustment_ids": ["enter", "skip"],
				"eligibility_snapshot": {"eligible": true, "hard_gate_codes": [], "warnings": []},
				"reason_codes": ["development_value"],
			}},
		},
		"qualification_state": {"cfsa_registered": true, "club_final_top_six": false},
		"event_statuses": {"chn_club_beijing": "confirmed"},
	}
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.season_state, career.season_state)

func test_formal_state_round_trip() -> void:
	var career := CareerState.new()
	career.world_athletes = {"chn_lin_xinning": {"name": "林心宁", "federation": "CHN", "career_seed": 901}}
	career.competition_archive = [{"event_id": "chn_national_gp_2018", "status": "complete", "player_rank": 18}]
	career.record_book = {
		"international": {"short": {"score": 58.24, "event_id": "jgp_test_2018"}},
		"all_formal": {"total": {"score": 162.80, "event_id": "chn_national_gp_2018"}},
	}
	career.ranking_state = {
		"domestic_points": 126,
		"isu_world": 0,
		"season_world": 0,
		"selection_evidence": {"chn_national_gp_2018": 18},
	}
	var restored := CareerState.from_dict(career.to_dict())
	TestSupport.assert_equal(restored.world_athletes, career.world_athletes)
	TestSupport.assert_equal(restored.competition_archive, career.competition_archive)
	TestSupport.assert_equal(restored.record_book, career.record_book)
	TestSupport.assert_equal(restored.ranking_state, career.ranking_state)

func test_version_thirteen_defaults() -> void:
	var career := CareerState.new()
	TestSupport.assert_equal(career.condition_state, {"growth_phase":"stable","growth_signals":[],"injuries":[],"medical_opinions":[],"psychology":{},"health_model_version":1,"function_limits":{},"rehabilitation":{},"pending_decision":{}})
	TestSupport.assert_equal(career.social_state, {"friendships":{},"fan_climate":"quiet","media_events":[],"commercial_commitments":[]})
	TestSupport.assert_equal(career.selection_state, {"applications":{},"assignments":{},"appeals":[]})
	TestSupport.assert_equal(career.event_ledger, [])
	TestSupport.assert_equal(career.world_state, {"season_id":"","generated_federations":[],"athlete_ids":[],"last_advanced_clock":{}})

func test_version_thirteen_round_trip_twice() -> void:
	var career := CareerState.new()
	career.condition_state = {"growth_phase":"active","growth_signals":[{"id":"height"}],"injuries":[{"id":"ankle"}],"medical_opinions":[{"id":"rest"}],"psychology":{"confidence":42}}
	career.social_state = {"friendships":{"friend-1":{"closeness":60}},"fan_climate":"warm","media_events":[{"id":"media-1"}],"commercial_commitments":[{"id":"sponsor-1"}]}
	career.selection_state = {"applications":{"jgp":{"status":"submitted"}},"assignments":{"jgp":"stage-1"},"appeals":[{"id":"appeal-1"}]}
	career.event_ledger = [{"id":"evt-1","details":{"codes":["created"]}}]
	career.world_state = {"season_id":"2018-19","generated_federations":["CHN","JPN"],"athlete_ids":["chn-1","jpn-1"],"last_advanced_clock":{"year":2018,"quarter":3}}
	var once := CareerState.from_dict(career.to_dict())
	var twice := CareerState.from_dict(once.to_dict())
	var expected: Dictionary = career.to_dict()
	expected.condition_state.merge({"health_model_version":1,"function_limits":{},"rehabilitation":{},"pending_decision":{}},false)
	TestSupport.assert_equal(twice.to_dict(), expected)
	once.condition_state.growth_signals[0].id = "mutated"
	TestSupport.assert_equal(career.condition_state.growth_signals[0].id, "height")
