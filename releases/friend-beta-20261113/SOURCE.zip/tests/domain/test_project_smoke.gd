extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "main scene is configured", "callable": test_main_scene_is_configured},
		{"name": "restored web runtime is complete", "callable": test_restored_web_runtime_is_complete},
	]

func test_main_scene_is_configured() -> void:
	var project := ConfigFile.new()
	TestSupport.assert_equal(project.load("res://project.godot"), OK)
	TestSupport.assert_equal(project.get_value("application", "run/main_scene"), "res://src/app/main.tscn")

func test_restored_web_runtime_is_complete() -> void:
	var exports := ConfigFile.new()
	TestSupport.assert_equal(exports.load("res://export_presets.cfg"), OK)
	TestSupport.assert_equal(exports.get_value("preset.0", "platform"), "Web")
	TestSupport.assert_equal(exports.get_value("preset.0.options", "variant/thread_support"), false)
	TestSupport.assert_equal(exports.get_value("preset.0.options", "html/canvas_resize_policy"), 2)
	for directory in [".playwright-cli/*","output/*"]:
		TestSupport.assert_equal(str(exports.get_value("preset.0","exclude_filter")).contains(directory),true,"browser QA artifacts must not enter the shipped game package")
	TestSupport.assert_equal(FileAccess.file_exists("res://src/app/main.tscn"), true)
	TestSupport.assert_equal(FileAccess.file_exists("res://src/persistence/browser_durability_bridge.js"), true)
	TestSupport.assert_equal(FileAccess.file_exists("res://scripts/install_web_durability.ps1"), true)
	TestSupport.assert_equal(FileAccess.file_exists("res://scripts/web_smoke_check.ps1"), true)
	TestSupport.assert_equal(FileAccess.file_exists("res://assets/fonts/NotoSansCJKsc-Regular.otf"), true)
