extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const JumpFoundation = preload("res://src/domain/jump_foundation.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "new athlete has shared jump foundation", "callable": test_new_athlete_has_shared_jump_foundation},
		{"name": "jump foundation round trips", "callable": test_jump_foundation_round_trips},
	]

func test_new_athlete_has_shared_jump_foundation() -> void:
	var athlete := AthleteState.new()
	TestSupport.assert_equal(athlete.jump_foundation.takeoff_power, 25.0)
	TestSupport.assert_equal(athlete.jump_foundation.air_axis, 30.0)
	TestSupport.assert_equal(athlete.jump_foundation.landing_control, 25.0)

func test_jump_foundation_round_trips() -> void:
	var foundation = JumpFoundation.create()
	foundation.air_tightness = 41.5
	TestSupport.assert_equal(JumpFoundation.from_dict(foundation.to_dict()).to_dict(), foundation.to_dict())
