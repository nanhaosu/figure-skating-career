extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Judges = preload("res://src/content/judging_profile_repository.gd")
const World = preload("res://src/simulation/world_generation_service.gd")
const Sim = preload("res://src/simulation/formal_competition_simulator.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"2019 domestic and international events have nine judges and real scores","callable":real_scores},{"name":"missing judges cannot silently become zero-score archived competitions","callable":missing_panel}]
func real_scores() -> void:
	var c = F.formal_junior_career(9)
	var bundle := Bundle.load_bundle(2019,"women_singles","junior")
	World.ensure_season(c,bundle,9)
	var npc: Dictionary = c.world_athletes.values()[0]
	for event_id in ["cn_club_league_2019_stage_1","golden_spin_junior_2019"]:
		var event: Dictionary = bundle.calendar.events.filter(func(e): return e.event_id == event_id)[0]
		var panel := Judges.panel(event,9)
		T.assert_equal(panel.size(),9,"2019 event lacks nine judges: "+event_id)
		var rules: Dictionary = Bundle.competition_event(event).rules.short
		var result: Dictionary = load("res://src/simulation/formal_segment_simulator.gd").simulate(load("res://src/domain/athlete_state.gd").from_dict(npc.athlete),load("res://src/domain/skating_program.gd").from_dict(npc.short_program),{"risk":"balanced"},{"judge_profiles":panel},rules,9)
		T.assert_equal(result.errors,[])
		T.assert_equal(float(result.score.get("total",0))>0.0,true,"valid field must receive real TES/PCS")
func missing_panel() -> void:
	var c = F.formal_junior_career(9)
	var event: Dictionary = Bundle.load_bundle(2018,"women_singles","junior").calendar.events.filter(func(e): return e.event_id == "cn_club_league_2018_stage_1")[0]
	var session := Sim.create_session(c,event,c.active_programs,"balanced",9)
	session.judge_profiles = []
	session = Sim.complete_practice(session,"accept")
	session = Sim.lock_short(c,session)
	T.assert_equal(session.errors.is_empty(),false,"panel failure must propagate rather than award all-zero ranks")
	T.assert_equal(c.competition_archive,[])
