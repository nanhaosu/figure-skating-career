extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const Simulator = preload("res://src/simulation/club_decision_simulator.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "club resources can diverge from public rank", "callable": test_resources_diverge_from_rank},
		{"name": "club decision never changes technique directly", "callable": test_decision_is_not_training},
		{"name": "clear winner still receives a minimum opportunity", "callable": test_winner_floor},
	]

func test_resources_diverge_from_rank() -> void:
	var career := Fixtures.starting_career(120)
	var winner := Simulator.decide({"public_rank": 1, "total": 48.0}, {"priority": 0.0, "coach_favor": 10.0, "available_external_slots": 1}, career)
	var favorite := Simulator.decide({"public_rank": 2, "total": 46.0}, {"priority": 90.0, "coach_favor": 85.0, "available_external_slots": 1}, career)
	TestSupport.assert_equal(favorite.resource_changes.ice_access > winner.resource_changes.ice_access, true)
	TestSupport.assert_equal(favorite.decision_score > winner.decision_score, true)
	TestSupport.assert_equal(winner.observable_reasons.has("public_result"), true)
	TestSupport.assert_equal(favorite.observable_reasons.has("priority_treatment"), true)

func test_decision_is_not_training() -> void:
	var career := Fixtures.starting_career(121)
	var before := career.athlete.to_dict()
	Simulator.decide({"public_rank": 3, "total": 40.0}, {"priority": 70.0, "coach_favor": 80.0}, career)
	TestSupport.assert_equal(career.athlete.to_dict(), before)

func test_winner_floor() -> void:
	var career := Fixtures.starting_career(122)
	var result := Simulator.decide({"public_rank": 1, "total": 42.0}, {"priority": 0.0, "coach_favor": 0.0}, career)
	TestSupport.assert_equal(result.resource_changes.ice_access >= 1.0, true)
	TestSupport.assert_equal(result.review_requirement.is_empty(), true)
