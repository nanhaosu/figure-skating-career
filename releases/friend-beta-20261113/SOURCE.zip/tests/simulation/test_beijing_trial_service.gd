extends RefCounted
const T = preload("res://tests/test_support.gd")
const PATH := "res://src/simulation/beijing_trial_service.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"Beijing trials count best four complete totals and preserve the discarded score", "callable":best_four},
		{"name":"Beijing trial four completed starts suffice while three cannot qualify", "callable":minimum},
		{"name":"equal total discarded trials favor TES then free score in counted four", "callable":discard_tie},
		{"name":"Beijing tied series compare counted TES then counted free then fixed lottery", "callable":series_ties},
		{"name":"trial source order and identical duplicate receipts never change totals or lottery", "callable":repeatable},
		{"name":"changed duplicate incomplete or invalid trial source cannot silently alter the series", "callable":invalid},
		{"name":"five canonical Beijing trials resolve full senior short and free rules on approved game dates", "callable":canonical_events},
		{"name":"open Beijing enrollment confirms five starts without prior results or Olympic TES and replays once", "callable":open_enrollment},
		{"name":"trial enrollment rejects underage missing grade and illegal programmes without mutation", "callable":admission_gates},
		{"name":"Beijing trial roster retains enrolled Chinese identities instead of padding thirty random starters", "callable":enrolled_roster},
		{"name":"five real SP FS archives and dated intervals produce the actual best-four standings", "callable":five_real_competitions},
	]

func _service():
	T.assert_equal(FileAccess.file_exists(PATH),true,"five actual competitions need a shared series aggregator")
	return load(PATH) if FileAccess.file_exists(PATH) else null

func canonical_events() -> void:
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","senior")
	T.assert_equal(bundle.errors,[])
	var dates := ["2021-12-18","2021-12-30","2022-01-01","2022-01-13","2022-01-15"]
	for index in 5:
		var id := "cn_beijing_trial_%d_2021" % (index+1)
		var found: Array = bundle.get("calendar",{}).get("events",[]).filter(func(event):return event.event_id == id)
		T.assert_equal(found.size(),1,id+" must be a real canonical event")
		if found.size() != 1: continue
		T.assert_equal(found[0].start_date,dates[index])
		T.assert_equal(found[0].end_date,dates[index])
		T.assert_equal(found[0].date_precision,"game_schedule")
		T.assert_equal(found[0].level_options,["senior"])
		var resolved: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event(found[0])
		T.assert_equal(resolved.errors,[])
		if resolved.errors.is_empty():
			T.assert_equal(resolved.rules.has("short") and resolved.rules.has("free"),true)
			T.assert_equal(resolved.event.competition_policy.free_cut,0,"all enrolled athletes must be able to complete both segments")

func _entrant():
	var fixture = load("res://tests/integration/test_dual_level_programs.gd").new()
	var c = fixture._career()
	fixture._ready(c)
	c.clock.quarter = 4
	c.certification_state.national_technical_grade = 7
	return c

func open_enrollment() -> void:
	var api = _service()
	T.assert_equal(api.new().has_method("enroll"),true,"series enrollment must be a real persistent operation")
	if not api.new().has_method("enroll"): return
	var c = _entrant()
	T.assert_equal(c.competition_archive.is_empty(),true)
	var result: Dictionary = api.enroll(c,"beijing2022_women_trials","open-player")
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	T.assert_equal(c.beijing_trial_series.player_choice,"enrolled")
	T.assert_equal(c.beijing_trial_series.entrant_ids.has("player"),true)
	for id in api.event_ids(): T.assert_equal(c.season_state.entry_plan.entries[id].status,"confirmed")
	var before: Dictionary = c.to_dict()
	T.assert_equal(api.enroll(c,"beijing2022_women_trials","open-player").ok,true)
	T.assert_equal(c.to_dict(),before)
	var repo = load("res://src/persistence/save_repository.gd")
	T.assert_equal(repo.save(c,"user://beijing-open-enrollment-v1.json").ok,true)
	var read: Dictionary = repo.load_save("user://beijing-open-enrollment-v1.json")
	T.assert_equal(read.ok,true)
	if read.ok: T.assert_equal(read.career.beijing_trial_series,c.beijing_trial_series)

func admission_gates() -> void:
	var api = _service()
	if not api.new().has_method("enroll"): T.assert_equal(false,true,"enrollment gate missing");return
	for variant in ["age","grade","programme"]:
		var c = _entrant()
		if variant == "age": c.athlete.birth_year = 2008;c.athlete.birth_date = {}
		elif variant == "grade": c.certification_state.national_technical_grade = 6
		else:
			c.season_program_plan.programs_by_level.senior.free = {}
		var before: Dictionary = c.to_dict()
		var result: Dictionary = api.enroll(c,"beijing2022_women_trials","rejected-"+variant)
		T.assert_equal(result.ok,false,variant)
		T.assert_equal(c.to_dict(),before,"failed admission must not confirm partial series")

func enrolled_roster() -> void:
	var c = _entrant()
	var api = _service()
	if not api.new().has_method("enroll"): T.assert_equal(false,true,"enrollment missing");return
	T.assert_equal(api.enroll(c,"beijing2022_women_trials","real-field").ok,true)
	T.assert_equal(c.beijing_trial_series.entrant_ids.size()>1,true,"the player cannot win a manufactured one-person field")
	var enrolled: Array = c.beijing_trial_series.entrant_ids.duplicate()
	var roster_api = load("res://src/simulation/formal_roster_generator.gd")
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	for id in ["cn_beijing_trial_1_2021","cn_beijing_trial_5_2021"]:
		var event: Dictionary = bundle.calendar.events.filter(func(e):return e.event_id == id)[0]
		var field: Dictionary = roster_api.build(c,event,99200,34,true)
		T.assert_equal(field.errors,[])
		if not field.errors.is_empty(): continue
		var actual: Array = []
		for row in field.roster:
			actual.append(row.athlete_id)
			T.assert_equal(row.federation,"CHN")
		actual.sort(); var expected: Array = enrolled.duplicate();expected.sort()
		T.assert_equal(actual,expected,"all five races use the same open enrollment, not a new padded pool")

func five_real_competitions() -> void:
	var api = _service()
	T.assert_equal(api.new().has_method("standings"),true,"standings must consume actual archived segments")
	if not api.new().has_method("standings"): return
	var c = _entrant()
	c.condition_state.growth_phase = "adapted"
	T.assert_equal(api.enroll(c,"beijing2022_women_trials","play-five").ok,true)
	var shares: Dictionary = load("res://tests/fixtures.gd").percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.rest = 100
	c.last_generated_plan = load("res://src/domain/training_plan.gd").create(shares).plan.to_dict()
	var commands = load("res://src/simulation/career_command_service.gd")
	var begun: Dictionary = commands.apply(c,{"type":"begin_dated_training"})
	T.assert_equal(begun.ok,true,begun.get("error",""))
	if not begun.ok: return
	c = begun.career
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var scores: Array = []
	var calendar: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	calendar.calendar.events = calendar.calendar.events.filter(func(event):return api.event_ids().has(event.event_id))
	var coordinator = load("res://src/simulation/season_progression_service.gd")
	for index in 5:
		var id := "cn_beijing_trial_%d_2021" % (index+1)
		var date: String = ["2021-12-18","2021-12-30","2022-01-01","2022-01-13","2022-01-15"][index]
		print("BEIJING_CHAIN begin ",id," ticks=",Time.get_ticks_msec())
		var trained: Dictionary = coordinator.advance_to_next_node(c,calendar,func(_candidate):return true)
		T.assert_equal(trained.errors,[])
		if not trained.errors.is_empty(): return
		c = trained.career
		T.assert_equal(trained.stop_node.get("event_id"),id)
		T.assert_equal(trained.stop_node.get("kind"),"competition_check_in","existing season coordinator must reach the actual next trial, not another registration")
		if trained.stop_node.get("kind") != "competition_check_in": return
		var event: Dictionary = {"event_id":id,"ruleset_season_start_year":2021,"competition_level":"senior"}
		var resolved: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_for_career(c,event)
		T.assert_equal(resolved.errors,[])
		if not resolved.errors.is_empty(): return
		var programs: Dictionary = load("res://src/simulation/season_program_service.gd").programs_for_event(c,resolved.event)
		var race: Dictionary = sim.create_session(c,resolved.event,programs,"balanced",99300+index,34)
		race = sim.lock_short(c,sim.complete_practice(race,"accept"))
		if race.get("status") != "complete": race = sim.lock_free(c,race,"keep")
		T.assert_equal(race.get("errors",[]),[])
		T.assert_equal(race.get("status"),"complete")
		T.assert_equal(race.free_results.size(),c.beijing_trial_series.entrant_ids.size())
		if race.get("status") != "complete": return
		var short: Dictionary = race.short_results.player.score
		var free: Dictionary = race.free_results.player.score
		scores.append(int(round((float(short.total)+float(free.total))*100)))
		c.competition_state = race
		var consumed: Dictionary = commands.apply(c,{"type":"acknowledge_formal_result"})
		T.assert_equal(consumed.ok,true,consumed.get("error",""))
		if not consumed.ok: return
		c = consumed.career
		T.assert_equal(c.competition_timeline.date,date)
		T.assert_equal(c.competition_state.is_empty(),true)
		T.assert_equal(c.beijing_trial_series.event_receipts.has(id),true,"closing an actual result must settle its immutable trial source before the next race")
		if not c.beijing_trial_series.event_receipts.has(id): return
		print("BEIJING_CHAIN acknowledged ",id," ticks=",Time.get_ticks_msec())
	var table: Dictionary = api.standings(c,"2022-01-15")
	print("BEIJING_CHAIN final table ticks=",Time.get_ticks_msec())
	T.assert_equal(table.errors,[])
	if not table.errors.is_empty(): return
	var row: Dictionary = table.rows.filter(func(r):return r.athlete_id == "player")[0]
	scores.sort();scores.reverse()
	T.assert_equal(row.completed,5)
	T.assert_equal(row.total,(scores[0]+scores[1]+scores[2]+scores[3])/100.0)
	T.assert_equal(row.discarded_event_ids.size(),1)
	T.assert_equal(c.clock.to_dict(),{"year":2022,"quarter":1})
	T.assert_equal(c.history.any(func(r):return r.get("category") == "dated_training" and r.get("date") in ["2021-12-18","2021-12-30","2022-01-01","2022-01-13","2022-01-15"]),false)
	var earlier: Dictionary = api.standings(c,"2022-01-14")
	T.assert_equal(earlier.errors,[])
	if earlier.errors.is_empty(): T.assert_equal(earlier.rows.filter(func(r):return r.athlete_id == "player")[0].completed,4)
	var report: Dictionary = load("res://src/presentation/post_competition_presenter.gd").build(c,c.competition_archive.back())
	print("BEIJING_CHAIN report ticks=",Time.get_ticks_msec())
	var text := str(report.consequences.text)
	T.assert_equal(text.contains("最好四场") and text.contains("%.2f" % row.total),true,"existing post-race page must show actual series standing, not an irrelevant domestic zero")
	T.assert_equal(text.contains("国内积分"),false)
	T.assert_equal(text.contains("已入选"),false,"series score alone cannot announce Olympic dispatch")
	T.assert_equal(api.new().has_method("finalize"),true,"real series must connect to audited final dispatch")
	if not api.new().has_method("finalize"): return
	var interim: Dictionary = api.finalize(c,"2022-01-15")
	T.assert_equal(interim.status,"pending","TES cutoff still leaves a preparation window after the fifth trial")
	var advanced: Dictionary = commands.apply(c,{"type":"advance_dated_training","target_date":"2022-01-24"})
	print("BEIJING_CHAIN Jan24 training ticks=",Time.get_ticks_msec())
	T.assert_equal(advanced.ok,true,advanced.get("error",""))
	if not advanced.ok: return
	c = advanced.career
	T.assert_equal(api.finalize(c,"2022-01-24").status,"pending","unknown country places cannot be replaced by historical one-place assumption")
	# Controlled full-protocol quota/TES fixtures isolate the final consumer;
	# these are NOT a claim of a naturally qualified Olympic career.
	var quota_archive: Dictionary = load("res://tests/integration/test_olympic_quota_archives.gd").new()._archive()
	var quota: Dictionary = load("res://src/simulation/olympic_quota_service.gd").settle(c,quota_archive)
	T.assert_equal(quota.errors,[])
	T.assert_equal(c.olympic_quota_state.current.countries.CHN,3)
	c.competition_archive.append(load("res://tests/simulation/test_international_personal_eligibility.gd").new()._archive("isu_gpusa2021",23,40))
	var final: Dictionary = api.finalize(c,"2022-01-24")
	print("BEIJING_CHAIN finalized ticks=",Time.get_ticks_msec())
	T.assert_equal(final.ok,true,final.get("error",""))
	T.assert_equal(final.status,"confirmed")
	T.assert_equal(final.selected_ids,["player"],"three country places cannot manufacture other athletes' missing international TES")
	T.assert_equal(c.beijing_trial_series.status,"finalized")
	var before: Dictionary = c.to_dict()
	T.assert_equal(api.finalize(c,"2022-01-24").selected_ids,["player"])
	T.assert_equal(c.to_dict(),before)
	var repo = load("res://src/persistence/save_repository.gd")
	print("BEIJING_CHAIN before disk ticks=",Time.get_ticks_msec())
	T.assert_equal(repo.save(c,"user://beijing-five-finalized-v3.json").ok,true)
	print("BEIJING_CHAIN saved ticks=",Time.get_ticks_msec())
	var read: Dictionary = repo.load_save("user://beijing-five-finalized-v3.json")
	print("BEIJING_CHAIN loaded ticks=",Time.get_ticks_msec())
	T.assert_equal(read.ok,true)
	if read.ok: T.assert_equal(read.career.beijing_trial_series,c.beijing_trial_series)
	print("BEIJING_CHAIN done ticks=",Time.get_ticks_msec())

func _rows(id: String,scores: Array,tes: float = 100.0,free_score: float = 120.0) -> Array:
	var rows: Array = []
	for index in scores.size():
		rows.append({"athlete_id":id,"event_id":"cn_beijing_trial_%d_2021"%(index+1),"total_score":float(scores[index]),"tes":tes,"free_score":free_score,"complete":true})
	return rows

func best_four() -> void:
	var s = _service()
	if s == null: return
	var result: Dictionary = s.aggregate(_rows("player",[210,205,200,190,100]),900)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.rows[0].total,805.0)
	T.assert_equal(result.rows[0].counted_event_ids,["cn_beijing_trial_1_2021","cn_beijing_trial_2_2021","cn_beijing_trial_3_2021","cn_beijing_trial_4_2021"])
	T.assert_equal(result.rows[0].discarded_event_ids,["cn_beijing_trial_5_2021"])
	T.assert_equal(result.rows[0].completed,5)

func minimum() -> void:
	var s = _service()
	if s == null: return
	var result: Dictionary = s.aggregate(_rows("four",[210,205,200,190])+_rows("three",[250,240,230]),900)
	var four: Dictionary = result.rows.filter(func(r):return r.athlete_id == "four")[0]
	var three: Dictionary = result.rows.filter(func(r):return r.athlete_id == "three")[0]
	T.assert_equal(four.eligible,true)
	T.assert_equal(four.total,805.0)
	T.assert_equal(three.eligible,false)
	T.assert_equal(three.completed,3)

func discard_tie() -> void:
	var s = _service()
	if s == null: return
	var rows := _rows("player",[210,205,200,190,190])
	rows[4].tes = 110.0
	var result: Dictionary = s.aggregate(rows,900)
	T.assert_equal(result.rows[0].counted_event_ids.has("cn_beijing_trial_5_2021"),true)
	T.assert_equal(result.rows[0].discarded_event_ids,["cn_beijing_trial_4_2021"])
	rows[3].tes = 110.0
	rows[3].free_score = 125.0
	result = s.aggregate(rows,900)
	T.assert_equal(result.rows[0].discarded_event_ids,["cn_beijing_trial_5_2021"])

func series_ties() -> void:
	var s = _service()
	if s == null: return
	var rows := _rows("lower",[200,200,200,200],99)+_rows("higher",[200,200,200,200],100)
	T.assert_equal(s.aggregate(rows,900).rows[0].athlete_id,"higher")
	rows = _rows("lower",[200,200,200,200],100,119)+_rows("higher",[200,200,200,200],100,120)
	T.assert_equal(s.aggregate(rows,900).rows[0].athlete_id,"higher")
	rows = _rows("a",[200,200,200,200])+_rows("b",[200,200,200,200])
	var first: Dictionary = s.aggregate(rows,900)
	var second: Dictionary = s.aggregate(JSON.parse_string(JSON.stringify(rows)),900)
	T.assert_equal(first.rows[0].athlete_id,second.rows[0].athlete_id)
	T.assert_equal(first.rows[0].lottery_key,second.rows[0].lottery_key)

func repeatable() -> void:
	var s = _service()
	if s == null: return
	var rows := _rows("player",[210,205,200,190,100])
	var expected: Dictionary = s.aggregate(rows,900)
	rows.append(rows[0].duplicate(true))
	rows.reverse()
	var actual: Dictionary = s.aggregate(rows,900)
	T.assert_equal(actual.errors,[])
	T.assert_equal(actual.rows,expected.rows)

func invalid() -> void:
	var s = _service()
	if s == null: return
	for mode in ["changed","partial","wrong_event","nan","negative"]:
		var rows := _rows("player",[210,205,200,190,100])
		match mode:
			"changed":
				var duplicate: Dictionary = rows[0].duplicate(true)
				duplicate.total_score = 999.0
				rows.append(duplicate)
			"partial": rows[0].complete = false
			"wrong_event": rows[0].event_id = "cn_beijing_trial_1_2022"
			"nan": rows[0].tes = NAN
			"negative": rows[0].total_score = -1.0
		T.assert_equal(s.aggregate(rows,900).errors.is_empty(),false,mode)
