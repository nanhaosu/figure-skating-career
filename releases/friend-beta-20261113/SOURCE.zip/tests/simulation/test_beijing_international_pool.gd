extends RefCounted
const T = preload("res://tests/test_support.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const W = preload("res://src/simulation/world_generation_service.gd")
const A = preload("res://src/domain/athlete_state.gd")
const P = preload("res://src/domain/skating_program.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")
const V = preload("res://src/simulation/program_validator.gd")
const Sim = preload("res://src/simulation/formal_segment_simulator.gd")
const Scoring = preload("res://src/content/formal_scoring_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"Beijing era federation catalogs describe fictional distinct pools with seasonal provenance","callable":_catalogs},
		{"name":"international entrants have varied reserves rather than universal triple axels","callable":_reserves},
		{"name":"rare international difficulty enters legal programs and retains mastered lower rotations","callable":_programs},
		{"name":"invalid international generation probabilities fail closed","callable":_invalid},
		{"name":"season catalog rejects missing or unlinked international generation models","callable":_catalog_invalid},
		{"name":"international advanced entrant spins are trained in actual scored programs","callable":_spin_performance},
		{"name":"advanced international presentation does not keep child expression defaults","callable":_artistic_performance},
	]

func _catalogs() -> void:
	for year in [2020,2021]:
		var loaded = B._load_federation_profiles(year,"women_singles")
		T.assert_equal(loaded.errors,[])
		if not loaded.errors.is_empty():return
		T.assert_equal(loaded.profiles.size()>=8,true)
		T.assert_equal(loaded.profiles.RUS.pool_size>loaded.profiles.CHN.pool_size,true)
		T.assert_equal(loaded.profiles.JPN.mean_strength>loaded.profiles.HKG.mean_strength,true)
		for fed in loaded.profiles:
			if fed == "CHN":continue
			T.assert_equal(loaded.profiles[fed].has("technical_generation"),true)

func _reserves() -> void:
	var loaded = B._load_federation_profiles(2021,"women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	for fed in ["RUS","JPN","USA","KOR","BEL","HKG","TPE"]:
		var axels := 0
		var signatures := {}
		for index in 48:
			var record = W.generate_record({},fed,loaded.profiles[fed],771,index,{"year":2021,"quarter":3},"2021-22",14)
			T.assert_equal(record.get("errors",[]),[])
			if record.has("errors"):return
			if int(record.athlete.jumps.axel.unlocked_rotations)>=3: axels+=1
			var signature := ""
			for jump in record.athlete.jumps.values():signature+=str(jump.unlocked_rotations)
			signatures[signature]=true
		T.assert_equal(axels<12,true,"A national pool is not a field of universal3A holders: "+fed)
		T.assert_equal(signatures.size()>1,true,"Difficulty must be athlete-specific")

func _programs() -> void:
	var loaded = B._load_federation_profiles(2021,"women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	var profile:Dictionary = loaded.profiles.RUS.duplicate(true)
	# Boundary fixture forces reserves, not results or actual historical people.
	profile.technical_generation.axel_triple_probability=1.0
	profile.technical_generation.quad_probability=1.0
	var record = W.generate_record({},"RUS",profile,771,1,{"year":2021,"quarter":3},"2021-22",14)
	T.assert_equal(record.get("errors",[]),[])
	if record.has("errors"):return
	var athlete = A.from_dict(record.athlete)
	T.assert_equal(athlete.jumps.axel.unlocked_rotations,3)
	T.assert_equal(athlete.jumps.values().any(func(j):return j.unlocked_rotations==4),true)
	for jump in athlete.jumps.values():
		for rotation in range(1,int(jump.unlocked_rotations)+1):
			T.assert_equal(int(jump.attempt_evidence[["","single","double","triple","quad"][rotation]].successes)>0,true)
	for segment in ["short","free"]:
		var program = P.from_dict(record[segment+"_program"])
		T.assert_equal(V.validate(program,athlete,Rules.for_season(2021,"junior",segment)),[])
		if segment == "short":T.assert_equal(program.elements.any(func(e):return e.kind=="jump" and e.rotations==4),false)
		else:T.assert_equal(program.elements.any(func(e):return e.kind=="jump" and e.rotations==4),true,"A rare reserve must affect actual program composition")

func _invalid() -> void:
	var loaded = B._load_federation_profiles(2021,"women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	for invalid in [-0.1,1.1,"high",null]:
		var profile:Dictionary = loaded.profiles.RUS.duplicate(true)
		profile.technical_generation.axel_triple_probability=invalid
		var record = W.generate_record({},"RUS",profile,771,1,{"year":2021,"quarter":3},"2021-22",14)
		T.assert_equal(record.get("errors",[]).is_empty(),false,"Malformed new content cannot revert to universal3A")

func _catalog_invalid() -> void:
	var original = JSON.parse_string(FileAccess.get_file_as_string("res://data/federations/2021_2022_women_singles.json"))
	T.assert_equal(original is Dictionary,true)
	if not original is Dictionary:return
	for mutation in ["missing","unlinked","probability"]:
		var data:Dictionary = original.duplicate(true)
		if mutation=="missing":data.federation_profiles.RUS.erase("technical_generation")
		elif mutation=="unlinked":data.federation_profiles.RUS.technical_generation.source_ids=["not-a-source"]
		else:data.federation_profiles.RUS.technical_generation.quad_probability=2.0
		T.assert_equal(B._validate_federation_catalog(data,2021,"women_singles").is_empty(),false,"Invalid seasonal model: "+mutation)

func _spin_performance() -> void:
	var loaded = B._load_federation_profiles(2021,"women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	var profile:Dictionary=loaded.profiles.JPN.duplicate(true)
	profile.mean_strength=90.0
	profile.strength_deviation=0.0
	var record=W.generate_record({},"JPN",profile,771,1,{"year":2021,"quarter":3},"2021-22",15)
	T.assert_equal(record.get("errors",[]),[])
	if record.has("errors"):return
	var judges:Array=[]
	for i in 9:judges.append({"judge_id":str(i),"technical_bias":0.0,"pcs_bias":0.0,"affinity":0.0})
	var level_total:=0
	var spin_count:=0
	var spin_ids:Array = record.free_program.elements.filter(func(e):return e.kind=="spin").map(func(e):return e.element_id)
	for seed in [41,42,43,44]:
		var result=Sim.simulate(A.from_dict(record.athlete),P.from_dict(record.free_program),{"risk":"balanced"},{"judge_profiles":judges},{"segment_rules":Rules.for_season(2021,"junior","free"),"scoring_catalog":Scoring.load_catalog(2021,"women_singles").catalog},seed)
		T.assert_equal(result.errors,[])
		if not result.errors.is_empty():return
		for element in result.protocol.element_scores:
			if spin_ids.has(element.element_id):
				level_total+=int(element.final_level)
				spin_count+=1
	T.assert_equal(spin_count,12)
	T.assert_equal(level_total>=36,true,"An advanced international entrant cannot retain novice spin foundations")

func _artistic_performance() -> void:
	var loaded=B._load_federation_profiles(2021,"women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	var profile:Dictionary=loaded.profiles.JPN.duplicate(true)
	profile.mean_strength=90.0
	profile.strength_deviation=0.0
	profile.technical_generation.axel_triple_probability=0.0
	var record=W.generate_record({},"JPN",profile,771,1,{"year":2021,"quarter":3},"2021-22",15)
	T.assert_equal(record.get("errors",[]),[])
	if record.has("errors"):return
	var judges:Array=[]
	for i in 9:judges.append({"judge_id":str(i),"technical_bias":0.0,"pcs_bias":0.0,"affinity":0.0})
	var performance_total:=0.0
	var interpretation_total:=0.0
	for seed in [41,42,43,44]:
		var result=Sim.simulate(A.from_dict(record.athlete),P.from_dict(record.free_program),{"risk":"balanced"},{"judge_profiles":judges},{"segment_rules":Rules.for_season(2021,"junior","free"),"scoring_catalog":Scoring.load_catalog(2021,"women_singles").catalog},seed)
		T.assert_equal(result.errors,[])
		if not result.errors.is_empty():return
		performance_total+=float(result.protocol.component_scores.performance.average)
		interpretation_total+=float(result.protocol.component_scores.interpretation.average)
	T.assert_equal(performance_total>=24.0,true,"Actual performance PCS must reflect developed expressive ability, not child20 default")
	T.assert_equal(interpretation_total>=24.0,true,"Interpretation PCS must not silently stay at child defaults")
