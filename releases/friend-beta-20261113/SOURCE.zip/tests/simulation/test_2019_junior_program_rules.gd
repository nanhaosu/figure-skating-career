extends RefCounted

const T = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")
const Validator = preload("res://src/simulation/program_validator.gd")
const Element = preload("res://src/domain/program_element.gd")
const Program = preload("res://src/domain/skating_program.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"2019 junior SP validates its prescribed jumps and distinct spins","callable":prescribed},
		{"name":"2019 coach proposal reports locked prescribed skills instead of hiding them","callable":draft},
		{"name":"persistent world programs follow the 2019 prescribed spin without player scaling","callable":world},
		{"name":"2019 junior SP permits camel alternative but forbids quad combinations","callable":boundaries},
		{"name":"2019 world adaptation repairs double loop collision without changing opponent identity","callable":double_collision}]

func boundaries() -> void:
	var athlete = Fixtures.formal_junior_career(94).athlete
	var rules := Rules.for_season(2019,"junior","short")
	var program = _program(); program.elements[5].spin_code = "CSp"
	T.assert_equal(Validator.validate(program,athlete,rules),[],"camel spin is an official alternative to layback")
	T.assert_equal(Program.from_dict(program.to_dict()) != null,true,"legal camel spin must survive programme persistence")
	athlete.jumps.toe_loop.unlocked_rotations = 4
	program = _program(); program.elements[1].rotations = 4
	T.assert_equal(Validator.validate(program,athlete,rules).is_empty(),false,"junior SP combination cannot start with a quad")
	program = _program(); program.elements[1].combination_parts[0].rotations = 4
	T.assert_equal(Validator.validate(program,athlete,rules).is_empty(),false,"junior SP combination cannot end with a quad")

func _program():
	var combo = Element.create("combo","jump","toe_loop",2).element
	combo.set_combination_parts([{"jump_id":"toe_loop","rotations":2}])
	var elements := [Element.create("axel","jump","axel",2).element,combo,Element.create("solo","jump","loop",2).element]
	for code in ["CCoSp","FSSp","LSp"]:
		var spin = Element.create(code,"spin").element
		spin.spin_code = code; elements.append(spin)
	elements.append(Element.create("steps","step_sequence").element)
	return Program.create("legal-2019","short",elements).program

func prescribed() -> void:
	var athlete = Fixtures.formal_junior_career(91).athlete
	var rules := Rules.for_season(2019,"junior","short")
	var program = _program()
	T.assert_equal(Validator.validate(program,athlete,rules),[])
	program.elements[0].rotations = 1
	T.assert_equal(Validator.validate(program,athlete,rules).is_empty(),false,"1A cannot satisfy the 2019 prescribed 2A")
	program = _program(); program.elements[2].jump_id = "salchow"
	T.assert_equal(Validator.validate(program,athlete,rules).is_empty(),false,"solo jump must be Lo")
	program = _program(); program.elements[1].combination_parts[0].rotations = 1
	T.assert_equal(Validator.validate(program,athlete,rules).is_empty(),false,"single follower cannot satisfy junior SP")
	program = _program(); program.elements[4].spin_code = "CCoSp"
	T.assert_equal(Validator.validate(program,athlete,rules).is_empty(),false,"three copies of an allowed spin are not the required three types")

func draft() -> void:
	var athlete = Fixtures.formal_junior_career(92).athlete
	var rules := Rules.for_season(2019,"junior","short")
	var proposal: Dictionary = load("res://src/simulation/program_draft_service.gd").propose(athlete,"short",rules,{},92)
	T.assert_equal(proposal.missing,[])
	athlete.jumps.axel.unlocked_rotations = 1
	proposal = load("res://src/simulation/program_draft_service.gd").propose(athlete,"short",rules,{},92)
	T.assert_equal(proposal.missing.is_empty(),false)

func world() -> void:
	var career = Fixtures.formal_junior_career(93)
	var bundles = load("res://src/content/season_bundle_repository.gd")
	var generator = load("res://src/simulation/world_generation_service.gd")
	T.assert_equal(generator.ensure_season(career,bundles.load_bundle(2018,"women_singles","junior"),93).errors,[])
	var ids: Array = career.world_athletes.keys()
	var previous_athlete: Dictionary = career.world_athletes[ids[0]].athlete.duplicate(true)
	T.assert_equal(generator.ensure_season(career,bundles.load_bundle(2019,"women_singles","junior"),93).errors,[])
	T.assert_equal(career.world_athletes[ids[0]].athlete,previous_athlete)
	for record in career.world_athletes.values():
		var athlete = load("res://src/domain/athlete_state.gd").from_dict(record.athlete)
		T.assert_equal(Validator.validate(Program.from_dict(record.short_program),athlete,Rules.for_season(2019,"junior","short")),[])

func double_collision() -> void:
	var athlete = Fixtures.formal_junior_career(95).athlete
	athlete.jumps.loop.unlocked_rotations = 2
	for jump in athlete.jumps.values(): jump.proficiency.double = 62.0
	var program = _program()
	program.elements[1].set_combination_parts([{"jump_id":"loop","rotations":2}])
	program.elements[2].jump_id = "flip"
	program.revision = 4
	program.whole_run_familiarity = 73.0
	program.choreography_quality = 64.0
	program.music = {"title":"retained season music"}
	for slot in program.slot_familiarity: program.slot_familiarity[slot] = 71.0
	var record := {"athlete_id":"retained-world-opponent","athlete":athlete.to_dict(),"career_seed":95,"short_program":program.to_dict()}
	var original: Dictionary = record.duplicate(true)
	var rules := Rules.for_season(2019,"junior","short")
	var generator = load("res://src/simulation/world_generation_service.gd")
	generator._apply_short_rules(record,rules)
	var repaired = Program.from_dict(record.short_program)
	T.assert_equal(Validator.validate(repaired,athlete,rules),[],"2Lo solo must not repeat 2Lo in another element")
	T.assert_equal(record.athlete,original.athlete,"programme adaptation must not grant skills")
	T.assert_equal(record.athlete_id,original.athlete_id)
	T.assert_equal(record.career_seed,original.career_seed)
	for key in ["program_id","revision","music","slot_familiarity","whole_run_familiarity","choreography_quality","route_complexity","draft_status","locked_segments"]:
		T.assert_equal(record.short_program[key],original.short_program[key],"retain programme metadata: " + key)
	for index in repaired.elements.size():
		T.assert_equal(repaired.elements[index].element_id,program.elements[index].element_id)
	var once: Dictionary = record.duplicate(true)
	generator._apply_short_rules(record,rules)
	T.assert_equal(record,once,"repeated migration must not redraw or rewrite programmes")
