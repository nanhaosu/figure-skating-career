extends RefCounted
const T = preload("res://tests/test_support.gd")
const World = preload("res://src/simulation/world_generation_service.gd")
const Profiles = preload("res://src/content/historical_athlete_profile_repository.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")
const Validator = preload("res://src/simulation/program_validator.gd")
const Athlete = preload("res://src/domain/athlete_state.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Fixtures = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2021 Chinese junior generation cannot fall back to universal triple axels","callable":test_field},
		{"name":"2021 domestic profiles use current evidence without rewriting earlier cohorts","callable":test_provenance},
		{"name":"2021 generation prior never removes an incumbent athlete's earned triple axel reserve","callable":test_incumbent_reserve},
	]

func test_field() -> void:
	var counts := {}
	var signatures := {}
	for index in 28:
		var record = World.generate_record({},"CHN",{"mean_strength":72,"strength_deviation":8,"resource_level":78,"late_bloomer_rate":0.13,"volatility":0.16},880,index,{"year":2021,"quarter":3},"2021-22",13+index%6)
		T.assert_equal(record.get("errors",[]),[])
		if record.has("errors"):return
		T.assert_equal(record.has("generation_profile_id"),true,"Missing2021 profile must not silently become generic all-triples")
		var athlete = Athlete.from_dict(record.athlete)
		T.assert_equal(athlete.jumps.axel.unlocked_rotations,2,"2021 domestic generation is not a field of3A holders")
		T.assert_equal(athlete.jumps.axel.proficiency.triple,0.0)
		T.assert_equal(int(athlete.jumps.axel.attempt_evidence.triple.successes),0)
		if not record.has("archetype"):return
		counts[record.archetype] = int(counts.get(record.archetype,0))+1
		var signature := ""
		for jump in athlete.jumps.values():signature += str(jump.unlocked_rotations)
		signatures[signature] = true
		for segment in ["short","free"]:
			var program = Program.from_dict(record[segment+"_program"])
			T.assert_equal(Validator.validate(program,athlete,Rules.for_season(2021,"junior",segment)),[])
	T.assert_equal(counts.keys().size(),3)
	T.assert_equal(int(counts.get("top",0))<=3,true,"Rare top packages cannot expand to the whole field")
	T.assert_equal(signatures.size()>=4,true)

func test_provenance() -> void:
	var catalog = Profiles.load_catalog()
	T.assert_equal(catalog.errors,[])
	for tier in ["domestic_development","domestic_junior","national"]:
		var old = Profiles.profile_for(2020,"CHN",15,tier,catalog)
		var current = Profiles.profile_for(2021,"CHN",15,tier,catalog)
		T.assert_equal(current.errors,[])
		if not current.errors.is_empty():return
		T.assert_equal(current.source_ids.has("cn_gp2021_protocol"),true)
		T.assert_equal(old.year_to,2020.0,"Old era boundaries must stay unchanged")
		T.assert_equal(current.id != old.id,true)
		T.assert_equal(Profiles.profile_for(2022,"CHN",15,tier,catalog).errors.is_empty(),false,"Do not extrapolate future evidence")

func test_incumbent_reserve() -> void:
	# Regression characterization: this is a generation prior, not an age/nation cap.
	var profile = {"mean_strength":72,"strength_deviation":8,"resource_level":78,"late_bloomer_rate":0.13,"volatility":0.16}
	var record = World.generate_record({},"CHN",profile,880,1,{"year":2021,"quarter":3},"2021-22",18)
	T.assert_equal(record.get("errors",[]),[])
	if record.has("errors"):return
	record.athlete.jumps.axel.unlocked_rotations = 3
	record.athlete.jumps.axel.proficiency.triple = 75.0
	record.athlete.jumps.axel.attempt_evidence.triple = {"attempts":120,"successes":80,"clean_successes":60,"falls":0,"pops":0,"two_foot":0,"hand_down":0,"underrotated":0,"downgraded":0,"first_success_clock":{"year":2021,"quarter":1}}
	var before = record.athlete.duplicate(true)
	var career = Fixtures.formal_junior_career(880)
	career.world_athletes = {record.athlete_id:record}
	career.world_state.generated_seasons = ["2021-22"]
	career.world_state.junior_cohort_seasons = ["2021-22"]
	var bundle = {"calendar":{"season_id":"2021-22"},"rules":load("res://src/content/historical_rule_repository.gd").load_season(2021,"women_singles").rules,"federation_profiles":{"CHN":profile},"errors":[]}
	var result = World.ensure_season(career,bundle,880)
	T.assert_equal(result.errors,[])
	T.assert_equal(career.world_athletes[record.athlete_id].athlete,before,"A historical sampling ceiling cannot erase an earned3A")
