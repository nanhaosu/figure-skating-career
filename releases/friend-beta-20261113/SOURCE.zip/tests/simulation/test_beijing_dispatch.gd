extends RefCounted
const T = preload("res://tests/test_support.gd")
var API = load("res://src/simulation/beijing_trial_service.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"junior primary calendar still schedules enrolled Beijing administrative deadline", "callable":junior_administrative_deadline},
		{"name":"fair trial dispatch skips missing personal qualification without rewriting trial rank", "callable":separate_layers},
		{"name":"two or three actual country places select corresponding qualified trial finishers", "callable":multiple_places},
		{"name":"three completed trials or medical withdrawal cannot secure Olympic dispatch", "callable":incomplete_or_injured},
		{"name":"unknown personal evidence remains pending instead of manufacturing a defeat", "callable":unknown_evidence},
		{"name":"actual finalization refuses to invent missing five-race evidence and future decisions", "callable":missing_sources},
		{"name":"season calendar inserts the final dispatch deadline before Olympic race dates", "callable":administrative_deadline},
		{"name":"confirmed final dispatch automatically registers the selected player without another fee or choice", "callable":automatic_entry},
		{"name":"explicit Olympic decline is not overwritten by a later domestic trial win", "callable":explicit_decline},
		{"name":"season coordinator automatically commits dispatch once and reaches the selected Olympic event", "callable":administrative_commit},
		{"name":"Olympic actual roster respects earned country seats and final Chinese selection without padding", "callable":olympic_field},
		{"name":"compacted persisted trial protocols retain all five starts and the same best four", "callable":packed_trials},
		{"name":"non-participating qualifier settles after actual free skate instead of revealing future country places", "callable":background_result_date},
	]

func _api() -> bool:
	T.assert_equal(API.new().has_method("allocate_dispatch"),true)
	return API.new().has_method("allocate_dispatch")

func _row(id: String,rank: int,status: String = "eligible",completed: int = 5,healthy: bool = true) -> Dictionary:
	return {"athlete_id":id,"rank":rank,"completed":completed,"personal_status":status,"medically_available":healthy,"reason_codes":[]}

func separate_layers() -> void:
	if not _api(): return
	var rows := [_row("trial-winner",1,"ineligible"),_row("second",2),_row("third",3)]
	var before: Array = rows.duplicate(true)
	var result: Dictionary = API.allocate_dispatch(rows,1)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.selected_ids,["second"])
	T.assert_equal(result.alternate_ids,["third"])
	T.assert_equal(rows,before)
	T.assert_equal(result.audit[0].rank,1,"missing TES is not a loss in the actual trial standings")

func multiple_places() -> void:
	if not _api(): return
	var rows := [_row("a",1),_row("b",2),_row("c",3),_row("d",4)]
	T.assert_equal(API.allocate_dispatch(rows,2).selected_ids,["a","b"])
	T.assert_equal(API.allocate_dispatch(rows,3).selected_ids,["a","b","c"])
	T.assert_equal(API.allocate_dispatch(rows,0).selected_ids,[])
	T.assert_equal(API.allocate_dispatch(rows,4).errors.is_empty(),false)

func incomplete_or_injured() -> void:
	if not _api(): return
	var result: Dictionary = API.allocate_dispatch([_row("three-only",1,"eligible",3),_row("injured",2,"eligible",5,false),_row("four-valid",3,"eligible",4)],1)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.selected_ids,["four-valid"])
	T.assert_equal(result.audit[0].reason_codes.has("fewer_than_four_complete_trials"),true)
	T.assert_equal(result.audit[1].reason_codes.has("medical_unavailable"),true)

func unknown_evidence() -> void:
	if not _api(): return
	var result: Dictionary = API.allocate_dispatch([_row("unclear",1,"unknown"),_row("known",2)],1)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.status,"pending")
	T.assert_equal(result.selected_ids,[])
	T.assert_equal(result.pending_ids,["unclear"])

func missing_sources() -> void:
	T.assert_equal(API.new().has_method("finalize"),true)
	if not API.new().has_method("finalize"): return
	var c = load("res://tests/simulation/test_beijing_trial_service.gd").new()._entrant()
	T.assert_equal(API.enroll(c,"beijing2022_women_trials","no-source-finalize").ok,true)
	c.clock.year = 2022;c.clock.quarter = 1
	var before: Dictionary = c.to_dict()
	var result: Dictionary = API.finalize(c,"2022-01-24")
	T.assert_equal(result.ok,true)
	T.assert_equal(result.status,"pending")
	T.assert_equal(result.selected_ids,[])
	T.assert_equal(c.to_dict(),before,"missing sources cannot grant country seats, fake races or write a final dispatch")
	T.assert_equal(API.finalize(c,"2023-01-24").ok,false)
	T.assert_equal(c.to_dict(),before)

func administrative_deadline() -> void:
	var c = load("res://tests/simulation/test_beijing_trial_service.gd").new()._entrant()
	T.assert_equal(API.enroll(c,"beijing2022_women_trials","calendar-decision").ok,true)
	c.clock.year = 2022;c.clock.quarter = 1
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","senior")
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.event_id == "isu_owg2022")
	var node: Dictionary = load("res://src/simulation/season_progression_service.gd")._next_event(c,bundle)
	T.assert_equal(node.get("kind"),"beijing_dispatch","the final selection cannot wait for the Olympic race itself")
	T.assert_equal(node.get("date"),"2022-01-24")

func junior_administrative_deadline() -> void:
	var c = load("res://tests/simulation/test_beijing_trial_service.gd").new()._entrant()
	T.assert_equal(API.enroll(c,"beijing2022_women_trials","junior-calendar-decision").ok,true)
	c.clock.year = 2022;c.clock.quarter = 1
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","junior")
	T.assert_equal(bundle.errors,[])
	# All ordinary events have already settled; group identity must not erase
	# the independent adult domestic series' administrative conclusion.
	for event in bundle.calendar.events:
		c.event_ledger.append({"kind":"season_event","season_id":"2021-22","event_id":event.event_id})
	var node: Dictionary = load("res://src/simulation/season_progression_service.gd")._next_event(c,bundle)
	T.assert_equal(node.get("kind"),"beijing_dispatch","junior primary must not silently abandon five senior domestic trials")
	T.assert_equal(node.get("date"),"2022-01-24")

# Controlled complete protocol tables isolate administrative plumbing.
# Actual five-SPFS/date/save consumers run separately in the trial suite.
func _controlled_ready(quota_archive_override: Dictionary = {}):
	var c = load("res://tests/simulation/test_beijing_trial_service.gd").new()._entrant()
	T.assert_equal(API.enroll(c,"beijing2022_women_trials","controlled-final-entry").ok,true)
	c.clock.year = 2022;c.clock.quarter = 1
	var shares: Dictionary = load("res://tests/fixtures.gd").percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.rest = 100
	c.last_generated_plan = load("res://src/domain/training_plan.gd").create(shares).plan.to_dict()
	for id in API.event_ids():
		var resolved: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event({"event_id":id,"ruleset_season_start_year":2021,"competition_level":"senior"})
		var sp := {"total":80.0,"tes":40.0,"pcs":40.0,"deductions":0.0}
		var fs := {"total":150.0,"tes":80.0,"pcs":70.0,"deductions":0.0}
		c.competition_archive.append({"record_version":1,"status":"complete","event_id":id,"season_id":"2021-22","event":resolved.event,"roster":[{"athlete_id":"player","federation":"CHN"}],"short_results":{"player":{"score":sp,"protocol":sp.duplicate(),"technical_review":{"review_events":[]}}},"free_results":{"player":{"score":fs,"protocol":fs.duplicate(),"technical_review":{"review_events":[]}}},"final_standings":[{"athlete_id":"player","federation":"CHN","total_score":230.0,"short_score":80.0,"free_score":150.0}]})
	var quota_archive: Dictionary = load("res://tests/integration/test_olympic_quota_archives.gd").new()._archive()
	if not quota_archive_override.is_empty(): quota_archive = quota_archive_override.duplicate(true)
	T.assert_equal(load("res://src/simulation/olympic_quota_service.gd").settle(c,quota_archive).errors,[])
	c.competition_archive.append(load("res://tests/simulation/test_international_personal_eligibility.gd").new()._archive("isu_gpusa2021",23,40))
	return c

func automatic_entry() -> void:
	var c = _controlled_ready()
	var money := float(c.athlete.resources.money)
	var result: Dictionary = API.finalize(c,"2022-01-24")
	T.assert_equal(result.ok,true,result.get("error",""))
	T.assert_equal(result.selected_ids,["player"])
	T.assert_equal(c.season_state.entry_plan.entries.get("isu_owg2022",{}).get("status"),"confirmed")
	T.assert_equal(c.selection_state.applications.has("isu_owg2022:enter"),true,"automatic entry needs an idempotent receipt")
	T.assert_equal(float(c.athlete.resources.money),money)

func explicit_decline() -> void:
	var c = _controlled_ready()
	var skipped: Dictionary = load("res://src/simulation/entry_application_service.gd").apply(c,{"event_id":"isu_owg2022","route_id":"skip"})
	T.assert_equal(skipped.ok,true,skipped.get("error",""))
	var result: Dictionary = API.finalize(c,"2022-01-24")
	T.assert_equal(result.ok,true)
	T.assert_equal(result.selected_ids,[],"winning domestic selection does not revoke an explicit Olympic decline")
	T.assert_equal(c.season_state.entry_plan.entries.isu_owg2022.status,"declined")

func administrative_commit() -> void:
	var c = _controlled_ready()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.event_id == "isu_owg2022" or API.event_ids().has(event.event_id))
	var service = load("res://src/simulation/season_progression_service.gd")
	var commits: Array = []
	var result: Dictionary = service.advance_to_next_node(c,bundle,func(candidate):commits.append(candidate);return true)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.career.beijing_trial_series.status,"finalized")
	T.assert_equal(result.career.beijing_trial_series.finalization.get("selected_ids"),["player"])
	T.assert_equal(result.stop_node.get("event_id"),"isu_owg2022")
	T.assert_equal(result.stop_node.get("kind") in ["competition_check_in","program_replacement","program_adjustment"],true,"selected athlete must not receive another registration decision")
	T.assert_equal(result.career.event_ledger.filter(func(event):return event.get("kind") == "beijing_dispatch_checked").size(),1)
	var replay_commits: Array = []
	var replay: Dictionary = service.advance_to_next_node(result.career,bundle,func(candidate):replay_commits.append(candidate);return true)
	T.assert_equal(replay.errors,[])
	T.assert_equal(replay_commits.size(),0)
	T.assert_equal(replay.career.to_dict()==result.career.to_dict(),true)

func olympic_field() -> void:
	var c = _controlled_ready()
	T.assert_equal(API.finalize(c,"2022-01-24").ok,true)
	var event: Dictionary = load("res://src/content/season_bundle_repository.gd").competition_event({"event_id":"isu_owg2022","ruleset_season_start_year":2021,"competition_level":"senior"}).event
	var field: Dictionary = load("res://src/simulation/formal_roster_generator.gd").build(c,event,90213,34,true)
	T.assert_equal(field.errors,[])
	if not field.errors.is_empty(): return
	var counts := {};var chinese: Array = []
	for row in field.roster:
		counts[row.federation] = int(counts.get(row.federation,0))+1
		if row.federation == "CHN": chinese.append(row.athlete_id)
	T.assert_equal(chinese,["player"],"winning a country place is not a dispatch for every domestic skater")
	for country in counts:
		var cap := int(c.olympic_quota_state.current.countries.get(country,0))
		if cap == 0: cap = int(c.olympic_quota_state.current.host_additional.get(country,{}).get("places",0))
		T.assert_equal(int(counts[country]) <= cap,true,"Olympic roster must not fabricate extra country places")
	T.assert_equal(field.roster.size()<=30,true,"do not pad Olympic field to the generic 34")

func packed_trials() -> void:
	var c = _controlled_ready()
	var original: Dictionary = API.standings(c,"2022-01-24")
	for index in c.competition_archive.size():
		c.competition_archive[index] = load("res://src/persistence/competition_archive_codec.gd").compact(c.competition_archive[index])
	var packed: Dictionary = API.standings(c,"2022-01-24")
	T.assert_equal(packed.errors,[])
	T.assert_equal(packed.rows,original.rows,"normal save compression cannot erase actual starts")
	T.assert_equal(packed.sources,original.sources,"normal compaction cannot falsely change an immutable race source")

func background_result_date() -> void:
	var c = _controlled_ready()
	c.clock.year = 2021;c.clock.quarter = 3
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","senior")
	bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.event_id == "isu_olympic_qualifier_nebelhorn_2021")
	var node: Dictionary = load("res://src/simulation/season_progression_service.gd")._next_event(c,bundle)
	T.assert_equal(node.kind,"event")
	T.assert_equal(node.date,"2021-09-25","country qualification result does not exist on September23 short programme day")
