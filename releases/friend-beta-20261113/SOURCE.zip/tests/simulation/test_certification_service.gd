extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const SeasonCalendarPlanner = preload("res://src/simulation/season_calendar_planner.gd")
const SERVICE_PATH := "res://src/simulation/certification_service.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"valid formal programs also count as grade preparation", "callable":test_formal_programs},
		{"name":"unlocked doubles are not a recorded technical grade", "callable":test_unlock_is_not_grade},
		{"name":"recorded grade remains valid after a skill decline", "callable":test_recorded_grade_persists},
		{"name":"assessment defers for health and never repeats in one quarter", "callable":test_health_deferral},
		{"name":"prepared athlete earns a stored grade through assessment", "callable":test_prepared_athlete_passes},
	]

func test_formal_programs() -> void:
	var career = Fixtures.formal_junior_career(925)
	var assessment: Dictionary = load(SERVICE_PATH).assess(career)
	TestSupport.assert_equal(assessment.evidence.legal_programs,2,"formal programs should not fail a teaching-group maximum element count")

func test_unlock_is_not_grade() -> void:
	var career = Fixtures.starting_career(921)
	for jump_id in ["toe_loop", "salchow", "loop"]: career.athlete.jumps[jump_id].unlocked_rotations = 2
	TestSupport.assert_equal(SeasonCalendarPlanner.qualification_state_for(career).national_technical_minimum, false)

func test_recorded_grade_persists() -> void:
	var career = Fixtures.starting_career(922)
	career.certification_state.national_technical_grade = 7
	TestSupport.assert_equal(SeasonCalendarPlanner.qualification_state_for(career).national_technical_minimum, true)
	TestSupport.assert_equal(career.to_dict().certification_state.national_technical_grade, 7)

func test_health_deferral() -> void:
	var service = load(SERVICE_PATH)
	TestSupport.assert_equal(service != null, true)
	if service == null: return
	var career = Fixtures.starting_career(923)
	career.clock.year = 2018
	career.athlete.body.acute_fatigue = 90.0
	var assessment: Dictionary = service.call("assess", career)
	TestSupport.assert_equal(assessment.status, "health_deferred")
	service.call("process_quarter", career)
	var count: int = career.certification_state.history.size()
	service.call("process_quarter", career)
	TestSupport.assert_equal(career.certification_state.history.size(), count)

func test_prepared_athlete_passes() -> void:
	var service = load(SERVICE_PATH)
	var career = Fixtures.starting_career(924)
	career.clock.year = 2018
	for jump_id in ["toe_loop", "salchow", "loop"]:
		var jump = career.athlete.jumps[jump_id]
		jump.unlocked_rotations = 2
		jump.proficiency.double = 100.0
		jump.consistency.training = 100.0
		jump.attempt_evidence.double.attempts = 20
		jump.attempt_evidence.double.clean_successes = 20
	for key in ["speed", "one_foot_stability", "deep_edge"]: career.athlete.skating[key] = 100.0
	for segment in ["short", "free"]:
		var proposed = preload("res://src/simulation/program_draft_service.gd").propose(career.athlete, segment, preload("res://src/content/internal_event_rules.gd").for_teaching_group(segment), {}, 924)
		career.active_programs[segment] = proposed.program.to_dict()
		career.active_programs[segment].whole_run_familiarity = 100.0
	TestSupport.assert_equal(service.call("assess", career).status, "ready")
	service.call("process_quarter", career)
	TestSupport.assert_equal(career.certification_state.national_technical_grade, 7)
	TestSupport.assert_equal(SeasonCalendarPlanner.qualification_state_for(career).national_technical_minimum, true)
