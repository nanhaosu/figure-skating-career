extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const Programs = preload("res://src/simulation/season_program_service.gd")
const Assignment = preload("res://src/simulation/international_assignment_service.gd")
const Presenter = preload("res://src/presentation/annual_selection_policy_presenter.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const POLICY := "res://src/simulation/annual_selection_policy_service.gd"
const REPO := "res://src/content/annual_selection_policy_repository.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"fresh season confirmation publishes exactly one immutable game policy", "callable":publication},
		{"name":"legacy confirmed season remains explicitly unfrozen and is not retroactively published", "callable":legacy},
		{"name":"frozen minimum and designated events drive actual eligibility and public roles", "callable":minimum_and_roles},
		{"name":"frozen World Junior weights and quarter drive actual selected athlete", "callable":weights_and_window},
		{"name":"best complete total ties use same-event free score independent of archive order", "callable":tie_order},
		{"name":"short-only cut cannot masquerade as a complete high merit result", "callable":cut_evidence},
		{"name":"frozen station and athlete start limits are consumed by assignment", "callable":start_limits},
		{"name":"frozen development coefficients alter selection without changing scores", "callable":development_coefficients},
		{"name":"native policy roundtrip and closed season retain canonical content hash", "callable":roundtrip_history},
		{"name":"next season publishes its own policy without overwriting historical announcement", "callable":next_season},
		{"name":"corrupt published policy fails closed in load computation and presentation", "callable":corruption},
		{"name":"malformed active and historical snapshots fail closed before commands", "callable":malformed},
		{"name":"snapshot container season bindings fail closed without template fallback", "callable":season_bindings},
		{"name":"closed policy remains effective before next season publishes", "callable":closed_effective},
		{"name":"actual segment presence distinguishes zero free score completion from a cut", "callable":actual_completeness},
		{"name":"optional NPC schedule fields are validated before legacy world compatibility", "callable":npc_optional_schema},
		{"name":"policy preview is detached and unsupported seasons do not borrow standards", "callable":readonly_unsupported},
	]

func _career():
	var c = F.formal_junior_career(8240)
	c.clock.year = 2019; c.clock.quarter = 3
	c.season_state.season_id = "2019-20"
	return c

func _confirm(c, receipt: String = "policy-first") -> Dictionary:
	var draft := Programs.preview(c,"2019-20","retain",c.active_programs,{})
	T.assert_equal(draft.errors,[])
	return Commands.apply(c,{"type":"confirm_season_program","draft":draft,"receipt_id":receipt})

func _published():
	var result := _confirm(_career())
	T.assert_equal(result.ok,true,result.get("error",""))
	T.assert_equal(result.career.season_state.has("selection_policy"),true)
	return result.career if result.ok and result.career.season_state.has("selection_policy") else null

func _api():
	T.assert_equal(FileAccess.file_exists(POLICY),true,"published policy consumer required")
	return load(POLICY) if FileAccess.file_exists(POLICY) else null

func _seal(c) -> void:
	c.season_state.selection_policy.content_sha256 = load(REPO).content_hash(c.season_state.selection_policy.payload)

func _row(id: String, total: float, free: float, event_id: String = "cn_club_league_2019_stage_1") -> Dictionary:
	return {"athlete_id":id,"name":id,"age":14,"federation":"CHN","eligible":true,"club_access":80.0,"results":[{"event_id":event_id,"total_score":total,"free_score":free}]}

func _context(kind: String = "jgp") -> Dictionary:
	return {"kind":kind,"bundle":{"calendar":{"calendar_year":2019,"season_id":"2019-20","events":[{"event_id":"station-a","event_family":"jgp_stage","end_date":"2019-09-30"},{"event_id":"station-b","event_family":"jgp_stage","end_date":"2019-10-30"}]}},"station_fields":{"station-a":60.0,"station-b":65.0}}

func publication() -> void:
	var c = _published()
	if c == null: return
	var frozen: Dictionary = c.season_state.selection_policy.duplicate(true)
	T.assert_equal(frozen.payload.source_kind,"game_setting")
	T.assert_equal(frozen.payload.season_id,"2019-20")
	T.assert_equal(frozen.payload.targets.world_junior.window.precision,"quarter")
	var repeated := _confirm(c,"policy-repeat")
	T.assert_equal(repeated.ok,true,repeated.get("error",""))
	T.assert_equal(repeated.career.season_state.selection_policy,frozen)
	T.assert_equal(repeated.career.event_ledger.filter(func(e):return e.get("kind") == "selection_policy_published").size(),1)
	T.assert_equal(c.season_state.selection_policy,frozen)

func legacy() -> void:
	var c = _career()
	c.season_program_plan = {"season_id":"2019-20","status":"confirmed","revision":1,"receipts":[],"programs":c.active_programs.duplicate(true),"targets":{}}
	var api = _api()
	if api == null: return
	var result: Dictionary = api.effective(c,2019)
	T.assert_equal(result.status,"legacy_unfrozen")
	var changed := _confirm(c)
	T.assert_equal(changed.ok,true,changed.get("error",""))
	T.assert_equal(changed.career.season_state.has("selection_policy"),false)
	var notice := Presenter.build(changed.career,{"season_id":"2019-20","events":[]})
	T.assert_equal(notice.announcements.contains("未冻结"),true)

func minimum_and_roles() -> void:
	var c = _published()
	if c == null: return
	var target: Dictionary = c.season_state.selection_policy.payload.targets.jgp
	target.minimum_score = 150.0
	target.designated_event_ids = ["cn_national_championships_2019"]
	_seal(c)
	var result := Assignment.resolve(c,[_row("under",140,90,"cn_national_championships_2019"),_row("wrong",180,110)],4,_context(),99)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.assignments,{})
	T.assert_equal(result.audit.policy.content_sha256,c.season_state.selection_policy.content_sha256)
	var view := Presenter.build(c,{"season_id":"2019-20","events":[{"event_id":"cn_national_championships_2019","scope":"domestic"},{"event_id":"cn_club_league_2019_stage_1","scope":"domestic"}]})
	T.assert_equal(view.event_roles.cn_national_championships_2019.jgp.role,"countable")
	T.assert_equal(view.event_roles.cn_club_league_2019_stage_1.jgp.role,"optional")
	T.assert_equal(view.announcements.contains("150"),true)

func weights_and_window() -> void:
	var c = _published()
	if c == null: return
	c.clock.year = 2020; c.clock.quarter = 1
	var target: Dictionary = c.season_state.selection_policy.payload.targets.world_junior
	target.weights = {"cn_national_championships_2019":0.2,"cn_grand_prix_u_series_2019":0.8}
	_seal(c)
	var a := _row("a",200,120,"cn_national_championships_2019")
	a.results.append({"event_id":"cn_grand_prix_u_series_2019","total_score":100,"free_score":60})
	var b := _row("b",110,65,"cn_national_championships_2019")
	b.results.append({"event_id":"cn_grand_prix_u_series_2019","total_score":160,"free_score":100})
	var selected := Assignment.resolve(c,[a,b],3,_context("world_junior"),99)
	T.assert_equal(selected.errors,[])
	T.assert_equal(selected.assignments.keys(),["b"],"frozen weights and one-place policy beat caller's three free slots")
	target.window.quarter = 2
	_seal(c)
	T.assert_equal(Assignment.world_selection_window_errors(c,2019).is_empty(),false)
	c.clock.quarter = 2
	T.assert_equal(Assignment.world_selection_window_errors(c,2019),[])

func tie_order() -> void:
	var c = _career()
	var a := _row("a",150,80)
	a.results.append({"event_id":"cn_club_league_2019_stage_2","total_score":150,"free_score":110})
	var first := Assignment.resolve(c,[a],1,_context(),99)
	a.results.reverse()
	var second := Assignment.resolve(c,[a],1,_context(),99)
	T.assert_equal(first.audit.candidate_rows[0].free_score,110.0)
	T.assert_equal(second.audit.candidate_rows[0].free_score,110.0)

func cut_evidence() -> void:
	var result := Assignment.resolve(_career(),[_row("cut",230,0)],1,_context(),99)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.assignments,{})
	T.assert_equal(result.audit.candidate_rows[0].eligible,false)

func start_limits() -> void:
	var c = _published()
	if c == null: return
	c.season_state.selection_policy.payload.targets.jgp.max_starts = 1
	_seal(c)
	var result := Assignment.resolve(c,[_row("a",160,100)],4,_context(),99)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.assignments.a.size(),1)

func roundtrip_history() -> void:
	var c = _published()
	if c == null: return
	var policy: Dictionary = c.season_state.selection_policy.duplicate(true)
	var path := "user://annual-policy-roundtrip-%d.json" % Time.get_ticks_usec()
	T.assert_equal(Save.save(c,path).ok,true)
	var loaded := Save.load_save(path)
	T.assert_equal(loaded.ok,true,str(loaded.get("errors",[])))
	if not loaded.ok: return
	T.assert_equal(loaded.career.season_state.selection_policy.content_sha256,policy.content_sha256)
	load("res://src/simulation/season_progression_service.gd")._close(loaded.career,{"calendar":{"season_id":"2019-20","calendar_year":2019}})
	T.assert_equal(loaded.career.season_state.season_history["2019-20"].season.selection_policy.content_sha256,policy.content_sha256)
	T.assert_equal(loaded.career.season_state.has("selection_policy"),false)

func next_season() -> void:
	var c = _published()
	if c == null: return
	var old_hash: String = c.season_state.selection_policy.content_sha256
	load("res://src/simulation/season_progression_service.gd")._close(c,{"calendar":{"season_id":"2019-20","calendar_year":2019}})
	c.clock.year = 2020; c.clock.quarter = 3
	var draft := Programs.preview(c,"2020-21","retain",c.active_programs,{})
	var result := Commands.apply(c,{"type":"confirm_season_program","draft":draft,"receipt_id":"next-policy"})
	T.assert_equal(result.ok,true,result.get("error",""))
	if not result.ok: return
	T.assert_equal(result.career.season_state.selection_policy.payload.season_id,"2020-21")
	T.assert_equal(result.career.season_state.season_history["2019-20"].season.selection_policy.content_sha256,old_hash)
	T.assert_equal(result.career.season_state.selection_policy.content_sha256 == old_hash,false)

func development_coefficients() -> void:
	var c = _published()
	if c == null: return
	var rows := [_row("leader-a",160,100),_row("leader-b",155,95),_row("leader-c",150,90),_row("merit-fourth",145,85),_row("rising",112,70),_row("steady",130,80)]
	for row in rows.slice(0,4): row.age = 17
	rows[4].results.append({"event_id":"cn_club_league_2019_stage_2","total_score":100,"free_score":60,"event_start_date":"2019-07-01"})
	rows[4].results[0].event_start_date = "2019-08-01"
	rows[5].results.append({"event_id":"cn_club_league_2019_stage_2","total_score":130,"free_score":80,"event_start_date":"2019-07-01"})
	rows[5].results[0].event_start_date = "2019-08-01"
	var context := _context()
	context.bundle.calendar.events = []
	for index in 8:
		var id := "station-%d" % index
		context.bundle.calendar.events.append({"event_id":id,"event_family":"jgp_stage","end_date":"2019-09-30"})
		context.station_fields[id] = 60.0
	var before: Array = rows.duplicate(true)
	var original := Assignment.resolve(c,rows,4,context,99)
	T.assert_equal(original.assignments.has("rising"),true)
	var d: Dictionary = c.season_state.selection_policy.payload.targets.jgp.development
	d.growth_factor = 0.0; d.age_factor = 0.0; d.access_factor = 0.0
	_seal(c)
	var changed := Assignment.resolve(c,rows,4,context,99)
	T.assert_equal(changed.assignments.has("steady"),true)
	T.assert_equal(changed.assignments.has("rising"),false)
	T.assert_equal(rows,before)

func malformed() -> void:
	var c = _published()
	if c == null: return
	var valid: Dictionary = c.season_state.selection_policy.duplicate(true)
	for bad in [42,{}, {"payload":42,"published_clock":{},"content_sha256":"bad"}]:
		c.season_state.selection_policy = bad
		T.assert_equal(load(POLICY).effective(c,2019).errors.is_empty(),false)
		T.assert_equal(Save.save(c,"user://annual-policy-malformed.json").ok,false)
	c.season_state.selection_policy = valid
	load("res://src/simulation/season_progression_service.gd")._close(c,{"calendar":{"season_id":"2019-20","calendar_year":2019}})
	c.season_state.season_history["2019-20"].season.selection_policy.content_sha256 = "bad"
	T.assert_equal(Save.save(c,"user://annual-policy-bad-history.json").ok,false)

func season_bindings() -> void:
	var c = _published()
	if c == null: return
	var valid: Dictionary = c.season_state.selection_policy.duplicate(true)
	c.season_state.selection_policy.payload = load(REPO).load_for_season("2018-19").policy
	_seal(c)
	T.assert_equal(Save.save(c,"user://annual-policy-wrong-active.json").ok,false)
	T.assert_equal(load(POLICY).effective(c,2019).errors.is_empty(),false)
	c.season_state.selection_policy = valid
	load("res://src/simulation/season_progression_service.gd")._close(c,{"calendar":{"season_id":"2019-20","calendar_year":2019}})
	c.season_state.season_history["2019-20"].season.selection_policy.payload = load(REPO).load_for_season("2018-19").policy
	c.season_state.season_history["2019-20"].season.selection_policy.content_sha256 = load(REPO).content_hash(c.season_state.season_history["2019-20"].season.selection_policy.payload)
	T.assert_equal(Save.save(c,"user://annual-policy-wrong-history.json").ok,false)
	T.assert_equal(load(POLICY).effective(c,2019).errors.is_empty(),false)

func closed_effective() -> void:
	var c = _published()
	if c == null: return
	c.season_state.selection_policy.payload.targets.jgp.minimum_score = 175
	_seal(c)
	var hash: String = c.season_state.selection_policy.content_sha256
	load("res://src/simulation/season_progression_service.gd")._close(c,{"calendar":{"season_id":"2019-20","calendar_year":2019}})
	var effective: Dictionary = load(POLICY).effective(c,2019)
	T.assert_equal(effective.status,"frozen")
	T.assert_equal(effective.content_sha256,hash)
	T.assert_equal(effective.policy.targets.jgp.minimum_score,175)

func actual_completeness() -> void:
	var c = _career()
	var event_id := "cn_club_league_2019_stage_1"
	c.competition_archive.append({"event_id":event_id,"season_id":"2019-20","status":"complete","short_results":{"player":{}},"free_results":{"player":{}},"final_standings":[{"athlete_id":"player","total_score":130.0,"free_score":0.0}]})
	var candidates: Array = Assignment.candidates_from_archives(c,"jgp")
	var row: Dictionary = candidates.filter(func(r):return r.athlete_id == "player")[0]
	T.assert_equal(row.results[0].get("complete_result"),true)
	T.assert_equal(Assignment.resolve(c,[row],1,_context(),99).assignments.has("player"),true)
	c.competition_archive[0].free_results = {}
	c.competition_archive[0].final_standings[0].free_score = 100.0
	row = Assignment.candidates_from_archives(c,"jgp").filter(func(r):return r.athlete_id == "player")[0]
	T.assert_equal(row.results[0].get("complete_result"),false)
	T.assert_equal(Assignment.resolve(c,[row],1,_context(),99).assignments.has("player"),false)
	var no_age := _row("unknown-age",160,100)
	no_age.erase("age")
	T.assert_equal(Assignment.resolve(c,[no_age],1,_context(),99).assignments.has("unknown-age"),false)

func npc_optional_schema() -> void:
	T.assert_equal(Save._validate_world_record("npc",{"opponent_schedule":42}).is_empty(),false)
	T.assert_equal(Save._validate_world_record("npc",{"opponent_schedule_history":42}).is_empty(),false)

func corruption() -> void:
	var c = _published()
	if c == null: return
	c.season_state.selection_policy.payload.targets.jgp.minimum_score = 999
	T.assert_equal(Save.save(c,"user://annual-policy-corrupt.json").ok,false)
	T.assert_equal(Assignment.resolve(c,[_row("a",160,100)],1,_context(),99).errors.is_empty(),false)
	var view := Presenter.build(c,{"season_id":"2019-20","events":[]})
	T.assert_equal(view.announcements.contains("损坏"),true)

func readonly_unsupported() -> void:
	var c = _published()
	if c == null: return
	var before: Dictionary = c.to_dict()
	var api = _api()
	if api == null: return
	var result: Dictionary = api.effective(c,2019)
	result.policy.targets.jgp.minimum_score = 1000
	T.assert_equal(c.to_dict(),before)
	T.assert_equal(api.effective(c,2038).status,"uncovered")
