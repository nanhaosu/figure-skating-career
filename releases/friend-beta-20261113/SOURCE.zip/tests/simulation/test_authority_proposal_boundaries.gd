extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const Authority = preload("res://src/simulation/authority_resolver.gd")
const Plan = preload("res://src/domain/training_plan.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"save validates every plan representation including unused conflict maps", "callable":test_all_plan_fields},
		{"name":"pending authority proposal save load accept preserves executable integer plans", "callable":test_pending_roundtrip},
		{"name":"malformed authority command rejects without runtime errors or mutation", "callable":test_clean_command_rejection},
	]

func _proposal(career) -> Dictionary:
	var shares := F.percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.jump_toe_loop = 95
	shares.rest = 5
	return Authority.preview(career, Plan.create(shares, {"toe_loop":1}).plan).to_dict()

func test_all_plan_fields() -> void:
	var career = F.starting_career(951)
	var base := _proposal(career)
	var invalid: Array[Dictionary] = []
	for layer in ["desired", "approved", "executed"]:
		for extra in [{"allocations":{"rest":{}}}, {"allocations":{}}, {"unknown":{}}]:
			var candidate := base.duplicate(true)
			candidate[layer].merge(extra)
			invalid.append(candidate)
	for key in ["proposed_allocations", "proposed_shares", "proposed_jump_rotations"]:
		var candidate := base.duplicate(true)
		candidate.conflicts[0][key]["rest"] = {}
		invalid.append(candidate)
	var conflicting := base.duplicate(true)
	conflicting.conflicts[0].proposed_allocations = {"rest":100}
	invalid.append(conflicting)
	for candidate in invalid:
		career.last_generated_plan = candidate
		var before: Dictionary = career.to_dict()
		var error := Save._validate_payload({"save_version":13, "saved_at_unix":0, "career":before})
		T.assert_equal(error.is_empty(), false, "all present plan fields must be checked")
		# Do not let the pre-fix clone crash mask this assertion failure.
		if error.is_empty(): continue
		T.assert_equal(Save.save(career, "user://task5-proposal-invalid.json").ok, false)
		var result := Commands.apply(career, {"type":"record_event", "event":{}})
		T.assert_equal(result.ok, false)
		T.assert_equal(career.to_dict(), before)

func test_pending_roundtrip() -> void:
	var career = F.starting_career(952)
	career.last_generated_plan = _proposal(career)
	T.assert_equal(career.last_generated_plan.status, "needs_response")
	var saved := Save.save(career, "user://task5-proposal-pending.json")
	T.assert_equal(saved.ok, true)
	if not saved.ok: return
	var loaded := Save.load_save("user://task5-proposal-pending.json")
	T.assert_equal(loaded.ok, true)
	if not loaded.ok: return
	var all_integers := true
	for conflict in loaded.career.last_generated_plan.conflicts:
		for key in ["proposed_allocations", "proposed_shares", "proposed_jump_rotations"]:
			for value in conflict[key].values(): all_integers = all_integers and value is int
	T.assert_equal(all_integers, true, "loaded conflict plans must restore integer values before responding")
	if not all_integers: return
	var direct := _accept(career)
	var before: Dictionary = loaded.career.to_dict()
	var restored := _accept(loaded.career)
	T.assert_equal(restored.ok, true)
	T.assert_equal(direct.ok, true)
	T.assert_equal(loaded.career.to_dict(), before)
	if not restored.ok or not direct.ok: return
	T.assert_equal(restored.career.to_dict(), direct.career.to_dict())
	for layer in ["desired", "approved", "executed"]:
		T.assert_equal(Plan.from_dict(restored.career.last_generated_plan[layer]) != null, true)
	T.assert_equal(restored.career.last_generated_plan.conflicts.size(), career.last_generated_plan.conflicts.size() - 1)

func _accept(career) -> Dictionary:
	return Commands.apply(career, {"type":"resolve_authority_conflict", "proposal":career.last_generated_plan, "conflict_id":career.last_generated_plan.conflicts[0].id, "response_id":"accept"})

func test_clean_command_rejection() -> void:
	var output: Array = []
	var code := OS.execute(OS.get_executable_path(), ["--headless", "--path", ProjectSettings.globalize_path("res://"), "--script", "res://tests/fixtures/malformed_authority_command_probe.gd"], output, true)
	var log := "\n".join(output)
	T.assert_equal(code, 0, "malformed commands must be rejected atomically")
	T.assert_equal(log.contains("SCRIPT ERROR"), false, "malformed commands must not reach unsafe plan construction")
