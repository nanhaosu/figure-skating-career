extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const EffectiveTrainingCalculator = preload("res://src/simulation/effective_training_calculator.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"rotation curriculum develops every spin family and shared foundation", "callable":test_spin_curriculum_growth},
		{"name": "same seed and plan produce same quarter", "callable": test_same_seed_and_plan_produce_same_quarter},
		{"name": "world random stream does not change training result", "callable": test_world_stream_does_not_change_training_result},
		{"name": "every nonzero change has a cause", "callable": test_every_nonzero_change_has_a_cause},
		{"name": "quarter applies exact workload and records history", "callable": test_quarter_applies_exact_workload_and_records_history},
		{"name": "authority is resolved before workload", "callable": test_authority_is_resolved_before_workload},
		{"name": "low motivation reduces only training growth", "callable": test_low_motivation_reduces_only_training_growth},
		{"name": "cause codes respect exact workload boundaries", "callable": test_cause_codes_respect_exact_workload_boundaries},
		{"name": "year end records neutral growth observation", "callable": test_year_end_records_neutral_growth_observation},
		{"name": "year end appends an explainable season summary", "callable": test_year_end_appends_an_explainable_season_summary},
		{"name": "season summary applies no additional state changes", "callable": test_season_summary_applies_no_additional_state_changes},
		{"name": "jump heavy quarters accumulate more load than balanced quarters", "callable": test_jump_heavy_quarters_accumulate_more_load_than_balanced_quarters},
		{"name": "recovery quarters reduce fatigue without erasing technique", "callable": test_recovery_quarters_reduce_fatigue_without_erasing_technique},
		{"name": "resolved proposal executes without second authority pass", "callable": test_resolved_proposal_executes_without_second_authority_pass},
		{"name": "proposal history records all plan layers and secret result", "callable": test_proposal_history_records_plan_layers_and_secret_result},
		{"name": "percentage plan trains selected jump rotation", "callable": test_percentage_plan_trains_selected_jump_rotation},
		{"name": "configured roadmap updates after percentage quarter", "callable": test_configured_roadmap_updates_after_quarter},
		{"name": "quarter practice improves only selected active program", "callable": test_quarter_practice_improves_only_selected_active_program},
	]

func test_spin_curriculum_growth() -> void:
	var career := Fixtures.starting_career(105)
	var before: Dictionary = career.athlete.to_dict()
	CareerSimulator.advance_quarter(career, Fixtures.percentage_balanced_plan(), CatalogRepository.load_catalog())
	for key in career.athlete.spin_foundation:
		TestSupport.assert_equal(float(career.athlete.spin_foundation[key]) > float(before.spin_foundation[key]), true)
	for key in career.athlete.spins:
		TestSupport.assert_equal(float(career.athlete.spins[key].proficiency) > float(before.spins[key].proficiency), true)

func test_quarter_practice_improves_only_selected_active_program() -> void:
	var career := Fixtures.starting_career(104)
	var short_program = SkatingProgram.create("short-2014", "short", [ProgramElement.create("short-spin", "spin").element]).program
	var free_program = SkatingProgram.create("free-2014", "free", [ProgramElement.create("free-spin", "spin").element]).program
	career.active_programs = {"short": short_program.to_dict(), "free": free_program.to_dict()}
	var shares := Fixtures.percentage_balanced_plan().shares
	shares.skating_foundation -= 10
	shares.program_short = 10
	var plan = TrainingPlan.create(shares, Fixtures.percentage_balanced_plan().jump_rotations).plan
	var proposal = preload("res://src/domain/plan_proposal.gd").create(plan)
	proposal.status = "resolved"
	CareerSimulator.advance_proposal(career, proposal, CatalogRepository.load_catalog())
	TestSupport.assert_equal(float(career.active_programs.short.whole_run_familiarity) > 0.0, true)
	TestSupport.assert_equal(float(career.active_programs.short.slot_familiarity["short-spin"]) > 0.0, true)
	TestSupport.assert_equal(float(career.active_programs.free.whole_run_familiarity), 0.0)
	var records := career.history.filter(func(entry: Dictionary) -> bool: return entry.get("category") == "program_training")
	TestSupport.assert_equal(records.size(), 1)
	TestSupport.assert_equal(records[0].segment, "short")

func test_configured_roadmap_updates_after_quarter() -> void:
	var career := Fixtures.starting_career(102)
	var DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
	var roadmap = DevelopmentRoadmap.create("balanced", [{"age": 10, "rotations": 2, "count": 4}], ["toe_loop"], "", "normal").roadmap
	career.development_roadmap = roadmap.to_dict()
	career.development_roadmap.last_evaluation = {"status": "on_track", "risk_codes": [], "milestone_forecasts": []}
	var proposal = preload("res://src/domain/plan_proposal.gd").create(Fixtures.percentage_balanced_plan())
	proposal.status = "resolved"
	CareerSimulator.advance_proposal(career, proposal, CatalogRepository.load_catalog())
	TestSupport.assert_equal(career.development_roadmap.last_evaluation.is_empty(), false)
	TestSupport.assert_equal(career.history[-1].category, "roadmap_progress")
	TestSupport.assert_equal(career.history[-1].has("key_events"), true)

func test_percentage_plan_trains_selected_jump_rotation() -> void:
	var career := Fixtures.starting_career(101)
	Fixtures.clear_jump_progress(career, ["toe_loop"])
	var proposal = preload("res://src/domain/plan_proposal.gd").create(Fixtures.percentage_plan({"toe_loop": 2}))
	proposal.status = "resolved"
	CareerSimulator.advance_proposal(career, proposal, CatalogRepository.load_catalog())
	var profile = career.athlete.jumps.toe_loop
	var expected: Dictionary = EffectiveTrainingCalculator.calculate(Fixtures.starting_career(101), Fixtures.percentage_plan({"toe_loop": 2}))
	TestSupport.assert_equal(profile.attempt_evidence.double.attempts, expected.jump_attempts.toe_loop)
	TestSupport.assert_equal(profile.attempt_evidence.double.attempts > 8, true)
	TestSupport.assert_equal(profile.attempt_evidence.single.attempts, 0)
	TestSupport.assert_equal(profile.proficiency.double > 0.0, true)
	# Related single-jump practice can transfer skill, but it must not fabricate attempts.
	TestSupport.assert_equal(profile.proficiency.single > 0.0, true)
	var batches := career.history.filter(func(entry: Dictionary) -> bool: return entry.get("category") == "jump_attempt_batch" and entry.get("jump_id") == "toe_loop")
	TestSupport.assert_equal(batches.size() >= 3 and batches.size() <= 6, true)
	var staged_attempts := 0
	for batch in batches:
		staged_attempts += int(batch.attempts)
		TestSupport.assert_equal(int(batch.stage) >= 1, true)
	TestSupport.assert_equal(staged_attempts, expected.jump_attempts.toe_loop)
	var plan_record: Dictionary = career.history[-1]
	TestSupport.assert_equal(plan_record.executed_shares.jump_toe_loop, 10)
	TestSupport.assert_equal(plan_record.executed_jump_rotations.toe_loop, 2)

func test_resolved_proposal_executes_without_second_authority_pass() -> void:
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	var proposal = preload("res://src/domain/plan_proposal.gd").create(Fixtures.jump_heavy_plan())
	proposal.status = "resolved"
	CareerSimulator.advance_proposal(career, proposal, CatalogRepository.load_catalog())
	TestSupport.assert_equal(proposal.executed.to_dict(), Fixtures.jump_heavy_plan().to_dict())
	TestSupport.assert_equal(career.history[0].get("cause_codes", []).has("guardian_health_protection"), false)

func test_proposal_history_records_plan_layers_and_secret_result() -> void:
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	career.athlete.mind.autonomy = 30.0
	var proposal = preload("res://src/simulation/authority_resolver.gd").preview(career, Fixtures.jump_heavy_plan())
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	preload("res://src/simulation/authority_resolver.gd").respond(career, proposal, proposal.conflicts[0].id, "pretend_comply", rng)
	CareerSimulator.advance_proposal(career, proposal, CatalogRepository.load_catalog())
	var plan_record: Dictionary = career.history[-1]
	TestSupport.assert_equal(plan_record.category, "quarter_plan")
	TestSupport.assert_equal(plan_record.desired.jump_toe_loop, 2)
	TestSupport.assert_equal(plan_record.approved.jump_toe_loop, 1)
	TestSupport.assert_equal(plan_record.executed.jump_toe_loop, 1)
	TestSupport.assert_equal(plan_record.secret_practice.executed_units, 1)
	TestSupport.assert_equal(plan_record.cause_codes.has("secret_practice"), true)

func test_same_seed_and_plan_produce_same_quarter() -> void:
	var a := Fixtures.starting_career(123)
	var b := Fixtures.starting_career(123)
	var plan := Fixtures.balanced_plan()
	var catalog := CatalogRepository.load_catalog()
	var out_a := CareerSimulator.advance_quarter(a, plan, catalog)
	var out_b := CareerSimulator.advance_quarter(b, plan, catalog)
	TestSupport.assert_equal(a.to_dict(), b.to_dict())
	TestSupport.assert_equal(OutcomeRecord.list_to_dict(out_a), OutcomeRecord.list_to_dict(out_b))

func test_world_stream_does_not_change_training_result() -> void:
	var baseline := Fixtures.starting_career(123)
	var interleaved := Fixtures.starting_career(123)
	interleaved.random_streams.take_rng("world")
	var catalog := CatalogRepository.load_catalog()
	var baseline_outcomes := CareerSimulator.advance_quarter(baseline, Fixtures.balanced_plan(), catalog)
	var interleaved_outcomes := CareerSimulator.advance_quarter(interleaved, Fixtures.balanced_plan(), catalog)
	TestSupport.assert_equal(
		OutcomeRecord.list_to_dict(interleaved_outcomes),
		OutcomeRecord.list_to_dict(baseline_outcomes),
	)
	TestSupport.assert_equal(interleaved.random_streams.steps.get("world"), 1)
	TestSupport.assert_equal(interleaved.random_streams.steps.get("training"), 1)

func test_every_nonzero_change_has_a_cause() -> void:
	var outcomes := CareerSimulator.advance_quarter(
		Fixtures.starting_career(9),
		Fixtures.jump_heavy_plan(),
		CatalogRepository.load_catalog(),
	)
	for outcome in outcomes:
		if outcome.delta != 0.0:
			TestSupport.assert_equal(outcome.cause_codes.is_empty(), false)

func test_quarter_applies_exact_workload_and_records_history() -> void:
	var career := Fixtures.starting_career(17)
	var outcomes := CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	TestSupport.assert_equal(is_equal_approx(career.athlete.body.acute_fatigue, 6.0), true)
	TestSupport.assert_equal(is_equal_approx(career.athlete.body.cumulative_fatigue, 0.5), true)
	TestSupport.assert_equal(is_equal_approx(career.athlete.body.ankle_load, 0.0), true)
	TestSupport.assert_equal(career.clock.to_dict(), {"year": 2014, "quarter": 2})
	TestSupport.assert_equal(career.rng_step, 1)
	TestSupport.assert_equal(career.random_streams.steps.get("training"), 1)
	TestSupport.assert_equal(career.history, OutcomeRecord.list_to_dict(outcomes))

func test_authority_is_resolved_before_workload() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	Fixtures.clear_pre_career_load(career)
	var outcomes := CareerSimulator.advance_quarter(career, Fixtures.jump_heavy_plan(), CatalogRepository.load_catalog())
	TestSupport.assert_equal(is_equal_approx(career.athlete.body.acute_fatigue, 6.0), true)
	TestSupport.assert_equal(is_equal_approx(career.athlete.body.cumulative_fatigue, 0.5), true)
	TestSupport.assert_equal(is_equal_approx(career.athlete.body.ankle_load, 1.25), true)
	TestSupport.assert_equal(_has_cause(outcomes, "guardian_health_protection"), true)

func test_low_motivation_reduces_only_training_growth() -> void:
	var motivated := Fixtures.starting_career(21)
	var low_motivation := Fixtures.starting_career(21)
	low_motivation.athlete.mind.motivation = 34.0
	var catalog := CatalogRepository.load_catalog()
	var normal_outcomes := CareerSimulator.advance_quarter(motivated, Fixtures.balanced_plan(), catalog)
	var reduced_outcomes := CareerSimulator.advance_quarter(low_motivation, Fixtures.balanced_plan(), catalog)
	var normal_edge = _find_target(normal_outcomes, "deep_edge")
	var reduced_edge = _find_target(reduced_outcomes, "deep_edge")
	TestSupport.assert_equal(is_equal_approx(reduced_edge.delta, normal_edge.delta * 0.8), true)
	TestSupport.assert_equal(reduced_edge.cause_codes.has("low_motivation"), true)
	TestSupport.assert_equal(
		float(low_motivation.athlete.body.recovery_capacity) < float(motivated.athlete.body.recovery_capacity),
		true,
	)
	for load_target in ["acute_fatigue", "cumulative_fatigue", "ankle_load", "impact_load"]:
		TestSupport.assert_equal(low_motivation.athlete.body[load_target], motivated.athlete.body[load_target])

func test_cause_codes_respect_exact_workload_boundaries() -> void:
	var catalog := CatalogRepository.load_catalog()
	var jump_four_career := Fixtures.starting_career(23)
	var jump_five_career := Fixtures.starting_career(23)
	jump_four_career.clock.year = 2026
	jump_five_career.clock.year = 2026
	var jump_four := CareerSimulator.advance_quarter(
		jump_four_career,
		_plan(2, 4, 2, 2, 2),
		catalog,
	)
	var jump_five := CareerSimulator.advance_quarter(
		jump_five_career,
		_plan(2, 5, 2, 2, 1),
		catalog,
	)
	TestSupport.assert_equal(_find_target(jump_four, "ankle_load").cause_codes.has("jump_repetition_load"), false)
	TestSupport.assert_equal(_find_target(jump_five, "ankle_load").cause_codes.has("jump_repetition_load"), true)
	TestSupport.assert_equal(_find_target(jump_four, "acute_fatigue").cause_codes.has("insufficient_recovery"), false)
	TestSupport.assert_equal(_find_target(jump_five, "acute_fatigue").cause_codes.has("insufficient_recovery"), true)

	var motivation_35 := Fixtures.starting_career(25)
	var motivation_34 := Fixtures.starting_career(25)
	motivation_35.athlete.mind.motivation = 35.0
	motivation_34.athlete.mind.motivation = 34.0
	var outcome_35 := CareerSimulator.advance_quarter(motivation_35, Fixtures.balanced_plan(), catalog)
	var outcome_34 := CareerSimulator.advance_quarter(motivation_34, Fixtures.balanced_plan(), catalog)
	TestSupport.assert_equal(_find_target(outcome_35, "deep_edge").cause_codes.has("low_motivation"), false)
	TestSupport.assert_equal(_find_target(outcome_34, "deep_edge").cause_codes.has("low_motivation"), true)

func test_year_end_records_neutral_growth_observation() -> void:
	var career := Fixtures.starting_career(31)
	career.clock.quarter = 4
	var growth_before := float(career.athlete.body.growth_trend)
	var outcomes := CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	var observation = _find_target(outcomes, "growth_trend")
	TestSupport.assert_equal(observation.summary_key, "growth_change_observed")
	TestSupport.assert_equal(observation.delta >= 0.0 and observation.delta <= 20.0, true)
	TestSupport.assert_equal(career.athlete.body.growth_trend >= 0.0 and career.athlete.body.growth_trend <= 20.0, true)
	TestSupport.assert_equal(is_equal_approx(observation.delta, career.athlete.body.growth_trend - growth_before), true)
	TestSupport.assert_equal(observation.cause_codes.is_empty(), false)
	TestSupport.assert_equal(career.clock.to_dict(), {"year": 2015, "quarter": 1})
	TestSupport.assert_equal(career.athlete.body.has("weight"), false)
	TestSupport.assert_equal(career.athlete.body.has("body_shape"), false)
	TestSupport.assert_equal(career.athlete.body.has("puberty_outcome"), false)

func test_year_end_appends_an_explainable_season_summary() -> void:
	var career := Fixtures.starting_career(37)
	var catalog := CatalogRepository.load_catalog()
	var technique_at_year_start := career.athlete.technique.duplicate(true)
	for quarter in 4:
		CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), catalog)
	var summaries := career.history.filter(
		func(item: Dictionary) -> bool: return item.get("category") == "season_summary"
	)
	TestSupport.assert_equal(summaries.size(), 1)
	if summaries.is_empty():
		return
	var summary: Dictionary = summaries[0]
	TestSupport.assert_equal(summary.year, 2014)
	TestSupport.assert_equal(summary.peak_fatigue >= career.athlete.body.cumulative_fatigue, true)
	TestSupport.assert_equal(summary.cause_codes.has("skating_foundation_training"), true)
	TestSupport.assert_equal(summary.cause_codes.has("year_end_growth_observation"), true)
	for target in technique_at_year_start:
		TestSupport.assert_equal(
			is_equal_approx(
				float(summary.technique_deltas.get(target, 0.0)),
				float(career.athlete.technique[target]) - float(technique_at_year_start[target]),
			),
			true,
		)

func test_season_summary_applies_no_additional_state_changes() -> void:
	var career := Fixtures.starting_career(39)
	career.clock.quarter = 4
	var technique_before := career.athlete.technique.duplicate(true)
	var body_before := career.athlete.body.duplicate(true)
	var outcomes := CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	for target in career.athlete.technique:
		TestSupport.assert_equal(
			is_equal_approx(
				float(career.athlete.technique[target]) - float(technique_before.get(target, 0.0)),
				_sum_outcome_delta(outcomes, target),
			),
			true,
		)
	for target in career.athlete.body:
		TestSupport.assert_equal(
			is_equal_approx(
				float(career.athlete.body[target]) - float(body_before.get(target, 0.0)),
				_sum_outcome_delta(outcomes, target),
			),
			true,
		)

func test_jump_heavy_quarters_accumulate_more_load_than_balanced_quarters() -> void:
	var jump_heavy := Fixtures.starting_career(41)
	var balanced := Fixtures.starting_career(41)
	var catalog := CatalogRepository.load_catalog()
	var jump_outcomes: Array = []
	var balanced_outcomes: Array = []
	for quarter in 4:
		jump_outcomes.append_array(CareerSimulator.advance_quarter(jump_heavy, Fixtures.jump_heavy_plan(), catalog))
		balanced_outcomes.append_array(CareerSimulator.advance_quarter(balanced, Fixtures.balanced_plan(), catalog))
	TestSupport.assert_equal(jump_heavy.athlete.body.ankle_load > balanced.athlete.body.ankle_load, true)
	TestSupport.assert_equal(jump_heavy.athlete.body.impact_load > balanced.athlete.body.impact_load, true)
	_assert_nonzero_outcomes_have_causes(jump_outcomes)
	_assert_nonzero_outcomes_have_causes(balanced_outcomes)

func test_recovery_quarters_reduce_fatigue_without_erasing_technique() -> void:
	var career := Fixtures.starting_career(43)
	var catalog := CatalogRepository.load_catalog()
	for quarter in 2:
		CareerSimulator.advance_quarter(career, Fixtures.jump_heavy_plan(), catalog)
	var fatigue_before := {
		"acute": career.athlete.body.acute_fatigue,
		"cumulative": career.athlete.body.cumulative_fatigue,
	}
	var technique_before := career.athlete.technique.duplicate(true)
	var recovery_outcomes: Array = []
	for quarter in 2:
		recovery_outcomes.append_array(CareerSimulator.advance_quarter(career, _recovery_heavy_plan(), catalog))
	TestSupport.assert_equal(career.athlete.body.acute_fatigue < fatigue_before.acute, true)
	TestSupport.assert_equal(career.athlete.body.cumulative_fatigue < fatigue_before.cumulative, true)
	for target in technique_before:
		TestSupport.assert_equal(career.athlete.technique[target] >= technique_before[target], true)
	_assert_nonzero_outcomes_have_causes(recovery_outcomes)

func _find_target(outcomes: Array, target: String):
	for outcome in outcomes:
		if outcome.target == target:
			return outcome
	TestSupport.assert_equal(false, true, "Missing outcome target: %s" % target)
	return OutcomeRecord.new("missing", target, 0.0, [], "missing")

func _has_cause(outcomes: Array, cause_code: String) -> bool:
	for outcome in outcomes:
		if outcome.cause_codes.has(cause_code):
			return true
	return false

func _sum_outcome_delta(outcomes: Array, target: String) -> float:
	var total := 0.0
	for outcome in outcomes:
		if outcome.target == target:
			total += outcome.delta
	return total

func _recovery_heavy_plan() -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation": 2,
		"jump_toe_loop": 1, "jump_salchow": 0, "jump_loop": 0,
		"jump_flip": 0, "jump_lutz": 0, "jump_axel": 0,
		"rotation": 1,
		"conditioning": 2,
		"rest": 6,
	}).plan

func _plan(skating: int, jumps: int, spins: int, conditioning: int, rest: int) -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation": skating,
		"jump_toe_loop": jumps, "jump_salchow": 0, "jump_loop": 0,
		"jump_flip": 0, "jump_lutz": 0, "jump_axel": 0,
		"rotation": spins,
		"conditioning": conditioning,
		"rest": rest,
	}).plan

func _assert_nonzero_outcomes_have_causes(outcomes: Array) -> void:
	for outcome in outcomes:
		if outcome.delta != 0.0:
			TestSupport.assert_equal(outcome.cause_codes.is_empty(), false)
