extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const World = preload("res://src/simulation/world_generation_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"every federation replenishes age-thirteen juniors without rewriting incumbents","callable":cohort},{"name":"annual cohorts survive reload and ignore player identity and ability","callable":independent},{"name":"initial six junior age buckets are balanced and annual additions are bounded","callable":balanced}]
func balanced() -> void:
	var c = F.starting_career(99)
	var b := Bundle.load_bundle(2018,"women_singles","junior")
	World.ensure_season(c,b,99)
	for federation in b.federation_profiles:
		var counts := [0,0,0,0,0,0]
		for npc in c.world_athletes.values():
			if npc.federation != federation: continue
			# International ages must be attained BEFORE July 1, not on it.
			var age := 2018-int(npc.athlete.birth_year)-(1 if str(npc.birth_date).substr(5)>="07-01" else 0)
			T.assert_equal(age >= 13 and age <= 18,true)
			if age >= 13 and age <= 18: counts[age-13] += 1
		T.assert_equal(counts.max()-counts.min() <= 1,true,"unbalanced initial age buckets "+federation+":"+str(counts))
	var added := World.ensure_season(c,Bundle.load_bundle(2019,"women_singles","junior"),99)
	for federation in b.federation_profiles:
		var ids: Array = added.created_ids.filter(func(id): return c.world_athletes[id].federation == federation)
		T.assert_equal(ids.size(),maxi(1,int(ceil(float(b.federation_profiles[federation].pool_size)/6.0))),"annual cohort must not overpopulate "+federation)
func cohort() -> void:
	var c = F.starting_career(99)
	World.ensure_season(c,Bundle.load_bundle(2018,"women_singles","junior"),99)
	var old: Dictionary = c.world_athletes.duplicate(true)
	var b := Bundle.load_bundle(2019,"women_singles","junior")
	var generated := World.ensure_season(c,b,99)
	T.assert_equal(generated.errors,[])
	for federation in b.federation_profiles:
		var young: Array = c.world_athletes.values().filter(func(n): return n.federation == federation and 2019-int(n.athlete.birth_year)-(1 if str(n.birth_date).substr(5)>="07-01" else 0) == 13)
		T.assert_equal(young.size() >= maxi(1,int(ceil(float(b.federation_profiles[federation].pool_size)/6.0))),true,"no new junior cohort for "+federation)
	for id in old:
		T.assert_equal(c.world_athletes.has(id),true)
		T.assert_equal(c.world_athletes[id].athlete,old[id].athlete,"incumbent abilities/identity must not be rewritten")
		T.assert_equal(c.world_athletes[id].competition_history,old[id].competition_history)
func independent() -> void:
	var a = F.starting_career(101); var b = F.formal_acceptance_career("qualify")
	for c in [a,b]:
		World.ensure_season(c,Bundle.load_bundle(2018,"women_singles","junior"),99)
		World.ensure_season(c,Bundle.load_bundle(2019,"women_singles","junior"),99)
	T.assert_equal(a.world_athletes,b.world_athletes,"player must not affect cohort identity, strength or count")
	var before: Dictionary = JSON.parse_string(JSON.stringify(a.world_athletes))
	a = load("res://src/domain/career_state.gd").from_dict(JSON.parse_string(JSON.stringify(a.to_dict())))
	World.ensure_season(a,Bundle.load_bundle(2019,"women_singles","junior"),99)
	T.assert_equal(a.world_athletes,before,"reload/repeated ensure must not duplicate a cohort")
