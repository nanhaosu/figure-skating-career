extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const PATH := "res://src/simulation/athlete_function_service.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"manual rotation and skating lessons respect coordination restrictions","callable":manual_constraints},
		{"name":"stage hazard rules reject malformed probabilities","callable":hazard_rules},
		{"name":"functional landing limitation reduces actual attempt probability but not unrelated safe lessons","callable":execution_effect},
		{"name":"landing restriction blocks jumps but not ordinary steps", "callable":specific_restriction},
		{"name":"veteran with identical function has no age hard lock on axel", "callable":age_parity},
		{"name":"fatigue and recovered injury do not erase baseline physical function", "callable":temporary_state},
		{"name":"serious legacy injury remains a restriction pending functional reassessment", "callable":legacy_injury},
	]

func manual_constraints() -> void:
	var career = F.starting_career(1106)
	career.condition_state.function_limits = {"coordination":{"blocked":true}}
	var plans = load("res://src/domain/training_plan.gd")
	var effects = load("res://src/simulation/athlete_condition_service.gd")
	for category in ["rotation","skating_foundation"]:
		var shares := {}
		for id in plans.REQUIRED_CATEGORY_IDS: shares[id] = 0
		shares.rest = 10
		shares[category] = 90
		var plan = plans.create(shares).plan
		T.assert_equal(effects.can_train(career,plan),false)
	var rest := {}
	for id in plans.REQUIRED_CATEGORY_IDS: rest[id] = 0
	rest.rest = 100
	T.assert_equal(effects.can_train(career,plans.create(rest).plan),true)

func hazard_rules() -> void:
	var rules = load("res://src/content/repertoire_health_rules.gd")
	for field in ["stage_base_risk","stage_major_fraction","stage_overload_risk"]:
		var data: Dictionary = rules.load_rules()
		data[field] = -0.1
		T.assert_equal(rules.validate(data).is_empty(),false)

func execution_effect() -> void:
	var fresh = F.formal_junior_career(1105)
	var restricted = fresh.transaction_copy()
	restricted.condition_state.function_limits = {"landing":{"factor":0.6}}
	var rng := RandomNumberGenerator.new()
	rng.seed = 1105
	var batches = preload("res://src/simulation/jump_attempt_batch_simulator.gd")
	var a: Dictionary = batches.simulate(fresh,"toe_loop",3,4,1.0,rng)
	rng.seed = 1105
	var b: Dictionary = batches.simulate(restricted,"toe_loop",3,4,1.0,rng)
	T.assert_equal(b.probability < a.probability,true)
	var program = preload("res://src/domain/skating_program.gd").from_dict(fresh.active_programs.free)
	var first: Dictionary = {"jump_id":"toe_loop","rotations":3}
	var effects = preload("res://src/simulation/athlete_condition_service.gd")
	var execution = preload("res://src/simulation/program_performance_simulator.gd")
	T.assert_equal(execution._part_success_probability(restricted.athlete,program,"probe",first,0,0,{},effects.competition_context(restricted)) < execution._part_success_probability(fresh.athlete,program,"probe",first,0,0,{},effects.competition_context(fresh)),true)

func service():
	T.assert_equal(FileAccess.file_exists(PATH),true,"shared physical function service must exist")
	return load(PATH) if FileAccess.file_exists(PATH) else null

func axel() -> Dictionary:
	return {"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}

func specific_restriction() -> void:
	var api = service()
	if api == null: return
	var career = F.starting_career(1101)
	career.condition_state.function_limits = {"landing":{"blocked":true,"factor":0.6,"source_id":"ankle","review_condition":"重新评估落冰承受能力"}}
	var jump: Dictionary = api.action_constraints(career,axel())
	T.assert_equal(jump.allowed,false)
	T.assert_equal(jump.reasons.is_empty(),false)
	T.assert_equal(jump.review_conditions.is_empty(),false)
	T.assert_equal(api.action_constraints(career,{"kind":"step_sequence"}).allowed,true)
	T.assert_equal(api.action_constraints(career,{"kind":"choreographic_sequence"}).allowed,true)
	T.assert_equal(api.action_constraints(career,{"kind":"spin","flying":false}).allowed,true)
	T.assert_equal(api.action_constraints(career,{"kind":"spin","spin_code":"FCSp"}).allowed,false)

func age_parity() -> void:
	var api = service()
	if api == null: return
	var young = F.starting_career(1102)
	young.athlete.birth_year = young.clock.year-18
	var veteran = young.transaction_copy()
	veteran.athlete.birth_year = veteran.clock.year-30
	T.assert_equal(api.snapshot(young),api.snapshot(veteran))
	T.assert_equal(api.action_constraints(young,axel()),api.action_constraints(veteran,axel()))
	T.assert_equal(api.action_constraints(veteran,axel()).allowed,true)

func temporary_state() -> void:
	var api = service()
	if api == null: return
	var career = F.starting_career(1103)
	var before: Dictionary = api.snapshot(career)
	career.athlete.body.acute_fatigue = 80
	career.condition_state.injuries = [{"id":"old","severity":0.9,"status":"recovered"}]
	var tired: Dictionary = api.snapshot(career)
	for field in ["takeoff","coordination","landing","recovery"]:
		T.assert_equal(tired[field],before[field])
	T.assert_equal(api.action_constraints(career,axel()).allowed,true)
	career.athlete.body.acute_fatigue = before.acute_fatigue
	T.assert_equal(api.snapshot(career),before)

func legacy_injury() -> void:
	var api = service()
	if api == null: return
	var career = F.starting_career(1104)
	career.condition_state.injuries = [{"id":"legacy","severity":0.8,"status":"active","remaining_quarters":2}]
	T.assert_equal(api.action_constraints(career,axel()).allowed,false)
	T.assert_equal(api.action_constraints(career,{"kind":"step_sequence"}).allowed,true)
