extends RefCounted
const T = preload("res://tests/test_support.gd")
const S = preload("res://src/content/formal_scoring_repository.gd")
const P = preload("res://src/simulation/formal_technical_panel.gd")
const J = preload("res://src/simulation/formal_judging_panel.gd")
const F = preload("res://tests/fixtures.gd")
const PerformanceSimulator = preload("res://src/simulation/program_performance_simulator.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Element = preload("res://src/domain/program_element.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2334 exact quarter and half boundaries use missing turns not completion percentage","callable":test_boundaries},
		{"name":"2334 same missing turns receive consistent calls across double triple quad","callable":test_absolute_turns},
		{"name":"2021 five judge protocol combo has9.26 base and minus1.18 GOE","callable":test_protocol_combo},
		{"name":"popped planned3A is evaluated as actual2A without false downgrade","callable":test_pop},
		{"name":"quarter landing keeps full base but reduces positive GOE by two","callable":test_quarter_goe},
		{"name":"2019 archived rule contract retains legacy ratio and values","callable":test_legacy},
		{"name":"new era catalogs require an applicable sourced rotation standard","callable":test_catalog_guard},
		{"name":"actual simulated underrotated quad carries absolute evidence instead of false downgrade","callable":test_generated_evidence},
		{"name":"quarter errors in both combination parts retain both deductions","callable":test_two_quarters},
		{"name":"judge affinity cannot exceed quarter GOE ceiling or erase a fall","callable":test_quarter_ceiling},
		{"name":"sourced new era wrong edge uses80 percent without altering legacy calls","callable":test_edge_value},
	]

func _catalog() -> Dictionary:
	var rules = S.load_catalog(2019,"women_singles").catalog
	rules.season_start_year = 2020
	rules.season_id = "2020-21"
	rules.rotation_call_standard = "isu_2334"
	rules.rotation_call_source_id = "isu2334"
	rules.non_jump_base_values.SSp = {"B":1.1,"1":1.3,"2":1.6,"3":2.1,"4":2.5}
	rules.domestic_bonus = {"policy":"none","short":{},"free":{},"included_in_tes":false}
	rules.sources.append({"source_id":"isu2334","title":"ISU2334 p3 missing turns and p10 GOE","url":"https://ctsu.com.tw/wp-content/uploads/2020/07/2334-SP-Levels-of-Difficulty-and-Guidelines-for-marking-2020-21_replacing-2254.pdf","retrieved_on":"2026-10-21"})
	return rules

func _jump(code:String,missing:float) -> Dictionary:
	return {"element_id":code,"kind":"jump","abbreviation":code,"planned_abbreviation":code,"facts":{"planned_rotations":int(code.left(1)),"missing_rotation_turns":missing,"rotation_ratio":1.0,"edge_quality":100.0,"landing_quality":90.0}}

func _call(element:Dictionary,rules:Dictionary) -> Dictionary:
	return P.resolve({"elements":[element]},rules,{}, {},177).final_elements[0]

func test_boundaries() -> void:
	for row in [[0.24,[],4.2],[0.25,["q"],4.2],[0.2501,["<"],3.36],[0.4999,["<"],3.36],[0.5,["<<"],1.3]]:
		var result = _call(_jump("3T",row[0]),_catalog())
		T.assert_equal(result.info,row[1])
		T.assert_equal(result.base_value,row[2])
		if row[0] == 0.25: T.assert_equal(result.status,"error","q cannot be presented as a clean technical completion")

func test_absolute_turns() -> void:
	for row in [["2T",1.04],["3T",3.36],["4T",7.6]]:
		var result = _call(_jump(row[0],0.3),_catalog())
		T.assert_equal(result.info,["<"])
		T.assert_equal(is_equal_approx(float(result.base_value),float(row[1])),true)

func _judges(count:int) -> Array:
	var judges:Array = []
	for i in count: judges.append({"judge_id":"J%d" % i,"consistency":1.0,"technical_bias":0.0,"affinity":0.0,"pcs_bias":0.0})
	return judges

func test_protocol_combo() -> void:
	var first = _jump("3Lz",0.0)
	var second = _jump("3T",0.35)
	first.facts.landing_quality = 30.0
	second.facts.landing_quality = 30.0
	var performance = {"segment":"short","elements":[{"element_id":"combo","kind":"jump","parts":[first,second]}]}
	var rules = _catalog()
	rules.panel.judge_count = 5
	rules.domestic_bonus = {}
	var review = P.resolve(performance,rules,{}, {},177)
	var score = J.score(performance,review,{},rules,_judges(5),177)
	T.assert_equal(score.errors,[])
	T.assert_equal(score.element_scores[0].base_value,9.26,"Official2021 protocol p25:5.90+3.36")
	T.assert_equal(score.element_scores[0].goe,-1.18)
	T.assert_equal(score.element_scores[0].total,8.08)

func test_pop() -> void:
	var jump = _jump("3A",0.0)
	jump.abbreviation = "2A"
	jump.actual = {"error_type":"pop"}
	jump.facts.erase("missing_rotation_turns")
	jump.facts.rotation_ratio = 0.62
	jump.facts.executed_rotation_ratio = 0.96
	var result = _call(jump,_catalog())
	T.assert_equal(result.abbreviation,"2A")
	T.assert_equal(is_equal_approx(float(result.base_value),3.3),true)
	T.assert_equal(result.info,[])
	T.assert_equal(result.facts.planned_abbreviation,"3A")

func test_quarter_goe() -> void:
	var rules = _catalog()
	var marks:Array = []
	for missing in [0.0,0.25]:
		var performance = {"segment":"short","elements":[_jump("3T",missing)]}
		var review = P.resolve(performance,rules,{}, {},177)
		var score = J.score(performance,review,{},rules,_judges(9),177)
		T.assert_equal(score.element_scores[0].base_value,4.2)
		marks.append(score.element_scores[0].judge_goes[0])
	T.assert_equal(marks,[4,2],"q reduction is two steps from starting GOE, not an automatic negative cap")

func test_legacy() -> void:
	var jump = _jump("3T",0.25)
	jump.facts.rotation_ratio = 0.84
	var result = _call(jump,S.load_catalog(2019,"women_singles").catalog)
	T.assert_equal(result.info,["<"])
	T.assert_equal(result.base_value,3.15)

func test_catalog_guard() -> void:
	T.assert_equal(S.validate(_catalog()),[])
	for defect in ["missing","unknown","source","year"]:
		var rules = _catalog()
		match defect:
			"missing": rules.erase("rotation_call_standard")
			"unknown": rules.rotation_call_standard = "guess"
			"source": rules.rotation_call_source_id = "not_in_sources"
			"year": rules.season_start_year = 2019; rules.season_id = "2019-20"
		T.assert_equal(S.validate(rules).is_empty(),false,defect+" must not fall back to wrong historical calls")

func test_generated_evidence() -> void:
	var athlete = F.starting_career(80).athlete
	athlete.jumps.toe_loop.unlocked_rotations = 4
	athlete.jumps.toe_loop.attempt_evidence.quad = {"attempts":20,"successes":5}
	var program = Program.create("rotation-probe","free",[Element.create("jump","jump","toe_loop",4).element]).program
	var rules = _catalog()
	for seed in 128:
		var rng = RandomNumberGenerator.new()
		rng.seed = seed
		var actual = PerformanceSimulator._simulate_jump_part(athlete,program,"jump",{"jump_id":"toe_loop","rotations":4},0,0,0.0,0.0,{}, {"scoring_catalog":rules},rng)
		if actual.actual.error_type != "underrotated": continue
		T.assert_equal(actual.facts.has("missing_rotation_turns"),true,"New-era producer must express actual missing turns, not legacy0.84 for all jumps")
		var review = _call(actual,rules)
		T.assert_equal(review.info,["<"],"Underrotation generated by the performance must not turn into an unmodeled half-turn downgrade")
		T.assert_equal(is_equal_approx(float(review.base_value),7.6),true)
		return
	T.assert_equal(false,true,"Fixed seeded fixture must include an underrotated attempt")

func test_two_quarters() -> void:
	var rules = _catalog()
	var performance = {"segment":"free","elements":[{"element_id":"combo","kind":"jump","parts":[_jump("3Lz",0.25),_jump("3T",0.25)]}]}
	var review = P.resolve(performance,rules,{}, {},177)
	var score = J.score(performance,review,{},rules,_judges(9),177)
	T.assert_equal(score.element_scores[0].judge_goes,[ -2,-2,-2,-2,-2,-2,-2,-2,-2 ],"Multiple errors cap startingGOE+2, then two distinctq reductions of2; unioned display symbols must not erase a part error")

func test_quarter_ceiling() -> void:
	var rules = _catalog()
	for fall in [false,true]:
		var jump = _jump("3T",0.25)
		jump.facts.landing_quality = 100.0
		jump.facts.fall = fall
		var performance = {"segment":"short","elements":[jump]}
		var review = P.resolve(performance,rules,{}, {},177)
		var judges = _judges(9)
		for judge in judges: judge.affinity = 1.0
		var score = J.score(performance,review,{},rules,judges,177)
		T.assert_equal(score.element_scores[0].judge_goes.max(),-5 if fall else 3)

func test_edge_value() -> void:
	var jump = _jump("3Lz",0.0)
	jump.facts.edge_quality = 0.0
	T.assert_equal(is_equal_approx(float(_call(jump,_catalog()).base_value),4.72),true,"2253 table 3Lze is4.72, not legacy4.43")
	T.assert_equal(is_equal_approx(float(_call(jump,S.load_catalog(2019,"women_singles").catalog).base_value),4.43),true,"Do not rewrite archived legacy scoring contract")
