extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const BaseF = preload("res://tests/fixtures.gd")
const Volume = preload("res://src/simulation/effective_training_calculator.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"real childhood edge observation produces actual edge correction","callable":real_observation},{"name":"artistic coaching develops expression without requiring hidden focus setup","callable":artistic},{"name":"coach lesson quality changes learning without adding attempts","callable":quality},
		{"name":"coach cannot stack lesson quality with external lesson quality","callable":external},
		{"name":"coaching corrections require observed issues and actual attempts","callable":correction},
		{"name":"zero executed training gives no psychological or technical reward","callable":no_execution}]

func real_observation() -> void:
	var service = _service()
	if service == null: return
	var c = F.starting(73306)
	c.athlete.jumps.lutz.takeoff.edge_quality = 30.0
	c.athlete.jumps.lutz.observations.assign([{"id":"lutz-edge","kind":"edge","text":"勾手跳的起跳刃还不稳定，教练建议继续观察。","known":true}])
	var before := float(c.athlete.jumps.lutz.takeoff.edge_quality)
	service.settle(c,BaseF.percentage_balanced_plan(),0.25,[{"jump_id":"lutz","attempts":4}])
	T.assert_equal(float(c.athlete.jumps.lutz.takeoff.edge_quality)>before,true,"real observation shape, not a synthetic label field, must drive teaching corrections")

func artistic() -> void:
	var service = _service()
	if service == null: return
	var base = F.starting(73305)
	var art = base.transaction_copy()
	art.coach_assignment.technical_tendencies = {"component_development":0.28}
	var plan = BaseF.percentage_balanced_plan()
	var art_plan = service.decorate(art,plan).plan
	T.assert_equal(art_plan.expression_share>0,true)
	T.assert_equal(art_plan.total_share(),100)
	for subject in [base,art]:
		var executed = art_plan if subject == art else plan
		load("res://src/simulation/career_simulator.gd").advance_quarter(subject,executed,load("res://src/content/catalog_repository.gd").load_catalog())
	T.assert_equal(float(art.athlete.mind.expression)>float(base.athlete.mind.expression),true)

func _service():
	var path := "res://src/simulation/coach_lesson_service.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"executed teaching service required")
	return load(path) if FileAccess.file_exists(path) else null

func quality() -> void:
	var service = _service()
	if service == null: return
	var c = F.starting(73301)
	c.coach_assignment.technical_tendencies = {"toe_jump_mechanics":0.24}
	var base = BaseF.percentage_balanced_plan()
	var taught = service.decorate(c,base).plan
	T.assert_equal(Volume.calculate(c,base).jump_attempts,Volume.calculate(c,taught).jump_attempts)
	T.assert_equal(float(taught.lesson_quality.jump_toe_loop)>1.0,true)
	var plain = c.transaction_copy()
	var guided = c.transaction_copy()
	var a := RandomNumberGenerator.new(); a.seed=73301
	var b := RandomNumberGenerator.new(); b.seed=73301
	var learn = load("res://src/simulation/jump_training_simulator.gd")
	learn.apply(plain,"toe_loop",1,10,1.0,a,false)
	learn.apply(guided,"toe_loop",1,10,float(taught.lesson_quality.jump_toe_loop),b,false)
	T.assert_equal(float(guided.athlete.jumps.toe_loop.proficiency.single)>float(plain.athlete.jumps.toe_loop.proficiency.single),true,"quality cannot disappear at a downstream clamp")

func external() -> void:
	var service = _service()
	if service == null: return
	var c = F.starting(73302)
	c.coach_assignment.technical_tendencies = {"toe_jump_mechanics":0.24}
	var plan = BaseF.percentage_balanced_plan()
	plan.lesson_quality.jump_toe_loop = 1.15
	var taught = service.decorate(c,plan).plan
	T.assert_equal(taught.lesson_quality.jump_toe_loop,1.15)
	T.assert_equal(service.decorate(c,taught).plan.lesson_quality.jump_toe_loop,1.15,"repeated previews cannot multiply quality")

func correction() -> void:
	var service = _service()
	if service == null: return
	var c = F.starting(73303)
	c.coach_assignment.technical_tendencies = {"edge_foundation":0.25,"psychological_attunement":0.8}
	c.coach_assignment.relationship.professional_trust = 80.0
	c.condition_state.psychology.stress = 40.0
	c.athlete.jumps.lutz.observations.assign([{"label":"用刃不稳"}])
	var before := float(c.athlete.jumps.lutz.takeoff.edge_stability)
	var unobserved := float(c.athlete.jumps.flip.takeoff.edge_stability)
	var plan = BaseF.percentage_balanced_plan()
	service.settle(c,plan,0.25,[{"jump_id":"lutz","attempts":4}])
	T.assert_equal(float(c.athlete.jumps.lutz.takeoff.edge_stability)>before,true)
	T.assert_equal(float(c.athlete.jumps.lutz.takeoff.edge_stability)-before<=0.25,true)
	T.assert_equal(c.athlete.jumps.flip.takeoff.edge_stability,unobserved)
	T.assert_equal(float(c.condition_state.psychology.stress)<40.0,true)

func no_execution() -> void:
	var service = _service()
	if service == null: return
	var c = F.starting(73304)
	c.condition_state.psychology.stress = 40.0
	c.athlete.jumps.lutz.observations.assign([{"label":"用刃不稳"}])
	var before := JSON.stringify(c.to_dict())
	service.settle(c,BaseF.percentage_balanced_plan(),0.0,[{"jump_id":"lutz","attempts":4}])
	service.settle(c,BaseF.percentage_balanced_plan(),0.25,[])
	T.assert_equal(JSON.stringify(c.to_dict()),before)
