extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const CareerCommandService = preload("res://src/simulation/career_command_service.gd")
const TrainingRecommendationPresenter = preload("res://src/app/training_recommendation_presenter.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const SeasonBundleRepository = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"season continuation refreshes coaching without overwriting manual plans", "callable":test_adaptive_coach_continuation},
		{"name": "unknown command is rejected without mutating the career", "callable": test_unknown_command_is_atomic},
		{"name": "malformed record event command is rejected without mutating the career", "callable": test_malformed_record_event_is_atomic},
		{"name": "record event applies deterministically to an isolated clone", "callable": test_record_event_applies_to_clone},
		{"name": "accepted command result is deeply separated from its inputs", "callable": test_accepted_command_deep_copy_separation},
		{"name": "coach recovery plan expires after one completed quarter", "callable": test_recovery_plan_is_one_quarter_only},
	]

func test_adaptive_coach_continuation() -> void:
	var career = Fixtures.starting_career(1601)
	Fixtures.clear_jump_progress(career)
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var service = load("res://src/simulation/coach_training_plan_service.gd")
	career.last_generated_plan = service.build(career,intent).plan.to_dict()
	career.event_ledger.append({"kind":"coach_curriculum", "intent":intent.to_dict(), "executed_plan":career.last_generated_plan.duplicate(true)})
	var toe = career.athlete.jumps.toe_loop
	toe.unlocked_rotations = 1
	toe.attempt_evidence.single = {"attempts":20,"successes":10,"clean_successes":3}
	toe.proficiency.single = 30.0
	career.athlete.body.strength_readiness = 50.0
	career.athlete.body.joint_readiness = 50.0
	TestSupport.assert_equal(service.build(career,intent).plan.jump_rotations.toe_loop,2)
	career = load("res://src/domain/career_state.gd").from_dict(JSON.parse_string(JSON.stringify(career.to_dict())))
	var applied := CareerCommandService.apply(career,{"type":"advance_quarter", "bundle":SeasonBundleRepository.for_career(career)})
	TestSupport.assert_equal(applied.ok,true,str(applied.get("stop_node",applied.get("error",""))))
	if not applied.ok: return
	TestSupport.assert_equal(applied.career.last_generated_plan.jump_rotations.toe_loop,2,"season shortcut must not freeze learned single targets")
	# A deliberately edited manual plan no longer matches the coaching receipt.
	career.last_generated_plan.shares.rest += 5
	career.last_generated_plan.shares.skating_foundation -= 5
	var manual: Dictionary = career.last_generated_plan.duplicate(true)
	var edited := CareerCommandService.apply(career,{"type":"advance_quarter", "bundle":SeasonBundleRepository.for_career(career)})
	TestSupport.assert_equal(edited.ok,true)
	if edited.ok: TestSupport.assert_equal(edited.career.last_generated_plan,manual,"manual edits must remain exactly the player's plan")
	var resumed = load("res://src/domain/career_state.gd").from_dict(JSON.parse_string(JSON.stringify(applied.career.to_dict())))
	resumed.condition_state.pending_training_events = [] # Responses are tested separately.
	var second := CareerCommandService.apply(resumed,{"type":"advance_quarter", "bundle":SeasonBundleRepository.for_career(resumed)})
	TestSupport.assert_equal(second.ok,true,str(second.get("stop_node",{})))
	if second.ok: TestSupport.assert_equal(second.career.last_generated_plan.jump_rotations.toe_loop>=2,true,"coaching receipt must survive repeated JSON reloads")

func test_unknown_command_is_atomic() -> void:
	var career = Fixtures.starting_career(1301)
	var before := JSON.stringify(career.to_dict())
	var failed := CareerCommandService.apply(career, {"type": "unknown"})
	TestSupport.assert_equal(failed.ok, false)
	TestSupport.assert_equal(failed.career, career)
	TestSupport.assert_equal(failed.events, [])
	TestSupport.assert_equal(failed.error.is_empty(), false)
	TestSupport.assert_equal(JSON.stringify(career.to_dict()), before)

func test_malformed_record_event_is_atomic() -> void:
	var career = Fixtures.starting_career(1302)
	var before := JSON.stringify(career.to_dict())
	var failed := CareerCommandService.apply(career, {"type": "record_event", "event": []})
	TestSupport.assert_equal(failed.ok, false)
	TestSupport.assert_equal(failed.career, career)
	TestSupport.assert_equal(failed.events, [])
	TestSupport.assert_equal(JSON.stringify(career.to_dict()), before)

func test_record_event_applies_to_clone() -> void:
	var career = Fixtures.starting_career(1303)
	var event := {"id": "evt-1", "kind": "audit", "details": {"decision": "continue"}}
	var first := CareerCommandService.apply(career, {"type": "record_event", "event": event})
	var second := CareerCommandService.apply(career, {"type": "record_event", "event": event})
	TestSupport.assert_equal(first.ok, true)
	TestSupport.assert_equal(first.error, "")
	TestSupport.assert_equal(first.career == career, false)
	TestSupport.assert_equal(first.career.to_dict(), second.career.to_dict())
	TestSupport.assert_equal(first.events, [event])
	TestSupport.assert_equal(first.career.event_ledger, [event])
	TestSupport.assert_equal(career.event_ledger, [])

func test_accepted_command_deep_copy_separation() -> void:
	var career = Fixtures.starting_career(1304)
	career.selection_state.applications = {"jgp": {"status": "draft"}}
	var event := {"id": "evt-2", "kind": "audit", "details": {"tags": ["created"]}}
	var applied := CareerCommandService.apply(career, {"type": "record_event", "event": event})
	applied.career.selection_state.applications.jgp.status = "submitted"
	applied.career.event_ledger[0].details.tags.append("committed")
	event.details.tags.append("caller-mutated")
	TestSupport.assert_equal(career.selection_state.applications.jgp.status, "draft")
	TestSupport.assert_equal(career.event_ledger, [])
	TestSupport.assert_equal(applied.career.event_ledger[0].details.tags, ["created", "committed"])
	TestSupport.assert_equal(applied.events[0].details.tags, ["created"])

func test_recovery_plan_is_one_quarter_only() -> void:
	var career = Fixtures.starting_career(1310)
	var recommendation := TrainingRecommendationPresenter.for_career(career, CatalogRepository.load_catalog())
	var recovery: Dictionary = recommendation.options.filter(func(option): return option.id == "recovery")[0]
	career.last_training_policy = recovery.policy.duplicate(true)
	career.last_generated_plan = recovery.plan.duplicate(true)
	var applied := CareerCommandService.apply(career, {"type": "advance_quarter", "bundle": SeasonBundleRepository.for_career(career)})
	TestSupport.assert_equal(applied.ok, true)
	if not applied.ok: return
	TestSupport.assert_equal(applied.career.last_training_policy, {})
	TestSupport.assert_equal(applied.career.last_generated_plan, {})
	TestSupport.assert_equal(applied.events.any(func(event): return event.get("kind") == "training_plan_expired"), true)
