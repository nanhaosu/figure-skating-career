extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "valid character uses background effects", "callable": test_valid_character_uses_background_effects},
		{"name": "new character owns explicit story and random context", "callable": test_new_character_foundation},
		{"name": "character age is six to eight", "callable": test_character_age_is_six_to_eight},
		{"name": "factory trims a valid display name", "callable": test_factory_trims_a_valid_display_name},
		{"name": "factory rejects invalid identifiers and seed", "callable": test_factory_rejects_invalid_identifiers_and_seed},
		{"name": "factory rejects a catalog with validation errors", "callable": test_factory_rejects_catalog_errors},
		{"name": "factory validates skating start age", "callable": test_factory_validates_skating_start_age},
		{"name": "factory applies one deterministic pre-career history", "callable": test_factory_applies_deterministic_history},
		{"name": "six-year-old may begin skating at handoff", "callable": test_zero_duration_factory_handoff},
		{"name": "generated childhood preserves pristine competition state and random streams", "callable": test_history_does_not_create_results_or_consume_streams},
	]

func test_valid_character_uses_background_effects() -> void:
	var catalog := CatalogRepository.load_catalog()
	var result := CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, catalog)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.career.clock.year, 2014)
	TestSupport.assert_equal(result.career.clock.quarter, 1)
	TestSupport.assert_equal(result.career.seed, 42)
	TestSupport.assert_equal(result.career.schema_version, preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	TestSupport.assert_equal(result.career.athlete.display_name, "林澄")
	TestSupport.assert_equal(result.career.athlete.skating.deep_edge > 28.0, true)
	TestSupport.assert_equal(result.career.athlete.resources.ice_access > 35.0, true)
	TestSupport.assert_equal(result.career.relationships.guardian.control, 35.0)
	TestSupport.assert_equal(result.career.relationships.has("coach"), true)

func test_new_character_foundation() -> void:
	var result := CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, CatalogRepository.load_catalog())
	var serialized: Dictionary = result.career.to_dict()
	TestSupport.assert_equal(serialized.get("story_context", {}), {
		"discipline": "women_singles",
		"home_federation": "CHN",
		"start_year": 2014,
		"rule_mode": "story_time",
	})
	TestSupport.assert_equal(serialized.get("random_streams", {}), {"base_seed": 42, "steps": {}})

func test_character_age_is_six_to_eight() -> void:
	var result := CareerFactory.create("林澄", 2003, "entry_interest_class", "family_supportive", 42, CatalogRepository.load_catalog())
	TestSupport.assert_equal(result.errors, ["2014年时年龄必须为6至8岁"])
	TestSupport.assert_equal(result.career, null)

func test_factory_trims_a_valid_display_name() -> void:
	var result := CareerFactory.create("  林澄  ", 2007, "entry_interest_class", "family_supportive", 0, CatalogRepository.load_catalog())
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.career.athlete.display_name, "林澄")

func test_factory_rejects_invalid_identifiers_and_seed() -> void:
	var result := CareerFactory.create("", 2007, "unknown", "missing", -1, CatalogRepository.load_catalog())
	TestSupport.assert_equal(result.errors, ["姓名长度必须为1至20个字符", "请选择有效的入门路径", "请选择有效的家庭背景", "随机种子必须为非负整数"])
	TestSupport.assert_equal(result.career, null)

func test_factory_rejects_catalog_errors() -> void:
	var catalog := CatalogRepository.load_catalog()
	catalog.errors = ["backgrounds.entry_paths must contain exactly 5 entries, got 4"]
	var result := CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, catalog)
	TestSupport.assert_equal(result, {
		"career": null,
		"errors": ["backgrounds.entry_paths must contain exactly 5 entries, got 4"],
	})

func test_factory_validates_skating_start_age() -> void:
	var catalog := CatalogRepository.load_catalog()
	var too_early: Dictionary = CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, catalog, 2)
	var too_late: Dictionary = CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, catalog, 7)
	TestSupport.assert_equal(too_early.errors, ["开始学滑年龄必须为3至6岁"])
	TestSupport.assert_equal(too_late.errors, ["开始学滑年龄必须为3至6岁"])
	TestSupport.assert_equal(too_early.career, null)
	TestSupport.assert_equal(too_late.career, null)

func test_factory_applies_deterministic_history() -> void:
	var catalog := CatalogRepository.load_catalog()
	var first: Dictionary = CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, catalog, 4)
	var second: Dictionary = CareerFactory.create("林澄", 2007, "entry_interest_class", "family_supportive", 42, catalog, 4)
	TestSupport.assert_equal(first.errors, [])
	TestSupport.assert_equal(first.career.pre_career_history.is_empty(), false)
	TestSupport.assert_equal(first.career.to_dict(), second.career.to_dict())
	var learned := 0
	for jump in first.career.athlete.jumps.values(): learned += int(jump.unlocked_rotations)
	TestSupport.assert_equal(learned > 0, true)

func test_zero_duration_factory_handoff() -> void:
	var result: Dictionary = CareerFactory.create("初学者", 2008, "entry_interest_class", "family_supportive", 7, CatalogRepository.load_catalog(), 6)
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.career.pre_career_history.training_quarters, 0)
	for jump in result.career.athlete.jumps.values():
		TestSupport.assert_equal(int(jump.unlocked_rotations) <= 1, true)

func test_history_does_not_create_results_or_consume_streams() -> void:
	var result: Dictionary = CareerFactory.create("林澄", 2007, "entry_club_trial", "family_ambitious", 42, CatalogRepository.load_catalog(), 4)
	var career = result.career
	TestSupport.assert_equal(career.random_streams.to_dict(), {"base_seed": 42, "steps": {}})
	TestSupport.assert_equal(career.record_book, {"international": {}, "all_formal": {}})
	TestSupport.assert_equal(career.competition_archive, [])
	TestSupport.assert_equal(career.ranking_state, {"domestic_points": 0, "isu_world": 0, "season_world": 0, "selection_evidence": {}})
	TestSupport.assert_equal(career.certification_state, {"national_technical_grade": 0, "last_assessment": {}, "history": []})
