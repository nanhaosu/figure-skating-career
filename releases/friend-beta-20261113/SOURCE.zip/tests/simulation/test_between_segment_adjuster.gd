extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const Adjuster = preload("res://src/simulation/between_segment_adjuster.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "between segment options react to short result", "callable": test_dynamic_options},
		{"name": "protect option lowers risk without mutating original", "callable": test_protect_copy},
		{"name": "keep option preserves exact free program", "callable": test_keep_program},
	]

func test_dynamic_options() -> void:
	var options := Adjuster.options({"falls": 2, "fatigue_end": 55.0, "provisional_rank": 4}, _free_program())
	var ids := options.map(func(option): return option.id)
	TestSupport.assert_equal(ids.has("keep"), true)
	TestSupport.assert_equal(ids.has("protect"), true)
	TestSupport.assert_equal(ids.has("chase"), true)

func test_protect_copy() -> void:
	var original = _free_program()
	var result := Adjuster.apply(original, "protect")
	TestSupport.assert_equal(result.program.elements[0].rotations, 2)
	TestSupport.assert_equal(original.elements[0].rotations, 3)
	TestSupport.assert_equal(result.program.whole_run_familiarity < original.whole_run_familiarity, true)
	TestSupport.assert_equal(result.strategy_overrides.risk, "conservative")

func test_keep_program() -> void:
	var original = _free_program()
	var result := Adjuster.apply(original, "keep")
	TestSupport.assert_equal(result.program.to_dict(), original.to_dict())
	TestSupport.assert_equal(result.strategy_overrides, {})

func _free_program():
	var program = SkatingProgram.create("free", "free", [
		ProgramElement.create("triple", "jump", "toe_loop", 3).element,
		ProgramElement.create("double", "jump", "salchow", 2).element,
		ProgramElement.create("spin", "spin").element,
	]).program
	program.whole_run_familiarity = 80.0
	program.slot_familiarity = {"triple": 75.0, "double": 80.0, "spin": 82.0}
	return program
