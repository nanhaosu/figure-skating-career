extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Plan = preload("res://src/domain/training_plan.gd")
const Career = preload("res://src/simulation/career_simulator.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Commands = preload("res://src/simulation/career_command_service.gd")
const Authority = preload("res://src/simulation/authority_resolver.gd")
const Milestone = preload("res://src/simulation/milestone_advance_service.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const Formal = preload("res://src/simulation/formal_competition_simulator.gd")
const Internal = preload("res://src/simulation/internal_competition_simulator.gd")
const Program = preload("res://src/domain/skating_program.gd")
const PerformanceSim = preload("res://src/simulation/program_performance_simulator.gd")
const CONDITION := "res://src/simulation/athlete_condition_service.gd"
const NODES := "res://src/simulation/key_node_service.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"extreme load causes more injuries across fixed seeds", "callable":test_injury_matrix},
		{"name":"condition streams replay without consuming training rng", "callable":test_replay},
		{"name":"acute fatigue reduces actual legacy training output", "callable":test_fatigue_output},
		{"name":"growth warning pauses progression before body change", "callable":test_growth_warning},
		{"name":"serious injury blocks training and both competition entries", "callable":test_serious_injury},
		{"name":"psychological pressure alters actual program execution", "callable":test_psychology},
		{"name":"four child authority choices commit distinct consequences", "callable":test_four_responses},
		{"name":"malformed and forged authority commands are atomic", "callable":test_bad_commands},
		{"name":"secret practice persists and discovery changes future supervision", "callable":test_secret_discovery},
		{"name":"condition and pending nodes survive save and render fuzzy labels", "callable":test_save_and_ui},
		{"name":"save rejects invalid condition severities and nodes", "callable":test_invalid_save},
		{"name":"authority command cannot apply the same relationship delta twice", "callable":test_authority_replay},
		{"name":"minor injury reduces real staged jump output and stress slows recovery", "callable":test_minor_injury_output},
		{"name":"main cannot launch injured skater or falsely complete a blocked quarter", "callable":test_medical_ui_gate},
	]

func _service(path: String):
	T.assert_equal(ResourceLoader.exists(path), true)
	return load(path) if ResourceLoader.exists(path) else null

func extreme():
	var shares := F.percentage_balanced_plan().shares
	for key in shares: shares[key] = 0
	shares.jump_toe_loop = 95
	shares.rest = 5
	return Plan.create(shares, {"toe_loop":3}).plan

func test_injury_matrix() -> void:
	var service = _service(CONDITION)
	if service == null: return
	var counts := [0, 0]
	for seed in range(100, 160):
		for index in 2:
			var career = F.starting_career(seed)
			var result: Dictionary = service.advance_quarter(career, extreme() if index == 0 else F.percentage_balanced_plan(), seed)
			counts[index] += result.injuries.size()
	print("CONDITION seeds100..159 extreme=", counts[0], " balanced=", counts[1])
	T.assert_equal(counts[0] > counts[1], true)

func test_replay() -> void:
	var service = _service(CONDITION)
	if service == null: return
	var a = F.starting_career(102)
	var b = F.starting_career(102)
	var before: Dictionary = a.random_streams.to_dict()
	T.assert_equal(service.advance_quarter(a, extreme(), 102), service.advance_quarter(b, extreme(), 102))
	T.assert_equal(a.condition_state, b.condition_state)
	T.assert_equal(a.random_streams.steps.get("training", 0), before.steps.get("training", 0))
	T.assert_equal(a.random_streams.steps.get("condition_injury", 0), 1)

func test_fatigue_output() -> void:
	var fresh = F.starting_career(123)
	var tired = F.starting_career(123)
	fresh.athlete.birth_year = 1990
	tired.athlete.birth_year = 1990
	tired.athlete.body.acute_fatigue = 80.0
	var baseline: float = fresh.athlete.skating.deep_edge
	Career.advance_quarter(fresh, F.balanced_plan(), Catalog.load_catalog())
	Career.advance_quarter(tired, F.balanced_plan(), Catalog.load_catalog())
	T.assert_equal(tired.athlete.skating.deep_edge - baseline < fresh.athlete.skating.deep_edge - baseline, true)

func test_growth_warning() -> void:
	var service = _service(CONDITION)
	var nodes = _service(NODES)
	if service == null or nodes == null: return
	var career = F.starting_career(801)
	career.clock.year = 2017
	career.athlete.birth_year = 2006
	var body: Dictionary = career.athlete.body.duplicate(true)
	service.advance_quarter(career, F.balanced_plan(), 801)
	T.assert_equal(career.condition_state.growth_phase, "stable")
	T.assert_equal(career.athlete.body.growth_trend, body.growth_trend)
	T.assert_equal(nodes.pending(career)[0].kind, "growth_warning")
	var before: Dictionary = career.to_dict()
	var stopped := Milestone.advance(career, F.balanced_plan(), Catalog.load_catalog(), func(_c): return true)
	T.assert_equal(stopped.stop_reason, "key_node")
	T.assert_equal(career.to_dict(), before)
	var applied := Commands.apply(career, {"type":"resolve_key_node", "node_id":nodes.pending(career)[0].id, "response_id":"acknowledge"})
	T.assert_equal(applied.ok, true)
	if not applied.ok: return
	T.assert_equal(applied.career.condition_state.growth_phase, "stable")
	applied.career.clock.advance_quarter()
	service.advance_quarter(applied.career, F.balanced_plan(), 802)
	T.assert_equal(applied.career.condition_state.growth_phase, "rapid")
	T.assert_equal(applied.career.athlete.body.growth_trend > body.growth_trend, true)

func injured():
	var career = F.formal_junior_career(808)
	career.condition_state.injuries = [{"id":"ankle-1", "severity":0.9, "remaining_quarters":2, "status":"active", "site":"ankle"}]
	return career

func test_serious_injury() -> void:
	var career = injured()
	var before: Dictionary = career.to_dict()
	T.assert_equal(Career.advance_quarter(career, extreme(), Catalog.load_catalog()), [])
	T.assert_equal(career.to_dict(), before)
	var formal := Formal.create_session(career, F.u_series_event(), career.active_programs, "balanced", 99, 5)
	T.assert_equal(formal.status, "error")
	T.assert_equal(career.to_dict(), before)
	var internal := Internal.start_event(career, Program.from_dict(career.active_programs.short), Program.from_dict(career.active_programs.free), {}, {}, 99, 0)
	T.assert_equal(internal.get("status"), "error")
	var service = _service(CONDITION)
	if service == null: return
	var shares: Dictionary = extreme().shares
	shares.jump_toe_loop = 0
	shares.rest = 100
	for index in 2:
		service.advance_quarter(career, Plan.create(shares).plan, index)
		career.clock.advance_quarter()
	T.assert_equal(service.can_compete(career), true)

func test_psychology() -> void:
	var service = _service(CONDITION)
	if service == null: return
	var calm = F.formal_junior_career(909)
	var anxious = F.formal_junior_career(909)
	anxious.condition_state.psychology = {"stress":90.0, "label":"压力偏高"}
	var program = Program.from_dict(calm.active_programs.short)
	var a := RandomNumberGenerator.new()
	var b := RandomNumberGenerator.new()
	a.seed = 42
	b.seed = 42
	var calm_run := PerformanceSim.simulate(calm.athlete, program, {}, service.competition_context(calm), a)
	var anxious_run := PerformanceSim.simulate(anxious.athlete, program, {}, service.competition_context(anxious), b)
	T.assert_equal(anxious_run.elements[0].success_probability < calm_run.elements[0].success_probability, true)

func test_four_responses() -> void:
	var allocations: Array = []
	var relationships: Array = []
	var efficiencies: Array = []
	for response in ["accept", "negotiate", "insist", "pretend_comply"]:
		var career = F.career_with_guardian(0.0, 0.0)
		career.relationships.coach.control = 0.0
		career.athlete.mind.autonomy = 10.0
		var proposal = Authority.preview(career, extreme())
		T.assert_equal(proposal.status, "needs_response")
		var before: Dictionary = career.to_dict()
		var result := Commands.apply(career, {"type":"resolve_authority_conflict", "proposal":proposal.to_dict(), "conflict_id":proposal.conflicts[0].id, "response_id":response})
		T.assert_equal(result.ok, true)
		T.assert_equal(career.to_dict(), before)
		if not result.ok: continue
		var saved: Dictionary = result.career.last_generated_plan
		allocations.append(saved.executed)
		relationships.append(result.career.relationships.coach.to_dict())
		efficiencies.append(saved.training_efficiency)
		T.assert_equal(result.events.any(func(e): return e.get("category") == "relationship_delta"), true)
	for i in allocations.size():
		for j in range(i + 1, allocations.size()):
			T.assert_equal(allocations[i] != allocations[j], true)
			T.assert_equal(relationships[i] != relationships[j], true)
			T.assert_equal(efficiencies[i] != efficiencies[j], true)

func test_bad_commands() -> void:
	var career = F.starting_career(333)
	var before: Dictionary = career.to_dict()
	for command in [{"type":"resolve_authority_conflict", "proposal":{}}, {"type":"resolve_key_node", "node_id":[], "response_id":"acknowledge"}, {"type":"resolve_key_node", "node_id":"missing", "response_id":"acknowledge"}]:
		T.assert_equal(Commands.apply(career, command).ok, false)
		T.assert_equal(career.to_dict(), before)
	var proposal = Authority.preview(career, extreme()).to_dict()
	proposal.conflicts[0].proposed_shares = extreme().shares
	T.assert_equal(Commands.apply(career, {"type":"resolve_authority_conflict", "proposal":proposal, "conflict_id":proposal.conflicts[0].id, "response_id":"accept"}).ok, false)
	T.assert_equal(career.to_dict(), before)

func test_secret_discovery() -> void:
	var career = F.starting_career(111)
	career.athlete.mind.autonomy = 30.0
	career.relationships.guardian.control = 100.0
	career.relationships.guardian.health_priority = 100.0
	var proposal = Authority.preview(career, extreme())
	var result := Commands.apply(career, {"type":"resolve_authority_conflict", "proposal":proposal.to_dict(), "conflict_id":proposal.conflicts[0].id, "response_id":"pretend_comply"})
	T.assert_equal(result.ok, true)
	if not result.ok: return
	career = result.career
	T.assert_equal(career.last_generated_plan.secret_practice_intent.is_empty(), false)
	T.assert_equal(Save.save(career, "user://task5-secret.json").ok, true)
	var restored = Save.load_save("user://task5-secret.json").career
	proposal = preload("res://src/domain/plan_proposal.gd").from_dict(restored.last_generated_plan)
	T.assert_equal(proposal.executed != null, true)
	if proposal.executed == null: return
	Career.advance_proposal(restored, proposal, Catalog.load_catalog())
	T.assert_equal(restored.event_ledger.any(func(e): return e.get("kind") == "secret_practice_discovered"), true)
	T.assert_equal(restored.condition_state.get("secret_practice_blocked", false), true)

func test_save_and_ui() -> void:
	var service = _service(CONDITION)
	var nodes = _service(NODES)
	if service == null or nodes == null: return
	var career = F.starting_career(812)
	career.clock.year = 2018
	service.advance_quarter(career, F.balanced_plan(), 812)
	career.condition_state.psychology = {"stress":82.125, "label":"压力偏高"}
	var path := "user://task5-condition.json"
	T.assert_equal(Save.save(career, path).ok, true)
	var loaded := Save.load_save(path)
	T.assert_equal(loaded.ok, true)
	if not loaded.ok: return
	T.assert_equal(JSON.stringify(loaded.career.condition_state), JSON.stringify(career.condition_state))
	T.assert_equal(nodes.pending(loaded.career), nodes.pending(career))
	var panel = load("res://src/app/summary_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present(loaded.career, [])
	T.assert_equal(panel.get_node("%GrowthObservations").text.contains("近期生长速度偏快"), true)
	T.assert_equal(panel.get_node("%SetbacksCosts").text.contains("压力偏高"), true)
	T.assert_equal(panel.get_node("%SetbacksCosts").text.contains("82.125"), false)
	var button = panel.get_node_or_null("%ResolveKeyNodeButton")
	T.assert_equal(button != null, true)
	if button != null:
		var clicked: Array[String] = []
		panel.key_node_response_requested.connect(func(id): clicked.append(id))
		button.pressed.emit()
		T.assert_equal(clicked, ["growth:rapid"])
	panel.free()

func test_invalid_save() -> void:
	var career = injured()
	career.condition_state.injuries[0].severity = "severe"
	T.assert_equal(Save.save(career, "user://task5-invalid.json").ok, false)
	career = F.starting_career(810)
	career.condition_state.key_nodes = [{"id":"bad", "kind":"growth_warning", "resolved":"yes"}]
	T.assert_equal(Save.save(career, "user://task5-invalid.json").ok, false)

func test_authority_replay() -> void:
	var career = F.starting_career(991)
	var proposal = Authority.preview(career, extreme())
	var command := {"type":"resolve_authority_conflict", "proposal":proposal.to_dict(), "conflict_id":proposal.conflicts[0].id, "response_id":"accept"}
	var first := Commands.apply(career, command)
	T.assert_equal(first.ok, true)
	var before: Dictionary = first.career.to_dict()
	T.assert_equal(Commands.apply(first.career, command).ok, false)
	T.assert_equal(first.career.to_dict(), before)

func test_minor_injury_output() -> void:
	var fresh = F.starting_career(811)
	var hurt = F.starting_career(811)
	hurt.condition_state.injuries = [{"id":"minor", "site":"ankle", "severity":0.4, "status":"active", "remaining_quarters":2}]
	var proposal_type = preload("res://src/domain/plan_proposal.gd")
	for career in [fresh, hurt]:
		var proposal = proposal_type.create(F.percentage_balanced_plan())
		proposal.status = "resolved"
		Career.advance_proposal(career, proposal, Catalog.load_catalog())
	T.assert_equal(hurt.athlete.jumps.toe_loop.attempts < fresh.athlete.jumps.toe_loop.attempts, true)
	var calm = F.starting_career(812)
	var anxious = F.starting_career(812)
	anxious.condition_state.psychology = {"stress":90.0, "label":"压力偏高"}
	for career in [calm, anxious]:
		career.athlete.body.acute_fatigue = 50.0
		Career.advance_quarter(career, F.balanced_plan(), Catalog.load_catalog())
	T.assert_equal(anxious.athlete.body.acute_fatigue > calm.athlete.body.acute_fatigue, true)

func test_medical_ui_gate() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.autosave_path = "user://medical-refusal-must-not-save.json"
	main.active_career = injured()
	var before: Dictionary = main.active_career.to_dict()
	T.assert_equal(main.start_internal_competition({"status":"ready"}).ok, false)
	T.assert_equal(main.active_career.to_dict() == before, true)
	var panel = main.get_node("%QuarterPanel")
	panel.setup(main.active_career, Catalog.load_catalog())
	main._show_screen(panel)
	panel.set_allocations(F.percentage_balanced_plan().shares)
	before = main.active_career.to_dict()
	var saved_before := FileAccess.get_file_as_bytes(main.autosave_path) if FileAccess.file_exists(main.autosave_path) else PackedByteArray()
	# The default button now delegates safe planning to the coach. Exercise the
	# explicit advanced plan gate directly: a jump-heavy player plan must still
	# be refused before registration or persistence.
	await panel.request_advance()
	T.assert_equal(main.active_career.to_dict() == before,true,"medical refusal must precede registration refresh")
	T.assert_equal(panel.visible,true,"medical refusal must not navigate away from training")
	T.assert_equal(main.get_node("%SeasonOverviewPanel").visible,false)
	var proposal = preload("res://src/domain/plan_proposal.gd").create(F.percentage_balanced_plan())
	proposal.status = "resolved"
	panel._active_proposal = proposal
	await panel._apply_pending_plan()
	T.assert_equal(panel._quarter_completed, false)
	T.assert_equal(main.active_career.to_dict() == before, true)
	T.assert_equal(panel.visible,true)
	var saved_after := FileAccess.get_file_as_bytes(main.autosave_path) if FileAccess.file_exists(main.autosave_path) else PackedByteArray()
	T.assert_equal(saved_after,saved_before,"medical refusal must not write an autosave")
	main.free()
