extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const AuthorityResolver = preload("res://src/simulation/authority_resolver.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "high health priority adds rest to unsafe plan", "callable": test_high_health_priority_adds_rest_to_unsafe_plan},
		{"name": "authority leaves requested plan unchanged", "callable": test_authority_leaves_requested_plan_unchanged},
		{"name": "guardian control threshold permits health protection", "callable": test_guardian_control_threshold_permits_health_protection},
		{"name": "health priority threshold permits health protection", "callable": test_health_priority_threshold_permits_health_protection},
		{"name": "coach trust threshold does not adjust plan", "callable": test_coach_trust_threshold_does_not_adjust_plan},
		{"name": "jump allocation of five triggers adult protection", "callable": test_jump_allocation_of_five_triggers_adult_protection},
		{"name": "rest allocation of two does not trigger achievement pressure", "callable": test_rest_allocation_of_two_does_not_trigger_achievement_pressure},
		{"name": "guardian achievement pressure shifts excess rest to jumps", "callable": test_guardian_achievement_pressure_shifts_excess_rest_to_jumps},
		{"name": "coach safety precedes low trust style preference", "callable": test_coach_safety_precedes_low_trust_style_preference},
		{"name": "guardian decision is resolved before coach decision", "callable": test_guardian_decision_is_resolved_before_coach_decision},
		{"name": "authority does not alter plan after dependent ages", "callable": test_authority_does_not_alter_plan_after_dependent_ages},
		{"name": "no applicable authority rule preserves requested plan", "callable": test_no_applicable_authority_rule_preserves_requested_plan},
		{"name": "preview exposes conflict before execution", "callable": test_preview_exposes_conflict},
		{"name": "child responses are limited by autonomy", "callable": test_child_response_availability},
		{"name": "successful persuasion preserves desired plan", "callable": test_successful_persuasion_preserves_desired_plan},
		{"name": "pretend compliance stores the refused jump as secret intent", "callable": test_pretend_compliance_stores_secret_intent},
		{"name": "ordinary protective guardian challenges jump overload", "callable": test_ordinary_guardian_challenges_jump_overload},
		{"name": "coach challenges four skating units when jumps are neglected", "callable": test_coach_challenges_skating_heavy_plan},
		{"name": "gentle guardian still blocks unsafe jump specialization", "callable": test_gentle_guardian_blocks_unsafe_specialization},
		{"name": "reported pain forces recovery in the next plan", "callable": test_reported_pain_forces_recovery},
		{"name": "teenage athlete remains subject to adult safety review", "callable": test_teenage_athlete_remains_subject_to_safety_review},
		{"name": "critical fatigue blocks even a balanced teenage plan", "callable": test_critical_fatigue_blocks_balanced_teenage_plan},
		{"name": "critical fatigue raises percentage rest to twenty", "callable": test_percentage_critical_fatigue_requires_twenty_rest},
		{"name": "critical fatigue accepts an existing thirty percent recovery plan", "callable": test_percentage_existing_recovery_is_not_a_conflict},
		{"name": "concentrated jump share above forty percent triggers safety", "callable": test_percentage_jump_share_triggers_safety},
		{"name": "distributed forty percent jump lessons do not trigger obsolete overload review", "callable": test_distributed_percentage_lessons},
		{"name": "unprepared double target triggers rotation review", "callable": test_unprepared_double_target_triggers_rotation_review},
		{"name": "rotation review treats every unsafe jump equally", "callable": test_rotation_review_adjusts_all_unsafe_jumps},
		{"name": "pretend compliance retains requested rotation", "callable": test_percentage_pretend_compliance_retains_rotation},
	]

func test_percentage_critical_fatigue_requires_twenty_rest() -> void:
	var career := Fixtures.starting_career(51)
	career.athlete.body.acute_fatigue = 100.0
	var result := AuthorityResolver.resolve(career, Fixtures.percentage_balanced_plan(), _rng())
	TestSupport.assert_equal(result.approved_plan.shares.rest, 20)
	TestSupport.assert_equal(result.approved_plan.total_share(), 100)

func test_percentage_existing_recovery_is_not_a_conflict() -> void:
	var career := Fixtures.starting_career(52)
	career.athlete.body.acute_fatigue = 100.0
	var shares := {"skating_foundation":10,"jump_toe_loop":10,"jump_salchow":5,"jump_loop":5,"jump_flip":5,"jump_lutz":5,"jump_axel":5,"rotation":5,"conditioning":10,"rest":30,"program_short":5,"program_free":5}
	var plan = TrainingPlan.create(shares,{"toe_loop":1,"salchow":1,"loop":1,"flip":1,"lutz":1,"axel":1}).plan
	var before: Dictionary = plan.to_dict()
	var proposal = AuthorityResolver.preview(career,plan)
	TestSupport.assert_equal(proposal.status,"resolved","an already recovery-heavy plan must not create a no-op conflict")
	TestSupport.assert_equal(plan.to_dict(),before,"authority preview must never mutate the player's desired plan")

func test_percentage_jump_share_triggers_safety() -> void:
	var source = Fixtures.percentage_balanced_plan()
	var shares: Dictionary = source.shares
	shares.jump_toe_loop += 10
	shares.jump_salchow -= 5
	shares.skating_foundation -= 5
	var requested = TrainingPlan.create(shares,source.jump_rotations).plan
	var result := AuthorityResolver.resolve(Fixtures.starting_career(52), requested, _rng())
	TestSupport.assert_equal(result.decisions.is_empty(),false,"a genuinely concentrated request still requires protection")
	if result.decisions.is_empty(): return
	TestSupport.assert_equal(result.decisions[0].reason_code, "guardian_health_protection")
	TestSupport.assert_equal(result.approved_plan.total_share(), 100)

func test_distributed_percentage_lessons() -> void:
	var result := AuthorityResolver.resolve(Fixtures.starting_career(52), Fixtures.percentage_balanced_plan(), _rng())
	TestSupport.assert_equal(result.decisions,[])
	TestSupport.assert_equal(result.approved_plan.total_share(),100)

func test_unprepared_double_target_triggers_rotation_review() -> void:
	var career := Fixtures.career_with_guardian(0.0, 0.0)
	career.athlete.body.strength_readiness = 0.0
	career.athlete.body.joint_readiness = 0.0
	var proposal = AuthorityResolver.preview(career, Fixtures.percentage_plan({"toe_loop": 2}))
	TestSupport.assert_equal(proposal.conflicts[0].reason_code, "coach_rotation_risk")
	TestSupport.assert_equal(proposal.conflicts[0].proposed_jump_rotations.toe_loop, 1)

func test_rotation_review_adjusts_all_unsafe_jumps() -> void:
	var career := Fixtures.career_with_guardian(0.0, 0.0)
	career.athlete.body.strength_readiness = 0.0
	career.athlete.body.joint_readiness = 0.0
	var proposal = AuthorityResolver.preview(career, Fixtures.percentage_plan({"toe_loop":2,"salchow":2,"loop":2}))
	TestSupport.assert_equal(proposal.conflicts[0].reason_code,"coach_rotation_risk")
	for jump_id in ["toe_loop","salchow","loop"]:
		TestSupport.assert_equal(int(proposal.conflicts[0].proposed_jump_rotations[jump_id]),1,"risk review must not depend on jump dictionary order: "+jump_id)

func test_percentage_pretend_compliance_retains_rotation() -> void:
	var career := Fixtures.career_with_guardian(0.0, 0.0)
	career.athlete.body.strength_readiness = 0.0
	career.athlete.body.joint_readiness = 0.0
	career.athlete.mind.autonomy = 30.0
	var proposal = AuthorityResolver.preview(career, Fixtures.percentage_plan({"toe_loop": 2}))
	AuthorityResolver.respond(career, proposal, proposal.conflicts[0].id, "pretend_comply", _rng())
	TestSupport.assert_equal(proposal.approved.jump_rotations.toe_loop, 1)
	TestSupport.assert_equal(proposal.secret_practice_intent.rotations, 2)

func test_successful_persuasion_preserves_desired_plan() -> void:
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	career.athlete.mind.autonomy = 45.0
	career.athlete.mind.expression = 100.0
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	var rng := RandomNumberGenerator.new()
	rng.seed = 1
	AuthorityResolver.respond(career, proposal, proposal.conflicts[0].id, "persuade", rng)
	TestSupport.assert_equal(proposal.approved.to_dict(), proposal.desired.to_dict())
	TestSupport.assert_equal(proposal.decisions[0].adult_change_accepted, false)

func test_pretend_compliance_stores_secret_intent() -> void:
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	career.athlete.mind.autonomy = 30.0
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	AuthorityResolver.respond(career, proposal, proposal.conflicts[0].id, "pretend_comply", _rng())
	TestSupport.assert_equal(proposal.approved.jump_units(), 5)
	TestSupport.assert_equal(proposal.secret_practice_intent.jump_id, "toe_loop")
	TestSupport.assert_equal(proposal.secret_practice_intent.units, 1)
	TestSupport.assert_equal(proposal.status, "resolved")

func test_ordinary_guardian_challenges_jump_overload() -> void:
	var career := Fixtures.career_with_guardian(35.0, 75.0)
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].reason_code, "guardian_health_protection")

func test_coach_challenges_skating_heavy_plan() -> void:
	var career := Fixtures.starting_career(4)
	var proposal = AuthorityResolver.preview(career, _plan(5, 2, 1, 2, 2))
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].reason_code, "coach_jump_priority")

func test_gentle_guardian_blocks_unsafe_specialization() -> void:
	var career := Fixtures.career_with_guardian(0.0, 75.0)
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].actor_id, "guardian")

func test_reported_pain_forces_recovery() -> void:
	var career := Fixtures.career_with_guardian(0.0, 0.0)
	career.memories.append({"id": "medical", "signature": "medical_restriction", "strength": 80.0})
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].reason_code, "medical_recovery_required")
	TestSupport.assert_equal(int(proposal.conflicts[0].proposed_allocations.rest) >= 2, true)

func test_teenage_athlete_remains_subject_to_safety_review() -> void:
	var career := Fixtures.starting_career(14)
	career.clock.year = 2022
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].reason_code, "guardian_health_protection")

func test_critical_fatigue_blocks_balanced_teenage_plan() -> void:
	var career := Fixtures.starting_career(14)
	career.clock.year = 2022
	career.athlete.body.acute_fatigue = 100.0
	career.athlete.body.ankle_load = 100.0
	career.athlete.body.impact_load = 100.0
	var proposal = AuthorityResolver.preview(career, Fixtures.balanced_plan())
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].reason_code, "fatigue_recovery_required")
	TestSupport.assert_equal(int(proposal.conflicts[0].proposed_allocations.rest), 3)

func test_high_health_priority_adds_rest_to_unsafe_plan() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	var result := AuthorityResolver.resolve(career, Fixtures.jump_heavy_plan(), _rng())
	TestSupport.assert_equal(result.approved_plan.allocations.rest, 2)
	TestSupport.assert_equal(result.approved_plan.jump_units(), 5)
	TestSupport.assert_equal(result.decisions[0].actor_id, "guardian")
	TestSupport.assert_equal(result.decisions[0].action, "adjust_training_plan")
	TestSupport.assert_equal(result.decisions[0].reason_code, "guardian_health_protection")
	TestSupport.assert_equal(result.decisions[0].before.rest, 1)
	TestSupport.assert_equal(result.decisions[0].after.rest, 2)

func test_authority_leaves_requested_plan_unchanged() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	var requested := Fixtures.jump_heavy_plan()
	var before := requested.to_dict()
	AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(requested.to_dict(), before)

func test_guardian_control_threshold_permits_health_protection() -> void:
	var career := Fixtures.career_with_guardian(70, 90)
	var result := AuthorityResolver.resolve(career, Fixtures.jump_heavy_plan(), _rng())
	TestSupport.assert_equal(result.decisions.size(), 1)
	TestSupport.assert_equal(result.decisions[0].reason_code, "guardian_health_protection")

func test_health_priority_threshold_permits_health_protection() -> void:
	var career := Fixtures.career_with_guardian(90, 70)
	var result := AuthorityResolver.resolve(career, Fixtures.jump_heavy_plan(), _rng())
	TestSupport.assert_equal(result.decisions.size(), 1)
	TestSupport.assert_equal(result.decisions[0].reason_code, "guardian_health_protection")

func test_coach_trust_threshold_does_not_adjust_plan() -> void:
	var career := Fixtures.career_with_guardian(0, 0)
	career.relationships["coach"] = RelationshipState.new(35, 35, 0, 75)
	var requested := _plan(2, 5, 2, 2, 1)
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.jump_units(), 4)
	TestSupport.assert_equal(result.decisions[0].actor_id, "coach")
	TestSupport.assert_equal(result.decisions[0].reason_code, "coach_jump_load_safety")

func test_jump_allocation_of_five_triggers_adult_protection() -> void:
	var career := Fixtures.career_with_guardian(90, 70)
	var requested := _plan(2, 5, 2, 2, 1)
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.jump_units(), 4)
	TestSupport.assert_equal(result.approved_plan.allocations.rest, 2)
	TestSupport.assert_equal(result.decisions[0].reason_code, "guardian_health_protection")

func test_rest_allocation_of_two_does_not_trigger_achievement_pressure() -> void:
	var career := Fixtures.career_with_guardian(70, 20)
	var requested := _plan(2, 4, 2, 2, 2)
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.to_dict(), requested.to_dict())
	TestSupport.assert_equal(result.decisions, [])

func test_guardian_achievement_pressure_shifts_excess_rest_to_jumps() -> void:
	var career := Fixtures.career_with_guardian(70, 20)
	var requested := _plan(2, 4, 1, 2, 3)
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.allocations.rest, 2)
	TestSupport.assert_equal(result.approved_plan.jump_units(), 5)
	TestSupport.assert_equal(result.decisions[0].reason_code, "guardian_achievement_pressure")

func test_coach_safety_precedes_low_trust_style_preference() -> void:
	var career := Fixtures.career_with_guardian(0, 0)
	career.relationships["coach"] = RelationshipState.new(35, 20, 0, 75)
	var requested := _plan(2, 5, 2, 2, 1)
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.allocations.skating_foundation, 2)
	TestSupport.assert_equal(result.approved_plan.jump_units(), 4)
	TestSupport.assert_equal(result.decisions.size(), 1)
	TestSupport.assert_equal(result.decisions[0].actor_id, "coach")
	TestSupport.assert_equal(result.decisions[0].reason_code, "coach_jump_load_safety")

func test_guardian_decision_is_resolved_before_coach_decision() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	career.relationships["coach"] = RelationshipState.new(35, 20, 0, 75)
	var result := AuthorityResolver.resolve(career, Fixtures.jump_heavy_plan(), _rng())
	TestSupport.assert_equal(result.approved_plan.allocations.skating_foundation, 3)
	TestSupport.assert_equal(result.approved_plan.jump_units(), 4)
	TestSupport.assert_equal(result.decisions.size(), 2)
	TestSupport.assert_equal(result.decisions[0].actor_id, "guardian")
	TestSupport.assert_equal(result.decisions[1].actor_id, "coach")
	TestSupport.assert_equal(_jump_units(result.decisions[1].before), 5)
	TestSupport.assert_equal(_jump_units(result.decisions[1].after), 4)

func test_authority_does_not_alter_plan_after_dependent_ages() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	career.clock.year = 2026
	var requested := Fixtures.jump_heavy_plan()
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.to_dict(), requested.to_dict())
	TestSupport.assert_equal(result.decisions, [])

func test_no_applicable_authority_rule_preserves_requested_plan() -> void:
	var career := Fixtures.career_with_guardian(69, 90)
	career.relationships["coach"] = RelationshipState.new(35, 35, 0, 75)
	var requested := Fixtures.balanced_plan()
	var result := AuthorityResolver.resolve(career, requested, _rng())
	TestSupport.assert_equal(result.approved_plan.to_dict(), requested.to_dict())
	TestSupport.assert_equal(result.decisions, [])

func test_preview_exposes_conflict() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	TestSupport.assert_equal(proposal.status, "needs_response")
	TestSupport.assert_equal(proposal.conflicts[0].actor_id, "guardian")
	TestSupport.assert_equal(proposal.desired.jump_units(), 6)
	TestSupport.assert_equal(proposal.approved.jump_units(), 6)

func test_child_response_availability() -> void:
	var career := Fixtures.career_with_guardian(90, 90)
	career.athlete.mind["autonomy"] = 10.0
	var proposal = AuthorityResolver.preview(career, Fixtures.jump_heavy_plan())
	var ids: Array = proposal.conflicts[0].responses.map(func(item): return item.id)
	TestSupport.assert_equal(ids.has("accept"), true)
	TestSupport.assert_equal(ids.has("ask_reason"), true)
	TestSupport.assert_equal(ids.has("insist"), false)

func _plan(skating: int, jumps: int, rotation: int, conditioning: int, rest: int) -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation": skating,
		"jump_toe_loop": jumps, "jump_salchow": 0, "jump_loop": 0,
		"jump_flip": 0, "jump_lutz": 0, "jump_axel": 0,
		"rotation": rotation,
		"conditioning": conditioning,
		"rest": rest,
	}).plan

func _jump_units(allocations: Dictionary) -> int:
	var total := 0
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id.begins_with("jump_"):
			total += int(allocations[category_id])
	return total

func _rng() -> RandomNumberGenerator:
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	return rng
