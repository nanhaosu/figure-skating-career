extends RefCounted
const T = preload("res://tests/test_support.gd")
const R = preload("res://src/simulation/competition_ranking_service.gd")
const S = preload("res://src/content/formal_scoring_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"senior Beijing era finished results earn their own standings points","callable":_senior_points},
		{"name":"senior championships require a completed free and canceled events never award","callable":_completion},
		{"name":"promotion keeps separate junior and senior GP allowances and one championship best","callable":_categories},
		{"name":"senior GP rank limits and receipt replay do not manufacture points","callable":_rank_and_replay},
		{"name":"both Beijing scoring catalogs have executable senior policies","callable":_policies},
	]

func _archive(family:String,id:String="event",year:int=2021) -> Dictionary:
	return {"event_id":id,"season_id":"%d-%02d" % [year,(year+1)%100],"status":"complete","event":{"event_family":family,"ruleset_season_start_year":year,"ranking_points_system":"isu_world_standings","status":"held","start_date":"2022-02-17"}}

func _senior_points() -> void:
	# Hand-read Communication1629 p5; these are not JGP placement points.
	for row in [["gp_stage",1,400],["gp_stage",8,191],["gp_final",6,472],["four_continents",3,680],["world_championships",24,106],["olympic_games",2,1080]]:
		var state = R.preview({},_archive(row[0]),{"final_rank":row[1],"free_score":70.0})
		T.assert_equal(state.history[0].world_points,row[2])
		T.assert_equal(state.history[0].domestic_points,0)
		T.assert_equal(state.history[0].jgp_points,0)

func _completion() -> void:
	for family in ["world_championships","four_continents","olympic_games"]:
		var no_free = R.preview({},_archive(family),{"short_rank":1})
		T.assert_equal(no_free.history[0].world_points,0)
		var canceled = _archive(family)
		canceled.event.status = "cancelled"
		T.assert_equal(R.preview({},canceled,{"final_rank":1,"free_score":70.0}).history[0].world_points,0)
	var unfinished = _archive("world_championships")
	unfinished.status = "in_progress"
	T.assert_equal(R.preview({},unfinished,{"final_rank":1,"free_score":70.0}).history[0].world_points,0)

func _categories() -> void:
	var state := {}
	for row in [["jgp_stage","j1"],["jgp_stage","j2"],["gp_stage","g1"],["gp_stage","g2"],["four_continents","fc"],["olympic_games","owg"],["world_championships","wc"]]:
		var archive = _archive(row[0],row[1])
		if row[0] == "jgp_stage": archive.event.ranking_points_system = "isu_jgp_standings"
		state = R.preview(state,archive,{"final_rank":1,"free_score":70.0})
	T.assert_equal(state.season_world.points,2500,"500 juniorGP + 800 seniorGP + best1200 championship, not all championships")
	T.assert_equal(state.history.size(),7,"Excluded totals retain earned receipts")

func _rank_and_replay() -> void:
	for row in [["gp_stage",9],["gp_final",7],["world_championships",25],["four_continents",0]]:
		T.assert_equal(R.preview({},_archive(row[0]),{"final_rank":row[1],"free_score":70.0}).history[0].world_points,0)
	var archive = _archive("gp_stage")
	var first = R.preview({},archive,{"final_rank":1,"free_score":70.0})
	T.assert_equal(R.preview(first,archive,{"final_rank":1,"free_score":70.0}),first)
	var pandemic = _archive("gp_stage","pandemic",2020)
	pandemic.event.ranking_points_system = "none"
	T.assert_equal(R.preview({},pandemic,{"final_rank":1,"free_score":70.0}).history[0].world_points,0)

func _policies() -> void:
	for year in [2020,2021]:
		var loaded = S.load_catalog(year,"women_singles")
		T.assert_equal(loaded.errors,[])
		for family in ["gp_stage","gp_final","four_continents","world_championships","olympic_games"]:
			T.assert_equal(loaded.catalog.event_policies.has(family),true,"Missing actual competition policy "+family)
