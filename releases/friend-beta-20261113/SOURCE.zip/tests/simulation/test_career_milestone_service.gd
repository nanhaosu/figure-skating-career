extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/first_meaning_fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"formal milestones require actual JGP participation not invitations or background events","callable":jgp},
		{"name":"formal triple Axel requires final valid actual evidence not GOE or planned code","callable":axel},
		{"name":"triple Axel first combo part survives a later part fall and input stays immutable","callable":combo},
		{"name":"actual simulator popped Axel shape keeps the attempted 3A without granting completion","callable":popped},
		{"name":"final technical review overrides temporary broadcast color but unresolved review still blocks a 3A milestone","callable":review_state}]

func review_state() -> void:
	for row in [{"review":"resolved","completed":1},{"review":"pending","completed":0}]:
		var a := F.archive()
		a.free_results.player.performance.elements[0].status = "review"
		a.free_results.player.technical_review.review_events = [{"element_id":"axel","status":row.review}]
		var facts: Dictionary = _service().inspect_archive(a)
		T.assert_equal(facts.axel_completed.size(),row.completed,"final review state, not landing color, decides recognition")

func popped() -> void:
	var a := F.popped_axel_archive()
	var before := JSON.stringify(a)
	var facts: Dictionary = _service().inspect_archive(a)
	T.assert_equal(facts.axel_attempts.size(),1,"inner planned_rotations must retain actual popped attempt")
	T.assert_equal(facts.axel_completed.size(),0)
	T.assert_equal(JSON.stringify(a),before)

func _service():
	var path := "res://src/simulation/career_milestone_service.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"formal milestone fact extractor missing")
	return load(path) if FileAccess.file_exists(path) else null

func jgp() -> void:
	var service = _service()
	if service == null: return
	T.assert_equal(service.inspect_archive(F.archive()).jgp_complete.is_empty(),false)
	for family in ["jgp_final","gp_stage","self_funded"]:
		var a := F.archive(); a.event.event_family = family
		T.assert_equal(service.inspect_archive(a).jgp_start,{})
	var world := F.archive("3A",{"world_only":true})
	T.assert_equal(service.inspect_archive(world).jgp_start,{})
	var invitation := F.archive(); invitation.short_results = {}; invitation.free_results = {}; invitation.status = "confirmed"
	T.assert_equal(service.inspect_archive(invitation).jgp_start,{})
	var planned_only := F.archive(); planned_only.short_results.player.performance.elements = [{"element_id":"planned","kind":"jump","parts":[{"jump_id":"axel","rotations":2}]}]; planned_only.free_results = {}
	T.assert_equal(service.inspect_archive(planned_only).jgp_start,{},"a saved programme is not evidence of actually skating")
	var withdrawn := F.archive(); withdrawn.free_results = {}; withdrawn.status = "withdrawn"
	T.assert_equal(service.inspect_archive(withdrawn).jgp_start.is_empty(),false)
	T.assert_equal(service.inspect_archive(withdrawn).jgp_complete,{})

func axel() -> void:
	var service = _service()
	if service == null: return
	var clean := F.archive()
	T.assert_equal(service.inspect_archive(clean).axel_completed.size(),1,"negative GOE alone cannot invalidate clean landed 3A")
	T.assert_equal(service.inspect_archive(F.archive("2A")).axel_completed.size(),0)
	for symbol in ["q","<","<<","*","REP"]:
		var a := F.archive(); a.free_results.player.technical_review.final_elements[0].info = [symbol]
		T.assert_equal(service.inspect_archive(a).axel_completed.size(),0,"reject "+symbol)
	for variant in ["fall","unknown","pending","invalid"]:
		var a := F.archive()
		match variant:
			"fall": a.free_results.player.performance.elements[0].actual.fall = true
			"unknown": a.free_results.player.performance.elements[0].erase("actual")
			"pending": a.free_results.player.technical_review.review_events = [{"element_id":"axel","status":"pending"}]
			"invalid": a.free_results.player.technical_review.final_elements[0].invalid_reason = "REP"
		T.assert_equal(service.inspect_archive(a).axel_completed.size(),0,variant)

func combo() -> void:
	var service = _service()
	if service == null: return
	var a := F.archive()
	var record: Dictionary = a.free_results.player
	var first: Dictionary = record.performance.elements[0].duplicate(true)
	var second := first.duplicate(true); second.abbreviation = "2T"; second.actual.fall = true; second.actual.success = false
	var first_call: Dictionary = record.technical_review.final_elements[0].duplicate(true)
	var second_call := first_call.duplicate(true); second_call.abbreviation = "2T"; second_call.facts.fall = true
	record.performance.elements = [{"element_id":"combo","kind":"jump","parts":[first,second],"actual":{"fall":true,"success":false}}]
	record.technical_review.final_elements = [{"element_id":"combo","abbreviation":"3A+2T","parts":[first_call,second_call],"info":[],"base_value":9.3}]
	var before := JSON.stringify(a)
	var facts: Dictionary = service.inspect_archive(a)
	T.assert_equal(facts.axel_completed.size(),1)
	if not facts.axel_completed.is_empty():
		T.assert_equal(facts.axel_completed[0].part_index,0)
		T.assert_equal(facts.axel_completed[0].element_id,"combo")
	T.assert_equal(JSON.stringify(a),before)
