class_name Fixtures
extends RefCounted

const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const GameClock = preload("res://src/domain/game_clock.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const JumpProfile = preload("res://src/domain/jump_profile.gd")

static func starting_career(seed: int) -> CareerState:
	var career: CareerState = CareerFactory.create(
		"林澄",
		2007,
		"entry_interest_class",
		"family_supportive",
		seed,
		CatalogRepository.load_catalog(),
		4,
	).career
	# Most suites exercise the established career loop, not the opening flow.
	career.opening_stage = "complete"
	return career

static func clear_jump_progress(career: CareerState, jump_ids: Array = []) -> void:
	var ids: Array = career.athlete.jumps.keys() if jump_ids.is_empty() else jump_ids
	for jump_id in ids:
		career.athlete.jumps[jump_id] = JumpProfile.create(str(jump_id))

static func clear_pre_career_load(career: CareerState) -> void:
	for field in ["acute_fatigue", "cumulative_fatigue", "ankle_load", "impact_load"]:
		career.athlete.body[field] = 0.0
	career.condition_state.injuries = []

static func formal_junior_career(seed: int) -> CareerState:
	var career := starting_career(seed)
	career.clock = GameClock.new(2018, 3)
	career.athlete.birth_year = 2004
	set_competition_strength(career.athlete, 62.0)
	career.active_programs = {
		"short": _fixture_program("player-short", "short").to_dict(),
		"free": _fixture_program("player-free", "free").to_dict(),
	}
	for segment in ["short","free"]:
		career.active_programs[segment].draft_status = "locked"
		career.active_programs[segment].locked_segments = [segment]
	# This fixture starts four years after the early-career loop and therefore
	# must not be interrupted by an invitation it has already passed.
	career.internal_invitation_state.status = "completed"
	# Established formal-career fixtures have already chosen their season.
	career.season_program_plan = preload("res://src/domain/season_program_plan.gd").create("2018-19")
	career.season_program_plan.status = "confirmed"
	return career

static func formal_programs() -> Dictionary:
	return formal_junior_career(4040).active_programs.duplicate(true)

static func formal_acceptance_career(scenario: String) -> CareerState:
	var career := formal_junior_career(12001 if scenario == "qualify" else 12002)
	for segment in ["short", "free"]:
		career.active_programs[segment].draft_status = "locked"
		career.active_programs[segment].locked_segments = [segment]
	career.certification_state.national_technical_grade = 7
	career.athlete.display_name = "林心宁" if scenario == "qualify" else "沈若冰"
	set_competition_strength(career.athlete, 96.0 if scenario == "qualify" else 4.0)
	career.record_book = {"all_formal": {"isu_iqs_2018_plus": {
		"short":{"pb":48.20,"pb_meta":{},"sb":{}}, "free":{"pb":82.10,"pb_meta":{},"sb":{}}, "total":{"pb":130.30,"pb_meta":{},"sb":{}}
	}}, "international": {}}
	return career

static func u_series_event() -> Dictionary:
	var result := SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles")
	for event in result.calendar.get("events", []):
		if event.get("event_id") == "cn_grand_prix_u_series_2018":
			return Dictionary(event).duplicate(true)
	return {}

static func set_competition_strength(athlete, value: float) -> void:
	for key in athlete.technique: athlete.technique[key] = value
	for key in athlete.skating: athlete.skating[key] = value
	for key in athlete.jump_foundation.to_dict(): athlete.jump_foundation.set(key, value)
	for jump in athlete.jumps.values():
		jump.unlocked_rotations = 3
		for key in jump.takeoff: jump.takeoff[key] = value
		for key in jump.air: jump.air[key] = value
		for key in jump.landing: jump.landing[key] = value
		jump.proficiency.triple = value
		jump.consistency.official = value

static func _fixture_program(program_id: String, segment: String):
	var elements: Array = []
	var jump_specs := [["axel", 2], ["lutz", 3], ["flip", 3]] if segment == "short" else [["lutz", 3], ["flip", 3], ["axel", 2], ["loop", 3], ["salchow", 3], ["lutz", 3], ["axel", 2]]
	for index in jump_specs.size():
		var jump = ProgramElement.create("%s-j%d" % [program_id, index + 1], "jump", jump_specs[index][0], jump_specs[index][1]).element
		if index == 1: jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 2}])
		elif segment == "free" and index == 4: jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 2}])
		elif segment == "free" and index == 5: jump.set_combination_parts([{"jump_id": "loop", "rotations": 2}, {"jump_id": "loop", "rotations": 2}])
		elements.append(jump)
	for index in 3:
		var spin = ProgramElement.create("%s-spin%d" % [program_id, index + 1], "spin").element
		spin.spin_code = ["CCoSp", "FCSp", "LSp"][index]
		elements.append(spin)
	elements.append(ProgramElement.create("%s-step" % program_id, "step_sequence").element)
	var program = SkatingProgram.create(program_id, segment, elements).program
	program.whole_run_familiarity = 70.0
	program.choreography_quality = 66.0
	for element_id in program.slot_familiarity: program.slot_familiarity[element_id] = 68.0
	return program

static func career_with_guardian(control: float, health_priority: float) -> CareerState:
	var career := starting_career(1)
	career.relationships["guardian"] = RelationshipState.new(85.0, 40.0, control, health_priority)
	return career

static func balanced_plan() -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation": 3,
		"jump_toe_loop": 1, "jump_salchow": 1, "jump_loop": 0,
		"jump_flip": 0, "jump_lutz": 0, "jump_axel": 1,
		"rotation": 2,
		"conditioning": 2,
		"rest": 2,
	}).plan

static func jump_heavy_plan() -> TrainingPlan:
	return TrainingPlan.create({
		"skating_foundation": 2,
		"jump_toe_loop": 2, "jump_salchow": 1, "jump_loop": 1,
		"jump_flip": 1, "jump_lutz": 1, "jump_axel": 0,
		"rotation": 1,
		"conditioning": 2,
		"rest": 1,
	}).plan

static func percentage_balanced_plan() -> TrainingPlan:
	return percentage_plan({})

static func percentage_plan(target_overrides: Dictionary = {}) -> TrainingPlan:
	var targets := {
		"toe_loop": 1, "salchow": 1, "loop": 1,
		"flip": 1, "lutz": 1, "axel": 1,
	}
	for jump_id in target_overrides:
		targets[jump_id] = int(target_overrides[jump_id])
	return TrainingPlan.create({
		"skating_foundation": 25,
		"jump_toe_loop": 10, "jump_salchow": 10, "jump_loop": 5,
		"jump_flip": 5, "jump_lutz": 5, "jump_axel": 5,
		"rotation": 10, "conditioning": 10, "rest": 15,
	}, targets).plan
