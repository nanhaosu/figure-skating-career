extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Plan = preload("res://src/domain/training_plan.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"version20 adds empty coaching memory without touching repertoire","callable":migration},
		{"name":"coaching memory rejects unbounded and fractional data","callable":bounds},
		{"name":"actual coaching decision survives plan serialization","callable":plan_roundtrip},
		{"name":"coaching memory survives JSON numbers and career copy","callable":career_roundtrip}]

func migration() -> void:
	var career = F.starting_career(73101)
	var old: Dictionary = career.to_dict()
	old.schema_version = 20
	old.erase("coach_training_state")
	var payload := {"save_version":20,"saved_at_unix":0,"career":old}
	var original := JSON.stringify(payload)
	var result: Dictionary = load("res://src/persistence/save_migrator.gd").to_current(payload)
	T.assert_equal(result.data.save_version,preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	T.assert_equal(result.data.career.get("coach_training_state",{}).get("completed_periods",-1),0)
	for field in ["athlete","active_programs","technical_repertoire","competition_archive"]:
		T.assert_equal(result.data.career[field],old[field],field+" must not be rewritten")
	T.assert_equal(JSON.stringify(payload),original)

func bounds() -> void:
	var path := "res://src/domain/coach_training_state.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"bounded memory model required")
	if not FileAccess.file_exists(path): return
	var model = load(path)
	for bad in [0.5,-1,"1"]:
		var state: Dictionary = model.defaults()
		state.completed_periods = bad
		T.assert_equal(model.validate(state).is_empty(),false)
	var state: Dictionary = model.defaults()
	state.last_practiced = {"unknown":1}
	T.assert_equal(model.validate(state).is_empty(),false)
	state = model.defaults()
	state.last_decision = {"coach_id":"x".repeat(129)}
	T.assert_equal(model.validate(state).is_empty(),false)
	state = model.defaults()
	state.last_decision = {"gap_ids":["a","b","c","d","e","f","g"]}
	T.assert_equal(model.validate(state).is_empty(),false)

func plan_roundtrip() -> void:
	var data: Dictionary = F.percentage_balanced_plan().to_dict()
	data.coach_decision = {"period_key":"2014:1","coach_id":"coach_he","gap_ids":["toe_loop"],"allocated_gap_ids":["toe_loop"],"reason_codes":["foundation_gap"]}
	var restored = Plan.from_dict(data)
	T.assert_equal(restored != null,true)
	if restored == null: return
	T.assert_equal(restored.to_dict().get("coach_decision",{}),data.coach_decision)
	data.coach_decision.coach_id = "x".repeat(129)
	T.assert_equal(Plan.from_dict(data),null,"invalid decision cannot enter saved plan")

func career_roundtrip() -> void:
	var data: Dictionary = F.starting_career(73102).to_dict()
	data.coach_training_state = {"version":1,"completed_periods":2,"last_practiced":{"toe_loop":1},"last_completed_period":"2014:2","last_decision":{}}
	var restored = load("res://src/domain/career_state.gd").from_dict(JSON.parse_string(JSON.stringify(data)))
	T.assert_equal(restored.to_dict().get("coach_training_state",{}),data.coach_training_state)
