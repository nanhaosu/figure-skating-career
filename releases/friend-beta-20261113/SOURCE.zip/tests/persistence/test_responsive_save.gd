extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Repo = preload("res://src/persistence/save_repository.gd")
class AvailableStorage extends RefCounted:
	func begin() -> Dictionary: return {"ok":true,"errors":[]}
	func flush() -> Dictionary: return {"ok":true,"errors":[]}
	func release() -> void: pass

func cases() -> Array[Dictionary]:
	return [{"name":"responsive save yields across preparation and preserves the canonical career","callable":test_save},
		{"name":"responsive save rejects invalid input without replacing the previous save","callable":test_failure},
		{"name":"interactive save reports preparation and durable completion without early success","callable":test_progress}]

func test_progress() -> void:
	var service = load("res://src/persistence/browser_save_service.gd").new("user://save-progress-%d" % Time.get_ticks_usec())
	service.durability = AvailableStorage.new()
	var reports: Array[Dictionary] = []
	service.load_progress.connect(func(report): reports.append(report))
	var result: Dictionary = await service.save_slot("manual-1",F.starting_career(100103))
	T.assert_equal(result.ok,true)
	T.assert_equal(reports.size() >= 5,true,"save must expose preparation instead of a motionless wait window")
	if reports.is_empty(): return
	var previous := -1
	for report in reports:
		T.assert_equal(int(report.percent) >= previous,true)
		previous = int(report.percent)
	T.assert_equal(reports[-1].stage,"save_complete")
	T.assert_equal(reports[-1].percent,100)

func test_save() -> void:
	var repository = Repo.new()
	T.assert_equal(repository.has_method("save_responsive"),true,"interactive saves need a responsive preparation entry")
	if not repository.has_method("save_responsive"): return
	var career = F.starting_career(100101)
	var path := "user://responsive-save-%d.json" % Time.get_ticks_usec()
	var before := JSON.stringify(career.to_dict())
	var frames := Engine.get_process_frames()
	var result: Dictionary = await repository.call("save_responsive",career,path,false)
	T.assert_equal(result.ok,true)
	T.assert_equal(Engine.get_process_frames()-frames >= 4,true,"expensive preparation must not monopolize a single input frame")
	T.assert_equal(JSON.stringify(career.to_dict()),before,"save preparation cannot publish canonical changes before storage acknowledgement")
	var loaded: Dictionary = Repo.load_save(path)
	T.assert_equal(loaded.ok,true)
	if result.ok and loaded.ok:
		T.assert_equal(loaded.career.to_dict(),result.canonical_state)

func test_failure() -> void:
	var repository = Repo.new()
	T.assert_equal(repository.has_method("save_responsive"),true,"interactive saves need a responsive preparation entry")
	if not repository.has_method("save_responsive"): return
	var career = F.starting_career(100102)
	var path := "user://responsive-save-failure-%d.json" % Time.get_ticks_usec()
	T.assert_equal(Repo.save(career,path).ok,true)
	var before := FileAccess.get_sha256(path)
	career.training_period_state.weeks_elapsed = 13
	var result: Dictionary = await repository.call("save_responsive",career,path,false)
	T.assert_equal(result.ok,false)
	T.assert_equal(FileAccess.get_sha256(path),before,"invalid preparation must leave the committed file untouched")
