extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Repo = preload("res://src/persistence/save_repository.gd")
const Service = preload("res://src/persistence/browser_save_service.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"slot loading yields between real archives and preserves canonical protocols","callable":archives},
		{"name":"responsive load reports monotonic archive validation progress","callable":progress},
		{"name":"main resume entry uses the responsive loader before publishing","callable":resume_entry},
		{"name":"load button locks input before publishing a validated candidate","callable":button},
		{"name":"failed slot load retains career and active destination","callable":failure}]

func resume_entry() -> void:
	var main = _main()
	var career = F.formal_junior_career(8192)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(career,bundle.calendar.events[0],501)
	T.assert_equal((await main.browser_saves.save_slot("autosave",career)).ok,true)
	var result: Dictionary = await main.load_active_career_responsive(main.browser_saves.slot_path("autosave"))
	T.assert_equal(result.ok,true)
	T.assert_equal(main.active_career.seed,8192)
	T.assert_equal(main._persistence_progress_label.text,"载入完成")
	T.assert_equal(int(main._persistence_progress_bar.value),100)
	T.assert_equal(main._persistence_wait.visible,false)
	await Engine.get_main_loop().process_frame
	main.free()
	await Engine.get_main_loop().process_frame

func progress() -> void:
	var career = F.formal_junior_career(8191)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	for i in 3:
		load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(career,bundle.calendar.events[i],301+i)
	var service = Service.new("user://responsive-progress-%d" % Time.get_ticks_usec())
	var saved: Dictionary = await service.save_slot("manual-1",career)
	T.assert_equal(saved.ok,true,"fixture save failed: %s" % "；".join(saved.errors))
	var reports: Array[Dictionary] = []
	var report_frames: Array[int] = []
	var release := {"frame":-1}
	service.load_progress.connect(func(report: Dictionary):
		reports.append(report.duplicate(true))
		report_frames.append(Engine.get_process_frames()))
	service.busy_changed.connect(func(value: bool):
		if not value: release.frame = Engine.get_process_frames())
	var result: Dictionary = await service.load_slot("manual-1")
	T.assert_equal(result.ok,true)
	T.assert_equal(reports.is_empty(),false,"a long read must expose progress instead of appearing frozen")
	var previous := -1
	var archive_steps := 0
	for report in reports:
		var percent := int(report.get("percent",-1))
		T.assert_equal(percent >= previous,true,"reported progress cannot move backwards")
		T.assert_equal(percent >= 0 and percent <= 100,true)
		previous = percent
		if report.get("stage","") == "archives":
			archive_steps += 1
			T.assert_equal(int(report.get("total",0)),3)
	T.assert_equal(archive_steps,3,"each historical competition must produce one visible completed-validation step")
	T.assert_equal(reports[-1].get("stage",""),"complete")
	T.assert_equal(int(reports[-1].get("percent",0)),100)
	var constructing_index := reports.find_custom(func(report): return report.get("stage","") == "constructing")
	T.assert_equal(constructing_index >= 0,true)
	T.assert_equal(report_frames[-1] > report_frames[constructing_index],true,"constructing must be painted before complete replaces it")
	T.assert_equal(int(release.frame) > report_frames[-1],true,"100 percent must be paintable before the busy window closes")

func archives() -> void:
	var career = F.formal_junior_career(8190)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	for i in 3:
		load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(career,bundle.calendar.events[i],201+i)
	var service = Service.new("user://responsive-archives-%d" % Time.get_ticks_usec())
	var saved: Dictionary = await service.save_slot("manual-1",career)
	T.assert_equal(saved.ok,true,"fixture save failed: %s" % "；".join(saved.errors))
	var expected := JSON.stringify(JSON.parse_string(JSON.stringify(career.to_dict())))
	var frames := Engine.get_process_frames()
	var result: Dictionary = await service.load_slot("manual-1")
	T.assert_equal(result.ok,true)
	T.assert_equal(Engine.get_process_frames()-frames >= 4,true,"input loop must run before and between each real archived competition")
	if not result.ok: return
	T.assert_equal(JSON.stringify(JSON.parse_string(JSON.stringify(result.career.to_dict()))) == expected,true,"responsive load must preserve the complete canonical career")
	for archive in result.career.competition_archive:
		T.assert_equal(Codec.validate(archive),"")
		var expanded := Codec.expand(archive)
		var winner: Dictionary = archive.final_standings[0]
		T.assert_equal(expanded.short_results[winner.athlete_id].protocol.total,winner.short_score)
		T.assert_equal(expanded.free_results[winner.athlete_id].protocol.total,winner.free_score)
	# A late archive integrity failure must reject the private candidate too;
	# skipping payload validation in the responsive path is not permissible.
	var corrupt: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(service.slot_path("manual-1")))
	corrupt.career.competition_archive[-1] = Codec.compact(corrupt.career.competition_archive[-1])
	corrupt.career.competition_archive[-1].packed_archive.sha256 = "0".repeat(64)
	var file := FileAccess.open(service.slot_path("manual-2"),FileAccess.WRITE)
	file.store_string(JSON.stringify(corrupt,"",true,true)); file.close()
	T.assert_equal((await service.load_slot("manual-2")).ok,false,"invalid last archive must not publish a partially normalized career")
	T.assert_equal(service.active_slot,"manual-1")

func _main():
	var main = load("res://src/app/main.tscn").instantiate()
	main.browser_saves = Service.new("user://responsive-ui-%d" % Time.get_ticks_usec())
	main.save_path = main.browser_saves.slot_path("manual-1")
	main.autosave_path = main.browser_saves.slot_path("autosave")
	Engine.get_main_loop().root.add_child(main)
	main.offer_new_career(F.starting_career(818))
	return main

func _click_load(panel):
	for child in panel.find_children("*","Button",true,false):
		if child.text == "读取": child.pressed.emit(); return
	T.assert_equal(false,true,"actual load button must exist")

func button() -> void:
	var main = _main()
	var service = main.browser_saves
	var loaded_career = F.formal_junior_career(819)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(loaded_career,bundle.calendar.events[0],401)
	var saved: Dictionary = await service.save_slot("manual-2",loaded_career)
	T.assert_equal(saved.ok,true,"fixture save failed: %s" % "；".join(saved.errors))
	service.active_slot = "manual-1"
	var original = main.active_career
	var panel = main.get_node("%SaveManagerPanel")
	panel.present(service,original); panel.slot_list.select(2)
	_click_load(panel)
	T.assert_equal(service.busy,true,"busy lock must be acquired inside input callback before decoding starts")
	T.assert_equal(main.active_career == original,true,"candidate cannot be published before asynchronous load completes")
	T.assert_equal(service.active_slot,"manual-1")
	T.assert_equal((await service.load_slot("manual-1")).ok,false,"another read cannot enter while the candidate is loading")
	if main._persistence_wait != null: T.assert_equal(main._persistence_wait.visible,true)
	else: T.assert_equal(false,true,"load must present the existing input-blocking wait window")
	T.assert_equal(main._persistence_progress_label != null,true,"wait window must explain the current load stage")
	T.assert_equal(main._persistence_progress_bar != null,true,"wait window must show measurable progress")
	var saw_archive_stage := false
	while service.busy:
		if main._persistence_progress_label.text.contains("历史比赛"):
			saw_archive_stage = true
		await Engine.get_main_loop().process_frame
	T.assert_equal(saw_archive_stage,true,"archive validation must be visible while the candidate stays private")
	T.assert_equal(int(main._persistence_progress_bar.value),100)
	T.assert_equal(main.active_career.seed,819)
	T.assert_equal(service.active_slot,"manual-2")
	T.assert_equal(panel.visible,false)
	T.assert_equal(main._persistence_wait.visible,false)
	await Engine.get_main_loop().process_frame
	main.free()
	await Engine.get_main_loop().process_frame

func failure() -> void:
	var main = _main()
	var service = main.browser_saves
	var original := JSON.stringify(main.active_career.to_dict())
	var file := FileAccess.open(service.slot_path("manual-2"),FileAccess.WRITE)
	file.store_string("{broken"); file.close()
	var panel = main.get_node("%SaveManagerPanel")
	panel.present(service,main.active_career); panel.slot_list.select(2)
	_click_load(panel)
	while service.busy: await Engine.get_main_loop().process_frame
	T.assert_equal(JSON.stringify(main.active_career.to_dict()),original)
	T.assert_equal(service.active_slot,"manual-1")
	T.assert_equal(panel.visible,true,"failed read must retain visible retry context")
	T.assert_equal(panel.message.text.begins_with("失败"),true)
	await Engine.get_main_loop().process_frame
	main.free()
	await Engine.get_main_loop().process_frame
