extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Migrator = preload("res://src/persistence/save_migrator.gd")
const Repo = preload("res://src/persistence/save_repository.gd")
const Career = preload("res://src/domain/career_state.gd")

func cases() -> Array[Dictionary]:
	# Persisted targets are later traversed by the coach, not inert metadata.
	return [
		{"name":"malformed season targets and residual limits are rejected before coach traversal","callable":invalid_targets},
		{"name":"legacy migration preserves progress while adding health and repertoire", "callable":legacy},
		{"name":"legacy combinations require evidence without erasing current programs", "callable":combinations},
		{"name":"new state survives canonical transaction and save load", "callable":roundtrip},
		{"name":"fractional repertoire counts are rejected without altering player state", "callable":invalid_counts},
		{"name":"migration is idempotent and does not mutate legacy input", "callable":idempotent},
		{"name":"legacy save load leaves original bytes untouched and backs them up on save", "callable":legacy_file},
		{"name":"integer JSON counts accepted but nonfinite and impossible evidence rejected", "callable":evidence_boundaries},
	]

func invalid_targets() -> void:
	for targets in [{"free":"3A"},{"free":[{"element_id":"x","action":{"kind":"jump","parts":[{"jump_id":"axel","rotations":2.5}]}}]},{"free":[{"element_id":"x","action":{"kind":"spin","parts":[{"jump_id":"axel","rotations":3}]}}]}]:
		var career = F.starting_career(1009)
		var data: Dictionary = career.to_dict()
		data.season_program_plan.targets = targets
		T.assert_equal(Repo._validate_version_sixteen_state(data).is_empty(),false)

func payload() -> Dictionary:
	var career = F.starting_career(1008)
	career.athlete.jumps.toe_loop.unlocked_rotations = 3
	career.athlete.jumps.toe_loop.attempt_evidence.triple.successes = 8
	var data: Dictionary = career.to_dict()
	data.schema_version = 15
	data.erase("season_program_plan")
	data.erase("technical_repertoire")
	for key in ["health_model_version","function_limits","rehabilitation","pending_decision"]:
		data.condition_state.erase(key)
	return {"save_version":15,"saved_at_unix":0,"career":data}

func legacy() -> void:
	var old := payload()
	var migrated: Dictionary = Migrator.to_current(old)
	T.assert_equal(migrated.ok, true)
	if not migrated.ok: return
	var data: Dictionary = migrated.data.career
	T.assert_equal(data.get("technical_repertoire", {}).has("entries"), true, "migration must add repertoire")
	T.assert_equal(data.get("season_program_plan", {}).has("targets"), true, "migration must add planning targets")
	T.assert_equal(data.condition_state.get("health_model_version",0), 1)
	for key in ["athlete","clock","random_streams","record_book","active_programs"]:
		T.assert_equal(data[key], old.career[key], "legacy progress changed: "+key)

func combinations() -> void:
	var old := payload()
	old.career.active_programs.free = {"elements":[{"kind":"jump","jump_id":"lutz","rotations":3,"combination_parts":[{"jump_id":"toe_loop","rotations":3}]}]}
	var result: Dictionary = Migrator.to_current(old)
	T.assert_equal(result.ok,true)
	if not result.ok: return
	var entries: Dictionary = result.data.career.get("technical_repertoire",{}).get("entries",{})
	T.assert_equal(entries.has("3Lz+3T"),true,"legacy combination must remain visible")
	if entries.has("3Lz+3T"):
		T.assert_equal(entries["3Lz+3T"].legacy_unverified,true)
		T.assert_equal(entries["3Lz+3T"].evidence,[])
	T.assert_equal(result.data.career.active_programs,old.career.active_programs)

func roundtrip() -> void:
	var data: Dictionary = F.starting_career(1009).to_dict()
	data.season_program_plan = {"season_id":"2018-19","status":"draft","revision":2,"programs":{},"targets":{"free":[]},"receipts":[]}
	data.technical_repertoire = {"entries":{}}
	var career = Career.from_dict(data)
	T.assert_equal(career.transaction_copy(true).to_dict().get("season_program_plan",{}),data.season_program_plan)
	var result: Dictionary = Repo.save(career,"user://health-repertoire-roundtrip.json")
	T.assert_equal(result.ok,true)
	if not result.ok: return
	var restored: Dictionary = Repo.load_save("user://health-repertoire-roundtrip.json")
	T.assert_equal(restored.ok,true)
	if restored.ok: T.assert_equal(restored.career.to_dict().get("season_program_plan",{}),data.season_program_plan)

func invalid_counts() -> void:
	var career = F.starting_career(1010)
	var data: Dictionary = career.to_dict()
	data.technical_repertoire = {"entries":{"3T":{"action":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":3}]},"state":"training","legacy_unverified":false,"evidence":[{"batch_id":"a","clock":{"year":2014,"quarter":1},"action_id":"3T","context":"practice","attempts":1.5,"successes":0,"clean_successes":0,"failure_counts":{},"assessment_eligible":true}],"learned_history":{}}}}
	var validation: String = Repo._validate_payload({"save_version":Repo.SAVE_VERSION,"saved_at_unix":0,"career":data})
	T.assert_equal(validation.is_empty(),false,"fractional attempt counts must be rejected")
	T.assert_equal(career.to_dict().get("technical_repertoire",{}).get("entries",{}),{})

func idempotent() -> void:
	var old := payload()
	var before := JSON.stringify(old)
	var first: Dictionary = Migrator.to_current(old)
	T.assert_equal(JSON.stringify(old),before)
	T.assert_equal(first.ok,true)
	if not first.ok: return
	var second: Dictionary = Migrator.to_current(first.data)
	T.assert_equal(second.data,first.data)

func legacy_file() -> void:
	var old := payload()
	var path := "user://health-repertoire-legacy.json"
	var bytes := JSON.stringify(old)
	var file := FileAccess.open(path,FileAccess.WRITE)
	file.store_string(bytes)
	file.close()
	var loaded: Dictionary = Repo.load_save(path)
	T.assert_equal(loaded.ok,true)
	T.assert_equal(FileAccess.get_file_as_string(path),bytes,"loading must not rewrite original save")
	if not loaded.ok: return
	T.assert_equal(loaded.career.technical_repertoire.entries["3T"].learned_history.ever_learned,true)
	T.assert_equal(Repo.save(loaded.career,path).ok,true)
	T.assert_equal(FileAccess.get_file_as_string(path+".bak"),bytes,"first save must retain original legacy bytes")
	T.assert_equal(Repo.load_save(path).ok,true)

func evidence_boundaries() -> void:
	var data: Dictionary = F.starting_career(1011).to_dict()
	var evidence := {"batch_id":"integer","clock":{"year":2014,"quarter":1},"action_id":"3T","context":"practice","attempts":4.0,"successes":2.0,"clean_successes":1.0,"failure_counts":{"falls":1.0},"assessment_eligible":true}
	data.technical_repertoire = {"entries":{"3T":{"action":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":3}]},"state":"training","legacy_unverified":false,"evidence":[evidence],"learned_history":{}}}}
	var wrapped := {"save_version":Repo.SAVE_VERSION,"saved_at_unix":0,"career":data}
	T.assert_equal(Repo._validate_payload(wrapped),"")
	for bad in [-1.0,1.5,NAN,INF]:
		evidence.attempts = bad
		T.assert_equal(Repo._validate_payload(wrapped).is_empty(),false,"invalid attempts must fail before normalization")
	evidence.attempts = 1
	T.assert_equal(Repo._validate_payload(wrapped).is_empty(),false,"successes cannot exceed attempts")
