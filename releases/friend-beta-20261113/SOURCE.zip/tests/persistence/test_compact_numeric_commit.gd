extends RefCounted
const T = preload("res://tests/test_support.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"legacy compact archive remains readable after canonical load","callable":legacy},
		{"name":"saving compact archive canonicalizes index and payload together","callable":save_compact},
		{"name":"canonical compact archive repeated saves preserve complete career and protocol","callable":repeated}]

func _legacy():
	var fixture = load("res://tests/persistence/test_compact_competition_archive.gd").new()
	var career = fixture._career()
	var source: Dictionary = fixture._raw_archive()
	# Exact precision-bearing field from the real public 2019 Beijing archive.
	# Scores/protocols/entrant IDs still come from an actual simulated field.
	source.consequence_snapshot = {"ranking_state":{"selection_evidence":{"health":82.1855583116407}}}
	# Encode the historical v1 format explicitly; do not let a new encoder
	# silently upgrade the legacy fixture before exercising the loader.
	var raw := JSON.stringify(source)
	var bytes := raw.to_utf8_buffer()
	var payload := Marshalls.raw_to_base64(bytes.compress(FileAccess.COMPRESSION_GZIP))
	var index: Dictionary = Codec._index(source)
	index.packed_archive = {"version":1,"encoding":"gzip_base64","raw_bytes":bytes.size(),"sha256":raw.sha256_text(),"payload":payload,"payload_sha256":payload.sha256_text()}
	T.assert_equal(Codec.validate(index),"")
	career.competition_archive[0] = index
	return career

func _read_protocol(career) -> void:
	var archive: Dictionary = career.competition_archive[0]
	T.assert_equal(Codec.validate(archive),"","canonical state must keep strict archive index/source integrity")
	# Historical protocols are immutable evidence. Their original precision is
	# preserved byte-for-byte; repeated saves below prove it cannot drift into
	# mutable simulation state.
	T.assert_equal(Codec.expand(archive).is_empty(),false,"compressed source remains available without eager numeric rewriting")
	var row: Dictionary = archive.final_standings[0]
	var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present_session(archive.merged({"archive":archive}))
	panel.present_final_archive(archive)
	panel.standing_button_for(row.athlete_id).pressed.emit()
	var view = panel.get_node("%ProtocolView")
	T.assert_equal(view._protocols.has("short"),true,"old saved entrant must still open her archived SP protocol")
	if view._protocols.has("short"):
		T.assert_equal(view._protocols.short.total,row.short_score)
		T.assert_equal(view.get_node("%ElementRows").get_child_count()>0,true)
	panel.free()

func legacy() -> void:
	var career = _legacy()
	var file := FileAccess.open("user://compact-numeric-legacy.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"save_version":13,"saved_at_unix":0,"career":career.to_dict()})); file.close()
	var loaded := Save.load_save("user://compact-numeric-legacy.json")
	T.assert_equal(loaded.ok,true)
	if loaded.ok: _read_protocol(loaded.career)

func save_compact() -> void:
	var career = _legacy()
	var result := Save.save(career,"user://compact-numeric-new.json")
	T.assert_equal(result.ok,true)
	if result.ok: _read_protocol(career)

func repeated() -> void:
	var career = _legacy()
	T.assert_equal(Save.save(career,"user://compact-numeric-repeat.json").ok,true)
	var expected_state: Dictionary = JSON.parse_string(JSON.stringify(career.to_dict()))
	var expected := JSON.stringify(expected_state)
	for round in 3:
		var loaded := Save.load_save("user://compact-numeric-repeat.json")
		T.assert_equal(loaded.ok,true,"canonical compact save must remain loadable")
		if not loaded.ok: return
		career = loaded.career
		var actual: Dictionary = JSON.parse_string(JSON.stringify(career.to_dict()))
		var equal := JSON.stringify(actual) == expected
		if not equal: print("COMPACT_NUMERIC_DIFF ",load("res://tests/simulation/test_season_progression_service.gd").new()._first_difference(expected_state,actual).left(300))
		T.assert_equal(equal,true,"complete canonical career must not drift on compact archive reload")
		if not equal: return
		T.assert_equal(Save.save(career,"user://compact-numeric-repeat.json").ok,true)
	_read_protocol(career)
