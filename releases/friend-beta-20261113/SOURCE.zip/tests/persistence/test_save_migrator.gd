extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const SaveMigrator = preload("res://src/persistence/save_migrator.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "schema one edge control migrates only to skating", "callable": test_v1_edge_migrates_only_to_skating},
		{"name": "schema two migration is idempotent", "callable": test_v2_is_idempotent},
		{"name": "schema two quarter plans gain percentage layers", "callable": test_v2_quarter_plan_gains_percentage_layers},
		{"name": "schema three gains shared foundation without changing jumps", "callable": test_v3_gains_foundation_without_changing_jumps},
		{"name": "schema four gains empty roadmap without changing jumps", "callable": test_v4_gains_empty_roadmap_without_changing_jumps},
		{"name": "schema five gains empty program library without changing career", "callable": test_v5_gains_program_library},
		{"name": "schema six gains empty competition session", "callable": test_v6_gains_competition_session},
		{"name": "schema seven preserves routes and gains program route defaults", "callable": test_v7_preserves_competition_routes},
		{"name": "schema eight gains story context and preserves next training cursor", "callable": test_v8_gains_career_foundation},
		{"name": "schema nine gains empty season state without consuming randomness", "callable": test_v9_gains_empty_season_state},
		{"name": "schema ten gains formal competition state", "callable": test_v10_gains_formal_state},
		{"name": "schema eleven gains empty certification and invitation state", "callable": test_v11_gains_career_entry_state},
		{"name": "schema twelve gains exact version thirteen boundaries without changing existing data", "callable": test_v12_gains_state_boundaries},
		{"name": "schema thirteen gains empty pre-career history without regeneration", "callable": test_v13_gains_empty_pre_career_history_without_regeneration},
		{"name": "schema fourteen gains the first-loop fields without inventing history", "callable": test_v14_gains_first_loop_defaults},
		{"name": "schema fourteen preserves partial opening invitation and explicit draft state", "callable": test_v14_preserves_partial_first_loop},
		{"name": "schema fourteen normalizes only implicit legacy locks and preserves archives", "callable": test_v14_normalizes_legacy_program_lock},
		{"name": "schema fourteen keeps an implicit illegal legacy programme as a draft", "callable": test_v14_keeps_implicit_illegal_program_draft},
		{"name": "future schema is rejected by migrator", "callable": test_future_schema_rejected},
	]

func test_v6_gains_competition_session() -> void:
	var payload := _v1_payload()
	payload.save_version = 6
	payload.career.schema_version = 6
	payload.career.erase("competition_state")
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.competition_state, {})

func test_v1_edge_migrates_only_to_skating() -> void:
	var payload := _v1_payload()
	payload.career.athlete.erase("skating")
	payload.career.athlete.erase("jumps")
	payload.career.athlete.technique.edge_control = 28.0
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.athlete.skating.deep_edge, 28.0)
	TestSupport.assert_equal(result.data.career.athlete.jumps.lutz.takeoff.edge_quality, 50.0)
	TestSupport.assert_equal(result.data.career.athlete.jumps.flip.takeoff.edge_quality, 50.0)
	TestSupport.assert_equal(result.data.career.athlete.technique.has("edge_control"), false)

func test_v2_is_idempotent() -> void:
	var payload := _v1_payload()
	var first = SaveMigrator.to_current(payload)
	var second = SaveMigrator.to_current(first.data)
	TestSupport.assert_equal(second.ok, true)
	TestSupport.assert_equal(second.data, first.data)

func test_v2_quarter_plan_gains_percentage_layers() -> void:
	var payload := _v1_payload()
	payload.save_version = 2
	payload.career.schema_version = 2
	var units := Fixtures.balanced_plan().allocations
	payload.career.history = [{
		"category": "quarter_plan", "desired": units, "approved": units,
		"executed": units, "decisions": [], "secret_practice": {}, "cause_codes": [],
	}]
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	var record: Dictionary = result.data.career.history[0]
	TestSupport.assert_equal(_sum(record.desired_shares), 100)
	TestSupport.assert_equal(record.desired_jump_rotations.toe_loop, 1)
	TestSupport.assert_equal(record.desired, units)

func test_future_schema_rejected() -> void:
	var payload := _v1_payload()
	payload.save_version = SaveMigrator.CURRENT_VERSION+1
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(result.errors, ["该存档来自尚不支持的版本：%d" % (SaveMigrator.CURRENT_VERSION+1)])

func test_v3_gains_foundation_without_changing_jumps() -> void:
	var payload := _v1_payload()
	payload.save_version = 3
	payload.career.schema_version = 3
	payload.career.athlete.erase("jump_foundation")
	var original_jumps: Dictionary = payload.career.athlete.jumps.duplicate(true)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.athlete.jumps, original_jumps)
	for value in result.data.career.athlete.jump_foundation.values():
		TestSupport.assert_equal(float(value) >= 0.0 and float(value) <= 100.0, true)

func test_v4_gains_empty_roadmap_without_changing_jumps() -> void:
	var payload := _v1_payload()
	payload.save_version = 4
	payload.career.schema_version = 4
	payload.career.erase("development_roadmap")
	payload.career.erase("roadmap_revision_history")
	var original_jumps := JSON.stringify(payload.career.athlete.jumps)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.development_roadmap, {})
	TestSupport.assert_equal(result.data.career.roadmap_revision_history, [])
	TestSupport.assert_equal(JSON.stringify(result.data.career.athlete.jumps), original_jumps)

func test_v5_gains_program_library() -> void:
	var payload := _v1_payload()
	payload.save_version = 5
	payload.career.schema_version = 5
	payload.career.erase("active_programs")
	payload.career.erase("program_archive")
	var original_athlete := JSON.stringify(payload.career.athlete)
	var original_history := JSON.stringify(payload.career.history)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.active_programs, {"short": {}, "free": {}})
	TestSupport.assert_equal(result.data.career.program_archive, [])
	TestSupport.assert_equal(JSON.stringify(result.data.career.athlete), original_athlete)
	TestSupport.assert_equal(JSON.stringify(result.data.career.history), original_history)

func test_v7_preserves_competition_routes() -> void:
	var payload := _v1_payload()
	payload.save_version = 7
	payload.career.schema_version = 7
	payload.career.active_programs.short = {"program_id": "short", "segment": "short", "elements": []}
	payload.career.competition_state = {
		"status": "awaiting_adjustment",
		"short": {"route_execution": {"points": [{"x": 0.2, "y": 0.4, "progress": 0.0}], "action_anchors": []}},
	}
	var original_competition: Dictionary = payload.career.competition_state.duplicate(true)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.story_context.rule_mode, "story_time")
	TestSupport.assert_equal(result.data.career.competition_state, original_competition)
	TestSupport.assert_equal(result.data.career.active_programs.short.route_complexity, "standard")
	TestSupport.assert_equal(result.data.career.active_programs.short.choreography_quality, 50.0)

func test_v8_gains_career_foundation() -> void:
	var payload := _v1_payload()
	payload.save_version = 8
	payload.career.schema_version = 8
	payload.career.seed = 77
	payload.career.rng_step = 3
	payload.career.erase("story_context")
	payload.career.erase("random_streams")
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.story_context, {
		"discipline": "women_singles",
		"home_federation": "CHN",
		"start_year": 2014,
		"rule_mode": "story_time",
	})
	TestSupport.assert_equal(result.data.career.random_streams, {
		"base_seed": 77,
		"steps": {"training": 3},
	})

func test_v9_gains_empty_season_state() -> void:
	var payload := _v1_payload()
	payload.save_version = 9
	payload.career.schema_version = 9
	payload.career.seed = 91
	payload.career.rng_step = 8
	payload.career.random_streams = {"base_seed": 91, "steps": {"training": 8, "competition": 4}}
	payload.career.erase("season_state")
	var original_random_streams: Dictionary = payload.career.random_streams.duplicate(true)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.season_state, {
		"season_id": "", "entry_plan": {}, "qualification_state": {}, "event_statuses": {},
	})
	TestSupport.assert_equal(result.data.career.random_streams, original_random_streams)
	TestSupport.assert_equal(result.data.career.rng_step, 8)

func test_v10_gains_formal_state() -> void:
	var payload := _v1_payload()
	payload.save_version = 10
	payload.career.schema_version = 10
	for key in ["world_athletes", "competition_archive", "record_book", "ranking_state"]:
		payload.career.erase(key)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.world_athletes, {})
	TestSupport.assert_equal(result.data.career.competition_archive, [])
	TestSupport.assert_equal(result.data.career.record_book, {"international": {}, "all_formal": {}})
	TestSupport.assert_equal(result.data.career.ranking_state, {
		"domestic_points": 0,
		"isu_world": 0,
		"season_world": 0,
		"selection_evidence": {},
	})

func test_v11_gains_career_entry_state() -> void:
	var payload := _v1_payload()
	payload.save_version = 11
	payload.career.schema_version = 11
	payload.career.erase("internal_invitation_state")
	payload.career.erase("certification_state")
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.internal_invitation_state.status, "not_ready")
	TestSupport.assert_equal(result.data.career.certification_state.national_technical_grade, 0)

func test_v12_gains_state_boundaries() -> void:
	var payload := _v1_payload()
	payload.save_version = 12
	payload.career.schema_version = 12
	for key in ["condition_state", "social_state", "selection_state", "event_ledger", "world_state"]:
		payload.career.erase(key)
	var legacy_career: Dictionary = payload.career.duplicate(true)
	var original_random_streams: Dictionary = payload.career.random_streams.duplicate(true)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.condition_state, {"growth_phase":"stable","growth_signals":[],"injuries":[],"medical_opinions":[],"psychology":{},"health_model_version":1,"function_limits":{},"rehabilitation":{},"pending_decision":{}})
	TestSupport.assert_equal(result.data.career.social_state, {"friendships":{},"fan_climate":"quiet","media_events":[],"commercial_commitments":[]})
	TestSupport.assert_equal(result.data.career.selection_state, {"applications":{},"assignments":{},"appeals":[]})
	TestSupport.assert_equal(result.data.career.event_ledger, [])
	TestSupport.assert_equal(result.data.career.world_state, {"season_id":"","generated_federations":[],"athlete_ids":[],"last_advanced_clock":{}})
	TestSupport.assert_equal(result.data.career.random_streams, original_random_streams)
	for key in legacy_career:
		if key != "schema_version":
			TestSupport.assert_equal(result.data.career[key], legacy_career[key])

func test_v13_gains_empty_pre_career_history_without_regeneration() -> void:
	var payload := _v1_payload()
	payload.save_version = 13
	payload.career.schema_version = 13
	payload.career.erase("pre_career_history")
	var before: Dictionary = payload.career.duplicate(true)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.get("pre_career_history"), {})
	for key in before:
		if key != "schema_version":
			TestSupport.assert_equal(result.data.career[key], before[key])

func test_v14_gains_first_loop_defaults() -> void:
	var payload := _v1_payload()
	payload.save_version = 14
	payload.career.schema_version = 14
	for key in ["opening_stage","career_goal","training_period_state","coach_assignment","training_preferences","last_training_policy","last_generated_plan"]:
		payload.career.erase(key)
	var history_before := JSON.stringify(payload.career.history)
	var archive_before := JSON.stringify(payload.career.competition_archive)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok,true)
	TestSupport.assert_equal(result.data.save_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.schema_version, SaveMigrator.CURRENT_VERSION)
	TestSupport.assert_equal(result.data.career.opening_stage,"complete","an established V14 career must not be forced through invented childhood screens")
	TestSupport.assert_equal(result.data.career.career_goal,{})
	TestSupport.assert_equal(result.data.career.training_period_state,{})
	TestSupport.assert_equal(result.data.career.coach_assignment.coach_id,"")
	TestSupport.assert_equal(result.data.career.training_preferences,{"breakthrough_policy":"summary","minor_pain_policy":"ask","coach_strategy_policy":"summary"})
	TestSupport.assert_equal(JSON.stringify(result.data.career.history),history_before)
	TestSupport.assert_equal(JSON.stringify(result.data.career.competition_archive),archive_before)

func test_v14_preserves_partial_first_loop() -> void:
	var payload := _v1_payload()
	payload.save_version = 14
	payload.career.schema_version = 14
	payload.career.opening_stage = "handoff"
	payload.career.career_goal = {}
	payload.career.training_period_state = {"weeks_elapsed":5,"started_clock":{"year":2014,"quarter":1},"facts":[]}
	payload.career.internal_invitation_state = {"status":"pending","event_id":"teaching-old-first","scheduled_week":9,"offered_week":9,"offered_clock":{"year":2014,"quarter":1},"peer_ids":["peer-1"]}
	payload.career.world_state.early_peer_ids = ["peer-1"]
	payload.career.world_athletes = {"peer-1":{"athlete_id":"peer-1","name":"旧队友"}}
	payload.career.active_programs.short = {"program_id":"illegal-short","segment":"short","elements":[],"draft_status":"draft","locked_segments":[]}
	var before_invitation: Dictionary = payload.career.internal_invitation_state.duplicate(true)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok,true)
	TestSupport.assert_equal(result.data.career.opening_stage,"handoff")
	TestSupport.assert_equal(result.data.career.training_period_state.weeks_elapsed,5)
	TestSupport.assert_equal(result.data.career.internal_invitation_state,before_invitation,"migration must not reschedule or accept a pending invitation")
	TestSupport.assert_equal(result.data.career.world_state.early_peer_ids,["peer-1"])
	TestSupport.assert_equal(result.data.career.active_programs.short.draft_status,"draft","an explicit illegal draft must stay a draft")

func test_v14_normalizes_legacy_program_lock() -> void:
	var payload := _v1_payload()
	payload.save_version = 14
	payload.career.schema_version = 14
	var formal := Fixtures.formal_junior_career(4040)
	payload.career.clock = formal.clock.to_dict()
	payload.career.athlete = formal.athlete.to_dict()
	payload.career.active_programs = formal.active_programs.duplicate(true)
	for segment in ["short","free"]:
		payload.career.active_programs[segment].erase("draft_status")
		payload.career.active_programs[segment].erase("locked_segments")
	payload.career.competition_archive = [{"event_id":"old-final","status":"complete","player_result":{"rank":8},"playback_speed":1.5}]
	var archive_before := JSON.stringify(payload.career.competition_archive)
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok,true)
	for segment in ["short","free"]:
		TestSupport.assert_equal(result.data.career.active_programs[segment].draft_status,"locked")
		TestSupport.assert_equal(result.data.career.active_programs[segment].locked_segments,[segment])
	TestSupport.assert_equal(JSON.stringify(result.data.career.competition_archive),archive_before,"committed results and playback data are immutable migration input")

func test_v14_keeps_implicit_illegal_program_draft() -> void:
	var payload := _v1_payload()
	payload.save_version = 14
	payload.career.schema_version = 14
	payload.career.active_programs.short = {
		"program_id":"unfinished-short", "segment":"short", "elements":[],
	}
	var result = SaveMigrator.to_current(payload)
	TestSupport.assert_equal(result.ok,true)
	TestSupport.assert_equal(result.data.career.active_programs.short.draft_status,"draft")
	TestSupport.assert_equal(result.data.career.active_programs.short.locked_segments,[])

func _sum(values: Dictionary) -> int:
	var total := 0
	for value in values.values(): total += int(value)
	return total

func _v1_payload() -> Dictionary:
	var legacy := Fixtures.starting_career(77).to_dict()
	# This field did not exist in v1–v18; do not pretend a new native-history
	# marker was present in the historical input preservation assertions.
	legacy.erase("experience_state")
	return {
		"save_version": 1,
		"saved_at_unix": 1.0,
		"career": legacy,
	}
