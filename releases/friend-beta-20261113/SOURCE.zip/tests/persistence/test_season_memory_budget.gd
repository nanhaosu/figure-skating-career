extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"a complete real event saves and reloads within the native allocation budget","callable":test_budget}]

func test_budget() -> void:
	var output: Array = []
	var code := OS.execute(OS.get_executable_path(),["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/fixtures/season_memory_probe.gd"],output,true)
	for chunk in output: print(str(chunk))
	T.assert_equal(code,0,"single-event save/reload must preserve archives with tracked peaks <= 500 MiB saving / 700 MiB reloading beside the original career")
