extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const PATH := "res://src/persistence/competition_archive_codec.gd"

func cases() -> Array[Dictionary]:
	return [{"name":"committed compact archive retains every protocol and rebuilds display only", "callable":test_codec},
		{"name":"compact archive save reload and watched replay are immutable", "callable":test_replay},
		{"name":"completed competition is compact at its first durable boundary", "callable":test_immediate_commit_compaction},
		{"name":"canonical numeric pass does not unpack an immutable archive", "callable":test_packed_archive_canonical_identity},
		{"name":"corrupt compressed archive is rejected before save recovery", "callable":test_corrupt}]

func _codec():
	T.assert_equal(ResourceLoader.exists(PATH),true,"large committed archives need a lossless compact representation")
	return load(PATH) if ResourceLoader.exists(PATH) else null

func _career():
	var career = F.formal_junior_career(8190)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(career,bundle.calendar.events[0],201)
	return career

func _raw_archive() -> Dictionary:
	var career = F.formal_junior_career(8190)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	return load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(career,bundle.calendar.events[0],201).archive

func test_codec() -> void:
	var codec = _codec()
	if codec == null: return
	var archive: Dictionary = _raw_archive()
	var before := JSON.stringify(archive)
	var compact: Dictionary = codec.compact(archive)
	T.assert_equal(JSON.stringify(compact).length() < before.length()*0.2,true,"compact archive must cut at least 80% without dropping source facts")
	T.assert_equal(JSON.stringify(archive),before)
	T.assert_equal(codec.compact(compact),compact)
	T.assert_equal(codec.validate(compact),"")
	if not codec.validate(compact).is_empty(): return
	var expanded: Dictionary = codec.expand(compact)
	T.assert_equal(expanded.final_standings,archive.final_standings)
	for segment in ["short","free"]:
		for id in archive[segment+"_results"]:
			var saved: Dictionary = expanded[segment+"_results"][id]
			var original: Dictionary = archive[segment+"_results"][id]
			for key in ["protocol","technical_review","performance","snapshot","score"]:
				T.assert_equal(JSON.stringify(saved[key]),JSON.stringify(original[key]),"committed "+key+" must remain byte-identical")
			T.assert_equal(saved.has("route_execution"),false,"reproducible display geometry must not occupy every historical protocol")
			T.assert_equal(saved.get("route_source",{}).get("version",0),1,"archived replay must retain an explicit deterministic source contract")
			var replay: Dictionary = codec.replay_record(saved)
			T.assert_equal(JSON.stringify(replay.protocol),JSON.stringify(original.protocol))
			T.assert_equal(replay.route_execution.duration_seconds,original.route_execution.duration_seconds)
			T.assert_equal(replay.route_execution.action_anchors.size(),original.route_execution.action_anchors.size())
			T.assert_equal(replay.route_execution.points.size(),original.route_execution.points.size())
			for i in replay.route_execution.points.size():
				for coordinate in ["x","y","progress"]:
					T.assert_equal(absf(float(replay.route_execution.points[i][coordinate])-float(original.route_execution.points[i][coordinate])) < 0.00001,true,"saved source must reproduce display geometry")

func test_replay() -> void:
	var codec = _codec()
	if codec == null: return
	var career = _career()
	career.competition_archive[0] = codec.compact(career.competition_archive[0])
	career = career.transaction_copy(true)
	var saved := Save.save(career,"user://task10-compact.json")
	T.assert_equal(saved.ok,true,str(saved.errors))
	if not saved.ok: return
	var loaded := Save.load_save("user://task10-compact.json")
	T.assert_equal(loaded.ok,true)
	if not loaded.ok: return
	var before := JSON.stringify(loaded.career.to_dict())
	if before != JSON.stringify(career.to_dict()):
		print("COMPACT FIRST DIFFERENCE: ",load("res://tests/simulation/test_season_progression_service.gd").new()._first_difference(career.to_dict(),loaded.career.to_dict()))
	T.assert_equal(before == JSON.stringify(career.to_dict()),true,"compact career JSON round-trip must be stable")
	var archive: Dictionary = loaded.career.competition_archive[0]
	var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	panel.present_session(archive.merged({"archive":archive}))
	panel.present_final_archive(archive)
	var id: String = archive.final_standings[0].athlete_id
	panel.set_focus_skater(id,true)
	T.assert_equal(panel.show_replay(id,"short"),true)
	T.assert_equal(panel._segment_record.route_execution.points.is_empty(),false)
	var score := JSON.stringify(panel._segment_record.protocol)
	panel._start_playback(); panel._process(2.0); panel._skip_result()
	T.assert_equal(panel.show_replay(id,"short"),true)
	T.assert_equal(JSON.stringify(panel._segment_record.protocol),score)
	T.assert_equal(JSON.stringify(loaded.career.to_dict()),before,"replay must not mutate the committed archive, clocks or score")
	panel.free()

func test_immediate_commit_compaction() -> void:
	var career = _career()
	T.assert_equal(career.competition_archive.size(),1)
	if career.competition_archive.is_empty(): return
	T.assert_equal(career.competition_archive[0].has("packed_archive"),true,"a finished event must not leave a multi-megabyte raw archive in the live career")
	T.assert_equal(_codec().validate(career.competition_archive[0]),"")

func test_packed_archive_canonical_identity() -> void:
	var codec = _codec()
	if codec == null: return
	var packed: Dictionary = codec.compact(_career().competition_archive[0])
	var canonical = load("res://src/persistence/numeric_state.gd").canonical_copy(packed)
	T.assert_equal(is_same(canonical,packed),true,"already canonical packed history should remain an immutable shared value")

func test_corrupt() -> void:
	var codec = _codec()
	if codec == null: return
	var career = _career()
	career.competition_archive[0] = codec.compact(career.competition_archive[0])
	career.competition_archive[0].packed_archive.sha256 = "tampered"
	T.assert_equal(Save._validate_payload({"save_version":13,"saved_at_unix":0,"career":career.to_dict()}).is_empty(),false)
	career.competition_archive[0].packed_archive.payload = "AAAA"
	T.assert_equal(Save._validate_payload({"save_version":13,"saved_at_unix":0,"career":career.to_dict()}).is_empty(),false)
	var mismatched = _career()
	T.assert_equal(_codec().validate(mismatched.competition_archive[0]),"")
	mismatched.competition_archive[0].final_standings[0].total_score = -999.0
	T.assert_equal(_codec().validate(mismatched.competition_archive[0]).is_empty(),false,"cache key must include the public archive index")
	var invalid_gzip = _career()
	var fake_payload := Marshalls.raw_to_base64("not a gzip archive".to_utf8_buffer())
	invalid_gzip.competition_archive[0].packed_archive.payload = fake_payload
	invalid_gzip.competition_archive[0].packed_archive.payload_sha256 = fake_payload.sha256_text()
	invalid_gzip.competition_archive[0].packed_archive.sha256 = "0".repeat(64)
	invalid_gzip.competition_archive[0].packed_archive.raw_bytes = 32
	T.assert_equal(Save.save(invalid_gzip,"user://task10-invalid-gzip.json").ok,false,"durable save must deep-validate an uncached packed body")
