extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Repo = preload("res://src/persistence/save_repository.gd")
const Migrator = preload("res://src/persistence/save_migrator.gd")
const Schema = preload("res://src/persistence/save_schema.gd")
const Career = preload("res://src/domain/career_state.gd")
const Factory = preload("res://src/simulation/career_factory.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"old identity migration keeps missing date unknown and preserves history", "callable":old_unknown},
		{"name":"identity migration preserves explicitly supplied date", "callable":old_exact},
		{"name":"real repository birthday roundtrip survives JSON numeric dates", "callable":save_roundtrip},
		{"name":"repository rejects malformed birthday before decoding it away", "callable":reject_payload},
		{"name":"nested NPC birthday is validated at the same load boundary", "callable":reject_nested},
		{"name":"failed birthday save preserves previous primary and live career", "callable":failed_save},
		{"name":"creation carries an explicit birthday and rejects an impossible one", "callable":factory_date},
		{"name":"year only creation never invents a birthday", "callable":factory_unknown},
	]

func _payload(version: int = Schema.CURRENT_VERSION) -> Dictionary:
	var data: Dictionary = F.starting_career(80301).to_dict()
	data.schema_version = version
	return {"save_version":version,"saved_at_unix":0,"career":data}

func old_unknown() -> void:
	for version in [19,20,21]:
		var payload := _payload(version)
		payload.career.athlete.erase("birth_date")
		var before := JSON.stringify(payload)
		var result: Dictionary = Migrator.to_current(payload)
		T.assert_equal(result.ok,true)
		if not result.ok: continue
		T.assert_equal(result.data.career.athlete.has("birth_date"),true,"migration records unknown precision explicitly")
		T.assert_equal(result.data.career.athlete.get("birth_date",{}),{})
		var restored_athlete: Dictionary = result.data.career.athlete.duplicate(true)
		restored_athlete.erase("birth_date")
		T.assert_equal(restored_athlete,payload.career.athlete)
		for field in ["clock","random_streams","active_programs","technical_repertoire","competition_archive"]:
			T.assert_equal(result.data.career[field],payload.career[field],field+" must remain unchanged")
		T.assert_equal(result.data.save_version,Schema.CURRENT_VERSION)
		T.assert_equal(JSON.stringify(payload),before)

func old_exact() -> void:
	var payload := _payload(21)
	payload.career.athlete.birth_date = {"year":2007,"month":6,"day":30}
	var decoded: Dictionary = Repo.decode_payload(JSON.stringify(payload))
	T.assert_equal(decoded.ok,true)
	if not decoded.ok: return
	var restored = Career.from_dict(decoded.data.career)
	T.assert_equal(restored.to_dict().athlete.get("birth_date",{}),payload.career.athlete.birth_date)

func save_roundtrip() -> void:
	var data: Dictionary = F.starting_career(80302).to_dict()
	data.athlete.birth_date = {"year":2007,"month":7,"day":1}
	var career = Career.from_dict(JSON.parse_string(JSON.stringify(data)))
	var saved: Dictionary = Repo.save(career,"user://identity-roundtrip.json")
	T.assert_equal(saved.ok,true)
	if not saved.ok: return
	var loaded: Dictionary = Repo.load_save("user://identity-roundtrip.json")
	T.assert_equal(loaded.ok,true)
	if loaded.ok:
		T.assert_equal(loaded.career.to_dict().athlete.get("birth_date",{}),data.athlete.birth_date)
		T.assert_equal(JSON.stringify(loaded.career.to_dict()),JSON.stringify(career.to_dict()))

func reject_payload() -> void:
	for value in ["2007-06-30",[],null,{"year":2007,"month":2,"day":29},{"year":2007,"month":6,"day":0},{"year":2007,"month":6.5,"day":30},{"year":2007,"month":"6","day":30},{"year":2006,"month":6,"day":30},{"year":2007,"month":true,"day":1}]:
		var payload := _payload()
		payload.career.athlete.birth_date = value
		var result: Dictionary = Repo.decode_payload(JSON.stringify(payload))
		T.assert_equal(result.ok,false,"bad date must fail before state normalization: "+str(value))

func reject_nested() -> void:
	var payload := _payload()
	var record: Dictionary = load("res://src/simulation/world_generation_service.gd").generate_child_record({},"identity-peer",80303,0,2014,8,"northstar")
	payload.career.world_athletes = {"identity-peer":record}
	T.assert_equal(Repo.decode_payload(JSON.stringify(payload)).ok,true,"control NPC must be a valid real generated record")
	record.athlete.birth_date = {"year":record.athlete.birth_year,"month":2,"day":30}
	T.assert_equal(Repo.decode_payload(JSON.stringify(payload)).ok,false,"nested impossible date must reject")

func failed_save() -> void:
	var career = F.starting_career(80304)
	T.assert_equal(Repo.save(career,"user://identity-preserve.json").ok,true)
	var before := FileAccess.get_file_as_string("user://identity-preserve.json")
	var data: Dictionary = career.to_dict()
	data.athlete.birth_date = {"year":2007,"month":2,"day":30}
	var invalid = Career.from_dict(data)
	var invalid_before := JSON.stringify(invalid.to_dict())
	T.assert_equal(Repo.save(invalid,"user://identity-preserve.json").ok,false)
	T.assert_equal(FileAccess.get_file_as_string("user://identity-preserve.json"),before)
	T.assert_equal(JSON.stringify(invalid.to_dict()),invalid_before)

func _profile() -> Dictionary:
	var repository = load("res://src/content/club_coach_repository.gd").new()
	var club: Dictionary = repository.clubs()[0]
	var coach: Dictionary = repository.coaches_for_club(club.id)[0]
	return {"display_name":"生日测试","birth_year":2007,"entry_path_id":"entry_interest_class","family_profile_id":"family_supportive","skating_start_age":4,"club_id":club.id,"coach_id":coach.id}

func factory_date() -> void:
	var profile := _profile()
	profile.birth_date = {"year":2007,"month":6,"day":30}
	var result: Dictionary = Factory.create_from_profile(profile,80305)
	T.assert_equal(result.errors,[])
	if result.career != null: T.assert_equal(result.career.to_dict().athlete.get("birth_date",{}),profile.birth_date)
	for value in [{"year":2007,"month":2,"day":29},"2007-06-30",{"year":2007,"month":6,"day":0}]:
		profile.birth_date = value
		var invalid: Dictionary = Factory.create_from_profile(profile,80305)
		T.assert_equal(invalid.career,null,"invalid profile date must not publish a career")
		T.assert_equal(invalid.errors.is_empty(),false)

func factory_unknown() -> void:
	var result: Dictionary = Factory.create_from_profile(_profile(),80306)
	T.assert_equal(result.errors,[])
	if result.career != null: T.assert_equal(result.career.to_dict().athlete.get("birth_date",{}),{})
	T.assert_equal(F.starting_career(80307).to_dict().athlete.get("birth_date",{}),{})
