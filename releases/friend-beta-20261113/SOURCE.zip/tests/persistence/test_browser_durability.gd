extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Service = preload("res://src/persistence/browser_save_service.gd")

class RefusedStorage extends RefCounted:
	var available := true
	var releases := 0
	func begin() -> Dictionary: return {"ok":available,"errors":["IndexedDB unavailable"] if not available else []}
	func flush() -> Dictionary: return {"ok":false,"errors":["IndexedDB quota transaction aborted"]}
	func release() -> void: releases += 1

class FailedWrite extends RefCounted:
	func store_string(_text: String) -> void: pass
	func get_error() -> Error: return ERR_FILE_CANT_WRITE
	func close() -> void: pass

func cases() -> Array[Dictionary]:
	return [{"name":"unavailable IndexedDB refuses save without replacing target or active slot","callable":test_unavailable},
		{"name":"failed durable sync rolls back slot and retains import retry candidate","callable":test_sync_failure},
		{"name":"metadata store error rejects rename without falsifying payload success","callable":test_metadata_error},
		{"name":"body decision does not publish or clear dirty after durable failure","callable":test_body_failure},
		{"name":"invitation action retains career on durable failure","callable":test_invitation_failure},
		{"name":"held acknowledgement gates UI publication and retry","callable":test_held_ack}]

func _service():
	return Service.new("user://durability-%d" % Time.get_ticks_usec())

func test_unavailable() -> void:
	var service = _service(); var original = F.starting_career(900)
	service.save_slot("manual-2",original); service.save_slot("manual-1",original)
	var before := FileAccess.get_file_as_bytes(service.slot_path("manual-2"))
	var driver := RefusedStorage.new(); driver.available = false
	service.set("durability",driver)
	T.assert_equal((await service.save_slot("manual-2",F.starting_career(901))).ok,false,"memory-only writes are not durable success")
	T.assert_equal(FileAccess.get_file_as_bytes(service.slot_path("manual-2")),before)
	T.assert_equal(service.active_slot,"manual-1")

func test_sync_failure() -> void:
	var service = _service(); service.save_slot("manual-1",F.starting_career(902))
	service.save_slot("manual-1",F.starting_career(903))
	var path: String = service.slot_path("manual-1")
	var primary := FileAccess.get_file_as_bytes(path); var backup := FileAccess.get_file_as_bytes(path + ".bak")
	service.save_slot("manual-2",F.starting_career(904))
	service.import_payload(FileAccess.get_file_as_string(service.slot_path("manual-2")))
	service.set("durability",RefusedStorage.new())
	T.assert_equal((await service.confirm_import("manual-1")).ok,false,"an aborted IndexedDB sync must reach the caller")
	T.assert_equal(FileAccess.get_file_as_bytes(path),primary)
	T.assert_equal(FileAccess.get_file_as_bytes(path + ".bak"),backup)
	T.assert_equal(service.active_slot,"manual-2")
	service.set("durability",null)
	T.assert_equal((await service.confirm_import("manual-1")).ok,true,"failed durable import retains its validated preview")

func test_metadata_error() -> void:
	var service = _service(); var career = F.starting_career(905)
	service.save_slot("manual-1",career)
	service.set("metadata_opener",func(_path): return FailedWrite.new())
	T.assert_equal((await service.rename_slot("manual-1","不能写入")).ok,false)
	T.assert_equal((await service.save_slot("manual-1",career)).ok,true,"sidecar errors do not turn committed core payloads into failed saves")

func test_body_failure() -> void:
	var main = load("res://src/app/main.tscn").instantiate(); Engine.get_main_loop().root.add_child(main)
	main.browser_saves = _service(); main.autosave_path = main.browser_saves.slot_path("autosave")
	main.browser_saves.set("durability",RefusedStorage.new())
	main.active_career = F.starting_career(906); main.has_unsaved_changes = true
	load("res://src/simulation/key_node_service.gd").add(main.active_career,"durable-body","growth_warning","需要回应")
	var before: Dictionary = main.active_career.to_dict()
	await main._on_key_node_response("durable-body")
	T.assert_equal(main.active_career.to_dict(),before)
	T.assert_equal(main.has_unsaved_changes,true)
	main.free()

func test_invitation_failure() -> void:
	var main = load("res://src/app/main.tscn").instantiate(); Engine.get_main_loop().root.add_child(main)
	main.browser_saves = _service(); main.autosave_path = main.browser_saves.slot_path("autosave")
	main.browser_saves.set("durability",RefusedStorage.new())
	main.active_career = F.starting_career(907); main.has_unsaved_changes = true
	main.active_career.internal_invitation_state = {"status":"pending","offered_clock":main.active_career.clock.to_dict()}
	main.quarter_panel.setup(main.active_career,main.catalog)
	var before: Dictionary = main.active_career.to_dict()
	await main._on_internal_competition_deferred()
	T.assert_equal(main.active_career.to_dict() == before,true,"failed invitation save must not publish the decision")
	main.free()

func test_held_ack() -> void:
	var output: Array = []
	var code := OS.execute(OS.get_executable_path(),["--headless","--path",ProjectSettings.globalize_path("res://"),"--script","res://tests/fixtures/browser_ack_probe.gd"],output,true)
	for chunk in output: print(str(chunk))
	T.assert_equal(code,0,"pending acknowledgement must block UI and preserve retry state")
