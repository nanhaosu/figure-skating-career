extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Career = preload("res://src/domain/career_state.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const PATH := "res://src/domain/beijing_trial_series.gd"
const RIVAL := "world-96600-CHN-0000"

func cases() -> Array[Dictionary]:
	return [
		{"name":"trial series defaults remain unexamined without inventing enrollment or scores", "callable":defaults},
		{"name":"trial series choices lottery and source receipts survive actual disk read", "callable":roundtrip},
		{"name":"invalid trial identities or source receipts cannot overwrite a valid save", "callable":corruption},
		{"name":"trial series cannot persist future event or finalization receipts", "callable":chronology},
	]

func _career():
	var c = F.starting_career(96600)
	c.clock.year = 2021; c.clock.quarter = 4
	c.athlete.birth_year = 2004
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","junior")
	var record: Dictionary = load("res://src/simulation/world_generation_service.gd").generate_record({},"CHN",bundle.federation_profiles.CHN,96600,0,{"year":2021,"quarter":3},"2021-22",16)
	T.assert_equal(record.get("errors",[]),[])
	if record.has("errors"): return c
	c.world_athletes[record.athlete_id] = record
	c.world_state.athlete_ids = [record.athlete_id]
	c.world_state.generated_federations = ["CHN"]
	c.world_state.season_id = "2021-22"
	c.world_state.last_advanced_clock = {"year":2021,"quarter":3}
	return c

func _state() -> Dictionary:
	return {"version":1,"series_id":"beijing2022_women_trials","season_id":"2021-22","status":"collecting","player_choice":"enrolled","entrant_ids":["player",RIVAL],"lottery_seed":96600,"enrollment_receipts":{"join-1":{"choice":"enrolled"}},"withdrawals":{"player":["cn_beijing_trial_2_2021"]},"event_receipts":{"cn_beijing_trial_1_2021":{"fingerprint":"a".repeat(64),"revision":1}},"finalization":{}}

func defaults() -> void:
	T.assert_equal(FileAccess.file_exists(PATH),true,"dedicated series state validator required")
	var c = F.starting_career(96600)
	var data := c.to_dict()
	T.assert_equal(data.has("beijing_trial_series"),true)
	if not data.has("beijing_trial_series"): return
	T.assert_equal(data.beijing_trial_series.status,"unexamined")
	T.assert_equal(data.beijing_trial_series.entrant_ids,[])
	data.erase("beijing_trial_series")
	var restored = Career.from_dict(data)
	T.assert_equal(restored.to_dict().beijing_trial_series.player_choice,"unexamined")
	T.assert_equal(restored.competition_archive,[])

func roundtrip() -> void:
	var c = _career()
	if not c.to_dict().has("beijing_trial_series"):
		T.assert_equal(false,true,"series state must be part of actual career persistence")
		return
	c.set("beijing_trial_series",_state())
	var saved := Save.save(c,"user://beijing-trial-series-state-v3.json")
	T.assert_equal(saved.ok,true,str(saved.errors))
	if not saved.ok: return
	var read := Save.load_save("user://beijing-trial-series-state-v3.json")
	T.assert_equal(read.ok,true,str(read.errors))
	if not read.ok: return
	T.assert_equal(read.career.get("beijing_trial_series"),_state())
	var detached: Dictionary = read.career.to_dict()
	detached.beijing_trial_series.entrant_ids.clear()
	T.assert_equal(read.career.get("beijing_trial_series").entrant_ids,["player",RIVAL])

func corruption() -> void:
	var c = _career()
	if not c.to_dict().has("beijing_trial_series"):
		T.assert_equal(false,true,"invalid series state must not be silently lost by serialization")
		return
	c.set("beijing_trial_series",_state())
	var saved := Save.save(c,"user://beijing-trial-series-protected-v4.json")
	T.assert_equal(saved.ok,true,str(saved.errors))
	if not saved.ok: return
	var before := FileAccess.get_sha256("user://beijing-trial-series-protected-v4.json")
	for mode in ["duplicate","event","hash","revision","declined","ghost","seed","missing_identity"]:
		var state := _state()
		match mode:
			"duplicate": state.entrant_ids.append("player")
			"event": state.event_receipts["cn_beijing_trial_6_2021"] = state.event_receipts.values()[0]
			"hash": state.event_receipts.values()[0].fingerprint = "not-a-hash"
			"revision": state.event_receipts.values()[0].revision = 1.5
			"declined": state.player_choice = "declined"
			"ghost": state.status = "finalized"; state.finalization = {"selected_ids":["ghost"],"decided_on":"2022-01-24"}
			"seed": state.lottery_seed = -1
			"missing_identity": state.entrant_ids.append("nonexistent-rival")
		c.set("beijing_trial_series",state)
		var denied := Save.save(c,"user://beijing-trial-series-protected-v4.json")
		T.assert_equal(denied.ok,false,mode)
		T.assert_equal(FileAccess.get_sha256("user://beijing-trial-series-protected-v4.json"),before,"invalid series cannot damage the existing file: "+mode)

func chronology() -> void:
	var c = _career()
	if not c.to_dict().has("beijing_trial_series"):
		T.assert_equal(false,true,"series state required")
		return
	for mode in ["before_season","future_event","future_final"]:
		var state := _state()
		c.clock.year = 2021; c.clock.quarter = 4
		match mode:
			"before_season": c.clock.year = 2020; state.event_receipts = {}
			"future_event": state.event_receipts["cn_beijing_trial_3_2021"] = {"fingerprint":"b".repeat(64),"revision":1}
			"future_final":
				c.clock.year = 2022; c.clock.quarter = 1
				state.status = "finalized"
				state.finalization = {"selected_ids":["player"],"decided_on":"2022-04-01"}
		c.set("beijing_trial_series",state)
		var result := Save.save(c,"user://beijing-trial-future-denied-v2.json")
		T.assert_equal(result.ok,false,mode+" must not turn future trials into saved evidence")
