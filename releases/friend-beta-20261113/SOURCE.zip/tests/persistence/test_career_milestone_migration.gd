extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const M = preload("res://tests/fixtures/first_meaning_fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"version nineteen gains bounded milestones without altering old memories or results","callable":migration},
		{"name":"milestone index rejects malformed keys and oversized records","callable":bounds},
		{"name":"legacy restore preserves unknown earliest history and expands at most four protocols","callable":restore}]

func migration() -> void:
	var c = F.starting_career(1801)
	var payload := {"save_version":19,"saved_at_unix":0,"career":c.to_dict()}
	payload.career.schema_version = 19
	payload.career.experience_state = {"personal_expectations":{},"suggestion_receipts":{},"relationship_memories":[]}
	var before := JSON.stringify(payload)
	var result: Dictionary = load("res://src/persistence/save_migrator.gd").to_current(payload)
	T.assert_equal(result.data.save_version,preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	T.assert_equal(result.data.career.experience_state.get("milestones",{"missing":true}),{})
	T.assert_equal(result.data.career.experience_state.get("milestone_history",{}).get("status",""),"unexamined")
	T.assert_equal(result.data.career.athlete,payload.career.athlete)
	T.assert_equal(JSON.stringify(payload),before)

func bounds() -> void:
	var model = load("res://src/domain/career_experience_state.gd")
	var state: Dictionary = model.empty()
	state.milestones = {"fake_world_record":{"event_id":"x"}}
	T.assert_equal(model.validate(state).is_empty(),false,"unknown milestones must not be accepted")
	state = model.empty()
	state.milestones = {"first_formal_3a":{"event_id":"x","summary":"x".repeat(9000)}}
	T.assert_equal(model.validate(state).is_empty(),false)
	var service = load("res://src/simulation/career_milestone_service.gd")
	var fact: Dictionary = service.inspect_archive(M.archive()).axel_completed[0]
	for invalid in ["negative_part","zero_year"]:
		state = model.empty()
		state.milestones.first_formal_3a = service.record_for(fact,"live","confirmed_first")
		if invalid == "negative_part": state.milestones.first_formal_3a.part_index = -1
		else: state.milestones.first_formal_3a.clock.year = 0
		T.assert_equal(model.validate(state).is_empty(),false,invalid+" must not become a valid persisted memory")

func restore() -> void:
	var path := "res://src/persistence/career_milestone_restore_service.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"legacy milestones need a conservative one-time restore")
	if not FileAccess.file_exists(path): return
	var c = F.starting_career(1802)
	c.experience_state.milestone_history = {"status":"unexamined","checked_archive_count":0}
	var unknown := M.archive(); unknown.event_id = "old"; unknown.event.start_date = "2018-09-01"; unknown.short_results.player.erase("performance"); unknown.free_results.player.erase("performance")
	c.competition_archive.assign([M.archive(),unknown])
	var result: Dictionary = load(path).restore(c)
	T.assert_equal(result.experience_state.milestone_history.status,"partial")
	T.assert_equal(result.experience_state.milestones.get("first_formal_3a",{}).get("certainty",""),"observed")
	T.assert_equal(c.experience_state.milestone_history.status,"unexamined","restoration must return a private candidate")
	var codec = load("res://src/persistence/competition_archive_codec.gd")
	c.competition_archive.clear()
	for index in 7:
		var a := M.archive(); a.event_id = "formal-%d" % index; a.roster = []
		c.competition_archive.append(codec.compact(a))
	result = load(path).restore(c)
	T.assert_equal(result.expanded_count,4)
	T.assert_equal(result.experience_state.milestone_history.status,"partial")
	c.experience_state = result.experience_state
	T.assert_equal(load(path).restore(c).expanded_count,0)
