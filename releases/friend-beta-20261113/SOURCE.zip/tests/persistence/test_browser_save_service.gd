extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Repo = preload("res://src/persistence/save_repository.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"portable slot adapter exists", "callable":test_service}, {"name":"slot summaries isolate malformed metadata", "callable":test_metadata_isolation}, {"name":"failed event save keeps visible retry options", "callable":test_event_retry}, {"name":"failed body decision save preserves active node", "callable":test_body_retry}]

func test_metadata_isolation() -> void:
	var service = load("res://src/persistence/browser_save_service.gd").new("user://metadata-isolation-%d" % Time.get_ticks_usec())
	var career = F.starting_career(810)
	T.assert_equal((await service.save_slot("manual-2", career)).ok, true)
	var broken := FileAccess.open(service.slot_path("autosave") + ".meta", FileAccess.WRITE)
	broken.store_string("{broken")
	broken.close()
	var rows: Array[Dictionary] = service.list_slots()
	T.assert_equal(rows[0].status, "unreadable")
	T.assert_equal(rows[2].status, "saved")
	T.assert_equal(rows[2].athlete, career.athlete.display_name)

func test_service() -> void:
	T.assert_equal(ResourceLoader.exists("res://src/persistence/browser_save_service.gd"),true,"browser slot service is required")
	if not ResourceLoader.exists("res://src/persistence/browser_save_service.gd"): return
	var service = load("res://src/persistence/browser_save_service.gd").new("user://browser-test-%d" % Time.get_ticks_usec())
	var career = F.starting_career(811)
	career.athlete.display_name = "林雪·冰上追梦"
	T.assert_equal((await service.save_slot("manual-1",career)).ok,true)
	T.assert_equal((await service.save_slot("autosave",career)).ok,true)
	T.assert_equal(service.list_slots().size(),4)
	var broken_meta := FileAccess.open(service.slot_path("manual-1") + ".meta",FileAccess.WRITE)
	broken_meta.store_string("")
	broken_meta.close()
	var fallback_row: Dictionary = service.list_slots()[1]
	T.assert_equal(fallback_row.name,"手动存档 1","a truncated metadata sidecar must degrade to safe defaults")
	T.assert_equal(fallback_row.status,"saved")
	T.assert_equal((await service.save_slot("manual-1",career)).ok,true,"a later save must repair truncated metadata")
	T.assert_equal((await service.load_slot("manual-1")).career.athlete.display_name,"林雪·冰上追梦")
	var original := FileAccess.get_file_as_bytes(service.slot_path("manual-1"))
	for id in ["../escape","manual-1/../../bad","", "manual-99", "C:/bad"]:
		T.assert_equal((await service.save_slot(id,career)).ok,false)
	T.assert_equal((await service.load_slot("manual-1")).ok,true)
	for payload in ["{broken", "{}", "{\"save_version\":999,\"saved_at_unix\":0,\"career\":{}}", original.get_string_from_utf8().left(400)]:
		T.assert_equal(service.import_payload(payload).ok,false)
		T.assert_equal(FileAccess.get_file_as_bytes(service.slot_path("manual-1")),original)
		T.assert_equal(service.active_slot,"manual-1")
	T.assert_equal(service.export_slot("manual-1","user://browser-export.json").ok,true)
	var clean = load("res://src/persistence/browser_save_service.gd").new("user://browser-clean-%d" % Time.get_ticks_usec())
	var preview: Dictionary = clean.import_slot("user://browser-export.json")
	T.assert_equal(preview.ok,true)
	T.assert_equal(FileAccess.file_exists(clean.slot_path("manual-1")),false,"preview never writes the target")
	T.assert_equal((await clean.confirm_import("manual-1")).ok,true)
	T.assert_equal((await clean.load_slot("manual-1")).career.to_dict(),career.to_dict())
	var legacy: Dictionary = JSON.parse_string(original.get_string_from_utf8())
	legacy.save_version = 13; legacy.career.schema_version = 13
	legacy.career.erase("pre_career_history")
	T.assert_equal(clean.import_payload(JSON.stringify(legacy)).ok,true)
	T.assert_equal((await clean.confirm_import("manual-2")).ok,true)
	T.assert_equal((await clean.load_slot("manual-2")).career.schema_version, preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	var v14: Dictionary = JSON.parse_string(original.get_string_from_utf8())
	v14.save_version = 14; v14.career.schema_version = 14
	for key in ["opening_stage","career_goal","training_period_state","coach_assignment","training_preferences","last_training_policy","last_generated_plan"]: v14.career.erase(key)
	T.assert_equal(clean.import_payload(JSON.stringify(v14)).ok,true)
	T.assert_equal((await clean.confirm_import("manual-3")).ok,true)
	var imported_v14 = await clean.load_slot("manual-3")
	T.assert_equal(imported_v14.ok,true)
	T.assert_equal(imported_v14.career.schema_version, preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	T.assert_equal(imported_v14.career.opening_stage,"complete")
	T.assert_equal(imported_v14.career.history,career.history,"browser import must not manufacture past events")
	T.assert_equal((await clean.delete_slot("manual-1",false)).ok,false)
	T.assert_equal((await clean.rename_slot("manual-1","中文备份")).ok,true)
	T.assert_equal(clean.list_slots()[1].name,"中文备份")
	T.assert_equal((await clean.delete_slot("manual-1",true)).ok,true)

func test_event_retry() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.autosave_path = "user://no-such-browser-test-dir/fail.json"
	main.active_career = F.starting_career(91)
	main.active_career.condition_state.pending_training_events = [{"id":"retry","signature":"roadmap_progress","title":"讨论目标","description":"训练后讨论","trigger_codes":[],"cause_ids":[],"choices":[{"id":"roadmap_accept_revision","label":"接受调整"}]}]
	main.open_next_quarter()
	var panel = main.get_node("%QuarterPanel")
	var before: Dictionary = main.active_career.to_dict()
	panel.event_dialog._choose("roadmap_accept_revision")
	T.assert_equal(main.active_career.to_dict(),before)
	T.assert_equal(panel.event_dialog.visible,true,"failed transaction must leave a retryable visible dialog")
	T.assert_equal(panel._pending_events.size(),1)
	main.free()

func test_body_retry() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.autosave_path = "user://no-such-browser-test-dir/fail.json"
	main.active_career = F.starting_career(91)
	load("res://src/simulation/key_node_service.gd").add(main.active_career,"browser-growth","growth_warning","需要回应")
	var before: Dictionary = main.active_career.to_dict()
	main._on_key_node_response("browser-growth")
	T.assert_equal(main.active_career.to_dict(),before,"failed autosave cannot publish a resolved body decision")
	main.free()
