extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"version eighteen migration adds empty experience without changing ability","callable":test_migration},
		{"name":"experience memories reject malformed and unbounded data","callable":test_validation}]

func test_migration() -> void:
	var career = F.starting_career(1032)
	var payload := {"save_version":18,"saved_at_unix":0,"career":career.to_dict()}
	payload.career.erase("experience_state")
	var result: Dictionary = load("res://src/persistence/save_migrator.gd").to_current(payload)
	T.assert_equal(result.ok,true)
	T.assert_equal(result.data.save_version,preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	T.assert_equal(result.data.career.get("experience_state",{}).get("personal_expectations",{"missing":true}),{})
	T.assert_equal(result.data.career.athlete,payload.career.athlete)
	T.assert_equal(payload.career.has("experience_state"),false)

func test_validation() -> void:
	T.assert_equal(FileAccess.file_exists("res://src/domain/career_experience_state.gd"),true)
	if not FileAccess.file_exists("res://src/domain/career_experience_state.gd"): return
	var model = load("res://src/domain/career_experience_state.gd")
	var state: Dictionary = model.empty()
	state.relationship_memories.append({"invalid":true})
	T.assert_equal(model.validate(state).is_empty(),false)
	state = model.empty()
	for index in 65: state.relationship_memories.append({"memory_id":"m:%d" % index,"person_id":"coach","event_id":"e","choice_id":"c","clock":{"year":2019,"quarter":3},"summary":"经历"})
	T.assert_equal(model.validate(state).is_empty(),false)
