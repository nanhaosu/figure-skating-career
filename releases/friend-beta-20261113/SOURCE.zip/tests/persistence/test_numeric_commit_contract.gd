extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Repo = preload("res://src/persistence/save_repository.gd")
const Simulator = preload("res://src/simulation/career_simulator.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"successful save publishes bounded numeric canonical state and identical continued training", "callable":training},
		{"name":"real player and NPC protocols reload and continue free from identical canonical state", "callable":competition},
		{"name":"legacy decimal load canonicalizes all floats and repeated saves do not drift", "callable":legacy},
		{"name":"disk and IndexedDB failure never publish numeric normalization", "callable":failures}]

func canonical(value) -> String: return JSON.stringify(JSON.parse_string(JSON.stringify(value)))
func first_unfixed(value,path: String="career") -> String:
	if value is float:
		if value != roundf(value*1000000000.0)/1000000000.0: return path
		if value == 0.0 and var_to_bytes(value) != var_to_bytes(0.0): return path+":negative_zero"
	elif value is Dictionary:
		for key in value:
			var found := first_unfixed(value[key],path+"."+str(key))
			if not found.is_empty(): return found
	elif value is Array:
		for i in value.size():
			var found := first_unfixed(value[i],path+"["+str(i)+"]")
			if not found.is_empty(): return found
	return ""

func _trained():
	var career = F.starting_career(88)
	Simulator.advance_quarter(career,F.balanced_plan(),Catalog.load_catalog())
	return career

func training() -> void:
	var career = _trained()
	var before: Dictionary = career.to_dict()
	T.assert_equal(Repo.save(career,"user://numeric-training.json").ok,true)
	T.assert_equal(first_unfixed(career.to_dict()),"","successful save must publish canonical floats")
	for group in ["skating","body"]:
		for key in before.athlete[group]:
			T.assert_equal(absf(float(before.athlete[group][key])-float(career.athlete.get(group)[key]))<=0.000000001,true)
	var loaded = Repo.load_save("user://numeric-training.json").career
	T.assert_equal(canonical(loaded.to_dict()),canonical(career.to_dict()))
	var expected: Array = Simulator.advance_quarter(career,F.balanced_plan(),Catalog.load_catalog())
	var actual: Array = Simulator.advance_quarter(loaded,F.balanced_plan(),Catalog.load_catalog())
	T.assert_equal(JSON.stringify(load("res://src/domain/outcome_record.gd").list_to_dict(actual)),JSON.stringify(load("res://src/domain/outcome_record.gd").list_to_dict(expected)))
	T.assert_equal(canonical(loaded.to_dict()),canonical(career.to_dict()))

func competition() -> void:
	var s = load("res://tests/app/test_journey_roundtrip_checkpoints.gd").new().setup("qualify")
	var career = s.driver.main.active_career
	var scores := JSON.stringify(career.competition_state.short_standings)
	T.assert_equal(s.driver.main.save_active_career().ok,true)
	T.assert_equal(first_unfixed(career.to_dict()),"","all player and NPC protocol floats use the same boundary")
	T.assert_equal(JSON.stringify(career.competition_state.short_standings),scores,"display scores and ranks are unchanged")
	var original = career.transaction_copy()
	T.assert_equal(s.driver.main.load_active_career().ok,true)
	var restored = s.driver.main.active_career
	T.assert_equal(canonical(original.to_dict()),canonical(restored.to_dict()))
	var formal = load("res://src/simulation/formal_competition_simulator.gd")
	var expected: Dictionary = formal.lock_free(original,original.competition_state,"keep")
	var actual: Dictionary = formal.lock_free(restored,restored.competition_state,"keep")
	T.assert_equal(canonical(actual),canonical(expected),"next complete FS including every NPC must match")
	T.assert_equal(canonical(original.to_dict()),canonical(restored.to_dict()))
	s.driver.main.free()

func legacy() -> void:
	var data: Dictionary = _trained().to_dict()
	data.athlete.body.ankle_load = -0.0
	var file := FileAccess.open("user://numeric-legacy.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"save_version":13,"saved_at_unix":0,"career":data})); file.close()
	var career = Repo.load_save("user://numeric-legacy.json").career
	T.assert_equal(first_unfixed(career.to_dict()),"","legacy float state must be canonical on load")
	var expected := canonical(career.to_dict())
	for round in 5:
		T.assert_equal(Repo.save(career,"user://numeric-legacy.json").ok,true)
		career = Repo.load_save("user://numeric-legacy.json").career
		T.assert_equal(canonical(career.to_dict()),expected)

func failures() -> void:
	var career = _trained()
	var original := JSON.stringify(career.to_dict(),"",true,true)
	T.assert_equal(Repo.save(career,"user://missing-numeric-folder/save.json").ok,false)
	T.assert_equal(JSON.stringify(career.to_dict(),"",true,true),original)
	var service = load("res://src/persistence/browser_save_service.gd").new("user://numeric-browser")
	service.durability = load("res://tests/persistence/test_browser_durability.gd").RefusedStorage.new()
	T.assert_equal((await service.save_slot("manual-2",career)).ok,false)
	T.assert_equal(JSON.stringify(career.to_dict(),"",true,true),original,"failed IDB ack must not publish normalized state")
	T.assert_equal(service.active_slot,"manual-1")
