extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const State = preload("res://src/domain/career_state.gd")
const Migrator = preload("res://src/persistence/save_migrator.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"external booking rejects contradictory settlement and mismatched course", "callable":test_booking_boundaries},
		{"name":"invalid training direction cannot be saved", "callable":test_invalid},
		{"name":"training direction rejects excess duplicate and malformed focuses", "callable":test_boundaries},
		{"name":"two independent focuses survive actual disk save and reload", "callable":test_disk},
		{"name":"career retains independent training direction across serialization", "callable":test_roundtrip},
		{"name":"version sixteen migration preserves career and defaults to coach direction", "callable":test_legacy}]

func test_booking_boundaries() -> void:
	var direction = load("res://src/domain/training_direction.gd")
	var focus := {"id":"expression","kind":"musical_expression","target":{}}
	var booking := {"id":"b","offer_id":"expression_lab","focus_id":"expression","focus":focus,"year":2014,"quarter":1,"cost":6,"executed_stages":0,"refund":0,"status":"booked"}
	var valid := {"focuses":[focus],"priority":"balanced","revision":0,"external_schedule":[booking]}
	T.assert_equal(direction.validate(valid),"")
	for change in [{"status":"completed"},{"refund":6},{"offer_id":"spin_lab"},{"status":"cancelled","refund":0}]:
		var invalid := valid.duplicate(true)
		invalid.external_schedule[0].merge(change,true)
		T.assert_equal(direction.validate(invalid).is_empty(),false)

func test_invalid() -> void:
	var career = F.starting_career(1733)
	var direction := {"focuses":[],"priority":"balanced","revision":-1,"external_schedule":[]}
	career.set("training_direction", direction)
	var result: Dictionary = load("res://src/persistence/save_repository.gd").save(career,"user://invalid-focus-test.json")
	T.assert_equal(result.ok, false)

func test_boundaries() -> void:
	var validator = load("res://src/domain/training_direction.gd")
	var expression := {"id":"expression","kind":"musical_expression","target":{}}
	var jump := {"id":"axel","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}}
	var valid := {"focuses":[expression,jump],"priority":"balanced","revision":0,"external_schedule":[]}
	T.assert_equal(validator.validate(valid), "")
	for focuses in [[expression,jump,{"id":"third","kind":"steps","target":{}}],[expression,expression], [{"id":"bad","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":5}]}}]]:
		var invalid := valid.duplicate(true)
		invalid.focuses = focuses
		T.assert_equal(validator.validate(invalid).is_empty(), false)

func test_disk() -> void:
	var career = F.starting_career(1734)
	career.training_direction.focuses = [{"id":"expression","kind":"musical_expression","target":{}},{"id":"axel","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}}]
	var repository = load("res://src/persistence/save_repository.gd")
	var saved: Dictionary = repository.save(career,"user://dual-focus-roundtrip.json")
	T.assert_equal(saved.ok, true)
	var restored: Dictionary = repository.load_save("user://dual-focus-roundtrip.json")
	T.assert_equal(restored.ok, true)
	if restored.ok: T.assert_equal(restored.career.training_direction,career.training_direction)

func test_roundtrip() -> void:
	var career = F.starting_career(1731)
	var data: Dictionary = career.to_dict()
	T.assert_equal(data.has("training_direction"), true)
	if not data.has("training_direction"): return
	data.training_direction = {"focuses":[{"id":"expression","kind":"musical_expression","target":{}}],"priority":"balanced","revision":1,"external_schedule":[]}
	var restored = State.from_dict(data)
	T.assert_equal(restored.to_dict().training_direction, data.training_direction)
	T.assert_equal(restored.active_programs, career.active_programs)

func test_legacy() -> void:
	var data: Dictionary = F.starting_career(1732).to_dict()
	data.erase("training_direction")
	data.schema_version = 16
	var result: Dictionary = Migrator.to_current({"save_version":16,"career":data})
	T.assert_equal(result.ok, true)
	T.assert_equal(result.data.career.has("training_direction"), true)
	if not result.data.career.has("training_direction"): return
	T.assert_equal(result.data.career.training_direction.focuses, [])
	T.assert_equal(result.data.career.condition_state, data.condition_state)
	T.assert_equal(result.data.career.technical_repertoire, data.technical_repertoire)
