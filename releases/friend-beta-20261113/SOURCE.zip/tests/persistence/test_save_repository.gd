extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")
const FormalCompetitionSimulator = preload("res://src/simulation/formal_competition_simulator.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const CareerState = preload("res://src/domain/career_state.gd")

const ROUND_TRIP_PATH := "user://test-career.json"
const FUTURE_VERSION_PATH := "user://future-career.json"
const MISSING_KEY_PATH := "user://missing-key-career.json"
const MALFORMED_PATH := "user://malformed-career.json"
const OLD_VERSION_PATH := "user://old-career.json"
const MISSING_FILE_PATH := "user://missing-career.json"
const INVALID_SCHEMA_PATH := "user://invalid-schema-career.json"
const SEASON_SUMMARY_PATH := "user://season-summary-career.json"
const ROADMAP_FLOW_PATH := "user://roadmap-flow-career.json"
const BACKUP_PATH := "user://backup-career.json"
const RECOVERY_PATH := "user://recovery-career.json"

func cases() -> Array[Dictionary]:
	return [
		{"name":"save writes full precision learned metrics and preserves canonical reload state", "callable":test_learned_precision},
		{"name":"verified save fingerprints never authorize changed primary bytes", "callable":test_fingerprint_integrity},
		{"name": "save round trip preserves rng and history", "callable": test_save_round_trip_preserves_rng_and_history},
		{"name": "partial coach led training resumes from saved week", "callable": test_partial_training_period_round_trip},
		{"name": "future save version is rejected", "callable": test_future_version_is_rejected},
		{"name": "old save version is rejected", "callable": test_old_version_is_rejected},
		{"name": "missing save file is rejected", "callable": test_missing_save_file_is_rejected},
		{"name": "missing required save key is rejected", "callable": test_missing_required_save_key_is_rejected},
		{"name": "malformed save JSON is rejected", "callable": test_malformed_save_json_is_rejected},
		{"name": "non dictionary athlete state is rejected", "callable": test_non_dictionary_athlete_state_is_rejected},
		{"name": "non dictionary relationship is rejected", "callable": test_non_dictionary_relationship_is_rejected},
		{"name": "save replaces an existing target", "callable": test_save_replaces_an_existing_target},
		{"name": "failed save preserves existing target", "callable": test_failed_save_preserves_existing_target},
		{"name": "first save does not invent a backup", "callable": test_first_save_has_no_backup},
		{"name": "second save retains previous valid career as backup", "callable": test_second_save_retains_previous_backup},
		{"name": "failed save preserves primary and backup", "callable": test_failed_save_preserves_primary_and_backup},
		{"name": "corrupt primary recovers explicitly from backup", "callable": test_corrupt_primary_recovers_from_backup},
		{"name": "corrupt nested athlete metric is rejected before restoration", "callable": test_corrupt_nested_athlete_metric_is_rejected},
		{"name": "corrupt seed relationship and history are rejected", "callable": test_corrupt_seed_relationship_and_history_are_rejected},
		{"name": "missing career foundation is rejected", "callable": test_missing_career_foundation_is_rejected},
		{"name": "malformed story and random context are rejected", "callable": test_malformed_story_and_random_context_are_rejected},
		{"name": "season summary save round trips after fourth quarter", "callable": test_season_summary_save_round_trip},
		{"name": "quarter plan and secret result survive save round trip", "callable": test_quarter_plan_secret_result_round_trip},
		{"name": "malformed season summaries are rejected on load", "callable": test_malformed_season_summaries_are_rejected},
		{"name": "malformed memory is rejected before restoration", "callable": test_malformed_memory_is_rejected},
		{"name": "malformed percentage plan is rejected", "callable": test_malformed_percentage_plan_is_rejected},
		{"name": "four quarter roadmap flow survives save and reload", "callable": test_roadmap_flow_round_trip},
		{"name": "competition session survives save and reload", "callable": test_competition_session_round_trip},
		{"name": "formal competition career state survives save and reload", "callable": test_formal_competition_state_round_trip},
		{"name": "season entry state survives save and reload", "callable": test_season_state_round_trip},
		{"name": "malformed season entry state is rejected", "callable": test_malformed_season_state_is_rejected},
		{"name": "technical grade and invitation state survive save and reject malformed grade", "callable": test_certification_and_invitation_round_trip},
		{"name": "version thirteen state boundaries survive save round trip", "callable": test_version_thirteen_state_round_trip},
		{"name": "malformed version thirteen state boundaries are rejected", "callable": test_malformed_version_thirteen_state},
		{"name": "version fourteen pre-career history validates and round trips", "callable": test_version_fourteen_pre_career_history},
		{"name": "malformed version fourteen pre-career history is rejected", "callable": test_malformed_version_fourteen_pre_career_history},
		{"name": "malformed version fifteen first-loop state is rejected", "callable": test_malformed_version_fifteen_state},
		{"name": "malformed roadmap progress is rejected", "callable": test_malformed_roadmap_progress_is_rejected},
		{"name": "every formal competition checkpoint survives reload", "callable": test_formal_checkpoints_round_trip},
		{"name": "legacy career without spin types loads safely", "callable": test_legacy_spin_program_load},
	]

func test_partial_training_period_round_trip() -> void:
	var career := Fixtures.starting_career(889)
	career.training_period_state = {
		"weeks_elapsed":5,
		"intent":{"mode":"safer", "element_id":""},
		"plan":Fixtures.percentage_balanced_plan().to_dict(),
		"started_clock":career.clock.to_dict(),
	}
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.training_period_state, career.training_period_state)
	TestSupport.assert_equal(loaded.career.clock.to_dict(), career.clock.to_dict())

func test_learned_precision() -> void:
	var career := Fixtures.starting_career(88)
	CareerSimulator.advance_quarter(career,Fixtures.balanced_plan(),CatalogRepository.load_catalog())
	TestSupport.assert_equal(SaveRepository.save(career,ROUND_TRIP_PATH).ok,true)
	var encoded := FileAccess.get_file_as_string(ROUND_TRIP_PATH)
	var restored: Dictionary = SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(restored.ok,true)
	for group in ["skating","body"]:
		for metric in career.athlete.get(group):
			var full_precision := JSON.stringify(float(career.athlete.get(group)[metric]),"",true,true)
			TestSupport.assert_equal(encoded.contains('"%s":%s' % [metric,full_precision]),true,"save text must retain full precision: "+group+"."+metric)
	# Godot's decimal parser can shift one ULP; the external contract is full
	# precision text plus complete canonical state, not a second binary format.
	TestSupport.assert_equal(JSON.stringify(restored.career.to_dict()),JSON.stringify(career.to_dict()))
	var canonical := JSON.stringify(restored.career.to_dict())
	TestSupport.assert_equal(SaveRepository.save(restored.career,ROUND_TRIP_PATH).ok,true)
	TestSupport.assert_equal(JSON.stringify(SaveRepository.load_save(ROUND_TRIP_PATH).career.to_dict()),canonical)

func test_legacy_spin_program_load() -> void:
	var career := Fixtures.formal_junior_career(991)
	var legacy_free: Dictionary = Dictionary(career.active_programs.free).duplicate(true)
	for element in legacy_free.elements:
		Dictionary(element).erase("spin_code")
	career.active_programs.free = legacy_free
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	var restored = SkatingProgram.from_dict(Dictionary(loaded.career.active_programs.free))
	TestSupport.assert_equal(restored.elements.filter(func(element): return element.kind == "spin").all(func(element): return element.spin_code == "CCoSp"), true)

func test_formal_checkpoints_round_trip() -> void:
	var career := Fixtures.formal_acceptance_career("qualify")
	var session := FormalCompetitionSimulator.create_session(career, Fixtures.u_series_event(), career.active_programs, "balanced", 12001, 34)
	var checkpoints: Array[Dictionary] = [session.duplicate(true)]
	session = FormalCompetitionSimulator.complete_practice(session, "accept"); checkpoints.append(session.duplicate(true))
	session = FormalCompetitionSimulator.lock_short(career, session); checkpoints.append(session.duplicate(true))
	session = FormalCompetitionSimulator.lock_free(career, session, "keep"); checkpoints.append(session.duplicate(true))
	for checkpoint in checkpoints:
		career.competition_state = checkpoint
		TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
		var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
		TestSupport.assert_equal(loaded.ok, true)
		TestSupport.assert_equal(_normalized(loaded.career.competition_state), _normalized(checkpoint))

func test_competition_session_round_trip() -> void:
	var career := Fixtures.starting_career(909)
	career.competition_state = {"status": "awaiting_adjustment", "seed": 77, "short": {
		"score": {"total": 21.4},
		"route_execution": {"points": [{"x": 0.2, "y": 0.4, "progress": 0.0}], "action_anchors": [{"element_id": "j1", "part_index": 0, "progress": 0.3}]},
	}}
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.competition_state, career.competition_state)
	var written: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(ROUND_TRIP_PATH))
	TestSupport.assert_equal(written.save_version, preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)
	TestSupport.assert_equal(written.career.schema_version, preload("res://src/persistence/save_schema.gd").CURRENT_VERSION)

func test_formal_competition_state_round_trip() -> void:
	var career := Fixtures.starting_career(911)
	career.competition_state = {"kind": "formal", "status": "short_complete", "event_id": "chn_national_gp_2018"}
	career.world_athletes = {"jpn_aoi": {"name": "青井澪", "federation": "JPN"}}
	career.competition_archive = [{"event_id": "chn_national_gp_2018", "status": "complete"}]
	career.record_book = {"international": {}, "all_formal": {"short": {"score": 58.24}}}
	career.ranking_state = {"domestic_points": 88, "isu_world": 0, "season_world": 0, "selection_evidence": {}}
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.competition_state, career.competition_state)
	TestSupport.assert_equal(loaded.career.world_athletes, career.world_athletes)
	TestSupport.assert_equal(loaded.career.competition_archive, career.competition_archive)
	TestSupport.assert_equal(loaded.career.record_book, career.record_book)
	TestSupport.assert_equal(loaded.career.ranking_state, career.ranking_state)

func test_season_state_round_trip() -> void:
	var career := Fixtures.starting_career(910)
	career.season_state = _populated_season_state()
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.season_state, career.season_state)

func test_malformed_season_state_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.season_state = _populated_season_state()
	data.career.season_state.qualification_state.cfsa_registered = "yes"
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 season_state.qualification_state.cfsa_registered 必须是布尔值")
	data = _valid_save_data()
	data.career.season_state = _populated_season_state()
	data.career.season_state.event_statuses.chn_club_beijing = "teleported"
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 season_state.event_statuses.chn_club_beijing 无效")
	data = _valid_save_data()
	data.career.season_state = _populated_season_state()
	data.career.season_state.entry_plan.entries.chn_club_beijing.status = "unknown"
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 season_state.entry_plan.entries.chn_club_beijing.status 无效")

func test_certification_and_invitation_round_trip() -> void:
	var career := Fixtures.starting_career(981)
	career.certification_state.national_technical_grade = 7
	career.internal_invitation_state = {"status":"deferred", "offered_clock":career.clock.to_dict()}
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.certification_state, career.certification_state)
	TestSupport.assert_equal(loaded.career.internal_invitation_state, career.internal_invitation_state)
	var malformed := _valid_save_data()
	malformed.career.certification_state.national_technical_grade = "seven"
	TestSupport.assert_equal(SaveRepository._validate_payload(malformed), "生涯字段 certification_state.national_technical_grade 必须是非负整数")

func test_version_thirteen_state_round_trip() -> void:
	var career := Fixtures.starting_career(1313)
	career.condition_state.growth_signals = [{"id":"height"}]
	career.social_state.friendships = {"friend-1":{"closeness":60}}
	career.selection_state.applications = {"jgp":{"status":"submitted"}}
	career.event_ledger = [{"id":"evt-1","kind":"audit"}]
	career.world_state = {"season_id":"2018-19","generated_federations":["CHN"],"athlete_ids":["chn-1"],"last_advanced_clock":{"year":2018,"quarter":3}}
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(_normalized(loaded.career.to_dict()), _normalized(career.to_dict()))
	var twice = CareerState.from_dict(loaded.career.to_dict())
	TestSupport.assert_equal(_normalized(twice.to_dict()), _normalized(career.to_dict()))

func test_malformed_version_thirteen_state() -> void:
	var corruptions := [
		{"field":"condition_state", "value":[], "error":"生涯字段 condition_state 必须是对象"},
		{"field":"social_state", "value":[], "error":"生涯字段 social_state 必须是对象"},
		{"field":"selection_state", "value":[], "error":"生涯字段 selection_state 必须是对象"},
		{"field":"event_ledger", "value":{}, "error":"生涯字段 event_ledger 必须是数组"},
		{"field":"world_state", "value":[], "error":"生涯字段 world_state 必须是对象"},
	]

	for corruption in corruptions:
		var data := _valid_save_data()
		data.career[corruption.field] = corruption.value
		TestSupport.assert_equal(SaveRepository._validate_payload(data), corruption.error)
	var data := _valid_save_data()
	data.career.condition_state.injuries = {}
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 condition_state.injuries 必须是数组")
	data = _valid_save_data()
	data.career.social_state.friendships = []
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 social_state.friendships 必须是对象")
	data = _valid_save_data()
	data.career.selection_state.appeals = {}
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 selection_state.appeals 必须是数组")
	data = _valid_save_data()
	data.career.event_ledger = ["bad"]
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 event_ledger.0 必须是对象")
	data = _valid_save_data()
	data.career.world_state.generated_federations = {}
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 world_state.generated_federations 必须是字符串数组")
	data = _valid_save_data()
	data.career.world_state.last_advanced_clock = {"year":2018,"quarter":5}
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 world_state.last_advanced_clock.生涯时钟字段 quarter 必须在1至4之间")

func test_version_fourteen_pre_career_history() -> void:
	var history := _valid_pre_career_history()
	var data := _valid_save_data()
	data.career.pre_career_history = history.duplicate(true)
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "")
	var restored = CareerState.from_dict(data.career)
	TestSupport.assert_equal(restored.to_dict().get("pre_career_history"), history)
	data.career.erase("pre_career_history")
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯数据缺少字段：pre_career_history")

func test_malformed_version_fourteen_pre_career_history() -> void:
	var corruptions := [
		{"field":"pre_career_history", "value":[], "error":"生涯字段 pre_career_history 必须是对象"},
		{"field":"skating_start_age", "value":2, "error":"启蒙史开始学滑年龄必须为3至6岁的整数"},
		{"field":"training_quarters", "value":21, "error":"启蒙史训练时长必须为0至20个季度的整数"},
		{"field":"source", "value":"template", "error":"启蒙史生成来源无效"},
		{"field":"episodes", "value":_valid_pre_career_history().episodes.slice(0,2), "error":"启蒙史关键经历必须为3至5条"},
		{"field":"known_observations", "value":["落冰不稳",7], "error":"启蒙史已知观察必须是字符串数组"},
	]
	for corruption in corruptions:
		var data := _valid_save_data()
		data.career.pre_career_history = _valid_pre_career_history()
		if corruption.field == "pre_career_history": data.career.pre_career_history = corruption.value
		else: data.career.pre_career_history[corruption.field] = corruption.value
		TestSupport.assert_equal(SaveRepository._validate_payload(data), corruption.error)
	var data := _valid_save_data()
	data.career.pre_career_history = _valid_pre_career_history()
	data.career.pre_career_history.episodes[1].id = data.career.pre_career_history.episodes[0].id
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "启蒙史关键经历标识不能重复")
	data = _valid_save_data()
	data.career.pre_career_history = _valid_pre_career_history()
	data.career.pre_career_history.episodes[0].erase("text")
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "启蒙史关键经历缺少有效字段：text")
	data = _valid_save_data()
	data.career.pre_career_history = _valid_pre_career_history()
	data.career.pre_career_history.episodes[0].age = 9
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "启蒙史关键经历年龄必须为3至8岁的整数")

func teardown() -> void:
	for path in [ROUND_TRIP_PATH, FUTURE_VERSION_PATH, MISSING_KEY_PATH, MALFORMED_PATH, OLD_VERSION_PATH, MISSING_FILE_PATH, INVALID_SCHEMA_PATH, SEASON_SUMMARY_PATH, ROADMAP_FLOW_PATH, BACKUP_PATH, RECOVERY_PATH]:
		_delete_file(path)
		_delete_file("%s.tmp" % path)
		_delete_file("%s.bak" % path)

func test_save_round_trip_preserves_rng_and_history() -> void:
	var career := Fixtures.starting_career(88)
	CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	TestSupport.assert_equal(SaveRepository.save(career, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(
		JSON.stringify(loaded.career.to_dict()),
		JSON.stringify(career.to_dict()),
	)
	TestSupport.assert_equal(loaded.career.seed, career.seed)
	TestSupport.assert_equal(loaded.career.rng_step, career.rng_step)
	_assert_history_equal(loaded.career.history, career.history)
	var expected_next := CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	var loaded_next := CareerSimulator.advance_quarter(loaded.career, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	TestSupport.assert_equal(JSON.stringify(OutcomeRecord.list_to_dict(loaded_next)), JSON.stringify(OutcomeRecord.list_to_dict(expected_next)))
	TestSupport.assert_equal(_normalized(loaded.career.to_dict()), _normalized(career.to_dict()))

func test_roadmap_flow_round_trip() -> void:
	var career := Fixtures.starting_career(120)
	var DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
	var DevelopmentRoadmapEvaluator = preload("res://src/simulation/development_roadmap_evaluator.gd")
	var PlanProposal = preload("res://src/domain/plan_proposal.gd")
	var roadmap = DevelopmentRoadmap.create("balanced", [{"age": 10, "rotations": 2, "count": 6}, {"age": 14, "rotations": 3, "count": 4}], ["toe_loop", "salchow"], "", "normal").roadmap
	var evaluation: Dictionary = DevelopmentRoadmapEvaluator.evaluate(career, roadmap)
	roadmap.status = evaluation.status
	roadmap.last_evaluation = evaluation
	career.development_roadmap = roadmap.to_dict()
	career.roadmap_revision_history.append({"clock": career.clock.to_dict(), "route_id": "balanced", "reason": "玩家确认成长路线"})
	var catalog := CatalogRepository.load_catalog()
	for _quarter in 4:
		var proposal = PlanProposal.create(Fixtures.percentage_balanced_plan())
		proposal.status = "resolved"
		CareerSimulator.advance_proposal(career, proposal, catalog)
	var save_result := SaveRepository.save(career, ROADMAP_FLOW_PATH)
	TestSupport.assert_equal(save_result.ok, true)
	var loaded := SaveRepository.load_save(ROADMAP_FLOW_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(_normalized(loaded.career.to_dict()), _normalized(career.to_dict()))
	TestSupport.assert_equal(loaded.career.roadmap_revision_history.size(), 1)
	TestSupport.assert_equal(loaded.career.development_roadmap.last_evaluation.is_empty(), false)

func test_malformed_roadmap_progress_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.history = [{"category": "roadmap_progress", "clock": {"year": 2014, "quarter": 2}, "status_change": {}, "forecast_change": [], "key_events": "bad", "revision_suggestion": ""}]
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 history.0 的路线预测、事件或建议类型无效")

func test_future_version_is_rejected() -> void:
	_write_json(FUTURE_VERSION_PATH, {"save_version": 99, "saved_at_unix": 0, "career": {}})
	var result := SaveRepository.load_save(FUTURE_VERSION_PATH)
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(result.errors, ["该存档来自尚不支持的版本：99"])

func test_old_version_is_rejected() -> void:
	_write_json(OLD_VERSION_PATH, {"save_version": 0, "saved_at_unix": 0, "career": {}})
	var result := SaveRepository.load_save(OLD_VERSION_PATH)
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(result.errors, ["该存档版本过低：0"])

func test_missing_save_file_is_rejected() -> void:
	_delete_file(MISSING_FILE_PATH)
	var result := SaveRepository.load_save(MISSING_FILE_PATH)
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(result.errors, ["存档文件不存在：user://missing-career.json"])

func test_missing_required_save_key_is_rejected() -> void:
	_write_json(MISSING_KEY_PATH, {"save_version": 1, "career": {}})
	var result := SaveRepository.load_save(MISSING_KEY_PATH)
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(result.errors, ["存档缺少字段：saved_at_unix"])

func test_malformed_save_json_is_rejected() -> void:
	var file := FileAccess.open(MALFORMED_PATH, FileAccess.WRITE)
	file.store_string("{not valid json")
	file.close()
	var result := SaveRepository.load_save(MALFORMED_PATH)
	TestSupport.assert_equal(result.ok, false)
	TestSupport.assert_equal(result.errors, ["存档文件不是有效的JSON"])

func test_non_dictionary_athlete_state_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.athlete.technique = 0
	_write_json(INVALID_SCHEMA_PATH, data)
	var result := SaveRepository.load_save(INVALID_SCHEMA_PATH)
	TestSupport.assert_equal(result, {
		"ok": false,
		"career": null,
		"errors": ["生涯字段 athlete.technique 必须是对象"],
	})

func test_non_dictionary_relationship_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.relationships.coach = 0
	_write_json(INVALID_SCHEMA_PATH, data)
	var result := SaveRepository.load_save(INVALID_SCHEMA_PATH)
	TestSupport.assert_equal(result, {
		"ok": false,
		"career": null,
		"errors": ["生涯字段 relationships.coach 必须是对象"],
	})

func test_fingerprint_integrity() -> void:
	_clear_save_family(BACKUP_PATH)
	var career := Fixtures.starting_career(300)
	TestSupport.assert_equal(SaveRepository.save(career,BACKUP_PATH).ok,true)
	TestSupport.assert_equal(SaveRepository.save(career,BACKUP_PATH).ok,true)
	var backup_hash := FileAccess.get_sha256(BACKUP_PATH+".bak")
	var file := FileAccess.open(BACKUP_PATH,FileAccess.WRITE)
	file.store_string("{corrupt"); file.close()
	TestSupport.assert_equal(SaveRepository.save(career,BACKUP_PATH).ok,false)
	TestSupport.assert_equal(FileAccess.get_file_as_string(BACKUP_PATH),"{corrupt")
	TestSupport.assert_equal(FileAccess.get_sha256(BACKUP_PATH+".bak"),backup_hash)
	_clear_save_family(BACKUP_PATH)
	career.athlete.body.acute_fatigue = NAN
	TestSupport.assert_equal(SaveRepository.save(career,BACKUP_PATH).ok,false)
	TestSupport.assert_equal(FileAccess.file_exists(BACKUP_PATH),false)

func test_save_replaces_an_existing_target() -> void:
	var original := Fixtures.starting_career(90)
	TestSupport.assert_equal(SaveRepository.save(original, ROUND_TRIP_PATH).ok, true)
	var replacement := Fixtures.starting_career(93)
	CareerSimulator.advance_quarter(replacement, Fixtures.balanced_plan(), CatalogRepository.load_catalog())
	TestSupport.assert_equal(SaveRepository.save(replacement, ROUND_TRIP_PATH).ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.career.seed, replacement.seed)
	TestSupport.assert_equal(loaded.career.rng_step, replacement.rng_step)
	_assert_history_equal(loaded.career.history, replacement.history)

func test_failed_save_preserves_existing_target() -> void:
	var original := Fixtures.starting_career(91)
	TestSupport.assert_equal(SaveRepository.save(original, ROUND_TRIP_PATH).ok, true)
	var invalid := Fixtures.starting_career(92)
	invalid.clock = null
	var result := SaveRepository.save(invalid, ROUND_TRIP_PATH)
	TestSupport.assert_equal(result.ok, false)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.seed, original.seed)
	TestSupport.assert_equal(loaded.career.rng_step, original.rng_step)
	_assert_history_equal(loaded.career.history, original.history)

func test_first_save_has_no_backup() -> void:
	_clear_save_family(BACKUP_PATH)
	var career := Fixtures.starting_career(201)
	TestSupport.assert_equal(SaveRepository.save(career, BACKUP_PATH).ok, true)
	TestSupport.assert_equal(FileAccess.file_exists(BACKUP_PATH), true)
	TestSupport.assert_equal(FileAccess.file_exists("%s.bak" % BACKUP_PATH), false)

func test_second_save_retains_previous_backup() -> void:
	_clear_save_family(BACKUP_PATH)
	var previous := Fixtures.starting_career(202)
	var current := Fixtures.starting_career(203)
	TestSupport.assert_equal(SaveRepository.save(previous, BACKUP_PATH).ok, true)
	TestSupport.assert_equal(SaveRepository.save(current, BACKUP_PATH).ok, true)
	var primary := SaveRepository.load_save(BACKUP_PATH)
	var backup := SaveRepository.load_save("%s.bak" % BACKUP_PATH)
	TestSupport.assert_equal(primary.ok, true)
	TestSupport.assert_equal(backup.ok, true)
	TestSupport.assert_equal(primary.career.seed, 203)
	TestSupport.assert_equal(backup.career.seed, 202)

func test_failed_save_preserves_primary_and_backup() -> void:
	_clear_save_family(BACKUP_PATH)
	var oldest := Fixtures.starting_career(204)
	var current := Fixtures.starting_career(205)
	TestSupport.assert_equal(SaveRepository.save(oldest, BACKUP_PATH).ok, true)
	TestSupport.assert_equal(SaveRepository.save(current, BACKUP_PATH).ok, true)
	var invalid := Fixtures.starting_career(206)
	invalid.clock = null
	TestSupport.assert_equal(SaveRepository.save(invalid, BACKUP_PATH).ok, false)
	TestSupport.assert_equal(SaveRepository.load_save(BACKUP_PATH).career.seed, 205)
	TestSupport.assert_equal(SaveRepository.load_save("%s.bak" % BACKUP_PATH).career.seed, 204)

func test_corrupt_primary_recovers_from_backup() -> void:
	_clear_save_family(RECOVERY_PATH)
	var previous := Fixtures.starting_career(207)
	var current := Fixtures.starting_career(208)
	TestSupport.assert_equal(SaveRepository.save(previous, RECOVERY_PATH).ok, true)
	TestSupport.assert_equal(SaveRepository.save(current, RECOVERY_PATH).ok, true)
	var file := FileAccess.open(RECOVERY_PATH, FileAccess.WRITE)
	file.store_string("{not valid json")
	file.close()
	var result := SaveRepository.load_with_recovery(RECOVERY_PATH)
	TestSupport.assert_equal(result.ok, true)
	TestSupport.assert_equal(result.recovered_from_backup, true)
	TestSupport.assert_equal(result.primary_error, "存档文件不是有效的JSON")
	TestSupport.assert_equal(result.career.seed, 207)

func test_corrupt_nested_athlete_metric_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.athlete.skating.deep_edge = 101
	TestSupport.assert_equal(
		SaveRepository._validate_payload(data),
		"生涯字段 athlete.skating.deep_edge 必须在0至100之间",
	)

func test_corrupt_seed_relationship_and_history_are_rejected() -> void:
	var data := _valid_save_data()
	data.career.seed = -1
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 seed 必须为非负整数")
	data = _valid_save_data()
	data.career.relationships.guardian.control = 101
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 relationships.guardian.control 必须在0至100之间")
	data = _valid_save_data()
	data.career.history = [{"category": "body"}]
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 history.0.target 缺失")

func test_missing_career_foundation_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.erase("story_context")
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯数据缺少字段：story_context")

func test_malformed_story_and_random_context_are_rejected() -> void:
	var data := _valid_save_data()
	data.career.story_context = 0
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 story_context 必须是对象")
	data = _valid_save_data()
	data.career.story_context.rule_mode = "computer_date"
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "故事背景 rule_mode 目前只支持 story_time")
	data = _valid_save_data()
	data.career.random_streams = []
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 random_streams 必须是对象")
	data = _valid_save_data()
	data.career.random_streams.steps["training"] = -1
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "随机流 training 的推进位置必须是非负整数")

func test_season_summary_save_round_trip() -> void:
	var career := Fixtures.starting_career(110)
	var catalog := CatalogRepository.load_catalog()
	for _quarter in 4:
		CareerSimulator.advance_quarter(career, Fixtures.balanced_plan(), catalog)
	var summaries := career.history.filter(func(item: Dictionary) -> bool: return item.get("category") == "season_summary")
	TestSupport.assert_equal(summaries.size(), 1)
	TestSupport.assert_equal(SaveRepository.save(career, SEASON_SUMMARY_PATH).ok, true)
	var loaded := SaveRepository.load_save(SEASON_SUMMARY_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(loaded.career.history.size(), career.history.size())
	var loaded_summary: Dictionary = loaded.career.history.back()
	var saved_summary: Dictionary = career.history.back()
	TestSupport.assert_equal(loaded_summary.category, "season_summary")
	TestSupport.assert_equal(loaded_summary.year, saved_summary.year)
	TestSupport.assert_equal(is_equal_approx(float(loaded_summary.peak_fatigue), float(saved_summary.peak_fatigue)), true)
	for target in saved_summary.technique_deltas:
		TestSupport.assert_equal(loaded_summary.technique_deltas.has(target), true)
		TestSupport.assert_equal(
			is_equal_approx(float(loaded_summary.technique_deltas[target]), float(saved_summary.technique_deltas[target])),
			true,
		)
	TestSupport.assert_equal(loaded_summary.cause_codes, saved_summary.cause_codes)

func test_quarter_plan_secret_result_round_trip() -> void:
	var career := Fixtures.career_with_guardian(90.0, 90.0)
	career.athlete.mind.autonomy = 30.0
	var resolver = preload("res://src/simulation/authority_resolver.gd")
	var proposal = resolver.preview(career, Fixtures.jump_heavy_plan())
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	resolver.respond(career, proposal, proposal.conflicts[0].id, "pretend_comply", rng)
	CareerSimulator.advance_proposal(career, proposal, CatalogRepository.load_catalog())
	var save_result := SaveRepository.save(career, ROUND_TRIP_PATH)
	TestSupport.assert_equal(save_result.ok, true)
	var loaded := SaveRepository.load_save(ROUND_TRIP_PATH)
	TestSupport.assert_equal(loaded.ok, true)
	TestSupport.assert_equal(JSON.stringify(loaded.career.history), JSON.stringify(career.history))

func test_malformed_season_summaries_are_rejected() -> void:
	var corruptions := [
		{"field": "year", "value": 0, "error": "生涯字段 history.0.year 必须是1至9999的整数"},
		{"field": "peak_fatigue", "value": 101, "error": "生涯字段 history.0.peak_fatigue 必须是0至100之间的数字"},
		{"field": "technique_deltas", "value": {"edge_control": "bad"}, "error": "生涯字段 history.0.technique_deltas.edge_control 必须是数字"},
		{"field": "cause_codes", "value": ["valid", 7], "error": "生涯字段 history.0.cause_codes.1 必须是字符串"},
	]
	for corruption in corruptions:
		var data := _valid_save_data()
		data.career.history = [{
			"category": "season_summary",
			"year": 2014,
			"technique_deltas": {"edge_control": 1.0},
			"peak_fatigue": 20.0,
			"cause_codes": ["training_load"],
		}]
		data.career.history[0][corruption.field] = corruption.value
		_write_json(INVALID_SCHEMA_PATH, data)
		var result := SaveRepository.load_save(INVALID_SCHEMA_PATH)
		TestSupport.assert_equal(result, {"ok": false, "career": null, "errors": [corruption.error]})

func test_malformed_memory_is_rejected() -> void:
	var data := _valid_save_data()
	data.career.memories = [{"id": "m1", "kind": "event_memory", "signature": "jump_load_conflict", "strength": 120.0, "credibility": 80.0, "decay_per_quarter": 5.0, "cause_ids": []}]
	_write_json(INVALID_SCHEMA_PATH, data)
	var result := SaveRepository.load_save(INVALID_SCHEMA_PATH)
	TestSupport.assert_equal(result.errors, ["生涯字段 memories.0.strength 必须在0至100之间"])

func test_malformed_percentage_plan_is_rejected() -> void:
	var data := _valid_save_data()
	var shares := Fixtures.percentage_balanced_plan().shares
	var targets := Fixtures.percentage_balanced_plan().jump_rotations
	data.career.history = [{
		"category": "quarter_plan", "desired": Fixtures.balanced_plan().allocations,
		"approved": Fixtures.balanced_plan().allocations, "executed": Fixtures.balanced_plan().allocations,
		"desired_shares": shares.duplicate(), "approved_shares": shares.duplicate(), "executed_shares": shares.duplicate(),
		"desired_jump_rotations": targets, "approved_jump_rotations": targets, "executed_jump_rotations": targets,
		"decisions": [], "secret_practice": {"executed_units": 0, "efficiency": 0.0, "discovered": false, "reaction": "none", "memories": [], "blocked_reasons": []}, "cause_codes": [],
	}]
	data.career.history[0].desired_shares.rest = 10
	TestSupport.assert_equal(SaveRepository._validate_payload(data), "生涯字段 history.0.desired_shares 不是有效百分比训练计划")

func test_malformed_version_fifteen_state() -> void:
	var corruptions := [
		{"field":"opening_stage", "value":7, "error":"生涯字段 opening_stage 无效"},
		{"field":"career_goal", "value":{"id":"win_everything","chosen_clock":{"year":2014,"quarter":1},"scoring_effect":false}, "error":"生涯字段 career_goal.id 无效"},
		{"field":"training_period_state", "value":{"weeks_elapsed":"five"}, "error":"生涯字段 training_period_state.weeks_elapsed 必须是0至12的整数"},
		{"field":"coach_assignment", "value":{"club_id":9}, "error":"生涯字段 coach_assignment.club_id 必须是字符串"},
		{"field":"training_preferences", "value":{"breakthrough_policy":"always","minor_pain_policy":"ask","coach_strategy_policy":"summary"}, "error":"生涯字段 training_preferences.breakthrough_policy 无效"},
	]
	for corruption in corruptions:
		var career := Fixtures.starting_career(1515)
		var data := {"save_version":15,"saved_at_unix":0,"career":career.to_dict()}
		data.career[corruption.field] = corruption.value
		TestSupport.assert_equal(SaveRepository._validate_payload(data),corruption.error)

func _write_json(path: String, data: Dictionary) -> void:
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_string(JSON.stringify(data))
	file.close()

func _normalized(value):
	if value is int or value is float: return snappedf(float(value), 0.000000001)
	if value is Array:
		var result: Array = []
		for item in value: result.append(_normalized(item))
		return result
	if value is Dictionary:
		var result: Dictionary = {}
		for key in value: result[key] = _normalized(value[key])
		return result
	return value

func _valid_save_data() -> Dictionary:
	return {
		"save_version": 3,
		"saved_at_unix": 0,
		"career": Fixtures.starting_career(101).to_dict(),
	}

func _valid_pre_career_history() -> Dictionary:
	return {
		"version":1,
		"skating_start_age":4,
		"training_quarters":12,
		"episodes":[
			{"id":"first-ice", "age":4, "kind":"first_contact", "text":"第一次踏上冰面。"},
			{"id":"first-jump", "age":5, "kind":"jump", "text":"学会了第一个基础单跳。"},
			{"id":"club-handoff", "age":7, "kind":"handoff", "text":"教练建议进入系统训练。"},
		],
		"coach_assessment":"冰感不错，落冰还需要耐心练习。",
		"known_observations":["落冰有时不稳"],
		"source":"generated",
	}

func _populated_season_state() -> Dictionary:
	return {
		"season_id": "2018-19",
		"entry_plan": {
			"season_id": "2018-19", "proposal_version": 1,
			"entries": {"chn_club_beijing": {
				"status": "confirmed", "requested_levels": ["junior"],
				"route": "club_nomination", "funding_source": "club",
				"coach_recommendation": "建议参赛", "player_override": "enter",
				"available_adjustment_ids": ["enter", "skip"],
				"eligibility_snapshot": {"eligible": true, "hard_gate_codes": [], "warnings": []},
				"reason_codes": ["development_value"],
			}},
		},
		"qualification_state": {"cfsa_registered": true, "club_final_top_six": false},
		"event_statuses": {"chn_club_beijing": "confirmed"},
	}

func _delete_file(path: String) -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func _clear_save_family(path: String) -> void:
	_delete_file(path)
	_delete_file("%s.tmp" % path)
	_delete_file("%s.bak" % path)

func _assert_history_equal(actual: Array, expected: Array) -> void:
	TestSupport.assert_equal(actual.size(), expected.size())
	for index in actual.size():
		for field in ["category", "target", "delta", "cause_codes", "summary_key"]:
			if field == "delta":
				TestSupport.assert_equal(is_equal_approx(float(actual[index][field]), float(expected[index][field])), true)
			else:
				TestSupport.assert_equal(actual[index][field], expected[index][field])
