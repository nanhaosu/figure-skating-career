extends RefCounted
const T = preload("res://tests/test_support.gd")
const C = preload("res://src/content/season_calendar_repository.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const R = preload("res://src/simulation/competition_ranking_service.gd")
const P = preload("res://src/simulation/personal_record_service.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2021 senior Grand Prix has six held stages including actual Italy replacement","callable":test_stages},
		{"name":"Beijing individual and Tallinn4CC use actual women segment dates","callable":test_championships},
		{"name":"all playable2021 senior events resolve senior rules and no domestic bonus","callable":test_rules},
		{"name":"2020 senior calendar keeps actual held dates and canceled events separate","callable":test_2020_calendar},
		{"name":"2020 pandemic GP settlement awards neither world points nor international records","callable":test_2020_settlement},
		{"name":"2020 pandemic GP content rejects normal international score permissions","callable":test_2020_invalid_permissions},
	]

func _calendar() -> Dictionary:
	var loaded = C.load_international_calendar(2021,"women_singles","senior")
	T.assert_equal(loaded.errors,[])
	return loaded.calendar

func test_stages() -> void:
	var data = _calendar()
	if data.is_empty():return
	var stages = C.playable_events(data).filter(func(e):return e.event_family == "gp_stage")
	T.assert_equal(stages.size(),6)
	T.assert_equal(stages.map(func(e):return e.segment_dates),[
		{"short":"2021-10-23","free":"2021-10-24"},{"short":"2021-10-29","free":"2021-10-30"},
		{"short":"2021-11-05","free":"2021-11-06"},{"short":"2021-11-12","free":"2021-11-13"},
		{"short":"2021-11-19","free":"2021-11-20"},{"short":"2021-11-26","free":"2021-11-27"}])
	T.assert_equal(stages[2].location,"Torino / ITA","Do not keep a canceled China stop alongside its Italy replacement")
	T.assert_equal(C.playable_events(data).any(func(e):return e.event_family == "gp_final"),false)
	var final_event = data.events.filter(func(e):return e.event_family == "gp_final")
	T.assert_equal(final_event.size(),1)
	if not final_event.is_empty():T.assert_equal(final_event[0].status,"cancelled")

func test_championships() -> void:
	var data = _calendar()
	if data.is_empty():return
	for row in [["four_continents","2022-01-20","2022-01-22"],["olympic_games","2022-02-15","2022-02-17"],["world_championships","2022-03-23","2022-03-25"]]:
		var events = C.playable_events(data).filter(func(e):return e.event_family == row[0])
		T.assert_equal(events.size(),1)
		if events.is_empty():return
		T.assert_equal(events[0].segment_dates,{"short":row[1],"free":row[2]})
		T.assert_equal(events[0].level_options,["senior"])

func test_rules() -> void:
	var data = _calendar()
	if data.is_empty():return
	for event in C.playable_events(data):
		var resolved = B.rules_for_event_level(event,"free","women_singles","senior")
		T.assert_equal(resolved.errors,[])
		if not resolved.errors.is_empty():return
		T.assert_equal(resolved.rules.element_max,12.0)
		T.assert_equal(resolved.scoring.domestic_bonus,{})
		T.assert_equal(B.rules_for_event_level(event,"short","women_singles","junior").errors.is_empty(),false)

func _calendar_2020() -> Dictionary:
	var loaded = C.load_international_calendar(2020,"women_singles","senior")
	T.assert_equal(loaded.errors,[])
	return loaded.calendar

func test_2020_calendar() -> void:
	var data = _calendar_2020()
	if data.is_empty():return
	var held = C.playable_events(data)
	T.assert_equal(held.size(),5)
	T.assert_equal(held.map(func(e):return e.segment_dates),[
		{"short":"2020-10-23","free":"2020-10-24"},
		{"short":"2020-11-06","free":"2020-11-07"},
		{"short":"2020-11-20","free":"2020-11-21"},
		{"short":"2020-11-27","free":"2020-11-28"},
		{"short":"2021-03-24","free":"2021-03-26"}])
	var cancelled = data.events.filter(func(e):return e.status == "cancelled")
	T.assert_equal(cancelled.size(),4)
	T.assert_equal(cancelled.map(func(e):return e.cancellation.announced_on),["2020-10-14","2020-10-19","2020-12-10","2020-10-20"])
	for event in cancelled:
		T.assert_equal(B.rules_for_event_level(event,"short","women_singles","senior").errors.is_empty(),false)

func test_2020_settlement() -> void:
	var data = _calendar_2020()
	if data.is_empty():return
	for event in C.playable_events(data):
		if event.event_family != "gp_stage":continue
		T.assert_equal(event.ranking_points_system,"none")
		T.assert_equal(event.record_eligibility,"domestic_only")
		var resolved = B.rules_for_event_level(event,"free","women_singles","senior")
		T.assert_equal(resolved.errors,[])
		if not resolved.errors.is_empty():return
		T.assert_equal(resolved.scoring.domestic_bonus,{})
		var result = {"final_rank":1,"qualified":true,"short_score":80.0,"free_score":160.0,"total_score":240.0}
		var archive = {"season_id":"2020-21","event_id":event.event_id,"event":event,"record_eligibility":event.record_eligibility,"scoring_era_id":"isu_iqs_2018_plus","player_result":result}
		var ranking = R.preview({},archive,result)
		T.assert_equal(ranking.isu_world.points,0)
		T.assert_equal(ranking.domestic_points,0)
		T.assert_equal(ranking.jgp_seasons["2020-21"],0)
		T.assert_equal(R.preview(ranking,archive,result),ranking,"Closing/reopening cannot award again")
		var records = P.preview({},archive)
		T.assert_equal(records.next_record_book.international,{})
		T.assert_equal(records.next_record_book.all_formal.isu_iqs_2018_plus.total.pb,240.0)

func test_2020_invalid_permissions() -> void:
	var data = _calendar_2020()
	if data.is_empty():return
	for defect in ["points","records","tes","missing_policy","missing_source","world_flag","normal_invitation","missing_host","bad_host"]:
		var changed = data.duplicate(true)
		match defect:
			"points":changed.events[0].ranking_points_system = "isu_world_standings"
			"records":changed.events[0].record_eligibility = "isu_recognized"
			"tes":changed.events[0].pandemic_policy.international_minimum_tes_eligible = true
			"missing_policy":changed.events[0].erase("pandemic_policy")
			"missing_source":changed.events[0].pandemic_policy.source_id = "unknown"
			"world_flag":changed.events[0].pandemic_policy.world_standing_points_eligible = true
			"normal_invitation":changed.events[0].pandemic_policy.entry_policy = "normal_gp"
			"missing_host":changed.events[0].erase("host_federation")
			"bad_host":changed.events[0].host_federation = "invalid"
		T.assert_equal(C.validate(changed).is_empty(),false,defect)
