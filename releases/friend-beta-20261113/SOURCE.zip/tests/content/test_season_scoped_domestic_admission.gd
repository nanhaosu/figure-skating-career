extends RefCounted
const T = preload("res://tests/test_support.gd")
const C = preload("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2021 junior admission accepts sourced approval routes without inventing2018 exemptions","callable":test_approval},
		{"name":"new junior admission rejects unlinked evidence and disguised unknown TES","callable":test_invalid},
		{"name":"approved domestic fallback cannot waive international TES or verified thresholds","callable":test_fallback_bounds},
	]

func _calendar() -> Dictionary:
	var calendar = C.load_calendar(2018,"CHN","women_singles").calendar.duplicate(true)
	var event = calendar.events.filter(func(e):return e.event_family == "national_junior")[0]
	calendar.events = [event]
	calendar.sources.append({"source_id":"youth2021_rules","title":"2021 junior championships rules pp1–3","url":"https://www.cfsa.com.cn/ueditor/jsp/upload/file/20211101/1635762203255069258.pdf","retrieved_on":"2026-10-21"})
	event.sources.append("youth2021_rules")
	event.ruleset_season_start_year = 2021
	event.formal_scoring_catalog = "2021_2022_women_singles_scoring"
	event.admission_policy = {
		"source_id":"youth2021_rules","min_grade":7,"grade_categories":["steps_performance","free_skating"],
		"birth_date_range":{"start":"2002-07-01","end":"2008-06-30"},
		"minimum_tes":{"status":"unknown","designated_events_only":true,"short":null,"free":null},
		"explicit_exemptions":[],"review_routes":{"HKG":["federation_review"],"MAC":["federation_review"],"TPE":["federation_review"],"overseas_chinese":["federation_review"],"elite_preparation":["federation_review"]}
	}
	return calendar

func test_approval() -> void:
	var data = _calendar()
	T.assert_equal(C.validate(data),[],"2021 original rules require approval, not inherited automatic regional grade exemptions")
	T.assert_equal(data.events[0].admission_policy.minimum_tes.short,null,"No numeric TES may be invented from the phrase minimum technical score")

func test_invalid() -> void:
	for defect in ["source","grade","birth","tes","route"]:
		var data = _calendar()
		var policy = data.events[0].admission_policy
		match defect:
			"source":policy.source_id = "absent"
			"grade":policy.min_grade = 0
			"birth":policy.birth_date_range.end = "2008-02-30"
			"tes":policy.minimum_tes.short = 23.0
			"route":policy.review_routes.HKG = ["automatic"]
		T.assert_equal(C.validate(data).is_empty(),false,defect+" must not be silently accepted as a verified entry policy")

func test_fallback_bounds() -> void:
	var data = _calendar()
	data.events[0].admission_policy.minimum_tes.game_fallback = {"policy":"verified_domestic_requirements_only","label":"游戏兜底规则","approved_on":"2026-10-21","basis":"explicit_user_approval"}
	T.assert_equal(C.validate(data),[])
	for defect in ["international","verified","unapproved","hidden"]:
		var copy = data.duplicate(true)
		var tes = copy.events[0].admission_policy.minimum_tes
		match defect:
			"international":copy.events[0].scope = "international"
			"verified":tes.status = "verified";tes.short = 23.0;tes.free = 38.0
			"unapproved":tes.game_fallback.basis = "assumed"
			"hidden":tes.game_fallback.label = "official rule"
		T.assert_equal(C.validate(copy).is_empty(),false,defect+" fallback must reject rather than weaken independent qualification")
