extends RefCounted
const T = preload("res://tests/test_support.gd")
const R = preload("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2021 junior circuit loads seven actual JGP venues without Canadian duplicate","callable":test_stages},
		{"name":"cancelled 2021 final is retained but never offered for competition","callable":test_final},
		{"name":"2022 world junior uses actual Tallinn April dates not earlier Sofia schedule","callable":test_world},
	]

func _calendar() -> Dictionary:
	var loaded = R.load_international_calendar(2021,"women_singles","junior")
	T.assert_equal(loaded.errors,[])
	return loaded.calendar

func test_stages() -> void:
	var data = _calendar(); if data.is_empty(): return
	var stages = R.playable_events(data).filter(func(event): return event.event_family == "jgp_stage")
	T.assert_equal(stages.size(),7)
	var expected = [["Courchevel / FRA","2021-08-18","2021-08-21"],["Courchevel / FRA","2021-08-25","2021-08-28"],["Kosice / SVK","2021-09-01","2021-09-04"],["Krasnoyarsk / RUS","2021-09-15","2021-09-18"],["Ljubljana / SLO","2021-09-22","2021-09-25"],["Gdansk / POL","2021-09-29","2021-10-02"],["Linz / AUT","2021-10-06","2021-10-09"]]
	for i in stages.size():
		T.assert_equal([stages[i].location,stages[i].start_date,stages[i].end_date],expected[i])
		T.assert_equal(stages[i].ruleset_season_start_year,2021)
		T.assert_equal(stages[i].level_options,["junior"])

func test_final() -> void:
	var data = _calendar(); if data.is_empty(): return
	var finals = R.ordered_events(data).filter(func(event): return event.event_family == "jgp_final")
	T.assert_equal(finals.size(),1)
	T.assert_equal(finals[0].status,"cancelled")
	T.assert_equal(R.playable_events(data).any(func(event): return event.event_family == "jgp_final"),false)

func test_world() -> void:
	var data = _calendar(); if data.is_empty(): return
	var worlds = R.playable_events(data).filter(func(event): return event.event_family == "world_junior")
	T.assert_equal(worlds.size(),1)
	T.assert_equal([worlds[0].location,worlds[0].start_date,worlds[0].end_date],["Tallinn / EST","2022-04-13","2022-04-17"])
	T.assert_equal(worlds[0].segment_dates,{"short":"2022-04-16","free":"2022-04-17"})
