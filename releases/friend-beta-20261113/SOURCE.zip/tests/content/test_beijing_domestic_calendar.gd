extends RefCounted
const T = preload("res://tests/test_support.gd")
const C = preload("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2021 domestic catalog contains three online stages one final and separate national GP","callable":test_calendar},
		{"name":"online game dates stay explicitly labeled inside linked published windows","callable":test_windows},
		{"name":"2021 cancelled nationals never become a playable scoring event","callable":test_cancelled},
		{"name":"new game schedules reject missing out of window or unlinked timing evidence","callable":test_invalid_windows},
		{"name":"2021 U2 junior route remains available on verified December online broadcast date","callable":test_junior_route},
	]

func _calendar() -> Dictionary:
	var loaded = C.load_calendar(2021,"CHN","women_singles")
	T.assert_equal(loaded.errors,[])
	return loaded.calendar

func test_calendar() -> void:
	var data = _calendar()
	if data.is_empty(): return
	T.assert_equal(data.events.filter(func(e):return e.event_family == "club_league_stage").size(),3)
	T.assert_equal(data.events.filter(func(e):return e.event_family == "club_league_final").size(),1)
	var gp = data.events.filter(func(e):return e.event_family == "national_grand_prix")
	T.assert_equal(gp.size(),1)
	if gp.is_empty():return
	T.assert_equal(gp[0].level_options,["junior","senior"])
	T.assert_equal(data.series_rules.club.final_selection,"highest_complete_total_top_six","Club final qualification is not a copy of Olympic best4 or ordinary assignment best2")

func test_windows() -> void:
	var data = _calendar()
	if data.is_empty():return
	var online_events: Array = C.playable_events(data).filter(func(event):return event.event_family != "beijing_trial")
	T.assert_equal(online_events.size(),6,"Do not omit a verified online event when separating the five trial races")
	for event in online_events:
		T.assert_equal(event.date_precision,"game_schedule")
		T.assert_equal(str(event.name).contains("游戏赛期"),true)
		T.assert_equal(event.game_schedule_window.start <= event.start_date,true)
		T.assert_equal(event.end_date <= event.game_schedule_window.end,true)
		T.assert_equal(C.judging_panel_size(event),5)
		T.assert_equal(event.scope,"domestic")
		T.assert_equal(event.record_eligibility,"domestic_only")

func test_cancelled() -> void:
	var data = _calendar()
	if data.is_empty():return
	var cancelled = data.events.filter(func(e):return e.event_id == "cn_national_championships_2021")
	T.assert_equal(cancelled.size(),1)
	if cancelled.is_empty():return
	T.assert_equal(cancelled[0].status,"cancelled")
	T.assert_equal(cancelled[0].cancellation.announced_on,"2022-05-06")
	T.assert_equal(cancelled[0].record_eligibility,"none")
	T.assert_equal(C.playable_events(data).any(func(e):return e.event_id == "cn_national_championships_2021"),false)

func test_invalid_windows() -> void:
	var data = C.load_calendar(2019,"CHN","women_singles").calendar.duplicate(true)
	data.events = [data.events[0]]
	data.events[0].ruleset_season_start_year = 2021
	data.events[0].date_precision = "game_schedule"
	data.events[0].start_date = "2021-08-10"
	data.events[0].end_date = "2021-08-11"
	data.events[0].game_schedule_window = {"start":"2021-08-09","end":"2021-08-14","source_ids":[data.events[0].sources[0]]}
	T.assert_equal(C.validate(data),[])
	for defect in ["missing","early","late","bad_date","source"]:
		var copy = data.duplicate(true)
		var event = copy.events[0]
		match defect:
			"missing":event.erase("game_schedule_window")
			"early":event.start_date = "2021-08-01"
			"late":event.end_date = "2021-08-30"
			"bad_date":event.game_schedule_window.start = "2021-02-30"
			"source":event.game_schedule_window.source_ids = ["not_linked"]
		T.assert_equal(C.validate(copy).is_empty(),false,defect+" invalid game schedule must reject")

func test_junior_route() -> void:
	var data = _calendar()
	if data.is_empty():return
	var events = C.playable_events(data).filter(func(e):return e.event_family == "national_junior")
	T.assert_equal(events.size(),1,"Junior domestic route must not disappear when senior events are added")
	if events.is_empty():return
	var event = events[0]
	T.assert_equal(event.start_date,"2021-12-18")
	T.assert_equal(event.end_date,"2021-12-18")
	T.assert_equal(event.level_options,["junior"])
	T.assert_equal(C.judging_panel_size(event),5)
	T.assert_equal(event.admission_policy.min_grade,7.0)
	T.assert_equal(event.admission_policy.explicit_exemptions,[])
	T.assert_equal(event.admission_policy.review_routes.HKG,["federation_review"])
	T.assert_equal(event.admission_policy.minimum_tes.has("game_fallback"),true,"Explicitly approved fallback must be retained for the eligibility consumer")
	if not event.admission_policy.minimum_tes.has("game_fallback"):return
	T.assert_equal(event.admission_policy.minimum_tes.game_fallback.policy,"verified_domestic_requirements_only")
	T.assert_equal(event.admission_policy.minimum_tes.game_fallback.label,"游戏兜底规则")
	T.assert_equal(event.record_eligibility,"domestic_only","Online domestic results do not become Olympic internationalTES")
