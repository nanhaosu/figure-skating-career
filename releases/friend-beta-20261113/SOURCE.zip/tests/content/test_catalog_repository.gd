extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "2014 CN catalog has required choices", "callable": test_required_choices},
		{"name": "invalid catalog reports exact field", "callable": test_invalid_catalog},
		{"name": "invalid relationship reference reports its exact field", "callable": test_invalid_relationship_reference},
		{"name": "too few entry paths report the collection path", "callable": test_too_few_entry_paths},
		{"name": "too many entry paths report the collection path", "callable": test_too_many_entry_paths},
		{"name": "too few family profiles report the collection path", "callable": test_too_few_family_profiles},
		{"name": "too many family profiles report the collection path", "callable": test_too_many_family_profiles},
	]

func test_required_choices() -> void:
	var result := CatalogRepository.load_catalog()
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.backgrounds.entry_paths.has("entry_interest_class"), true)
	TestSupport.assert_equal(result.backgrounds.family_profiles.has("family_supportive"), true)
	TestSupport.assert_equal(result.training.categories.size(), 10)
	TestSupport.assert_equal(result.training.categories.jump_lutz.target, "jump:lutz")
	TestSupport.assert_equal(result.event_phrases.locations.size() >= 3, true)
	TestSupport.assert_equal(result.event_phrases.fragments.has("jump_load_conflict"), true)

func test_invalid_catalog() -> void:
	var errors := CatalogRepository.validate_backgrounds({"entry_paths": {}})
	TestSupport.assert_equal(errors.has("backgrounds.family_profiles must be a non-empty Dictionary"), true)

func test_invalid_relationship_reference() -> void:
	var backgrounds := {
		"entry_paths": {"entry": {"name": "入口", "description": "描述", "technique_delta": 1, "resource_delta": 1, "starting_relationship_id": "missing"}},
		"family_profiles": {"family": {"name": "家庭", "description": "描述", "economic_capacity": 1, "control": 1, "health_priority": 1, "emotional_support": 1, "industry_knowledge": 1}},
	}
	var errors := CatalogRepository.validate_backgrounds(backgrounds)
	TestSupport.assert_equal(errors.has("backgrounds.entry_paths.entry.starting_relationship_id references unknown family profile missing"), true)

func test_too_few_entry_paths() -> void:
	var backgrounds: Dictionary = CatalogRepository.load_catalog().backgrounds.duplicate(true)
	backgrounds.entry_paths.erase("entry_transfer_sport")
	var errors := CatalogRepository.validate_backgrounds(backgrounds)
	TestSupport.assert_equal(errors.has("backgrounds.entry_paths must contain exactly 5 entries, got 4"), true)

func test_too_many_entry_paths() -> void:
	var backgrounds: Dictionary = CatalogRepository.load_catalog().backgrounds.duplicate(true)
	backgrounds.entry_paths["entry_extra"] = backgrounds.entry_paths.entry_interest_class.duplicate(true)
	var errors := CatalogRepository.validate_backgrounds(backgrounds)
	TestSupport.assert_equal(errors.has("backgrounds.entry_paths must contain exactly 5 entries, got 6"), true)

func test_too_few_family_profiles() -> void:
	var backgrounds: Dictionary = CatalogRepository.load_catalog().backgrounds.duplicate(true)
	backgrounds.family_profiles.erase("family_resource_limited")
	var errors := CatalogRepository.validate_backgrounds(backgrounds)
	TestSupport.assert_equal(errors.has("backgrounds.family_profiles must contain exactly 4 entries, got 3"), true)

func test_too_many_family_profiles() -> void:
	var backgrounds: Dictionary = CatalogRepository.load_catalog().backgrounds.duplicate(true)
	backgrounds.family_profiles["family_extra"] = backgrounds.family_profiles.family_supportive.duplicate(true)
	var errors := CatalogRepository.validate_backgrounds(backgrounds)
	TestSupport.assert_equal(errors.has("backgrounds.family_profiles must contain exactly 4 entries, got 5"), true)
