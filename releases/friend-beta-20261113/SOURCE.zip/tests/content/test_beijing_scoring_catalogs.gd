extends RefCounted
const T = preload("res://tests/test_support.gd")
const S = preload("res://src/content/formal_scoring_repository.gd")
const P = preload("res://src/simulation/formal_technical_panel.gd")
const J = preload("res://src/simulation/formal_judging_panel.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"both Beijing era catalogs score sit spins at all published levels","callable":test_sit_values},
		{"name":"Beijing era wrong edge uses80 percent and combined edge underrotation60 percent","callable":test_edges},
		{"name":"new domestic GP never inherits old unsourced triple combination bonuses","callable":test_bonus},
		{"name":"new catalog cannot accept incomplete alternative spin values or unexplained bonus policy","callable":test_invalid},
		{"name":"new era basic combination spin receives actual2253 value rather than inherited1.50","callable":test_basic_combination_spin},
	]

func _catalog(year:int) -> Dictionary:
	var loaded = S.load_catalog(year,"women_singles")
	T.assert_equal(loaded.errors,[])
	return loaded.catalog

func test_sit_values() -> void:
	for year in [2020,2021]:
		var rules = _catalog(year)
		if rules.is_empty():return
		for row in [[0,1.10],[1,1.30],[2,1.60],[3,2.10],[4,2.50]]:
			var result = P.resolve({"elements":[{"element_id":"sit","kind":"spin","abbreviation":"SSp","facts":{"element_code":"SSp","credited_features":row[0]}}]},rules,{}, {},10)
			T.assert_equal(result.final_elements[0].base_value,row[1],"ISU2253 member federation translation table p3")

func test_edges() -> void:
	for year in [2020,2021]:
		var rules = _catalog(year)
		if rules.is_empty():return
		for row in [[0.0,4.72],[0.35,3.54]]:
			var element = {"element_id":"lz","kind":"jump","abbreviation":"3Lz","facts":{"planned_rotations":3,"missing_rotation_turns":row[0],"edge_quality":0.0}}
			var result = P.resolve({"elements":[element]},rules,{}, {},10)
			T.assert_equal(is_equal_approx(float(result.final_elements[0].base_value),row[1]),true,"2253 3Lze=4.72;3Lz<e=3.54, not legacy75 percent")

func test_bonus() -> void:
	for year in [2020,2021]:
		var rules = _catalog(year)
		if rules.is_empty():return
		var first = {"element_id":"lz","kind":"jump","abbreviation":"3Lz","facts":{"planned_rotations":3,"missing_rotation_turns":0.0,"edge_quality":100.0,"landing_quality":90.0}}
		var second = {"element_id":"t","kind":"jump","abbreviation":"3T","facts":{"planned_rotations":3,"missing_rotation_turns":0.0,"edge_quality":100.0,"landing_quality":90.0}}
		var performance = {"segment":"short","elements":[{"element_id":"combo","kind":"jump","parts":[first,second]}]}
		var review = P.resolve(performance,rules,{}, {},10)
		var judges:Array = []
		for i in 9: judges.append({"judge_id":"J%d" % i,"consistency":1.0,"technical_bias":0.0,"affinity":0.0,"pcs_bias":0.0})
		var score = J.score(performance,review,{},rules,judges,10)
		T.assert_equal(score.errors,[])
		T.assert_equal(score.domestic_bonus,0.0,"Actual2021 domestic GP total is TES+PCS minus deductions; no2018 bonus automatically carried")
		T.assert_equal(score.total,snappedf(score.tes+score.pcs-score.deductions,0.01))

func test_invalid() -> void:
	var rules = _catalog(2020)
	if rules.is_empty():return
	for defect in ["sit","camel","bonus"]:
		var copy = rules.duplicate(true)
		match defect:
			"sit":copy.non_jump_base_values.SSp.erase("1")
			"camel":copy.non_jump_base_values.erase("CSp")
			"bonus":copy.domestic_bonus.policy = "invented"
		T.assert_equal(S.validate(copy).is_empty(),false,defect+" missing historical scoring contract must reject")

func test_basic_combination_spin() -> void:
	for year in [2020,2021]:
		var rules = _catalog(year)
		if rules.is_empty():return
		var result = P.resolve({"elements":[{"element_id":"combo_spin","kind":"spin","abbreviation":"CCoSp","facts":{"element_code":"CCoSp","credited_features":0}}]},rules,{}, {},10)
		T.assert_equal(result.final_elements[0].base_value,1.70,"2253 member federation table p5 CCoSpB1.70; legacy2019 remains unchanged")
