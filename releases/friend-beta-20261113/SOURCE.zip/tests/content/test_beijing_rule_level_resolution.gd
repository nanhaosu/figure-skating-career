extends RefCounted
const T = preload("res://tests/test_support.gd")
var B = load("res://src/content/season_bundle_repository.gd")
const H = preload("res://src/content/historical_rule_repository.gd")
const C = preload("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"explicit senior free resolves choreography without junior fallback","callable":test_senior},
		{"name":"event cannot be resolved for an unoffered or unknown level","callable":test_unoffered},
		{"name":"international explicit rule resolution strips domestic bonuses","callable":test_international},
		{"name":"cancelled event cannot resolve executable competition rules","callable":test_cancelled},
		{"name":"invalid senior segments cannot pass a junior only validator","callable":test_senior_validation},
		{"name":"competition event honors explicit offered senior level","callable":test_competition_level},
		{"name":"competition event rejects explicit unknown level instead of junior fallback","callable":test_bad_competition_level},
		{"name":"merged calendars preserve exceptional series policies without sharing mutable data","callable":test_series_merge},
		{"name":"conflicting series policies reject the whole merge rather than silently selecting one","callable":test_series_conflict},
		{"name":"conflicting qualification definitions reject the whole merge","callable":test_qualification_conflict},
		{"name":"mixed future calendar audits offered junior and senior groups without executing canceled events","callable":test_mixed_calendar_audit},
		{"name":"mixed calendar audit rejects unsupported offered groups rather than skipping them","callable":test_bad_calendar_group},
		{"name":"implicit senior international lookup finds its canonical calendar without trusting requested levels","callable":test_implicit_senior_calendar},
	]

func _ready() -> bool:
	var ready = B.get_script_method_list().any(func(method): return method.name == "rules_for_event_level")
	T.assert_equal(ready,true,"Explicit event level API missing")
	return ready

func _event() -> Dictionary:
	return {"event_id":"fixture","scope":"international","level_options":["junior","senior"],"ruleset_season_start_year":2019,"formal_scoring_catalog":"2019_2020_women_singles_scoring"}

func test_senior() -> void:
	if not _ready(): return
	var senior = B.rules_for_event_level(_event(),"free","women_singles","senior")
	var junior = B.rules_for_event_level(_event(),"free","women_singles","junior")
	T.assert_equal(senior.errors,[])
	T.assert_equal(junior.errors,[])
	T.assert_equal(senior.rules.level,"senior")
	T.assert_equal(senior.rules.choreographic_min,1)
	T.assert_equal(junior.rules.choreographic_min,0)

func test_unoffered() -> void:
	if not _ready(): return
	var event = _event()
	event.level_options = ["junior"]
	for level in ["senior","nonsense",""]:
		var result = B.rules_for_event_level(event,"short","women_singles",level)
		T.assert_equal(result.errors.is_empty(),false)
		T.assert_equal(result.rules,{})

func test_international() -> void:
	if not _ready(): return
	var result = B.rules_for_event_level(_event(),"short","women_singles","senior")
	T.assert_equal(result.scoring.domestic_bonus,{})

func test_cancelled() -> void:
	if not _ready(): return
	var event = _event()
	event.status = "cancelled"
	T.assert_equal(B.rules_for_event_level(event,"short","women_singles","senior").errors.is_empty(),false)

func test_senior_validation() -> void:
	var data = H.load_season(2019,"women_singles").rules.duplicate(true)
	data.levels.senior.segments.free.element_max = 1
	T.assert_equal(H.validate(data).is_empty(),false,"Broken adult rules must not pass junior-only validation")

func test_competition_level() -> void:
	var bundle = B.load_bundle(2019,"women_singles","junior")
	var event:Dictionary = bundle.calendar.events.filter(func(item): return item.event_id == "cn_club_league_2019_stage_1")[0].duplicate(true)
	event.competition_level = "senior"
	var result = B.competition_event(event)
	T.assert_equal(result.errors,[])
	T.assert_equal(result.rules.free.segment_rules.level,"senior")
	T.assert_equal(result.rules.free.segment_rules.choreographic_min,1)

func test_bad_competition_level() -> void:
	var bundle = B.load_bundle(2019,"women_singles","junior")
	var event:Dictionary = bundle.calendar.events.filter(func(item): return item.event_family == "jgp_stage")[0].duplicate(true)
	for level in ["senior","unknown"]:
		event.competition_level = level
		T.assert_equal(B.competition_event(event).errors.is_empty(),false,"Explicit unoffered group must reject")

func _calendars() -> Array:
	var calendar = load("res://src/content/season_calendar_repository.gd")
	return [calendar.load_calendar(2019,"CHN","women_singles").calendar,calendar.load_international_calendar(2019,"women_singles","junior").calendar]

func test_series_merge() -> void:
	var inputs = _calendars()
	inputs[0].series_rules = {"domestic":{"best_results":2}}
	inputs[1].series_rules = {"jgp":{"qualification":"winners_then_placement_score","quota_basis":2020}}
	var merged = B._merge_calendars(inputs[0],inputs[1])
	T.assert_equal(merged.errors,[])
	T.assert_equal(merged.calendar.get("series_rules"),{"domestic":{"best_results":2},"jgp":{"qualification":"winners_then_placement_score","quota_basis":2020}},"Exception must survive the exact merge used by bundles")
	if not merged.calendar.has("series_rules"): return
	merged.calendar.series_rules.jgp.quota_basis = 9999
	T.assert_equal(inputs[1].series_rules.jgp.quota_basis,2020,"A consumer cannot mutate source policy")
	inputs[0].series_rules = inputs[1].series_rules.duplicate(true)
	T.assert_equal(B._merge_calendars(inputs[0],inputs[1]).errors,[],"Identical policy IDs are safe to deduplicate")

func test_series_conflict() -> void:
	var inputs = _calendars()
	inputs[0].series_rules = {"jgp":{"qualification":"ordinary_points"}}
	inputs[1].series_rules = {"jgp":{"qualification":"winners_then_placement_score"}}
	var merged = B._merge_calendars(inputs[0],inputs[1])
	T.assert_equal(merged.errors.is_empty(),false,"Contradictory policies must not disappear in merge")
	T.assert_equal(merged.calendar,{})

func test_qualification_conflict() -> void:
	var inputs = _calendars()
	inputs[0].qualification_definitions["shared_admission"] = {"min_grade":7}
	inputs[1].qualification_definitions["shared_admission"] = {"min_grade":8}
	var merged = B._merge_calendars(inputs[0],inputs[1])
	T.assert_equal(merged.errors.is_empty(),false,"Admission conflict cannot silently inherit domestic definition")
	T.assert_equal(merged.calendar,{})

func _audit_ready() -> bool:
	var ready = B.get_script_method_list().any(func(method):return method.name == "_calendar_rule_errors")
	T.assert_equal(ready,true,"Bundle must audit actual offered groups and only executable events")
	return ready

func test_mixed_calendar_audit() -> void:
	if not _audit_ready():return
	var junior = C.load_international_calendar(2021,"women_singles","junior")
	var senior = C.load_international_calendar(2021,"women_singles","senior")
	var domestic = C.load_calendar(2021,"CHN","women_singles")
	for loaded in [junior,senior,domestic]:T.assert_equal(loaded.errors,[])
	if not junior.errors.is_empty() or not senior.errors.is_empty() or not domestic.errors.is_empty():return
	# Includes canceled GPF/nationals and junior-only U2 alongside mixed domestic GP.
	var mixed = {"events":junior.calendar.events + senior.calendar.events + domestic.calendar.events}
	var before = mixed.duplicate(true)
	T.assert_equal(B.call("_calendar_rule_errors",mixed,"women_singles"),[])
	T.assert_equal(mixed,before,"Audit must never modify the source/legacy archive")

func test_bad_calendar_group() -> void:
	if not _audit_ready():return
	var event = _event()
	event.level_options = ["junior","unknown"]
	T.assert_equal(B.call("_calendar_rule_errors",{"events":[event]},"women_singles").is_empty(),false)
	event.level_options = []
	T.assert_equal(B.call("_calendar_rule_errors",{"events":[event]},"women_singles").is_empty(),false)

func test_implicit_senior_calendar() -> void:
	var loaded = C.load_international_calendar(2021,"women_singles","senior")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	var event = C.playable_events(loaded.calendar).filter(func(e):return e.event_family=="gp_stage")[0]
	var resolved = B.competition_event(event)
	T.assert_equal(resolved.errors,[],"A senior-only international event cannot be lost in the junior-only calendar")
	if not resolved.errors.is_empty():return
	T.assert_equal(resolved.event.competition_level,"senior")
	T.assert_equal(resolved.rules.free.segment_rules.duration_seconds,240)
	var wrong = event.duplicate(true)
	wrong.competition_level="junior"
	T.assert_equal(B.competition_event(wrong).errors.is_empty(),false)
	var junior = C.load_international_calendar(2021,"women_singles","junior").calendar.events[0].duplicate(true)
	junior.level_options=["senior"]
	var canonical = B.competition_event(junior)
	T.assert_equal(canonical.errors,[])
	if canonical.errors.is_empty():T.assert_equal(canonical.event.competition_level,"junior","Requested level_options cannot promote a canonical junior event")
