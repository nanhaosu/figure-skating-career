extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const MusicSelection = preload("res://src/domain/music_selection.gd")
const MusicCatalogRepository = preload("res://src/content/music_catalog_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "music catalog offers broad skating staples without audio", "callable": test_catalog},
		{"name": "custom music round trips without catalog id", "callable": test_custom_round_trip},
		{"name": "music source must be built in or custom", "callable": test_source_validation},
	]

func test_catalog() -> void:
	var catalog := MusicCatalogRepository.load_catalog()
	TestSupport.assert_equal(catalog.errors, [])
	TestSupport.assert_equal(catalog.works.size() >= 25, true)
	for required_id in ["carmen", "swan_lake", "bolero", "scheherazade", "romeo_juliet_prokofiev", "phantom_opera"]:
		TestSupport.assert_equal(catalog.by_id.has(required_id), true)
	for work in catalog.works:
		TestSupport.assert_equal(str(work.audio_path), "")
		TestSupport.assert_equal(str(work.recording_license), "not_bundled")

func test_custom_round_trip() -> void:
	var result := MusicSelection.create("custom", "", "我的自选曲", "未知作者", "比赛剪辑", ["抒情", "渐强"])
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(MusicSelection.from_dict(result.music.to_dict()).to_dict(), result.music.to_dict())

func test_source_validation() -> void:
	var result := MusicSelection.create("streaming", "", "测试", "作者", "", [])
	TestSupport.assert_equal(result.music, null)
	TestSupport.assert_equal(result.errors, ["未知曲目来源：streaming"])
