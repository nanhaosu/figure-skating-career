extends RefCounted
const T = preload("res://tests/test_support.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const C = preload("res://src/content/season_calendar_repository.gd")
const J = preload("res://src/content/judging_profile_repository.gd")

# Acceptance gate for complete content, not proof of promotion/selection gameplay.
func cases() -> Array[Dictionary]:
	return [
		{"name":"2020 junior complete content bundle is usable without replaying canceled JGP","callable":func():_check_bundle(2020,"junior")},
		{"name":"2020 senior complete content bundle preserves pandemic restrictions","callable":func():_check_bundle(2020,"senior")},
		{"name":"2021 junior complete content bundle includes domestic U2 and international route","callable":func():_check_bundle(2021,"junior")},
		{"name":"2021 senior complete content bundle resolves complete calendar and judging pools","callable":func():_check_bundle(2021,"senior")},
	]

func _check_bundle(year:int,level:String) -> void:
	var loaded = B.load_bundle(year,"women_singles",level)
	T.assert_equal(loaded.errors,[],"Incomplete Beijing content must not earn a release certificate: %s" % str(loaded.errors))
	if not loaded.errors.is_empty():return
	T.assert_equal(loaded.calendar.is_empty(),false)
	T.assert_equal(loaded.federation_profiles.is_empty(),false)
	for event in C.playable_events(loaded.calendar):
		if event.get("panel_verification",{}).get("status","verified")!="verified":
			#2026-10-22 explicit user exception: historical count stays unknown,
			# but a visible narrowly approved7-person simulation can execute.
			T.assert_equal(event.event_id,"isu_gpchn2020")
			T.assert_equal(event.get("judge_count_game_policy",{}).get("user_approved"),true)
			T.assert_equal(C.judging_panel_size(event),7)
			T.assert_equal(str(event.get("gameplay_note","")).contains("历史人数未核实"),true)
		for offered_level in event.level_options:
			for segment in ["short","free"]:
				var rules = B.rules_for_event_level(event,segment,"women_singles",offered_level)
				T.assert_equal(rules.errors,[])
				if not rules.errors.is_empty():return
				if event.scope == "international":T.assert_equal(rules.scoring.domestic_bonus,{})
		T.assert_equal(J.panel(event,73).size(),C.judging_panel_size(event),"Missing seasonal judging profiles cannot yield an empty panel")
		T.assert_equal(loaded.scoring.event_policies.has(event.event_family),true,"Every playable family needs an actual competition policy")
