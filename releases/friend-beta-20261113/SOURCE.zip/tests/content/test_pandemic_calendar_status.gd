extends RefCounted
const T = preload("res://tests/test_support.gd")
var R = load("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"legacy calendars preserve all playable events and stable ordering","callable":test_legacy},
		{"name":"cancelled JGP and world junior remain inspectable not playable","callable":test_cancelled},
		{"name":"calendar rejects unsupported explicit status","callable":test_bad_status},
		{"name":"cancellation needs dated source linked announcement","callable":test_missing_notice},
		{"name":"cancelled event cannot award records or ranking points","callable":test_cancelled_awards},
		{"name":"planned and cancelled duplicate ids do not create two entries","callable":test_duplicate},
		{"name":"filtering makes no change to archived calendar or nested evidence","callable":test_no_mutation},
		{"name":"series metadata cannot hide malformed policies or dangling evidence ids","callable":test_series_policy_validation},
	]

func _ready() -> bool:
	var methods = R.get_script_method_list().map(func(method): return method.name)
	var ready = methods.has("event_status") and methods.has("playable_events")
	T.assert_equal(ready,true,"Calendar status API not implemented")
	return ready

func _fixture() -> Dictionary:
	var data:Dictionary = R.load_international_calendar(2019,"women_singles","junior").calendar.duplicate(true)
	data.events = [data.events[0].duplicate(true)]
	return data

func _cancelled() -> Dictionary:
	var data = _fixture()
	data.events[0].status = "cancelled"
	data.events[0].record_eligibility = "none"
	data.events[0].ranking_points_system = "none"
	data.events[0].cancellation = {"announced_on":"2020-07-20","reason":"Official cancellation","source_ids":[data.sources[0].source_id]}
	return data

func test_legacy() -> void:
	if not _ready(): return
	for year in [2018,2019]:
		var data = R.load_calendar(year,"CHN","women_singles").calendar
		T.assert_equal(R.playable_events(data),R.ordered_events(data))
		T.assert_equal(R.event_status(data.events[0]),"scheduled")

func test_cancelled() -> void:
	if not _ready(): return
	var data = _cancelled()
	for family in ["jgp_stage","world_junior"]:
		data.events[0].event_family = family
		T.assert_equal(R.validate(data),[])
		T.assert_equal(R.ordered_events(data).size(),1)
		T.assert_equal(R.playable_events(data),[])
	data.events[0].status = "held"
	data.events[0].erase("cancellation")
	T.assert_equal(R.playable_events(data).size(),1)

func test_bad_status() -> void:
	var data = _fixture()
	data.events[0].status = "maybe"
	T.assert_equal(R.validate(data).is_empty(),false,"Unknown status must reject")
	if _ready(): T.assert_equal(R.playable_events(data),[])

func test_missing_notice() -> void:
	for defect in ["missing","source","reason","date"]:
		var data = _cancelled()
		match defect:
			"missing": data.events[0].erase("cancellation")
			"source": data.events[0].cancellation.source_ids = ["unrelated"]
			"reason": data.events[0].cancellation.reason = ""
			"date": data.events[0].cancellation.announced_on = "2020-02-30"
		T.assert_equal(R.validate(data).is_empty(),false,defect+" cancellation must reject")

func test_cancelled_awards() -> void:
	for field in ["record_eligibility","ranking_points_system"]:
		var data = _cancelled()
		data.events[0][field] = "isu_recognized" if field == "record_eligibility" else "isu_world_standings"
		T.assert_equal(R.validate(data).is_empty(),false,"Cancelled event cannot award "+field)

func test_duplicate() -> void:
	var data = _cancelled()
	var duplicate:Dictionary = data.events[0].duplicate(true)
	duplicate.status = "scheduled"
	duplicate.erase("cancellation")
	data.events.append(duplicate)
	T.assert_equal(R.validate(data).is_empty(),false)

func test_no_mutation() -> void:
	if not _ready(): return
	var data = _fixture()
	data.events[0].status = "held"
	var before = data.duplicate(true)
	var events = R.playable_events(data)
	events[0].level_options.append("other")
	T.assert_equal(data,before)

func test_series_policy_validation() -> void:
	for invalid in [null,"not a policy map",[],{"jgp":1},{"jgp":{}},{"": {"quota_source_id":"unknown"}},{"jgp":{"quota_source_id":"unknown"}}]:
		var data = _fixture()
		data.series_rules = invalid
		T.assert_equal(R.validate(data).is_empty(),false,"Invalid series metadata must not pass into bundle merge")
	var valid = _fixture()
	valid.series_rules = {"jgp":{"quota_source_id":valid.sources[0].source_id,"quota_world_junior_year":2020}}
	T.assert_equal(R.validate(valid),[])
