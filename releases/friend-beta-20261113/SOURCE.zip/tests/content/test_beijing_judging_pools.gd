extends RefCounted
const T = preload("res://tests/test_support.gd")
const Calendar = preload("res://src/content/season_calendar_repository.gd")
const J = preload("res://src/content/judging_profile_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2021 domestic online event has an available five judge fictional panel","callable":test_online},
		{"name":"2020 locally run GP uses seven host judges not seven different countries","callable":test_pandemic},
		{"name":"2020 host panel fails closed if host country is missing or invalid","callable":test_bad_host},
	]

func test_online() -> void:
	var loaded = J.load_profiles(2021)
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	var data = Calendar.load_calendar(2021,"CHN","women_singles")
	T.assert_equal(data.errors,[])
	var online_events: Array = Calendar.playable_events(data.calendar).filter(func(event):return event.event_family != "beijing_trial")
	T.assert_equal(online_events.size(),6,"All six verified online events must remain covered, independently of Olympic trials")
	for event in online_events:
		var panel = J.panel(event,51)
		T.assert_equal(panel.size(),5)
		for judge in panel:T.assert_equal(judge.federation,"CHN")

func _us_event() -> Dictionary:
	var data = Calendar.load_international_calendar(2020,"women_singles","senior")
	T.assert_equal(data.errors,[])
	return data.calendar.events[0].duplicate(true) if data.errors.is_empty() else {}

func test_pandemic() -> void:
	var loaded = J.load_profiles(2020)
	T.assert_equal(loaded.errors,[])
	var event = _us_event()
	if event.is_empty():return
	var panel = J.panel(event,51)
	T.assert_equal(panel.size(),7)
	var ids := {}
	for judge in panel:
		T.assert_equal(judge.federation,"USA")
		ids[judge.judge_id] = true
	T.assert_equal(ids.size(),7)
	T.assert_equal(J.panel(event,51),panel,"Panel generation must be deterministic")

func test_bad_host() -> void:
	var event = _us_event()
	if event.is_empty():return
	event.erase("host_federation")
	T.assert_equal(J.panel(event,51),[])
	event.host_federation = "invalid"
	T.assert_equal(J.panel(event,51),[])
