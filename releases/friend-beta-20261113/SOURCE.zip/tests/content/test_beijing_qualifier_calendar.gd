extends RefCounted
const T = preload("res://tests/test_support.gd")
const B = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"Nebelhorn Olympic qualifier resolves actual women segment dates and panel", "callable":calendar}]

func calendar() -> void:
	var result := B.competition_event({"event_id":"isu_olympic_qualifier_nebelhorn_2021","ruleset_season_start_year":2021,"competition_level":"senior"})
	T.assert_equal(result.errors,[],str(result.errors))
	if not result.errors.is_empty(): return
	T.assert_equal(result.event.start_date,"2021-09-23")
	T.assert_equal(result.event.end_date,"2021-09-25")
	T.assert_equal(result.event.segment_dates,{"short":"2021-09-23","free":"2021-09-25"})
	T.assert_equal(result.event.event_family,"olympic_qualifier")
	T.assert_equal(result.event.record_eligibility,"isu_recognized")
	T.assert_equal(result.rules.short.scoring_catalog.panel.judge_count,9)
	T.assert_equal(result.event.qualification_ids.has("olympic_qualifier_assignment"),true)
