extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "2018 China calendar contains the full club circuit", "callable": test_full_club_circuit},
		{"name": "calendar events are stable and ordered", "callable": test_stable_order},
		{"name": "domestic events award no ISU standing points", "callable": test_domestic_isu_points_rejected},
		{"name": "calendar rejects duplicate event ids", "callable": test_duplicate_event_ids},
		{"name": "calendar rejects unknown qualifications", "callable": test_unknown_qualification},
		{"name": "calendar rejects events without record eligibility", "callable": test_missing_record_eligibility},
		{"name": "calendar rejects unresolved source references", "callable": test_unknown_source_reference},
	]

func test_full_club_circuit() -> void:
	var result := SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles")
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.calendar.season_id, "2018-19")
	var events := SeasonCalendarRepository.ordered_events(result.calendar)
	TestSupport.assert_equal(events.filter(func(event): return event.event_family == "club_league_stage").size(), 5)
	TestSupport.assert_equal(events.any(func(event): return event.event_family == "club_league_final"), true)
	TestSupport.assert_equal(events.any(func(event): return event.event_id == "cn_grand_prix_u_series_2018"), true)

func test_stable_order() -> void:
	var calendar: Dictionary = SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles").calendar
	var first := SeasonCalendarRepository.ordered_events(calendar)
	var second := SeasonCalendarRepository.ordered_events(calendar)
	TestSupport.assert_equal(first.map(func(event): return event.event_id), second.map(func(event): return event.event_id))
	TestSupport.assert_equal(first[0].event_id, "cn_club_league_2018_stage_1")

func test_domestic_isu_points_rejected() -> void:
	var data := _valid_calendar()
	data.events[0].ranking_points_system = "isu_world_standings"
	TestSupport.assert_equal(SeasonCalendarRepository.validate(data).has("events.0 国内赛事不能授予ISU世界排名积分"), true)

func test_duplicate_event_ids() -> void:
	var data := _valid_calendar()
	data.events.append(data.events[0].duplicate(true))
	TestSupport.assert_equal(SeasonCalendarRepository.validate(data).has("events.1.event_id 重复：event_a"), true)

func test_unknown_qualification() -> void:
	var data := _valid_calendar()
	data.events[0].qualification_ids = ["missing"]
	TestSupport.assert_equal(SeasonCalendarRepository.validate(data).has("events.0.qualification_ids 引用了未知资质：missing"), true)

func test_missing_record_eligibility() -> void:
	var data := _valid_calendar()
	data.events[0].erase("record_eligibility")
	TestSupport.assert_equal(SeasonCalendarRepository.validate(data).has("events.0.record_eligibility 缺失"), true)

func test_unknown_source_reference() -> void:
	var data := _valid_calendar()
	data.events[0].sources = ["missing"]
	TestSupport.assert_equal(SeasonCalendarRepository.validate(data).has("events.0.sources 引用了未知来源：missing"), true)

func _valid_calendar() -> Dictionary:
	return {
		"catalog_version": 1, "calendar_year": 2018, "season_id": "2018-19",
		"federation": "CHN", "discipline": "women_singles",
		"qualification_definitions": {"registered": {"label": "完成注册"}},
		"sources": [{"source_id": "source", "title": "Source", "url": "https://example.com", "retrieved_on": "2026-09-11"}],
		"events": [{
			"event_id": "event_a", "name": "测试赛", "event_family": "national_junior",
			"scope": "domestic", "sequence": 1, "start_date": "2018-09-01", "end_date": "2018-09-02",
			"date_precision": "day", "location": "测试地", "level_options": ["junior"],
			"entry_route": "club_nomination", "qualification_ids": ["registered"],
			"ranking_points_system": "domestic", "ruleset_season_start_year": 2018,
			"record_eligibility": "domestic_only",
			"sources": ["source"]
		}]
	}
