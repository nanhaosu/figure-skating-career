extends RefCounted
const T = preload("res://tests/test_support.gd")
const C = preload("res://src/content/season_calendar_repository.gd")
const B = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2020 domestic unknown coverage is explicit and never manufactures formal starts","callable":_domestic},
		{"name":"2020 China GP simulation panel is seven without certifying historical count","callable":_panel},
		{"name":"simulation panel requires the approved narrow scope and visible uncertainty","callable":_bad_panel},
		{"name":"empty pandemic domestic offering cannot masquerade as a verified canceled census","callable":_bad_coverage},
	]

func _domestic() -> void:
	var loaded=C.load_calendar(2020,"CHN","women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	T.assert_equal(C.playable_events(loaded.calendar),[])
	T.assert_equal(loaded.calendar.coverage_policy.policy,"verified_events_only")
	T.assert_equal(loaded.calendar.coverage_policy.historical_census_complete,false)
	T.assert_equal(loaded.calendar.coverage_policy.training_continues,true)
	T.assert_equal(str(loaded.calendar.coverage_policy.label).contains("游戏处理"),true)

func _event() -> Dictionary:
	var loaded=C.load_international_calendar(2020,"women_singles","senior")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return {}
	return loaded.calendar.events.filter(func(e):return e.event_id=="isu_gpchn2020")[0]

func _panel() -> void:
	var event=_event()
	if event.is_empty():return
	T.assert_equal(event.panel_verification.status,"unknown")
	T.assert_equal(C.judging_panel_size(event),7)
	T.assert_equal(event.get("judge_count_source_ids",[]),[],"Game approval is not a historical count source")
	T.assert_equal(str(event.get("gameplay_note","")).contains("7人模拟裁判组"),true)
	var resolved=B.rules_for_event_level(event,"short","women_singles","senior")
	T.assert_equal(resolved.errors,[])
	if resolved.errors.is_empty():T.assert_equal(resolved.scoring.panel.judge_count,7)

func _bad_panel() -> void:
	var original=_event()
	if original.is_empty():return
	T.assert_equal(original.has("judge_count_game_policy"),true)
	if not original.has("judge_count_game_policy"):return
	for mutation in ["approval","label","scope","history"]:
		var event:Dictionary=original.duplicate(true)
		if mutation=="approval":event.judge_count_game_policy.user_approved=false
		elif mutation=="label":event.judge_count_game_policy.label=""
		elif mutation=="scope":event.ruleset_season_start_year=2021
		else:event.panel_verification.status="verified"
		T.assert_equal(C.judging_panel_size(event),-1,"Invalid simulated count: "+mutation)

func _bad_coverage() -> void:
	var loaded=C.load_calendar(2020,"CHN","women_singles")
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	for mutation in ["approval","census","label"]:
		var data:Dictionary=loaded.calendar.duplicate(true)
		if mutation=="approval":data.coverage_policy.user_approved=false
		elif mutation=="census":data.coverage_policy.historical_census_complete=true
		else:data.coverage_policy.label=""
		T.assert_equal(C.validate(data).is_empty(),false)
