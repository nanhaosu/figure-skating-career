extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const FormalScoringRepository = preload("res://src/content/formal_scoring_repository.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "2018 formal scoring catalog exposes historical values", "callable": test_2018_formal_scoring_catalog},
		{"name": "u series keeps announced actual and regional admission data", "callable": test_u_series_keeps_announced_and_actual_dates},
	]

func test_2018_formal_scoring_catalog() -> void:
	var loaded := FormalScoringRepository.load_catalog(2018, "women_singles")
	TestSupport.assert_equal(loaded.errors, [])
	TestSupport.assert_equal(loaded.catalog.goe_scale, [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5])
	TestSupport.assert_equal(FormalScoringRepository.element_value(loaded.catalog, "3Lz"), 5.9)
	TestSupport.assert_equal(FormalScoringRepository.level_value(loaded.catalog, "CCoSp", 4), 3.5)
	TestSupport.assert_equal(loaded.catalog.components.short.factor, 0.8)
	TestSupport.assert_equal(loaded.catalog.components.free.factor, 1.6)
	TestSupport.assert_equal(loaded.catalog.panel.judge_count, 9)
	TestSupport.assert_equal(loaded.catalog.domestic_bonus.short.triple_triple, 1.0)
	TestSupport.assert_equal(loaded.catalog.domestic_bonus.free.five_triple_types, 2.0)

func test_u_series_keeps_announced_and_actual_dates() -> void:
	var loaded := SeasonCalendarRepository.load_calendar(2018, "CHN", "women_singles")
	TestSupport.assert_equal(loaded.errors, [])
	var event := _event(loaded.calendar, "cn_grand_prix_u_series_2018")
	TestSupport.assert_equal(event.announced_dates.start, "2018-09-05")
	TestSupport.assert_equal(event.actual_dates.start, "2018-09-14")
	TestSupport.assert_equal(event.actual_dates.end, "2018-09-16")
	TestSupport.assert_equal(event.admission_policy.explicit_exemptions, ["HKG", "MAC"])
	TestSupport.assert_equal(event.admission_policy.review_routes.has("TPE"), true)
	TestSupport.assert_equal(event.record_eligibility, "domestic_only")

func _event(calendar: Dictionary, event_id: String) -> Dictionary:
	for event in calendar.get("events", []):
		if str(event.get("event_id", "")) == event_id:
			return event
	return {}
