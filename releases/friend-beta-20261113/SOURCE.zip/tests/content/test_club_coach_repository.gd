extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const ClubCoachRepository = preload("res://src/content/club_coach_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "club catalog offers real coach choices", "callable": test_club_catalog_offers_real_coach_choices},
		{"name": "public coach summary hides technical tendency values", "callable": test_public_coach_summary_hides_technical_tendency_values},
		{"name": "catalog validation rejects unknown club references", "callable": test_catalog_validation_rejects_unknown_club_references},
	]

func test_club_catalog_offers_real_coach_choices() -> void:
	var repository := ClubCoachRepository.new()
	TestSupport.assert_equal(repository.errors(), [])
	var clubs := repository.clubs()
	TestSupport.assert_equal(clubs.size() >= 3, true)
	for club in clubs:
		TestSupport.assert_equal(str(club.get("id", "")).is_empty(), false)
		TestSupport.assert_equal(str(club.get("name", "")).is_empty(), false)
		TestSupport.assert_equal(club.get("resources") is Dictionary, true)
		TestSupport.assert_equal(club.get("competition_pressure") is String, true)
		var coaches := repository.coaches_for_club(str(club.id))
		TestSupport.assert_equal(coaches.size() >= 2 and coaches.size() <= 3, true)
		for coach in coaches:
			TestSupport.assert_equal(coach.club_id, club.id)

func test_public_coach_summary_hides_technical_tendency_values() -> void:
	var repository := ClubCoachRepository.new()
	var coach: Dictionary = repository.coaches_for_club("club_north_star")[0]
	TestSupport.assert_equal(coach.technical_tendencies is Dictionary, true)
	TestSupport.assert_equal(coach.technical_tendencies.is_empty(), false)
	var summary := repository.public_coach_summary(str(coach.id))
	TestSupport.assert_equal(summary.has("technical_tendencies"), false)
	TestSupport.assert_equal(summary.visible_ratings is Dictionary, true)
	for value in summary.visible_ratings.values():
		TestSupport.assert_equal(value in ["突出", "可靠", "一般", "存在争议"], true)
	TestSupport.assert_equal(summary.known_strengths is Array, true)
	TestSupport.assert_equal(summary.known_strengths.is_empty(), false)
	TestSupport.assert_equal(summary.known_concerns is Array, true)

func test_catalog_validation_rejects_unknown_club_references() -> void:
	var clubs := {"clubs": [{"id": "club_known", "name": "已知俱乐部", "summary": "说明", "resources": {}, "competition_pressure": "一般"}]}
	var coaches := {"coaches": [{"id": "coach_bad", "club_id": "club_missing", "name": "错误教练"}]}
	var errors := ClubCoachRepository.validate_catalogs(clubs, coaches)
	TestSupport.assert_equal(errors.any(func(error: String) -> bool: return error.contains("club_missing")), true)
