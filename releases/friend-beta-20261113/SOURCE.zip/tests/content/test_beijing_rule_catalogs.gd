extends RefCounted
const T = preload("res://tests/test_support.gd")
const H = preload("res://src/content/historical_rule_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2020 junior short uses Lutz flying camel and layback or sit alternatives","callable":test_2020},
		{"name":"2021 junior short uses flip flying sit and layback or camel alternatives","callable":test_2021},
		{"name":"both Beijing seasons preserve junior senior free durations and choreography differences","callable":test_free_groups},
		{"name":"unavailable rule levels and segments return empty without runtime error","callable":test_unknown_group},
	]

func _load(year:int) -> Dictionary:
	var loaded = H.load_season(year,"women_singles")
	T.assert_equal(loaded.errors,[])
	return loaded.rules

func test_2020() -> void:
	var rules = _load(2020)
	if rules.is_empty(): return
	var short = H.rules_for(rules,"junior","short")
	T.assert_equal(short.required_solo_jump,"lutz")
	T.assert_equal(short.required_axel_rotations,[2.0])
	T.assert_equal(short.required_spin_codes,["CCoSp","FCSp","LSp"])
	T.assert_equal(short.spin_alternatives,{"LSp":["SSp"]})
	T.assert_equal(short.allowed_spin_codes.has("SSp"),true)
	T.assert_equal(short.allowed_spin_codes.has("FSSp"),false)

func test_2021() -> void:
	var rules = _load(2021)
	if rules.is_empty(): return
	var short = H.rules_for(rules,"junior","short")
	T.assert_equal(short.required_solo_jump,"flip")
	T.assert_equal(short.required_spin_codes,["CCoSp","FSSp","LSp"])
	T.assert_equal(short.spin_alternatives,{"LSp":["CSp"]})
	T.assert_equal(short.allowed_spin_codes.has("FCSp"),false)

func test_free_groups() -> void:
	for year in [2020,2021]:
		var rules = _load(year)
		if rules.is_empty(): continue
		for level in ["junior","senior"]:
			var free = H.rules_for(rules,level,"free")
			T.assert_equal(free.duration_seconds,210 if level == "junior" else 240)
			T.assert_equal(free.choreographic_min,0 if level == "junior" else 1)
			T.assert_equal(free.element_max,11 if level == "junior" else 12)
			T.assert_equal(free.jump_max,7)
			T.assert_equal(free.component_factor,1.6)
			T.assert_equal(free.formal_scoring_catalog,"%d_%d_women_singles_scoring" % [year,year+1])

func test_unknown_group() -> void:
	for year in [2019,2020,2021]:
		var rules = _load(year)
		if rules.is_empty(): continue
		T.assert_equal(H.rules_for(rules,"unknown","free"),{})
		T.assert_equal(H.rules_for(rules,"junior","unknown"),{})
