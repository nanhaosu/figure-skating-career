extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const SeasonBundleRepository = preload("res://src/content/season_bundle_repository.gd")

const DOMESTIC_EVENT_IDS := [
	"cn_club_league_2018_stage_1",
	"cn_club_league_2018_stage_2",
	"cn_club_league_2018_stage_3",
	"cn_club_league_2018_stage_4",
	"cn_club_league_2018_stage_5",
	"cn_club_league_2018_final",
	"cn_grand_prix_u_series_2018",
	"cn_national_championships_2018",
]

const INTERNATIONAL_EVENT_FACTS := [
	{"event_id":"isu_jgp_bratislava_2018", "family":"jgp_stage", "start":"2018-08-22", "end":"2018-08-25", "location":"Bratislava / SVK"},
	{"event_id":"isu_jgp_linz_2018", "family":"jgp_stage", "start":"2018-08-29", "end":"2018-09-01", "location":"Linz / AUT"},
	{"event_id":"isu_jgp_kaunas_2018", "family":"jgp_stage", "start":"2018-09-05", "end":"2018-09-08", "location":"Kaunas / LTU"},
	{"event_id":"isu_jgp_richmond_2018", "family":"jgp_stage", "start":"2018-09-12", "end":"2018-09-15", "location":"Richmond, BC / CAN"},
	{"event_id":"isu_jgp_ostrava_2018", "family":"jgp_stage", "start":"2018-09-26", "end":"2018-09-29", "location":"Ostrava / CZE"},
	{"event_id":"isu_jgp_ljubljana_2018", "family":"jgp_stage", "start":"2018-10-03", "end":"2018-10-06", "location":"Ljubljana / SLO"},
	{"event_id":"isu_jgp_yerevan_2018", "family":"jgp_stage", "start":"2018-10-10", "end":"2018-10-13", "location":"Yerevan / ARM"},
	{"event_id":"isu_jgp_final_vancouver_2018", "family":"jgp_final", "start":"2018-12-05", "end":"2018-12-09", "location":"Vancouver, BC / CAN"},
	{"event_id":"isu_world_junior_2019", "family":"world_junior", "start":"2019-03-04", "end":"2019-03-10", "location":"Zagreb / CRO"},
]

func cases() -> Array[Dictionary]:
	return [
		{"name":"July boundary preserves the immediately preceding active season until its real closure", "callable":test_unclosed_boundary},
		{"name": "2018 junior women bundle merges every domestic and international event", "callable": test_complete_2018_junior_women_bundle},
		{"name": "season bundle event ids dates and source references are deterministic", "callable": test_event_contract_and_sources},
		{"name": "every season event resolves junior short free and scoring catalogs", "callable": test_every_event_resolves_rules_and_scoring},
		{"name": "federation profiles expose visibly different fictional generation inputs", "callable": test_federation_profile_inputs},
		{"name": "unsupported season bundle reports content errors without substituting 2018", "callable": test_unsupported_season_is_explicit},
		{"name": "first fictional season offers explicit rules and adult domestic entry", "callable": test_fictional_first_season},
		{"name": "2022 senior Grand Prix stages and final resolve the official segment schedule and panel", "callable": test_2022_senior_grand_prix_calendar},
		{"name": "2022 official calendar reference validates without scheduling incomplete entries", "callable": test_2022_historical_reference},
	]

func test_2022_historical_reference() -> void:
	var repository = preload("res://src/content/season_calendar_repository.gd")
	var loaded: Dictionary = repository.load_historical_women_reference(2022)
	TestSupport.assert_equal(loaded.errors, [])
	if not loaded.errors.is_empty(): return
	var events: Array = repository.chronological_events(loaded.calendar)
	TestSupport.assert_equal(events.size(), 11)
	TestSupport.assert_equal(repository.playable_events(loaded.calendar), [])
	TestSupport.assert_equal(events[1].event_id, "cn_club_league_stage1_2022")
	TestSupport.assert_equal(events[1].actual_dates, {"start": "2022-08-28", "end": "2022-08-29"})
	TestSupport.assert_equal(events[4].status, "cancelled")
	TestSupport.assert_equal(events[5].event_id, "isu_jgp_solidarity_2022")
	TestSupport.assert_equal(int(events[5].observed_entries.CHN), 1)
	TestSupport.assert_equal(events[6].event_id, "isu_jgp_baltic_2022")
	TestSupport.assert_equal(events[9].actual_dates, {"start": "2023-01-11", "end": "2023-01-13"})
	TestSupport.assert_equal(events[9].segment_dates, {"short": "2023-01-11", "free": "2023-01-13"})
	TestSupport.assert_equal(events[10].segment_dates, {"short": "2023-03-01", "free": "2023-03-03"})
	var entry = preload("res://src/simulation/entry_application_service.gd")
	TestSupport.assert_equal(entry.current_eligibility(null, events[9], {}).hard_gate_codes, ["historical_reference_only"])
	TestSupport.assert_equal(entry.options(null, events[1], {}), [])
	TestSupport.assert_equal(entry.options(null, events[5], {}), [])
	var example: Dictionary = loaded.calendar.duplicate(true)
	var chengde: Dictionary = example.events.filter(func(event): return event.event_id == "cn_nationals_chengde_2022")[0]
	chengde.application_window = {"opens": "2022-12-01", "closes": "2022-12-10", "source_id": "cn_nationals_chengde_2022"}
	TestSupport.assert_equal(repository.validate(example), [])
	chengde.application_window.closes = "2023-01-12"
	TestSupport.assert_equal(repository.validate(example).is_empty(), false)
	chengde.application_window.closes = "2022-12-10"
	chengde.application_window.source_id = "unknown"
	TestSupport.assert_equal(repository.validate(example).is_empty(), false)

func test_fictional_first_season() -> void:
	for level in ["junior","senior"]:
		var bundle := SeasonBundleRepository.load_bundle(2022,"women_singles",level)
		TestSupport.assert_equal(bundle.errors,[])
		if not bundle.errors.is_empty(): continue
		TestSupport.assert_equal(bundle.scoring.scoring_era_id,"fictional_career_v1")
		TestSupport.assert_equal(bundle.calendar.events.size(),9 if level == "junior" else 11)
		if level == "junior":
			TestSupport.assert_equal(bundle.calendar.events.filter(func(e):return e.event_family == "jgp_stage").size(),6)
			TestSupport.assert_equal(bundle.calendar.events.any(func(e):return e.event_id == "isu_jgp_yerevan_2022"),false)
		for event in bundle.calendar.events:
			if event.get("scoring_rule") == "isu_2022_junior":
				var short := SeasonBundleRepository.rules_for_event_level(event,"short","women_singles","junior")
				var free := SeasonBundleRepository.rules_for_event_level(event,"free","women_singles","junior")
				TestSupport.assert_equal(short.errors + free.errors, [])
				if short.errors.is_empty() and free.errors.is_empty():
					TestSupport.assert_equal(short.rules.required_solo_jump, "loop")
					TestSupport.assert_equal(short.rules.allowed_spin_codes.has("FCSp"), true)
					TestSupport.assert_equal(free.rules.choreographic_min, 1)
					TestSupport.assert_equal(free.rules.step_max, 0)
					TestSupport.assert_equal(free.scoring.panel.judge_count, 9 if event.event_family == "jgp_stage" else 5)
				continue
			if event.get("scoring_rule") == "isu_2022_senior":
				if event.event_id == "isu_cs_budapest_2022":
					TestSupport.assert_equal(event.nomination_deadline, "2022-08-25")
					TestSupport.assert_equal(event.application_deadline, "2022-09-16")
					TestSupport.assert_equal(int(event.official_entry_fee.amount), 75)
					TestSupport.assert_equal(event.host_entry_limit_exempt, true)
				var resolved := SeasonBundleRepository.rules_for_event_level(event,"free","women_singles","senior")
				TestSupport.assert_equal(resolved.errors, [])
				if resolved.errors.is_empty():
					TestSupport.assert_equal(resolved.rules.axel_sequence_allowed, true)
					TestSupport.assert_equal(resolved.scoring.scoring_era_id, "isu_2022_three_components")
					TestSupport.assert_equal(resolved.scoring.panel.judge_count, 7 if event.event_id == "isu_cs_nebelhorn_2022" else 9)
				continue
			TestSupport.assert_equal(event.world_mode,"fictional")
			TestSupport.assert_equal(event.formal_scoring_catalog,"2022_2023_women_singles_scoring")
			if event.scope == "domestic": TestSupport.assert_equal(event.move_up_allowed,true)
			else: TestSupport.assert_equal(event.level_options,[level])

func test_2022_senior_grand_prix_calendar() -> void:
	var bundle := SeasonBundleRepository.load_bundle(2022,"women_singles","senior")
	TestSupport.assert_equal(bundle.errors, [])
	if not bundle.errors.is_empty(): return
	var circuit: Array = bundle.calendar.events.filter(func(event): return event.event_family in ["gp_stage", "gp_final"])
	var schedule := [
		["skate_america", "10-21", "10-23", "10-22", "10-23", "16:18:40", "15:06:50", "-04:00"],
		["skate_canada", "10-28", "10-30", "10-28", "10-29", "14:00:00", "13:15:00", "-04:00"],
		["france", "11-04", "11-06", "11-04", "11-05", "13:00:00", "13:00:00", "+01:00"],
		["sheffield", "11-10", "11-13", "11-12", "11-13", "15:20:00", "11:15:00", "+00:00"],
		["nhk", "11-18", "11-20", "11-18", "11-19", "14:15:00", "13:50:00", "+09:00"],
		["espoo", "11-25", "11-27", "11-25", "11-26", "14:54:00", "14:21:00", "+02:00"],
		["final_torino", "12-08", "12-11", "12-09", "12-10", "21:05:00", "21:00:00", "+01:00"],
	]
	TestSupport.assert_equal(circuit.size(), schedule.size())
	for row in schedule:
		var event := _event(circuit, "isu_gp_%s_2022" % row[0])
		TestSupport.assert_equal(event.is_empty(), false)
		if event.is_empty(): continue
		var final: bool = row[0] == "final_torino"
		TestSupport.assert_equal(event.event_family, "gp_final" if final else "gp_stage")
		TestSupport.assert_equal(event.actual_dates, {"start": "2022-" + row[1], "end": "2022-" + row[2]})
		TestSupport.assert_equal(event.segment_dates, {"short": "2022-" + row[3], "free": "2022-" + row[4]})
		TestSupport.assert_equal(event.segment_start_local_times, {"short": row[5], "free": row[6]})
		TestSupport.assert_equal(event.segment_time_utc_offset, row[7])
		TestSupport.assert_equal(event.application_deadline_game_policy and event.association_funded_game_policy, true)
		TestSupport.assert_equal(event.qualification_ids, ["cfsa_registered", "gp_final_qualified" if final else "gp_invitation", "program_legal"])
		var resolved := SeasonBundleRepository.competition_event(event)
		TestSupport.assert_equal(resolved.errors, [])
		if not resolved.errors.is_empty(): continue
		TestSupport.assert_equal(resolved.event.competition_policy.roster_policy, "qualified_ids" if final else "persistent_event_field")
		TestSupport.assert_equal(resolved.event.competition_policy.free_cut, 0)
		for segment in ["short", "free"]:
			TestSupport.assert_equal(resolved.rules[segment].scoring_catalog.panel.judge_count, 9)

func test_unclosed_boundary() -> void:
	var c = preload("res://tests/fixtures.gd").formal_junior_career(7204)
	c.clock.year = 2021
	c.clock.quarter = 3
	c.season_program_plan.season_id = "2020-21"
	c.season_state = {"season_id":"2020-21","season_history":{},"entry_plan":{},"event_statuses":{},"qualification_state":{}}
	var before := JSON.stringify(c.to_dict())
	TestSupport.assert_equal(SeasonBundleRepository.for_career(c).calendar.season_id,"2020-21","calendar switch must not abandon an unclosed season after the final body decision")
	TestSupport.assert_equal(JSON.stringify(c.to_dict()),before)
	c.season_state.season_history["2020-21"] = {}
	c.season_state.season_id = "2021-22"
	TestSupport.assert_equal(SeasonBundleRepository.for_career(c).calendar.season_id,"2021-22","closed season releases next year's calendar")
	c.season_state.season_history = {}
	c.season_state.season_id = "2018-19"
	c.season_program_plan.season_id = "2018-19"
	TestSupport.assert_equal(SeasonBundleRepository.for_career(c).calendar.season_id,"2021-22","stale legacy metadata must not rewind several years")

func test_complete_2018_junior_women_bundle() -> void:
	var bundle: Dictionary = SeasonBundleRepository.load_bundle(2018, "women_singles", "junior")
	TestSupport.assert_equal(bundle.errors, [])
	var events: Array = bundle.calendar.get("events", [])
	TestSupport.assert_equal(events.size(), DOMESTIC_EVENT_IDS.size() + INTERNATIONAL_EVENT_FACTS.size() + 1)
	for event_id in DOMESTIC_EVENT_IDS:
		TestSupport.assert_equal(_event(events, event_id).is_empty(), false)
	var international := events.filter(func(event): return event.get("scope") == "international")
	TestSupport.assert_equal(international.filter(func(event): return event.get("event_family") == "jgp_stage").size(), 7)
	TestSupport.assert_equal(_event(events, "isu_jgp_final_vancouver_2018").event_family, "jgp_final")
	TestSupport.assert_equal(_event(events, "isu_world_junior_2019").event_family, "world_junior")

func test_event_contract_and_sources() -> void:
	var bundle: Dictionary = SeasonBundleRepository.load_bundle(2018, "women_singles", "junior")
	var events: Array = bundle.calendar.get("events", [])
	var ids: Array[String] = []
	var previous_start := ""
	var sources: Dictionary = _sources_by_id(bundle.calendar.get("sources", []))
	for event in events:
		var event_id := str(event.get("event_id", ""))
		TestSupport.assert_equal(ids.has(event_id), false)
		ids.append(event_id)
		TestSupport.assert_equal(previous_start <= str(event.get("start_date", "")), true)
		previous_start = str(event.get("start_date", ""))
		for field in ["ruleset_season_start_year", "entry_route", "scope", "record_eligibility", "sources"]:
			TestSupport.assert_equal(event.has(field), true)
		for source_id in event.get("sources", []):
			TestSupport.assert_equal(sources.has(source_id), true)
	for fact in INTERNATIONAL_EVENT_FACTS:
		var event := _event(events, fact.event_id)
		TestSupport.assert_equal(event.get("event_family"), fact.family)
		TestSupport.assert_equal(event.get("start_date"), fact.start)
		TestSupport.assert_equal(event.get("end_date"), fact.end)
		TestSupport.assert_equal(event.get("location"), fact.location)
		for source_id in event.get("sources", []):
			TestSupport.assert_equal(str(sources[source_id].get("url", "")).begins_with("https://results.isu.org/"), true)

func test_every_event_resolves_rules_and_scoring() -> void:
	var bundle: Dictionary = SeasonBundleRepository.load_bundle(2018, "women_singles", "junior")
	for event in bundle.calendar.get("events", []):
		for segment in ["short", "free"]:
			var resolved: Dictionary = SeasonBundleRepository.rules_for_event(event, segment, "women_singles", "junior")
			TestSupport.assert_equal(resolved.errors, [])
			TestSupport.assert_equal(resolved.rules.segment, segment)
			TestSupport.assert_equal(resolved.rules.level, "junior")
			TestSupport.assert_equal(resolved.scoring.season_start_year, 2018)
			TestSupport.assert_equal(resolved.rules.formal_scoring_catalog, "2018_2019_women_singles_scoring")

func test_federation_profile_inputs() -> void:
	var bundle: Dictionary = SeasonBundleRepository.load_bundle(2018, "women_singles", "junior")
	var profiles: Dictionary = bundle.federation_profiles
	for federation_id in ["RUS", "JPN", "CHN", "USA", "KOR", "BEL", "HKG", "TPE"]:
		TestSupport.assert_equal(profiles.has(federation_id), true)
		var profile: Dictionary = profiles.get(federation_id, {})
		for field in ["pool_size", "mean_strength", "strength_deviation", "resource_level", "volatility", "late_bloomer_rate", "nationality_frequency"]:
			TestSupport.assert_equal(profile.has(field), true)
		TestSupport.assert_equal(profile.has("athletes"), false)
	TestSupport.assert_equal(int(profiles.RUS.pool_size) > int(profiles.CHN.pool_size), true)
	TestSupport.assert_equal(int(profiles.CHN.pool_size) > int(profiles.HKG.pool_size), true)
	TestSupport.assert_equal(float(profiles.JPN.mean_strength) > float(profiles.BEL.mean_strength), true)
	TestSupport.assert_equal(float(profiles.HKG.strength_deviation) > float(profiles.JPN.strength_deviation), true)
	TestSupport.assert_equal(profiles.values().map(func(profile): return profile).all(func(profile): return profile.get("fictional_generation_only") == true), true)

func test_unsupported_season_is_explicit() -> void:
	# Beijing content intentionally adds2020/2021. An actually unimplemented
	# future season must still fail rather than borrowing an older catalog.
	var bundle: Dictionary = SeasonBundleRepository.load_bundle(2026, "women_singles", "junior")
	TestSupport.assert_equal(bundle.calendar, {})
	TestSupport.assert_equal(bundle.rules, {})
	TestSupport.assert_equal(bundle.scoring, {})
	TestSupport.assert_equal(bundle.federation_profiles, {})
	TestSupport.assert_equal(bundle.errors.is_empty(), false)

func _event(events: Array, event_id: String) -> Dictionary:
	for event in events:
		if str(event.get("event_id", "")) == event_id:
			return Dictionary(event)
	return {}

func _sources_by_id(source_rows: Array) -> Dictionary:
	var result := {}
	for source in source_rows:
		result[str(source.get("source_id", ""))] = source
	return result
