extends RefCounted
const T = preload("res://tests/test_support.gd")
const PATH="res://src/content/beijing_qualification_policy.gd"
const DATA="res://data/qualification/beijing_2022_adopted_policy.json"

func cases() -> Array[Dictionary]:
	return [
		{"name":"adopted Beijing TES policy preserves exact verified2395 requirements and final uncertainty","callable":_actual},
		{"name":"missing approval or hidden final-version caveat rejects adopted policy","callable":_invalid_approval},
		{"name":"domestic junior and wrong season records cannot silently replace senior international TES","callable":_invalid_scope},
		{"name":"adopted policy cannot silently lower the source minimum or expand its validity window","callable":_invalid_numbers},
	]

func _repo():
	T.assert_equal(FileAccess.file_exists(PATH),true,"Adopted policy consumer missing")
	if not FileAccess.file_exists(PATH):return null
	return load(PATH)

func _data() -> Dictionary:
	var value=JSON.parse_string(FileAccess.get_file_as_string(DATA))
	T.assert_equal(value is Dictionary,true)
	return value if value is Dictionary else {}

func _actual() -> void:
	var repo=_repo()
	if repo==null:return
	var loaded=repo.load_policy()
	T.assert_equal(loaded.errors,[])
	if not loaded.errors.is_empty():return
	T.assert_equal(loaded.policy.minimum_tes,{"short":23.0,"free":40.0})
	T.assert_equal(loaded.policy.valid_season_start_years,[2019,2020,2021])
	T.assert_equal(loaded.policy.earned_level,"senior")
	T.assert_equal(loaded.policy.record_scope,"isu_recognized")
	T.assert_equal(loaded.policy.final_historical_verification,"unknown")
	T.assert_equal(str(loaded.policy.label).contains("最终修订未核实"),true)
	T.assert_equal(loaded.policy.scope,"2021-22/olympics/women/individual")

func _invalid_approval() -> void:
	var repo=_repo()
	if repo==null:return
	for field in ["user_approved","label","final_historical_verification"]:
		var data=_data()
		if field=="user_approved":data[field]=false
		elif field=="label":data[field]="采用现行规则"
		else:data[field]="verified"
		T.assert_equal(repo.validate(data).is_empty(),false)

func _invalid_scope() -> void:
	var repo=_repo()
	if repo==null:return
	for field in ["earned_level","record_scope","scope"]:
		var data=_data()
		data[field]={"earned_level":"junior","record_scope":"domestic_only","scope":"all_events"}[field]
		T.assert_equal(repo.validate(data).is_empty(),false)

func _invalid_numbers() -> void:
	var repo=_repo()
	if repo==null:return
	for mutation in ["short","free","window","source"]:
		var data=_data()
		if mutation in ["short","free"]:data.minimum_tes[mutation]=0.0
		elif mutation=="window":data.valid_season_start_years=[2018,2019,2020,2021]
		else:data.source_id="unknown"
		T.assert_equal(repo.validate(data).is_empty(),false)
