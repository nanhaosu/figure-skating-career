extends RefCounted
const T = preload("res://tests/test_support.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"historical profiles resolve isolated validated age and era bands","callable":test_profiles}, {"name":"historical source references must resolve","callable":test_sources}]

func test_sources() -> void:
	var repo = load("res://src/content/historical_athlete_profile_repository.gd")
	var broken: Dictionary = repo.load_catalog()
	broken.profiles[0].source_ids = ["nonexistent"]
	T.assert_equal(repo.validate_catalog(broken).is_empty(),false)
func test_profiles() -> void:
	var repo = load("res://src/content/historical_athlete_profile_repository.gd")
	T.assert_equal(repo != null, true)
	if repo == null: return
	var catalog: Dictionary = repo.load_catalog()
	T.assert_equal(catalog.errors, [])
	for age in [6, 10]:
		var profile: Dictionary = repo.profile_for(2014,"CHN",age,"teaching")
		T.assert_equal(profile.errors, [])
		T.assert_equal(profile.jump_distributions.top.axel, 0.0)
	for year in [2018,2019,2020]:
		for tier in ["domestic_development","domestic_junior","national"]:
			var profile: Dictionary = repo.profile_for(year,"CHN",13,tier)
			T.assert_equal(profile.errors, [])
			T.assert_equal(profile.maximum_axel, 2)
	T.assert_equal(repo.profile_for(2014,"CHN",11,"teaching").errors.is_empty(), false)
	T.assert_equal(repo.age_on_july_first("2005-07-01",2018),13)
	T.assert_equal(repo.age_on_july_first("2005-07-02",2018),12)
	var first: Dictionary = repo.profile_for(2018,"CHN",13,"national")
	first.jump_distributions.top.lutz = 0.0
	T.assert_equal(repo.profile_for(2018,"CHN",13,"national").jump_distributions.top.lutz > 0.0,true)
	var broken: Dictionary = catalog.duplicate(true)
	broken.profiles[0].archetype_shares.top = 99
	T.assert_equal(repo.validate_catalog(broken).is_empty(),false)

