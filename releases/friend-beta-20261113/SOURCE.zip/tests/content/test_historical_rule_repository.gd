extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const HistoricalRuleRepository = preload("res://src/content/historical_rule_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "2018 junior women rules load from a sourced catalog", "callable": test_loads_2018_junior_women_rules},
		{"name": "unknown historical season reports an explicit error", "callable": test_unknown_season_is_explicit},
		{"name": "historical rules reject a missing source url", "callable": test_missing_source_url},
		{"name": "historical rules reject a mismatched season id", "callable": test_mismatched_season_id},
		{"name": "historical rules reject a fractional jump count", "callable": test_fractional_jump_count},
		{"name": "historical rules require both junior segments", "callable": test_missing_junior_segment},
		{"name": "historical rules reject an impossible element maximum", "callable": test_impossible_element_maximum},
		{"name": "historical rules reject unresolved segment sources", "callable": test_unknown_segment_source},
	]

func test_loads_2018_junior_women_rules() -> void:
	var result := HistoricalRuleRepository.load_season(2018, "women_singles")
	TestSupport.assert_equal(result.errors, [])
	TestSupport.assert_equal(result.rules.season_id, "2018-19")
	TestSupport.assert_equal(result.rules.levels.junior.segments.short.jump_max, 3)
	TestSupport.assert_equal(result.rules.levels.junior.segments.free.jump_max, 7)
	TestSupport.assert_equal(result.rules.sources.is_empty(), false)

func test_unknown_season_is_explicit() -> void:
	var result := HistoricalRuleRepository.load_season(2013, "women_singles")
	TestSupport.assert_equal(result.rules, {})
	TestSupport.assert_equal(result.errors, ["尚未收录2013-14赛季 women_singles 规则"])

func test_missing_source_url() -> void:
	var data := _valid_data()
	data.sources[0].erase("url")
	TestSupport.assert_equal(HistoricalRuleRepository.validate(data).has("sources.0.url 必须是非空字符串"), true)

func test_mismatched_season_id() -> void:
	var data := _valid_data()
	data.season_id = "2017-18"
	TestSupport.assert_equal(HistoricalRuleRepository.validate(data).has("season_id 必须与 season_start_year 对应"), true)

func test_fractional_jump_count() -> void:
	var data := _valid_data()
	data.levels.junior.segments.short.jump_max = 3.5
	TestSupport.assert_equal(HistoricalRuleRepository.validate(data).has("levels.junior.segments.short.jump_max 必须是非负整数"), true)

func test_missing_junior_segment() -> void:
	var data := _valid_data()
	data.levels.junior.segments.erase("free")
	TestSupport.assert_equal(HistoricalRuleRepository.validate(data).has("levels.junior.segments.free 必须是对象"), true)

func test_impossible_element_maximum() -> void:
	var data := _valid_data()
	data.levels.junior.segments.free.element_max = 5
	TestSupport.assert_equal(HistoricalRuleRepository.validate(data).has("levels.junior.segments.free.element_max 小于必需动作总数"), true)

func test_unknown_segment_source() -> void:
	var data := _valid_data()
	data.levels.junior.segments.short.source_ids = ["missing"]
	TestSupport.assert_equal(HistoricalRuleRepository.validate(data).has("levels.junior.segments.short.source_ids 引用了未知来源：missing"), true)

func _valid_data() -> Dictionary:
	return {
		"catalog_version": 1,
		"season_start_year": 2018,
		"season_id": "2018-19",
		"discipline": "women_singles",
		"effective_from": "2018-07-01",
		"effective_to": "2019-06-30",
		"sources": [{"source_id": "isu_rules_2018", "title": "ISU 2018 rules", "url": "https://www.isu.org/", "retrieved_on": "2026-09-11"}],
		"levels": {"junior": {"segments": {"short": _segment("short", 3, 3, 1, 7), "free": _segment("free", 7, 3, 1, 11)}}},
	}

func _segment(segment: String, jump_max: int, spin_min: int, step_min: int, element_max: int) -> Dictionary:
	return {
		"ruleset_id": "test_%s" % segment,
		"segment": segment,
		"label": "短节目" if segment == "short" else "自由滑",
		"duration_seconds": 160 if segment == "short" else 210,
		"duration_tolerance_seconds": 10,
		"jump_min": jump_max,
		"jump_max": jump_max,
		"jump_combination_min": 1 if segment == "short" else 0,
		"jump_combination_max": 1 if segment == "short" else 3,
		"spin_min": spin_min,
		"spin_max": 3,
		"step_min": step_min,
		"step_max": 1,
		"choreographic_min": 0,
		"choreographic_max": 0,
		"element_max": element_max,
		"required_jump_types": ["axel"],
		"repeat_limits": {"max_repeated_triples_or_quads": 2},
		"bonus_window": {"kind": "last_jump_elements", "count": 1 if segment == "short" else 3, "multiplier": 1.1},
		"component_factor": 0.8 if segment == "short" else 1.6,
		"source_ids": ["isu_rules_2018"],
	}
