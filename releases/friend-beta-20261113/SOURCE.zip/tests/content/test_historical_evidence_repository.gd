extends RefCounted
const T = preload("res://tests/test_support.gd")
const REPO = "res://src/content/historical_evidence_repository.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"explicit cancellation supersedes planned evidence independent of order","callable":test_revision},
		{"name":"unlinked contradictory facts remain conflicting","callable":test_conflict},
		{"name":"future expired or invalid dates cannot establish eligibility","callable":test_dates},
		{"name":"unknown final threshold never falls back to superseded value","callable":test_unknown},
		{"name":"invalid provenance locators windows and references fail closed","callable":test_invalid},
		{"name":"secondary commentary cannot certify official rules","callable":test_secondary},
		{"name":"cyclic or unrelated supersession is rejected","callable":test_bad_revision},
		{"name":"real catalog records cancellations but not invented Olympic TES","callable":test_real_catalog},
		{"name":"resolved values cannot mutate source evidence","callable":test_no_mutation},
		{"name":"national cancellation is known only after the actual May2022 announcement","callable":test_national_cancellation_timeline},
	]

func _repo():
	T.assert_equal(FileAccess.file_exists(REPO),true,"Historical evidence repository missing")
	if not FileAccess.file_exists(REPO): return null
	return load(REPO)

func _record(id:String,value:Variant,supersedes:Array=[]) -> Dictionary:
	return {"record_id":id,"claim_id":"jgp_2020_status","scope":"2020-21/junior/women","value":value,"source_id":"official","locator":"p1 decision1","effective_from":"2020-07-01","effective_to":"2021-06-30","verification_status":"verified","supersedes":supersedes}

func _catalog(records:Array) -> Dictionary:
	return {"catalog_version":1,"sources":[{"source_id":"official","kind":"official_primary","title":"Fixture rule","url":"https://isu.org/fixture.pdf","published_on":"2020-07-01","verified_on":"2026-10-21"}],"claims":records}

func test_revision() -> void:
	var repo = _repo(); if repo == null: return
	var planned = _record("plan","scheduled")
	var cancelled = _record("cancel","cancelled",["plan"])
	for records in [[planned,cancelled],[cancelled,planned]]:
		var result = repo.resolve(_catalog(records),"jgp_2020_status","2020-08-01")
		T.assert_equal(result.errors,[])
		T.assert_equal(result.status,"verified")
		T.assert_equal(result.value,"cancelled")

func test_conflict() -> void:
	var repo = _repo(); if repo == null: return
	var result = repo.resolve(_catalog([_record("a","scheduled"),_record("b","cancelled")]),"jgp_2020_status","2020-08-01")
	T.assert_equal(result.status,"conflicting")
	T.assert_equal(result.value,null)

func test_dates() -> void:
	var repo = _repo(); if repo == null: return
	var data = _catalog([_record("a","scheduled")])
	for day in ["2020-06-30","2021-07-01"]:
		T.assert_equal(repo.resolve(data,"jgp_2020_status",day).status,"unknown")
	data.sources[0].published_on = "2020-08-10"
	T.assert_equal(repo.resolve(data,"jgp_2020_status","2020-08-01").value,null)
	T.assert_equal(repo.resolve(data,"jgp_2020_status","bad-date").errors.is_empty(),false)

func test_unknown() -> void:
	var repo = _repo(); if repo == null: return
	var unknown = _record("final",null,["early"])
	unknown.verification_status = "unknown"
	var result = repo.resolve(_catalog([_record("early",30),unknown]),"jgp_2020_status","2020-08-01")
	T.assert_equal(result.status,"unknown")
	T.assert_equal(result.value,null)
	T.assert_equal(repo.resolve(_catalog([]),"missing","2020-08-01").value,null)

func test_invalid() -> void:
	var repo = _repo(); if repo == null: return
	for defect in ["url","locator","window","date","reference","non_string_source_id"]:
		var data = _catalog([_record("a","scheduled")])
		match defect:
			"url": data.sources[0].url = "javascript:fake"
			"locator": data.claims[0].locator = ""
			"window": data.claims[0].effective_to = "2019-01-01"
			"date": data.claims[0].effective_from = "2020-02-30"
			"reference": data.claims[0].source_id = "missing"
			"non_string_source_id":
				data.sources[0].source_id = 7
				data.claims[0].source_id = "7"
		var result = repo.resolve(data,"jgp_2020_status","2020-08-01")
		T.assert_equal(result.errors.is_empty(),false,defect+" must reject")
		T.assert_equal(result.value,null)

func test_secondary() -> void:
	var repo = _repo(); if repo == null: return
	var data = _catalog([_record("a","cancelled")])
	data.sources[0].kind = "secondary"
	T.assert_equal(repo.resolve(data,"jgp_2020_status","2020-08-01").errors.is_empty(),false)

func test_bad_revision() -> void:
	var repo = _repo(); if repo == null: return
	var data = _catalog([_record("a",true,["b"]),_record("b",false,["a"])])
	T.assert_equal(repo.resolve(data,"jgp_2020_status","2020-08-01").errors.is_empty(),false)
	data.claims[0].supersedes = []
	data.claims[0].claim_id = "unrelated"
	T.assert_equal(repo.resolve(data,"jgp_2020_status","2020-08-01").errors.is_empty(),false)

func test_real_catalog() -> void:
	var repo = _repo(); if repo == null: return
	var loaded = repo.load_catalog("res://data/qualification/beijing_2022_evidence.json")
	T.assert_equal(loaded.errors,[])
	T.assert_equal(repo.resolve(loaded.catalog,"jgp_2020_status","2020-08-01").value,"cancelled")
	T.assert_equal(repo.resolve(loaded.catalog,"wjc_2021_status","2021-02-01").value,"cancelled")
	T.assert_equal(repo.resolve(loaded.catalog,"jgp_2021_quota_basis","2021-07-01").value,2020)
	T.assert_equal(repo.resolve(loaded.catalog,"gpf_2021_status","2022-01-01").value,"cancelled")
	T.assert_equal(repo.resolve(loaded.catalog,"gpf_2021_status","2021-12-01").status,"unknown")
	T.assert_equal(repo.resolve(loaded.catalog,"beijing_women_tes_2395","2021-07-01").value,{"short":23.0,"free":40.0,"earned_level":"senior"})
	T.assert_equal(repo.resolve(loaded.catalog,"beijing_women_tes_final","2022-01-24").status,"unknown")
	T.assert_equal(repo.resolve(loaded.catalog,"beijing_women_tes_final","2022-01-24").value,null)
	T.assert_equal(repo.load_catalog("res://data/qualification/missing.json").errors.is_empty(),false)

func test_no_mutation() -> void:
	var repo = _repo(); if repo == null: return
	var data = _catalog([_record("a",{"best":4,"rounds":5})])
	var before = data.duplicate(true)
	var result = repo.resolve(data,"jgp_2020_status","2020-08-01")
	result.value.best = 1
	T.assert_equal(data,before)

func test_national_cancellation_timeline() -> void:
	var repo = _repo(); if repo == null: return
	var loaded = repo.load_catalog("res://data/qualification/beijing_2022_evidence.json")
	T.assert_equal(loaded.errors,[])
	for claim in ["cn_nationals_2021_22_final_status","cn_champions_2021_22_final_status"]:
		T.assert_equal(repo.resolve(loaded.catalog,claim,"2022-05-05").status,"unknown","Later cancellation is not advance knowledge in December/Beijing season")
		var result = repo.resolve(loaded.catalog,claim,"2022-05-06")
		T.assert_equal(result.status,"verified")
		T.assert_equal(result.value,"cancelled")
		T.assert_equal(result.source_ids,["cfsa_20220506_cancel_nationals_champions"])
