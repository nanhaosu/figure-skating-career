extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"world context never exposes future facts and main menu stays generic","callable":context_dates},
		{"name":"beginner guide adds international reference without extra compulsory pages","callable":guide_context}]

func context_dates() -> void:
	var path := "res://src/content/skating_world_context_repository.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"world context repository is not implemented")
	if not FileAccess.file_exists(path): return
	var repo = load(path)
	T.assert_equal(repo.for_clock().id,"generic")
	T.assert_equal(repo.for_clock({"year":2014,"quarter":1}).id,"generic")
	var old: Dictionary = repo.for_clock({"year":2019,"quarter":1})
	T.assert_equal(old.text.contains("2019年世青赛"),false)
	var current: Dictionary = repo.for_clock({"year":2019,"quarter":2})
	T.assert_equal(current.id,"women_junior_2019_worlds")
	T.assert_equal(current.source_urls.size(),1)
	T.assert_equal(current.text.contains("第十九"),true)

func guide_context() -> void:
	var guide = load("res://src/presentation/skating_beginner_guide.gd")
	T.assert_equal(guide.has_method("pages_for"),true,"existing help must select context without adding pages")
	if not guide.has_method("pages_for"): return
	var pages: Array = guide.pages_for({"year":2019,"quarter":2})
	T.assert_equal(pages.size(),6)
	T.assert_equal(pages[0].body.contains("国内"),true)
	T.assert_equal(pages[0].body.contains("第十九"),true)
	T.assert_equal(guide.pages_for()[0].body.contains("2019年"),false)
