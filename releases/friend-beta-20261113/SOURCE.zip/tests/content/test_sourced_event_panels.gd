extends RefCounted
const T = preload("res://tests/test_support.gd")
const C = preload("res://src/content/season_calendar_repository.gd")
const B = preload("res://src/content/season_bundle_repository.gd")
const J = preload("res://src/content/judging_profile_repository.gd")
const S = preload("res://src/content/formal_scoring_repository.gd")
const P = preload("res://src/simulation/formal_judging_panel.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"sourced online event resolves five judges without changing ordinary nine","callable":test_five},
		{"name":"unsupported or unsourced event panel size is rejected at content boundary","callable":test_invalid},
		{"name":"judge generator uses event panel size and fails closed for invalid override","callable":test_generator},
		{"name":"five judge scoring trims highest and lowest PCS marks","callable":test_scoring},
		{"name":"competition request cannot forge a smaller canonical panel","callable":test_forgery},
		{"name":"empty configured panel cannot silently produce a zero score","callable":test_empty_panel},
		{"name":"sourced seven judge pandemic panel generates seven and trims to five","callable":test_seven},
	]

func _event() -> Dictionary:
	return C.load_calendar(2019,"CHN","women_singles").calendar.events[0].duplicate(true)

func _sourced() -> Dictionary:
	var event = _event()
	event.judge_count = 5
	event.judge_count_source_ids = event.sources.duplicate()
	return event

func test_five() -> void:
	var normal = B.rules_for_event_level(_event(),"short","women_singles","junior")
	var online = B.rules_for_event_level(_sourced(),"short","women_singles","junior")
	T.assert_equal(normal.errors,[])
	T.assert_equal(online.errors,[])
	T.assert_equal(normal.scoring.panel.judge_count,9)
	T.assert_equal(online.scoring.panel.judge_count,5)
	T.assert_equal(S.validate(online.scoring),[])
	T.assert_equal(S.load_catalog(2019,"women_singles").catalog.panel.judge_count,9)

func test_invalid() -> void:
	for defect in ["four","missing","unrelated","fraction"]:
		var data = C.load_calendar(2019,"CHN","women_singles").calendar.duplicate(true)
		data.events[0] = _sourced()
		match defect:
			"four": data.events[0].judge_count = 4
			"missing": data.events[0].erase("judge_count_source_ids")
			"unrelated": data.events[0].judge_count_source_ids = ["unknown"]
			"fraction": data.events[0].judge_count = 5.5
		T.assert_equal(C.validate(data).is_empty(),false,defect+" panel must reject")
		T.assert_equal(B.rules_for_event_level(data.events[0],"short","women_singles","junior").errors.is_empty(),false)

func test_generator() -> void:
	T.assert_equal(J.panel(_event(),9).size(),9)
	T.assert_equal(J.panel(_sourced(),9).size(),5)
	var event = _sourced()
	event.judge_count = 0
	T.assert_equal(J.panel(event,9),[])

func test_scoring() -> void:
	var rules = S.load_catalog(2019,"women_singles").catalog.duplicate(true)
	rules.panel.judge_count = 5
	var judges:Array = []
	for mark in [-2.0,-1.0,0.0,1.0,2.0]:
		judges.append({"judge_id":str(mark),"pcs_bias":mark,"consistency":1.0,"technical_bias":0.0,"affinity":0.0})
	var scored = P.score({"segment":"short","elements":[]},{"final_elements":[],"review_events":[]},{"skating_skills":5.0,"transitions":5.0,"performance":5.0,"composition":5.0,"interpretation":5.0},rules,judges,7)
	T.assert_equal(scored.errors,[])
	T.assert_equal(scored.judge_count,5)
	# Symmetric deterministic bias, trimmed mean stays5.0 for each component.
	T.assert_equal(scored.component_scores.skating_skills.average,5.0)
	T.assert_equal(scored.component_scores.skating_skills.judge_marks.size(),5)

func test_forgery() -> void:
	var event = _sourced()
	T.assert_equal(B.competition_event(event).errors.is_empty(),false,"Caller cannot override canonical nine-judge event")

func test_empty_panel() -> void:
	var rules = S.load_catalog(2019,"women_singles").catalog.duplicate(true)
	rules.panel.judge_count = 0
	T.assert_equal(P.score({"segment":"short","elements":[]},{"final_elements":[],"review_events":[]},{},rules,[],7).errors.is_empty(),false)

func test_seven() -> void:
	var event = _sourced()
	event.judge_count = 7
	var resolved = B.rules_for_event_level(event,"short","women_singles","junior")
	T.assert_equal(resolved.errors,[],"2020 Skate America seven-judge scoring must not silently become nine")
	T.assert_equal(J.panel(event,9).size(),7)
	var rules = S.load_catalog(2019,"women_singles").catalog.duplicate(true)
	rules.panel.judge_count = 7
	T.assert_equal(S.validate(rules),[])
	var judges:Array = []
	for mark in [-3.0,-2.0,-1.0,0.0,1.0,2.0,3.0]:
		judges.append({"judge_id":str(mark),"pcs_bias":mark,"consistency":1.0,"technical_bias":0.0,"affinity":0.0})
	var scored = P.score({"segment":"short","elements":[]},{"final_elements":[],"review_events":[]},{"skating_skills":5.0,"transitions":5.0,"performance":5.0,"composition":5.0,"interpretation":5.0},rules,judges,7)
	T.assert_equal(scored.errors,[])
	if not scored.errors.is_empty():return
	T.assert_equal(scored.judge_count,7)
	T.assert_equal(scored.component_scores.skating_skills.average,5.0)
	T.assert_equal(scored.component_scores.skating_skills.judge_marks.size(),7)
