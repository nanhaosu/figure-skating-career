extends RefCounted
const T = preload("res://tests/test_support.gd")
const C = preload("res://src/content/season_calendar_repository.gd")
const B = preload("res://src/content/season_bundle_repository.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"2020 revised six JGP plans and Harbin world junior remain canceled not imaginary starts","callable":test_calendar},
		{"name":"canceled2020 junior events never resolve executable rules or award records","callable":test_no_execution},
	]

func _calendar() -> Dictionary:
	var loaded = C.load_international_calendar(2020,"women_singles","junior")
	T.assert_equal(loaded.errors,[])
	return loaded.calendar

func test_calendar() -> void:
	var data = _calendar()
	if data.is_empty():return
	T.assert_equal(C.playable_events(data),[])
	var stages = data.events.filter(func(e):return e.event_family == "jgp_stage")
	T.assert_equal(stages.size(),6,"2332 June revision had six remaining events, not a fabricated ordinary seven-stage circuit")
	T.assert_equal(stages.map(func(e):return e.location),["Budapest / HUN","Yokohama / JPN","Ostrava / CZE","Tashkent / UZB","Ljubljana / SLO","Riga / LAT"])
	var world = data.events.filter(func(e):return e.event_family == "world_junior")
	T.assert_equal(world.size(),1)
	if world.is_empty():return
	T.assert_equal(world[0].location,"Harbin / CHN（原计划，未举办）")
	T.assert_equal(world[0].cancellation.announced_on,"2020-11-24")

func test_no_execution() -> void:
	var data = _calendar()
	if data.is_empty():return
	for event in data.events:
		T.assert_equal(event.status,"cancelled")
		T.assert_equal(event.record_eligibility,"none")
		T.assert_equal(event.ranking_points_system,"none")
		T.assert_equal(B.rules_for_event_level(event,"short","women_singles","junior").errors.is_empty(),false)
