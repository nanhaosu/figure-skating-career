extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const ProgramCandidatePresenter = preload("res://src/presentation/program_candidate_presenter.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"one successful attempt is not a stable competition reserve", "callable":test_new_jump_is_not_stable},
		{"name":"mastered higher rotation does not lock out lower rotation", "callable":test_lower_rotation_remains_selectable},
		{"name":"jump candidates distinguish stable risky and unavailable attempts", "callable":test_jump_candidate_bands},
		{"name":"candidate reasons expose program repeat conflicts", "callable":test_repeat_conflict},
		{"name":"spin and step choices never ask the player for a target level", "callable":test_non_jump_choices_have_no_target_level},
	]

func test_new_jump_is_not_stable() -> void:
	var career = Fixtures.starting_career(804)
	var profile = career.athlete.jumps.axel
	profile.unlocked_rotations = 3
	profile.proficiency.triple = 8.0
	profile.attempt_evidence.triple = {"attempts":1, "successes":1, "clean_successes":1}
	var program = SkatingProgram.create("new-axel", "short", [_jump("j", "axel", 2)]).program
	var choice := _find_jump(ProgramCandidatePresenter.for_slot(career, program, 0, _rules()), "axel", 3)
	TestSupport.assert_equal(choice.band, "risky")
	TestSupport.assert_equal(choice.reason_codes.has("limited_training_evidence"), true)
	profile.proficiency.triple = 45.0
	profile.attempt_evidence.triple = {"attempts":100, "successes":5, "clean_successes":3}
	choice = _find_jump(ProgramCandidatePresenter.for_slot(career, program, 0, _rules()), "axel", 3)
	TestSupport.assert_equal(choice.band, "risky", "a few successes among many failed attempts are not stability")

func test_lower_rotation_remains_selectable() -> void:
	var career = Fixtures.starting_career(805)
	career.athlete.jumps.toe_loop.unlocked_rotations = 3
	var program = SkatingProgram.create("lower-toe", "short", [_jump("j", "toe_loop", 3)]).program
	var choice := _find_jump(ProgramCandidatePresenter.for_slot(career, program, 0, _rules()), "toe_loop", 2)
	TestSupport.assert_equal(choice.band != "unavailable", true)

func test_jump_candidate_bands() -> void:
	var career = Fixtures.starting_career(801)
	var profile = career.athlete.jumps.toe_loop
	profile.unlocked_rotations = 2
	profile.proficiency.double = 48.0
	profile.attempt_evidence.double = {"attempts":30, "successes":14, "clean_successes":6}
	profile.attempt_evidence.triple = {"attempts":12, "successes":2, "clean_successes":1}
	var program = SkatingProgram.create("candidate-short", "short", [_jump("jump-1", "toe_loop", 2)]).program
	var choices := ProgramCandidatePresenter.for_slot(career, program, 0, _rules())
	var double_choice := _find_jump(choices, "toe_loop", 2)
	var triple_choice := _find_jump(choices, "toe_loop", 3)
	var quad_choice := _find_jump(choices, "toe_loop", 4)
	TestSupport.assert_equal(double_choice.band, "stable")
	TestSupport.assert_equal(triple_choice.band, "risky")
	TestSupport.assert_equal(triple_choice.reason_codes.has("limited_training_evidence"), true)
	TestSupport.assert_equal(quad_choice.band, "unavailable")
	TestSupport.assert_equal(quad_choice.reason_codes.has("prerequisite_missing"), true)
	TestSupport.assert_equal(float(double_choice.base_value) > 0.0, true)

func test_repeat_conflict() -> void:
	var career = Fixtures.starting_career(802)
	career.athlete.jumps.toe_loop.unlocked_rotations = 3
	var program = SkatingProgram.create("repeat-free", "free", [
		_jump("jump-1", "toe_loop", 3), _jump("jump-2", "toe_loop", 3), _jump("jump-3", "salchow", 2),
	]).program
	var choices := ProgramCandidatePresenter.for_slot(career, program, 2, {
		"segment":"free", "label":"自由滑", "jump_min":3, "jump_max":3, "element_max":3,
		"repeat_limits":{"max_repeated_triples_or_quads":2},
		"season_start_year":2018,
	})
	var repeated := _find_jump(choices, "toe_loop", 3)
	TestSupport.assert_equal(repeated.band, "unavailable")
	TestSupport.assert_equal(repeated.reason_codes.has("repeat_limit"), true)

func test_non_jump_choices_have_no_target_level() -> void:
	var career = Fixtures.starting_career(803)
	var spin = ProgramElement.create("spin-1", "spin").element
	var steps = ProgramElement.create("steps-1", "step_sequence").element
	var program = SkatingProgram.create("non-jumps", "short", [spin, steps]).program
	var spin_choices := ProgramCandidatePresenter.for_slot(career, program, 0, _rules())
	var step_choices := ProgramCandidatePresenter.for_slot(career, program, 1, _rules())
	TestSupport.assert_equal(spin_choices.is_empty(), false)
	TestSupport.assert_equal(step_choices.is_empty(), false)
	for choice in spin_choices + step_choices:
		TestSupport.assert_equal(choice.has("target_level"), false)
		TestSupport.assert_equal(choice.group_id, "spins_steps")
	var jump_program = SkatingProgram.create("jump", "short", [_jump("j", "toe_loop", 1)]).program
	var jump_choices := ProgramCandidatePresenter.for_slot(career, jump_program, 0, _rules())
	TestSupport.assert_equal(jump_choices.all(func(choice): return choice.group_id == "jumps"), true)

func _rules() -> Dictionary:
	return {
		"segment":"short", "label":"短节目", "jump_min":1, "jump_max":1, "spin_min":0, "step_min":0,
		"element_max":1, "season_start_year":2018,
		"allowed_spin_codes":["CCoSp", "FCSp", "LSp", "FSSp", "CSp"],
	}

func _jump(element_id: String, jump_id: String, rotations: int):
	return ProgramElement.create(element_id, "jump", jump_id, rotations).element

func _find_jump(choices: Array[Dictionary], jump_id: String, rotations: int) -> Dictionary:
	for choice in choices:
		if str(choice.get("jump_id", "")) == jump_id and int(choice.get("rotations", 0)) == rotations:
			return choice
	return {}
