extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"only actual roster members can be highlighted","callable":test_roster},
		{"name":"previous meeting is chronological even when archive order changes","callable":test_order},
		{"name":"background events and duplicate archives are not extra player meetings","callable":test_meetings},
		{"name":"older meetings remain visible without counting unfinished or future races","callable":test_cross_season},
		{"name":"preparation and roster visibly recall a real meeting","callable":test_visible_meeting}]

func test_visible_meeting() -> void:
	var career = F.starting_career(1023)
	career.competition_archive.append(_archive("previous"))
	var panel = load("res://src/app/formal_competition_panel.tscn").instantiate()
	Engine.get_main_loop().root.add_child(panel)
	var session := {"event_id":"current","event":{"name":"这一站","ruleset_season_start_year":2019},"roster":[{"athlete_id":"player","name":"玩家","is_player":true},{"athlete_id":"peer","name":"老对手"}]}
	var before: Dictionary = career.to_dict()
	panel.present_session(session,career)
	T.assert_equal(panel.get_node("%RosterCount").text.contains("老对手"),true)
	var memory = panel.get_node("%RosterList").find_child("OpponentMemories",true,false)
	T.assert_equal(memory != null,true)
	if memory != null: T.assert_equal(memory.text.contains("你第2名，她第1名"),true)
	T.assert_equal(career.to_dict() == before,true)
	T.assert_equal(panel._session == session,true)
	panel.free()

func test_order() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(1022)
	var early := _archive("early")
	early.event.start_date = "2018-08-01"
	var later := _archive("later")
	later.event.start_date = "2018-12-01"
	career.competition_archive.append_array([later,early])
	var rows: Array = presenter.build(career,{"event_id":"current","ruleset_season_start_year":2019},[{"athlete_id":"peer","name":"队友"}])
	T.assert_equal(rows[0].previous_meeting.event_id,"later")

func _presenter():
	T.assert_equal(FileAccess.file_exists("res://src/presentation/opponent_context_presenter.gd"),true)
	return load("res://src/presentation/opponent_context_presenter.gd") if FileAccess.file_exists("res://src/presentation/opponent_context_presenter.gd") else null

func _archive(id: String, background: bool = false) -> Dictionary:
	return {"event_id":id,"season_id":"2018-19","world_only":background,"event":{"name":"上次比赛"},"final_standings":[{"athlete_id":"peer","rank":1,"total_score":125.0},{"athlete_id":"player","rank":2,"total_score":120.0}]}

func test_roster() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(1020)
	career.competition_archive.append(_archive("past"))
	var roster: Array = [{"athlete_id":"player","name":"玩家"},{"athlete_id":"other","name":"另一位"}]
	var before: Dictionary = career.to_dict()
	var rows: Array = presenter.build(career,{"event_id":"current","ruleset_season_start_year":2019},roster)
	T.assert_equal(rows.size(),1)
	T.assert_equal(rows[0].athlete_id,"other")
	T.assert_equal(rows[0].previous_meeting,{})
	T.assert_equal(career.to_dict(),before)
	T.assert_equal(roster.size(),2)

func test_meetings() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(1021)
	career.competition_archive.append_array([_archive("one"),_archive("one"),_archive("background",true)])
	var rows: Array = presenter.build(career,{"event_id":"current","ruleset_season_start_year":2019},[{"athlete_id":"player","name":"玩家"},{"athlete_id":"peer","name":"队友"}])
	T.assert_equal(rows.size(),1)
	T.assert_equal(rows[0].previous_meeting.event_id,"one")
	T.assert_equal(rows[0].previous_meeting.meetings,1)
	T.assert_equal(rows[0].previous_meeting.player_rank,2)
	T.assert_equal(rows[0].previous_meeting.opponent_rank,1)

func test_cross_season() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(1024)
	var future := _archive("future")
	future.season_id = "2021-22"
	future.event.end_date = "2021-12-03"
	var unfinished := _archive("unfinished")
	unfinished.status = "in_progress"
	career.competition_archive.append_array([future,unfinished,_archive("older")])
	var event := {"event_id":"current","ruleset_season_start_year":2021,"start_date":"2021-08-01"}
	var rows: Array = presenter.build(career,event,[{"athlete_id":"peer","name":"老对手"}])
	T.assert_equal(rows[0].previous_meeting.event_id,"older")
	T.assert_equal(rows[0].previous_meeting.meetings,1)
	T.assert_equal(rows[0].reason.contains("2018-19"),true)
