extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"season reflection excludes world only and other season results","callable":test_results},
		{"name":"season reflection remembers an actual offseason wish without rewards","callable":test_wish},
		{"name":"season summary recalls progress after changing training focus","callable":test_old_focus},
		{"name":"season close opens a factual reflection with a safe return","callable":test_visible_reflection}]

func test_old_focus() -> void:
	var career = F.starting_career(1063)
	var evidence := {"batch_id":"actual-practice","action":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":2}]},"action_id":"2T","attempts":5,"successes":2,"clean_successes":1,"failure_counts":{},"context":"practice","assessment_eligible":false,"clock":{"year":2018,"quarter":3}}
	T.assert_equal(load("res://src/simulation/repertoire_evidence_service.gd").record(career,evidence).ok,true)
	career.training_direction.focuses = []
	var report: Dictionary = _presenter().build(career,"2018-19")
	T.assert_equal(report.progress.size(),1)
	if not report.progress.is_empty(): T.assert_equal(report.progress[0].action_id,"2T")

func test_visible_reflection() -> void:
	var main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.active_career = F.starting_career(1064)
	var before: Dictionary = main.active_career.to_dict()
	main._present_season_node({"kind":"season_complete","closed_season_id":"2018-19"})
	T.assert_equal(main.summary_panel.summary_heading.text.contains("2018-19"),true)
	T.assert_equal(main.summary_panel.next_button.text,"回到生涯主页")
	T.assert_equal(main.active_career.to_dict() == before,true)
	main.free()

func _presenter():
	T.assert_equal(FileAccess.file_exists("res://src/presentation/season_reflection_presenter.gd"),true)
	return load("res://src/presentation/season_reflection_presenter.gd") if FileAccess.file_exists("res://src/presentation/season_reflection_presenter.gd") else null

func test_results() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(1061)
	career.competition_archive.append_array([
		{"event_id":"real","season_id":"2018-19","event":{"name":"玩家实际比赛"},"final_standings":[{"athlete_id":"player","rank":5,"total_score":120.0}]},
		{"event_id":"world","season_id":"2018-19","world_only":true,"final_standings":[{"athlete_id":"player","rank":1}]},
		{"event_id":"other","season_id":"2019-20","final_standings":[{"athlete_id":"player","rank":1}]}])
	var report: Dictionary = presenter.build(career,"2018-19")
	T.assert_equal(report.competition.size(),1)
	T.assert_equal(report.competition[0].event_id,"real")
	T.assert_equal(report.competition[0].rank,5)

func test_wish() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(1062)
	career.event_ledger.append({"kind":"offseason_choice","id":"offseason:2019:2","choice_id":"challenge","response":"想完成一直惦记的动作","clock":{"year":2019,"quarter":3}})
	var before: Dictionary = career.to_dict()
	var report: Dictionary = presenter.build(career,"2019-20")
	T.assert_equal(report.expectation.choice_id,"challenge")
	T.assert_equal(report.expectation.evidence_refs,["offseason:2019:2"])
	T.assert_equal(career.to_dict(),before)
