extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/first_meaning_fixtures.gd")
const Broadcast = preload("res://src/presentation/competition_broadcast_builder.gd")
const KC = preload("res://src/presentation/kiss_and_cry_builder.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"triple Axel meaning appears only after its played timestamp without announcing a milestone","callable":reveal},
		{"name":"kiss and cry distinguishes segment provisional and final placement","callable":placement}]

func reveal() -> void:
	var record: Dictionary = F.archive().free_results.player
	record.route_execution = {"action_anchors":[{"element_id":"axel","part_index":0,"progress":0.8}]}
	var timeline := Broadcast.build(record,0.0,80.0)
	T.assert_equal(Broadcast.frame_at(timeline,0.2).get("meaning_cue",""),"")
	var frame := Broadcast.frame_at(timeline,0.81)
	T.assert_equal(str(frame.get("meaning_cue","")).contains("3A"),true,"played attempt must connect to its significance")
	T.assert_equal(str(frame.get("meaning_cue","")).contains("首次完成"),false,"replay frames cannot grant first-ever milestone")
	T.assert_equal(Broadcast.frame_at(timeline,0.2).revealed_elements.size(),0)

func placement() -> void:
	var record: Dictionary = F.archive().free_results.player
	var segment: Dictionary = KC.build(null,record,{"current_rank":3,"ranking_scope":"segment"})
	T.assert_equal(segment.get("rank_label",""),"本段第3名")
	var provisional: Dictionary = KC.build(null,record,{"current_rank":3,"ranking_scope":"provisional"})
	T.assert_equal(provisional.get("rank_label",""),"暂列第3名")
	T.assert_equal(provisional.revealed_athlete_reaction.contains("奖牌"),false)
	var final: Dictionary = KC.build(null,record,{"current_rank":3,"ranking_scope":"final"})
	T.assert_equal(final.get("rank_label",""),"最终第3名")
