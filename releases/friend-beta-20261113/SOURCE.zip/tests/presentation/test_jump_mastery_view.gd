extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const JumpProfile = preload("res://src/domain/jump_profile.gd")
const JumpMasteryView = preload("res://src/presentation/jump_mastery_view.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "mastery stage and success range are separate", "callable": test_mastery_and_success_are_separate},
		{"name": "success estimate never reaches one hundred", "callable": test_success_estimate_never_reaches_one_hundred},
		{"name": "unobserved technique flaws remain hidden", "callable": test_unobserved_flaws_remain_hidden},
	]

func test_mastery_and_success_are_separate() -> void:
	var profile = JumpProfile.create("lutz")
	profile.unlocked_rotations = 1
	profile.attempts = 80
	profile.proficiency.single = 20.0
	profile.attempt_evidence.single.attempts = 40
	profile.attempt_evidence.single.successes = 20
	profile.attempt_evidence.single.clean_successes = 8
	var fresh := JumpMasteryView.describe(profile, {"acute_fatigue": 0.0})
	var tired := JumpMasteryView.describe(profile, {"acute_fatigue": 100.0})
	TestSupport.assert_equal(fresh.stage, "已形成训练基础，仍需巩固")
	TestSupport.assert_equal(fresh.stage_id, "training_stable")
	TestSupport.assert_equal(tired.stage, fresh.stage)
	TestSupport.assert_equal(int(tired.success_max) < int(fresh.success_max), true)

func test_success_estimate_never_reaches_one_hundred() -> void:
	var profile = JumpProfile.create("flip")
	profile.unlocked_rotations = 4
	profile.attempts = 10000
	profile.proficiency.single = 100.0
	profile.consistency.training = 100.0
	profile.consistency.internal = 100.0
	profile.consistency.official = 100.0
	profile.attempt_evidence.quad.attempts = 100
	profile.attempt_evidence.quad.successes = 80
	profile.attempt_evidence.quad.clean_successes = 60
	var view := JumpMasteryView.describe(profile, {"acute_fatigue": 0.0})
	TestSupport.assert_equal(int(view.success_max) <= 97, true)

func test_unobserved_flaws_remain_hidden() -> void:
	var profile = JumpProfile.create("lutz")
	profile.unlocked_rotations = 1
	profile.attempts = 40
	profile.takeoff.edge_quality = 0.0
	var hidden := JumpMasteryView.describe(profile, {})
	TestSupport.assert_equal(hidden.issue_text, "尚未识别明确技术问题")
	profile.observations.append({"source": "coach", "key": "wrong_edge", "confidence": 0.8})
	var revealed := JumpMasteryView.describe(profile, {})
	TestSupport.assert_equal(revealed.issue_text.contains("错刃"), true)
