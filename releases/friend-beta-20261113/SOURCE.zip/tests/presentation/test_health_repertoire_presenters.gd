extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"new career weapon view includes real opening completions without inventing batches","callable":opening_records},{"name":"health and repertoire inspection is read only","callable":read_only}]

func opening_records() -> void:
	var career = F.starting_career(3401)
	var before: Dictionary = career.to_dict()
	var view: Dictionary = load("res://src/presentation/repertoire_presenter.gd").build(career)
	T.assert_equal(view.rows.is_empty(),false,"known opening singles must not disappear from the weapon view")
	T.assert_equal(career.to_dict(),before)
	T.assert_equal(view.rows.any(func(row): return str(row.detail).contains("不代表比赛稳定")),true)

func read_only() -> void:
	var career = F.formal_junior_career(3402)
	career.condition_state.function_limits = {"landing":{"blocked":true,"review_condition":"落冰复评"}}
	var before: Dictionary = career.to_dict()
	var health: Dictionary = load("res://src/presentation/health_presenter.gd").build(career)
	load("res://src/presentation/repertoire_presenter.gd").build(career)
	T.assert_equal(health.rows.any(func(row): return str(row.label).contains("暂停相关动作")),true)
	T.assert_equal(career.to_dict(),before)
