extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const QuarterTrainingSummary = preload("res://src/presentation/quarter_training_summary.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "breakthroughs precede numeric details", "callable": test_breakthroughs_precede_numeric_details},
		{"name": "stage batches aggregate into one action", "callable": test_stage_batches_aggregate_into_one_action},
		{"name": "near breakthrough localizes evidence gaps", "callable": test_near_breakthrough_localizes_gaps},
		{"name": "body load appears as cost", "callable": test_body_load_appears_as_cost},
		{"name": "roadmap forecast shift is meaningful", "callable": test_roadmap_forecast_shift},
		{"name": "hidden flaws never appear", "callable": test_hidden_flaws_never_appear},
	]

func test_breakthroughs_precede_numeric_details() -> void:
	var entries := [{"category": "jump_milestone", "signature": "first_jump_success:toe_loop:2", "jump_id": "toe_loop", "rotations": 2}, {"category": "jump_attempt_batch", "jump_id": "toe_loop", "rotations": 2, "attempts": 12, "successes": 1}]
	var result := QuarterTrainingSummary.build(Fixtures.starting_career(301), entries)
	TestSupport.assert_equal(result.breakthroughs[0].contains("首次完成"), true)
	TestSupport.assert_equal(result.details.is_empty(), false)

func test_stage_batches_aggregate_into_one_action() -> void:
	var entries := [{"category": "jump_attempt_batch", "jump_id": "lutz", "rotations": 2, "attempts": 8, "successes": 2, "falls": 1}, {"category": "jump_attempt_batch", "jump_id": "lutz", "rotations": 2, "attempts": 10, "successes": 3, "falls": 2}]
	var result := QuarterTrainingSummary.build(Fixtures.starting_career(302), entries)
	TestSupport.assert_equal(result.details.size(), 1)
	TestSupport.assert_equal(result.details[0].contains("尝试18次"), true)

func test_near_breakthrough_localizes_gaps() -> void:
	var entries := [{"category": "jump_stage", "jump_id": "salchow", "rotations": 2, "stage_id": "occasional", "gaps": ["needs_recent_successes", "needs_landing_control"]}]
	var result := QuarterTrainingSummary.build(Fixtures.starting_career(303), entries)
	TestSupport.assert_equal(result.near_breakthroughs[0].contains("近期成功次数"), true)
	TestSupport.assert_equal(result.near_breakthroughs[0].contains("落冰控制"), true)

func test_body_load_appears_as_cost() -> void:
	var entries := [{"category": "body", "target": "ankle_load", "delta": 4.0, "cause_codes": ["training_load"]}]
	var result := QuarterTrainingSummary.build(Fixtures.starting_career(304), entries)
	TestSupport.assert_equal(result.costs[0].contains("踝部负荷"), true)

func test_roadmap_forecast_shift() -> void:
	var entries := [{"category": "roadmap_progress", "status_change": {"from": "on_track", "to": "slightly_behind"}, "forecast_change": [{"milestone": 0, "from_age": 10, "to_age": 11}]}]
	var result := QuarterTrainingSummary.build(Fixtures.starting_career(305), entries)
	TestSupport.assert_equal(result.roadmap[0].contains("轻微落后"), true)
	TestSupport.assert_equal(result.roadmap[0].contains("11岁"), true)

func test_hidden_flaws_never_appear() -> void:
	var career := Fixtures.starting_career(306)
	career.athlete.jumps.lutz.habits.rigidity = 90.0
	var text := JSON.stringify(QuarterTrainingSummary.build(career, []))
	TestSupport.assert_equal(text.contains("错刃"), false)
