extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Advance = preload("res://src/simulation/meaningful_advance_service.gd")
const Presenter = preload("res://src/presentation/training_period_presenter.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"late body costs survive ordinary progress limit","callable":test_late_body_costs}] + _existing_cases()

func _existing_cases() -> Array[Dictionary]:
	return [{"name":"executed stage report distinguishes saved practice from unfinished quarter","callable":test_partial_report},{"name":"training report preserves earned milestones and specific action progress", "callable":test_action_progress},{"name":"training period report states plan facts changes and stop", "callable":test_factual_report}, {"name":"training report localizes action names and omits empty zero-week progress","callable":test_localized_report}]

func test_partial_report() -> void:
	var career = F.starting_career(524)
	var report := Presenter.build(career,{"career":career,"elapsed_weeks":3,"stop_reason":"pending_action","facts":[{"kind":"training_stage","weeks_elapsed":3}]})
	T.assert_equal(JSON.stringify(report.changes).contains("已经保存"),true)
	T.assert_equal(JSON.stringify(report.changes).contains("没有被提前改写"),false)

func test_late_body_costs() -> void:
	var career = F.starting_career(525)
	var facts: Array = []
	for jump_id in ["toe_loop","salchow","loop","flip"]:
		facts.append({"kind":"state_change","target":jump_id+".single.proficiency","delta":1.0,"evidence_refs":["outcomes."+jump_id]})
	facts.append({"kind":"state_change","category":"body","target":"impact_load","delta":8.0,"evidence_refs":["outcomes.impact_load"]})
	facts.append({"kind":"state_change","category":"body","target":"acute_fatigue","delta":-4.0,"evidence_refs":["outcomes.acute_fatigue"]})
	var report := Presenter.build(career,{"career":career,"facts":facts,"stop_reason":"quarter_complete"})
	var text := JSON.stringify(report.changes)
	T.assert_equal(text.contains("冲击负荷变化+8.00"),true,"late physical costs must remain visible")
	T.assert_equal(text.contains("即时疲劳变化-4.00"),true,"late recovery must remain visible")
	T.assert_equal(text.contains("outcomes.impact_load"),true)
	T.assert_equal(text.contains("后内点冰跳单周熟练度"),false,"ordinary progress remains capped")

func test_action_progress() -> void:
	var career = F.starting_career(523)
	var facts: Array = [{"kind":"jump_milestone","jump_id":"toe_loop","rotations":2,"signature":"first_jump_success:toe_loop:2","evidence_refs":["history:milestone"]}]
	for id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		facts.append({"kind":"jump_attempts","jump_id":id,"rotations":2,"attempts":12,"successes":4,"evidence_refs":["history:batch"]})
	var report := Presenter.build(career,{"career":career,"facts":facts,"stop_reason":"quarter_complete"})
	var text := JSON.stringify(report.happened)
	T.assert_equal(text.contains("首次完成后外点冰跳双周"),true,"an earned first success must not disappear behind aggregate counts")
	T.assert_equal(text.contains("后内结环跳双周"),true,"a complete curriculum must still report specific actions")
	T.assert_equal(career.athlete.jumps.toe_loop.unlocked_rotations,1,"reporting cannot award progress")

func test_localized_report() -> void:
	var career = F.starting_career(522)
	var report := Presenter.build(career,{"career":career,"stop_reason":"quarter_complete","facts":[{"kind":"period_progress","text":"本次连续推进0周","evidence_refs":["training_period_state"]},{"kind":"jump_attempts","jump_id":"toe_loop","rotations":2,"attempts":7,"successes":3,"text":"toe_loop训练尝试7次、成功3次。","evidence_refs":["history.jump_attempt_batch"]}]})
	var text: String = JSON.stringify(report.happened)
	T.assert_equal(text.contains("后外点冰跳"),true)
	T.assert_equal(text.contains("双周"),true)
	T.assert_equal(text.contains("toe_loop"),false)
	T.assert_equal(text.contains("推进0周"),false)
	var batches: Array = []
	for index in range(24):
		batches.append({"kind":"jump_attempts","jump_id":["toe_loop","salchow","loop","flip","lutz","axel"][index%6],"attempts":6,"successes":4})
	var aggregate := Presenter.build(career,{"career":career,"facts":batches})
	T.assert_equal(JSON.stringify(aggregate.happened).contains("6类跳跃共尝试144次"),true,"count families, not repeated batches")
	var named := Presenter.build(career,{"career":career,"facts":[{"kind":"state_change","target":"toe_loop.single.proficiency","delta":3.61}]})
	T.assert_equal(JSON.stringify(named.changes).contains("后外点冰跳单周熟练度"),true)

func test_factual_report() -> void:
	var before = F.starting_career(521)
	var result := Advance.advance(before, Intent.create("accept").intent)
	var report: Dictionary = Presenter.build(before, result)
	for section in ["plan", "happened", "changes", "next_step"]:
		T.assert_equal(report.get(section, null) is Array, true)
		T.assert_equal(Array(report.get(section, [])).is_empty(), false, section)
	for line in report.plan + report.happened + report.changes + report.next_step:
		T.assert_equal(not str(line.get("text", "")).is_empty(), true)
		T.assert_equal(Array(line.get("evidence_refs", [])).is_empty(), false)
	T.assert_equal(JSON.stringify(report).contains("Dictionary"), false)
