extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")
const Fixtures = preload("res://tests/fixtures.gd")
const Presenter = preload("res://src/presentation/coach_handoff_presenter.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"opening coach statements remain brief and avoid implementation commentary", "callable":test_brief_copy},
		{"name": "every coach assessment statement cites career evidence", "callable": test_every_statement_has_evidence},
		{"name": "coach and history changes alter the handoff", "callable": test_handoff_reflects_career},
		{"name": "handoff never leaks private coach tendencies", "callable": test_no_private_tendency_leak},
	]

func test_brief_copy() -> void:
	var result = Presenter.build(Fixtures.starting_career(421))
	for section in ["existing_ability","known_risks","body_mind","first_plan"]:
		for statement in result[section]:
			var text := str(statement.text)
			TestSupport.assert_equal(text.length() <= 64,true,"coach paragraphs must fit narrow columns without becoming a manual: " + text)
			TestSupport.assert_equal(text.contains("不把一个季度等同于") or text.contains("不是固定性格标签") or text.contains("真实变化会在季度总结里说明"),false,"coach speech must discuss the athlete rather than defend the implementation")

func test_every_statement_has_evidence() -> void:
	var result: Dictionary = Presenter.build(Fixtures.starting_career(421))
	for section in ["existing_ability", "known_risks", "body_mind", "first_plan"]:
		TestSupport.assert_equal(result.get(section, null) is Array, true)
		TestSupport.assert_equal(Array(result.get(section, [])).is_empty(), false, "%s must not be empty" % section)
		for statement in result.get(section, []):
			TestSupport.assert_equal(not str(statement.get("text", "")).is_empty(), true)
			TestSupport.assert_equal(statement.get("evidence_refs", null) is Array, true)
			TestSupport.assert_equal(Array(statement.get("evidence_refs", [])).is_empty(), false)

func test_handoff_reflects_career() -> void:
	var first = Fixtures.starting_career(422)
	var second = Fixtures.starting_career(422)
	second.coach_assignment.coach_id = "coach_tang"
	second.coach_assignment.known_strengths.assign(["节目表现", "滑行连接"])
	second.pre_career_history.known_observations = ["勾手跳起跳刃需要继续观察。"]
	var first_result: Dictionary = Presenter.build(first)
	var second_result: Dictionary = Presenter.build(second)
	TestSupport.assert_equal(first_result.coach.name != second_result.coach.name, true)
	TestSupport.assert_equal(JSON.stringify(first_result) != JSON.stringify(second_result), true)
	TestSupport.assert_equal(JSON.stringify(second_result.known_risks).contains("勾手跳"), true)

func test_no_private_tendency_leak() -> void:
	var rendered := JSON.stringify(Presenter.build(Fixtures.starting_career(423)))
	for forbidden in ["technical_tendencies", "load_aggression", "lutz_edge_guidance", "psychological_attunement"]:
		TestSupport.assert_equal(rendered.contains(forbidden), false)
