extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures/connected_training_fixtures.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"coaching explanation shows the actual gap lesson and all family details","callable":proposal},
		{"name":"budget conflict cannot be described as completed gap practice","callable":conflict},
		{"name":"old agreed plan is not described as a new gap programme","callable":old_plan}]

func _service():
	var path := "res://src/presentation/coach_training_presenter.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"visible teaching explanation required")
	return load(path) if FileAccess.file_exists(path) else null

func proposal() -> void:
	var service = _service()
	if service == null: return
	var c = F.triple_gap(73501)
	var built = Coach.build(c,Intent.create("accept").intent)
	var output: Dictionary = service.proposal(c,built)
	T.assert_equal(output.headline.contains("后外点冰"),true)
	for text in ["后外点冰","后内结环","后外结环","后内点冰","勾手","阿克塞尔"]:
		T.assert_equal(output.detail.contains(text),true,text)
	T.assert_equal(output.headline.split("\n").size()<=2,true)

func conflict() -> void:
	var service = _service()
	if service == null: return
	var c = F.triple_gap(73502)
	var built = Coach.build(c,Intent.create("accept").intent)
	built.plan.coach_decision.allocated_gap_ids = []
	built.plan.coach_decision.reason_codes = ["gap_budget_unavailable"]
	var output: Dictionary = service.proposal(c,built)
	T.assert_equal(output.headline.contains("维护"),true)
	T.assert_equal(service.review([{"kind":"coach_training","decision":built.plan.coach_decision}]).is_empty(),true)

func old_plan() -> void:
	var service = _service()
	if service == null: return
	var c = F.starting(73503)
	var built = Coach.build(c,Intent.create("accept").intent)
	built.plan.coach_decision = {}
	T.assert_equal(service.proposal(c,built).headline.contains("原有"),true)
