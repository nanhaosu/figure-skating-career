extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const P = preload("res://src/presentation/season_target_presenter.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"target projection preserves unknown deadlines and frozen candidate evidence","callable":frozen_evidence},
		{"name":"empty target calendar is read only","callable":empty_calendar},
		{"name":"provisional championship candidates retain combined minimum and required event gaps","callable":provisional},
		{"name":"unrelated domestic targets cannot borrow JGP candidate rows","callable":unrelated_target},
		{"name":"board displays sporting eligibility separately from actual registration","callable":entry_availability},
		{"name":"season target command rejects unknown targets without changing career","callable":target_command},
	]

func unrelated_target() -> void:
	var career = F.starting_career(715)
	career.selection_state["decisions"] = {"jgp":{"decision":{"audit":{"candidate_rows":[{"athlete_id":"unrelated"}]}}}}
	T.assert_equal(P._competitors(career,{"event_id":"domestic","event_family":"national_championship"}),[])

func entry_availability() -> void:
	var options := [{"id":"enter","available":false,"reasons":["报名窗口尚未开放"],"costs":{"money":8},"deadline":"2025-01-01"}]
	var sections: Array = P._sections({"name":"测试目标"},{"eligible":true},[],[],[],options)
	T.assert_equal(str(sections[1].body).contains("当前无法提交报名"),true)
	T.assert_equal(str(sections[1].body).contains("报名窗口尚未开放"),true)
	var confirmed: Array = P._sections({"name":"测试目标"},{"eligible":true,"entry_status":"confirmed"},[],[],[],options)
	T.assert_equal(str(confirmed[1].body).contains("已完成报名"),true)

func target_command() -> void:
	var career = F.formal_junior_career(716)
	career.season_state.season_id = "2018-19"
	var before: Dictionary = career.to_dict().duplicate(true)
	var command = preload("res://src/simulation/career_command_service.gd")
	var rejected: Dictionary = command.apply(career,{"type":"set_season_target","event_id":"unknown"})
	T.assert_equal(rejected.ok,false)
	T.assert_equal(career.to_dict(),before)
	var accepted: Dictionary = command.apply(career,{"type":"set_season_target","event_id":F.u_series_event().event_id})
	T.assert_equal(accepted.ok,true)
	if accepted.ok: T.assert_equal(accepted.career.season_state.target_event_id,F.u_series_event().event_id)
	T.assert_equal(career.to_dict(),before)

func provisional() -> void:
	var career = F.starting_career(714)
	var bundle: Dictionary = preload("res://src/content/season_calendar_repository.gd").load_international_calendar(2025,"women_singles","senior")
	var target := {}
	for event in bundle.get("calendar",{}).get("events",[]):
		if event.get("event_id") == "isu_owg2026": target = event
	T.assert_equal(target.is_empty(),false)
	if target.is_empty(): return
	var policy: Dictionary = preload("res://src/simulation/international_personal_eligibility.gd").policy_for(target)
	var gate := {"senior_championship":{"audit":{"candidate_rows":[{"athlete_id":"rival","results":[],"personal":{"status":"unknown","tes":{},"reason_codes":[]}}]}}}
	var rows: Array = P._competitors(career,target,gate)
	T.assert_equal(rows[0].frozen,false)
	T.assert_equal(rows[0].source,"provisional_preview.isu_owg2026")
	var combined: Array = rows[0].gaps.filter(func(gap):return gap.code == "combined_tes")
	T.assert_equal(combined.size(),1)
	T.assert_equal(combined[0].required,policy.minimum_combined_tes)
	T.assert_equal(combined[0].observed,null)
	T.assert_equal(P._senior_role("cn_nationals_2025","isu_owg2026").role,"required")
	T.assert_equal(P._deadlines({"application_deadline":"2025-01-01","application_deadline_game_policy":true})[0].source.begins_with("游戏政策"),true)

func frozen_evidence() -> void:
	var career = F.starting_career(712)
	career.selection_state["decisions"] = {"jgp": {"decision":{"audit":{"candidate_rows":[{"athlete_id":"rival","personal":{"status":"unknown","reason_codes":["short_tes_not_established"]}}]}}}}
	var before: Dictionary = career.to_dict().duplicate(true)
	var rows: Array = P._competitors(career,{"event_id":"jgp_test","event_family":"jgp_stage"})
	T.assert_equal(rows.size(),1)
	T.assert_equal(rows[0].gaps[0].status,"unknown")
	T.assert_equal(rows[0].source,"selection_state.decisions.jgp")
	T.assert_equal(P._deadlines({})[0].status,"unknown")
	T.assert_equal(career.to_dict(),before)

func empty_calendar() -> void:
	var career = F.starting_career(713)
	var before: Dictionary = career.to_dict().duplicate(true)
	var result: Dictionary = P.build(career,{"season_id":"unknown","events":[]},{})
	T.assert_equal(result.targets,[])
	T.assert_equal(result.eligibility.status,"unknown")
	T.assert_equal(career.to_dict(),before)

