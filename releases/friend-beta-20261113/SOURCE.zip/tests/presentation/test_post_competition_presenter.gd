extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const PATH := "res://src/presentation/post_competition_presenter.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"short program elimination reports the recorded segment without inventing a zero total", "callable":test_short_elimination},
		{"name":"JGP aftermath reads committed series points not irrelevant domestic zero or an invented final qualification", "callable":test_jgp_points},
		{"name":"inconsistent historical score is shown as a record not a false equation","callable":test_inconsistent_score},
		{"name":"score explanation preserves actual segment arithmetic including domestic bonus", "callable":test_score_explanation},
		{"name":"post competition uses this event execution and excludes unrelated history", "callable":test_event_isolation},
		{"name":"formal competition report reads player rank execution and awarded points", "callable":test_formal_record},
		{"name":"post competition report accepts an ordinary loss without inventing a breakthrough", "callable":test_ordinary_loss},
		{"name":"post competition report keeps performance training consequences and next action auditable", "callable":test_sections_have_references},
	]

func test_short_elimination() -> void:
	var career = F.starting_career(208)
	var archive := {"event_id":"cut","player_result":{"short_rank":33,"short_score":18.22,"qualified":false},"short_results":{"player":{"score":{"tes":7.71,"pcs":10.51,"deductions":0.0,"total":18.22}}}}
	var before := JSON.stringify(archive)
	var report: Dictionary = _presenter().build(career,archive)
	T.assert_equal(str(report.performance.title).contains("第33名"),true)
	T.assert_equal(str(report.performance.text).contains("18.22"),true)
	T.assert_equal(str(report.performance.text).contains("未晋级"),true)
	T.assert_equal(str(report.performance.text).contains("总分 0.00"),false)
	T.assert_equal(JSON.stringify(archive),before,"presentation must not manufacture a free skate or rewrite the result")

func test_jgp_points() -> void:
	var career = F.starting_career(207)
	var archive := {"event_id":"isu_jgp_riga_2019","season_id":"2019-20","event":{"event_family":"jgp_stage","scope":"international"},"consequence_summary":{"domestic_points_awarded":0}}
	career.ranking_state = {"applied_events":{"2019-20:isu_jgp_riga_2019":{"jgp_points":13,"domestic_points":0}}}
	var before := JSON.stringify(career.to_dict())
	var text := str(_presenter().build(career,archive).consequences.text)
	T.assert_equal(text.contains("JGP") and text.contains("13"),true)
	T.assert_equal(text.contains("国内积分0"),false)
	T.assert_equal(text.contains("总决赛"),true)
	T.assert_equal(text.contains("已经入围"),false)
	career.ranking_state.applied_events.clear()
	var unknown := str(_presenter().build(career,archive).consequences.text)
	T.assert_equal(unknown.contains("13"),false,"missing receipt must not reconstruct points from imagined placement")
	T.assert_equal(unknown.contains("国内积分0"),false)
	career.ranking_state.applied_events["2019-20:isu_jgp_riga_2019"] = {"jgp_points":13,"domestic_points":0}
	T.assert_equal(JSON.stringify(career.to_dict()),before)

func test_inconsistent_score() -> void:
	var career = F.starting_career(206)
	var archive := {"event_id":"inconsistent","short_results":{"player":{"score":{"tes":30.0,"pcs":20.0,"deductions":1.0,"domestic_bonus":2.0,"total":60.0}}}}
	var report: Dictionary = _presenter().build(career,archive)
	T.assert_equal(report.scoring_guide.segments[0].get("arithmetic_matches",true),false)
	T.assert_equal(str(report.scoring_guide.text).contains("＝60.00"),false)
	T.assert_equal(report.scoring_guide.segments[0].total,60.0,"a presenter must not silently repair historical scores")

func test_score_explanation() -> void:
	var career = F.starting_career(205)
	var archive := {"event_id":"explain","short_results":{"player":{"score":{"tes":30.0,"pcs":20.0,"deductions":1.0,"domestic_bonus":2.0,"total":51.0,"element_scores":[{"actual_execution":{"abbreviation":"3T"},"base_value":4.2,"goe":-0.5,"total":3.7}]}}}}
	var report: Dictionary = _presenter().build(career,archive)
	T.assert_equal(report.has("scoring_guide"),true)
	if not report.has("scoring_guide"): return
	var segment: Dictionary = report.scoring_guide.segments[0]
	T.assert_equal(segment.tes,30.0)
	T.assert_equal(segment.pcs,20.0)
	T.assert_equal(segment.deductions,1.0)
	T.assert_equal(segment.domestic_bonus,2.0)
	T.assert_equal(segment.total,51.0)
	T.assert_equal(segment.example.action,"3T")
	T.assert_equal(segment.example.base_value,4.2)
	T.assert_equal(segment.example.goe,-0.5)
	T.assert_equal(segment.example.total,3.7)
	T.assert_equal(_presenter().build(career,{"event_id":"legacy"}).scoring_guide.segments,[])

func test_formal_record() -> void:
	var career = F.starting_career(204)
	var archive := {"event_id":"domestic-1","event":{"name":"国内赛","scope":"domestic","ranking_points_system":"domestic"},"player_result":{"final_rank":6,"total_score":123.0},"short_results":{"player":{"score":{"element_scores":[{"actual_execution":{"abbreviation":"3T","parts":[]},"goe":0.5}]}}},"consequence_summary":{"domestic_points_awarded":45}}
	var report: Dictionary = _presenter().build(career,archive)
	T.assert_equal(str(report.performance.title).contains("第6名"),true)
	T.assert_equal(str(report.training_evidence.text).contains("3T"),true)
	T.assert_equal(str(report.training_evidence.text).contains("abbreviation"),false,"nested actual execution must never be rendered as raw code")
	T.assert_equal(str(report.consequences.text).contains("45"),true)

func test_event_isolation() -> void:
	var career = F.starting_career(203)
	career.history.append({"category":"internal_competition","event_id":"other","summary":"不相关比赛获得奖励"})
	career.history.append({"category":"training","summary":"不相关训练首次四周"})
	var archive := _archive(career)
	archive.execution_scores = [{"element_scores":[{"actual_execution":"2T","goe":1.2},{"actual_execution":"2S","goe":-2.0}]}]
	archive.applied_resource_changes = {"ice_access":-2.0,"coach_attention":1.0}
	var report: Dictionary = _presenter().build(career,archive)
	var text := JSON.stringify(report)
	T.assert_equal(text.contains("不相关"),false,"summaries must not borrow unrelated history")
	T.assert_equal(str(report.training_evidence.text).contains("2T"),true)
	T.assert_equal(str(report.training_evidence.text).contains("2S"),true)
	T.assert_equal(str(report.consequences.text).contains("冰时"),true)
	T.assert_equal(career.history.size(),2,"viewing a summary cannot mutate career")

func _presenter():
	T.assert_equal(ResourceLoader.exists(PATH),true,"post competition needs a pure factual presenter")
	return load(PATH) if ResourceLoader.exists(PATH) else null

func _archive(career) -> Dictionary:
	return {
		"event_id":"club-teaching-1",
		"event_name":"俱乐部教学赛",
		"final_standings":[
			{"athlete_id":"peer-a","display_name":"队友甲","rank":1,"total_score":82.4},
			{"athlete_id":"player","display_name":career.athlete.display_name,"is_player":true,"rank":4,"total_score":61.2},
		],
		"player_result":{"rank":4,"total_score":61.2,"short_score":23.0,"free_score":38.2},
	}

func test_ordinary_loss() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(201)
	var report: Dictionary = presenter.build(career,_archive(career))
	T.assert_equal(report.performance.title.contains("第4名"),true)
	T.assert_equal(report.performance.text.contains("冠军"),false)
	T.assert_equal(report.performance.text.contains("突破"),false)
	T.assert_equal(report.next_action.id,"return_home")

func test_sections_have_references() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(202)
	career.history.append({"category":"jump_attempt_batch","record_id":"training-202","summary":"赛前训练完成"})
	career.history.append({"category":"internal_competition","record_id":"result-202","summary_key":"内部赛第4名"})
	var report: Dictionary = presenter.build(career,_archive(career))
	for key in ["performance","training_evidence","consequences","next_action"]:
		T.assert_equal(report.has(key),true)
		T.assert_equal(Array(report[key].evidence_refs).is_empty(),false,"%s needs record references" % key)
