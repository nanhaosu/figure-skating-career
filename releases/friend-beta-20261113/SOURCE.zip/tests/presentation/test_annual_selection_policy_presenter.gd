extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"annual adopted standards and target roles are season scoped and read only","callable":standards}]
func standards() -> void:
	var path := "res://src/presentation/annual_selection_policy_presenter.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"annual policy projection missing")
	if not FileAccess.file_exists(path): return
	var c = F.starting_career(1821)
	c.clock.year = 2019; c.clock.quarter = 1
	var calendar := {"season_id":"2018-19","events":[{"event_id":"cn_national_championships_2018","scope":"domestic"},{"event_id":"cn_grand_prix_u_series_2018","scope":"domestic"},{"event_id":"cn_club_league_2018_stage_1","scope":"domestic"},{"event_id":"extra","scope":"domestic"},{"event_id":"isu_world_junior_2019","event_family":"world_junior"},{"event_id":"isu_jgp_bratislava_2018","event_family":"jgp_stage"},{"event_id":"final","event_family":"jgp_final"},{"event_id":"unknown","scope":"international"}]}
	var before := JSON.stringify(c.to_dict())
	var p = load(path)
	var result: Dictionary = p.build(c,calendar)
	T.assert_equal(result.season_start_year,2018)
	T.assert_equal(result.event_roles.cn_national_championships_2018.world_junior.role,"required")
	T.assert_equal(result.event_roles.cn_grand_prix_u_series_2018.world_junior.role,"required")
	T.assert_equal(result.event_roles.cn_club_league_2018_stage_1.jgp.role,"countable")
	T.assert_equal(result.event_roles.cn_club_league_2018_stage_1.world_junior.role,"optional")
	T.assert_equal(result.event_roles.extra.jgp.role,"optional")
	T.assert_equal(result.target_standards.isu_jgp_bratislava_2018.covered,true)
	T.assert_equal(result.target_standards.final.covered,false)
	T.assert_equal(result.target_standards.unknown.covered,false)
	T.assert_equal(result.announcements.contains("70%"),true)
	T.assert_equal(result.announcements.contains("非官方"),true)
	T.assert_equal(p.build(c,{"season_id":"unknown","events":calendar.events}).target_standards.isu_world_junior_2019.covered,false)
	T.assert_equal(p.build(c,{"season_id":"2050-51","events":calendar.events}).target_standards.isu_world_junior_2019.covered,false)
	T.assert_equal(p.build(c,calendar),result)
	var clone = load("res://src/domain/career_state.gd").from_dict(c.to_dict())
	T.assert_equal(p.build(clone,calendar),result)
	T.assert_equal(JSON.stringify(c.to_dict()),before)

	var senior_calendar := {"season_id":"2021-22","events":[{"event_id":"isu_fc2022","scope":"international"},{"event_id":"isu_wc2022","scope":"international"},{"event_id":"senior_unknown","event_family":"senior_championship","scope":"international"}]}
	var senior: Dictionary = p.build(c,senior_calendar)
	var service = load("res://src/simulation/senior_championship_service.gd")
	T.assert_equal(senior.target_standards.isu_fc2022.public_formula,service.FOUR_CONTINENTS_FORMULA)
	T.assert_equal(senior.target_standards.isu_wc2022.public_formula,service.NEXT_WORLDS_FORMULA)
	T.assert_equal(senior.target_standards.senior_unknown.covered,false)
	var spoof: Dictionary = p.build(c,{"season_id":"2018-19","events":[{"event_id":"unknown","event_family":"world_junior"}]})
	T.assert_equal(spoof.target_standards.unknown.covered,false)
	var journey = load("res://src/app/season_journey_presenter.gd").build(c,calendar,{"entries":{}})
	T.assert_equal(journey.events_by_id.cn_national_championships_2018.policy_roles,result.event_roles.cn_national_championships_2018)

	for invalid in ["unknown","2018-99","2018-19extra","2018/19","2018-20"]:
		var invalid_result: Dictionary = p.build(c,{"season_id":invalid,"calendar_year":2018,"events":calendar.events})
		T.assert_equal(invalid_result.target_standards.isu_world_junior_2019.covered,false,"invalid explicit season cannot acquire calendar-year formula: "+invalid)
