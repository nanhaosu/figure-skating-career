extends RefCounted
const T=preload("res://tests/test_support.gd")
const F=preload("res://tests/fixtures.gd")
func cases() -> Array[Dictionary]:
	return [{"name":"preparation reports target rule gaps without rewriting programme","callable":rule_gaps},{"name":"upgrade comparison preserves actual revision costs and labels unweighted value","callable":upgrade_comparison},{"name":"real target programme upgrade confirms under its event rules instead of old internal format","callable":target_upgrade},{"name":"missing programme still exposes target checks and early editor","callable":missing_editor}]
func rule_gaps():
	var c=F.formal_junior_career(972)
	c.season_state.season_id="2018-19"
	c.competition_timeline.mode="dated"
	c.competition_timeline.date="2018-07-01"
	c.competition_timeline.origin_date="2018-07-01"
	c.competition_timeline.quarter_progress=1
	c.active_programs.free.elements.pop_back()
	var before: Dictionary=c.to_dict().duplicate(true)
	var p: Dictionary=load("res://src/simulation/preparation_route_service.gd").preview(c,F.u_series_event(),"programme")
	T.assert_equal(p.ok,true)
	T.assert_equal(p.has("programme_checks"),true,"actual target-rule checks required")
	if p.has("programme_checks"): T.assert_equal(p.programme_checks.free.errors.is_empty(),false)
	T.assert_equal(c.to_dict(),before)
func upgrade_comparison():
	var presenter=load("res://src/presentation/program_upgrade_presenter.gd")
	T.assert_equal(presenter!=null,true,"upgrade comparison presenter required")
	if presenter==null:return
	var c=F.formal_junior_career(973)
	c.active_programs.free.whole_run_familiarity=90.0
	var old: Dictionary=c.active_programs.free.duplicate(true)
	var edited=preload("res://src/domain/skating_program.gd").from_dict(old)
	for e in edited.elements:
		if e.kind=="jump" and e.jump_id=="axel":e.rotations=3;break
	var revision: Dictionary=preload("res://src/simulation/program_draft_service.gd").save_draft(preload("res://src/domain/skating_program.gd").from_dict(old),edited)
	var proposal: Dictionary={"segment":"free","programs":{"free":edited.to_dict()},"changed":true}
	var before: Dictionary=c.to_dict().duplicate(true)
	var p: Dictionary=presenter.build(c,proposal)
	T.assert_equal(p.ok,true,str(p))
	if p.ok:
		T.assert_equal(p.base_value_delta,4.7)
		T.assert_equal(p.familiarity_after,revision.program.whole_run_familiarity)
		T.assert_equal(p.familiarity_after < p.familiarity_before,true,"real edited slot must cost familiarity")
		T.assert_equal(p.text.contains("未含"),true)
		T.assert_equal(p.text.contains("比赛"),true)
	T.assert_equal(c.to_dict(),before)

	# Verify tail-jump value as well as the changed solo Axel.
	edited.elements[1].combination_parts[0].rotations=3
	proposal.programs.free=edited.to_dict()
	var combination: Dictionary=presenter.build(c,proposal)
	T.assert_equal(combination.ok,true)
	if combination.ok:T.assert_equal(absf(float(combination.base_value_delta)-7.6)<0.001,true)
	T.assert_equal(c.to_dict(),before)


func target_upgrade():
	var c=F.formal_junior_career(974)
	c.clock.year=2022
	c.season_state.season_id="2022-23"
	c.season_state.target_event_id="isu_jgp_courchevel_2022"
	c.season_program_plan.season_id="2022-23"
	var bundle: Dictionary=preload("res://src/content/season_bundle_repository.gd").for_career(c)
	var event: Dictionary=bundle.calendar.events.filter(func(e):return e.event_id=="isu_jgp_courchevel_2022")[0]
	var resolved: Dictionary=preload("res://src/content/season_bundle_repository.gd").competition_for_career(c,event)
	var rules: Dictionary=resolved.rules.free.segment_rules
	var program=preload("res://src/simulation/program_draft_service.gd").legal_draft(c.athlete,"free",rules,{},c.seed).program
	for element in program.elements:
		if element.kind=="jump" and element.jump_id=="axel":element.rotations=2
	c.active_programs.free=program.to_dict()
	var action:={"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}
	var item: Dictionary=preload("res://src/domain/technical_repertoire.gd").entry(action)
	item.state="available";item.learned_history.ever_learned=true
	c.technical_repertoire.entries["3A"]=item
	c.season_program_plan.targets={"free":[{"action":action}]}
	var service=preload("res://src/simulation/program_upgrade_service.gd")
	var proposal: Dictionary=service.propose(c,"free",rules)
	T.assert_equal(proposal.changed,true,"a legal learned 3A upgrade exists under JGP rules")
	if not proposal.changed:return
	var changed_target=c.transaction_copy()
	changed_target.season_state.target_event_id="fictional_club_2022"
	var before: Dictionary=changed_target.to_dict().duplicate(true)
	T.assert_equal(service.apply(changed_target,proposal,"changed-target").ok,false,"target changed to incompatible rules must require a new review")
	T.assert_equal(changed_target.to_dict(),before)
	var accepted: Dictionary=service.apply(c,proposal,"target-rule-upgrade")
	T.assert_equal(accepted.ok,true,accepted.get("error",""))
	if not accepted.ok:return
	var main=load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	# Re-open from the original pre-upgrade layout with no prior decision.
	c.active_programs.free=program.to_dict()
	c.experience_state.suggestion_receipts.clear()
	c.event_ledger=c.event_ledger.filter(func(e):return e.get("kind")!="program_upgrade_decision")
	main.active_career=c
	main._review_program_upgrade()
	T.assert_equal(is_instance_valid(main._decision_dialog),true,"actual advice UI must use the target event rules too")
	main.queue_free();await Engine.get_main_loop().process_frame

func missing_editor():
	var c=F.formal_junior_career(975)
	c.season_state.season_id="2018-19"
	c.season_state.target_event_id=F.u_series_event().event_id
	c.active_programs.free={}
	var window=load("res://src/app/season_target_dialog.gd").new()
	Engine.get_main_loop().root.add_child(window)
	window.present(c,preload("res://src/content/season_bundle_repository.gd").for_career(c).calendar,{})
	T.assert_equal(window.find_child("PreparationEditFree",true,false).disabled,false,"route cannot be required before creating its prerequisite programme")
	T.assert_equal(window.find_child("TargetDetails",true,false).text.contains("自由滑目标规则检查"),true)
	window.queue_free();await Engine.get_main_loop().process_frame
