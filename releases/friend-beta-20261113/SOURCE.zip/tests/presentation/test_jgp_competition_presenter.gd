extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"JGP board uses published rounds without reranking or mutating career","callable":frozen_round},{"name":"JGP board distinguishes pending second start and legacy policy","callable":pending_and_legacy},{"name":"JGP target adds domestic section alongside international candidates","callable":target_integration},{"name":"JGP board separates official name entry from game confirmation","callable":deadline_sources},{"name":"JGP board distinguishes unstarted reserve and actual frozen-order replacement","callable":reserve_and_replacement},{"name":"pending JGP board includes preregistered domestic rivals without inventing first results","callable":pending_domestic_pool}]

func frozen_round() -> void:
	var career = F.starting_career(918)
	career.season_state["season_id"] = "2018-19"
	career.selection_state["jgp_second_start"] = {"season_id":"2018-19","policy":{"minimum_first_points":7},"first_assignments":{"rival":["first"],"player":["first"]},"reserved_event_ids":["second"],"rounds":[{"event_id":"second","cutoff":"2018-09-01","candidate_rows":[{"athlete_id":"rival","name":"对手","score":155.0,"points":9,"eligible":true,"reason_codes":[]},{"athlete_id":"player","name":"你","score":150.0,"points":7,"eligible":true,"reason_codes":[]}],"selected_ids":["rival"],"alternate_ids":["player"],"assignments":{"rival":["second"]}}]}
	var before: Dictionary = career.to_dict().duplicate(true)
	var presenter = load("res://src/presentation/jgp_competition_presenter.gd")
	T.assert_equal(presenter != null,true,"JGP domestic competition presenter exists")
	if presenter == null: return
	var board: Dictionary = presenter.build(career,{"season_id":"2018-19","events":[]},"second")
	T.assert_equal(board.rows[0].athlete_id,"rival")
	T.assert_equal(board.rows[0].status,"selected")
	T.assert_equal(board.rows[1].status,"alternate")
	T.assert_equal(board.rows[1].points,7)
	T.assert_equal(board.cutoff,"2018-09-01")
	career.world_athletes["rival"] = {"name":"改名","attributes":{"skating":1}}
	var after: Dictionary = presenter.build(career,{"season_id":"2018-19","events":[]},"second")
	T.assert_equal(after.rows,board.rows)
	career.world_athletes.erase("rival")
	T.assert_equal(career.to_dict(),before)

func pending_and_legacy() -> void:
	var career = F.starting_career(919)
	var presenter = load("res://src/presentation/jgp_competition_presenter.gd")
	if presenter == null: return
	var legacy: Dictionary = presenter.build(career,{"season_id":"2018-19","events":[]},"second")
	T.assert_equal(legacy.policy_status,"legacy")
	career.selection_state["jgp_second_start"] = {"season_id":"2018-19","policy":{"minimum_first_points":7},"first_assignments":{"player":["first"]},"reserved_event_ids":["second"],"rounds":[]}
	var before: Dictionary = career.to_dict().duplicate(true)
	var pending: Dictionary = presenter.build(career,{"season_id":"2018-19","events":[{"event_id":"second","nomination_deadline":"2018-09-01"}]},"second")
	T.assert_equal(pending.policy_status,"after_first")
	T.assert_equal(pending.rows[0].status,"pending")
	T.assert_equal(pending.rows[0].points,null)
	T.assert_equal(pending.reserved_event_ids,["second"])
	T.assert_equal(pending.section.body.contains("7"),true)
	T.assert_equal(career.to_dict(),before)

func target_integration() -> void:
	var career = F.starting_career(920)
	var target := {"event_id":"second","name":"测试JGP","event_family":"jgp_stage","scope":"international"}
	var board: Dictionary = preload("res://src/presentation/season_target_presenter.gd").build(career,{"season_id":"2018-19","events":[target]}, {},"second")
	T.assert_equal(board.has("jgp_competition"),true)
	T.assert_equal(board.sections.any(func(section):return str(section.heading).contains("国内JGP")),true)
	T.assert_equal(board.has("competitors"),true)


func deadline_sources() -> void:
	var career = F.starting_career(921)
	career.selection_state["jgp_second_start"] = {"season_id":"2022-23","policy":{"minimum_first_points":7},"first_assignments":{"player":["first"]},"reserved_event_ids":["second"],"pre_registered_ids":{"second":["player"]},"official_entry_deadlines":{"second":"2022-08-26"},"substitution_deadlines":{"second":"2022-09-21"},"rounds":[]}
	var board: Dictionary = load("res://src/presentation/jgp_competition_presenter.gd").build(career,{"season_id":"2022-23","events":[]},"second")
	T.assert_equal(board.get("official_entry_deadline"),"2022-08-26")
	T.assert_equal(board.cutoff,"2022-09-21")
	T.assert_equal(board.get("pre_registered_ids"),["player"])
	var game_board: Dictionary = load("res://src/presentation/jgp_competition_presenter.gd").build(career,{"season_id":"2022-23","events":[{"event_id":"second","application_deadline_game_policy":true}]},"second")
	T.assert_equal(str(game_board.section.body).contains("姓名报名截止（游戏设定，官方日期未核实）"),true)
	T.assert_equal(str(game_board.section.body).contains("官方姓名报名截止："),false,"a calendar game date cannot be promoted to an official archive")
	T.assert_equal(board.section.body.contains("已报名名单"),true)


func reserve_and_replacement() -> void:
	var career = F.starting_career(922)
	career.selection_state["jgp_second_start"] = {"season_id":"2022-23","policy":{"minimum_first_points":11},"first_assignments":{"player":["first"]},"reserved_event_ids":["second"],"rounds":[{"event_id":"second","cutoff":"2022-09-21","candidate_rows":[{"athlete_id":"player","name":"你","points":11,"score":150.0,"first_event_id":"first","eligible":true,"reason_codes":[]},{"athlete_id":"reserve","name":"候补","points":0,"score":0.0,"first_event_id":"","eligible":true,"reason_codes":["eligible_first_start_reserve"]}],"selected_ids":["player"],"alternate_ids":["reserve"],"assignments":{"player":["second"]}}]}
	career.selection_state["assignments"] = {"player":["first"],"reserve":["second"]}
	career.selection_state["jgp_replacements"] = [{"event_id":"second","removed_id":"player","promoted_id":"reserve"}]
	var before: Dictionary = career.to_dict().duplicate(true)
	var board: Dictionary = load("res://src/presentation/jgp_competition_presenter.gd").build(career,{"season_id":"2022-23","events":[]},"second")
	T.assert_equal(board.rows[0].status,"withdrawn")
	T.assert_equal(board.rows[1].status,"promoted")
	T.assert_equal(board.rows[1].athlete_id,"reserve")
	T.assert_equal(board.section.body.contains("未首发候补"),true)
	T.assert_equal(board.section.body.contains("首站 0.00"),false)
	T.assert_equal(board.section.body.contains("还差 11"),false)
	T.assert_equal(career.to_dict(),before)

func pending_domestic_pool() -> void:
	var career = F.starting_career(923)
	career.selection_state["decisions"] = {"jgp":{"decision":{"audit":{"candidate_rows":[{"athlete_id":"bench","name":"冻结候补","score":160.0},{"athlete_id":"player","name":"冻结选手","score":150.0},{"athlete_id":"not_registered","name":"未报名","score":140.0}]}}}}
	career.selection_state["jgp_second_start"] = {"season_id":"2022-23","policy":{"minimum_first_points":3,"label":"非官方游戏政策：本季首站前八；赛前3天国内确认。"},"first_assignments":{"player":["first"]},"reserved_event_ids":["second"],"pre_registered_ids":{"second":["player","bench"]},"rounds":[]}
	var before: Dictionary = career.to_dict().duplicate(true)
	var board: Dictionary = load("res://src/presentation/jgp_competition_presenter.gd").build(career,{"season_id":"2022-23","events":[]},"second")
	T.assert_equal(board.rows.size(),2)
	if board.rows.size() != 2: return
	T.assert_equal(board.rows[0].athlete_id,"bench")
	T.assert_equal(board.rows[0].display_name,"冻结候补")
	T.assert_equal(board.rows[0].get("domestic_score"),160.0)
	T.assert_equal(board.rows[0].points,null)
	T.assert_equal(board.rows[0].score,null)
	T.assert_equal(board.rows[1].athlete_id,"player")
	T.assert_equal(board.section.body.contains("首站赛果待公布"),true)
	T.assert_equal(board.section.body.contains("未首发候补"),true)
	T.assert_equal(board.section.body.contains("国内选拔依据 160.00"),true)
	T.assert_equal(board.section.body.contains("赛前3天"),true)
	T.assert_equal(career.to_dict(),before)
