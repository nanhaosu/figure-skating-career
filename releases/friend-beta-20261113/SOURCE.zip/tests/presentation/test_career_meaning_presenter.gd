extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"a real programme 3A remains relevant after player changes training focus","callable":program_axel},
		{"name":"public comparable junior results can support a strong debut without prescribing low rank","callable":strong_debut},
		{"name":"first JGP distinguishes application assignment and entry without invented odds","callable":jgp},
		{"name":"triple Axel expectation follows real training contexts without obliging artistic routes","callable":training},
		{"name":"public expectation is pure and never reads future competition performances","callable":pure},
		{"name":"uncertain historical JGP absence never proves a first appearance","callable":unknown_history},
		{"name":"closed JGP entry overrides a retained assignment","callable":closed_entry},
		{"name":"past season and already archived JGP never become upcoming","callable":stale_entry},
		{"name":"international outlook rejects domestic undated incomplete and incomparable results","callable":outlook_boundaries}]

func _presenter():
	var path := "res://src/presentation/career_meaning_presenter.gd"
	T.assert_equal(FileAccess.file_exists(path),true,"shared expectation presenter missing")
	return load(path) if FileAccess.file_exists(path) else null

func _career():
	var c = F.formal_junior_career(1820)
	c.clock.year = 2019; c.clock.quarter = 3; c.athlete.birth_year = 2006
	c.season_state.entry_plan = {"season_id":"2019-20","entries":{"isu_jgp_riga_2019":{"status":"proposed","available_adjustment_ids":["request_assignment"],"eligibility_snapshot":{"eligible":true}}}}
	return c

func jgp() -> void:
	var p = _presenter()
	if p == null: return
	var c = _career()
	T.assert_equal(p.build(c).jgp_stage,"candidate")
	c.selection_state.applications.test = {"event_id":"isu_jgp_riga_2019","route_id":"request_assignment"}
	T.assert_equal(p.build(c).jgp_stage,"applied")
	c.selection_state.assignments.player = ["isu_jgp_riga_2019"]
	T.assert_equal(p.build(c).jgp_stage,"assigned")
	c.season_state.entry_plan.entries.isu_jgp_riga_2019.status = "confirmed"
	T.assert_equal(p.build(c).jgp_stage,"entered")
	T.assert_equal(p.build(c).home.title.contains("首场"),true,"a genuinely new career retains its first-JGP expectation")
	var view: Dictionary = p.build(c,{"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage"},"roster":[]})
	T.assert_equal(view.pre_event.lines.size() <= 2,true)
	T.assert_equal(JSON.stringify(view).contains("尚难判断"),true,"no history means uncertainty, not a fixed low placement")
	c.athlete.birth_year = 2010
	T.assert_equal(p.build(c).home,{})

func training() -> void:
	var p = _presenter()
	if p == null: return
	var c = _career()
	c.season_state.entry_plan = {}
	T.assert_equal(p.build(c).training,{})
	c.training_direction.focuses = [{"id":"explore:3A","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}}]
	T.assert_equal(p.build(c).axel_stage,"preparation")
	c.technical_repertoire.entries["3A"] = {"learned_history":{"first_success_contexts":{"practice":{"batch_id":"known-practice"}}}}
	T.assert_equal(p.build(c).axel_stage,"practice")
	c.technical_repertoire.entries["3A"].learned_history.first_success_contexts.program_late = {"batch_id":"known-program"}
	T.assert_equal(p.build(c).axel_stage,"program_transfer")
	T.assert_equal(p.build(c).training.lines.size() <= 2,true)

func pure() -> void:
	var p = _presenter()
	if p == null: return
	var c = _career()
	var before := JSON.stringify(c.to_dict())
	var public_context := {"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage"},"roster":[]}
	var a: Dictionary = p.build(c,public_context)
	public_context.future_performance = {"winner":"player","3A":"success"}
	var b: Dictionary = p.build(c,public_context)
	T.assert_equal(a,b)
	T.assert_equal(JSON.stringify(c.to_dict()),before)

func strong_debut() -> void:
	var p = _presenter()
	if p == null: return
	var c = _career()
	c.competition_archive.append(_international_result())
	var context := {"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage","scoring_era_id":"isu_iqs_2018_plus","start_date":"2019-09-04"},"roster":[{"athlete_id":"player"},{"athlete_id":"rival"}]}
	T.assert_equal(JSON.stringify(p.build(c,context).pre_event).contains("争牌"),true,"same-era junior public results should not be discarded because event uses level_options")

func program_axel() -> void:
	var p = _presenter()
	if p == null: return
	var c = _career()
	c.training_direction.focuses = []
	c.active_programs.free.elements[0] = load("res://src/domain/program_element.gd").create("planned-axel","jump","axel",3).element.to_dict()
	var view: Dictionary = p.build(c,{"event":{"event_id":"domestic","event_family":"club_league"}})
	T.assert_equal(view.axel_stage,"preparation")
	T.assert_equal(view.pre_event.is_empty(),false)
	view = p.build(c,{"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage"}})
	T.assert_equal(" ".join(view.pre_event.lines).contains("3A"),true,"same-event JGP context must not crowd its planned 3A out of the visible expectation")

func unknown_history() -> void:
	for status in ["partial","unexamined"]:
		var c = _career()
		c.experience_state.milestone_history.status = status
		c.season_state.entry_plan.entries.isu_jgp_riga_2019.status = "confirmed"
		var text := JSON.stringify(_presenter().build(c,{"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage"}}))
		for unproven in ["首次","首场","首秀","第一次"]:
			T.assert_equal(text.contains(unproven),false,"unknown history is not evidence for "+unproven)

func closed_entry() -> void:
	for status in ["declined","withdrawn","completed"]:
		var c = _career()
		c.season_state.entry_plan.entries.isu_jgp_riga_2019.status = status
		c.selection_state.assignments.player = ["isu_jgp_riga_2019"]
		var view: Dictionary = _presenter().build(c,{"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage"}})
		T.assert_equal(view.home,{})
		T.assert_equal(view.jgp_stage,"none",status)

func stale_entry() -> void:
	var c = _career()
	c.season_state.entry_plan.entries.isu_jgp_riga_2019.status = "confirmed"
	c.clock.year = 2020
	T.assert_equal(_presenter().build(c).home,{},"previous-season confirmed entries must not become next event")
	c = _career()
	c.season_state.entry_plan.entries.isu_jgp_riga_2019.status = "confirmed"
	c.competition_archive.append(preload("res://tests/fixtures/first_meaning_fixtures.gd").archive())
	T.assert_equal(_presenter().build(c).home,{},"a compressed score index or full record already proves event is past")
	var text := JSON.stringify(_presenter().build(c,{"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage"}}).pre_event)
	T.assert_equal(text.contains("首秀"),false,"missing new index cannot erase archived participation")

func _international_result() -> Dictionary:
	return {"event_id":"earlier_international","status":"complete","record_eligibility":"isu_recognized","scoring_era_id":"isu_iqs_2018_plus","event":{"scope":"international","level_options":["junior"],"start_date":"2019-07-01"},"final_standings":[{"athlete_id":"player","total_score":180.0},{"athlete_id":"rival","total_score":175.0}]}

func outlook_boundaries() -> void:
	for variant in ["domestic","undated","future","incomplete","wrong_era","senior"]:
		var c = _career()
		var prior := _international_result()
		match variant:
			"domestic": prior.event.scope = "domestic"; prior.record_eligibility = "domestic_only"
			"undated": prior.event.erase("start_date")
			"future": prior.event.start_date = "2019-10-01"
			"incomplete": prior.status = "between_segments"
			"wrong_era": prior.scoring_era_id = "isu_iqs_pre2018"
			"senior": prior.event.level_options = ["senior"]
		c.competition_archive.append(prior)
		var context := {"event":{"event_id":"isu_jgp_riga_2019","event_family":"jgp_stage","scoring_era_id":"isu_iqs_2018_plus","start_date":"2019-09-04"},"roster":[{"athlete_id":"player"},{"athlete_id":"rival"}]}
		var text := JSON.stringify(_presenter().build(c,context).pre_event)
		T.assert_equal(text.contains("争牌的依据"),false,variant+" is not reliable international podium evidence")
