extends RefCounted

const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const PATH := "res://src/presentation/career_home_presenter.gd"

func cases() -> Array[Dictionary]:
	return [
		{"name":"career home identifies ordinary training as its one action", "callable":test_training},
		{"name":"career home makes a pending invitation the current event", "callable":test_invitation},
		{"name":"career home distinguishes formal preparation from the next event", "callable":test_preparation},
		{"name":"career home returns a completed competition through its result", "callable":test_post_competition},
		{"name":"career home recent changes remain factual and bounded", "callable":test_changed_states},
		{"name":"career home translates internal outcome keys into player-facing facts", "callable":test_localized_recent_facts},
		{"name":"career home navigation uses stable ids", "callable":test_navigation},
		{"name":"Beijing final decision is visible on existing home without another confirmation", "callable":test_beijing_decision},
	]

func _presenter():
	T.assert_equal(ResourceLoader.exists(PATH),true,"career home needs a pure presenter")
	return load(PATH) if ResourceLoader.exists(PATH) else null

func test_beijing_decision() -> void:
	var c = F.formal_junior_career(149)
	c.clock.year = 2022;c.clock.quarter = 1
	c.beijing_trial_series.status = "finalized"
	c.beijing_trial_series.player_choice = "enrolled"
	c.beijing_trial_series.finalization = {"status":"confirmed","selected_ids":["player"],"alternate_ids":[],"places":1,"decided_on":"2022-01-24","audit":[]}
	var view: Dictionary = _presenter().build(c)
	T.assert_equal(view.current_event.title.contains("入选北京冬奥"),true)
	T.assert_equal(view.current_event.detail.contains("1"),true)
	T.assert_equal(view.primary_action.has("confirmation_required"),false)
	c.beijing_trial_series.finalization.selected_ids = ["another"]
	c.beijing_trial_series.finalization.alternate_ids = ["player"]
	view = _presenter().build(c)
	T.assert_equal(view.current_event.title.contains("候补"),true)
	c.beijing_trial_series.finalization.alternate_ids = []
	view = _presenter().build(c)
	T.assert_equal(view.current_event.title.contains("未入选"),true)
	c.beijing_trial_series.status = "collecting";c.beijing_trial_series.finalization = {}
	c.event_ledger.append({"kind":"beijing_dispatch_checked","status":"pending","reason_codes":["country_quota_unknown"]})
	view = _presenter().build(c)
	T.assert_equal(view.current_event.title.contains("待核验"),true,"unknown is not a fabricated selection defeat")

func test_training() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var view: Dictionary = presenter.build(F.starting_career(101))
	T.assert_equal(view.primary_action.id,"open_training")
	T.assert_equal(view.current_event.kind,"training")
	T.assert_equal(view.has("secondary_action"),false,"the home must not compete with its one primary action")

func test_invitation() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(102)
	career.internal_invitation_state = {"status":"pending","event_id":"club-teaching-1","scheduled_week":8}
	var view: Dictionary = presenter.build(career)
	T.assert_equal(view.primary_action.id,"review_internal_invitation")
	T.assert_equal(view.current_event.kind,"invitation")
	T.assert_equal(Array(view.current_event.evidence_refs).is_empty(),false)

func test_preparation() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.formal_junior_career(103)
	career.season_state = {"next_event":{"event_id":"cn_u_series","name":"全国青年系列赛·第一站","week":10}}
	var view: Dictionary = presenter.build(career)
	T.assert_equal(view.primary_action.id,"open_season")
	T.assert_equal(view.current_event.kind,"preparation")
	T.assert_equal(view.next_event.id,"cn_u_series")

func test_post_competition() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.formal_junior_career(104)
	career.competition_state = {"kind":"formal","status":"complete","event_id":"cn_u_series","archive":{"event_id":"cn_u_series"}}
	var view: Dictionary = presenter.build(career)
	T.assert_equal(view.primary_action.id,"resume_competition")
	T.assert_equal(view.current_event.kind,"result")

func test_changed_states() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(105)
	for index in 5:
		career.history.append({"category":"training_fact","summary":"记录 %d" % index,"record_id":"fact-%d" % index})
	var view: Dictionary = presenter.build(career)
	T.assert_equal(view.changed_states.size() <= 3,true)
	T.assert_equal(view.recent_facts.size() <= 3,true)
	for row in view.recent_facts:
		T.assert_equal(Array(row.evidence_refs).is_empty(),false)

func test_localized_recent_facts() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = F.starting_career(107)
	career.history.append({"category":"body","target":"impact_load","delta":4.0,"summary_key":"impact_load_change"})
	career.history.append({"category":"body","target":"ankle_load","delta":-2.0,"summary_key":"ankle_load_change"})
	var facts: Array = presenter.build(career).recent_facts
	T.assert_equal(facts.size(),2)
	T.assert_equal(str(facts[0].text).contains("_"),false)
	T.assert_equal(str(facts[0].text),"踝部负荷有所回落")
	T.assert_equal(str(facts[1].text),"跳跃冲击负荷有所上升")

func test_navigation() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var ids := Array(presenter.build(F.starting_career(106)).navigation).map(func(row): return row.id)
	T.assert_equal(ids,["home","training","programs","season","records"])
