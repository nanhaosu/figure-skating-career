extends RefCounted

const T = preload("res://tests/test_support.gd")
const Builder = preload("res://src/presentation/competition_broadcast_builder.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name":"broadcast GOE matches renderer and invalid combo parts are visible", "callable":test_invalid_parts},
		{"name":"broadcast frames expose actual calls without future leakage", "callable":test_actual_frames},
		{"name":"broadcast building never mutates committed results", "callable":test_immutable},
	]

func test_invalid_parts() -> void:
	var record := _record()
	record.technical_review.final_elements[0].parts = [{"abbreviation":"3T", "info":[]}, {"abbreviation":"2T", "info":["*"]}]
	var shown: Dictionary = Builder.build(record, 0.0, 60.0).events[0].record
	T.assert_equal(shown.live_goe, shown.goe)
	T.assert_equal(shown.abbreviation, "3T+2T*")
	var single := {"abbreviation":"3Lz", "info":["e"], "parts":[{"abbreviation":"3Lz"}]}
	T.assert_equal(Builder.display_abbreviation(single), "3Lze")
	T.assert_equal(Builder.display_abbreviation({"abbreviation":"3T", "info":["REP"], "invalid_reason":"REP"}), "3T*")
	T.assert_equal(Builder.display_abbreviation({"abbreviation":"3T+2T", "parts":[{"abbreviation":"3T"},{"abbreviation":"2T", "invalid_reason":"REP"}]}), "3T+2T*")

func test_actual_frames() -> void:
	var record := _record(); var timeline := Builder.build(record,18.0,60.0)
	T.assert_equal(timeline.events[0].record.abbreviation,"3T")
	T.assert_equal(timeline.events[0].record.has("planned_abbreviation"),false)
	var frame := Builder.frame_at(timeline,0.45)
	T.assert_equal(frame.revealed_elements.size(),1)
	T.assert_equal(frame.revealed_elements[0].goe,-1.1)
	T.assert_equal(frame.running_tes,3.0)
	T.assert_equal(frame.has("future_elements"),false)

func test_immutable() -> void:
	var record := _record(); var before := JSON.stringify(record)
	var timeline := Builder.build(record,18.0,60.0)
	Builder.frame_at(timeline,1.0)
	T.assert_equal(JSON.stringify(record),before)

func _record() -> Dictionary:
	return {"segment":"short","performance":{"elements":[
		{"element_id":"first","kind":"jump","planned_abbreviation":"4T","abbreviation":"3T","base_value":4.1,"live_goe":-1.1,"status":"error"},
		{"element_id":"spin","kind":"spin","abbreviation":"CCoSp","base_value":3.0,"live_goe":0.4,"status":"success"},
	]},"technical_review":{"final_elements":[
		{"element_id":"first","abbreviation":"3T","base_value":4.1,"status":"error","call_confidence":"clear"},
		{"element_id":"spin","abbreviation":"CCoSp4","base_value":3.5,"status":"success","call_confidence":"clear"},
	]},"protocol":{"element_scores":[
		{"element_id":"first","goe":-1.1,"total":3.0},
		{"element_id":"spin","goe":0.7,"total":4.2},
	]},"route_execution":{"action_anchors":[
		{"element_id":"first","part_index":0,"progress":0.3,"x":0.2,"y":0.3},
		{"element_id":"spin","part_index":0,"progress":0.7,"x":0.7,"y":0.6},
	]}}
