extends RefCounted
const T = preload("res://tests/test_support.gd")
const F = preload("res://tests/fixtures.gd")
const E = preload("res://src/simulation/repertoire_evidence_service.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"one practice success is not stable or competition confirmed","callable":test_practice},
		{"name":"missing legacy context remains unknown","callable":test_unknown}]

func _presenter():
	T.assert_equal(FileAccess.file_exists("res://src/presentation/season_progress_presenter.gd"),true,"season progress consumer is missing")
	return load("res://src/presentation/season_progress_presenter.gd") if FileAccess.file_exists("res://src/presentation/season_progress_presenter.gd") else null

func _career():
	var career = F.starting_career(1004)
	career.training_direction.focuses = [{"id":"goal","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":2}]}}]
	return career

func test_practice() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = _career()
	var evidence: Dictionary = load("res://tests/simulation/test_repertoire_context_history.gd").new()._evidence("first")
	E.record(career,evidence)
	var before: Dictionary = career.to_dict()
	var report: Dictionary = presenter.build(career,"2018-19")
	T.assert_equal(report.focuses.size(),1)
	T.assert_equal(report.focuses[0].stage,"practice")
	T.assert_equal(career.technical_repertoire.entries["2T"].state,"training")
	T.assert_equal(career.to_dict(),before)

func test_unknown() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var career = _career()
	var item: Dictionary = load("res://src/domain/technical_repertoire.gd").entry(career.training_direction.focuses[0].target,true)
	item.state = "available"
	career.technical_repertoire.entries["2T"] = item
	var report: Dictionary = presenter.build(career,"2018-19")
	T.assert_equal(report.focuses[0].stage,"unknown")
	T.assert_equal(report.focuses[0].evidence_refs,[])
