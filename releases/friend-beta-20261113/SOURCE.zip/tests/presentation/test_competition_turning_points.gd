extends RefCounted
const T = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [{"name":"negative GOE and planned combo do not invent a lost combination","callable":test_no_invention},
		{"name":"recovery requires an actual completed following jump","callable":test_recovery},
		{"name":"repetition explanation requires the actual REP call","callable":test_repeat},
		{"name":"broadcast and post competition consume actual turning points without mutation","callable":test_consumers}]

func test_consumers() -> void:
	var segment := {"performance":{"elements":[{"element_id":"repeat","kind":"jump","abbreviation":"3T","status":"error"}]},"technical_review":{"final_elements":[{"element_id":"repeat","abbreviation":"3T","invalid_reason":"REP"}]}}
	var before := segment.duplicate(true)
	var timeline: Dictionary = load("res://src/presentation/competition_broadcast_builder.gd").build(segment,0,60)
	T.assert_equal(timeline.events[0].record.get("turning_point",{}).get("kind"),"repetition_invalid")
	var career = load("res://tests/fixtures.gd").starting_career(1105)
	var report: Dictionary = load("res://src/presentation/post_competition_presenter.gd").build(career,{"event_id":"this-event","short_results":{"player":segment}})
	T.assert_equal(report.training_evidence.text.contains("重复失效"),true)
	T.assert_equal(segment == before,true)

func _presenter():
	T.assert_equal(FileAccess.file_exists("res://src/presentation/competition_turning_point_presenter.gd"),true)
	return load("res://src/presentation/competition_turning_point_presenter.gd") if FileAccess.file_exists("res://src/presentation/competition_turning_point_presenter.gd") else null

func test_no_invention() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var rows: Array = presenter.build({"performance":{"elements":[{"element_id":"one","kind":"jump","planned_abbreviation":"3T+2T","abbreviation":"3T","live_goe":-1.0,"parts":[{"called_rotations":3,"actual":{"success":true,"fall":false}}]}]}})
	T.assert_equal(rows,[])

func test_recovery() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var element := {"element_id":"recover","kind":"jump","abbreviation":"3S+2T","recovery_decision":{"action_id":"recover"},"parts":[{"actual":{"success":true,"fall":false}},{"actual":{"success":true,"fall":false}}]}
	var rows: Array = presenter.build({"performance":{"elements":[element]}})
	T.assert_equal(rows.size(),1)
	T.assert_equal(rows[0].kind,"recovered_combination")
	element.parts.pop_back()
	T.assert_equal(presenter.build({"performance":{"elements":[element]}}),[])

func test_repeat() -> void:
	var presenter = _presenter()
	if presenter == null: return
	var segment := {"performance":{"elements":[{"element_id":"repeat","kind":"jump","abbreviation":"3T"}]},"technical_review":{"final_elements":[{"element_id":"repeat","invalid_reason":"REP"}]}}
	var rows: Array = presenter.build(segment)
	T.assert_equal(rows.size(),1)
	T.assert_equal(rows[0].kind,"repetition_invalid")
