extends RefCounted

static func popped_axel_archive() -> Dictionary:
	var a := archive("2A")
	var part: Dictionary = a.free_results.player.performance.elements[0].duplicate(true)
	part.erase("planned_abbreviation")
	part.actual = {"success":false,"fall":false,"error_type":"pop"}
	var call: Dictionary = a.free_results.player.technical_review.final_elements[0].duplicate(true)
	a.free_results.player.performance.elements = [{"element_id":"axel","kind":"jump","status":"review","planned_abbreviation":"3A","abbreviation":"2A","parts":[part],"actual":part.actual.duplicate(true)}]
	a.free_results.player.technical_review.final_elements = [{"element_id":"axel","abbreviation":"2A","parts":[call],"base_value":3.3,"info":[]}]
	return a

static func archive(code: String = "3A", overrides: Dictionary = {}) -> Dictionary:
	var part := {"element_id":"axel","kind":"jump","jump_id":"axel","planned_abbreviation":"3A","abbreviation":code,"base_value":8.0,"live_goe":-1.0,"actual":{"success":true,"fall":false},"facts":{"planned_rotations":3,"rotation_ratio":1.0,"fall":false,"connection_held":true}}
	var performance := {"elements":[part]}
	var rules: Dictionary = load("res://src/content/formal_scoring_repository.gd").load_catalog(2019,"women_singles").catalog
	var review: Dictionary = load("res://src/simulation/formal_technical_panel.gd").resolve(performance,rules,{}, {},73)
	# A popped jump is explicit actual evidence, not an inferred negative GOE.
	if code == "2A": review.final_elements[0].abbreviation = "2A"
	var record := {"segment":"free","performance":performance,"technical_review":review,"protocol":{"tes":30.0,"pcs":35.0,"deductions":0.0,"total":65.0}}
	var result := {"record_version":1,"status":"complete","event_id":"isu_jgp_riga_2019","season_id":"2019-20","event":{"event_family":"jgp_stage","scope":"international","name":"JGP里加站","start_date":"2019-09-04"},"player_result":{"final_rank":10,"total_score":140.0,"qualified":true,"falls":0},"short_results":{"player":{"performance":{"elements":[{"element_id":"short_first","kind":"jump","abbreviation":"2A","actual":{"success":true,"fall":false}}]}}},"free_results":{"player":record},"consequences_applied":false}
	result.merge(overrides,true)
	result.final_standings = [{"athlete_id":"player","rank":10,"total_score":140.0,"short_score":60.0,"free_score":80.0}]
	return result
