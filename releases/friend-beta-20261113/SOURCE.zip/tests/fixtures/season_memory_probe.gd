extends SceneTree

func _initialize() -> void:
	# This probe owns only this exact save family; repeated suite runs start fresh.
	for suffix in ["",".bak",".tmp"]:
		var path: String = "user://memory-probe.json"+suffix
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	var career = load("res://tests/fixtures.gd").formal_junior_career(8190)
	load("res://tests/fixtures.gd").set_competition_strength(career.athlete,96.0)
	var bundle = load("res://src/content/season_bundle_repository.gd").load_bundle(2018,"women_singles","junior")
	load("res://src/simulation/world_generation_service.gd").ensure_season(career,bundle,8190)
	var sim = load("res://src/simulation/formal_competition_simulator.gd")
	var event = bundle.calendar.events.filter(func(e): return e.event_id == "cn_grand_prix_u_series_2018")[0]
	career.competition_state = sim.create_session(career,event,career.active_programs,"balanced",201,34)
	career.competition_state = sim.complete_practice(career.competition_state,"accept")
	career.competition_state = sim.lock_short(career,career.competition_state)
	career.competition_state = sim.lock_free(career,career.competition_state,"keep")
	print("MEMORY event_complete=",OS.get_static_memory_peak_usage())
	var save = load("res://src/persistence/save_repository.gd")
	for i in 2:
		var save_started := Time.get_ticks_usec()
		var saved = save.save(career,"user://memory-probe.json")
		print("PERFORMANCE save_",i,"_ms=",float(Time.get_ticks_usec()-save_started)/1000.0)
		if not saved.ok: print("MEMORY save_error=",saved.errors); quit(1); return
		print("MEMORY save_",i,"=",OS.get_static_memory_peak_usage())
	var save_peak := OS.get_static_memory_peak_usage()
	var fingerprint := JSON.stringify(career.competition_archive).sha256_text()
	var load_started := Time.get_ticks_usec()
	var loaded = save.load_save("user://memory-probe.json")
	print("PERFORMANCE load_ms=",float(Time.get_ticks_usec()-load_started)/1000.0)
	print("MEMORY loaded=",OS.get_static_memory_peak_usage())
	if not loaded.ok or JSON.stringify(loaded.career.competition_archive).sha256_text() != fingerprint:
		print("MEMORY reload archive mismatch"); quit(1); return
	var peak := OS.get_static_memory_peak_usage()
	print("MEMORY peak_bytes=",peak," save_budget_bytes=",500*1024*1024," reload_budget_bytes=",700*1024*1024)
	quit(0 if save_peak <= 500*1024*1024 and peak <= 700*1024*1024 else 1)
