extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.is_empty():
		push_error("career_persistence_performance_probe requires a save path")
		quit(2)
		return
	var source_path := str(args[0])
	var repo = load("res://src/persistence/save_repository.gd")
	var started := Time.get_ticks_msec()
	var loaded: Dictionary = repo.load_save(source_path)
	var load_ms := Time.get_ticks_msec() - started
	if not loaded.ok:
		push_error("probe load failed: %s" % str(loaded.errors))
		quit(3)
		return
	var career = loaded.career
	started = Time.get_ticks_msec()
	var copied = career.transaction_copy()
	var copy_ms := Time.get_ticks_msec() - started
	started = Time.get_ticks_msec()
	var validation: String = repo._validate_payload({"save_version":repo.SAVE_VERSION,"saved_at_unix":0,"career":copied.serialization_view()},false)
	var command_validation_ms := Time.get_ticks_msec() - started
	started = Time.get_ticks_msec()
	var saved: Dictionary = repo.save(copied,"user://performance-probe.json",false)
	var save_ms := Time.get_ticks_msec() - started
	if saved.ok: copied.commit_from(load("res://src/domain/career_state.gd").from_dict(saved.canonical_state,true))
	started = Time.get_ticks_msec()
	var resaved: Dictionary = repo.save(copied,"user://performance-probe-second.json",false)
	var resave_ms := Time.get_ticks_msec() - started
	started = Time.get_ticks_msec()
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var advanced: Dictionary = load("res://src/simulation/career_command_service.gd").apply(career,{"type":"advance_quarter","bundle":bundle})
	var advance_ms := Time.get_ticks_msec() - started
	print("PERF load_ms=%d copy_ms=%d command_validation_ms=%d save_ms=%d resave_ms=%d advance_ms=%d advance_ok=%s advance_error=%s archive_count=%d world_count=%d bytes=%d validation=%s save_ok=%s" % [load_ms,copy_ms,command_validation_ms,save_ms,resave_ms,advance_ms,str(advanced.ok),str(advanced.get("error",advanced.get("stop_node",{}).get("kind",""))),career.competition_archive.size(),career.world_athletes.size(),FileAccess.get_file_as_bytes("user://performance-probe.json").size(),validation,str(saved.ok)])
	quit(0 if validation.is_empty() and saved.ok and resaved.ok else 1)
