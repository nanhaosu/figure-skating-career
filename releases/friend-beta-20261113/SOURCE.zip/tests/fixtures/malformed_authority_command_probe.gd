extends SceneTree

func _init() -> void:
	var career = preload("res://tests/fixtures.gd").starting_career(953)
	var plan = preload("res://tests/fixtures.gd").percentage_balanced_plan()
	var proposal = preload("res://src/simulation/authority_resolver.gd").preview(career, plan).to_dict()
	proposal.desired.shares.jump_toe_loop = {}
	var before: Dictionary = career.to_dict()
	var result = preload("res://src/simulation/career_command_service.gd").apply(career, {"type":"resolve_authority_conflict", "proposal":proposal, "conflict_id":"invalid", "response_id":"accept"})
	quit(0 if not result.ok and result.career == career and result.events.is_empty() and not result.error.is_empty() and career.to_dict() == before else 1)
