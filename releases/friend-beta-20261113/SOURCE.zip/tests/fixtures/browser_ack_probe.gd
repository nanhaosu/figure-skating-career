extends SceneTree
const F = preload("res://tests/fixtures.gd")
const Service = preload("res://src/persistence/browser_save_service.gd")
class HeldStorage extends RefCounted:
	signal completed(result: Dictionary)
	var waiting := false
	func begin() -> Dictionary: return {"ok":true,"errors":[]}
	func flush() -> Dictionary:
		waiting = true
		var acknowledged: Dictionary = await completed
		waiting = false
		return acknowledged
	func release() -> void: pass
var failures: Array[String] = []
var result: Dictionary = {}
func check(value: bool, message: String) -> void:
	if not value: failures.append(message)
func _initialize() -> void: run.call_deferred()
func save(main) -> void: result = await main.save_active_career()
func wait_for_flush(driver) -> void:
	for frame in 120:
		if driver.waiting: return
		await process_frame
	check(false,"prepared save must eventually request durable acknowledgement")
func run() -> void:
	var main = load("res://src/app/main.tscn").instantiate(); root.add_child(main)
	main.browser_saves = Service.new("user://held-ack-%d" % Time.get_ticks_usec())
	main.save_path = main.browser_saves.slot_path("manual-1")
	main.autosave_path = main.browser_saves.slot_path("autosave")
	main.active_career = F.starting_career(988); main.has_unsaved_changes = true
	var driver := HeldStorage.new(); main.browser_saves.durability = driver
	save(main)
	check(result.is_empty() and main.has_unsaved_changes,"manual save must remain dirty before acknowledgement")
	check(main.browser_saves.busy,"service must lock pending writes")
	var blocker = main.get_node_or_null("PersistenceWait")
	check(blocker != null and blocker.visible,"pending save must block competing UI actions")
	check(not (await main.browser_saves.load_slot("manual-1")).ok,"staged files cannot be loaded before acknowledgement")
	await wait_for_flush(driver)
	driver.completed.emit({"ok":false,"errors":["quota failure"]})
	check(not result.get("ok",true) and main.has_unsaved_changes,"failure must retain dirty career")
	check(not FileAccess.file_exists(main.save_path),"failed first save must restore absent target")
	result = {}; save(main)
	await wait_for_flush(driver)
	driver.completed.emit({"ok":true,"errors":[]})
	check(result.get("ok",false) and not main.has_unsaved_changes,"only successful ack clears dirty")
	check(result.get("career") == main.active_career,"durable success preserves SaveRepository result contract")
	main.has_unsaved_changes = true
	load("res://src/simulation/key_node_service.gd").add(main.active_career,"held-body","growth_warning","需要回应")
	var before: Dictionary = main.active_career.to_dict()
	main._on_key_node_response("held-body")
	check(main.active_career.to_dict() == before and main.has_unsaved_changes,"candidate must not publish while ack pending")
	await wait_for_flush(driver)
	driver.completed.emit({"ok":false,"errors":["quota failure"]})
	check(main.active_career.to_dict() == before and main.has_unsaved_changes,"body candidate remains retryable after failure")
	main._on_key_node_response("held-body")
	await wait_for_flush(driver)
	driver.completed.emit({"ok":true,"errors":[]})
	check(main.active_career.to_dict() != before and not main.has_unsaved_changes,"body retry publishes only on successful ack")
	main.free()
	for failure in failures: printerr("FAIL: ",failure)
	if failures.is_empty(): print("PASS: held persistence acknowledgement gates UI, publication, dirty state, rollback and retry")
	quit(0 if failures.is_empty() else 1)
