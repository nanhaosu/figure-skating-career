extends RefCounted

const TestSupport = preload("res://tests/test_support.gd")

func cases() -> Array[Dictionary]:
	return [
		{"name": "intentional failing case probe", "callable": test_intentional_failure},
	]

func test_intentional_failure() -> void:
	# A runner must not declare an asynchronous case passed before it resumes.
	await Engine.get_main_loop().process_frame
	TestSupport.assert_equal("actual", "expected")
