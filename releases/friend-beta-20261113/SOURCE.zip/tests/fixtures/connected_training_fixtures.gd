extends RefCounted

const F = preload("res://tests/fixtures.gd")

static func starting(seed: int):
	var career = F.starting_career(seed)
	F.clear_pre_career_load(career)
	career.internal_invitation_state.status = "completed"
	career.training_preferences.breakthrough_policy = "summary"
	return career

# Synthetic structural regression fixture, NOT natural training evidence.
static func triple_gap(seed: int):
	var career = starting(seed)
	career.clock.year = career.athlete.birth_year+13
	career.athlete.body.strength_readiness = 85.0
	career.athlete.body.joint_readiness = 85.0
	for key in ["air_axis","rotation_completion","landing_control"]:
		career.athlete.jump_foundation.set(key,85.0)
	for id in career.athlete.jumps:
		var jump = career.athlete.jumps[id]
		jump.unlocked_rotations = 3 if id in ["flip","lutz"] else 2
		jump.proficiency.double = 60.0
		jump.attempt_evidence.double = {"attempts":40,"successes":30,"clean_successes":20,"falls":0,"pops":0,"two_foot":0,"hand_down":0,"underrotated":0,"downgraded":0,"first_success_clock":{}}
		jump.air.axis = 85.0
		jump.landing.control = 85.0
	return career
