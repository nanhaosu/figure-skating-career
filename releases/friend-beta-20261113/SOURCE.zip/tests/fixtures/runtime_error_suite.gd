extends RefCounted

func cases() -> Array[Dictionary]:
	return [
		{"name": "intentional runtime error probe", "callable": test_intentional_runtime_error},
	]

func test_intentional_runtime_error() -> void:
	var missing_value: Variant = null
	missing_value.call("method_that_does_not_exist")
