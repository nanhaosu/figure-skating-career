class_name SaveMigrator
extends RefCounted

const SaveSchema = preload("res://src/persistence/save_schema.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const StoryContext = preload("res://src/domain/story_context.gd")
const CoachAssignment = preload("res://src/domain/coach_assignment.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")

const CURRENT_VERSION := SaveSchema.CURRENT_VERSION

static func to_current(payload: Dictionary) -> Dictionary:
	if not payload.has("save_version") or not _is_integer(payload.save_version):
		return _failure("存档版本必须是整数")
	var version := int(payload.save_version)
	if version > CURRENT_VERSION:
		return _failure("该存档来自尚不支持的版本：%d" % version)
	if version < 1:
		return _failure("该存档版本过低：%d" % version)
	var migrated := payload.duplicate(true)
	if version == 1:
		var migration_error := _migrate_v1_to_v2(migrated)
		if not migration_error.is_empty():
			return _failure(migration_error)
		version = 2
	if version == 2:
		var migration_error := _migrate_v2_to_v3(migrated)
		if not migration_error.is_empty():
			return _failure(migration_error)
		version = 3
	if version == 3:
		var migration_error := _migrate_v3_to_v4(migrated)
		if not migration_error.is_empty():
			return _failure(migration_error)
		version = 4
	if version == 4:
		var migration_error := _migrate_v4_to_v5(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 5
	if version == 5:
		var migration_error := _migrate_v5_to_v6(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 6
	if version == 6:
		var migration_error := _migrate_v6_to_v7(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 7
	if version == 7:
		var migration_error := _migrate_v7_to_v8(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 8
	if version == 8:
		var migration_error := _migrate_v8_to_v9(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 9
	if version == 9:
		var migration_error := _migrate_v9_to_v10(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 10
	if version == 10:
		var migration_error := _migrate_v10_to_v11(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 11
	if version == 11:
		var migration_error := _migrate_v11_to_v12(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 12
	if version == 12:
		var migration_error := _migrate_v12_to_v13(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 13
	if version == 13:
		var migration_error := _migrate_v13_to_v14(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 14
	if version == 14:
		var migration_error := _migrate_v14_to_v15(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 15
	if version == 15:
		var migration_error := _migrate_v15_to_v16(migrated)
		if not migration_error.is_empty(): return _failure(migration_error)
		version = 16
	if version == 16:
		if not migrated.get("career") is Dictionary: return _failure("存档字段 career 必须是对象")
		migrated.career.training_direction = preload("res://src/domain/training_direction.gd").empty()
		migrated.career.schema_version = 17
		migrated.save_version = 17
		version = 17
	if version == 17:
		if not migrated.get("career") is Dictionary: return _failure("存档字段 career 必须是对象")
		for item in migrated.career.get("technical_repertoire",{}).get("entries",{}).values():
			if item is Dictionary and item.get("learned_history") is Dictionary:
				# Old windows do not establish first-ever contexts. Preserve raw
				# evidence but start the new milestone history without inventing it.
				item.learned_history.first_success_contexts = {}
		migrated.career.schema_version = 18
		migrated.save_version = 18
		version = 18
	if version == 18:
		if not migrated.get("career") is Dictionary: return _failure("存档字段 career 必须是对象")
		migrated.career.experience_state = preload("res://src/domain/career_experience_state.gd").empty()
		migrated.career.schema_version = 19
		migrated.save_version = 19
		version = 19
	if version == 19:
		if not migrated.get("career") is Dictionary or not migrated.career.get("experience_state") is Dictionary: return _failure("旧档生涯体验状态无效")
		migrated.career.experience_state.milestones = {}
		migrated.career.experience_state.milestone_history = {"status":"unexamined","checked_archive_count":0}
		migrated.career.schema_version = 20
		migrated.save_version = 20
		version = 20
	if version == 20:
		if not migrated.get("career") is Dictionary: return _failure("存档字段 career 必须是对象")
		migrated.career.coach_training_state = preload("res://src/domain/coach_training_state.gd").defaults()
		migrated.career.schema_version = 21
		migrated.save_version = 21
		version = 21
	if version == 21:
		if not migrated.get("career") is Dictionary or not migrated.career.get("athlete") is Dictionary:
			return _failure("存档字段 career.athlete 必须是对象")
		# Missing old dates remain unknown; preserve supplied data for validation.
		if not migrated.career.athlete.has("birth_date"): migrated.career.athlete.birth_date = {}
		migrated.career.schema_version = 22
		migrated.save_version = 22
		version = 22
	if version == 22:
		if not migrated.get("career") is Dictionary: return _failure("存档字段 career 必须是对象")
		if not migrated.career.has("olympic_quota_state"): migrated.career.olympic_quota_state = preload("res://src/domain/olympic_quota_state.gd").empty()
		migrated.career.schema_version = 23
		migrated.save_version = 23
	return {"ok": true, "data": migrated, "errors": []}

static func _migrate_v15_to_v16(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	if not career.get("condition_state") is Dictionary: return "生涯字段 condition_state 必须是对象"
	if not career.has("season_program_plan"):
		career.season_program_plan = preload("res://src/domain/season_program_plan.gd").create("")
	if not career.has("technical_repertoire"):
		career.technical_repertoire = preload("res://src/domain/technical_repertoire.gd").migrate_legacy(career)
	career.condition_state.health_model_version = 1
	for field in ["function_limits","rehabilitation","pending_decision"]:
		if not career.condition_state.has(field): career.condition_state[field] = {}
	payload.save_version = 16
	career.schema_version = 16
	return ""

static func _migrate_v1_to_v2(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary:
		return "存档字段 career 必须是对象"
	if not payload.career.get("athlete") is Dictionary:
		return "存档字段 athlete 必须是对象"
	var athlete: Dictionary = payload.career.athlete
	var defaults := AthleteState.new().to_dict()
	var old_edge := 20.0
	if not athlete.get("technique") is Dictionary:
		return "生涯字段 athlete.technique 必须是对象"
	var technique: Dictionary = athlete.technique.duplicate(true)
	old_edge = float(technique.get("edge_control", old_edge))
	technique.erase("edge_control")
	athlete.technique = technique
	if athlete.has("skating") and not athlete.skating is Dictionary:
		return "生涯字段 athlete.skating 必须是对象"
	if athlete.has("jumps") and not athlete.jumps is Dictionary:
		return "生涯字段 athlete.jumps 必须是对象"
	var had_skating := athlete.get("skating") is Dictionary
	athlete.skating = Dictionary(athlete.get("skating", defaults.skating)).duplicate(true)
	athlete.skating.deep_edge = float(athlete.skating.get("deep_edge", old_edge)) if had_skating else old_edge
	athlete.jumps = Dictionary(athlete.get("jumps", defaults.jumps)).duplicate(true)
	for field_name in ["body", "mind", "resources"]:
		var values: Dictionary = Dictionary(athlete.get(field_name, {})).duplicate(true)
		for key in defaults[field_name]:
			if not values.has(key):
				values[key] = defaults[field_name][key]
		athlete[field_name] = values
	payload.save_version = 2
	payload.career.schema_version = 2
	return ""

static func _migrate_v2_to_v3(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary:
		return "存档字段 career 必须是对象"
	if not payload.career.get("history", []) is Array:
		return "生涯字段 history 必须是数组"
	for index in payload.career.history.size():
		var record = payload.career.history[index]
		if not record is Dictionary or record.get("category") != "quarter_plan":
			continue
		for layer in ["desired", "approved", "executed"]:
			if not record.get(layer) is Dictionary:
				return "生涯字段 history.%d.%s 必须是对象" % [index, layer]
			record["%s_shares" % layer] = _units_to_shares(record[layer])
			record["%s_jump_rotations" % layer] = _single_targets(record["%s_shares" % layer])
	payload.save_version = 3
	payload.career.schema_version = 3
	return ""

static func _migrate_v3_to_v4(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary or not payload.career.get("athlete") is Dictionary:
		return "存档字段 career.athlete 必须是对象"
	var athlete: Dictionary = payload.career.athlete
	if not athlete.get("jumps") is Dictionary:
		return "生涯字段 athlete.jumps 必须是对象"
	athlete.jump_foundation = {
		"takeoff_power": _jump_median(athlete.jumps, "air", "height", 25.0),
		"speed_conversion": _jump_median(athlete.jumps, "air", "distance", 25.0),
		"timing": _jump_median(athlete.jumps, "takeoff", "angle", 25.0),
		"air_axis": _jump_median(athlete.jumps, "air", "axis", 30.0),
		"air_tightness": _jump_median(athlete.jumps, "air", "tightness", 25.0),
		"spatial_awareness": _jump_median(athlete.jumps, "air", "rotation_speed", 25.0),
		"rotation_completion": _jump_median(athlete.jumps, "landing", "completion", 20.0),
		"landing_control": _jump_median(athlete.jumps, "landing", "control", 25.0),
		"landing_flow": _jump_median(athlete.jumps, "landing", "flow", 20.0),
	}
	payload.save_version = 4
	payload.career.schema_version = 4
	return ""

static func _migrate_v4_to_v5(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	payload.career.development_roadmap = {}
	payload.career.roadmap_revision_history = []
	payload.save_version = 5
	payload.career.schema_version = 5
	return ""

static func _migrate_v5_to_v6(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	payload.career.active_programs = {"short": {}, "free": {}}
	payload.career.program_archive = []
	payload.save_version = 6
	payload.career.schema_version = 6
	return ""

static func _migrate_v6_to_v7(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	payload.career.competition_state = {}
	payload.save_version = 7
	payload.career.schema_version = 7
	return ""

static func _migrate_v7_to_v8(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	if career.get("active_programs", {}) is Dictionary:
		for segment in ["short", "free"]:
			_add_route_defaults(career.active_programs.get(segment, {}))
	if career.get("program_archive", []) is Array:
		for program in career.program_archive:
			_add_route_defaults(program)
	payload.save_version = 8
	career.schema_version = 8
	return ""

static func _migrate_v8_to_v9(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary:
		return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	career.story_context = StoryContext.women_singles_2014("CHN").to_dict()
	career.random_streams = {
		"base_seed": int(career.get("seed", 0)),
		"steps": {"training": int(career.get("rng_step", 0))},
	}
	payload.save_version = 9
	career.schema_version = 9
	return ""

static func _migrate_v9_to_v10(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary:
		return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	career.season_state = {
		"season_id": "",
		"entry_plan": {},
		"qualification_state": {},
		"event_statuses": {},
	}
	payload.save_version = 10
	career.schema_version = 10
	return ""

static func _migrate_v10_to_v11(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary:
		return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	if not career.has("world_athletes"):
		career.world_athletes = {}
	if not career.has("competition_archive"):
		career.competition_archive = []
	if not career.has("record_book"):
		career.record_book = {"international": {}, "all_formal": {}}
	if not career.has("ranking_state"):
		career.ranking_state = {
			"domestic_points": 0,
			"isu_world": 0,
			"season_world": 0,
			"selection_evidence": {},
		}
	payload.save_version = 11
	career.schema_version = 11
	return ""

static func _migrate_v11_to_v12(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	if not career.has("internal_invitation_state"):
		career.internal_invitation_state = {"status":"not_ready", "offered_clock":{}}
	if not career.has("certification_state"):
		career.certification_state = {"national_technical_grade":0, "last_assessment":{}, "history":[]}
	payload.save_version = 12
	career.schema_version = 12
	return ""

static func _migrate_v12_to_v13(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	if not career.has("condition_state"):
		career.condition_state = {"growth_phase":"stable","growth_signals":[],"injuries":[],"medical_opinions":[],"psychology":{}}
	if not career.has("social_state"):
		career.social_state = {"friendships":{},"fan_climate":"quiet","media_events":[],"commercial_commitments":[]}
	if not career.has("selection_state"):
		career.selection_state = {"applications":{},"assignments":{},"appeals":[]}
	if not career.has("event_ledger"):
		career.event_ledger = []
	if not career.has("world_state"):
		career.world_state = {"season_id":"","generated_federations":[],"athlete_ids":[],"last_advanced_clock":{}}
	payload.save_version = 13
	career.schema_version = 13
	return ""

static func _migrate_v13_to_v14(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	if not career.has("pre_career_history"):
		career.pre_career_history = {}
	payload.save_version = 14
	career.schema_version = 14
	return ""

static func _migrate_v14_to_v15(payload: Dictionary) -> String:
	if not payload.get("career") is Dictionary: return "存档字段 career 必须是对象"
	var career: Dictionary = payload.career
	# Existing V14 careers are already established unless they explicitly saved
	# a partial opening checkpoint. Never fabricate a childhood replay or goal.
	if not career.has("opening_stage"): career.opening_stage = "complete"
	elif not str(career.opening_stage) in ["history","handoff","complete"]: return "生涯字段 opening_stage 无效"
	for field in ["career_goal","training_period_state","last_training_policy","last_generated_plan"]:
		if career.has(field) and not career[field] is Dictionary: return "生涯字段 %s 必须是对象" % field
		if not career.has(field): career[field] = {}
	if career.has("coach_assignment") and not career.coach_assignment is Dictionary:
		return "生涯字段 coach_assignment 必须是对象"
	if not career.has("coach_assignment"): career.coach_assignment = CoachAssignment.new().to_dict()
	var preference_defaults := {
		"breakthrough_policy":"summary",
		"minor_pain_policy":"ask",
		"coach_strategy_policy":"summary",
	}
	if career.has("training_preferences") and not career.training_preferences is Dictionary:
		return "生涯字段 training_preferences 必须是对象"
	var preferences: Dictionary = Dictionary(career.get("training_preferences",{})).duplicate(true)
	for key in preference_defaults:
		if not preferences.get(key) is String: preferences[key] = preference_defaults[key]
	career.training_preferences = preferences
	# Legacy programs predate explicit Save/Lock separation. Only infer a lock
	# when the saved programme is complete and legal under at least one ruleset
	# it could have been used with; incomplete editor work must remain a draft.
	if career.get("active_programs",{}) is Dictionary:
		var athlete = _athlete_for_program_validation(career.get("athlete"))
		var clock: Dictionary = Dictionary(career.get("clock",{}))
		var season_year := maxi(2014,int(clock.get("year",2014)))
		for segment in ["short","free"]:
			var program = career.active_programs.get(segment,{})
			if not program is Dictionary or program.is_empty(): continue
			if not program.has("draft_status"):
				var restored = SkatingProgram.from_dict(program)
				var legal_teaching := restored != null and athlete != null and ProgramValidator.validate(restored,athlete,InternalEventRules.for_teaching_group(segment)).is_empty()
				var legal_formal := restored != null and athlete != null and ProgramValidator.validate(restored,athlete,InternalEventRules.for_season(season_year,"junior",segment)).is_empty()
				program.draft_status = "locked" if legal_teaching or legal_formal else "draft"
				program.locked_segments = [segment] if program.draft_status == "locked" else []
			elif str(program.get("draft_status","draft")) == "locked":
				if not program.get("locked_segments",[]) is Array: return "生涯字段 active_programs.%s.locked_segments 必须是数组" % segment
				if not program.locked_segments.has(segment): program.locked_segments.append(segment)
	payload.save_version = 15
	career.schema_version = 15
	return ""

static func _athlete_for_program_validation(data):
	if not data is Dictionary: return null
	for field in ["technique","skating","jumps","body","mind","resources"]:
		if not data.get(field) is Dictionary: return null
	return AthleteState.from_dict(data)

static func _add_route_defaults(program) -> void:
	if not program is Dictionary or program.is_empty(): return
	if not program.has("route_complexity"): program.route_complexity = "standard"
	if not program.has("choreography_quality"): program.choreography_quality = 50.0

static func _jump_median(jumps: Dictionary, group: String, metric: String, fallback: float) -> float:
	var values: Array[float] = []
	for jump_id in jumps:
		var jump = jumps[jump_id]
		if jump is Dictionary and jump.get(group) is Dictionary and jump[group].get(metric) is int or jump[group].get(metric) is float:
			values.append(clampf(float(jump[group][metric]), 0.0, 100.0))
	if values.is_empty(): return fallback
	values.sort()
	var middle := values.size() / 2
	return values[middle] if values.size() % 2 == 1 else (values[middle - 1] + values[middle]) / 2.0

static func _units_to_shares(allocations: Dictionary) -> Dictionary:
	var shares: Dictionary = {}
	var remainders: Array[Dictionary] = []
	var assigned := 0
	for index in TrainingPlan.CATEGORY_IDS.size():
		var category_id: String = TrainingPlan.CATEGORY_IDS[index]
		var raw := float(int(allocations.get(category_id, 0))) * 100.0 / 12.0
		var base := int(floor(raw / 5.0)) * 5
		shares[category_id] = base
		assigned += base
		remainders.append({"id": category_id, "remainder": raw - base, "index": index})
	remainders.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if not is_equal_approx(float(a.remainder), float(b.remainder)):
			return float(a.remainder) > float(b.remainder)
		return int(a.index) < int(b.index)
	)
	var cursor := 0
	while assigned < 100:
		var category_id: String = remainders[cursor % remainders.size()].id
		shares[category_id] += 5
		assigned += 5
		cursor += 1
	if int(shares.rest) < 5:
		var source := _largest_active_share(shares)
		shares[source] -= 5
		shares.rest = 5
	return shares

static func _single_targets(shares: Dictionary) -> Dictionary:
	var targets: Dictionary = {}
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id.begins_with("jump_") and int(shares.get(category_id, 0)) > 0:
			targets[category_id.trim_prefix("jump_")] = 1
	return targets

static func _largest_active_share(shares: Dictionary) -> String:
	var result := "skating_foundation"
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id != "rest" and int(shares.get(category_id, 0)) > int(shares.get(result, 0)):
			result = category_id
	return result

static func _is_integer(value: Variant) -> bool:
	return (value is int or value is float) and is_equal_approx(float(value), floorf(float(value)))

static func _failure(error: String) -> Dictionary:
	return {"ok": false, "data": {}, "errors": [error]}
