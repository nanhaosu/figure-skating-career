class_name BrowserSaveService
extends RefCounted

signal upload_ready(result: Dictionary)
signal busy_changed(value: bool)
signal load_progress(report: Dictionary)
const Repo = preload("res://src/persistence/save_repository.gd")
const Career = preload("res://src/domain/career_state.gd")
const IDS := ["autosave","manual-1","manual-2","manual-3"]
var root: String
var active_slot := "manual-1"
var _preview: Dictionary = {}
var _upload_callback
var durability
var metadata_opener: Callable
var busy := false

func _init(directory: String = "user://saves") -> void:
	root = directory.trim_suffix("/")
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(root))
	if OS.has_feature("web"): durability = preload("res://src/persistence/browser_durability.gd").new()

func slot_path(id: String) -> String:
	return root.path_join(id + ".json") if id in IDS else ""

func list_slots() -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	for id in IDS:
		var row: Dictionary = {"id":id,"name":"自动保存" if id == "autosave" else "手动存档 " + id.trim_prefix("manual-"),"athlete":"","clock":{},"saved_at_unix":0,"schema_version":0,"size":0,"status":"empty"}
		var metadata_path := slot_path(id) + ".meta"
		var metadata = _read_metadata(metadata_path)
		if metadata is Dictionary: row.merge(metadata,true)
		row.id = id
		if not FileAccess.file_exists(slot_path(id)) and FileAccess.file_exists(metadata_path) and not metadata is Dictionary:
			row.status = "unreadable"
		else:
			row.status = "saved" if FileAccess.file_exists(slot_path(id)) else "empty"
		rows.append(row)
	return rows

func _read_metadata(path: String):
	if not FileAccess.file_exists(path): return null
	var parser := JSON.new()
	if parser.parse(FileAccess.get_file_as_string(path)) != OK: return null
	return parser.data

func save_slot(id: String, career) -> Dictionary:
	if not id in IDS: return _failure("无效存档槽")
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	_set_busy(true)
	if durability != null:
		var ready: Dictionary = await durability.begin()
		if not ready.ok:
			_set_busy(false)
			return ready
	var previous := _snapshot(id)
	# Disk replacement is not publication: IndexedDB must acknowledge first.
	var result: Dictionary
	if durability != null:
		result = await Repo.save_responsive(career,slot_path(id),false,func(report: Dictionary): load_progress.emit(report))
	else:
		result = Repo.save(career,slot_path(id),false)
	var canonical_state: Dictionary = result.get("canonical_state",{})
	if result.ok:
		var metadata := _write_metadata(id,career)
		if not metadata.ok:
			_restore_file(slot_path(id) + ".meta",previous[".meta"])
			result.warnings = metadata.errors
		if durability != null:
			load_progress.emit({"stage":"save_acknowledging","percent":90})
			var acknowledged: Dictionary = await durability.flush()
			if not acknowledged.ok: result = acknowledged
	if not result.ok: _restore(id,previous)
	else: career.commit_from(Career.from_dict(canonical_state,true))
	result.erase("canonical_state")
	if durability != null: durability.release()
	if result.ok and id != "autosave": active_slot = id
	if result.ok and durability != null:
		load_progress.emit({"stage":"save_complete","percent":100})
	_set_busy(false)
	return result

func load_slot(id: String) -> Dictionary:
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	if not id in IDS: return _failure("无效存档槽")
	_set_busy(true)
	var result := await Repo.load_save_responsive(slot_path(id),func(report: Dictionary): load_progress.emit(report))
	if result.ok: active_slot = id
	_set_busy(false)
	return result

func export_slot(id: String, path: String = "") -> Dictionary:
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	if not id in IDS: return _failure("无效存档槽")
	var error := Repo._verify_payload(slot_path(id))
	if not error.is_empty(): return _failure(error)
	var bytes := FileAccess.get_file_as_bytes(slot_path(id))
	if OS.has_feature("web") and path.is_empty():
		JavaScriptBridge.download_buffer(bytes,"花滑生涯-%s.json" % id,"application/json")
		return {"ok":true,"errors":[]}
	if path.is_empty(): return _failure("请选择导出文件")
	var file := FileAccess.open(path,FileAccess.WRITE)
	if file == null: return _failure("无法写入导出文件")
	file.store_buffer(bytes)
	var result := file.get_error(); file.close()
	return {"ok":true,"errors":[]} if result == OK else _failure("导出写入失败")

func import_slot(path: String) -> Dictionary:
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	if not FileAccess.file_exists(path):
		_preview.clear()
		return _failure("导入文件不存在")
	return import_payload(FileAccess.get_file_as_string(path))

func import_payload(payload: String) -> Dictionary:
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	_preview.clear()
	var result := Repo.decode_payload(payload)
	if not result.ok: return result
	var data: Dictionary = result.data
	var career = Career.from_dict(data.career,true)
	Repo.restore_loaded_experiences(career)
	_preview = {"career":career,"athlete":career.athlete.display_name,"clock":career.clock.to_dict(),"schema_version":int(data.save_version),"size":payload.to_utf8_buffer().size()}
	return {"ok":true,"errors":[],"preview":{"athlete":_preview.athlete,"clock":_preview.clock,"schema_version":_preview.schema_version,"size":_preview.size}}

func confirm_import(id: String) -> Dictionary:
	if _preview.is_empty(): return _failure("请先选择并验证导入文件")
	var result := await save_slot(id,_preview.career)
	if result.ok: _preview.clear()
	return result

func rename_slot(id: String, title: String) -> Dictionary:
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	if not id in IDS or id == "autosave" or title.strip_edges().is_empty(): return _failure("无法重命名该存档")
	_set_busy(true)
	if durability != null:
		var ready: Dictionary = await durability.begin()
		if not ready.ok:
			_set_busy(false)
			return ready
	var previous := _snapshot(id)
	var row: Dictionary = list_slots()[IDS.find(id)]
	row.name = title.strip_edges().left(80)
	var result := _store_metadata(id,row)
	if result.ok and durability != null: result = await durability.flush()
	if not result.ok: _restore_file(slot_path(id) + ".meta",previous[".meta"])
	if durability != null: durability.release()
	_set_busy(false)
	return result

func delete_slot(id: String, confirmed: bool = false) -> Dictionary:
	if busy: return _failure("正在等待持久化确认，请稍后重试")
	if not confirmed or not id in IDS: return _failure("删除需要确认")
	_set_busy(true)
	if durability != null:
		var ready: Dictionary = await durability.begin()
		if not ready.ok:
			_set_busy(false)
			return ready
	var previous := _snapshot(id)
	var result := {"ok":true,"errors":[]}
	for suffix in ["",".bak",".meta"]:
		var path: String = slot_path(id) + suffix
		if FileAccess.file_exists(path) and DirAccess.remove_absolute(ProjectSettings.globalize_path(path)) != OK: result = _failure("无法删除存档"); break
	if result.ok and durability != null: result = await durability.flush()
	if not result.ok: _restore(id,previous)
	if durability != null: durability.release()
	_set_busy(false)
	return result

func request_upload() -> void:
	if not OS.has_feature("web"): return
	_upload_callback = JavaScriptBridge.create_callback(_receive_upload)
	JavaScriptBridge.get_interface("window").figureSkatingUpload(_upload_callback)

func _receive_upload(args: Array) -> void:
	if args.is_empty(): return
	upload_ready.emit(import_payload(str(args[0])))

func _write_metadata(id: String, career) -> Dictionary:
	var row: Dictionary = list_slots()[IDS.find(id)]
	row.merge({"athlete":career.athlete.display_name,"clock":career.clock.to_dict(),"schema_version":Repo.SAVE_VERSION,"saved_at_unix":Time.get_unix_time_from_system(),"size":FileAccess.get_file_as_bytes(slot_path(id)).size(),"status":"saved"},true)
	return _store_metadata(id,row)

func _store_metadata(id: String, row: Dictionary) -> Dictionary:
	var file = metadata_opener.call(slot_path(id) + ".meta") if metadata_opener.is_valid() else FileAccess.open(slot_path(id) + ".meta",FileAccess.WRITE)
	if file == null: return _failure("无法保存槽位名称")
	file.store_string(JSON.stringify(row))
	var error: Error = file.get_error()
	file.close()
	if error != OK: return _failure("槽位名称写入失败")
	return {"ok":true,"errors":[]}

func _set_busy(value: bool) -> void:
	busy = value
	busy_changed.emit(value)

func _snapshot(id: String) -> Dictionary:
	var snapshot := {}
	for suffix in ["",".bak",".meta"]:
		var path := slot_path(id) + str(suffix)
		snapshot[suffix] = FileAccess.get_file_as_bytes(path) if FileAccess.file_exists(path) else null
	return snapshot

func _restore(id: String, snapshot: Dictionary) -> void:
	for suffix in snapshot: _restore_file(slot_path(id) + str(suffix),snapshot[suffix])

func _restore_file(path: String, bytes) -> void:
	if bytes == null:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(ProjectSettings.globalize_path(path))
	else:
		var file := FileAccess.open(path,FileAccess.WRITE)
		if file != null: file.store_buffer(bytes); file.close()

func _failure(message: String) -> Dictionary:
	return {"ok":false,"career":null,"errors":[message]}
