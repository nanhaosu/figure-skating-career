class_name SaveSchema
extends RefCounted

const CURRENT_VERSION := 23
