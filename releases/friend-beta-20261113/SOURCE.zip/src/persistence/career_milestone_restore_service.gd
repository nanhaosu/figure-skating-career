class_name CareerMilestoneRestoreService
extends RefCounted

const Facts = preload("res://src/simulation/career_milestone_service.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")

static func restore(career, budget: int = 4) -> Dictionary:
	var state: Dictionary = career.experience_state.duplicate(true)
	var output := {"experience_state":state,"expanded_count":0,"errors":[]}
	if str(state.get("milestone_history",{}).get("status","")) != "unexamined": return output
	var archives: Array = career.competition_archive.duplicate()
	archives.sort_custom(func(a,b): return _date(a) < _date(b) if _date(a) != _date(b) else str(a.get("event_id","")) < str(b.get("event_id","")))
	var partial := false
	var checked := 0
	for index in archives:
		if bool(index.get("world_only",false)) or int(index.get("record_version",0)) != 1: continue
		var archive: Dictionary = index
		if archive.has("packed_archive"):
			if int(output.expanded_count) >= clampi(budget,0,4): partial = true; continue
			output.expanded_count += 1
			archive = Codec.expand(index)
			if archive.is_empty(): partial = true; continue
		checked += 1
		if archive.get("short_results",{}).get("player",{}).get("performance",{}).get("elements",[]).is_empty(): partial = true
		var facts: Dictionary = Facts.inspect_archive(archive)
		var candidates := {"first_jgp_start":facts.jgp_start,"first_jgp_complete":facts.jgp_complete,"first_formal_3a":facts.axel_completed[0] if not facts.axel_completed.is_empty() else {}}
		for key in candidates:
			if not state.milestones.has(key) and not candidates[key].is_empty():
				state.milestones[key] = Facts.record_for(candidates[key],"archive_confirmed","observed" if partial else "confirmed_first")
	# Unexamined later protocols cannot disprove an earlier confirmed first;
	# only uncertainty preceding a candidate changes its certainty.
	state.milestone_history = {"status":"partial" if partial else "complete","checked_archive_count":checked}
	return output

static func _date(archive: Dictionary) -> String:
	return str(archive.get("event",{}).get("start_date",archive.get("event",{}).get("actual_dates",{}).get("start","")))
