class_name NumericState
extends RefCounted

# One persistence contract for all game floats, with no field exemptions.
# Copy changed containers only; immutable committed archives can stay shared.
static func canonical_copy(value):
	# A compressed archive is a single checked value: its public index must
	# never be rounded separately from the source inside its payload.
	if value is Dictionary and value.has("packed_archive"):
		return value
	if value is float:
		if value == 0.0: return 0.0
		return roundf(value*1000000000.0)/1000000000.0
	if value is Dictionary or value is Array:
		var result = value
		var copied := false
		var keys = value.keys() if value is Dictionary else range(value.size())
		for key in keys:
			var original = value[key]
			var canonical = canonical_copy(original)
			var changed := not is_same(original,canonical)
			if original is float and original == 0.0:
				changed = var_to_bytes(original) != var_to_bytes(0.0)
			if changed:
				if not copied: result = value.duplicate(false); copied = true
				result[key] = canonical
		return result
	return value
