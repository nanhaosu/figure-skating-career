// Installed inside the Godot 4.7.2 module by install_web_durability.ps1.
// IDBFS calls back only after its IndexedDB transaction completes or aborts.
globalThis.figureSkatingInstallDurability = function (godotFS, fs, idbfs) {
    // Emscripten can invoke reconcile's error callback from a failed request,
    // before the transaction terminates, and suppress automatic abort. Make
    // every remote reconciliation atomic and acknowledge only its final event.
    if (idbfs) {
        const reconcile = idbfs.reconcile;
        idbfs.reconcile = (src, dst, callback) => {
            if (dst.type !== 'remote') return reconcile(src, dst, callback);
            let transaction, failure, finished = false;
            const finish = error => {
                if (!finished) { finished = true; callback(error || null); }
            };
            const abort = error => {
                failure ||= error;
                if (!transaction) return finish(failure);
                try { transaction.abort(); } catch (_) { /* final event follows */ }
            };
            const db = { transaction(...args) {
                transaction = dst.db.transaction(...args);
                transaction.addEventListener('abort', event => finish(failure || event.target.error || new Error('IndexedDB transaction aborted')));
                transaction.addEventListener('complete', () => finish(failure));
                return transaction;
            }};
            try {
                reconcile(src, {...dst, db}, error => {
                    if (error) abort(error);
                    else if (!transaction) finish(null); // no changed files
                });
            } catch (error) { abort(error); }
        };
    }
    let locked = false;
    let tail = Promise.resolve(null);
    const sync = () => new Promise(resolve => {
        try { fs.syncfs(false, error => resolve(error || null)); }
        catch (error) { resolve(error); }
    });
    const enqueue = () => (tail = tail.then(sync));
    // Every automatic sync uses the same queue. While a save is staged, the
    // explicit flush owns synchronization, including rollback before release.
    godotFS.sync = () => locked ? Promise.resolve(null) : enqueue();
    const bridge = {
        begin(callback) {
            if (!godotFS._idbfs) { callback('IndexedDB unavailable'); return; }
            if (locked) { callback('Persistence operation already pending'); return; }
            locked = true;
            tail.then(() => callback(''));
        },
        flush(callback) {
            if (!locked || !godotFS._idbfs) { callback('IndexedDB unavailable or not acquired'); return; }
            enqueue().then(error => callback(error ? String(error) : ''));
        },
        release() { locked = false; }
    };
    globalThis.figureSkatingDurability = bridge;
    return bridge;
};
