extends RefCounted

signal acknowledged
var _callback
var _answer: Dictionary

func begin() -> Dictionary:
	return await _request("begin")

func flush() -> Dictionary:
	return await _request("flush")

func release() -> void:
	JavaScriptBridge.get_interface("figureSkatingDurability").release()

func _request(operation: String) -> Dictionary:
	var bridge = JavaScriptBridge.get_interface("figureSkatingDurability")
	if bridge == null: return {"ok":false,"errors":["IndexedDB persistence bridge unavailable"]}
	_answer = {}
	_callback = JavaScriptBridge.create_callback(func(args):
		var error := str(args[0])
		_answer = {"ok":error.is_empty(),"errors":[] if error.is_empty() else [error]}
		acknowledged.emit())
	if operation == "begin": bridge.begin(_callback)
	else: bridge.flush(_callback)
	# Synchronous refusal needs no signal wait; success waits for the real JS ack.
	if _answer.is_empty(): await acknowledged
	_callback = null
	return _answer
