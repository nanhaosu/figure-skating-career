class_name TrainingDirection
extends RefCounted

static func empty() -> Dictionary:
	return {"focuses":[],"priority":"balanced","revision":0,"external_schedule":[]}

static func validate(data: Dictionary) -> String:
	if not data.get("focuses") is Array or data.focuses.size() > 2: return "训练重点最多两个"
	if not data.get("priority") in ["balanced","first","second"]: return "训练重点优先级无效"
	var revision = data.get("revision")
	if not (revision is int or revision is float): return "训练方向修订号无效"
	if not is_finite(float(revision)) or float(revision) < 0 or float(revision) != floorf(float(revision)): return "训练方向修订号无效"
	if not data.get("external_schedule") is Array: return "外训排程必须为列表"
	if data.external_schedule.size() > 64: return "外训排程过长"
	var bookings := {}
	for booking in data.external_schedule:
		if not booking is Dictionary or not booking.get("id") is String or booking.id.is_empty() or bookings.has(booking.id): return "外训预约编号无效或重复"
		bookings[booking.id] = true
		if not booking.get("offer_id") is String or not booking.get("focus_id") is String or not booking.get("focus") is Dictionary: return "外训课程目标无效"
		var course: Dictionary = preload("res://src/content/external_training_repository.gd").course(booking.offer_id)
		if course.is_empty(): return "外训课程不存在"
		if not booking.get("status") in ["booked","completed","cancelled"]: return "外训状态无效"
		for field in ["year","quarter","cost","executed_stages","refund"]:
			var value = booking.get(field)
			if not (value is int or value is float) or not is_finite(float(value)) or float(value) < 0 or float(value) != floorf(float(value)): return "外训数值无效"
		if int(booking.quarter) < 1 or int(booking.quarter) > 4 or int(booking.executed_stages) > 4 or int(booking.cost) != int(course.cost) or int(booking.refund) > int(booking.cost): return "外训时长或费用无效"
		var nested := {"focuses":[booking.focus],"priority":"balanced","revision":0,"external_schedule":[]}
		var nested_error := validate(nested)
		if not nested_error.is_empty(): return nested_error
		if booking.focus_id != booking.focus.id or not course.kinds.has(booking.focus.kind): return "外训课程与目标不匹配"
		if booking.offer_id == "jump_axis" and booking.focus.target.get("kind") != "jump": return "跳跃外训需要跳跃目标"
		var stages := int(booking.executed_stages)
		var refund := int(booking.refund)
		if booking.has("executed_days") or booking.has("period_days") or booking.has("last_executed_date"):
			for field in ["executed_days","period_days"]:
				var number = booking.get(field)
				if not (number is int or number is float) or not is_finite(float(number)) or float(number) != floorf(float(number)): return "外训日期计数无效"
			if not booking.get("last_executed_date") is String: return "外训最后执行日期无效"
			var date: String = booking.last_executed_date
			var dates = preload("res://src/simulation/dated_training_window.gd")
			if not dates.plan(date,date).errors.is_empty(): return "外训最后执行日期无效"
			var start := "%04d-%02d-01" % [int(booking.year),(int(booking.quarter)-1)*3+1]
			var end := "%04d-%02d-01" % [int(booking.year)+(1 if int(booking.quarter) == 4 else 0),1 if int(booking.quarter) == 4 else int(booking.quarter)*3+1]
			var full: Dictionary = dates.plan(start,end)
			var executed: Dictionary = dates.plan(start,date)
			if not full.errors.is_empty() or not executed.errors.is_empty() or int(booking.period_days) != full.days.size() or int(booking.executed_days) < 1 or int(booking.executed_days) > int(booking.period_days) or executed.days.size()+1 != int(booking.executed_days) or date >= end: return "外训日数与日历不一致"
			if stages != int(booking.executed_days)*4/int(booking.period_days): return "外训阶段与实际日数不一致"
		if booking.status == "booked" and (stages >= 4 or refund != 0): return "未完成外训的结算状态无效"
		if booking.status == "completed" and (stages != 4 or refund != 0): return "已完成外训的结算状态无效"
		var spent: int = (int(booking.cost)/4)*stages if stages < 4 else int(booking.cost)
		if booking.has("executed_days"): spent = int(booking.cost)*int(booking.executed_days)/int(booking.period_days)
		if booking.status == "cancelled" and refund != int(booking.cost)-spent: return "取消外训的退款金额无效"
	var seen := {}
	for focus in data.focuses:
		if not focus is Dictionary or not focus.get("id") is String or focus.id.strip_edges().is_empty(): return "训练重点编号无效"
		if seen.has(focus.id): return "训练重点不能重复"
		seen[focus.id] = true
		if not focus.get("target") is Dictionary: return "训练重点目标无效"
		if not focus.get("kind") in ["new_difficulty","execution","skating_edges","musical_expression","program_connections","spin","steps","recovery"]: return "训练重点类别无效"
		if focus.kind in ["new_difficulty","recovery"]:
			if focus.target.get("kind") != "jump" or preload("res://src/domain/technical_repertoire.gd").action_id(focus.target).is_empty(): return "训练重点动作无效"
		if focus.kind in ["execution","program_connections"]:
			if focus.target.get("kind") == "jump" and focus.kind == "execution":
				if preload("res://src/domain/technical_repertoire.gd").action_id(focus.target).is_empty(): return "训练重点动作无效"
			elif not focus.target.get("segment") in ["short","free"]: return "请选择节目专项对应的节目"
	return ""
