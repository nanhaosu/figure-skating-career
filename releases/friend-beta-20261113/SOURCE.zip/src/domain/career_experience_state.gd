class_name CareerExperienceState
extends RefCounted

static func empty() -> Dictionary:
	return {"personal_expectations":{},"suggestion_receipts":{},"relationship_memories":[],"milestones":{},"milestone_history":{"status":"native","checked_archive_count":0}}

static func validate(state: Dictionary) -> String:
	var milestones = state.get("milestones")
	var history = state.get("milestone_history")
	if not milestones is Dictionary or milestones.size() > 3: return "里程碑索引无效"
	if not history is Dictionary or not history.get("status") in ["native","unexamined","partial","complete"]: return "里程碑历史状态无效"
	if not _count(history.get("checked_archive_count")) or int(history.checked_archive_count) < 0: return "里程碑历史数量无效"
	if JSON.stringify(milestones).to_utf8_buffer().size() > 8192: return "里程碑索引过大"
	for key in milestones:
		if not key in ["first_jgp_start","first_jgp_complete","first_formal_3a"]: return "未知里程碑"
		var item = milestones[key]
		if not item is Dictionary or JSON.stringify(item).to_utf8_buffer().size() > 2048: return "里程碑记录过大或格式无效"
		for field in ["id","event_id","event_date","event_name","segment","element_id","origin","certainty"]:
			if not item.get(field) is String: return "里程碑缺少有效字段："+field
		if item.event_id.is_empty() or item.id.is_empty(): return "里程碑引用为空"
		if not item.origin in ["live","archive_confirmed"] or not item.certainty in ["confirmed_first","observed"]: return "里程碑来源无效"
		if not item.get("evidence_refs") is Array or item.evidence_refs.size() > 4: return "里程碑证据无效"
		for ref in item.evidence_refs:
			if not ref is String or ref.length() > 256: return "里程碑证据引用无效"
		if not item.get("clock") is Dictionary or not _count(item.clock.get("year")) or int(item.clock.year) < 1 or not _count(item.clock.get("quarter")) or int(item.clock.quarter) not in [1,2,3,4]: return "里程碑时点无效"
		if not _count(item.get("part_index")) or int(item.part_index) < 0 or int(item.part_index) > 2 or not item.get("result") is Dictionary: return "里程碑结果格式无效"
	if not state.get("personal_expectations") is Dictionary or state.personal_expectations.size() > 2: return "个人期待必须为最多两季的对象"
	if not state.get("suggestion_receipts") is Dictionary or state.suggestion_receipts.size() > 128: return "节目建议凭据超出容量或格式无效"
	if not state.get("relationship_memories") is Array or state.relationship_memories.size() > 64: return "关系记忆必须为最多64条的数组"
	for season in state.personal_expectations:
		var value = state.personal_expectations[season]
		if not season is String or not value is Dictionary or not value.get("choice_id") is String or not value.get("text") is String or not value.get("source_id") is String: return "个人期待记录无效"
	for id in state.suggestion_receipts:
		var receipt = state.suggestion_receipts[id]
		if not id is String or not receipt is Dictionary or not receipt.get("decision") in ["accepted","declined"] or not receipt.get("receipt_id") is String or not receipt.get("base_program_hash") is String: return "节目建议凭据无效"
	for memory in state.relationship_memories:
		if not memory is Dictionary: return "关系记忆必须是对象"
		for field in ["memory_id","person_id","event_id","choice_id","summary"]:
			if not memory.get(field) is String or str(memory[field]).is_empty(): return "关系记忆缺少有效的%s" % field
		var clock = memory.get("clock")
		if not clock is Dictionary or not _count(clock.get("year")) or int(clock.year) < 1 or not _count(clock.get("quarter")) or int(clock.quarter) not in [1,2,3,4]: return "关系记忆时点无效"
	return ""

static func _count(value) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floorf(float(value))
