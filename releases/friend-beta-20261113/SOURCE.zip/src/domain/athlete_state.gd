class_name AthleteState
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const JumpProfile = preload("res://src/domain/jump_profile.gd")
const JumpFoundation = preload("res://src/domain/jump_foundation.gd")

var name: String
var display_name: String:
	get:
		return name
	set(value):
		name = value
var birth_year: int
var birth_date: Dictionary = {}
var entry_id: String
var family_context_id: String
var technique: Dictionary = {"rotation": 15.0, "landing": 15.0, "single_jumps": 10.0}
var skating: Dictionary = {"speed": 20.0, "flow": 20.0, "one_foot_stability": 20.0, "deep_edge": 20.0, "turns": 15.0, "knee_action": 20.0, "ice_efficiency": 20.0}
var jumps: Dictionary = {}
var jump_foundation = JumpFoundation.create()
var spin_foundation: Dictionary = {
	"rotation": 15.0, "centering": 15.0, "balance": 20.0,
	"flexibility": 15.0, "position_control": 15.0, "entry_exit": 10.0,
}
var spins: Dictionary = _default_spins()
var body: Dictionary = {
	"acute_fatigue": 0.0,
	"cumulative_fatigue": 0.0,
	"ankle_load": 0.0,
	"growth_trend": 0.0,
	"impact_load": 0.0,
	"strength_readiness": 25.0,
	"joint_readiness": 35.0,
	"recovery_capacity": 30.0,
	"energy_availability_signal": 60.0,
}
var mind: Dictionary = {
	"motivation":60.0, "training_fear":0.0, "autonomy":10.0, "expression":20.0,
	"competition_composure":50.0, "recovery_urgency":50.0, "rules_awareness":50.0,
	"body_trust":50.0, "combination_continuity":50.0,
}
var resources: Dictionary = {"money": 50.0, "ice_access": 30.0}

func _init(initial_name: String = "", initial_birth_year: int = 0, initial_entry_id: String = "", initial_family_context_id: String = "") -> void:
	name = initial_name
	birth_year = initial_birth_year
	entry_id = initial_entry_id
	family_context_id = initial_family_context_id
	for jump_id in JumpCatalog.JUMP_IDS:
		jumps[jump_id] = JumpProfile.create(jump_id)

func to_dict() -> Dictionary:
	return {
		"name": name,
		"birth_year": birth_year,
		"birth_date": birth_date.duplicate(true),
		"entry_id": entry_id,
		"family_context_id": family_context_id,
		"technique": technique.duplicate(true),
		"skating": skating.duplicate(true),
		"jumps": _jumps_to_dict(),
		"jump_foundation": jump_foundation.to_dict(),
		"spin_foundation": spin_foundation.duplicate(true),
		"spins": spins.duplicate(true),
		"body": body.duplicate(true),
		"mind": mind.duplicate(true),
		"resources": resources.duplicate(true),
	}

static func from_dict(data: Dictionary) -> AthleteState:
	var athlete := AthleteState.new(
		str(data.get("name", "")),
		int(data.get("birth_year", 0)),
		str(data.get("entry_id", "")),
		str(data.get("family_context_id", "")),
	)
	if data.get("birth_date") is Dictionary:
		athlete.birth_date = preload("res://src/domain/athlete_identity.gd").canonical_birth_date(data.birth_date,athlete.birth_year)
	athlete.technique = Dictionary(data.get("technique", athlete.technique)).duplicate(true)
	athlete.skating = Dictionary(data.get("skating", athlete.skating)).duplicate(true)
	var jump_data: Dictionary = data.get("jumps", {})
	for jump_id in JumpCatalog.JUMP_IDS:
		if jump_data.get(jump_id) is Dictionary:
			athlete.jumps[jump_id] = JumpProfile.from_dict(jump_data[jump_id])
	if data.get("jump_foundation") is Dictionary:
		athlete.jump_foundation = JumpFoundation.from_dict(data.jump_foundation)
	if data.get("spin_foundation") is Dictionary:
		athlete.spin_foundation = _merged_numeric_dictionary(athlete.spin_foundation, data.spin_foundation)
	if data.get("spins") is Dictionary:
		var saved_spins: Dictionary = data.spins
		for spin_id in athlete.spins:
			if saved_spins.get(spin_id) is Dictionary:
				athlete.spins[spin_id] = _merged_numeric_dictionary(athlete.spins[spin_id], saved_spins[spin_id])
	athlete.body = Dictionary(data.get("body", athlete.body)).duplicate(true)
	if data.get("mind") is Dictionary: athlete.mind = _merged_numeric_dictionary(athlete.mind, data.mind)
	athlete.resources = Dictionary(data.get("resources", athlete.resources)).duplicate(true)
	return athlete

func _jumps_to_dict() -> Dictionary:
	var result := {}
	for jump_id in jumps:
		result[jump_id] = jumps[jump_id].to_dict()
	return result

static func _default_spins() -> Dictionary:
	var result := {}
	for spin_id in ["upright", "sit", "camel", "layback", "combination", "flying"]:
		result[spin_id] = {"proficiency": 0.0, "training_consistency": 0.0, "level_features": 0}
	return result

static func _merged_numeric_dictionary(defaults: Dictionary, saved: Dictionary) -> Dictionary:
	var result := defaults.duplicate(true)
	for key in result:
		if not saved.has(key): continue
		if result[key] is int:
			result[key] = maxi(0, int(saved[key]))
		else:
			result[key] = clampf(float(saved[key]), 0.0, 100.0)
	return result
