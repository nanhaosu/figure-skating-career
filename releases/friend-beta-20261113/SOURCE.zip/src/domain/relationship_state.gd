class_name RelationshipState
extends RefCounted

var closeness: float
var professional_trust: float
var control: float
var health_priority: float

func _init(initial_closeness: float = 0.0, initial_professional_trust: float = 0.0, initial_control: float = 0.0, initial_health_priority: float = 0.0) -> void:
	closeness = clampf(initial_closeness, 0.0, 100.0)
	professional_trust = clampf(initial_professional_trust, 0.0, 100.0)
	control = clampf(initial_control, 0.0, 100.0)
	health_priority = clampf(initial_health_priority, 0.0, 100.0)

func to_dict() -> Dictionary:
	return {
		"closeness": closeness,
		"professional_trust": professional_trust,
		"control": control,
		"health_priority": health_priority,
	}

static func from_dict(data: Dictionary) -> RelationshipState:
	return RelationshipState.new(
		float(data.get("closeness", 0.0)),
		float(data.get("professional_trust", 0.0)),
		float(data.get("control", 0.0)),
		float(data.get("health_priority", 0.0)),
	)
