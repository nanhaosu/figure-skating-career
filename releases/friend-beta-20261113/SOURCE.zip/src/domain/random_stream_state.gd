class_name RandomStreamState
extends RefCounted

const STEP_OFFSET := 104729
const HASH_OFFSET := 2166136261
const HASH_PRIME := 16777619

var base_seed: int
var steps: Dictionary = {}

func _init(initial_seed: int = 0, initial_steps: Dictionary = {}) -> void:
	base_seed = initial_seed
	for stream_id in initial_steps:
		steps[str(stream_id)] = int(initial_steps[stream_id])

func take_rng(stream_id: String) -> RandomNumberGenerator:
	assert(not stream_id.is_empty(), "Random stream id cannot be empty")
	var cursor := int(steps.get(stream_id, 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = _derived_seed(stream_id, cursor)
	steps[stream_id] = cursor + 1
	return rng

func peek_rng(stream_id: String) -> RandomNumberGenerator:
	assert(not stream_id.is_empty(), "Random stream id cannot be empty")
	var rng := RandomNumberGenerator.new()
	rng.seed = _derived_seed(stream_id, int(steps.get(stream_id, 0)))
	return rng

func to_dict() -> Dictionary:
	return {"base_seed": base_seed, "steps": steps.duplicate(true)}

static func from_dict(data: Dictionary):
	return RandomStreamState.new(
		int(data.get("base_seed", 0)),
		Dictionary(data.get("steps", {})),
	)

func _derived_seed(stream_id: String, cursor: int) -> int:
	var stream_salt := 0
	if stream_id != "training":
		stream_salt = HASH_OFFSET
		for byte in stream_id.to_utf8_buffer():
			stream_salt = int((stream_salt ^ int(byte)) * HASH_PRIME) & 0x7fffffff
	return (base_seed + stream_salt + cursor * STEP_OFFSET) & 0x7fffffffffffffff

static func validate(data: Dictionary) -> String:
	if not _is_non_negative_integer(data.get("base_seed")):
		return "随机流 base_seed 必须是非负整数"
	if not data.get("steps") is Dictionary:
		return "随机流 steps 必须是对象"
	for stream_id in data.steps:
		if not stream_id is String or str(stream_id).is_empty():
			return "随机流名称必须是非空字符串"
		if not _is_non_negative_integer(data.steps[stream_id]):
			return "随机流 %s 的推进位置必须是非负整数" % str(stream_id)
	return ""

static func _is_non_negative_integer(value: Variant) -> bool:
	return (
		(value is int or value is float)
		and is_equal_approx(float(value), floorf(float(value)))
		and float(value) >= 0.0
	)
