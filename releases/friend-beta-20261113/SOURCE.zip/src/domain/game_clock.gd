class_name GameClock
extends RefCounted

var year: int
var quarter: int

func _init(initial_year: int, initial_quarter: int) -> void:
	assert(initial_quarter >= 1 and initial_quarter <= 4, "Quarter must be between 1 and 4")
	year = initial_year
	quarter = initial_quarter

func advance_quarter() -> void:
	quarter += 1
	if quarter > 4:
		year += 1
		quarter = 1

func age_on(birth_year: int) -> int:
	return year - birth_year

func season_start_year() -> int:
	return year - 1 if quarter <= 2 else year

func season_id() -> String:
	var start := season_start_year()
	return "%d-%02d" % [start, (start + 1) % 100]

func to_dict() -> Dictionary:
	return {"year": year, "quarter": quarter}

static func from_dict(data: Dictionary) -> GameClock:
	return GameClock.new(int(data.get("year", 0)), int(data.get("quarter", 1)))
