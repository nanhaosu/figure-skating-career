class_name MusicSelection
extends RefCounted

const SOURCE_IDS := ["built_in", "custom"]

var source := "custom"
var work_id := ""
var title := ""
var creator := ""
var version_name := ""
var tags: Array[String] = []
var duration_seconds := 0
var edited := false
var work_rights := "unknown"
var recording_license := "not_bundled"
var audio_path := ""

static func create(requested_source: String, requested_work_id: String, requested_title: String, requested_creator: String, requested_version: String, requested_tags: Array) -> Dictionary:
	var errors: Array[String] = []
	if not SOURCE_IDS.has(requested_source): errors.append("未知曲目来源：%s" % requested_source)
	if requested_title.strip_edges().is_empty(): errors.append("曲目名称不能为空")
	if requested_source == "built_in" and requested_work_id.strip_edges().is_empty(): errors.append("内置曲目必须有作品编号")
	if not errors.is_empty(): return {"music": null, "errors": errors}
	var music = load("res://src/domain/music_selection.gd").new()
	music.source = requested_source
	music.work_id = requested_work_id.strip_edges()
	music.title = requested_title.strip_edges()
	music.creator = requested_creator.strip_edges()
	music.version_name = requested_version.strip_edges()
	for tag in requested_tags: music.tags.append(str(tag))
	return {"music": music, "errors": []}

func to_dict() -> Dictionary:
	return {"source": source, "work_id": work_id, "title": title, "creator": creator, "version_name": version_name, "tags": tags.duplicate(), "duration_seconds": duration_seconds, "edited": edited, "work_rights": work_rights, "recording_license": recording_license, "audio_path": audio_path}

static func from_dict(data: Dictionary):
	var result := create(str(data.get("source", "custom")), str(data.get("work_id", "")), str(data.get("title", "")), str(data.get("creator", "")), str(data.get("version_name", "")), Array(data.get("tags", [])))
	if result.music == null: return null
	result.music.duration_seconds = maxi(0, int(data.get("duration_seconds", 0)))
	result.music.edited = bool(data.get("edited", false))
	result.music.work_rights = str(data.get("work_rights", "unknown"))
	result.music.recording_license = str(data.get("recording_license", "not_bundled"))
	result.music.audio_path = str(data.get("audio_path", ""))
	return result.music
