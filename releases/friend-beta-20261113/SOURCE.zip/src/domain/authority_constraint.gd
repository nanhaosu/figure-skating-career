class_name AuthorityConstraint
extends RefCounted

var id := ""
var actor_id := ""
var reason_code := ""
var proposed_allocations: Dictionary = {}
var proposed_shares: Dictionary = {}
var proposed_jump_rotations: Dictionary = {}
var responses: Array[Dictionary] = []

func to_dict() -> Dictionary:
	return {"id": id, "actor_id": actor_id, "reason_code": reason_code, "proposed_allocations": proposed_allocations.duplicate(true), "proposed_shares": proposed_shares.duplicate(true), "proposed_jump_rotations": proposed_jump_rotations.duplicate(true), "responses": responses.duplicate(true)}

static func from_dict(data: Dictionary):
	var item = load("res://src/domain/authority_constraint.gd").new()
	item.id = str(data.get("id", ""))
	item.actor_id = str(data.get("actor_id", ""))
	item.reason_code = str(data.get("reason_code", ""))
	item.proposed_allocations = Dictionary(data.get("proposed_allocations", {})).duplicate(true)
	item.proposed_shares = Dictionary(data.get("proposed_shares", {})).duplicate(true)
	item.proposed_jump_rotations = Dictionary(data.get("proposed_jump_rotations", {})).duplicate(true)
	item.responses.assign(data.get("responses", []))
	return item
