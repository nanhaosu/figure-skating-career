class_name QuarterEvent
extends RefCounted

var id := ""
var signature := ""
var title := ""
var description := ""
var trigger_codes: Array[String] = []
var cause_ids: Array[String] = []
var choices: Array[Dictionary] = []

func to_dict() -> Dictionary:
	return {"id": id, "signature": signature, "title": title, "description": description, "trigger_codes": trigger_codes.duplicate(), "cause_ids": cause_ids.duplicate(), "choices": choices.duplicate(true)}
