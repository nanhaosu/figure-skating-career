class_name JumpProfile
extends RefCounted

var jump_id := ""
var unlocked_rotations := 0
var attempts := 0
var proficiency: Dictionary = {"single": 0.0, "double": 0.0, "triple": 0.0, "quad": 0.0}
var consistency: Dictionary = {"training": 0.0, "internal": 0.0, "official": 0.0, "high_pressure": 0.0}
var takeoff: Dictionary = {"edge_quality": 50.0, "edge_stability": 50.0, "toe_assist": 50.0, "prerotation": 0.0, "angle": 50.0}
var air: Dictionary = {"height": 20.0, "distance": 20.0, "rotation_speed": 20.0, "axis": 50.0, "tightness": 20.0}
var landing: Dictionary = {"completion": 20.0, "control": 20.0, "flow": 20.0, "combination": 0.0}
var habits: Dictionary = {"rigidity": 0.0, "correction_progress": 0.0, "relapse_risk": 0.0}
var observations: Array[Dictionary] = []
var attempt_evidence: Dictionary = _empty_attempt_evidence()

static func _empty_attempt_evidence() -> Dictionary:
	var result := {}
	for rotation_key in ["single", "double", "triple", "quad"]:
		result[rotation_key] = {
			"attempts": 0, "successes": 0, "clean_successes": 0,
			"falls": 0, "pops": 0, "two_foot": 0, "hand_down": 0,
			"underrotated": 0, "downgraded": 0, "first_success_clock": {},
		}
	return result

static func create(initial_jump_id: String):
	var profile = load("res://src/domain/jump_profile.gd").new()
	profile.jump_id = initial_jump_id
	return profile

func to_dict() -> Dictionary:
	return {
		"jump_id": jump_id,
		"unlocked_rotations": unlocked_rotations,
		"attempts": attempts,
		"proficiency": proficiency.duplicate(true),
		"consistency": consistency.duplicate(true),
		"takeoff": takeoff.duplicate(true),
		"air": air.duplicate(true),
		"landing": landing.duplicate(true),
		"habits": habits.duplicate(true),
		"observations": observations.duplicate(true),
		"attempt_evidence": attempt_evidence.duplicate(true),
	}

static func from_dict(data: Dictionary):
	var profile = create(str(data.get("jump_id", "")))
	profile.unlocked_rotations = int(data.get("unlocked_rotations", 0))
	profile.attempts = int(data.get("attempts", 0))
	for field_name in ["proficiency", "consistency", "takeoff", "air", "landing", "habits"]:
		var current: Dictionary = profile.get(field_name)
		profile.set(field_name, Dictionary(data.get(field_name, current)).duplicate(true))
	for observation in data.get("observations", []):
		if observation is Dictionary:
			profile.observations.append(observation.duplicate(true))
	var saved_evidence = data.get("attempt_evidence", {})
	if saved_evidence is Dictionary:
		for rotation_key in profile.attempt_evidence:
			var saved_rotation = saved_evidence.get(rotation_key, {})
			if saved_rotation is Dictionary:
				for evidence_key in profile.attempt_evidence[rotation_key]:
					if saved_rotation.has(evidence_key):
						if evidence_key == "first_success_clock":
							var clock: Dictionary = Dictionary(saved_rotation[evidence_key]).duplicate(true) if saved_rotation[evidence_key] is Dictionary else {}
							if clock.has("year"): clock.year = int(clock.year)
							if clock.has("quarter"): clock.quarter = int(clock.quarter)
							profile.attempt_evidence[rotation_key][evidence_key] = clock
						else:
							profile.attempt_evidence[rotation_key][evidence_key] = int(saved_rotation[evidence_key])
	return profile
