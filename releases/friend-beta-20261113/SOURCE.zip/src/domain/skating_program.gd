class_name SkatingProgram
extends RefCounted

const ProgramElement = preload("res://src/domain/program_element.gd")
const SEGMENT_IDS := ["short", "free"]

var program_id := ""
var revision := 1
var segment := "short"
var elements: Array = []
var whole_run_familiarity := 0.0
var slot_familiarity: Dictionary = {}
var music: Dictionary = {}
var route_complexity := "standard"
var choreography_quality := 50.0
var draft_status := "draft"
var locked_segments: Array[String] = []

static func create(requested_id: String, requested_segment: String, requested_elements: Array) -> Dictionary:
	var errors: Array[String] = []
	if requested_id.strip_edges().is_empty(): errors.append("节目必须有唯一编号")
	if not SEGMENT_IDS.has(requested_segment): errors.append("未知节目分段：%s" % requested_segment)
	var normalized: Array = []
	for raw_element in requested_elements:
		var element = raw_element
		if raw_element is Dictionary: element = ProgramElement.from_dict(raw_element)
		if element == null or not element is ProgramElement:
			errors.append("节目包含无效动作")
		else:
			var copied = ProgramElement.from_dict(element.to_dict())
			if copied == null: errors.append("节目包含无效动作参数")
			else: normalized.append(copied)
	if not errors.is_empty(): return {"program": null, "errors": errors}
	var program = load("res://src/domain/skating_program.gd").new()
	program.program_id = requested_id.strip_edges()
	program.segment = requested_segment
	program.elements = normalized
	for element in normalized: program.slot_familiarity[element.element_id] = 0.0
	return {"program": program, "errors": []}

func to_dict() -> Dictionary:
	var serialized_elements: Array = []
	for element in elements: serialized_elements.append(element.to_dict())
	return {
		"program_id": program_id, "revision": revision, "segment": segment, "elements": serialized_elements,
		"whole_run_familiarity": whole_run_familiarity,
		"slot_familiarity": slot_familiarity.duplicate(true),
		"music": music.duplicate(true),
		"route_complexity": route_complexity,
		"choreography_quality": choreography_quality,
		"draft_status": draft_status,
		"locked_segments": locked_segments.duplicate(),
	}

static func from_dict(data: Dictionary):
	var result := create(str(data.get("program_id", "")), str(data.get("segment", "")), Array(data.get("elements", [])))
	if result.program == null: return null
	result.program.revision = maxi(1, int(data.get("revision", 1)))
	result.program.whole_run_familiarity = clampf(float(data.get("whole_run_familiarity", 0.0)), 0.0, 100.0)
	var saved_slots = data.get("slot_familiarity", {})
	if saved_slots is Dictionary:
		for element in result.program.elements:
			result.program.slot_familiarity[element.element_id] = clampf(float(saved_slots.get(element.element_id, 0.0)), 0.0, 100.0)
	if data.get("music", {}) is Dictionary: result.program.music = Dictionary(data.get("music", {})).duplicate(true)
	var saved_complexity := str(data.get("route_complexity", "standard"))
	result.program.route_complexity = saved_complexity if ["simple", "standard", "rich", "extreme"].has(saved_complexity) else "standard"
	result.program.choreography_quality = clampf(float(data.get("choreography_quality", 50.0)), 0.0, 100.0)
	# Saves written before the draft/lock split only contain active competition
	# programs. Treat those populated legacy records as locked so an upgrade does
	# not suddenly strand an ongoing career at the entry gate.
	var legacy_locked: bool = not data.has("draft_status") and not result.program.elements.is_empty()
	var saved_status := str(data.get("draft_status", "locked" if legacy_locked else "draft"))
	result.program.draft_status = saved_status if ["draft", "locked"].has(saved_status) else "draft"
	for saved_segment in data.get("locked_segments", []):
		var normalized_segment := str(saved_segment)
		if SEGMENT_IDS.has(normalized_segment) and not result.program.locked_segments.has(normalized_segment):
			result.program.locked_segments.append(normalized_segment)
	if legacy_locked and not result.program.locked_segments.has(result.program.segment):
		result.program.locked_segments.append(result.program.segment)
	return result.program
