class_name PlanProposal
extends RefCounted

const TrainingPlan = preload("res://src/domain/training_plan.gd")
const AuthorityConstraint = preload("res://src/domain/authority_constraint.gd")

var desired: TrainingPlan
var approved: TrainingPlan
var executed: TrainingPlan
var status := "draft"
var conflicts: Array = []
var decisions: Array[Dictionary] = []
var secret_practice_intent: Dictionary = {}
var training_efficiency := 1.0

static func create(desired_plan: TrainingPlan):
	var proposal = load("res://src/domain/plan_proposal.gd").new()
	proposal.desired = desired_plan
	proposal.approved = desired_plan
	proposal.executed = desired_plan
	return proposal

func to_dict() -> Dictionary:
	var conflict_data: Array[Dictionary] = []
	for conflict in conflicts:
		conflict_data.append(conflict.to_dict())
	return {
		"desired": desired.to_dict(), "approved": approved.to_dict(), "executed": executed.to_dict(),
		"status": status, "conflicts": conflict_data, "decisions": decisions.duplicate(true),
		"secret_practice_intent": secret_practice_intent.duplicate(true),
		"training_efficiency": training_efficiency,
	}

static func from_dict(data: Dictionary):
	var proposal = create(TrainingPlan.from_dict(data.desired))
	proposal.approved = TrainingPlan.from_dict(data.approved)
	proposal.executed = TrainingPlan.from_dict(data.executed)
	proposal.status = str(data.get("status", "draft"))
	for conflict in data.get("conflicts", []):
		proposal.conflicts.append(AuthorityConstraint.from_dict(conflict))
	proposal.decisions.assign(data.get("decisions", []))
	proposal.secret_practice_intent = Dictionary(data.get("secret_practice_intent", {})).duplicate(true)
	proposal.training_efficiency = float(data.get("training_efficiency", 1.0))
	return proposal
