class_name JumpFamilyCatalog
extends RefCounted

const RELATED := {
	"toe_loop": {"flip": 0.25, "lutz": 0.18},
	"flip": {"toe_loop": 0.25, "lutz": 0.30},
	"lutz": {"flip": 0.30, "toe_loop": 0.18},
	"salchow": {"loop": 0.30, "axel": 0.12},
	"loop": {"salchow": 0.30, "axel": 0.18},
	"axel": {"salchow": 0.12, "loop": 0.18},
}

static func related(jump_id: String) -> Dictionary:
	return Dictionary(RELATED.get(jump_id, {})).duplicate()
