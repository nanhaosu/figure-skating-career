class_name CareerState
extends RefCounted

const GameClock = preload("res://src/domain/game_clock.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const SaveSchema = preload("res://src/persistence/save_schema.gd")
const StoryContext = preload("res://src/domain/story_context.gd")
const RandomStreamState = preload("res://src/domain/random_stream_state.gd")
const CoachAssignment = preload("res://src/domain/coach_assignment.gd")

var clock: GameClock
var athlete: AthleteState
var relationships: Dictionary = {}
var schema_version: int = SaveSchema.CURRENT_VERSION
# Kept as version-9 compatibility mirrors until every simulator uses a named stream.
var seed: int = 0
var rng_step: int = 0
var story_context = StoryContext.women_singles_2014("CHN")
var random_streams = RandomStreamState.new(0)
var history: Array[Dictionary] = []
var memories: Array[Dictionary] = []
var pre_career_history: Dictionary = {}
var opening_stage: String = "history"
var career_goal: Dictionary = {}
var training_period_state: Dictionary = {}
var coach_assignment = CoachAssignment.new()
var coach_training_state: Dictionary = preload("res://src/domain/coach_training_state.gd").defaults()
var training_preferences: Dictionary = {
	"breakthrough_policy": "summary",
	"minor_pain_policy": "ask",
	"coach_strategy_policy": "summary",
}
var last_training_policy: Dictionary = {}
var last_generated_plan: Dictionary = {}
var development_roadmap: Dictionary = {}
var roadmap_revision_history: Array[Dictionary] = []
var active_programs: Dictionary = {"short": {}, "free": {}}
var season_program_plan: Dictionary = preload("res://src/domain/season_program_plan.gd").create("")
var training_direction: Dictionary = preload("res://src/domain/training_direction.gd").empty()
var experience_state: Dictionary = preload("res://src/domain/career_experience_state.gd").empty()
var technical_repertoire: Dictionary = preload("res://src/domain/technical_repertoire.gd").empty()
var program_archive: Array[Dictionary] = []
var internal_invitation_state: Dictionary = {"status":"not_ready", "offered_clock":{}}
var certification_state: Dictionary = {"national_technical_grade":0, "last_assessment":{}, "history":[]}
var competition_state: Dictionary = {}
var world_athletes: Dictionary = {}
var competition_archive: Array[Dictionary] = []
var record_book: Dictionary = {"international": {}, "all_formal": {}}
var ranking_state: Dictionary = {
	"domestic_points": 0,
	"isu_world": 0,
	"season_world": 0,
	"selection_evidence": {},
}
var season_state: Dictionary = {
	"season_id": "",
	"entry_plan": {},
	"qualification_state": {},
	"event_statuses": {},
}
var condition_state := {"growth_phase":"stable","growth_signals":[],"injuries":[],"medical_opinions":[],"psychology":{},"health_model_version":1,"function_limits":{},"rehabilitation":{},"pending_decision":{}}
var social_state := {"friendships":{},"fan_climate":"quiet","media_events":[],"commercial_commitments":[]}
var selection_state := {"applications":{},"assignments":{},"appeals":[]}
var olympic_quota_state: Dictionary = preload("res://src/domain/olympic_quota_state.gd").empty()
var milano_olympic_quota_state: Dictionary = preload("res://src/domain/olympic_quota_state.gd").empty(2026)
var beijing_trial_series: Dictionary = preload("res://src/domain/beijing_trial_series.gd").empty()
var competition_timeline: Dictionary = preload("res://src/domain/competition_timeline.gd").empty()
var event_ledger: Array[Dictionary] = []
var world_state := {"season_id":"","generated_federations":[],"athlete_ids":[],"last_advanced_clock":{}}

# Adopt a validated transaction while preserving the UI's shared CareerState identity.
func commit_from(working: CareerState) -> void:
	for field in working.to_dict():
		set(field, working.get(field))

func to_dict(copy_archives: bool = true, copy_large_state: bool = true) -> Dictionary:
	var relationship_data := {}
	for relationship_id in relationships:
		relationship_data[relationship_id] = relationships[relationship_id].to_dict()
	return {
		"schema_version": schema_version,
		"seed": seed,
		"rng_step": rng_step,
		"story_context": story_context.to_dict(),
		"random_streams": random_streams.to_dict(),
		"clock": clock.to_dict() if clock != null else {},
		"athlete": athlete.to_dict() if athlete != null else {},
		"relationships": relationship_data,
		"history": history.duplicate(true),
		"memories": memories.duplicate(true),
		"pre_career_history": pre_career_history.duplicate(true),
		"opening_stage": opening_stage,
		"career_goal": career_goal.duplicate(true),
		"training_period_state": training_period_state.duplicate(true),
		"coach_assignment": coach_assignment.to_dict(),
		"coach_training_state": coach_training_state.duplicate(true),
		"training_preferences": training_preferences.duplicate(true),
		"last_training_policy": last_training_policy.duplicate(true),
		"last_generated_plan": last_generated_plan.duplicate(true),
		"development_roadmap": development_roadmap.duplicate(true),
		"roadmap_revision_history": roadmap_revision_history.duplicate(true),
		"active_programs": active_programs.duplicate(true),
		"season_program_plan": season_program_plan.duplicate(true),
		"training_direction": training_direction.duplicate(true),
		"experience_state": experience_state.duplicate(true),
		"technical_repertoire": technical_repertoire.duplicate(true),
		"program_archive": program_archive.duplicate(true),
		"internal_invitation_state": internal_invitation_state.duplicate(true),
		"certification_state": certification_state.duplicate(true),
		"competition_state": competition_state.duplicate(true) if copy_large_state else competition_state,
		"world_athletes": world_athletes.duplicate(true) if copy_large_state else world_athletes,
		"competition_archive": competition_archive.duplicate(true) if copy_archives else [],
		"record_book": record_book.duplicate(true),
		"ranking_state": ranking_state.duplicate(true),
		"season_state": season_state.duplicate(true),
		"condition_state": condition_state.duplicate(true),
		"social_state": social_state.duplicate(true),
		"selection_state": selection_state.duplicate(true),
		"olympic_quota_state": olympic_quota_state.duplicate(true),
		"milano_olympic_quota_state": milano_olympic_quota_state.duplicate(true),
		"beijing_trial_series": beijing_trial_series.duplicate(true),
		"competition_timeline": competition_timeline.duplicate(true),
		"event_ledger": event_ledger.duplicate(true),
		"world_state": world_state.duplicate(true),
	}

# Synchronous serialization/validation only; callers must not mutate this view.
# Public to_dict and from_dict still provide isolated mutable copies.
func serialization_view() -> Dictionary:
	var data := to_dict(false,false)
	data.competition_archive = competition_archive
	return data

# Committed competition archives are immutable. Transactions append new records
# but never rewrite existing ones; keep those large replay payloads shared.
func transaction_copy(canonical: bool = false) -> CareerState:
	var data := to_dict(false)
	if canonical: data = JSON.parse_string(JSON.stringify(data))
	var working := from_dict(data, canonical)
	working.competition_archive.assign(competition_archive)
	return working

static func from_dict(data: Dictionary, take_ownership: bool = false) -> CareerState:
	var career := CareerState.new()
	career.schema_version = int(data.get("schema_version", SaveSchema.CURRENT_VERSION))
	career.seed = int(data.get("seed", 0))
	career.rng_step = int(data.get("rng_step", 0))
	career.story_context = StoryContext.from_dict(Dictionary(data.get("story_context", {})))
	career.random_streams = RandomStreamState.from_dict(Dictionary(data.get("random_streams", {})))
	var clock_data: Dictionary = data.get("clock", {})
	var athlete_data: Dictionary = data.get("athlete", {})
	career.clock = GameClock.from_dict(clock_data) if not clock_data.is_empty() else null
	career.athlete = AthleteState.from_dict(athlete_data) if not athlete_data.is_empty() else null
	var relationship_data: Dictionary = data.get("relationships", {})
	for relationship_id in relationship_data:
		career.relationships[relationship_id] = RelationshipState.from_dict(relationship_data[relationship_id])
	for entry in data.get("history", []):
		if entry is Dictionary:
			career.history.append(_restore_history_entry(entry))
	for memory in data.get("memories", []):
		if memory is Dictionary:
			career.memories.append(memory.duplicate(true))
	if data.get("pre_career_history", {}) is Dictionary:
		career.pre_career_history = Dictionary(data.get("pre_career_history", {})).duplicate(true)
		_restore_pre_career_integers(career.pre_career_history)
	var saved_opening_stage := str(data.get("opening_stage", "complete"))
	career.opening_stage = saved_opening_stage if saved_opening_stage in ["history", "handoff", "complete"] else "complete"
	if data.get("career_goal", {}) is Dictionary:
		career.career_goal = Dictionary(data.get("career_goal", {})).duplicate(true)
		var chosen_clock: Dictionary = career.career_goal.get("chosen_clock", {})
		if not chosen_clock.is_empty():
			for field in ["year", "quarter"]:
				if chosen_clock.has(field): chosen_clock[field] = int(chosen_clock[field])
	if data.get("training_period_state", {}) is Dictionary:
		career.training_period_state = Dictionary(data.get("training_period_state", {})).duplicate(true)
		if career.training_period_state.has("weeks_elapsed"): career.training_period_state.weeks_elapsed = int(career.training_period_state.weeks_elapsed)
		var period_plan = career.training_period_state.get("plan")
		if period_plan is Dictionary: restore_plan_integers(period_plan)
		var agreed = career.training_period_state.get("agreed_proposal")
		if agreed is Dictionary: restore_plan_integers(agreed)
		var started_clock = career.training_period_state.get("started_clock")
		if started_clock is Dictionary:
			for field in ["year", "quarter"]:
				if started_clock.has(field): started_clock[field] = int(started_clock[field])
	if data.get("coach_assignment", {}) is Dictionary:
		career.coach_assignment = CoachAssignment.from_dict(Dictionary(data.get("coach_assignment", {})))
	var saved_preferences = data.get("training_preferences", {})
	if saved_preferences is Dictionary:
		for key in career.training_preferences:
			if saved_preferences.get(key) is String:
				career.training_preferences[key] = saved_preferences[key]
	if data.get("last_training_policy", {}) is Dictionary:
		career.last_training_policy = Dictionary(data.get("last_training_policy", {})).duplicate(true)
		var saved_targets = career.last_training_policy.get("target_rotations")
		if saved_targets is Dictionary:
			for jump_id in saved_targets: saved_targets[jump_id] = int(saved_targets[jump_id])
	if data.get("last_generated_plan", {}) is Dictionary:
		career.last_generated_plan = Dictionary(data.get("last_generated_plan", {})).duplicate(true)
		restore_plan_integers(career.last_generated_plan)
	if data.get("development_roadmap", {}) is Dictionary:
		career.development_roadmap = Dictionary(data.get("development_roadmap", {})).duplicate(true)
	if data.get("coach_training_state") is Dictionary:
		career.coach_training_state = preload("res://src/domain/coach_training_state.gd").normalize(data.coach_training_state)
	for revision in data.get("roadmap_revision_history", []):
		if revision is Dictionary: career.roadmap_revision_history.append(revision.duplicate(true))
	if data.get("active_programs", {}) is Dictionary:
		for segment in ["short", "free"]:
			if data.active_programs.get(segment, {}) is Dictionary:
				career.active_programs[segment] = Dictionary(data.active_programs.get(segment, {})).duplicate(true)
	for field in ["season_program_plan","technical_repertoire","training_direction","experience_state"]:
		if data.get(field) is Dictionary: career.set(field,Dictionary(data[field]).duplicate(true))
	if career.experience_state.get("milestone_history") is Dictionary:
		career.experience_state.milestone_history.checked_archive_count = int(career.experience_state.milestone_history.get("checked_archive_count",0))
	for milestone in career.experience_state.get("milestones",{}).values():
		if not milestone is Dictionary: continue
		milestone.part_index = int(milestone.get("part_index",0))
		for field in ["year","quarter"]:
			if milestone.get("clock",{}).has(field): milestone.clock[field] = int(milestone.clock[field])
		if milestone.get("result",{}).has("rank"): milestone.result.rank = int(milestone.result.rank)
	if career.season_program_plan.has("revision"): career.season_program_plan.revision = int(career.season_program_plan.revision)
	if career.season_program_plan.get("preparation") is Dictionary:
		career.season_program_plan.preparation.direction_revision = int(career.season_program_plan.preparation.get("direction_revision",0))
	if career.training_direction.has("revision"): career.training_direction.revision = int(career.training_direction.revision)
	for focus in career.training_direction.get("focuses",[]):
		for part in focus.get("target",{}).get("parts",[]): part.rotations = int(part.rotations)
	for booking in career.training_direction.get("external_schedule",[]):
		for field in ["year","quarter","cost","executed_stages","refund","executed_days","period_days"]:
			if booking.has(field): booking[field] = int(booking[field])
		for part in booking.get("focus",{}).get("target",{}).get("parts",[]): part.rotations = int(part.rotations)
	for item in career.technical_repertoire.get("entries",{}).values():
		for milestone in item.get("learned_history",{}).get("first_success_contexts",{}).values():
			milestone.source_sequence = int(milestone.source_sequence)
			for field in ["year","quarter"]: milestone.clock[field] = int(milestone.clock[field])
		if item.has("revalidation_after_sequence"): item.revalidation_after_sequence = int(item.revalidation_after_sequence)
		for field in ["total_attempts","total_successes","record_count"]:
			if item.get("learned_history",{}).has(field): item.learned_history[field] = int(item.learned_history[field])
		for part in item.get("action",{}).get("parts",[]): part.rotations = int(part.rotations)
		for evidence in item.get("evidence",[]):
			for part in evidence.get("action",{}).get("parts",[]): part.rotations = int(part.rotations)
			if evidence.has("sequence"): evidence.sequence = int(evidence.sequence)
			for field in ["attempts","successes","clean_successes"]: evidence[field] = int(evidence[field])
			for field in evidence.get("failure_counts",{}): evidence.failure_counts[field] = int(evidence.failure_counts[field])
			for field in ["year","quarter"]:
				if evidence.get("clock",{}).has(field): evidence.clock[field] = int(evidence.clock[field])
	for program in data.get("program_archive", []):
		if program is Dictionary: career.program_archive.append(program.duplicate(true))
	if data.get("internal_invitation_state", {}) is Dictionary:
		var saved_invitation: Dictionary = data.get("internal_invitation_state", {})
		if ["not_ready", "pending", "deferred", "accepted", "completed"].has(str(saved_invitation.get("status", ""))):
			career.internal_invitation_state = saved_invitation.duplicate(true)
			if not career.internal_invitation_state.get("offered_clock", {}) is Dictionary:
				career.internal_invitation_state.offered_clock = {}
			for field in ["year", "quarter"]:
				if career.internal_invitation_state.offered_clock.has(field): career.internal_invitation_state.offered_clock[field] = int(career.internal_invitation_state.offered_clock[field])
			for field in ["scheduled_week", "offered_week", "deferred_until_week"]:
				if career.internal_invitation_state.has(field): career.internal_invitation_state[field] = int(career.internal_invitation_state[field])
	if data.get("certification_state", {}) is Dictionary:
		var saved_certification: Dictionary = data.get("certification_state", {})
		career.certification_state.national_technical_grade = maxi(0, int(saved_certification.get("national_technical_grade", 0)))
		if saved_certification.get("last_assessment", {}) is Dictionary: career.certification_state.last_assessment = Dictionary(saved_certification.last_assessment).duplicate(true)
		if saved_certification.get("history", []) is Array: career.certification_state.history = Array(saved_certification.history).duplicate(true)
	if data.get("competition_state", {}) is Dictionary:
		career.competition_state = _restore_competition_state(Dictionary(data.get("competition_state", {})),not take_ownership)
	if data.get("world_athletes", {}) is Dictionary:
		career.world_athletes = Dictionary(data.get("world_athletes", {})) if take_ownership else Dictionary(data.get("world_athletes", {})).duplicate(true)
	for competition in data.get("competition_archive", []):
		if competition is Dictionary:
			career.competition_archive.append(_restore_competition_state(competition,not take_ownership))
	if data.get("record_book", {}) is Dictionary:
		career.record_book = Dictionary(data.get("record_book", {})).duplicate(true)
	if data.get("ranking_state", {}) is Dictionary:
		career.ranking_state = _restore_ranking_state(Dictionary(data.get("ranking_state", {})))
	if data.get("season_state", {}) is Dictionary:
		career.season_state = _restore_season_state(Dictionary(data.get("season_state", {})))
	if data.get("condition_state", {}) is Dictionary:
		career.condition_state = Dictionary(data.get("condition_state", {})).duplicate(true)
		_restore_condition_integers(career.condition_state)
		for field in ["function_limits","rehabilitation","pending_decision"]:
			if not career.condition_state.has(field): career.condition_state[field] = {}
		if not career.condition_state.has("health_model_version"): career.condition_state.health_model_version = 1
		career.condition_state.health_model_version = int(career.condition_state.health_model_version)
	if data.get("social_state", {}) is Dictionary:
		career.social_state = Dictionary(data.get("social_state", {})).duplicate(true)
	if data.get("selection_state", {}) is Dictionary:
		career.selection_state = Dictionary(data.get("selection_state", {})).duplicate(true)
		_restore_selection_numbers(career.selection_state)
	if data.get("olympic_quota_state") is Dictionary:
		career.olympic_quota_state = preload("res://src/domain/olympic_quota_state.gd").normalize(data.olympic_quota_state)
	if data.get("milano_olympic_quota_state") is Dictionary:
		career.milano_olympic_quota_state = preload("res://src/domain/olympic_quota_state.gd").normalize(data.milano_olympic_quota_state)
	if data.get("beijing_trial_series") is Dictionary:
		career.beijing_trial_series = preload("res://src/domain/beijing_trial_series.gd").normalize(data.beijing_trial_series)
	if data.get("competition_timeline") is Dictionary:
		career.competition_timeline = preload("res://src/domain/competition_timeline.gd").normalize(data.competition_timeline)
	if data.get("event_ledger", []) is Array:
		for event in data.get("event_ledger", []):
			if event is Dictionary:
				var restored_event := Dictionary(event).duplicate(true)
				for clock_field in ["clock", "from_clock", "to_clock"]:
					if restored_event.has(clock_field) and restored_event[clock_field] is Dictionary:
						for field in ["year", "quarter"]:
							if restored_event[clock_field].has(field): restored_event[clock_field][field] = int(restored_event[clock_field][field])
				career.event_ledger.append(restored_event)
	if data.get("world_state", {}) is Dictionary:
		career.world_state = Dictionary(data.get("world_state", {})).duplicate(true)
		if career.world_state.has("world_seed"):
			career.world_state.world_seed = int(career.world_state.world_seed)
		for field in ["year", "quarter"]:
			if career.world_state.get("last_advanced_clock", {}).has(field):
				career.world_state.last_advanced_clock[field] = int(career.world_state.last_advanced_clock[field])
	return career

static func _restore_pre_career_integers(history_record: Dictionary) -> void:
	for field in ["version", "skating_start_age", "training_quarters"]:
		if history_record.has(field): history_record[field] = int(history_record[field])
	for episode in history_record.get("episodes", []):
		if episode is Dictionary and episode.has("age"): episode.age = int(episode.age)

static func _restore_history_entry(entry: Dictionary) -> Dictionary:
	var restored := entry.duplicate(true)
	if restored.get("category") == "dated_training":
		if restored.has("actual_jump_attempts"): restored.actual_jump_attempts = int(restored.actual_jump_attempts)
		return restored
	if restored.get("category") == "jump_attempt_batch":
		for key in ["rotations", "stage", "attempts", "successes", "clean_successes", "falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]:
			restored[key] = int(restored.get(key, 0))
		return restored
	if restored.get("category") == "jump_milestone":
		restored.rotations = int(restored.get("rotations", 1))
		if restored.get("clock") is Dictionary:
			restored.clock.year = int(restored.clock.get("year", 0))
			restored.clock.quarter = int(restored.clock.get("quarter", 1))
		return restored
	if restored.get("category") != "quarter_plan":
		return restored
	for layer in ["desired", "approved", "executed"]:
		if restored.get(layer) is Dictionary:
			for category_id in restored[layer]:
				restored[layer][category_id] = int(restored[layer][category_id])
		for suffix in ["shares", "jump_rotations"]:
			var key := "%s_%s" % [layer, suffix]
			if restored.get(key) is Dictionary:
				for item_id in restored[key]: restored[key][item_id] = int(restored[key][item_id])
	if restored.get("secret_practice") is Dictionary:
		restored.secret_practice.executed_units = int(restored.secret_practice.get("executed_units", 0))
	return restored

static func _restore_selection_numbers(value) -> void:
	if value is Dictionary:
		for key in value:
			if str(key) in ["version","season_start_year","year","quarter","seed","lottery_key","available_slots","station_choices","next_eligible_season_start_year","rank","best_rank","short_rank","final_rank","points","age","minimum_possible_age","maximum_possible_age","complete_events","member_rank","stations","per_station"] and (value[key] is int or value[key] is float):
				value[key] = int(value[key])
			elif str(key) == "tiebreak_inputs" and value[key] is Array and value[key].size() == 7:
				for index in [0,2,6]: value[key][index] = int(value[key][index])
			elif str(key) == "remaining_station_slots" and value[key] is Dictionary:
				for station in value[key]: value[key][station] = int(value[key][station])
			else: _restore_selection_numbers(value[key])
	elif value is Array:
		for child in value: _restore_selection_numbers(child)

static func restore_plan_integers(value: Dictionary) -> void:
	# JSON stores numbers as floats, including the plans nested in pending conflicts.
	for field in ["shares", "allocations", "jump_rotations", "proposed_shares", "proposed_allocations", "proposed_jump_rotations"]:
		if not value.get(field) is Dictionary: continue
		for key in value[field]:
			var number = value[field][key]
			if number is float and is_finite(number) and number == floorf(number): value[field][key] = int(number)
	for layer in ["desired", "approved", "executed"]:
		if value.get(layer) is Dictionary: restore_plan_integers(value[layer])
	for target in value.get("specialist_targets",[]):
		for field in ["allocated_attempt_budget","priority"]:
			if target.has(field): target[field] = int(target[field])
		for part in target.get("action",{}).get("parts",[]): part.rotations = int(part.rotations)
	if value.get("conflicts") is Array:
		for conflict in value.conflicts:
			if conflict is Dictionary: restore_plan_integers(conflict)

static func _restore_condition_integers(value) -> void:
	# Only normalize consumed schema fields, never arbitrary keys in extensible data.
	for record in value.get("rehabilitation",{}).values():
		for field in ["elapsed_quarters","route_quarters"]:
			if record.get(field) is float: record[field] = int(record[field])
		if record.get("dated_period_fraction") is Dictionary:
			for field in ["n","d"]:
				if record.dated_period_fraction.get(field) is float: record.dated_period_fraction[field] = int(record.dated_period_fraction[field])
	if value.get("pending_decision",{}).get("elapsed_quarters") is float:
		value.pending_decision.elapsed_quarters = int(value.pending_decision.elapsed_quarters)
	if value.get("growth_quarters") is float: value.growth_quarters = int(value.growth_quarters)
	for group in ["growth_signals", "injuries", "medical_opinions", "key_nodes"]:
		for entry in value.get(group, []):
			if not entry is Dictionary: continue
			if group == "injuries" and entry.get("remaining_quarters") is float: entry.remaining_quarters = int(entry.remaining_quarters)
			if group == "injuries" and entry.get("dated_recovery_fraction") is Dictionary:
				for field in ["n","d"]:
					if entry.dated_recovery_fraction.get(field) is float: entry.dated_recovery_fraction[field] = int(entry.dated_recovery_fraction[field])
			for clock_key in ["clock", "resolved_clock"]:
				if not entry.get(clock_key) is Dictionary: continue
				for field in ["year", "quarter"]:
					if entry[clock_key].get(field) is float: entry[clock_key][field] = int(entry[clock_key][field])

static func _restore_competition_state(data: Dictionary, copy_data: bool = true) -> Dictionary:
	var restored := data.duplicate(true) if copy_data else data
	if restored.get("packed_archive") is Dictionary:
		for key in ["version","raw_bytes"]:
			if restored.packed_archive.has(key): restored.packed_archive[key] = int(restored.packed_archive[key])
	for key in ["seed", "rng_state", "season_start_year", "provisional_rank", "public_rank"]:
		if restored.has(key): restored[key] = int(restored[key])
	# Integer JSON representations must compare identically in a compressed
	# archive's public index and immutable payload. Preserve malformed values
	# for validation rather than truncating a fractional version.
	var version = restored.get("record_version")
	if (version is int or version is float) and is_finite(float(version)) and float(version) == floor(float(version)):
		restored.record_version = int(version)
	for row in restored.get("standings", []):
		if row is Dictionary and row.has("rank"): row.rank = int(row.rank)
	_restore_competition_indices(restored)
	return restored

static func _restore_season_state(data: Dictionary) -> Dictionary:
	var restored := data.duplicate(true)
	_restore_selection_numbers(restored)
	if restored.get("entry_plan", {}) is Dictionary and restored.entry_plan.has("proposal_version"):
		restored.entry_plan.proposal_version = int(restored.entry_plan.proposal_version)
		var entries = restored.entry_plan.get("entries", {})
		if entries is Dictionary:
			for event_id in entries:
				var entry = entries[event_id]
				if entry is Dictionary and entry.get("eligibility_snapshot", {}) is Dictionary:
					var snapshot: Dictionary = entry.eligibility_snapshot
					if snapshot.has("next_eligible_season_start_year"):
						snapshot.next_eligible_season_start_year = int(snapshot.next_eligible_season_start_year)
	return restored

static func _restore_ranking_state(data: Dictionary) -> Dictionary:
	var restored := data.duplicate(true)
	for key in ["domestic_points", "isu_world", "season_world"]:
		if restored.has(key):
			if restored[key] is Dictionary:
				for field in ["points","rank"]:
					if restored[key].has(field): restored[key][field] = int(restored[key][field])
			else: restored[key] = int(restored[key])
	return restored

static func _restore_competition_indices(value) -> void:
	if value is Dictionary:
		for key in value.keys():
			if str(key) in ["part_index", "point_index", "from", "to"]:
				value[key] = int(value[key])
			else:
				_restore_competition_indices(value[key])
	elif value is Array:
		for item in value:
			_restore_competition_indices(item)
