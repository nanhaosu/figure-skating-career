class_name TrainingIntent
extends RefCounted

const MODES := ["accept", "safer", "more_aggressive", "requested_element"]

var mode := "accept"
var element_id := ""

static func create(requested_mode: String, requested_element_id: String = "") -> Dictionary:
	var errors: Array[String] = []
	if not MODES.has(requested_mode): errors.append("未知训练回应：%s" % requested_mode)
	if requested_mode == "requested_element" and requested_element_id.strip_edges().is_empty(): errors.append("请选择想争取加入的动作")
	if requested_mode != "requested_element" and not requested_element_id.strip_edges().is_empty(): errors.append("只有主动提出动作时才能填写动作编号")
	if not errors.is_empty(): return {"intent": null, "errors": errors}
	var intent = load("res://src/domain/training_intent.gd").new()
	intent.mode = requested_mode
	intent.element_id = requested_element_id.strip_edges()
	return {"intent": intent, "errors": []}

func to_dict() -> Dictionary:
	return {"mode": mode, "element_id": element_id}

static func from_dict(data: Dictionary):
	return create(str(data.get("mode", "")), str(data.get("element_id", ""))).intent
