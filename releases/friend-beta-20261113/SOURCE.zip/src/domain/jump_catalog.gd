class_name JumpCatalog
extends RefCounted

const JUMP_IDS: Array[String] = [
	"toe_loop",
	"salchow",
	"loop",
	"flip",
	"lutz",
	"axel",
]

