class_name DevelopmentRoadmap
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")

const ROUTE_IDS := ["steady", "balanced", "fast", "custom"]
const RISK_IDS := ["cautious", "normal", "aggressive"]
const STATUS_IDS := ["ahead", "on_track", "slightly_behind", "far_behind", "reassess"]

var route_id := "balanced"
var milestones: Array[Dictionary] = []
var priority_jumps: Array[String] = []
var deferred_jump := ""
var risk_attitude := "normal"
var status := "on_track"
var last_evaluation: Dictionary = {}

static func create(requested_route: String, requested_milestones: Array, requested_priorities: Array, requested_deferred: String, requested_risk: String) -> Dictionary:
	var errors: Array[String] = []
	if not ROUTE_IDS.has(requested_route): errors.append("未知成长路线：%s" % requested_route)
	if not RISK_IDS.has(requested_risk): errors.append("未知成长风险态度：%s" % requested_risk)
	if requested_milestones.is_empty(): errors.append("成长路线至少需要一个年龄节点")
	var normalized_milestones: Array[Dictionary] = []
	var previous_age := 0
	for index in requested_milestones.size():
		var milestone = requested_milestones[index]
		if not milestone is Dictionary:
			errors.append("成长节点%d必须是对象" % (index + 1)); continue
		var age = milestone.get("age")
		var rotations = milestone.get("rotations")
		var count = milestone.get("count")
		if typeof(age) != TYPE_INT or int(age) < 6 or int(age) > 30: errors.append("成长节点年龄必须为6至30岁的整数")
		if typeof(rotations) != TYPE_INT or not [2, 3].has(int(rotations)): errors.append("成长节点目标只能是双周或三周")
		if typeof(count) != TYPE_INT or int(count) < 1 or int(count) > 6: errors.append("成长节点动作数量必须为1至6")
		if typeof(age) == TYPE_INT and int(age) <= previous_age: errors.append("成长节点年龄必须严格递增")
		if typeof(age) == TYPE_INT: previous_age = int(age)
		if typeof(age) == TYPE_INT and typeof(rotations) == TYPE_INT and typeof(count) == TYPE_INT:
			normalized_milestones.append({"age": int(age), "rotations": int(rotations), "count": int(count)})
	var priorities: Array[String] = []
	if requested_priorities.size() > 2: errors.append("优先跳跃最多选择两个")
	for raw_id in requested_priorities:
		var jump_id := str(raw_id)
		if not JumpCatalog.JUMP_IDS.has(jump_id): errors.append("未知优先跳跃：%s" % jump_id)
		elif priorities.has(jump_id): errors.append("优先跳跃不能重复：%s" % jump_id)
		else: priorities.append(jump_id)
	if not requested_deferred.is_empty() and not JumpCatalog.JUMP_IDS.has(requested_deferred): errors.append("未知暂缓跳跃：%s" % requested_deferred)
	if priorities.has(requested_deferred): errors.append("暂缓跳跃不能同时是优先跳跃")
	if not errors.is_empty(): return {"roadmap": null, "errors": errors}
	var roadmap = load("res://src/domain/development_roadmap.gd").new()
	roadmap.route_id = requested_route
	roadmap.milestones = normalized_milestones
	roadmap.priority_jumps = priorities
	roadmap.deferred_jump = requested_deferred
	roadmap.risk_attitude = requested_risk
	return {"roadmap": roadmap, "errors": []}

func to_dict() -> Dictionary:
	return {"route_id": route_id, "milestones": milestones.duplicate(true), "priority_jumps": priority_jumps.duplicate(), "deferred_jump": deferred_jump, "risk_attitude": risk_attitude, "status": status, "last_evaluation": last_evaluation.duplicate(true)}

static func from_dict(data: Dictionary):
	var normalized_milestones: Array = []
	for raw_milestone in data.get("milestones", []):
		if not raw_milestone is Dictionary:
			normalized_milestones.append(raw_milestone)
			continue
		var milestone: Dictionary = raw_milestone.duplicate(true)
		for key in ["age", "rotations", "count"]:
			var value = milestone.get(key)
			if (value is int or value is float) and is_equal_approx(float(value), floorf(float(value))):
				milestone[key] = int(value)
		normalized_milestones.append(milestone)
	# Correct only the old built-in fast preset; custom roadmaps retain their
	# selected breadth. This changes a goal, never the athlete's learned skills.
	if str(data.get("route_id","")) == "fast" and normalized_milestones.size() == 2:
		var first = normalized_milestones[0]
		var second = normalized_milestones[1]
		if first is Dictionary and second is Dictionary and first.get("rotations") == 2 and first.get("count") == 6 and second.get("rotations") == 3 and second.get("count") == 4:
			second.count = 5
	var result := create(str(data.get("route_id", "")), normalized_milestones, Array(data.get("priority_jumps", [])), str(data.get("deferred_jump", "")), str(data.get("risk_attitude", "")))
	if result.roadmap == null: return null
	result.roadmap.status = str(data.get("status", "on_track")) if STATUS_IDS.has(str(data.get("status", "on_track"))) else "on_track"
	if data.get("last_evaluation", {}) is Dictionary: result.roadmap.last_evaluation = Dictionary(data.get("last_evaluation", {})).duplicate(true)
	return result.roadmap
