class_name OlympicQuotaState
extends RefCounted

static func empty(edition: int = 2022) -> Dictionary:
	return {"version":1,"edition":edition,"status":"unknown","worlds":{},"qualifier":{},"current":{},"receipts":{},"dispatch":{}}

static func validate(value: Variant) -> String:
	if not value is Dictionary or value.get("version") != 1 or not _whole(value.get("edition")) or int(value.edition) not in [2022,2026] or value.get("status") not in ["unknown","worlds_complete","qualifier_complete","reallocated"]: return "奥运国家席位状态无效"
	var milano: bool = value.edition == 2026
	if milano and value.status == "reallocated": return "米兰周期没有可核对的递补处理"
	var policy := "milano2026_D1_D2" if milano else "beijing2022_20210309_D1_D2"
	var source_events := ["isu_wc2025","isu_olympic_qualifier_beijing_2025"] if milano else ["isu_wc2021","isu_olympic_qualifier_nebelhorn_2021"]
	for key in ["worlds","qualifier","current","receipts","dispatch"]:
		if not value.get(key) is Dictionary: return "奥运国家席位缺少对象字段："+key
	if value.status == "unknown":
		if not value.current.is_empty() or not value.worlds.is_empty() or not value.qualifier.is_empty() or not value.receipts.is_empty() or not value.dispatch.is_empty(): return "未知国家席位不得预先发放资格"
		return ""
	for stage in ["worlds","qualifier","current"]:
		var record: Dictionary = value[stage]
		if record.is_empty() and stage == "qualifier": continue
		if record.get("policy_id") != policy or not record.get("countries") is Dictionary or not record.get("details") is Dictionary or not record.get("worlds_free_ids") is Array or not record.get("standby") is Array: return "国家席位分配依据缺失"
		var total := 0
		for federation in record.countries:
			var count = record.countries[federation]
			if not federation is String or federation.length() != 3 or not _whole(count) or int(count) < 0 or int(count) > 3: return "国家席位必须为0至3的整数"
			total += int(count)
		var neutral = record.get("neutral_awards",{})
		if not neutral is Dictionary or (not milano or stage == "worlds") and not neutral.is_empty(): return "个人中立席位资料无效"
		for id in neutral:
			var award = neutral[id]
			if not id is String or id.is_empty() or not award is Dictionary or award.get("athlete_id") != id or award.get("places") != 1: return "个人中立席位资料无效"
			total += 1
		if not _whole(record.get("ordinary_places")) or int(record.ordinary_places) != total or total > (24 if stage == "worlds" else (29 if milano else 30)): return "国家普通席位合计无效"
		if not record.get("host_additional") is Dictionary or not record.get("reallocation_receipts") is Dictionary: return "主办国额外席位或递补凭据无效"
		for federation in record.host_additional:
			var host = record.host_additional[federation]
			if federation != ("ITA" if milano else "CHN") or not host is Dictionary or host.get("places") != 1 or host.get("ordinary_quota") != false or host.get("personal_eligibility_required") != true: return "主办国额外席位不能绕过个人资格"
	for id in value.receipts:
		var receipt = value.receipts[id]
		if id not in source_events or not receipt is Dictionary or not receipt.get("fingerprint") is String or receipt.fingerprint.length() != 64: return "国家席位赛果凭据无效"
	if milano:
		if not value.receipts.has(source_events[0]) or value.worlds.get("status") != "worlds_complete" or value.current.get("status") != value.status: return "米兰奥运席位来源或阶段不符"
		if value.worlds.get("source_event_id") != source_events[0] or value.worlds.get("fingerprint") != value.receipts[source_events[0]].fingerprint: return "米兰世锦赛席位归档凭据不符"
		if value.status == "worlds_complete" and (not value.qualifier.is_empty() or not value.dispatch.is_empty() or value.current != value.worlds): return "米兰世锦赛席位记录不符"
		if value.status == "qualifier_complete":
			if not value.receipts.has(source_events[1]) or value.qualifier.get("status") != "qualifier_complete" or value.current != value.qualifier: return "米兰资格赛席位记录不符"
			if value.qualifier.get("source_event_id") != source_events[1] or value.qualifier.get("fingerprint") != value.receipts[source_events[1]].fingerprint: return "米兰资格赛席位归档凭据不符"
			if int(value.qualifier.ordinary_places) - int(value.worlds.ordinary_places) > 5: return "米兰资格赛女单新增席位超过五席"
		if not value.dispatch.is_empty():
			var dispatch: Dictionary = value.dispatch
			if dispatch.get("event_id") != "isu_owg2026" or dispatch.get("policy_id") != "milano2026_dispatch" or dispatch.get("quota_fingerprint") != value.current.get("fingerprint") or not dispatch.get("selected_ids") is Array or dispatch.selected_ids.size() > int(value.current.countries.get("CHN",0)): return "米兰中国队派遣与国家席位不符"
			var seen := {}
			for id in dispatch.selected_ids:
				if not id is String or id.is_empty() or seen.has(id): return "米兰中国队派遣身份无效"
				seen[id] = true
	return ""

static func normalize(value: Dictionary) -> Dictionary:
	var result := value.duplicate(true)
	result.version = int(result.get("version",1))
	result.edition = int(result.get("edition",2022))
	for key in ["worlds","qualifier","current"]:
		var record: Dictionary = result.get(key,{})
		if record.is_empty(): continue
		record.ordinary_places = int(record.get("ordinary_places",0))
		for federation in record.get("countries",{}): record.countries[federation] = int(record.countries[federation])
		for detail in record.get("details",{}).values():
			for field in ["best_rank","points","potential","free_qualifiers","worlds_places"]:
				if detail.has(field): detail[field] = int(detail[field])
	return result

static func _whole(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value))
