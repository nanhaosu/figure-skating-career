class_name ProgramElement
extends RefCounted

const KIND_IDS := ["jump", "spin", "step_sequence", "choreographic_sequence"]
const JUMP_IDS := ["toe_loop", "salchow", "loop", "flip", "lutz", "axel"]
const SPIN_CODES := ["CCoSp", "FCSp", "LSp", "FSSp", "CSp", "SSp"]

var element_id := ""
var kind := ""
var jump_id := ""
var rotations := 0
var combination_parts: Array[Dictionary] = []
var spin_code := "CCoSp"
var planned_entry := "standard"
var planned_exit := "standard"
var target_level := 4
# Normalized 0..1 entry demand and rink coordinates. Empty anchor means automatic placement.
var entry_difficulty := 0.0
var ice_anchor: Dictionary = {}

func set_combination_parts(parts: Array) -> Array[String]:
	var errors: Array[String] = []
	var normalized: Array[Dictionary] = []
	if kind != "jump" and not parts.is_empty():
		return ["只有跳跃动作可以设置连跳"]
	if parts.size() > 2: errors.append("连跳最多追加两个跳跃")
	for index in mini(parts.size(), 2):
		var part = parts[index]
		if not part is Dictionary:
			errors.append("连跳第%d跳数据无效" % [index + 2])
			continue
		var part_jump_id := str(part.get("jump_id", ""))
		var part_rotations := int(part.get("rotations", 0))
		if not JUMP_IDS.has(part_jump_id): errors.append("连跳第%d跳跳种无效" % [index + 2])
		if part_rotations < 1 or part_rotations > 4: errors.append("连跳第%d跳周数必须为1至4" % [index + 2])
		if JUMP_IDS.has(part_jump_id) and part_rotations >= 1 and part_rotations <= 4:
			normalized.append({"jump_id": part_jump_id, "rotations": part_rotations})
	if errors.is_empty(): combination_parts = normalized
	return errors

static func create(requested_id: String, requested_kind: String, requested_jump_id: String = "", requested_rotations: int = 0) -> Dictionary:
	var errors: Array[String] = []
	if requested_id.strip_edges().is_empty(): errors.append("节目动作必须有唯一编号")
	if not KIND_IDS.has(requested_kind): errors.append("未知节目动作类型：%s" % requested_kind)
	if requested_kind == "jump":
		if requested_jump_id.is_empty(): errors.append("跳跃动作必须选择跳种")
		if requested_rotations < 1 or requested_rotations > 4: errors.append("跳跃周数必须为1至4")
	elif not requested_jump_id.is_empty() or requested_rotations != 0:
		errors.append("非跳跃动作不能设置跳种或周数")
	if not errors.is_empty(): return {"element": null, "errors": errors}
	var element = load("res://src/domain/program_element.gd").new()
	element.element_id = requested_id.strip_edges()
	element.kind = requested_kind
	element.jump_id = requested_jump_id
	element.rotations = requested_rotations
	return {"element": element, "errors": []}

func to_dict() -> Dictionary:
	return {
		"element_id": element_id, "kind": kind, "jump_id": jump_id, "rotations": rotations,
		"combination_parts": combination_parts.duplicate(true),
		"spin_code": spin_code,
		"planned_entry": planned_entry, "planned_exit": planned_exit,
		"target_level": target_level, "entry_difficulty": entry_difficulty, "ice_anchor": ice_anchor.duplicate(true),
	}

static func from_dict(data: Dictionary):
	var level = data.get("target_level", 4)
	if not (level is int or level is float) or not is_finite(float(level)) or float(level) != floor(float(level)) or float(level) < 1 or float(level) > 4: return null
	var entry = data.get("entry_difficulty", 0.0)
	if not (entry is int or entry is float) or not is_finite(float(entry)) or float(entry) < 0.0 or float(entry) > 1.0: return null
	var anchor = data.get("ice_anchor", {})
	if not anchor is Dictionary: return null
	if not anchor.is_empty():
		for axis in ["x", "y"]:
			var coordinate = anchor.get(axis)
			if not (coordinate is int or coordinate is float) or not is_finite(float(coordinate)) or float(coordinate) < 0.0 or float(coordinate) > 1.0: return null
	if not data.get("combination_parts", []) is Array: return null
	var result := create(str(data.get("element_id", "")), str(data.get("kind", "")), str(data.get("jump_id", "")), int(data.get("rotations", 0)))
	if result.element == null: return null
	if not result.element.set_combination_parts(Array(data.get("combination_parts", []))).is_empty(): return null
	if result.element.kind == "spin":
		var saved_spin_code := str(data.get("spin_code", "CCoSp"))
		if not SPIN_CODES.has(saved_spin_code): return null
		result.element.spin_code = saved_spin_code
	result.element.planned_entry = str(data.get("planned_entry", "standard"))
	result.element.planned_exit = str(data.get("planned_exit", "standard"))
	result.element.target_level = int(data.get("target_level", 4))
	result.element.entry_difficulty = float(data.get("entry_difficulty", 0.0))
	if data.get("ice_anchor", {}) is Dictionary: result.element.ice_anchor = Dictionary(data.get("ice_anchor", {})).duplicate(true)
	return result.element
