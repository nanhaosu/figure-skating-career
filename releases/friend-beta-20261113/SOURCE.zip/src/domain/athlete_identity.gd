class_name AthleteIdentity
extends RefCounted

# An empty date deliberately means year-only knowledge, never January 1.
static func validate_birth_date(value: Dictionary, birth_year: int) -> Array[String]:
	var errors: Array[String] = []
	if value.is_empty(): return errors
	if value.size() != 3:
		errors.append("生日必须只包含年、月、日")
		return errors
	for key in ["year","month","day"]:
		if not _integer(value.get(key)):
			errors.append("生日%s必须为有限整数" % key)
	if not errors.is_empty(): return errors
	var year := int(value.year)
	var month := int(value.month)
	var day := int(value.day)
	if year < 1 or year > 9999 or year != birth_year:
		errors.append("生日年份必须与出生年份一致")
	if month < 1 or month > 12:
		errors.append("生日月份必须在1至12之间")
		return errors
	var days := [31,28,31,30,31,30,31,31,30,31,30,31]
	if year % 400 == 0 or (year % 4 == 0 and year % 100 != 0): days[1] = 29
	if day < 1 or day > int(days[month - 1]): errors.append("生日不是有效的日历日期")
	return errors

static func canonical_birth_date(value: Dictionary, birth_year: int) -> Dictionary:
	var result := value.duplicate(true)
	# Normalize only already-valid JSON integers. Invalid data must remain
	# rejectable at persistence boundaries, never become a plausible birthday.
	if not result.is_empty() and validate_birth_date(result,birth_year).is_empty():
		for key in ["year","month","day"]: result[key] = int(result[key])
	return result

static func age_gate(birth_year: int, birth_date: Dictionary, season_start_year: int, min_age: int, max_age: int) -> Dictionary:
	var result := {"status":"unknown","minimum_possible_age":null,"maximum_possible_age":null,"age":null,"reason_codes":[]}
	if birth_year < 1 or birth_year > 9999 or season_start_year < birth_year or season_start_year > 9999 or min_age < 0 or max_age < min_age:
		result.reason_codes = ["invalid_age_inputs"]
		return result
	if not validate_birth_date(birth_date,birth_year).is_empty():
		result.reason_codes = ["invalid_birth_date"]
		return result
	var highest := season_start_year - birth_year
	var lowest := highest - 1
	if not birth_date.is_empty():
		var age := highest - (1 if int(birth_date.month) >= 7 else 0)
		lowest = age
		highest = age
		result.age = age
	result.minimum_possible_age = lowest
	result.maximum_possible_age = highest
	if lowest >= min_age and highest <= max_age:
		result.status = "eligible"
	elif highest < min_age or lowest > max_age:
		result.status = "ineligible"
		result.reason_codes = ["age_below_minimum" if highest < min_age else "age_above_maximum"]
	else:
		result.reason_codes = ["birth_date_required"]
	return result

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value))
