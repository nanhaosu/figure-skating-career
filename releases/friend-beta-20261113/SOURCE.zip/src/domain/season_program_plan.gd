class_name SeasonProgramPlan
extends RefCounted

static func create(season_id: String) -> Dictionary:
	return {"season_id":season_id,"status":"unplanned","revision":0,"programs":{},"targets":{},"receipts":[]}

static func validate(data: Dictionary) -> String:
	if data.has("preparation"):
		var preparation = data.preparation
		if not preparation is Dictionary or not preparation.get("route_id") in ["combination","axel","programme"] or not preparation.get("target_event_id") is String or str(preparation.get("target_event_id","")).is_empty(): return "赛季备战记录无效"
		if not preparation.get("chosen_date") is String or not preload("res://src/simulation/dated_training_window.gd").valid_range(preparation.chosen_date,preparation.chosen_date): return "赛季备战日期无效"
		if not preload("res://src/content/annual_selection_policy_repository.gd").integer(preparation.get("direction_revision"),0,1000000): return "赛季备战修订号无效"
	var map_error := validate_group_programs(data.get("programs_by_level",{}))
	if not map_error.is_empty(): return map_error
	if data.has("competitive_level") and not data.competitive_level in ["junior","transition","senior"]:
		return "赛季参赛组别无效"
	if not data.get("season_id") is String or not data.get("status") in ["unplanned","draft","confirmed"]:
		return "赛季节目规划状态无效"
	var revision = data.get("revision")
	if not (revision is int or revision is float) or not is_finite(float(revision)) or float(revision) < 0 or float(revision) != floorf(float(revision)):
		return "赛季节目规划 revision 必须为非负整数"
	for field in ["programs","targets"]:
		if not data.get(field) is Dictionary: return "赛季节目规划 %s 必须为对象" % field
	for segment in data.targets:
		if not str(segment) in ["short","free"] or not data.targets[segment] is Array or data.targets[segment].size() > 32: return "赛季专项目标必须是有界的节目动作列表"
		for target in data.targets[segment]:
			if not target is Dictionary or not target.get("action") is Dictionary: return "赛季专项目标缺少动作"
			if target.action.get("kind") != "jump" or preload("res://src/domain/technical_repertoire.gd").action_id(target.action).is_empty(): return "赛季专项目标跳跃无效"
			if target.has("element_id") and not target.element_id is String: return "赛季目标动作编号必须为文本"
	for segment in data.programs:
		if not str(segment) in ["short","free"] or not data.programs[segment] is Dictionary: return "赛季节目格式无效"
		var program = preload("res://src/domain/skating_program.gd").from_dict(data.programs[segment])
		if program == null or program.segment != segment: return "赛季节目内容无效"
	if not data.get("receipts") is Array: return "赛季节目规划 receipts 必须为数组"
	for receipt in data.receipts:
		if not receipt is String: return "赛季节目规划确认记录无效"
	return ""

static func validate_group_programs(groups: Variant) -> String:
	if not groups is Dictionary: return "两组节目必须按组别保存"
	for level in groups:
		if level not in ["junior","senior"] or not groups[level] is Dictionary: return "节目参赛组别无效"
		for segment in groups[level]:
			if segment not in ["short","free"] or not groups[level][segment] is Dictionary: return "分组节目格式无效"
			var program = preload("res://src/domain/skating_program.gd").from_dict(groups[level][segment])
			if program == null or program.segment != segment: return "分组节目内容无效"
	return ""
