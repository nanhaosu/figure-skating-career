class_name StoryContext
extends RefCounted

const SUPPORTED_DISCIPLINE := "women_singles"
const STORY_TIME_RULE_MODE := "story_time"

var discipline: String
var home_federation: String
var start_year: int
var rule_mode: String

func _init(
	initial_discipline: String = SUPPORTED_DISCIPLINE,
	initial_federation: String = "CHN",
	initial_start_year: int = 2014,
	initial_rule_mode: String = STORY_TIME_RULE_MODE,
) -> void:
	discipline = initial_discipline
	home_federation = initial_federation
	start_year = initial_start_year
	rule_mode = initial_rule_mode

static func women_singles_2014(federation: String = "CHN"):
	return StoryContext.new(SUPPORTED_DISCIPLINE, federation, 2014, STORY_TIME_RULE_MODE)

func to_dict() -> Dictionary:
	return {
		"discipline": discipline,
		"home_federation": home_federation,
		"start_year": start_year,
		"rule_mode": rule_mode,
	}

static func from_dict(data: Dictionary):
	return StoryContext.new(
		str(data.get("discipline", SUPPORTED_DISCIPLINE)),
		str(data.get("home_federation", "CHN")),
		int(data.get("start_year", 2014)),
		str(data.get("rule_mode", STORY_TIME_RULE_MODE)),
	)

static func validate(data: Dictionary) -> String:
	if str(data.get("discipline", "")) != SUPPORTED_DISCIPLINE:
		return "故事背景 discipline 目前只支持 women_singles"
	if not data.get("home_federation") is String or str(data.home_federation).length() != 3:
		return "故事背景 home_federation 必须是三位协会代码"
	if str(data.get("rule_mode", "")) != STORY_TIME_RULE_MODE:
		return "故事背景 rule_mode 目前只支持 story_time"
	var year = data.get("start_year")
	if not (year is int or year is float) or not is_equal_approx(float(year), floorf(float(year))):
		return "故事背景 start_year 必须是整数"
	return ""
