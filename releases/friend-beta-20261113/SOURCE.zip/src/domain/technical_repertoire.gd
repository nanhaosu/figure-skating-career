class_name TechnicalRepertoire
extends RefCounted

const CODES := {"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz","axel":"A"}
const DATED_SOURCE_LIMIT := 23

# The old quarter model assesses four practice stages. A calendar day is an
# execution receipt, not an entire independent assessment session.
static func dated_assessment_id(date: String) -> String:
	var dates = preload("res://src/simulation/dated_training_window.gd")
	if not dates.plan(date,date).errors.is_empty(): return ""
	var year := int(date.substr(0,4)); var quarter := (int(date.substr(5,2))-1)/3+1
	var first := "%04d-%02d-01T00:00:00" % [year,(quarter-1)*3+1]
	var next := "%04d-%02d-01T00:00:00" % [year+(1 if quarter == 4 else 0),1 if quarter == 4 else quarter*3+1]
	var start := int(Time.get_unix_time_from_datetime_string(first))
	var days := (int(Time.get_unix_time_from_datetime_string(next))-start)/86400
	var offset := (int(Time.get_unix_time_from_datetime_string(date+"T00:00:00"))-start)/86400
	return "dated-assessment:%d:%d:%d" % [year,quarter,(offset*4)/days]

static func empty() -> Dictionary:
	return {"entries":{}}

static func first_context_type(value: String) -> String:
	return str({"practice":"practice","specialist":"practice","program":"program","program_early":"program","program_late":"program_late","competition":"competition"}.get(value,""))

static func action_id(action: Dictionary) -> String:
	var parts = action.get("parts",[])
	if not parts is Array or parts.is_empty() or parts.size() > 3: return ""
	var codes: PackedStringArray = []
	for part in parts:
		if not part is Dictionary or not CODES.has(part.get("jump_id")): return ""
		if not _count(part.get("rotations")) or int(part.rotations) < 1 or int(part.rotations) > 4: return ""
		codes.append("%d%s" % [int(part.rotations),CODES[part.jump_id]])
	return "+".join(codes)

static func entry(action: Dictionary, legacy: bool = false) -> Dictionary:
	return {"action":action.duplicate(true),"state":"training","legacy_unverified":legacy,
		"evidence":[],"learned_history":{},"reason_codes":[],"context_warnings":[]}

static func migrate_legacy(career: Dictionary) -> Dictionary:
	var result := empty()
	var jumps: Dictionary = career.get("athlete",{}).get("jumps",{})
	for jump_id in jumps:
		if not jumps[jump_id] is Dictionary: continue
		for rotation in range(1,mini(4,int(jumps[jump_id].get("unlocked_rotations",0)))+1):
			var action := {"kind":"jump","parts":[{"jump_id":jump_id,"rotations":rotation}]}
			var id := action_id(action)
			if id.is_empty(): continue
			var restored := entry(action,true)
			restored.state = "available"
			restored.learned_history = {"ever_learned":true,"source":"legacy_single"}
			result.entries[id] = restored
	for program in career.get("active_programs",{}).values():
		if not program is Dictionary: continue
		for element in program.get("elements",[]):
			if not element is Dictionary or element.get("kind") != "jump": continue
			var tail = element.get("combination_parts",[])
			if not tail is Array or tail.is_empty(): continue
			var parts: Array = [{"jump_id":element.get("jump_id",""),"rotations":element.get("rotations",0)}]
			parts.append_array(tail)
			var action := {"kind":"jump","parts":parts}
			var id := action_id(action)
			if not id.is_empty(): result.entries[id] = entry(action,true)
	return result

static func validate(data: Dictionary) -> String:
	if not data.get("entries") is Dictionary: return "技术储备 entries 必须为对象"
	for id in data.entries:
		var item = data.entries[id]
		if not item is Dictionary or not item.get("action") is Dictionary: return "技术储备动作无效"
		if action_id(item.action) != id or str(id).is_empty(): return "技术储备动作编号不一致"
		if not item.get("state") in ["training","available","unavailable"]: return "技术储备状态无效"
		if not item.get("legacy_unverified") is bool or not item.get("learned_history") is Dictionary: return "技术储备历史无效"
		if item.learned_history.has("first_success_contexts"):
			var contexts = item.learned_history.first_success_contexts
			if not contexts is Dictionary or contexts.size() > 4: return "首次完成情境必须是有界对象"
			for context in contexts:
				if not context in ["practice","program","program_late","competition"]: return "首次完成情境无效"
				var milestone = contexts[context]
				if not milestone is Dictionary or not milestone.get("batch_id") is String or str(milestone.get("batch_id","")).is_empty(): return "首次完成缺少批次"
				if not _count(milestone.get("source_sequence")) or int(milestone.source_sequence) < 1 or int(milestone.source_sequence) > int(item.learned_history.get("record_count",0)): return "首次完成记录序号无效"
				var clock = milestone.get("clock")
				if not clock is Dictionary or not _count(clock.get("year")) or int(clock.year) < 1 or not _count(clock.get("quarter")) or int(clock.quarter) not in [1,2,3,4]: return "首次完成时点无效"
		if not item.get("evidence") is Array or item.evidence.size() > 32: return "技术储备证据必须为最多32条的数组"
		for evidence in item.evidence:
			var error := validate_evidence(evidence,str(id))
			if not error.is_empty(): return error
	return ""

static func validate_evidence(evidence, id: String) -> String:
	if not evidence is Dictionary: return "技术储备证据必须为对象"
	if not evidence.get("batch_id") is String or str(evidence.batch_id).is_empty() or evidence.get("action_id") != id:
		return "技术储备证据编号无效"
	if not evidence.get("clock") is Dictionary or not evidence.get("context") is String or not evidence.get("assessment_eligible") is bool:
		return "技术储备证据情境无效"
	for field in ["attempts","successes","clean_successes"]:
		if not _count(evidence.get(field)): return "技术储备证据 %s 必须为非负整数" % field
	if float(evidence.clean_successes) > float(evidence.successes) or float(evidence.successes) > float(evidence.attempts):
		return "技术储备完成次数超过尝试次数"
	if not evidence.get("failure_counts") is Dictionary: return "技术储备失败记录必须为对象"
	for value in evidence.failure_counts.values():
		if not _count(value): return "技术储备失败次数必须为非负整数"
	if evidence.has("source_id") or evidence.has("source_ids"):
		if evidence.has("source_id") and evidence.has("source_ids"): return "日期训练来源不能同时包含单日与汇总"
		var sources = [evidence.source_id] if evidence.has("source_id") else evidence.source_ids
		if not sources is Array or sources.is_empty() or sources.size() > DATED_SOURCE_LIMIT: return "日期训练来源必须为有界非空数组"
		var unique := {}
		for source in sources:
			if not source is String or source.is_empty() or dated_assessment_id(source) != evidence.batch_id: return "日期训练来源与评估阶段不一致"
			if unique.has(source): return "日期训练来源不能重复"
			unique[source] = true
			var quarter := (int(source.substr(5,2))-1)/3+1
			if not _count(evidence.clock.get("year")) or not _count(evidence.clock.get("quarter")) or int(evidence.clock.year) != int(source.substr(0,4)) or int(evidence.clock.quarter) != quarter: return "日期训练来源与季度不一致"
	return ""

static func _count(value) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0 and float(value) == floorf(float(value))
