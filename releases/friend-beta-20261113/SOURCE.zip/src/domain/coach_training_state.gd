class_name CoachTrainingState
extends RefCounted

const FAMILIES := ["toe_loop","salchow","loop","flip","lutz","axel"]
const DECISION_FIELDS := ["period_key","coach_id","gap_ids","allocated_gap_ids","reason_codes"]

static func defaults() -> Dictionary:
	return {"version":1,"completed_periods":0,"last_practiced":{},"last_completed_period":"","last_decision":{}}

static func validate_decision(data) -> Array[String]:
	var errors: Array[String] = []
	if not data is Dictionary: return ["教练决策必须为对象"]
	for key in data:
		if not key in DECISION_FIELDS: errors.append("未知教练决策字段：%s" % key); continue
		if key in ["period_key","coach_id"]:
			if not _text(data[key]): errors.append("教练决策字符串无效")
		else:
			var limit := 12 if key == "reason_codes" else 6
			if not data[key] is Array or data[key].size() > limit:
				errors.append("教练决策列表超出范围"); continue
			var seen := {}
			for item in data[key]:
				if not _text(item) or seen.has(item): errors.append("教练决策列表无效")
				else: seen[item] = true
				if key != "reason_codes" and not item in FAMILIES: errors.append("未知教练跳跃类别")
	return errors

static func validate(data: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	var expected := defaults()
	for key in expected:
		if not data.has(key): errors.append("教练课程记忆缺少%s" % key)
	for key in data:
		if not expected.has(key): errors.append("未知教练课程记忆字段")
	if not _integer(data.get("version")) or int(data.get("version",0)) != 1: errors.append("教练课程记忆版本无效")
	if not _integer(data.get("completed_periods")): errors.append("教练课程记忆期数无效")
	if not _text(data.get("last_completed_period")): errors.append("教练课程记忆日期无效")
	var practiced = data.get("last_practiced")
	if not practiced is Dictionary or practiced.size() > 6: errors.append("教练课程记忆类别无效")
	else:
		for key in practiced:
			if not key in FAMILIES or not _integer(practiced[key]): errors.append("教练课程记忆练习无效")
			elif _integer(data.get("completed_periods")) and int(practiced[key]) > int(data.completed_periods): errors.append("练习不能晚于已完成训练期")
	errors.append_array(validate_decision(data.get("last_decision")))
	return errors

static func normalize(data: Dictionary) -> Dictionary:
	var normalized := data.duplicate(true)
	for key in ["version","completed_periods"]:
		if _integer(normalized.get(key)): normalized[key] = int(normalized[key])
	if normalized.get("last_practiced") is Dictionary:
		for key in normalized.last_practiced:
			if _integer(normalized.last_practiced[key]): normalized.last_practiced[key] = int(normalized.last_practiced[key])
	return normalized

static func _integer(value) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0 and float(value) == floorf(float(value)) and float(value) <= 1000000.0

static func _text(value) -> bool:
	return value is String and value.length() <= 128
