class_name TrainingPlan
extends RefCounted

const CATEGORY_IDS: Array[String] = [
	"skating_foundation",
	"jump_toe_loop",
	"jump_salchow",
	"jump_loop",
	"jump_flip",
	"jump_lutz",
	"jump_axel",
	"rotation",
	"conditioning",
	"rest",
	"program_short",
	"program_free",
]
const PROGRAM_CATEGORY_IDS: Array[String] = ["program_short", "program_free"]
const REQUIRED_CATEGORY_IDS: Array[String] = [
	"skating_foundation", "jump_toe_loop", "jump_salchow", "jump_loop", "jump_flip",
	"jump_lutz", "jump_axel", "rotation", "conditioning", "rest",
]
const UNITS_PER_QUARTER := 12
const SHARE_STEP := 5
const TOTAL_SHARE := 100
const JUMP_LABELS := {
	"toe_loop": "后外点冰跳", "salchow": "后内结环跳", "loop": "后外结环跳",
	"flip": "后内点冰跳", "lutz": "勾手跳", "axel": "阿克塞尔跳",
}

var allocations: Dictionary:
	get:
		return _allocations.duplicate()

var shares: Dictionary:
	get:
		return _shares.duplicate()

var jump_rotations: Dictionary:
	get:
		return _jump_rotations.duplicate()

var _allocations: Dictionary = {}
var _shares: Dictionary = {}
var _jump_rotations: Dictionary = {}
var specialist_targets: Array[Dictionary] = []
var expression_share: int = 0
var lesson_quality: Dictionary = {}
var focus_lessons: Dictionary = {}
var coach_decision: Dictionary = {}

static func create(requested_values: Dictionary, requested_jump_rotations: Dictionary = {}) -> Dictionary:
	if requested_jump_rotations.is_empty() and _looks_like_legacy_units(requested_values):
		return _create_legacy(requested_values)
	return _create_percentage(requested_values, requested_jump_rotations)

static func _create_legacy(requested_allocations: Dictionary) -> Dictionary:
	var errors: Array[String] = []
	var normalized_allocations := requested_allocations.duplicate(true)
	for program_category in PROGRAM_CATEGORY_IDS:
		if not normalized_allocations.has(program_category):
			normalized_allocations[program_category] = 0
	for category_id in REQUIRED_CATEGORY_IDS:
		if not normalized_allocations.has(category_id):
			errors.append("缺少训练类别：%s" % category_id)
	for category_id in normalized_allocations:
		if not CATEGORY_IDS.has(category_id):
			errors.append("未知训练类别：%s" % category_id)
			continue
		var value: Variant = normalized_allocations[category_id]
		if typeof(value) != TYPE_INT:
			errors.append("训练类别%s必须使用整数单位" % category_id)
		elif value < 0:
			errors.append("训练类别%s不能为负数" % category_id)

	var total := 0
	var values_are_valid := true
	for category_id in CATEGORY_IDS:
		if not normalized_allocations.has(category_id):
			values_are_valid = false
			continue
		var value: Variant = normalized_allocations[category_id]
		if typeof(value) != TYPE_INT:
			values_are_valid = false
			continue
		total += int(value)
		if value < 0:
			values_are_valid = false
	if total != UNITS_PER_QUARTER:
		errors.append("每季度必须正好分配12个训练单位，当前为%d" % total)
	if normalized_allocations.has("rest") and typeof(normalized_allocations["rest"]) == TYPE_INT and int(normalized_allocations["rest"]) < 1:
		errors.append("每季度至少需要1个恢复单位")
	if not errors.is_empty() or not values_are_valid:
		return {"plan": null, "errors": errors}

	var plan = load("res://src/domain/training_plan.gd").new()
	plan._allocations = normalized_allocations
	return {"plan": plan, "errors": []}

static func _create_percentage(requested_shares: Dictionary, requested_jump_rotations: Dictionary) -> Dictionary:
	var errors: Array[String] = []
	var normalized_shares := requested_shares.duplicate(true)
	for program_category in PROGRAM_CATEGORY_IDS:
		if not normalized_shares.has(program_category): normalized_shares[program_category] = 0
	for category_id in REQUIRED_CATEGORY_IDS:
		if not normalized_shares.has(category_id):
			errors.append("缺少训练类别：%s" % category_id)
	for category_id in normalized_shares:
		if not CATEGORY_IDS.has(category_id):
			errors.append("未知训练类别：%s" % category_id)
			continue
		var value: Variant = normalized_shares[category_id]
		if typeof(value) != TYPE_INT:
			errors.append("训练类别%s必须使用整数百分比" % category_id)
		elif int(value) < 0:
			errors.append("训练类别%s不能为负数" % category_id)

	var total := 0
	var valid_numbers := true
	var invalid_step := false
	for category_id in CATEGORY_IDS:
		if not normalized_shares.has(category_id) or typeof(normalized_shares[category_id]) != TYPE_INT:
			valid_numbers = false
			continue
		var value := int(normalized_shares[category_id])
		total += value
		if value < 0:
			valid_numbers = false
		if value % SHARE_STEP != 0:
			invalid_step = true
	if invalid_step:
		errors.append("所有训练比例必须以5%为步长")
	if total != TOTAL_SHARE:
		errors.append("训练比例总和必须为100" + "%，当前为" + str(total) + "%")
	if normalized_shares.has("rest") and typeof(normalized_shares.rest) == TYPE_INT and int(normalized_shares.rest) < SHARE_STEP:
		errors.append("恢复与自由活动至少需要5%")

	for target_id in requested_jump_rotations:
		if not JUMP_LABELS.has(target_id):
			errors.append("未知跳跃目标：%s" % target_id)
		elif typeof(requested_jump_rotations[target_id]) != TYPE_INT or int(requested_jump_rotations[target_id]) < 1 or int(requested_jump_rotations[target_id]) > 4:
			errors.append("%s目标周数必须为1至4" % JUMP_LABELS[target_id])
	for jump_id in JUMP_LABELS:
		var category_id := "jump_%s" % jump_id
		if int(normalized_shares.get(category_id, 0)) > 0 and not requested_jump_rotations.has(jump_id):
			errors.append("%s有训练比例但未选择目标周数" % JUMP_LABELS[jump_id])

	if not errors.is_empty() or not valid_numbers:
		return {"plan": null, "errors": errors}
	var plan = load("res://src/domain/training_plan.gd").new()
	plan._shares = normalized_shares
	plan._jump_rotations = requested_jump_rotations.duplicate(true)
	return {"plan": plan, "errors": []}

static func _integer_total(values: Dictionary) -> int:
	var total := 0
	for value in values.values():
		if typeof(value) != TYPE_INT:
			return -1
		total += int(value)
	return total

static func _looks_like_legacy_units(values: Dictionary) -> bool:
	var total := _integer_total(values)
	if total < 0 or total > UNITS_PER_QUARTER * 2:
		return false
	for value in values.values():
		if int(value) > UNITS_PER_QUARTER:
			return false
	return true

func total_units() -> int:
	var total := 0
	for value in _allocations.values():
		total += int(value)
	return total

func total_share() -> int:
	var total := 0
	for value in _shares.values():
		total += int(value)
	return total

func jump_units() -> int:
	var total := 0
	for category_id in CATEGORY_IDS:
		if category_id.begins_with("jump_"):
			total += int((_allocations if not _allocations.is_empty() else _shares).get(category_id, 0))
	return total / SHARE_STEP if not _shares.is_empty() else total

func to_dict() -> Dictionary:
	if not _shares.is_empty():
		var data := {"shares": _shares.duplicate(true), "jump_rotations": _jump_rotations.duplicate(true)}
		if not specialist_targets.is_empty(): data.specialist_targets = specialist_targets.duplicate(true)
		if expression_share > 0: data.expression_share = expression_share
		if not lesson_quality.is_empty(): data.lesson_quality = lesson_quality.duplicate(true)
		if not focus_lessons.is_empty(): data.focus_lessons = focus_lessons.duplicate(true)
		if not coach_decision.is_empty(): data.coach_decision = coach_decision.duplicate(true)
		return data
	return {"allocations": _allocations.duplicate(true)}

func requires_load_review() -> bool:
	if _shares.is_empty(): return jump_units() >= 5
	var total := 0
	var largest := 0
	for id in JUMP_LABELS:
		var share := int(_shares.get("jump_"+str(id),0))
		total += share
		largest = maxi(largest,share)
	# Complete distributed lessons are not the same as repeated concentrated
	# impact. Actual fatigue, pain and medical restrictions remain separate.
	return total >= 55 or (total >= 40 and largest >= 20)

static func from_dict(data: Dictionary):
	var plan
	if data.has("shares"):
		plan = create(Dictionary(data.get("shares", {})), Dictionary(data.get("jump_rotations", {}))).plan
	else:
		plan = create(Dictionary(data.get("allocations", {}))).plan
	if plan == null: return null
	var decision = data.get("coach_decision",{})
	if not preload("res://src/domain/coach_training_state.gd").validate_decision(decision).is_empty(): return null
	plan.coach_decision = decision.duplicate(true)
	var expression = data.get("expression_share",0)
	if not (expression is int or expression is float) or not is_finite(float(expression)) or float(expression) != floorf(float(expression)) or float(expression) < 0 or float(expression) > float(plan.shares.get("skating_foundation",0)): return null
	plan.expression_share = int(expression)
	if not data.get("focus_lessons",{}) is Dictionary: return null
	for key in data.get("focus_lessons",{}):
		var value = data.focus_lessons[key]
		var category := "skating_foundation" if key == "steps" else "program_"+str(key).trim_prefix("connections_")
		if not key in ["steps","connections_short","connections_free"] or not (value is int or value is float) or not is_finite(float(value)) or float(value)<0 or float(value)>float(plan.shares.get(category,0)): return null
		plan.focus_lessons[key] = float(value)
	if not data.get("lesson_quality",{}) is Dictionary: return null
	for category in data.get("lesson_quality",{}):
		var value = data.lesson_quality[category]
		if not (category in CATEGORY_IDS or category == "expression") or not (value is int or value is float) or not is_finite(float(value)) or float(value)<0.5 or float(value)>1.15: return null
		plan.lesson_quality[category] = float(value)
	var targets = data.get("specialist_targets",[])
	if not targets is Array: return null
	for target in targets:
		if not target is Dictionary or not target.get("action") is Dictionary: return null
		if preload("res://src/domain/technical_repertoire.gd").action_id(target.action).is_empty(): return null
		for field in ["allocated_attempt_budget","priority"]:
			var value = target.get(field)
			if not (value is int or value is float) or not is_finite(float(value)) or float(value) < 0 or float(value) != floorf(float(value)): return null
		var normalized: Dictionary = target.duplicate(true)
		for field in ["allocated_attempt_budget","priority"]: normalized[field] = int(normalized[field])
		plan.specialist_targets.append(normalized)
	return plan
