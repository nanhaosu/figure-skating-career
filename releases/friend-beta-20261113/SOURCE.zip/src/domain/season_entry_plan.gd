class_name SeasonEntryPlan
extends RefCounted

const STATUS_IDS := ["proposed", "optional", "blocked", "confirmed", "declined"]
const ENTRY_FIELDS := ["status", "requested_levels", "route", "funding_source", "coach_recommendation", "player_override", "available_adjustment_ids", "eligibility_snapshot", "reason_codes"]

var season_id := ""
var proposal_version := 1
var entries: Dictionary = {}

static func create(requested_season_id: String, requested_entries: Dictionary, requested_version: int = 1) -> Dictionary:
	var data := {"season_id": requested_season_id, "proposal_version": requested_version, "entries": requested_entries}
	var errors := validate(data)
	if not errors.is_empty(): return {"plan": null, "errors": errors}
	var plan = load("res://src/domain/season_entry_plan.gd").new()
	plan.season_id = requested_season_id
	plan.proposal_version = requested_version
	plan.entries = requested_entries.duplicate(true)
	return {"plan": plan, "errors": []}

func to_dict() -> Dictionary:
	return {"season_id": season_id, "proposal_version": proposal_version, "entries": entries.duplicate(true)}

static func from_dict(data: Dictionary):
	var result := create(str(data.get("season_id", "")), Dictionary(data.get("entries", {})), int(data.get("proposal_version", 1)))
	return result.plan

static func validate(data: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not data.get("season_id") is String or str(data.get("season_id", "")).is_empty(): errors.append("season_id 必须是非空字符串")
	if not _is_positive_integer(data.get("proposal_version")): errors.append("proposal_version 必须是正整数")
	if not data.get("entries") is Dictionary:
		errors.append("entries 必须是对象")
		return errors
	for event_id in data.entries:
		var path := "entries.%s" % event_id
		var entry = data.entries[event_id]
		if not entry is Dictionary:
			errors.append("%s 必须是对象" % path)
			continue
		for field in ENTRY_FIELDS:
			if not entry.has(field): errors.append("%s.%s 缺失" % [path, field])
		if not STATUS_IDS.has(str(entry.get("status", ""))): errors.append("%s.status 无效" % path)
		var levels = entry.get("requested_levels", [])
		if not levels is Array: errors.append("%s.requested_levels 必须是数组" % path)
		elif _has_duplicates(levels): errors.append("%s.requested_levels 不能重复" % path)
		var override_id := str(entry.get("player_override", ""))
		var adjustments = entry.get("available_adjustment_ids", [])
		if not override_id.is_empty() and (not adjustments is Array or not adjustments.has(override_id)):
			errors.append("%s.player_override 不在可选调整中" % path)
		var snapshot = entry.get("eligibility_snapshot", {})
		if str(entry.get("status", "")) == "confirmed" and snapshot is Dictionary and not Array(snapshot.get("hard_gate_codes", [])).is_empty():
			errors.append("%s 有硬性门槛，不能确认报名" % path)
	return errors

static func _has_duplicates(values: Array) -> bool:
	var seen := {}
	for value in values:
		if seen.has(value): return true
		seen[value] = true
	return false

static func _is_positive_integer(value) -> bool:
	return (value is int or value is float) and is_equal_approx(float(value), floorf(float(value))) and int(value) > 0
