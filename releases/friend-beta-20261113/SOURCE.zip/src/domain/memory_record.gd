class_name MemoryRecord
extends RefCounted

var id := ""
var kind := ""
var actors: Array[String] = []
var cause_ids: Array[String] = []
var strength := 0.0
var credibility := 0.0
var created_clock: Dictionary = {}
var decay_per_quarter := 0.0
var signature := ""

func to_dict() -> Dictionary:
	return {"id": id, "kind": kind, "actors": actors.duplicate(), "cause_ids": cause_ids.duplicate(), "strength": strength, "credibility": credibility, "created_clock": created_clock.duplicate(true), "decay_per_quarter": decay_per_quarter, "signature": signature}
