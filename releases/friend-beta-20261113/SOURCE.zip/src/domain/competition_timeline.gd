class_name CompetitionTimeline
extends RefCounted

const Dates = preload("res://src/simulation/dated_training_window.gd")
const Dose = preload("res://src/simulation/dated_training_dose.gd")

static func empty() -> Dictionary:
	return {"version":1,"mode":"quarterly","date":"","origin_date":"","quarter_progress":0,"applied_intervals":[],"attempt_remainders":{}}

static func validate(data: Dictionary,clock: Dictionary) -> String:
	if not _integer(data.get("version")) or int(data.version) != 1 or not data.get("mode") in ["quarterly","dated"]: return "生涯日期模式无效"
	if not data.get("date") is String or not data.get("origin_date") is String or not _integer(data.get("quarter_progress")) or not data.get("applied_intervals") is Array or not data.get("attempt_remainders") is Dictionary: return "生涯日期游标结构无效"
	if data.mode == "quarterly":
		if data.date != "" or data.origin_date != "" or int(data.quarter_progress) != 0 or not data.applied_intervals.is_empty() or not data.attempt_remainders.is_empty(): return "旧季度模式不能带有已消费日期"
		return ""
	for date in [data.date,data.origin_date]:
		if not Dates.plan(date,date).errors.is_empty(): return "生涯日期游标不是有效日历日期"
	if data.origin_date > data.date: return "生涯日期游标不能早于启用日"
	var start := "%04d-%02d-01" % [int(clock.get("year",0)),(int(clock.get("quarter",0))-1)*3+1]
	if not Dates.plan(start,start).errors.is_empty(): return "日期游标缺少有效季度"
	var elapsed := (_time(data.date)-_time(start))/86400+1
	var quarter := int(clock.quarter)
	var next := "%04d-%02d-01" % [int(clock.year)+(1 if quarter == 4 else 0),1 if quarter == 4 else quarter*3+1]
	var period := (_time(next)-_time(start))/86400
	if elapsed < 0 or elapsed > period or int(data.quarter_progress) != elapsed: return "已消费日期与当前季度进度不一致"
	if data.date == data.origin_date:
		if not data.applied_intervals.is_empty(): return "零日日期游标不能有训练区间回执"
	else:
		if data.applied_intervals.size() != 1 or not data.applied_intervals[0] is Dictionary or data.applied_intervals[0].get("from") != data.origin_date or data.applied_intervals[0].get("through") != data.date: return "已消费日期区间回执不连续"
	if data.attempt_remainders.size() > 128: return "日期训练余数过多"
	for key in data.attempt_remainders:
		if not key is String or not (key.begins_with("single:") or key.begins_with("combo:")): return "日期训练余数动作无效"
	var checked: Dictionary = Dose.slice({"category_volumes":{},"jump_attempts":{},"specialist_attempts":[]},0,90,data.attempt_remainders,{})
	return "日期训练余数无效" if not checked.errors.is_empty() else ""

static func normalize(data: Dictionary) -> Dictionary:
	var result := data.duplicate(true)
	for field in ["version","quarter_progress"]:
		if _integer(result.get(field)): result[field] = int(result[field])
	for fraction in result.get("attempt_remainders",{}).values():
		if fraction is Dictionary:
			for field in ["n","d"]:
				if _integer(fraction.get(field)): fraction[field] = int(fraction[field])
	return result

static func _time(date: String) -> int:
	return int(Time.get_unix_time_from_datetime_string(date+"T00:00:00"))

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floorf(float(value))
