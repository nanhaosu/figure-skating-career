class_name BeijingTrialSeries
extends RefCounted

const ID := "beijing2022_women_trials"
const DATES := ["2021-12-18","2021-12-30","2022-01-01","2022-01-13","2022-01-15"]

static func empty() -> Dictionary:
	# Absence in an older save never means the player declined or participated.
	return {"version":1,"series_id":ID,"season_id":"2021-22","status":"unexamined","player_choice":"unexamined","entrant_ids":[],"lottery_seed":0,"enrollment_receipts":{},"withdrawals":{},"event_receipts":{},"finalization":{}}

static func event_ids() -> Array[String]:
	var ids: Array[String] = []
	for index in 5: ids.append("cn_beijing_trial_%d_2021" % (index+1))
	return ids

static func validate(value: Variant) -> String:
	if not value is Dictionary or value.get("version") != 1 or value.get("series_id") != ID or value.get("season_id") != "2021-22": return "北京选拔系列标识或版本无效"
	if value.get("status") not in ["unexamined","collecting","finalized"] or value.get("player_choice") not in ["unexamined","enrolled","declined","withdrawn"]: return "北京选拔状态或玩家选择无效"
	if not _integer(value.get("lottery_seed")) or float(value.lottery_seed) < 0 or float(value.lottery_seed) > 9007199254740991.0: return "北京选拔固定抽签种子无效"
	if not _ids(value.get("entrant_ids")): return "北京选拔参赛身份无效或重复"
	for key in ["enrollment_receipts","withdrawals","event_receipts","finalization"]:
		if not value.get(key) is Dictionary: return "北京选拔缺少对象字段："+key
	if value.player_choice == "enrolled" and not value.entrant_ids.has("player"): return "已报名玩家不在选拔参赛名单中"
	if value.player_choice in ["unexamined","declined"] and value.entrant_ids.has("player"): return "未报名玩家不能出现在选拔参赛名单中"
	if value.has("medical_pause"):
		var pause = value.medical_pause
		if not pause is Dictionary or pause.size() != 4 or not pause.get("receipt_id") is String or pause.receipt_id.is_empty() or pause.receipt_id.length() > 160 or not event_ids().has(pause.get("event_id")) or not _ids(pause.get("injury_ids")) or pause.injury_ids.is_empty() or not _date(pause.get("selected_on")) or value.player_choice != "enrolled": return "北京选拔医疗暂停回执无效"
		if str(pause.selected_on) > DATES[event_ids().find(pause.event_id)]: return "不能在本场结束后补记医疗暂停选择"
	if value.status == "unexamined":
		if value.player_choice != "unexamined" or not value.entrant_ids.is_empty() or not value.enrollment_receipts.is_empty() or not value.event_receipts.is_empty() or not value.finalization.is_empty() or not value.withdrawals.is_empty(): return "未核验选拔不得预先生成参赛、成绩或派遣"
	for receipt_id in value.enrollment_receipts:
		var receipt = value.enrollment_receipts[receipt_id]
		if not receipt_id is String or receipt_id.is_empty() or not receipt is Dictionary or receipt.get("choice") not in ["enrolled","declined","withdrawn"]: return "北京选拔报名回执无效"
	var allowed := event_ids()
	for athlete_id in value.withdrawals:
		if not value.entrant_ids.has(athlete_id) or not _ids(value.withdrawals[athlete_id]): return "北京选拔退赛身份或场次无效"
		for event_id in value.withdrawals[athlete_id]:
			if not allowed.has(event_id): return "北京选拔退赛场次不属于本系列"
	for event_id in value.event_receipts:
		var receipt = value.event_receipts[event_id]
		if not allowed.has(event_id) or not receipt is Dictionary: return "北京选拔成绩回执不属于本系列"
		var fingerprint = receipt.get("fingerprint")
		if not fingerprint is String or fingerprint.length() != 64 or not fingerprint.is_valid_hex_number(false): return "北京选拔成绩来源摘要无效"
		if not _integer(receipt.get("revision")) or int(receipt.revision) < 1: return "北京选拔成绩更正版本无效"
	if value.status == "finalized":
		if not _ids(value.finalization.get("selected_ids")) or not _date(value.finalization.get("decided_on")): return "北京选拔最终派遣记录无效"
		for id in value.finalization.selected_ids:
			if not value.entrant_ids.has(id): return "北京选拔最终派遣包含未参赛身份"
	elif not value.finalization.is_empty(): return "北京选拔尚未最终结算，不能预先存入最终派遣"
	return ""

static func chronology_error(value: Dictionary,clock: Variant) -> String:
	if not clock is Dictionary or not _integer(clock.get("year")) or not _integer(clock.get("quarter")) or int(clock.year) < 1 or int(clock.year) > 9999 or int(clock.quarter) < 1 or int(clock.quarter) > 4: return "北京选拔缺少有效当前时间"
	if value.get("status") == "unexamined": return ""
	if int(clock.year) < 2021: return "北京选拔不能在2021赛季之前生效"
	var quarter := int(clock.quarter)
	var latest := "%04d-%02d-%02d" % [int(clock.year),quarter*3,[31,30,30,31][quarter-1]]
	if value.has("medical_pause") and str(value.medical_pause.selected_on) > latest: return "不能提前保存未来的医疗暂停选择"
	var allowed := event_ids()
	for id in value.get("event_receipts",{}):
		var index := allowed.find(id)
		if index < 0 or DATES[index] > latest: return "不能保存尚未举行的北京选拔场次成绩"
	if value.get("status") == "finalized" and str(value.get("finalization",{}).get("decided_on","")) > latest: return "不能提前保存未来的北京选拔派遣决定"
	return ""

static func normalize(value: Dictionary) -> Dictionary:
	var result := value.duplicate(true)
	if not validate(result).is_empty(): return result
	result.version = int(result.version)
	result.lottery_seed = int(result.lottery_seed)
	for receipt in result.event_receipts.values(): receipt.revision = int(receipt.revision)
	for receipt in result.enrollment_receipts.values():
		if receipt.get("basis") == "game_readiness_review":
			if _integer(receipt.get("domestic_grade")): receipt.domestic_grade = int(receipt.domestic_grade)
			var evidence: Dictionary = receipt.get("assessment",{}).get("evidence",{})
			if _integer(evidence.get("legal_programs")): evidence.legal_programs = int(evidence.legal_programs)
	return result

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value))

static func _ids(value: Variant) -> bool:
	if not value is Array: return false
	var seen := {}
	for id in value:
		if not id is String or id.is_empty() or seen.has(id): return false
		seen[id] = true
	return true

static func _date(value: Variant) -> bool:
	if not value is String or value.length() != 10 or value[4] != "-" or value[7] != "-": return false
	var parts: Array = Array(value.split("-"))
	if not parts.all(func(part):return str(part).is_valid_int()): return false
	var year := int(parts[0])
	return preload("res://src/domain/athlete_identity.gd").validate_birth_date({"year":year,"month":int(parts[1]),"day":int(parts[2])},year).is_empty()
