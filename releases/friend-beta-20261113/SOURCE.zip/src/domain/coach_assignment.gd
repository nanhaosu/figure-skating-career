class_name CoachAssignment
extends RefCounted

const RelationshipState = preload("res://src/domain/relationship_state.gd")

var club_id: String
var coach_id: String
var relationship: RelationshipState
var known_strengths: Array[String]
var known_concerns: Array[String]
var technical_tendencies: Dictionary

func _init(
	initial_club_id: String = "",
	initial_coach_id: String = "",
	initial_relationship: RelationshipState = null,
	initial_known_strengths: Array = [],
	initial_known_concerns: Array = [],
	initial_technical_tendencies: Dictionary = {},
) -> void:
	club_id = initial_club_id
	coach_id = initial_coach_id
	relationship = initial_relationship if initial_relationship != null else RelationshipState.new()
	known_strengths.assign(initial_known_strengths)
	known_concerns.assign(initial_known_concerns)
	technical_tendencies = initial_technical_tendencies.duplicate(true)

func to_dict() -> Dictionary:
	return {
		"club_id": club_id,
		"coach_id": coach_id,
		"relationship": relationship.to_dict(),
		"known_strengths": known_strengths.duplicate(),
		"known_concerns": known_concerns.duplicate(),
		"technical_tendencies": technical_tendencies.duplicate(true),
	}

func public_dict() -> Dictionary:
	return {
		"club_id": club_id,
		"coach_id": coach_id,
		"relationship": relationship.to_dict(),
		"known_strengths": known_strengths.duplicate(),
		"known_concerns": known_concerns.duplicate(),
	}

static func from_dict(data: Dictionary):
	return CoachAssignment.new(
		str(data.get("club_id", "")),
		str(data.get("coach_id", "")),
		RelationshipState.from_dict(Dictionary(data.get("relationship", {}))),
		Array(data.get("known_strengths", [])),
		Array(data.get("known_concerns", [])),
		Dictionary(data.get("technical_tendencies", {})),
	)
