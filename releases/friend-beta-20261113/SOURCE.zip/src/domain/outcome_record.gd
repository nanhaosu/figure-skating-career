class_name OutcomeRecord
extends RefCounted

var category: String
var target: String
var delta: float
var cause_codes: Array[String]
var summary_key: String

func _init(
	initial_category: String,
	initial_target: String,
	initial_delta: float,
	initial_cause_codes: Array[String],
	initial_summary_key: String,
) -> void:
	category = initial_category
	target = initial_target
	delta = initial_delta
	cause_codes = initial_cause_codes.duplicate()
	summary_key = initial_summary_key

func to_dict() -> Dictionary:
	return {
		"category": category,
		"target": target,
		"delta": delta,
		"cause_codes": cause_codes.duplicate(),
		"summary_key": summary_key,
	}

static func list_to_dict(outcomes: Array) -> Array[Dictionary]:
	var serialized: Array[Dictionary] = []
	for outcome in outcomes:
		serialized.append(outcome.to_dict())
	return serialized
