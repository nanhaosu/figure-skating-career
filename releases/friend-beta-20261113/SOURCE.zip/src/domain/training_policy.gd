class_name TrainingPolicy
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")

const POLICY_IDS := ["balanced_foundation", "rotation_push", "technique_rebuild", "competition_stability", "recovery"]
const RISK_ATTITUDES := ["cautious", "normal", "aggressive"]

var policy_id := "balanced_foundation"
var focus_jumps: Array[String] = []
var target_rotations: Dictionary = {}
var risk_attitude := "normal"

static func create(requested_policy_id: String, requested_focus_jumps: Array, requested_targets: Dictionary, requested_risk: String) -> Dictionary:
	var errors: Array[String] = []
	if not POLICY_IDS.has(requested_policy_id): errors.append("未知训练方针：%s" % requested_policy_id)
	if not RISK_ATTITUDES.has(requested_risk): errors.append("未知风险态度：%s" % requested_risk)
	if requested_focus_jumps.size() > 2: errors.append("重点跳跃最多选择两个")
	var normalized_focus: Array[String] = []
	for raw_jump_id in requested_focus_jumps:
		var jump_id := str(raw_jump_id)
		if not JumpCatalog.JUMP_IDS.has(jump_id):
			errors.append("未知重点跳跃：%s" % jump_id)
		elif normalized_focus.has(jump_id):
			errors.append("重点跳跃不能重复：%s" % jump_id)
		else:
			normalized_focus.append(jump_id)
		var rotations = requested_targets.get(jump_id)
		if typeof(rotations) != TYPE_INT or int(rotations) < 1 or int(rotations) > 4:
			errors.append("重点跳跃%s必须设置1至4周目标" % jump_id)
	if not errors.is_empty(): return {"policy": null, "errors": errors}
	var policy = load("res://src/domain/training_policy.gd").new()
	policy.policy_id = requested_policy_id
	policy.focus_jumps = normalized_focus
	policy.target_rotations = requested_targets.duplicate(true)
	policy.risk_attitude = requested_risk
	return {"policy": policy, "errors": []}

func to_dict() -> Dictionary:
	return {"policy_id": policy_id, "focus_jumps": focus_jumps.duplicate(), "target_rotations": target_rotations.duplicate(true), "risk_attitude": risk_attitude}

static func from_dict(data: Dictionary):
	return create(str(data.get("policy_id", "")), Array(data.get("focus_jumps", [])), Dictionary(data.get("target_rotations", {})), str(data.get("risk_attitude", ""))).policy
