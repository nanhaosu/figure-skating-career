class_name JumpFoundation
extends RefCounted

const DEFAULTS := {
	"takeoff_power": 25.0, "speed_conversion": 25.0, "timing": 25.0,
	"air_axis": 30.0, "air_tightness": 25.0, "spatial_awareness": 25.0,
	"rotation_completion": 20.0, "landing_control": 25.0, "landing_flow": 20.0,
}

var takeoff_power := 25.0
var speed_conversion := 25.0
var timing := 25.0
var air_axis := 30.0
var air_tightness := 25.0
var spatial_awareness := 25.0
var rotation_completion := 20.0
var landing_control := 25.0
var landing_flow := 20.0

static func create():
	return load("res://src/domain/jump_foundation.gd").new()

func to_dict() -> Dictionary:
	var result := {}
	for key in DEFAULTS: result[key] = get(key)
	return result

static func from_dict(data: Dictionary):
	var foundation = create()
	for key in DEFAULTS:
		foundation.set(key, clampf(float(data.get(key, DEFAULTS[key])), 0.0, 100.0))
	return foundation
