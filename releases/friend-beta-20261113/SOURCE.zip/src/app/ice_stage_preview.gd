extends Window

const CLIP_SECONDS := 30.0
const ICE = preload("res://src/app/competition_ice_view.gd")

var _ice: CompetitionIceView
var _scrub: HSlider
var _play: Button
var _audio: AudioStreamPlayer
var _duration := 1.0
var _start := 0.0
var _length := 0.0
var _elapsed := 0.0

func _ready() -> void:
	title = "冰场舞台 · 30 秒回放"
	transient = true
	exclusive = true
	close_requested.connect(hide)
	var card := PanelContainer.new()
	card.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	card.add_theme_stylebox_override("panel",preload("res://src/app/theme_factory.gd").card_style())
	add_child(card)
	var body := VBoxContainer.new()
	card.add_child(body)
	_ice = ICE.new()
	_ice.stage_preview = true
	_ice.custom_minimum_size.y = 160
	_ice.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(_ice)
	var caption := Label.new()
	caption.text = "取自比赛档案的动作与轨迹 · 原创合成配乐《冰上小品》"
	caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.add_child(caption)
	_scrub = HSlider.new()
	_scrub.step = 0.05
	_scrub.value_changed.connect(_seek)
	body.add_child(_scrub)
	_play = Button.new()
	_play.text = "播放"
	_play.pressed.connect(_toggle)
	body.add_child(_play)
	var close_button := Button.new()
	close_button.text = "返回比赛档案"
	close_button.pressed.connect(hide)
	body.add_child(close_button)
	_audio = AudioStreamPlayer.new()
	_audio.stream = load("res://assets/audio/ice_stage_study.wav")
	add_child(_audio)
	visibility_changed.connect(func():
		if not visible: _pause())
	set_process(false)

func present(record: Dictionary) -> void:
	var route: Dictionary = record.get("route_execution",{})
	if route.get("points",[]).is_empty(): return
	_pause()
	_duration = maxf(1.0,float(route.get("duration_seconds",160.0)))
	_length = minf(CLIP_SECONDS,_duration)
	_start = 0.0
	for phase in route.get("action_phases",[]):
		if phase.get("kind") == "airborne":
			_start = clampf(float(phase.start)*_duration-5.0,0.0,_duration-_length)
			break
	_ice.load_timeline(route,record.get("performance",{}).get("elements",[]))
	_scrub.max_value = _length
	_seek(0.0)
	var parent_size := Vector2i(get_parent().get_viewport().get_visible_rect().size)
	show()
	size = Vector2i(mini(880,parent_size.x-48),mini(550,parent_size.y-64))
	position = (parent_size-size)/2

func _toggle() -> void:
	if is_processing():
		_pause()
		return
	if _elapsed >= _length: _seek(0.0)
	_play.text = "暂停"
	if _audio.stream != null: _audio.play(_elapsed)
	set_process(true)

func _pause() -> void:
	set_process(false)
	_audio.stop()
	_play.text = "播放"

func _seek(seconds: float) -> void:
	_elapsed = clampf(seconds,0.0,_length)
	_refresh()
	if is_processing() and _audio.stream != null: _audio.seek(_elapsed)

func _refresh() -> void:
	_scrub.set_value_no_signal(_elapsed)
	_ice.set_progress((_start+_elapsed)/_duration)

func _process(delta: float) -> void:
	_elapsed = minf(_elapsed+delta,_length)
	_refresh()
	if _elapsed >= _length: _pause()
