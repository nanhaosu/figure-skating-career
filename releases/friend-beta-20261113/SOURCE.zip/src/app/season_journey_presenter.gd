class_name SeasonJourneyPresenter
extends RefCounted

const STATUS_LABELS := {
	"cancelled":"已取消",
	"proposed":"待确认",
	"optional":"可选参赛",
	"blocked":"暂不可报名",
	"confirmed":"已报名",
	"declined":"本次不参加",
	"in_progress":"比赛进行中",
	"completed":"已完赛",
}

static func build(career, calendar: Dictionary, entry_plan: Dictionary) -> Dictionary:
	var policy := preload("res://src/presentation/annual_selection_policy_presenter.gd").build(career,calendar)
	var rows: Array[Dictionary] = []
	var rows_by_id := {}
	var entries = entry_plan.get("entries", {})
	for source in calendar.get("events", []):
		if not source is Dictionary: continue
		var event: Dictionary = source
		var event_id := str(event.get("event_id", ""))
		var entry := Dictionary(entries.get(event_id, {})) if entries is Dictionary else {}
		var status := _resolved_status(career, event_id, str(entry.get("status", "blocked")))
		if source.get("status")=="cancelled":status="cancelled"
		var row := event.duplicate(true)
		row["policy_roles"] = policy.event_roles.get(event_id,{})
		row["policy_standard"] = policy.target_standards.get(event_id,{})
		row["status"] = status
		row["status_label"] = str(STATUS_LABELS.get(status, "未知状态"))
		row["route"] = str(entry.get("route", event.get("entry_route", "")))
		row["coach_recommendation"] = str(entry.get("coach_recommendation", "等待教练评估"))
		row["eligibility_snapshot"] = Dictionary(entry.get("eligibility_snapshot", {})).duplicate(true)
		row["available_adjustment_ids"] = Array(entry.get("available_adjustment_ids", [])).duplicate()
		row["is_due"] = _event_is_due(career, event)
		var action := _action_for(row)
		row["action_kind"] = action.kind
		row["action_label"] = action.label
		row["has_entry_choice"] = true
		if career != null and str(event.get("scope","")) == "international" and not status in ["completed","declined","in_progress","confirmed","cancelled"]:
			var entry_service = preload("res://src/simulation/entry_application_service.gd")
			row.has_entry_choice = entry_service.has_entry_choice(entry_service.options(career,event,{"rules":{"junior_min_age":13,"junior_max_age":18}}))
		if status=="cancelled":
			row.has_entry_choice=false
			row.action_kind="none"
			row.action_label="已取消，无需确认"
		rows.append(row)
		rows_by_id[event_id] = row
	var candidates: Array[Dictionary] = []
	for row in rows:
		if str(row.status) in ["completed", "declined","cancelled"]: continue
		if not bool(row.has_entry_choice): continue
		candidates.append(row)
	var next_id := str(candidates[0].event_id) if not candidates.is_empty() else ""
	var chain: Array[Dictionary] = []
	if not candidates.is_empty(): chain.append(candidates[0])
	# The first chip must match the progression service's chronological stop.
	# Remaining chips favour actionable entries, while reserving a place for
	# the next domestic fallback so blocked JGP applications cannot hide it.
	for row in candidates:
		if chain.has(row) or (str(row.status) == "blocked" and str(row.get("scope", "")) == "international"): continue
		chain.append(row)
		if chain.size() >= 4: break
	var domestic := candidates.filter(func(row): return str(row.get("scope", "")) == "domestic")
	if not domestic.is_empty() and not chain.any(func(row): return str(row.get("scope", "")) == "domestic"):
		if chain.size() >= 4: chain.pop_back()
		chain.append(domestic[0])
	for row in candidates:
		if chain.size() >= 4: break
		if not chain.has(row): chain.append(row)
	chain.sort_custom(func(a: Dictionary, b: Dictionary): return int(a.get("sequence", 0)) < int(b.get("sequence", 0)))
	return {
		"annual_policy":policy,
		"season_id":str(calendar.get("season_id", "")),
		"events":rows,
		"events_by_id":rows_by_id,
		"current_chain":chain,
		"next_event_id":next_id,
		"coach_recommendation":str(chain[0].coach_recommendation) if not chain.is_empty() else "本赛季路线已处理完毕",
	}

static func _resolved_status(career, event_id: String, planned: String) -> String:
	if career != null:
		var current = career.competition_state
		if current is Dictionary and not current.is_empty() and str(current.get("event_id", "")) == event_id:
			return "in_progress"
		for archive in career.competition_archive:
			# A simulated event without the player is still a committed, past event.
			# It must open as a read-only archive instead of offering the impossible
			# action of entering the same dated competition after results exist.
			if archive is Dictionary and str(archive.get("event_id", "")) == event_id and str(archive.get("status", "complete")) == "complete":
				return "completed"
	return planned if STATUS_LABELS.has(planned) else "blocked"

static func _action_for(row: Dictionary) -> Dictionary:
	match str(row.status):
		"completed": return {"kind":"view_archive", "label":"查看比赛档案"}
		"in_progress": return {"kind":"resume", "label":"继续当前比赛"}
		"confirmed":
			var eligible := bool(Dictionary(row.get("eligibility_snapshot", {})).get("eligible", false))
			if bool(row.is_due) and eligible: return {"kind":"compete", "label":"前往比赛"}
			return {"kind":"prepare", "label":"准备本场比赛"}
		"proposed", "optional": return {"kind":"decide", "label":"决定是否报名"}
		"declined": return {"kind":"none", "label":"本次不参加"}
		_: return {"kind":"blocked", "label":"暂不可报名"}

static func _event_is_due(career, event: Dictionary) -> bool:
	if career == null: return false
	if career.competition_timeline.get("mode") == "dated":
		var today := Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_datetime_string(str(career.competition_timeline.date)+"T00:00:00"))+86400)
		return today >= str(event.get("start_date","")) and today <= str(event.get("end_date",event.get("start_date","")))
	var parts := str(event.get("start_date", "")).split("-")
	if parts.size() < 2: return false
	var quarter := int((int(parts[1]) - 1) / 3) + 1
	return int(parts[0]) == int(career.clock.year) and quarter == int(career.clock.quarter)
