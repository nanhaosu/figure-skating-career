class_name CareerReferencePanel
extends MarginContainer

signal archive_requested(event_id: String)

var _milestone_links: VBoxContainer

func _ready() -> void:
	_milestone_links = VBoxContainer.new()
	_milestone_links.name = "MilestoneLinks"
	get_node("Content/RecordsScroll/RecordsBody").add_child(_milestone_links)
	get_node("Content/RecordsScroll/RecordsBody").move_child(_milestone_links,0)

func present(career, section_id: String) -> void:
	for child in _milestone_links.get_children(): child.free()
	if section_id == "relationships":
		%SectionTitle.text = "关系与支持"
		var lines: Array[String] = []
		var profile: Dictionary = preload("res://src/content/club_coach_repository.gd").new().public_coach_summary(career.coach_assignment.coach_id)
		if not profile.is_empty():
			lines.append("现任教练：%s\n%s" % [str(profile.name),str(profile.get("style",""))])
			if not career.coach_assignment.known_strengths.is_empty(): lines.append("已知长处：%s" % "、".join(career.coach_assignment.known_strengths))
			if not career.coach_assignment.known_concerns.is_empty(): lines.append("需要留意：%s" % "、".join(career.coach_assignment.known_concerns))
		for relationship_id in career.relationships:
			var relation = career.relationships[relationship_id]
			var trust := float(relation.professional_trust) if relation is RelationshipState else float(relation.get("professional_trust", relation.get("trust", 0.0)))
			lines.append("%s · 信任 %.0f" % [str({"coach":"教练","guardian":"监护人"}.get(str(relationship_id),str(relationship_id))), trust])
		%FactsText.text = "尚未建立稳定的支持关系。" if lines.is_empty() else "\n".join(lines)
		return
	%SectionTitle.text = "生涯履历"
	var facts: Array[String] = []
	var events := {}
	var milestones: Dictionary = career.experience_state.get("milestones",{})
	var labels := {"first_jgp_start":"JGP首次出场","first_jgp_complete":"JGP两套节目完成","first_formal_3a":"正式比赛足周3A"}
	for key in milestones:
		var milestone: Dictionary = milestones[key]
		var label := str(labels.get(key,"比赛经历"))
		if milestone.get("certainty") != "confirmed_first": label = "档案已确认 · "+label.replace("首次","")
		facts.append("• %s · %s · %s" % [str(milestone.event_date),label,str(milestone.event_name)])
		var id := str(milestone.event_id)
		if events.has(id): continue
		events[id] = true
		var button := Button.new()
		button.name = "MilestoneArchive_%d" % (_milestone_links.get_child_count())
		button.text = "回看 · "+str(milestone.event_name)
		button.pressed.connect(func(): archive_requested.emit(id))
		_milestone_links.add_child(button)
	var portfolio := Button.new()
	portfolio.name = "ProgrammePortfolioButton"
	portfolio.text = "查看代表作档案"
	_milestone_links.add_child(portfolio)
	_milestone_links.move_child(portfolio,0)
	portfolio.pressed.connect(func(): _show_programme_portfolio(career,portfolio))
	for item in career.history:
		if item.get("category") == "dated_training" and item.get("summary_key") == "dated_training_day":
			facts.append("• %s · 按日训练" % str(item.get("date","日期未记录")))
		else:
			facts.append("• %s" % str(item.get("summary_key", item.get("category", "生涯记录"))))
	%FactsText.text = "第一条生涯记录仍在等待你写下。" if facts.is_empty() else "\n".join(facts)

func _show_programme_portfolio(career, opener: Button) -> void:
	opener.disabled = true
	var rows := preload("res://src/presentation/programme_portfolio_presenter.gd").build(career.competition_archive)
	var heading := Label.new()
	heading.text = "代表作档案 · 每个版本的最高单段分"
	_milestone_links.add_child(heading)
	_milestone_links.move_child(heading,1)
	if rows.is_empty():
		heading.text = "代表作档案 · 暂无带节目版本的正式比赛成绩"
	for index in rows.size():
		var row: Dictionary = rows[index]
		var button := Button.new()
		button.name = "ProgrammeArchive_%d" % index
		button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var segment := "短节目" if row.segment == "short" else "自由滑"
		var title: String = row.title if not row.title.is_empty() else "未命名节目"
		button.text = "%s · %s · 第%d版 · %.2f分\n%s · %s" % [segment,title,row.revision,row.score,row.season_id,row.event_name]
		button.pressed.connect(func(): archive_requested.emit(row.event_id))
		_milestone_links.add_child(button)
		_milestone_links.move_child(button,index+2)
