class_name CompetitionIceView
extends Control

const SUCCESS_COLOR := Color("42c98b")
const REVIEW_COLOR := Color("f0bd4f")
const ERROR_COLOR := Color("ef6672")
const ROUTE_COLOR := Color(0.12, 0.55, 0.72, 0.92)
const FUTURE_ROUTE_COLOR := Color(0.22, 0.49, 0.60, 0.10)

var visible_route_point_count := 0
var visible_action_count := 0
var skater_position := Vector2.ZERO
var combination_links: Array[Dictionary] = []
var action_node_colors: Dictionary = {}
var current_action_state: Dictionary = {}
var stage_preview := false

var _points: Array = []
var _anchors: Array = []
var _element_status: Dictionary = {}
var _action_phases: Array = []
var _progress := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(false)
	queue_redraw()

func load_timeline(route_execution: Dictionary, element_records: Array) -> void:
	_points = Array(route_execution.get("points", [])).duplicate(true)
	_anchors = Array(route_execution.get("action_anchors", [])).duplicate(true)
	_action_phases = Array(route_execution.get("action_phases", [])).duplicate(true)
	# Older committed records predate held route points. Adapt a private display copy only.
	if not route_execution.has("duration_seconds") and not _action_phases.is_empty():
		var points: Array[Dictionary] = []; points.assign(_points)
		var phases: Array[Dictionary] = []; phases.assign(_action_phases)
		_points = preload("res://src/simulation/competition_route_executor.gd")._hold_points(points,phases,_anchors)
	_element_status.clear()
	action_node_colors.clear()
	for record in element_records:
		var element_id := str(record.get("element_id", ""))
		var status := str(record.get("status", "success"))
		_element_status[element_id] = status
		action_node_colors[element_id] = _status_color(status)
	set_progress(0.0)

func set_progress(value: float) -> void:
	_progress = clampf(value, 0.0, 1.0)
	current_action_state = {}
	for raw_phase in _action_phases:
		var phase: Dictionary = Dictionary(raw_phase)
		if _progress >= float(phase.get("start", 0.0)) and _progress <= float(phase.get("end", 0.0)):
			current_action_state = phase
	visible_route_point_count = 0
	for point in _points:
		if float(point.get("progress", 0.0)) <= _progress + 0.0001:
			visible_route_point_count += 1
	visible_action_count = 0
	combination_links.clear()
	var previous_visible_anchor: Dictionary = {}
	for raw_anchor in _anchors:
		var anchor: Dictionary = Dictionary(raw_anchor)
		if float(anchor.get("progress", 0.0)) > _progress + 0.0001:
			continue
		visible_action_count += 1
		if (
			not previous_visible_anchor.is_empty()
			and str(previous_visible_anchor.get("element_id", "")) == str(anchor.get("element_id", ""))
		):
			combination_links.append({"from": previous_visible_anchor, "to": anchor})
		previous_visible_anchor = anchor
	skater_position = _position_at_progress(_progress)
	queue_redraw()

func update_element_status(element_id: String, status: String) -> void:
	_element_status[element_id] = status
	action_node_colors[element_id] = _status_color(status)
	queue_redraw()

func _draw() -> void:
	if stage_preview: _draw_stage()
	_draw_empty_ice_marks()
	if _points.is_empty():
		return
	var full_line := PackedVector2Array()
	for point in _points:
		full_line.append(_canvas_point(Vector2(float(point.get("x", 0.5)), float(point.get("y", 0.5)))))
	if full_line.size() >= 2:
		draw_polyline(full_line, FUTURE_ROUTE_COLOR, 1.7, true)
	var travelled := PackedVector2Array()
	for point in _points:
		if float(point.get("progress", 0.0)) <= _progress + 0.0001 and float(point.get("progress", 0.0)) >= _progress - 0.22:
			travelled.append(_canvas_point(Vector2(float(point.get("x", 0.5)), float(point.get("y", 0.5)))))
	travelled.append(_canvas_point(skater_position))
	if travelled.size() >= 2:
		draw_polyline(travelled, ROUTE_COLOR, 2.8, true)
	for link in combination_links:
		draw_line(_anchor_canvas_point(link.from), _anchor_canvas_point(link.to), Color(0.08, 0.25, 0.34, 0.8), 3.0, true)
	for raw_anchor in _anchors:
		var anchor: Dictionary = Dictionary(raw_anchor)
		if float(anchor.get("progress", 0.0)) > _progress + 0.0001:
			continue
		var element_id := str(anchor.get("element_id", ""))
		var center := _anchor_canvas_point(anchor)
		var color: Color = action_node_colors.get(element_id, SUCCESS_COLOR)
		draw_circle(center, 5.0, Color(0.02, 0.10, 0.14, 0.55))
		draw_circle(center, 3.0, color)
	var skater := _canvas_point(skater_position)
	_draw_action_phase(skater)
	var heading := (_canvas_point(_position_at_progress(minf(1.0,_progress+0.006))) - _canvas_point(_position_at_progress(maxf(0.0,_progress-0.006)))).normalized()
	if heading.length_squared() < 0.01: heading = Vector2.UP
	var side := Vector2(-heading.y, heading.x)
	draw_circle(skater+Vector2(2,3), 9.0, Color(0.02,0.12,0.18,0.16))
	var costume := Color("9d3458") if stage_preview else Color("214e66")
	draw_line(skater-side*9,skater+side*9,costume,3.0,true)
	draw_line(skater-heading*6,skater+heading*5,costume,6.0,true)
	draw_circle(skater+heading*8,3.8,Color("f7fcff"))
	draw_line(skater-heading*6-side*3,skater-heading*10-side*5,Color("214e66"),2.0,true)
	draw_line(skater-heading*6+side*3,skater-heading*10+side*5,Color("214e66"),2.0,true)

func _draw_stage() -> void:
	draw_rect(Rect2(Vector2.ZERO,size),Color("101f38"))
	var rink := Rect2(Vector2(10,10),size-Vector2(20,20))
	draw_rect(rink,Color("d8edf5"))
	for index in 18:
		var light := float(index)/17.0
		draw_rect(Rect2(Vector2(10,10+rink.size.y*light),Vector2(rink.size.x,rink.size.y/18.0)),Color(0.35,0.65,0.82,0.16*(1.0-light)))
	draw_rect(rink,Color("6f9ab1"),false,3.0)
	var spot := _canvas_point(skater_position)
	for radius in [43.0,32.0,21.0]:
		draw_circle(spot,radius,Color(1.0,1.0,0.95,0.11))

func _draw_action_phase(skater: Vector2) -> void:
	if current_action_state.is_empty(): return
	match str(current_action_state.get("kind", "")):
		"airborne":
			draw_arc(skater + Vector2(0, 5), 18.0, PI, TAU, 18, Color(0.16, 0.54, 0.78, 0.9), 2.0, true)
		"spin_hold":
			for radius in [12.0, 20.0, 28.0]: draw_arc(skater, radius, 0.0, TAU * 0.82, 32, Color(0.16, 0.55, 0.76, 0.38), 2.0, true)
		"step_run":
			for offset in [-24.0, -12.0, 12.0, 24.0]: draw_line(skater + Vector2(offset, -8), skater + Vector2(offset + 7, 0), Color(0.12, 0.42, 0.64, 0.7), 1.5, true)
		"fall_recovery", "recovery":
			draw_circle(skater, 18.0, Color(0.86, 0.18, 0.22, 0.28))
			draw_line(skater - Vector2(10, 10), skater + Vector2(10, 10), ERROR_COLOR, 3.0, true)
			draw_line(skater + Vector2(10, -10), skater - Vector2(10, 10), ERROR_COLOR, 3.0, true)

func _draw_empty_ice_marks() -> void:
	var center := size * 0.5
	draw_circle(center, minf(size.x, size.y) * 0.12, Color(0.25, 0.55, 0.64, 0.12), false, 2.0, true)
	draw_line(Vector2(20.0, center.y), Vector2(size.x - 20.0, center.y), Color(0.25, 0.55, 0.64, 0.08), 2.0)

func _position_at_progress(value: float) -> Vector2:
	if _points.is_empty(): return Vector2(0.5, 0.5)
	var first: Dictionary = Dictionary(_points.front())
	if value <= float(first.get("progress", 0.0)): return Vector2(float(first.get("x", 0.5)), float(first.get("y", 0.5)))
	for index in range(1, _points.size()):
		var previous: Dictionary = Dictionary(_points[index - 1])
		var current: Dictionary = Dictionary(_points[index])
		var current_progress := float(current.get("progress", 1.0))
		if value <= current_progress:
			var previous_progress := float(previous.get("progress", 0.0))
			var weight := inverse_lerp(previous_progress, current_progress, value)
			return Vector2(float(previous.get("x", 0.5)), float(previous.get("y", 0.5))).lerp(
				Vector2(float(current.get("x", 0.5)), float(current.get("y", 0.5))), weight
			)
	var last: Dictionary = Dictionary(_points.back())
	return Vector2(float(last.get("x", 0.5)), float(last.get("y", 0.5)))

func _anchor_canvas_point(anchor: Dictionary) -> Vector2:
	if anchor.has("x") and anchor.has("y"): return _canvas_point(Vector2(anchor.x,anchor.y))
	var normalized := _position_at_progress(float(anchor.get("progress", 0.0)))
	var part_index := int(anchor.get("part_index", 0))
	if part_index > 0:
		normalized += Vector2(0.012 * float(part_index), -0.012 * float(part_index))
	return _canvas_point(normalized)

func _canvas_point(normalized: Vector2) -> Vector2:
	var padding := Vector2(28.0, 24.0)
	return padding + normalized * (size - padding * 2.0)

func _status_color(status: String) -> Color:
	match status:
		"review": return REVIEW_COLOR
		"error": return ERROR_COLOR
		_: return SUCCESS_COLOR
