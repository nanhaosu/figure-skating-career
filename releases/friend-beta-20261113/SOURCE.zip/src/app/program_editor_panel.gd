class_name ProgramEditorPanel
extends MarginContainer

const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const ProgramValidatorCodes = preload("res://src/simulation/program_validator.gd")
const ProgramDraftService = preload("res://src/simulation/program_draft_service.gd")
const MusicCatalogRepository = preload("res://src/content/music_catalog_repository.gd")
const ProgramPerformanceSimulator = preload("res://src/simulation/program_performance_simulator.gd")
const FormalScoringRepository = preload("res://src/content/formal_scoring_repository.gd")
const ProgramLoadEstimator = preload("res://src/simulation/program_load_estimator.gd")
const BetweenSegmentAdjuster = preload("res://src/simulation/between_segment_adjuster.gd")
const SeasonBundleRepository = preload("res://src/content/season_bundle_repository.gd")
const HistoricalRuleRepository = preload("res://src/content/historical_rule_repository.gd")
const JumpConnectionRules = preload("res://src/simulation/jump_connection_rules.gd")
const ProgramCandidatePresenter = preload("res://src/presentation/program_candidate_presenter.gd")

signal program_saved(segment: String, program_data: Dictionary)
signal closed()

var career
var segment := "short"
var rules: Dictionary = {}
var program
var original_between_program
var load_preview: Dictionary = {}
var _load_context: Dictionary = {}
var _load_athlete
var _anchor_edited := false
var _entry_snapshot: Dictionary = {}

@onready var title_label: Label = %TitleLabel
@onready var music_title_input: LineEdit = %MusicTitleInput
@onready var music_preset_choice: OptionButton = %MusicPresetChoice
@onready var difficulty_input: OptionButton = %DifficultyInput
@onready var status_label: Label = %StatusLabel
@onready var element_summary: Label = %ElementSummary
@onready var base_preview_label: Label = %BasePreviewLabel
@onready var advanced_toggle: CheckButton = %AdvancedToggle
@onready var advanced_content: VBoxContainer = %AdvancedContent
@onready var action_list: ItemList = %ActionList
@onready var save_button: Button = %SaveButton
@onready var lock_button: Button = %LockButton
@onready var close_button: Button = %CloseButton
@onready var candidate_list: ItemList = %CandidateList
@onready var candidate_reason_label: Label = %CandidateReasonLabel

func _ready() -> void:
	%ActionGuideButton.pressed.connect(func(): %ActionGuideDialog.popup_centered(Vector2i(620,400)))
	%TargetSeasonChoice.item_selected.connect(_select_target_season)
	for entry in [{"id":"simple", "label":"简洁"}, {"id":"standard", "label":"标准"}, {"id":"rich", "label":"丰富"}, {"id":"extreme", "label":"极密"}]:
		difficulty_input.add_item(entry.label)
		difficulty_input.set_item_metadata(difficulty_input.item_count - 1, entry.id)
	save_button.pressed.connect(_save)
	lock_button.pressed.connect(_lock_for_competition)
	close_button.pressed.connect(_request_close)
	%UnsavedReturnDialog.confirmed.connect(keep_draft)
	%UnsavedReturnDialog.custom_action.connect(func(action: StringName):
		if action == &"discard": discard_changes())
	%UnsavedReturnDialog.add_button("放弃修改", false, "discard")
	%JumpGroupButton.pressed.connect(_select_action_group.bind("jumps"))
	%SpinStepGroupButton.pressed.connect(_select_action_group.bind("spins_steps"))
	%AdvancedDrawerButton.pressed.connect(_toggle_advanced_drawer)
	advanced_toggle.visible = false
	advanced_content.visible = true
	%AdvancedButtons.visible = false
	%JumpChoices.visible = false
	%SpinChoices.visible = false
	%DetailsLabel.visible = false
	%DetailInputs.visible = false
	music_preset_choice.add_item("自定义曲目")
	music_preset_choice.set_item_metadata(0, "")
	var music_catalog := MusicCatalogRepository.load_catalog()
	for work in music_catalog.get("works", []):
		music_preset_choice.add_item(str(work.title))
		music_preset_choice.set_item_metadata(music_preset_choice.item_count - 1, str(work.id))
	music_preset_choice.item_selected.connect(_on_music_preset_selected)
	music_title_input.text_changed.connect(func(_text):
		_mark_local_revision_draft()
		_render()
	)
	%MoveUpButton.pressed.connect(func(): _move_selection(-1))
	%MoveDownButton.pressed.connect(func(): _move_selection(1))
	%RefreshDraftButton.pressed.connect(refresh_coach_draft)
	%CoachRepairButton.pressed.connect(refresh_coach_draft)
	%ApplyJumpButton.pressed.connect(_apply_selected_jump)
	%AddJumpButton.pressed.connect(_add_selected_jump)
	%RemoveActionButton.pressed.connect(_remove_selected_action)
	%ApplySpinButton.pressed.connect(_apply_selected_spin)
	%ApplyDetailsButton.pressed.connect(_apply_selected_details)
	action_list.item_selected.connect(_select_action)
	candidate_list.item_selected.connect(_select_candidate)
	%Connection1Choice.item_selected.connect(func(_index): _populate_second_connection())
	%CandidateApplyButton.pressed.connect(_apply_selected_candidate)
	%SlotMoveUpButton.pressed.connect(func(): _move_selection(-1))
	%SlotMoveDownButton.pressed.connect(func(): _move_selection(1))
	%SlotRemoveButton.pressed.connect(_remove_selected_action)
	%SlotCoachButton.pressed.connect(refresh_coach_draft)
	%AnchorXInput.value_changed.connect(func(_value): _anchor_edited = true)
	%AnchorYInput.value_changed.connect(func(_value): _anchor_edited = true)
	difficulty_input.item_selected.connect(func(index):
		if program != null:
			program.route_complexity = str(difficulty_input.get_item_metadata(index))
			_mark_local_revision_draft()
			_render()
	)

func present(active_career, requested_segment: String, target_rules: Dictionary, proposal: Dictionary) -> void:
	career = active_career
	segment = requested_segment
	rules = target_rules.duplicate(true)
	var saved: Dictionary = Dictionary(career.active_programs.get(segment, {}))
	original_between_program = proposal.get("original_between_program")
	var replace_saved := bool(proposal.get("replace_saved",false))
	_load_context = Dictionary(proposal.get("load_context", {"condition":career.condition_state})).duplicate(true)
	_load_athlete = proposal.get("load_athlete", career.athlete)
	_anchor_edited = false
	var draft = proposal.get("program")
	program = SkatingProgram.from_dict(draft.to_dict()) if original_between_program != null or replace_saved else (SkatingProgram.from_dict(saved) if not saved.is_empty() else SkatingProgram.from_dict(draft.to_dict()) if draft != null else null)
	if program == null:
		status_label.text = "节目草案无法生成"
		return
	_entry_snapshot = program.to_dict().duplicate(true)
	title_label.text = "短节目筹备" if segment == "short" else "自由滑筹备"
	save_button.text = "确认编排并进入自由滑" if original_between_program != null else "保存节目草案"
	lock_button.visible = original_between_program == null
	close_button.text = "取消并返回成绩" if original_between_program != null else "返回训练"
	advanced_toggle.button_pressed = original_between_program != null
	music_preset_choice.select(0)
	music_title_input.set_block_signals(true)
	music_title_input.text = str(program.music.get("title", ""))
	music_title_input.set_block_signals(false)
	for index in difficulty_input.item_count:
		if str(difficulty_input.get_item_metadata(index)) == program.route_complexity:
			difficulty_input.select(index)
			break
	_populate_jump_choices()
	_configure_target_season()
	_populate_spin_choices()
	_render()
	_select_action_group("jumps")

func set_return_screen(screen_id: String) -> void:
	if original_between_program != null:
		return
	close_button.text = {
		"career_home": "返回生涯主页",
		"training": "返回训练",
		"season": "返回赛季",
		"records": "返回履历",
		"relationships": "返回关系",
	}.get(screen_id, "返回上一页")

func _select_action_group(group_id: String) -> void:
	%JumpGroupButton.button_pressed = group_id == "jumps"
	%SpinStepGroupButton.button_pressed = group_id == "spins_steps"
	if program == null: return
	for index in program.elements.size():
		var is_jump: bool = program.elements[index].kind == "jump"
		if (group_id == "jumps" and is_jump) or (group_id == "spins_steps" and not is_jump):
			action_list.select(index)
			_select_action(index)
			return

func _toggle_advanced_drawer() -> void:
	var show: bool = not %DetailInputs.visible
	%DetailsLabel.visible = show
	%DetailInputs.visible = show
	%AdvancedDrawerButton.text = "收起高级路线" if show else "高级路线"

func _request_close() -> void:
	if program != null and program.to_dict() != _entry_snapshot:
		%UnsavedReturnDialog.popup_centered(Vector2i(520, 220))
		return
	closed.emit()

func keep_draft() -> void:
	%UnsavedReturnDialog.hide()
	if program == null:
		closed.emit()
		return
	program.draft_status = "draft"
	program_saved.emit(segment, program.to_dict())

func discard_changes() -> void:
	%UnsavedReturnDialog.hide()
	if not _entry_snapshot.is_empty():
		program = SkatingProgram.from_dict(_entry_snapshot)
	closed.emit()

func cancel_return() -> void:
	%UnsavedReturnDialog.hide()

func _configure_target_season() -> void:
	var choice: OptionButton = %TargetSeasonChoice
	choice.clear()
	var current := SeasonBundleRepository.season_year(career)
	var target := int(rules.get("season_start_year",0))
	var locked: bool = original_between_program != null or not career.competition_state.is_empty()
	choice.disabled = locked
	choice.get_parent().visible = not locked
	if target == 0:
		choice.add_item("教学阶段规则")
		choice.set_item_metadata(0,0)
		return
	for year in [current,current+1]:
		if year > current and (locked or career.clock.year < current): continue
		var bundle := SeasonBundleRepository.load_bundle(year,"women_singles",str(rules.get("level","junior")))
		if not bundle.errors.is_empty(): continue
		choice.add_item("%d–%02d（%s）" % [year,(year+1)%100,"当前季" if year == current else "提前准备下一季"])
		choice.set_item_metadata(choice.item_count-1,year)
		if year == target: choice.select(choice.item_count-1)

func _select_target_season(index: int) -> void:
	if original_between_program != null or not career.competition_state.is_empty(): return
	if index < 0 or index >= %TargetSeasonChoice.item_count: return
	var year := int(%TargetSeasonChoice.get_item_metadata(index))
	var loaded := HistoricalRuleRepository.load_season(year,"women_singles")
	if not loaded.errors.is_empty(): return
	var selected := HistoricalRuleRepository.rules_for(loaded.rules,str(rules.get("level","junior")),segment)
	if selected.is_empty(): return
	rules = selected
	_populate_jump_choices()
	_populate_spin_choices()
	_render()

func _populate_spin_choices() -> void:
	%SpinChoice.clear()
	for code in rules.get("allowed_spin_codes",ProgramElement.SPIN_CODES):
		%SpinChoice.add_item(ProgramCandidatePresenter.spin_label(str(code)))
		%SpinChoice.set_item_metadata(%SpinChoice.item_count-1,str(code))

func available_jump_options() -> Array[Dictionary]:
	var choices: Array[Dictionary] = []
	if career == null: return choices
	for jump_id in JumpCatalog.JUMP_IDS:
		var unlocked := int(career.athlete.jumps[jump_id].unlocked_rotations)
		for rotations in range(1, unlocked + 1):
			choices.append({"jump_id":jump_id, "rotations":rotations})
	return choices

func move_element(index: int, delta: int) -> void:
	if program == null or index < 0 or index >= program.elements.size(): return
	var target := index + delta
	if target < 0 or target >= program.elements.size(): return
	var element = program.elements[index]
	program.elements.remove_at(index)
	program.elements.insert(target, element)
	_mark_local_revision_draft()
	_render()
	action_list.select(target)

func _move_selection(delta: int) -> void:
	var selected := action_list.get_selected_items()
	if selected.is_empty(): return
	move_element(int(selected[0]), delta)

func refresh_coach_draft() -> void:
	if career == null or program == null: return
	var proposal := ProgramDraftService.legal_draft(career.athlete, segment, rules, program.music, career.seed + (1 if segment == "short" else 2))
	if proposal.program == null:
		var reasons: Array = proposal.missing if not proposal.missing.is_empty() else proposal.errors
		status_label.text = "教练暂时无法生成合规方案：%s" % "；".join(reasons)
		return
	program = proposal.program
	_populate_jump_choices()
	_render()

func _populate_jump_choices() -> void:
	%JumpChoice.clear()
	%Combo1Choice.clear()
	%Combo2Choice.clear()
	for combo_choice in [%Combo1Choice, %Combo2Choice]:
		combo_choice.add_item("不追加")
		combo_choice.set_item_metadata(0, {})
	for option in available_jump_options():
		var label := "%d%s" % [int(option.rotations), ProgramValidatorCodes.JUMP_CODES.get(str(option.jump_id), str(option.jump_id))]
		var names := {"toe_loop":"后外点冰跳","salchow":"后内结环跳","loop":"后外结环跳","flip":"后内点冰跳","lutz":"勾手跳","axel":"阿克塞尔跳"}
		var readable := "%s · %d周%s" % [label,int(option.rotations),names.get(str(option.jump_id),str(option.jump_id))]
		var explanation := readable+"。数字是周数，字母是跳跃类型。"
		if option.jump_id == "axel": explanation += "阿克塞尔向前起跳，实际转体比标记周数多半周。"
		%JumpChoice.add_item(readable)
		%JumpChoice.set_item_metadata(%JumpChoice.item_count - 1, option)
		%JumpChoice.set_item_tooltip(%JumpChoice.item_count - 1,explanation)
		if not JumpConnectionRules.DIRECT_FOLLOWERS.has(str(option.jump_id)): continue
		for combo_choice in [%Combo1Choice, %Combo2Choice]:
			combo_choice.add_item("+" + readable)
			combo_choice.set_item_metadata(combo_choice.item_count - 1, option)
			combo_choice.set_item_tooltip(combo_choice.item_count - 1,"连跳的追加跳跃："+explanation+"能否接上还取决于前一跳落冰和衔接能力。")
	%ApplyJumpButton.disabled = %JumpChoice.item_count == 0
	%AddJumpButton.disabled = %JumpChoice.item_count == 0

func _add_selected_jump() -> void:
	if program == null or %JumpChoice.item_count == 0: return
	var choice: Dictionary = %JumpChoice.get_item_metadata(%JumpChoice.selected)
	var next_number := 1
	var element_id := "%s-user-jump-%d" % [segment, next_number]
	while program.elements.any(func(element): return element.element_id == element_id):
		next_number += 1
		element_id = "%s-user-jump-%d" % [segment, next_number]
	var added = ProgramElement.create(element_id, "jump", str(choice.jump_id), int(choice.rotations)).element
	program.elements.append(added)
	_mark_local_revision_draft()
	_render()
	action_list.select(program.elements.size() - 1)

func _remove_selected_action() -> void:
	if program == null: return
	var selected := action_list.get_selected_items()
	if selected.is_empty(): return
	program.elements.remove_at(int(selected[0]))
	_mark_local_revision_draft()
	_render()

func _apply_selected_jump() -> void:
	var selected := action_list.get_selected_items()
	if selected.is_empty() or %JumpChoice.item_count == 0: return
	var choice: Dictionary = %JumpChoice.get_item_metadata(%JumpChoice.selected)
	var parts: Array = []
	for combo_choice in [%Combo1Choice, %Combo2Choice]:
		var part: Dictionary = combo_choice.get_item_metadata(combo_choice.selected)
		if not part.is_empty(): parts.append(part)
	var errors: Array[String] = replace_jump(int(selected[0]), str(choice.jump_id), int(choice.rotations), parts)
	if not errors.is_empty(): status_label.text = "无法修改：%s" % "；".join(errors)

func _apply_selected_spin() -> void:
	var selected := action_list.get_selected_items()
	if selected.is_empty(): return
	var errors: Array[String] = set_spin_type(int(selected[0]), str(%SpinChoice.get_item_metadata(%SpinChoice.selected)))
	if not errors.is_empty(): status_label.text = "无法修改：%s" % "；".join(errors)

func replace_jump(index: int, jump_id: String, rotations: int, parts: Array) -> Array[String]:
	if program == null or index < 0 or index >= program.elements.size() or program.elements[index].kind != "jump":
		return ["请先选择跳跃动作"]
	if not career.athlete.jumps.has(jump_id) or rotations > int(career.athlete.jumps[jump_id].unlocked_rotations) or rotations < 1:
		return ["%d%s尚未解锁" % [rotations, ProgramValidatorCodes.JUMP_CODES.get(jump_id, jump_id)]]
	for part in parts:
		var part_id := str(part.get("jump_id", ""))
		var part_rotations := int(part.get("rotations", 0))
		if not career.athlete.jumps.has(part_id) or part_rotations > int(career.athlete.jumps[part_id].unlocked_rotations) or part_rotations < 1:
			return ["%d%s尚未解锁" % [part_rotations, ProgramValidatorCodes.JUMP_CODES.get(part_id, part_id)]]
	var previous_jump_id := jump_id
	for part in parts:
		var connection: Dictionary = JumpConnectionRules.can_connect(previous_jump_id,str(part.jump_id),rules)
		if not connection.allowed: return [str(connection.reason)]
		previous_jump_id = str(part.jump_id)
	var old = program.elements[index]
	var replacement = ProgramElement.from_dict(old.to_dict())
	replacement.jump_id = jump_id
	replacement.rotations = rotations
	var errors: Array[String] = replacement.set_combination_parts(parts)
	if not errors.is_empty(): return errors
	program.elements[index] = replacement
	_mark_local_revision_draft()
	_render()
	action_list.select(index)
	return []

func _mark_local_revision_draft() -> void:
	if program == null: return
	program.draft_status = "draft"
	program.locked_segments.erase(program.segment)

func set_spin_type(index: int, spin_code: String) -> Array[String]:
	if program == null or index < 0 or index >= program.elements.size() or program.elements[index].kind != "spin":
		return ["请先选择旋转动作"]
	if not ProgramElement.SPIN_CODES.has(spin_code): return ["未知旋转类型"]
	program.elements[index].spin_code = spin_code
	_mark_local_revision_draft()
	_render()
	action_list.select(index)
	return []

func _save() -> void:
	if program == null: return
	_sync_music()
	program.route_complexity = str(difficulty_input.get_item_metadata(difficulty_input.selected))
	if original_between_program != null:
		var checked := BetweenSegmentAdjuster.revise(original_between_program, program, _load_athlete, rules)
		if not checked.errors.is_empty():
			status_label.text = "无法确认：%s" % "；".join(checked.errors)
			return
		program_saved.emit(segment, program.to_dict())
		return
	var existing = null
	var existing_data: Dictionary = Dictionary(career.active_programs.get(segment, {}))
	if not existing_data.is_empty(): existing = SkatingProgram.from_dict(existing_data)
	var saved := ProgramDraftService.save_draft(existing, program)
	if not saved.errors.is_empty():
		status_label.text = "草稿保存失败：%s" % "；".join(saved.errors)
		return
	program = saved.program
	# Saving a revision returns it to draft state. Refresh immediately so the
	# separate competition-lock action is available without reopening the panel.
	_render()
	program_saved.emit(segment, program.to_dict())

func _lock_for_competition() -> void:
	if program == null or original_between_program != null: return
	_sync_music()
	program.route_complexity = str(difficulty_input.get_item_metadata(difficulty_input.selected))
	var result := ProgramDraftService.lock_for_competition(program, career.athlete, rules)
	if not result.errors.is_empty():
		status_label.text = "还不能锁定参赛：%s" % "；".join(result.errors)
		return
	program = result.program
	program_saved.emit(segment, program.to_dict())

func _sync_music() -> void:
	var title_changed := music_title_input.text.strip_edges() != str(program.music.get("title", ""))
	var selected_work_id := str(music_preset_choice.get_item_metadata(music_preset_choice.selected))
	var selected_work: Dictionary = MusicCatalogRepository.load_catalog().get("by_id", {}).get(selected_work_id, {})
	if title_changed or not selected_work_id.is_empty():
		program.music["title"] = music_title_input.text.strip_edges()
		program.music["source"] = "built_in" if not selected_work.is_empty() and str(selected_work.title) == program.music.title else "custom"
		program.music["work_id"] = selected_work_id if program.music.source == "built_in" else ""

func _select_details(index: int) -> void:
	var element = program.elements[index]
	%TargetLevelInput.value = element.target_level
	%TargetLevelInput.editable = element.kind in ["spin", "step_sequence"]
	%EntryDifficultyInput.value = element.entry_difficulty
	%AnchorXInput.value = float(element.ice_anchor.get("x", 0.5))
	%AnchorYInput.value = float(element.ice_anchor.get("y", 0.5))
	_anchor_edited = false

func _select_action(index: int) -> void:
	_select_details(index)
	_populate_candidates(index)

func _populate_candidates(index: int) -> void:
	candidate_list.clear()
	candidate_reason_label.text = "选择左侧动作后，这里会说明当前可替换内容。"
	for candidate in ProgramCandidatePresenter.for_slot(career, program, index, rules):
		var action_name := str(candidate.get("label", ""))
		if candidate.has("readable_name"): action_name += " · " + str(candidate.readable_name)
		var row := "%s  ·  %s" % [action_name, str(candidate.get("band_label", ""))]
		candidate_list.add_item(row)
		candidate_list.set_item_tooltip(candidate_list.item_count-1,row + "\n" + str(candidate.get("reason_text","")))
		candidate_list.set_item_metadata(candidate_list.item_count - 1, candidate)
	if candidate_list.item_count > 0:
		candidate_list.select(0)
		_select_candidate(0)

func _select_candidate(index: int) -> void:
	if index < 0 or index >= candidate_list.item_count: return
	var candidate: Dictionary = candidate_list.get_item_metadata(index)
	var value_text := " · 基础分 %.2f" % float(candidate.get("base_value", 0.0)) if float(candidate.get("base_value", 0.0)) > 0.0 else ""
	candidate_reason_label.text = "%s%s\n%s" % [str(candidate.get("band_label", "")), value_text, str(candidate.get("reason_text", ""))]
	%CandidateApplyButton.disabled = str(candidate.get("band", "unavailable")) == "unavailable"
	%ConnectionEditor.visible = str(candidate.get("kind", "")) == "jump"
	if %ConnectionEditor.visible: _populate_connection_choices(candidate)

func _populate_connection_choices(primary: Dictionary) -> void:
	var selected_slot := action_list.get_selected_items()
	if selected_slot.is_empty(): return
	var element = program.elements[int(selected_slot[0])]
	_fill_connection_choice(%Connection1Choice, str(primary.get("jump_id", "")), int(selected_slot[0]))
	_select_connection_metadata(%Connection1Choice, element.combination_parts[0] if element.combination_parts.size() > 0 else {})
	_populate_second_connection()
	_select_connection_metadata(%Connection2Choice, element.combination_parts[1] if element.combination_parts.size() > 1 else {})

func _populate_second_connection() -> void:
	var selected_slot := action_list.get_selected_items()
	var selected_primary := candidate_list.get_selected_items()
	if selected_slot.is_empty() or selected_primary.is_empty(): return
	var primary: Dictionary = candidate_list.get_item_metadata(int(selected_primary[0]))
	var previous_id := str(primary.get("jump_id", ""))
	var first: Dictionary = %Connection1Choice.get_item_metadata(%Connection1Choice.selected) if %Connection1Choice.item_count > 0 else {}
	if first.is_empty():
		%Connection2Choice.clear()
		%Connection2Choice.add_item("先选择第一后半跳")
		%Connection2Choice.set_item_metadata(0, {})
		%Connection2Choice.disabled = true
		return
	%Connection2Choice.disabled = false
	previous_id = str(first.get("jump_id", previous_id))
	_fill_connection_choice(%Connection2Choice, previous_id, int(selected_slot[0]))

func _fill_connection_choice(choice: OptionButton, previous_jump_id: String, slot_index: int) -> void:
	choice.clear()
	choice.add_item("不追加")
	choice.set_item_metadata(0, {})
	for candidate in ProgramCandidatePresenter.for_slot(career, program, slot_index, rules):
		if str(candidate.get("kind", "")) != "jump": continue
		var connection := JumpConnectionRules.can_connect(previous_jump_id, str(candidate.jump_id), rules)
		if not bool(connection.allowed): continue
		var sequence_label := " · 序列" if candidate.jump_id == "axel" else ""
		choice.add_item("+%s%s · %s" % [str(candidate.label), sequence_label, str(candidate.band_label)])
		choice.set_item_tooltip(choice.item_count-1,str(candidate.get("readable_name",candidate.label)))
		choice.set_item_metadata(choice.item_count - 1, candidate)
		choice.set_item_disabled(choice.item_count - 1, str(candidate.band) == "unavailable")

func _select_connection_metadata(choice: OptionButton, part: Dictionary) -> void:
	choice.select(0)
	if part.is_empty(): return
	for index in choice.item_count:
		var candidate: Dictionary = choice.get_item_metadata(index)
		if str(candidate.get("jump_id", "")) == str(part.get("jump_id", "")) and int(candidate.get("rotations", 0)) == int(part.get("rotations", 0)):
			choice.select(index)
			return

func _apply_selected_candidate() -> void:
	var selected_slot := action_list.get_selected_items()
	var selected_candidate := candidate_list.get_selected_items()
	if selected_slot.is_empty() or selected_candidate.is_empty(): return
	var index := int(selected_slot[0])
	var candidate: Dictionary = candidate_list.get_item_metadata(int(selected_candidate[0]))
	if str(candidate.get("band", "unavailable")) == "unavailable": return
	var element = program.elements[index]
	match str(candidate.get("kind", "")):
		"jump":
			var replacement = ProgramElement.from_dict(element.to_dict())
			replacement.jump_id = str(candidate.jump_id)
			replacement.rotations = int(candidate.rotations)
			var parts: Array = []
			for choice in [%Connection1Choice, %Connection2Choice]:
				var part: Dictionary = choice.get_item_metadata(choice.selected)
				if not part.is_empty(): parts.append({"jump_id":str(part.jump_id), "rotations":int(part.rotations)})
			var connection_errors: Array[String] = replacement.set_combination_parts(parts)
			if not connection_errors.is_empty():
				status_label.text = "连跳无法采用：%s" % "；".join(connection_errors)
				return
			program.elements[index] = replacement
		"spin": element.spin_code = str(candidate.spin_code)
	_mark_local_revision_draft()
	_render()
	action_list.select(index)
	_populate_candidates(index)

func _apply_selected_details() -> void:
	var selected := action_list.get_selected_items()
	if selected.is_empty(): return
	var index := int(selected[0])
	var element = program.elements[index]
	if element.kind in ["spin", "step_sequence"]: element.target_level = int(%TargetLevelInput.value)
	element.entry_difficulty = float(%EntryDifficultyInput.value)
	if _anchor_edited: element.ice_anchor = {"x":float(%AnchorXInput.value), "y":float(%AnchorYInput.value)}
	_anchor_edited = false
	_mark_local_revision_draft()
	_render()
	action_list.select(index)

func _on_music_preset_selected(index: int) -> void:
	var work_id := str(music_preset_choice.get_item_metadata(index))
	if work_id.is_empty(): return
	var work: Dictionary = MusicCatalogRepository.load_catalog().get("by_id", {}).get(work_id, {})
	if not work.is_empty(): music_title_input.text = str(work.title)
	_render()

func _render() -> void:
	if program == null: return
	%SubtitleLabel.text = "%s · 切换规则不改动节目；实际编辑保存后按正常规则计算熟悉度代价。" % str(rules.get("ruleset_id","教学阶段"))
	if rules.has("required_spin_codes"): %SubtitleLabel.text += " 指定旋转："+" / ".join(Array(rules.required_spin_codes))
	_sync_music()
	var errors := ProgramValidator.validate(program, career.athlete, rules)
	var slot_issues: Array[String] = []
	for index in program.elements.size():
		var issue := _element_slot_issue(program.elements[index],index)
		if not issue.is_empty(): slot_issues.append(issue)
	status_label.text = "节目符合比赛规则 · 保存后仍需通过训练提高熟悉度" if errors.is_empty() else "草案暂不可参赛：%s%s" % ["；".join(errors),"\n问题槽位：%s" % "；".join(slot_issues) if not slot_issues.is_empty() else ""]
	if errors.is_empty() and program.draft_status == "locked": status_label.text = "节目符合比赛规则 · 已锁定为参赛版本"
	lock_button.disabled = not errors.is_empty() or program.draft_status == "locked"
	%CoachRepairButton.visible = not errors.is_empty()
	var labels: Array[String] = []
	action_list.clear()
	for index in program.elements.size():
		var element = program.elements[index]
		var label := _element_label(element)
		if not _element_slot_issue(element,index).is_empty(): label = "⚠ %s" % label
		labels.append(label)
		action_list.add_item(label)
	element_summary.text = "动作顺序：%s" % (" → ".join(labels) if not labels.is_empty() else "暂无动作")
	base_preview_label.text = "预计基础分 %.2f · 静态动作估算，不含执行质量、复核与扣分" % _preview_base_value()
	var revision := {"program":program, "familiarity_cost":0.0, "errors":[]}
	if original_between_program != null:
		revision = BetweenSegmentAdjuster.revise(original_between_program, program, _load_athlete, rules)
	if not revision.errors.is_empty():
		load_preview = {}
		%LoadLabel.text = "编排尚未通过验证，暂不能预览确认后的自由滑负荷。"
		return
	load_preview = ProgramLoadEstimator.estimate_segment(revision.program, _load_athlete, _load_context)
	var estimate := load_preview
	var parts: Array[String] = []
	var labels_by_key := {"bv_ambition":"基础分难度", "transitions":"衔接进入", "coverage":"路线覆盖", "late_placement":"后段安排", "familiarity":"熟悉度", "stamina":"体能", "fatigue":"疲劳", "injury":"伤病", "growth":"生长", "psychology":"心理"}
	for key in labels_by_key: parts.append("%s %+.1f" % [labels_by_key[key], float(estimate.components[key])])
	%LoadLabel.text = "%s · 总负荷 %.1f · 动作需求 %.1f / 当前容量 %.1f\n%s\n内容较少或路线简单会限制衔接与编排表现。负荷是训练参考，不是成功率。" % [estimate.assessment, estimate.total_load, estimate.demand, estimate.capacity, " · ".join(parts)]
	var combination_estimates: Array[String] = []
	for element in program.elements:
		if element.kind != "jump" or element.combination_parts.is_empty(): continue
		var abbreviation := "%d%s" % [element.rotations,ProgramValidatorCodes.JUMP_CODES.get(element.jump_id,"")]
		for part in element.combination_parts:
			abbreviation += "+%d%s" % [int(part.rotations),ProgramValidatorCodes.JUMP_CODES.get(str(part.jump_id),"")]
		var probability := ProgramPerformanceSimulator.estimate_combination_success_probability(_load_athlete,program,element,_load_context)
		combination_estimates.append("%s 约%d%%" % [abbreviation,int(round(probability*100.0))])
	if not combination_estimates.is_empty():
		%LoadLabel.text += "\n教练连跳完成率参考（状态平稳）：%s。它会随单跳、落冰衔接和节目熟悉度变化，不是保证。" % " · ".join(combination_estimates)
	if original_between_program != null:
		%LoadLabel.text += "\n确认后合练熟悉度代价 %.1f；目标级别以赛中技术组最终判定为准。" % float(revision.familiarity_cost)

func _preview_base_value() -> float:
	var values: Dictionary = ProgramPerformanceSimulator.BASE_VALUES_2014
	var non_jump: Dictionary = {}
	if career.clock.year >= 2018:
		var result := FormalScoringRepository.load_catalog(int(rules.get("season_start_year",SeasonBundleRepository.season_year(career))), "women_singles")
		if result.errors.is_empty():
			values = Dictionary(result.catalog.jump_base_values)
			non_jump = Dictionary(result.catalog.non_jump_base_values)
	var total := 0.0
	for element in program.elements:
		if element.kind == "jump":
			total += float(values.get("%d%s" % [element.rotations, ProgramValidatorCodes.JUMP_CODES.get(element.jump_id, "")], 0.0))
			for part in element.combination_parts:
				total += float(values.get("%d%s" % [int(part.rotations), ProgramValidatorCodes.JUMP_CODES.get(str(part.jump_id), "")], 0.0))
		elif element.kind == "spin":
			total += float(Dictionary(non_jump.get(element.spin_code, {})).get(str(element.target_level), 2.5))
		elif element.kind == "step_sequence":
			total += float(Dictionary(non_jump.get("StSq", {})).get(str(element.target_level), 2.6))
	return snappedf(total, 0.01)

func _element_label(element) -> String:
	if element.kind == "jump":
		var label := "%d%s" % [element.rotations, ProgramValidatorCodes.JUMP_CODES.get(str(element.jump_id),"?")]
		for part in element.combination_parts:
			label += "+%d%s" % [int(part.rotations), ProgramValidatorCodes.JUMP_CODES.get(str(part.jump_id),"?")]
		return label
	if element.kind == "spin": return "旋转 %s · 等级由临场执行判定" % element.spin_code
	if element.kind == "step_sequence": return "接续步 · 等级由临场执行判定"
	return "编排步法"

func _element_slot_issue(element, index: int) -> String:
	var prefix := "第%d槽" % (index + 1)
	if element.kind == "jump":
		if not career.athlete.jumps.has(element.jump_id) or int(career.athlete.jumps[element.jump_id].unlocked_rotations) < int(element.rotations): return "%s动作尚未掌握" % prefix
		if element.jump_id == "axel" and not element.combination_parts.is_empty() and str(rules.get("segment","")) == "short" and (rules.has("required_axel_rotations") or Array(rules.get("required_jump_types",[])).has("axel")): return "%s阿克塞尔必须单跳" % prefix
		if element.combination_parts.is_empty() and element.jump_id != "axel" and rules.has("required_solo_jump") and element.jump_id != str(rules.required_solo_jump): return "%s应为规定单跳" % prefix
		var previous_id: String = element.jump_id
		for part in element.combination_parts:
			var part_id := str(part.get("jump_id",""))
			var rotations := int(part.get("rotations",0))
			if not career.athlete.jumps.has(part_id) or int(career.athlete.jumps[part_id].unlocked_rotations) < rotations: return "%s连跳后半尚未掌握" % prefix
			if not JumpConnectionRules.can_connect(previous_id,part_id,rules).allowed: return "%s连跳连接不成立" % prefix
			previous_id = part_id
	elif element.kind == "spin":
		if not Array(rules.get("allowed_spin_codes",ProgramElement.SPIN_CODES)).has(element.spin_code): return "%s旋转类型不符合本场规则" % prefix
		var required: Array = rules.get("required_spin_codes",[])
		if not required.is_empty():
			var canonical := _canonical_spin_code(str(element.spin_code))
			if not required.has(canonical): return "%s不满足指定旋转槽位" % prefix
			var same_group := 0
			for candidate in program.elements:
				if candidate.kind == "spin" and _canonical_spin_code(str(candidate.spin_code)) == canonical: same_group += 1
			if same_group > 1: return "%s与另一旋转重复，缺少指定类型" % prefix
	return ""

func _canonical_spin_code(spin_code: String) -> String:
	for required_code in rules.get("spin_alternatives",{}):
		if spin_code == str(required_code) or Array(rules.spin_alternatives[required_code]).has(spin_code): return str(required_code)
	return spin_code
