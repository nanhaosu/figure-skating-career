class_name InternalCompetitionPanel
extends MarginContainer

signal adjustment_selected(option_id: String)
signal segment_completed(segment: String)
signal competition_confirmed
signal main_menu_requested

const VIEW_MODES := ["slow", "normal", "fast"]
const PLAYBACK_RATES := {"slow": 0.65, "normal": 1.0, "fast": 2.0}

var view_mode := "normal"
var playback_state := "ready"
var cached_performance: Dictionary = {}
var _revealed := 0
var _total := 0
var _playback_index := 0
var _segment_id := "short"
var _segment_record: Dictionary = {}
var _completion_emitted := false
var _playback_elapsed := 0.0
var _playback_duration := 8.0
var _element_reveal_progresses: Array[float] = []
var _kc_elapsed := 0.0
var _kc_stage_index := 0
var _protocol_dialog: AcceptDialog
var _score_context: Dictionary = {}

@onready var event_title: Label = %EventTitle
@onready var progress_label: Label = %ProgressLabel
@onready var athlete_lower_third: Label = %AthleteLowerThird
@onready var technical_panel = %TechnicalPanel
@onready var competition_ice_view = %CompetitionIceView

func _ready() -> void:
	%BroadcastMainMenuButton.pressed.connect(func(): main_menu_requested.emit())
	%AdjustmentMainMenuButton.pressed.connect(func(): main_menu_requested.emit())
	%ResultMainMenuButton.pressed.connect(func(): main_menu_requested.emit())
	%SpeedSlow.pressed.connect(set_view_mode.bind("slow"))
	%SpeedNormal.pressed.connect(set_view_mode.bind("normal"))
	%SpeedFast.pressed.connect(set_view_mode.bind("fast"))
	%PlaybackButton.pressed.connect(advance_playback)
	%SettleButton.pressed.connect(settle_immediately)
	%ConfirmResultButton.pressed.connect(_confirm_result)
	%KissAndCryPanel.continue_requested.connect(_confirm_segment_score)
	%KissAndCryPanel.return_requested.connect(func():
		%KissAndCryOverlay.hide()
		%PlaybackButton.disabled = false
		%PlaybackButton.text = "查看本段成绩")
	%KissAndCryPanel.main_menu_requested.connect(func(): main_menu_requested.emit())
	%KissAndCryPanel.view_protocol_requested.connect(_show_segment_protocol)
	_protocol_dialog = AcceptDialog.new()
	_protocol_dialog.title = "本段小分"
	add_child(_protocol_dialog)
	set_process(false)
	set_view_mode("normal")

func present(context: Dictionary) -> void:
	_score_context = context.duplicate(true)
	present_score({})
	var segment_name := str(context.get("segment_name", "比赛"))
	_segment_id = str(context.get("segment", "short"))
	event_title.text = "%s · %s" % [str(context.get("event_name", "内部赛")), segment_name]
	athlete_lower_third.text = "%s\n曲目：%s" % [str(context.get("athlete_name", "运动员")), str(context.get("music_title", "未命名曲目"))]
	_revealed = 0
	_total = int(context.get("element_count", 0))
	_update_progress()
	technical_panel.reset_segment(segment_name)
	cached_performance = {}
	_playback_index = 0
	_completion_emitted = false
	_segment_record = {}
	_playback_elapsed = 0.0
	playback_state = "ready"
	set_process(false)
	%PlaybackButton.disabled = false
	%PlaybackButton.text = "开始自动播放"
	%SettleButton.disabled = false
	competition_ice_view.load_timeline({}, [])
	%ResultOverlay.visible = false
	%KissAndCryOverlay.visible = false

func load_performance(performance: Dictionary) -> void:
	cached_performance = performance.duplicate(true)
	_playback_index = 0
	_revealed = 0
	_total = Array(cached_performance.get("elements", [])).size()
	_playback_duration = maxf(7.0, 3.0 + float(_total) * 2.2)
	_playback_elapsed = 0.0
	playback_state = "ready"
	set_process(false)
	var route := _current_route()
	_element_reveal_progresses = _build_reveal_progresses(route, Array(cached_performance.get("elements", [])))
	competition_ice_view.load_timeline(route, Array(cached_performance.get("elements", [])))
	_update_progress()

func load_segment(segment_record: Dictionary) -> void:
	_segment_record = segment_record.duplicate(true)
	var display: Dictionary = Dictionary(segment_record.get("performance", {})).duplicate(true)
	var timeline: Dictionary = load("res://src/presentation/competition_broadcast_builder.gd").build(segment_record, 0.0, 60.0)
	display.elements = []
	for event in timeline.events: display.elements.append(event.record)
	load_performance(display)

func playback_checkpoint() -> Dictionary:
	return {"segment":_segment_id,"state":playback_state,"elapsed":_playback_elapsed,"kc_elapsed":_kc_elapsed,"view_mode":view_mode}

func restore_playback_checkpoint(checkpoint: Dictionary) -> void:
	if str(checkpoint.get("segment","")) != _segment_id: return
	var state := str(checkpoint.get("state","ready"))
	if not state in ["ready","playing","paused","kiss_and_cry","awaiting_confirmation","segment_complete"]: return
	var elapsed := float(checkpoint.get("elapsed",0.0))
	if not is_finite(elapsed): return
	set_view_mode(str(checkpoint.get("view_mode","normal")))
	_playback_elapsed = clampf(elapsed,0.0,_playback_duration)
	var progress := _playback_elapsed / _playback_duration
	competition_ice_view.set_progress(progress)
	_reveal_due_elements(progress)
	if state in ["kiss_and_cry","awaiting_confirmation","segment_complete"]:
		_complete_segment()
		var reveal_elapsed := float(checkpoint.get("kc_elapsed",0.0))
		_advance_kiss_and_cry(maxf(0.0,reveal_elapsed) if is_finite(reveal_elapsed) else 0.0)
		if state in ["awaiting_confirmation","segment_complete"] and _kc_stage_index < 3:
			_advance_kiss_and_cry(2.0)
		if state == "segment_complete": _confirm_segment_score()
	else:
		playback_state = "ready" if state == "ready" else "paused"
		%PlaybackButton.text = "开始自动播放" if state == "ready" else "继续播放"
		set_process(false)

func advance_playback() -> void:
	match playback_state:
		"awaiting_confirmation":
			%KissAndCryOverlay.show()
		"ready":
			playback_state = "playing"
			%PlaybackButton.text = "暂停"
			set_process(true)
		"playing":
			playback_state = "paused"
			%PlaybackButton.text = "继续播放"
			set_process(false)
		"paused":
			playback_state = "playing"
			%PlaybackButton.text = "暂停"
			set_process(true)

func _process(delta: float) -> void:
	advance_time(delta)

func advance_time(delta: float) -> void:
	if playback_state == "kiss_and_cry":
		_advance_kiss_and_cry(delta)
		return
	if playback_state != "playing": return
	_playback_elapsed = minf(_playback_duration, _playback_elapsed + maxf(0.0, delta) * float(PLAYBACK_RATES[view_mode]))
	var progress := 1.0 if _playback_duration <= 0.0 else _playback_elapsed / _playback_duration
	competition_ice_view.set_progress(progress)
	_reveal_due_elements(progress)
	if progress >= 1.0:
		_complete_segment()

func settle_immediately() -> void:
	if playback_state == "segment_complete": return
	_playback_elapsed = _playback_duration
	competition_ice_view.set_progress(1.0)
	_reveal_due_elements(1.0)
	_complete_segment()

func reveal_element(record: Dictionary) -> void:
	technical_panel.push_element(record)
	_revealed += 1
	_total = maxi(_total, _revealed)
	_update_progress()

func finalize_review(element_id: String, final_values: Dictionary) -> void:
	technical_panel.finalize_review(element_id, final_values)
	competition_ice_view.update_element_status(element_id, str(final_values.get("status", "success")))

func apply_technical_review(review: Dictionary) -> void:
	var scores := {}
	for score in _segment_record.get("score", {}).get("element_scores", []): scores[str(score.get("element_id", ""))] = score
	for final_element in review.get("final_elements", []):
		var element_id := str(final_element.get("element_id", ""))
		if element_id.is_empty(): continue
		var display: Dictionary = final_element.duplicate(true)
		display.abbreviation = load("res://src/presentation/competition_broadcast_builder.gd").display_abbreviation(final_element)
		if scores.has(element_id):
			display.live_goe = float(scores[element_id].goe)
			display.element_score = float(scores[element_id].total)
		technical_panel.finalize_review(element_id, display)

func present_score(score: Dictionary) -> void:
	%TesValue.text = "%.2f" % float(score.get("tes", 0.0))
	%PcsValue.text = "%.2f" % float(score.get("pcs", 0.0))
	%DeductionValue.text = "-%.2f" % float(score.get("deductions", 0.0))
	%TotalValue.text = "%.2f" % float(score.get("total", 0.0))
	var has_internal_advantage := float(score.get("internal_advantage", 0.0)) > 0.05
	%InternalAdvantageNote.visible = has_internal_advantage
	%InternalAdvantageNote.text = "教练提醒：内部评分环境可能偏宽，外赛不会自动复制这一待遇。" if has_internal_advantage else ""

func present_adjustment_options(options: Array) -> void:
	for child in %AdjustmentChoices.get_children(): child.queue_free()
	for option in options:
		var button := Button.new()
		button.name = "Adjustment_%s" % str(option.get("id", "unknown"))
		button.text = "%s\n%s" % [str(option.get("label", "未命名调整")), str(option.get("reason", ""))]
		button.custom_minimum_size = Vector2(420, 58)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.pressed.connect(_select_adjustment.bind(str(option.get("id", "keep"))))
		%AdjustmentChoices.add_child(button)
	%AdjustmentOverlay.visible = true

func present_final_result(result: Dictionary) -> void:
	%ResultTitle.text = "内部赛结束 · 第 %d 名 · %.2f 分" % [int(result.get("public_rank", 0)), float(result.get("total_score", 0.0))]
	var lines: Array[String] = []
	for row in result.get("standings", []):
		var marker := "  ← 你" if bool(row.get("is_player", false)) else ""
		lines.append("%d. %-8s  SP %.2f  FS %.2f  总分 %.2f%s" % [int(row.get("rank", 0)), str(row.get("name", "")), float(row.get("short_total", 0.0)), float(row.get("free_total", 0.0)), float(row.get("total", 0.0)), marker])
	%StandingsText.text = "\n".join(lines)
	var decision: Dictionary = Dictionary(result.get("club_decision", {}))
	var changes: Dictionary = Dictionary(decision.get("resource_changes", {}))
	var slot_text := "推荐获得一次外赛名额" if bool(decision.get("external_slot_recommended", false)) else "暂不推荐外赛名额"
	var review_text := str(decision.get("review_requirement", ""))
	%ClubDecisionText.text = "俱乐部决定（与公开名次分开）\n%s；冰时 %s，教练关注 %s%s" % [slot_text, _signed(float(changes.get("ice_access", 0.0))), _signed(float(changes.get("coach_attention", 0.0))), ("；" + review_text) if not review_text.is_empty() else ""]
	%ResultOverlay.visible = true

func _select_adjustment(option_id: String) -> void:
	%AdjustmentOverlay.visible = false
	adjustment_selected.emit(option_id)

func _complete_segment() -> void:
	if _completion_emitted: return
	playback_state = "kiss_and_cry"
	set_process(true)
	apply_technical_review(Dictionary(_segment_record.get("technical_review", {})))
	present_score(Dictionary(_segment_record.get("score", {})))
	%PlaybackButton.disabled = true
	%SettleButton.disabled = true
	%PlaybackButton.text = "等待成绩确认"
	var model := preload("res://src/presentation/kiss_and_cry_builder.gd").build(null,_segment_record,{"current_rank":int(_score_context.get("current_rank",0)),"total_score":float(_score_context.get("total_score",_segment_record.get("score",{}).get("total",0.0))),"review_complete":true})
	%KissAndCryPanel.setup(model); %KissAndCryOverlay.visible = true; _kc_elapsed = 0.0; _kc_stage_index = 0

func _advance_kiss_and_cry(delta: float) -> void:
	_kc_elapsed += maxf(0.0,delta)
	if _kc_elapsed >= 0.6 and _kc_stage_index < 1: %KissAndCryPanel.advance_reveal(); _kc_stage_index = 1
	if _kc_elapsed >= 1.2 and _kc_stage_index < 2: %KissAndCryPanel.advance_reveal(); _kc_stage_index = 2
	if _kc_elapsed >= 1.8 and _kc_stage_index < 3: %KissAndCryPanel.advance_reveal(); _kc_stage_index = 3
	if _kc_stage_index == 3:
		playback_state = "awaiting_confirmation"
		set_process(false)

func _confirm_segment_score() -> void:
	if _completion_emitted or %KissAndCryPanel.reveal_stage != "final": return
	_completion_emitted = true
	playback_state = "segment_complete"
	set_process(false)
	%KissAndCryOverlay.hide()
	%PlaybackButton.disabled = true
	%PlaybackButton.text = "本阶段已结束"
	segment_completed.emit(_segment_id)

func _show_segment_protocol() -> void:
	var lines: PackedStringArray = []
	var elements: Array = _segment_record.get("technical_review",{}).get("final_elements",cached_performance.get("elements",[]))
	if elements.is_empty(): elements = cached_performance.get("elements",[])
	for element in elements:
		lines.append("%s  ·  BV %.2f  ·  GOE %+.2f" % [str(element.get("abbreviation","动作")),float(element.get("base_value",0.0)),float(element.get("live_goe",element.get("goe",0.0)))])
	lines.append("TES %.2f  ·  PCS %.2f  ·  扣分 %.2f" % [float(_segment_record.get("score",{}).get("tes",0.0)),float(_segment_record.get("score",{}).get("pcs",0.0)),float(_segment_record.get("score",{}).get("deductions",0.0))])
	_protocol_dialog.dialog_text = "\n".join(lines)
	_protocol_dialog.popup_centered(Vector2i(520,320))

func _confirm_result() -> void:
	%ResultOverlay.visible = false
	competition_confirmed.emit()

func _signed(value: float) -> String:
	return "+%.1f" % value if value >= 0.0 else "%.1f" % value

func set_view_mode(mode: String) -> void:
	if not VIEW_MODES.has(mode): return
	view_mode = mode
	%SpeedSlow.button_pressed = mode == "slow"
	%SpeedNormal.button_pressed = mode == "normal"
	%SpeedFast.button_pressed = mode == "fast"

func _update_progress() -> void:
	progress_label.text = "%d / %d" % [_revealed, _total]

func _reveal_due_elements(progress: float) -> void:
	var elements: Array = cached_performance.get("elements", [])
	while _playback_index < elements.size():
		var threshold := _element_reveal_progresses[_playback_index] if _playback_index < _element_reveal_progresses.size() else float(_playback_index + 1) / float(elements.size() + 1)
		if progress + 0.0001 < threshold: break
		reveal_element(elements[_playback_index])
		_playback_index += 1

func _build_reveal_progresses(route: Dictionary, elements: Array) -> Array[float]:
	var primary_anchors: Dictionary = {}
	for raw_anchor in route.get("action_anchors", []):
		var anchor: Dictionary = Dictionary(raw_anchor)
		if int(anchor.get("part_index", 0)) == 0:
			primary_anchors[str(anchor.get("element_id", ""))] = float(anchor.get("progress", 0.0))
	var progresses: Array[float] = []
	for index in elements.size():
		var element_id := str(elements[index].get("element_id", ""))
		progresses.append(float(primary_anchors.get(element_id, float(index + 1) / float(elements.size() + 1))))
	return progresses

func _current_route() -> Dictionary:
	var route: Dictionary = Dictionary(_segment_record.get("route_execution", {})).duplicate(true)
	if not Array(route.get("points", [])).is_empty(): return route
	var elements: Array = cached_performance.get("elements", [])
	var points: Array[Dictionary] = [
		{"x": 0.08, "y": 0.5, "progress": 0.0},
		{"x": 0.34, "y": 0.18, "progress": 0.33},
		{"x": 0.68, "y": 0.78, "progress": 0.66},
		{"x": 0.92, "y": 0.42, "progress": 1.0},
	]
	var anchors: Array[Dictionary] = []
	for index in elements.size():
		anchors.append({"element_id": str(elements[index].get("element_id", "")), "part_index": 0, "progress": float(index + 1) / float(elements.size() + 1)})
	return {"points": points, "action_anchors": anchors}
