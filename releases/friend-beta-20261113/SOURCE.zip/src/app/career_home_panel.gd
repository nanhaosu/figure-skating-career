class_name CareerHomePanel
extends MarginContainer

signal action_requested(action_id: String)

const Presenter = preload("res://src/presentation/career_home_presenter.gd")
const ThemeFactory = preload("res://src/app/theme_factory.gd")

var _action_id := ""
var _offseason_optional: Button

func _ready() -> void:
	_offseason_optional = Button.new()
	_offseason_optional.name = "OffseasonOptional"
	_offseason_optional.text = "冰场之外 · 可选"
	_offseason_optional.tooltip_text = "看看这个夏天的生活片段；不查看也能照常训练。"
	_offseason_optional.pressed.connect(func(): action_requested.emit("open_offseason_memory"))
	%CurrentEventDetail.get_parent().add_child(_offseason_optional)
	%PrimaryAction.pressed.connect(func(): action_requested.emit(_action_id))
	%TrainingNavButton.pressed.connect(func(): action_requested.emit("open_training"))
	%ProgramsNavButton.pressed.connect(func(): action_requested.emit("open_programs"))
	%SeasonNavButton.pressed.connect(func(): action_requested.emit("open_season"))
	%RecordsNavButton.pressed.connect(func(): action_requested.emit("open_records"))
	%SaveNavButton.pressed.connect(func(): action_requested.emit("open_saves"))
	for card_path in ["Content/GoalCard","Content/Body/CurrentEventCard","Content/Body/RightRail/ChangedCard","Content/Body/RightRail/FactsCard","Content/BottomBar"]:
		get_node(card_path).add_theme_stylebox_override("panel",ThemeFactory.card_style())
	%PrimaryAction.add_theme_stylebox_override("normal",ThemeFactory.primary_style())
	%PrimaryAction.add_theme_color_override("font_color",ThemeFactory.GOLD_DARK)
	resized.connect(_update_layout)
	_update_layout()

func present(career) -> void:
	_offseason_optional.visible = career != null and not preload("res://src/simulation/offseason_event_service.gd").pending(career).is_empty()
	var view: Dictionary = Presenter.build(career)
	%AthleteName.text = str(view.athlete_name)
	%DateLabel.text = str(view.date_label)
	%StageTitle.text = str(view.stage_title)
	%GoalText.text = str(view.career_goal)
	%CurrentEventTitle.text = str(view.current_event.title)
	%CurrentEventDetail.text = str(view.current_event.detail)
	var next_event: Dictionary = view.next_event
	%NextEventLabel.text = "下一站 · 尚未确定" if next_event.is_empty() else "下一站 · %s  %s" % [str(next_event.label),str(next_event.when)]
	var states: Array = view.changed_states
	while states.size() < 3: states.append({"label":"状态","value":"暂无变化"})
	%CompetitiveLabel.text = str(states[0].label)
	%CompetitiveValue.text = str(states[0].value)
	%BodyLabel.text = str(states[1].label)
	%BodyValue.text = str(states[1].value)
	%SupportLabel.text = str(states[2].label)
	%SupportValue.text = str(states[2].value)
	_action_id = str(view.primary_action.id)
	%ActionDetail.text = str(view.primary_action.detail)
	%PrimaryAction.text = str(view.primary_action.label)
	var facts: Array = view.recent_facts
	%RecentStory.text = "还没有新的事实记录。" if facts.is_empty() else "\n".join(facts.map(func(row): return "• %s" % str(row.text)))

func _update_layout() -> void:
	var compact := size.x > 0.0 and size.x < 1080.0
	add_theme_constant_override("margin_left",18 if compact else 36)
	add_theme_constant_override("margin_right",18 if compact else 36)
	add_theme_constant_override("margin_top",12 if compact else 20)
	add_theme_constant_override("margin_bottom",12 if compact else 20)
	%RightRail.custom_minimum_size.x = 280.0 if compact else 340.0
	%AthleteName.add_theme_font_size_override("font_size",26 if compact else 32)
	%CurrentEventTitle.add_theme_font_size_override("font_size",22 if compact else 27)
