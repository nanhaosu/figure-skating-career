class_name CareerScreenRouter
extends RefCounted

const ScreenRouteValue = preload("res://src/app/screen_route.gd")

var _known_screens: Dictionary = {}
var _fallback_screen_id := "career_home"
var _current: Dictionary = {}
var _history: Array[Dictionary] = []

func _init(known_screen_ids: Array = ["career_home"], fallback_screen_id: String = "career_home") -> void:
	_fallback_screen_id = fallback_screen_id
	for screen_id in known_screen_ids:
		_known_screens[str(screen_id)] = true
	if not _known_screens.has(_fallback_screen_id):
		_known_screens[_fallback_screen_id] = true

func reset(route: Dictionary, safe_fallback: Dictionary = {}) -> void:
	_history.clear()
	_current = _validated(route, safe_fallback)

func open(route: Dictionary, safe_fallback: Dictionary = {}) -> void:
	var next := _validated(route, safe_fallback)
	if not _current.is_empty():
		var explicit_return: Dictionary = Dictionary(next.get("return_route", {}))
		_history.append(_validated(explicit_return) if not explicit_return.is_empty() else _current.duplicate(true))
	_current = next

func replace(route: Dictionary, safe_fallback: Dictionary = {}) -> void:
	_current = _validated(route, safe_fallback)

func back() -> Dictionary:
	if _history.is_empty():
		_current = _default_route()
	else:
		_current = _history.pop_back()
	return current()

func current() -> Dictionary:
	return _current.duplicate(true)

func can_back() -> bool:
	return not _history.is_empty()

func _validated(route: Dictionary, safe_fallback: Dictionary = {}) -> Dictionary:
	var screen_id := str(route.get("screen_id", ""))
	if _known_screens.has(screen_id):
		return ScreenRouteValue.create(
			screen_id,
			Dictionary(route.get("context", {})),
			Dictionary(route.get("return_route", {})),
		)
	if not safe_fallback.is_empty():
		var fallback_id := str(safe_fallback.get("screen_id", ""))
		if _known_screens.has(fallback_id):
			return ScreenRouteValue.create(
				fallback_id,
				Dictionary(safe_fallback.get("context", {})),
				Dictionary(safe_fallback.get("return_route", {})),
			)
	return _default_route()

func _default_route() -> Dictionary:
	return ScreenRouteValue.create(_fallback_screen_id)
