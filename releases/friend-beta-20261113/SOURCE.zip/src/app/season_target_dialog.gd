extends Window

signal target_selected(event_id: String)
signal event_requested(event_id: String)
signal auto_requested
signal preparation_requested(route_id: String, event_id: String, base_revision: int)
signal preparation_program_requested(event_id: String, segment: String)

var _career
var _calendar: Dictionary
var _entry_plan: Dictionary
var _model: Dictionary = {}
var _targets: OptionButton
var _body: RichTextLabel
var _save: Button
var _competition_filter: OptionButton
var _auto: Button
var _route: OptionButton
var _apply_route: Button
var _route_view: Dictionary = {}
var _programme_buttons: Array[Button] = []

func _ready() -> void:
	hide()
	title = "赛季目标与竞争形势"
	transient = true
	exclusive = true
	min_size = Vector2i(320,300)
	var panel := PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.add_theme_stylebox_override("panel",preload("res://src/app/theme_factory.gd").card_style())
	add_child(panel)
	var margin := MarginContainer.new()
	for edge in ["left","right","top","bottom"]:
		margin.add_theme_constant_override("margin_"+edge,16)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",12)
	margin.add_child(box)
	_targets = OptionButton.new()
	_targets.name = "TargetChoice"
	_targets.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_targets.item_selected.connect(_select)
	box.add_child(_targets)
	_competition_filter = OptionButton.new()
	_competition_filter.name = "CompetitionFilter"
	for text in ["国内竞争者","已达标 / 入选的国际对手","全部候选人"]:
		_competition_filter.add_item(text)
	_competition_filter.item_selected.connect(func(_index): _render())
	box.add_child(_competition_filter)
	_route = OptionButton.new()
	_route.name = "PreparationRouteChoice"
	for option in preload("res://src/simulation/preparation_route_service.gd").options():
		_route.add_item(option.label)
		_route.set_item_metadata(_route.item_count-1,option.id)
	_route.item_selected.connect(func(_index): _render())
	box.add_child(_route)
	_body = RichTextLabel.new()
	_body.name = "TargetDetails"
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.scroll_active = true
	box.add_child(_body)
	var actions := HFlowContainer.new()
	box.add_child(actions)
	_save = Button.new()
	_save.name = "SaveTargetButton"
	_save.text = "设为本季目标"
	_save.pressed.connect(func():
		if not _model.get("target_event_id","").is_empty():
			target_selected.emit(str(_model.target_event_id)))
	actions.add_child(_save)
	_apply_route = Button.new()
	_apply_route.name = "ApplyPreparationButton"
	_apply_route.text = "采用备战方案并设为目标"
	_apply_route.pressed.connect(func():
		if _route_view.get("ok",false): preparation_requested.emit(str(_route.get_item_metadata(_route.selected)),str(_model.target_event_id),int(_career.training_direction.revision)))
	actions.add_child(_apply_route)
	for segment in ["short","free"]:
		var edit := Button.new()
		edit.name = "PreparationEdit"+segment.capitalize()
		edit.text = "按目标规则检查"+("短节目" if segment == "short" else "自由滑")
		edit.pressed.connect(func():
			hide()
			preparation_program_requested.emit(str(_model.get("target_event_id","")),segment))
		actions.add_child(edit)
		_programme_buttons.append(edit)
	var inspect := Button.new()
	inspect.name = "InspectTargetButton"
	inspect.text = "查看赛事 / 安排参赛"
	inspect.pressed.connect(func():
		hide()
		event_requested.emit(str(_model.get("target_event_id",""))))
	actions.add_child(inspect)
	_auto = Button.new()
	_auto.name = "AutoToTargetButton"
	_auto.text = "托管到此目标"
	_auto.pressed.connect(func():
		hide()
		auto_requested.emit())
	actions.add_child(_auto)
	var close := Button.new()
	close.name = "CloseTargetButton"
	close.text = "返回"
	close.pressed.connect(hide)
	actions.add_child(close)
	close_requested.connect(hide)

func present(career, calendar: Dictionary, entry_plan: Dictionary) -> void:
	_career = career
	_calendar = calendar
	_entry_plan = entry_plan
	_model = preload("res://src/presentation/season_target_presenter.gd").build(career,calendar,entry_plan)
	_targets.clear()
	for target in _model.get("targets",[]):
		_targets.add_item(str(target.get("name",target.event_id)))
		_targets.set_item_metadata(_targets.item_count-1,str(target.event_id))
		if target.event_id == _model.get("target_event_id"): _targets.select(_targets.item_count-1)
	var preparation: Dictionary = career.season_program_plan.get("preparation",{})
	if int(preparation.get("direction_revision",-1)) == int(career.training_direction.revision):
		for index in _route.item_count:
			if _route.get_item_metadata(index) == preparation.get("route_id"): _route.select(index)
	_render()
	var viewport_size := Vector2i(get_parent().get_viewport().get_visible_rect().size)
	size = Vector2i(maxi(320,mini(900,viewport_size.x-40)),maxi(300,mini(650,viewport_size.y-40)))
	position = (viewport_size-size)/2
	if not visible: popup()

func _select(index: int) -> void:
	var id := str(_targets.get_item_metadata(index))
	_model = preload("res://src/presentation/season_target_presenter.gd").build(_career,_calendar,_entry_plan,id)
	_render()

func _render() -> void:
	var rivals: Array = _model.get("competitors",[])
	if _competition_filter.selected == 0:
		var home := str(_career.story_context.home_federation)
		rivals = rivals.filter(func(row):return row.get("federation") == home)
	elif _competition_filter.selected == 1:
		rivals = rivals.filter(func(row):return row.get("personal_status") == "eligible" or row.get("status") == "selected")
	var sections: Array = preload("res://src/presentation/season_target_presenter.gd")._sections(_model.get("target",{}),_model.get("eligibility",{}),_model.get("deadlines",[]),rivals,_model.get("skip_consequences",[]),_model.get("entry_options",[]))
	var domestic: Dictionary = _model.get("jgp_competition",{}).get("section",{})
	if not domestic.is_empty(): sections.insert(2,domestic)
	var lines: Array[String] = []
	_route_view = preload("res://src/simulation/preparation_route_service.gd").preview(_career,_model.get("target",{}),str(_route.get_item_metadata(_route.selected)))
	var chosen: Dictionary = _career.season_program_plan.get("preparation",{})
	var already_chosen: bool = chosen.get("route_id") == _route.get_item_metadata(_route.selected) and chosen.get("target_event_id") == _model.get("target_event_id") and int(chosen.get("direction_revision",-1)) == int(_career.training_direction.revision)
	_apply_route.disabled = not _route_view.get("ok",false) or already_chosen
	_apply_route.text = "当前备战方案" if already_chosen else "采用备战方案并设为目标"
	var checks: Dictionary = _route_view.get("programme_checks",{})
	if checks.is_empty() and not _model.get("target",{}).is_empty(): checks = preload("res://src/simulation/preparation_route_service.gd").programme_checks(_career,_model.target)
	var can_edit: bool = not checks.is_empty() and checks.short.get("rules_known",false) and checks.free.get("rules_known",false) and _career.competition_state.is_empty()
	for button in _programme_buttons: button.disabled = not can_edit
	if not checks.is_empty():
		var gaps := false
		for segment in ["short","free"]:
			var errors: Array = checks[segment].errors
			lines.append(("短节目" if segment == "short" else "自由滑")+"目标规则检查："+("符合目标赛事规则" if errors.is_empty() else "；".join(errors)))
			gaps = gaps or not errors.is_empty()
		if gaps: lines.append("建议先按目标规则修订节目，再安排后续合乐；改编会损失熟悉度，临近比赛再改会减少重新熟悉的时间。")
	if _route_view.get("ok",false):
		lines.append("目标备战 · "+str(_route_view.label)+"（距比赛%d天）" % int(_route_view.days))
		lines.append(str(_route_view.programme))
		lines.append("当前自由滑跳跃构成："+str(_route_view.programme_layout))
		var course_labels := {"skating_foundation":"滑行基础","rotation":"旋转与转体","conditioning":"体能","rest":"恢复","program_short":"短节目合乐","program_free":"自由滑合乐","jump_toe_loop":"后外点冰","jump_salchow":"后内结环","jump_loop":"后外结环","jump_flip":"后内点冰","jump_lutz":"勾手","jump_axel":"阿克塞尔"}
		var changes: Array[String] = []
		for key in _route_view.deltas:
			changes.append("%s %+d" % [course_labels.get(key,key),int(_route_view.deltas[key])])
		lines.append("实际课时占比变化（百分点）："+("；".join(changes) if not changes.is_empty() else "与当前课程相同"))
		var allocation: Array[String] = []
		for key in _route_view.plan.shares:
			allocation.append("%s %d%%" % [course_labels.get(key,key),int(_route_view.plan.shares[key])])
		lines.append("采用后的实际课程："+"；".join(allocation))
		if not _route_view.retained_goals.is_empty(): lines.append("保留此前技术意向："+"、".join(_route_view.retained_goals))
		if int(_route_view.plan.get("expression_share",0)) > 0: lines.append("音乐表达专项使用滑行课程中的%d个百分点，不额外增加训练量。" % int(_route_view.plan.expression_share))
		lines.append("\n".join(_route_view.readiness))
		lines.append(str(_route_view.warning))
	else:
		lines.append("目标备战暂不可采用："+str(_route_view.get("error","")))
	lines.append("")
	for section in sections:
		lines.append(str(section.get("heading","")))
		lines.append(str(section.get("body","")))
		lines.append("")
	_body.text = "\n".join(lines) if not lines.is_empty() else "本赛季暂无可查看目标。"
	_body.scroll_to_line(0)
	var id := str(_model.get("target_event_id",""))
	_save.disabled = id.is_empty() or _career.season_state.get("target_event_id","") == id
	_save.text = "当前赛季目标" if not id.is_empty() and _career.season_state.get("target_event_id","") == id else "设为本季目标"
	_auto.disabled = id.is_empty() or _career.season_state.get("target_event_id","") != id

