class_name SummaryPanel
extends MarginContainer

const CareerState = preload("res://src/domain/career_state.gd")
const QuarterTrainingSummary = preload("res://src/presentation/quarter_training_summary.gd")
const AthleteConditionService = preload("res://src/simulation/athlete_condition_service.gd")
const KeyNodeService = preload("res://src/simulation/key_node_service.gd")
const ThemeFactory = preload("res://src/app/theme_factory.gd")
const TrainingPeriodPresenter = preload("res://src/presentation/training_period_presenter.gd")
const PostCompetitionPresenter = preload("res://src/presentation/post_competition_presenter.gd")

signal next_quarter_requested
signal home_requested
signal save_requested
signal main_menu_requested
signal milestone_advance_requested
signal key_node_response_requested(node_id: String)
var _pending_node_id := ""
var _next_action_id := "next_quarter"

const TARGET_LABELS := {
	"deep_edge": "滑行深刃",
	"single_jumps": "跳跃基础",
	"rotation": "旋转能力",
	"landing": "落冰控制",
	"recovery_capacity": "恢复能力",
	"acute_fatigue": "即时疲劳",
	"cumulative_fatigue": "累积疲劳",
	"ankle_load": "踝部负荷",
	"impact_load": "跳跃冲击负荷",
	"growth_trend": "身体成长趋势",
}
const CAUSE_LABELS := {
	"skating_foundation_training": "滑行基础训练",
	"jump_toe_loop_training": "后外点冰跳训练",
	"jump_salchow_training": "后内结环跳训练",
	"jump_loop_training": "后外结环跳训练",
	"jump_flip_training": "后内点冰跳训练",
	"jump_lutz_training": "勾手跳训练",
	"jump_axel_training": "阿克塞尔跳训练",
	"toe_loop_practice": "后外点冰跳训练",
	"salchow_practice": "后内结环跳训练",
	"loop_practice": "后外结环跳训练",
	"flip_practice": "后内点冰跳训练",
	"lutz_practice": "勾手跳训练",
	"axel_practice": "阿克塞尔跳训练",
	"1_rotation_attempt": "单周跳尝试",
	"readiness_gap": "身体与技术准备不足",
	"rotation_training": "旋转训练",
	"conditioning_training": "体能与力量训练",
	"training_load": "训练负荷",
	"rest_recovery": "恢复安排",
	"insufficient_recovery": "恢复单位不足",
	"jump_repetition_load": "跳跃重复负荷",
	"low_motivation": "训练动力偏低",
	"year_end_growth_observation": "年末身体成长观察",
	"guardian_health_protection": "监护人优先保护健康",
	"guardian_achievement_pressure": "监护人提高成绩期待",
	"coach_foundation_priority": "教练优先巩固滑行基础",
	"coach_jump_priority": "教练认为跳跃训练不足",
	"coach_jump_load_safety": "教练制止过量跳跃训练",
	"medical_recovery_required": "疼痛报告后强制恢复",
	"fatigue_recovery_required": "疲劳或身体负荷过高，强制恢复",
	"secret_practice": "私下加练",
	"unsupervised_full_load": "无人指导但身体负荷未减",
	"unknown_high_difficulty": "尚未掌握的高难度尝试",
}
const AUTHORITY_CAUSES := [
	"guardian_health_protection",
	"guardian_achievement_pressure",
	"coach_foundation_priority",
	"coach_jump_priority",
	"coach_jump_load_safety",
	"medical_recovery_required",
	"fatigue_recovery_required",
]
const JUMP_LABELS := {"toe_loop": "后外点冰跳", "salchow": "后内结环跳", "loop": "后外结环跳", "flip": "后内点冰跳", "lutz": "勾手跳", "axel": "阿克塞尔跳"}
const ROTATION_LABELS := {"single": "单周", "double": "双周", "triple": "三周", "quad": "四周"}

@onready var summary_heading: Label = %SummaryHeading
@onready var technique_changes: Label = %TechniqueChanges
@onready var body_changes: Label = %BodyChanges
@onready var people_decisions: Label = %PeopleDecisions
@onready var growth_observations: Label = %GrowthObservations
@onready var primary_sections: VBoxContainer = %PrimarySections
@onready var breakthroughs: Label = %Breakthroughs
@onready var near_breakthroughs: Label = %NearBreakthroughs
@onready var setbacks_costs: Label = %SetbacksCosts
@onready var roadmap_summary: Label = %RoadmapSummary
@onready var coach_advice: Label = %CoachAdvice
@onready var relationship_summary: Label = %RelationshipSummary
@onready var details_button: Button = %DetailsButton
@onready var details_container: VBoxContainer = %DetailsContainer
@onready var details_text: Label = %DetailsText
@onready var action_message: Label = %ActionMessage
@onready var next_button: Button = %NextButton
@onready var milestone_button: Button = %AdvanceMilestoneButton
@onready var save_button: Button = %SaveButton
@onready var menu_button: Button = %MenuButton
@onready var key_node_button: Button = %ResolveKeyNodeButton

func _ready() -> void:
	next_button.pressed.connect(_on_next_pressed)
	milestone_button.pressed.connect(func(): milestone_advance_requested.emit())
	save_button.pressed.connect(func(): save_requested.emit())
	menu_button.pressed.connect(func(): main_menu_requested.emit())
	details_button.pressed.connect(_toggle_details)
	details_container.visible = false
	key_node_button.pressed.connect(func(): key_node_response_requested.emit(_pending_node_id))
	for card_name in ["ProgressCard", "CostCard", "RelationshipCard", "SuggestionCard"]:
		%StoryCards.get_node(card_name).add_theme_stylebox_override("panel", ThemeFactory.card_style())

func present(career: CareerState, outcomes: Array) -> void:
	_set_next_action("next_quarter","进入下一季度")
	%StoryCards.get_node("ProgressCard/Box/BreakthroughHeading").text = "进步与突破"
	%StoryCards.get_node("CostCard/Box/SetbacksCostsHeading").text = "代价与风险"
	%StoryCards.get_node("RelationshipCard/Box/RelationshipHeading").text = "身边的人"
	%StoryCards.get_node("SuggestionCard/Box/CoachAdviceHeading").text = "下一步建议"
	var completed_year := career.clock.year
	var completed_quarter := career.clock.quarter - 1
	if completed_quarter == 0:
		completed_quarter = 4
		completed_year -= 1
	summary_heading.text = "%s · %d年 第%d季度总结" % [
		career.athlete.display_name,
		completed_year,
		completed_quarter,
	]
	var technique_lines: Array[String] = []
	var body_lines: Array[String] = []
	var growth_lines: Array[String] = []
	for signal_row in career.condition_state.growth_signals:
		if signal_row.has("label"): growth_lines.append(str(signal_row.label))
	var authority_codes: Array[String] = []
	for outcome in outcomes:
		for cause_code in outcome.cause_codes:
			if AUTHORITY_CAUSES.has(cause_code) and not authority_codes.has(cause_code):
				authority_codes.append(cause_code)
		if is_zero_approx(outcome.delta):
			continue
		var rendered := _format_delta(outcome.target, outcome.delta, outcome.cause_codes)
		if outcome.summary_key == "growth_change_observed":
			growth_lines.append(rendered)
		elif outcome.category == "body" or outcome.target == "recovery_capacity":
			body_lines.append(rendered)
		else:
			technique_lines.append(rendered)
	for entry in _latest_attempt_entries(career.history):
		technique_lines.append(_format_attempt_batch(entry))
	technique_changes.text = _section_text(technique_lines, "本季度没有技术数值变化。")
	body_changes.text = _section_text(body_lines, "本季度身体与恢复指标保持不变。")
	growth_observations.text = _section_text(growth_lines, "本季度没有新的成长观察。")
	var decision_lines: Array[String] = []
	for cause_code in authority_codes:
		var description := _cause_label(cause_code)
		decision_lines.append("• %s\n  原因：%s" % [description, description])
	people_decisions.text = _section_text(decision_lines, "本季度监护人与教练未修改训练安排。")
	relationship_summary.text = _section_text(decision_lines, "教练与家人没有提出新的异议，关系保持稳定。")
	var completed_entries: Array = []
	for outcome in outcomes: completed_entries.append(outcome)
	completed_entries.append_array(_latest_attempt_entries(career.history))
	var progress := _latest_roadmap_entry(career.history)
	if not progress.is_empty(): completed_entries.append(progress)
	var meaningful: Dictionary = QuarterTrainingSummary.build(career, completed_entries)
	var progress_lines: Array[String] = []
	progress_lines.assign(meaningful.breakthroughs)
	progress_lines.append_array(meaningful.near_breakthroughs)
	breakthroughs.text = _section_text(progress_lines, "本季度在巩固基础，还没有出现显著突破。")
	near_breakthroughs.text = _section_text(meaningful.near_breakthroughs, "暂时没有接近突破的动作。")
	var combined: Array[String] = []
	combined.assign(meaningful.setbacks)
	combined.append_array(meaningful.costs)
	combined.append_array(AthleteConditionService.labels(career))
	setbacks_costs.text = _section_text(combined, "没有明显挫折或新增身体代价。")
	roadmap_summary.text = _section_text(meaningful.roadmap, "成长路线没有明显偏移。")
	var suggestion_lines: Array[String] = []
	suggestion_lines.assign(meaningful.coach_advice)
	suggestion_lines.append_array(meaningful.roadmap)
	coach_advice.text = _section_text(suggestion_lines, "继续观察。")
	details_text.text = _section_text(meaningful.details, "本季度没有额外数值详情。")
	details_container.visible = false
	details_button.text = "展开训练详情"
	action_message.text = ""
	milestone_button.disabled = not KeyNodeService.pending(career).is_empty()
	var pending := KeyNodeService.pending(career)
	key_node_button.visible = not pending.is_empty()
	_pending_node_id = str(pending[0].id) if not pending.is_empty() else ""
	if not pending.is_empty():
		key_node_button.text = "已了解：%s" % str(pending[0].label)
		action_message.text = "请确认身体情况，再调整下一季度的具体训练分配。"

func present_milestone(career: CareerState, result: Dictionary) -> void:
	var quarter_rows: Array = result.get("quarters", [])
	if quarter_rows.is_empty(): return
	var last: Dictionary = quarter_rows.back()
	var outcomes: Array = []
	for row in last.get("outcomes", []):
		outcomes.append(preload("res://src/domain/outcome_record.gd").new(str(row.get("category", "")), str(row.get("target", "")), float(row.get("delta", 0.0)), Array(row.get("cause_codes", [])).duplicate(), str(row.get("summary_key", ""))))
	present(career, outcomes)
	var ledger: Array[String] = ["快速推进账本："]
	for row in quarter_rows:
		var clock: Dictionary = row.get("clock", {})
		var milestone_count := Array(row.get("history", [])).filter(func(entry): return ["jump_milestone", "technical_grade_review", "roadmap_progress"].has(str(entry.get("category", "")))).size()
		ledger.append("• %d年第%d季度：训练完成，关键记录%d条" % [int(clock.get("year", 0)), int(clock.get("quarter", 1)), milestone_count])
	details_text.text += "\n\n" + "\n".join(ledger)
	action_message.text = "已安全推进%d个季度；停止原因：%s。可展开训练详情查看逐季度账本。" % [quarter_rows.size(), _milestone_reason(str(result.get("stop_reason", "")))]

func present_training_period(career: CareerState, result: Dictionary) -> void:
	var before: CareerState = result.get("before", career)
	var report := TrainingPeriodPresenter.build(before, result)
	summary_heading.text = "%s · %d年 第%d季度训练结果" % [career.athlete.display_name, before.clock.year, before.clock.quarter]
	%StoryCards.get_node("ProgressCard/Box/BreakthroughHeading").text = "原定计划"
	%StoryCards.get_node("CostCard/Box/SetbacksCostsHeading").text = "实际发生"
	%StoryCards.get_node("RelationshipCard/Box/RelationshipHeading").text = "状态变化"
	%StoryCards.get_node("SuggestionCard/Box/CoachAdviceHeading").text = "接下来"
	breakthroughs.text = _report_lines(report.plan)
	var highlights: Array = []
	var coaching: Dictionary = {}
	for line in report.happened:
		if line.get("kind") == "coach_review" and coaching.is_empty(): coaching = line
		if str(line.text).begins_with("首次完成") or str(line.text).contains("类跳跃共尝试"):
			highlights.append(line)
	if highlights.is_empty(): highlights = Array(report.happened).slice(0, 2)
	if not coaching.is_empty():
		highlights = highlights.filter(func(line): return line.get("kind") != "coach_review").slice(0,1)
		highlights.append(coaching)
	setbacks_costs.text = _compact_report_lines(highlights)
	relationship_summary.text = _training_change_overview(report.changes, result.get("facts", []))
	coach_advice.text = _report_lines(report.next_step)
	near_breakthroughs.text = ""
	roadmap_summary.text = ""
	details_text.text = "实际训练\n%s\n\n状态变化\n%s\n\n训练证据\n%s" % [_report_lines(report.happened), _report_lines(report.changes), _fact_ledger(result.get("facts", []))]
	details_container.visible = false
	details_button.text = "查看训练证据"
	if result.has("completed_quarters"):
		summary_heading.text = "%s · 阶段验收（实际训练%d周）" % [career.athlete.display_name,int(result.get("elapsed_weeks",0))]
		var focus_lines: Array[String] = []
		for fact in result.get("facts",[]): focus_lines.append(str(fact.get("text","")))
		setbacks_costs.text = "\n".join(focus_lines.slice(0,2))
		coach_advice.text = str(focus_lines.back()) if not focus_lines.is_empty() else "可调整重点，或沿用当前安排。"
	action_message.text = "本期已经结算。这里展示的是实际训练记录，不是预告或自动生成的故事。"
	key_node_button.visible = false
	milestone_button.disabled = false
	_set_next_action("return_home","带着结果回到主页")

func present_post_competition(career: CareerState, archive: Dictionary) -> void:
	var report: Dictionary = PostCompetitionPresenter.build(career,archive)
	summary_heading.text = str(report.heading)
	%StoryCards.get_node("ProgressCard/Box/BreakthroughHeading").text = str(report.performance.title)
	%StoryCards.get_node("CostCard/Box/SetbacksCostsHeading").text = str(report.training_evidence.title)
	%StoryCards.get_node("RelationshipCard/Box/RelationshipHeading").text = str(report.consequences.title)
	%StoryCards.get_node("SuggestionCard/Box/CoachAdviceHeading").text = "接下来"
	breakthroughs.text = str(report.performance.text)
	setbacks_costs.text = str(report.training_evidence.text)
	relationship_summary.text = str(report.consequences.text)
	coach_advice.text = str(report.next_action.detail)
	near_breakthroughs.text = ""
	roadmap_summary.text = ""
	details_text.text = "看懂本场得分\n%s\n\n本场证据\n%s" % [str(report.scoring_guide.text),_post_competition_evidence(report)]
	if not report.programme_memory.is_empty():
		details_text.text += "\n\n本场使用的节目\n"+report.programme_memory
	details_container.visible = false
	details_button.text = "看懂本场得分 / 查看证据"
	action_message.text = "名次、分数和后果均来自已经提交的比赛记录。"
	key_node_button.visible = false
	milestone_button.disabled = false
	_set_next_action(str(report.next_action.id),str(report.next_action.label))

func present_season_reflection(career: CareerState, season_id: String) -> void:
	var report: Dictionary = preload("res://src/presentation/season_reflection_presenter.gd").build(career,season_id)
	summary_heading.text = season_id+" · 这一季，属于你的记录"
	%StoryCards.get_node("ProgressCard/Box/BreakthroughHeading").text = "当时的期待"
	%StoryCards.get_node("CostCard/Box/SetbacksCostsHeading").text = "留下的进步"
	%StoryCards.get_node("RelationshipCard/Box/RelationshipHeading").text = "真正站过的赛场"
	%StoryCards.get_node("SuggestionCard/Box/CoachAdviceHeading").text = "身边的人与下一季"
	breakthroughs.text = str(report.expectation.get("text","这一季没有记下额外的个人愿望；成绩不是唯一的回顾方式。"))
	var progress_lines: Array[String] = []
	for row in report.progress:
		var stage: String = {"practice":"训练中留下完成记录","program_transfer":"在节目练习中完成","competition_confirmed":"在比赛中完成"}.get(row.stage,"留下技术记录")
		progress_lines.append(str(row.action_id)+" · "+stage)
	setbacks_costs.text = "\n".join(progress_lines.slice(0,2)) if not progress_lines.is_empty() else "本季没有可核实的首次技术突破，不把日常积累写成虚构解锁。"
	var competition_lines: Array[String] = []
	for row in report.competition: competition_lines.append("%s · 第%d名，%.2f分" % [row.name,row.rank,row.total_score])
	relationship_summary.text = "\n".join(competition_lines.slice(-2)) if not competition_lines.is_empty() else "本季没有已记录的个人正式赛成绩。没有上国际赛的日子，也可以继续培养。"
	coach_advice.text = str(report.relationships.back().text) if not report.relationships.is_empty() else "可以沿用节目继续打磨，也可以重新考虑下季的两个培养重点。"
	near_breakthroughs.text = ""
	roadmap_summary.text = ""
	details_text.text = "本季技术记录\n%s\n\n比赛记录\n%s\n\n期待与相处\n%s" % ["\n".join(progress_lines),"\n".join(competition_lines),str(report.expectation.get("text",""))]
	for memory in report.relationships: details_text.text += "\n"+str(memory.text)
	details_container.visible = false
	details_button.text = "展开这一季的记录"
	action_message.text = "回顾只读取已保存经历，不推进时间，不额外发奖励。"
	key_node_button.visible = false
	milestone_button.disabled = false
	_set_next_action("return_home","回到生涯主页")

func _post_competition_evidence(report: Dictionary) -> String:
	var lines: Array[String] = []
	for key in ["performance","training_evidence","consequences"]:
		lines.append("• %s：%s" % [str(report[key].title),"、".join(Array(report[key].evidence_refs))])
	return "\n\n".join(lines)

func _set_next_action(action_id: String, label: String) -> void:
	_next_action_id = action_id
	next_button.text = label

func _on_next_pressed() -> void:
	if _next_action_id == "return_home": home_requested.emit()
	else: next_quarter_requested.emit()

func _report_lines(lines: Array) -> String:
	var rendered: Array[String] = []
	for line in lines: rendered.append("• %s" % str(line.get("text", "")))
	return "\n\n".join(rendered)

func _training_change_overview(changes: Array, facts: Array) -> String:
	var costs: Array[String] = []
	var recovery: Array[String] = []
	var physical_labels := {"acute_fatigue":"即时疲劳","cumulative_fatigue":"累积疲劳","ankle_load":"踝部负荷","impact_load":"冲击负荷"}
	for fact in facts:
		var target := str(fact.get("target", ""))
		if str(fact.get("kind", "")) != "state_change" or not physical_labels.has(target): continue
		var delta := float(fact.get("delta", 0.0))
		if is_zero_approx(delta): continue
		var text := "%s%+.2f" % [physical_labels[target], delta]
		if delta > 0.0: costs.append(text)
		else: recovery.append(text)
	var priority: Array = []
	if not costs.is_empty(): priority.append({"text":"身体负荷：%s。" % "、".join(costs)})
	if not recovery.is_empty(): priority.append({"text":"身体恢复：%s。" % "、".join(recovery)})
	var remaining: Array = changes.filter(func(change): return not physical_labels.has(str(change.get("target", "")))) if not priority.is_empty() else changes
	return _compact_report_lines(priority + remaining)

func _compact_report_lines(lines: Array) -> String:
	var rendered: Array[String] = []
	for line in lines.slice(0, 2):
		var description := str(line.get("text", ""))
		if description.length() > 90: description = description.substr(0, 89) + "…"
		rendered.append("• %s" % description)
	return "\n".join(rendered)

func _fact_ledger(facts: Array) -> String:
	var rendered: Array[String] = []
	for fact in facts:
		var refs: Array = fact.get("evidence_refs", [])
		rendered.append("• %s\n  依据：%s" % [str(fact.get("text", "")), "、".join(refs)])
	return "本期没有可核验记录。" if rendered.is_empty() else "\n\n".join(rendered)

func _milestone_reason(reason: String) -> String:
	if reason == "key_node": return "身体情况需要确认"
	if reason == "medical_restriction": return "伤病恢复期间不能执行当前训练"
	if reason == "advance_rejected": return "当前季度尚未完成"
	return str({"max_quarters":"达到本次推进上限", "2018_transition":"进入2018赛季", "competition_invitation":"内部赛邀请待处理", "certification_review":"技术等级考核有新结果", "health_alert":"身体负荷需要关注", "save_failed":"自动保存失败", "authority_conflict":"教练或家长提出异议", "quarter_event":"季度事件需要选择", "choice_due":"成长路线需要选择"}.get(reason, reason))

func _toggle_details() -> void:
	details_container.visible = not details_container.visible
	details_button.text = "收起训练详情" if details_container.visible else "展开训练详情"

func _latest_roadmap_entry(history: Array[Dictionary]) -> Dictionary:
	for index in range(history.size() - 1, -1, -1):
		var entry: Dictionary = history[index]
		if entry.get("category") == "roadmap_progress": return entry
		if entry.get("category") == "quarter_plan": break
	return {}

func _latest_attempt_entries(history: Array[Dictionary]) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var found_latest_plan := false
	for index in range(history.size() - 1, -1, -1):
		var entry: Dictionary = history[index]
		if entry.get("category") == "quarter_plan":
			if found_latest_plan: break
			found_latest_plan = true
			continue
		if found_latest_plan and ["jump_attempt_batch", "jump_milestone", "jump_stage"].has(str(entry.get("category", ""))):
			result.push_front(entry)
	return result

func _format_attempt_batch(entry: Dictionary) -> String:
	var rotation_names := {1: "单周", 2: "双周", 3: "三周", 4: "四周"}
	var details: Array[String] = ["尝试%d次" % int(entry.get("attempts", 0)), "成功%d次" % int(entry.get("successes", 0))]
	for key in ["falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]:
		var count := int(entry.get(key, 0))
		if count > 0:
			details.append("%s%d次" % [{"falls":"摔倒", "pops":"跳空", "two_foot":"双足", "hand_down":"扶冰", "underrotated":"存周", "downgraded":"降组"}[key], count])
	return "• %s·%s：%s" % [JUMP_LABELS.get(str(entry.get("jump_id", "")), "未知跳跃"), rotation_names.get(int(entry.get("rotations", 1)), "未知周数"), "，".join(details)]

func show_message(message: String, is_error: bool = false) -> void:
	action_message.text = message
	action_message.modulate = Color(0.8, 0.12, 0.12) if is_error else Color(0.1, 0.55, 0.2)

func _format_delta(target: String, delta: float, cause_codes: Array[String]) -> String:
	var localized_causes: Array[String] = []
	for cause_code in cause_codes:
		localized_causes.append(_cause_label(cause_code))
	if localized_causes.is_empty():
		localized_causes.append("系统未提供原因（请检查记录）")
	return "• %s %s\n  原因：%s" % [
		_target_label(target),
		_signed_delta(delta),
		"、".join(localized_causes),
	]

func _signed_delta(delta: float) -> String:
	if delta > 0.0:
		return "+%.2f" % delta
	return "%.2f" % delta

func _target_label(target: String) -> String:
	if TARGET_LABELS.has(target): return TARGET_LABELS[target]
	var parts := target.split(".")
	if parts.size() == 3 and JUMP_LABELS.has(parts[0]) and ROTATION_LABELS.has(parts[1]) and parts[2] == "proficiency":
		return "%s·%s熟练度" % [JUMP_LABELS[parts[0]], ROTATION_LABELS[parts[1]]]
	return target

func _cause_label(cause_code: String) -> String:
	if CAUSE_LABELS.has(cause_code): return CAUSE_LABELS[cause_code]
	if cause_code.ends_with("_rotation_attempt"):
		var rotations := int(cause_code.trim_suffix("_rotation_attempt"))
		return ["", "单周跳尝试", "双周跳尝试", "三周跳尝试", "四周跳尝试"][clampi(rotations, 0, 4)]
	if cause_code.begins_with("event:"): return "季度事件"
	if cause_code.begins_with("memory:"): return "既往事件记忆"
	return cause_code

func _section_text(lines: Array, empty_text: String) -> String:
	var normalized: Array[String] = []
	for line in lines: normalized.append(str(line))
	return empty_text if normalized.is_empty() else "\n\n".join(normalized)
