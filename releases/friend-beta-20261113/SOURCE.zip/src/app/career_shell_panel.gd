class_name CareerShellPanel
extends Control

signal navigation_requested(screen_id: String)
signal save_manager_requested
signal main_menu_requested

const NAVIGATION := {
	"career_home": "HomeNavButton",
	"training": "TrainingNavButton",
	"programs": "ProgramsNavButton",
	"season": "SeasonNavButton",
	"records": "RecordsNavButton",
	"relationships": "RelationshipsNavButton",
	"health":"HealthNavButton",
	"repertoire":"RepertoireNavButton",
}

@onready var content_host: Control = %ContentHost

func _ready() -> void:
	var navigation := get_node("SideBar/Navigation")
	for entry in [{"name":"HealthNavButton","label":"身体与康复"},{"name":"RepertoireNavButton","label":"技术武器库"}]:
		var button := Button.new()
		button.name = entry.name
		button.text = entry.label
		navigation.add_child(button)
		navigation.move_child(button,6)
	for child in navigation.get_children():
		if child is Button: child.custom_minimum_size.y = 32
	navigation.add_theme_constant_override("separation",4)
	for screen_id in NAVIGATION:
		navigation.get_node(NAVIGATION[screen_id]).pressed.connect(func(): navigation_requested.emit(screen_id))
	%SaveManagerButton.pressed.connect(func(): save_manager_requested.emit())
	%MainMenuButton.pressed.connect(func(): main_menu_requested.emit())

func present(career, route: Dictionary, persistence_text: String = "") -> void:
	%AthleteLabel.text = career.athlete.display_name
	%DateLabel.text = "%d年 · 第%d季度" % [career.clock.year, career.clock.quarter]
	%PersistenceLabel.text = persistence_text if not persistence_text.is_empty() else "当前进度已保留"
	var selected := str(route.get("screen_id", "career_home"))
	for screen_id in NAVIGATION:
		var button: Button = get_node("SideBar/Navigation/" + NAVIGATION[screen_id])
		button.disabled = screen_id == selected
		button.theme_type_variation = "SelectedNavButton" if screen_id == selected else "NavButton"
