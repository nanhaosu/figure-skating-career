class_name PlayerGuidanceService
extends RefCounted

const COMPETITION_ACTIONS := {
	"practice_ready": {"label":"查看赛前训练", "detail":"先了解当天状态，再决定如何应对。"},
	"short_ready": {"label":"开始短节目", "detail":"短节目即将开始，检查状态后上场。"},
	"free_adjustment": {"label":"调整自由滑构成", "detail":"根据短节目结果决定具体动作配置。"},
	"free_ready": {"label":"开始自由滑", "detail":"自由滑即将开始，准备完成本场比赛。"},
	"complete": {"label":"查看比赛结果", "detail":"确认排名、小分表和本场影响。"},
}

static func build(career) -> Dictionary:
	if career == null or career.athlete == null or career.clock == null:
		return _empty_view()
	var action := _next_action(career)
	return {
		"stage_title": _stage_title(career),
		"goal": _goal(career,action),
		"key_states": _key_states(career),
		"next_action": action,
		"recent_story": _recent_story(career),
	}

static func _next_action(career) -> Dictionary:
	if not career.condition_state.get("pending_decision",{}).is_empty():
		return {"id":"review_health_decision","label":"与医疗团队商量下一步","detail":"可以先了解身体情况，再确认治疗路线；查看不会推进时间。"}
	if not career.competition_state.is_empty():
		var copy: Dictionary = COMPETITION_ACTIONS.get(str(career.competition_state.get("status","")),{"label":"继续当前比赛","detail":"当前比赛还有需要完成的环节。"})
		return {"id":"resume_competition","label":copy.label,"detail":copy.detail}
	var invitation := str(career.internal_invitation_state.get("status","not_ready"))
	if invitation in ["pending","accepted"]:
		return {"id":"review_internal_invitation","label":"回应俱乐部内部赛","detail":"这是第一次检验训练成果的机会，也可以暂缓参加。"}
	if int(career.clock.year) >= 2018:
		return {"id":"open_season","label":"查看赛季安排","detail":"确认下一场赛事、报名状态和赛前准备。"}
	return {"id":"open_training","label":"与教练安排训练","detail":"先确定近期重点，具体比例可以交给教练。"}

static func _goal(career,action: Dictionary) -> String:
	match str(action.id):
		"review_health_decision": return "先确认治疗与康复安排"
		"resume_competition": return "完成当前比赛"
		"review_internal_invitation": return "准备第一次完整比赛"
		"open_season": return "在青年组争取稳定的正式比赛机会"
		_: return "建立可靠的滑行与跳跃基础"

static func _stage_title(career) -> String:
	if not career.competition_state.is_empty(): return "比赛日·站上冰面"
	if int(career.clock.year) >= 2018: return "国内青年组·争取机会"
	var age := int(career.clock.year) - int(career.athlete.birth_year)
	if age <= 9: return "启蒙期·打好基础"
	if age <= 11: return "成长前期·积累技术"
	return "青年组准备·形成竞争力"

static func _key_states(career) -> Array[Dictionary]:
	var body: Dictionary = career.athlete.body
	var fatigue := float(body.get("acute_fatigue",0.0)) + float(body.get("cumulative_fatigue",0.0)) * 0.35
	var body_text := "状态良好" if fatigue < 38.0 else ("需要留意" if fatigue < 68.0 else "必须恢复")
	var programs_ready := not Dictionary(career.active_programs.get("short",{})).is_empty() and not Dictionary(career.active_programs.get("free",{})).is_empty()
	var support := _support_label(career)
	return [
		{"id":"competitive","label":"竞技准备","value":"节目已就绪" if programs_ready else "继续积累"},
		{"id":"body","label":"身体状态","value":body_text},
		{"id":"support","label":"支持环境","value":support},
	]

static func _support_label(career) -> String:
	var values: Array[float] = []
	for relationship in career.relationships.values():
		if relationship != null: values.append(float(relationship.professional_trust))
	if values.is_empty(): return "正在磨合"
	var total := 0.0
	for value in values: total += value
	var average := total / values.size()
	return "稳定支持" if average >= 65.0 else ("需要沟通" if average >= 40.0 else "关系紧张")

static func _recent_story(career) -> Array[String]:
	var result: Array[String] = []
	for index in range(career.history.size() - 1,-1,-1):
		var entry: Dictionary = career.history[index]
		var line := str(entry.get("summary",entry.get("reason",entry.get("label","")))).strip_edges()
		if line.is_empty() or result.has(line): continue
		result.append(line)
		if result.size() == 3: break
	return result

static func _empty_view() -> Dictionary:
	return {
		"stage_title":"等待建立生涯",
		"goal":"创建一名选手，开始她的花滑故事",
		"key_states":[],
		"next_action":{"id":"create_career","label":"创建新生涯","detail":"选择出生年份、家庭和启蒙经历。"},
		"recent_story":[],
	}
