class_name FormalCompetitionPanel
extends MarginContainer

signal strategy_selected(strategy_id: String)
signal practice_response_selected(response_id: String)
signal playback_requested(segment: String)
signal adjustment_selected(adjustment_id: String)
signal archive_confirmed
signal playback_completed(segment: String)
signal score_acknowledged(segment: String)
signal broadcast_return_requested
signal main_menu_requested

var selected_strategy_id := "balanced"
var cut_after_rank := 24
var _session: Dictionary = {}
var playback_speed := 1.0
var playback_state := "ready"
var _segment_record: Dictionary = {}
var _prepared_live_elements: Array = []
var _elapsed := 0.0
var _revealed_elements := 0
var _standing_buttons: Dictionary = {}
var _archive: Dictionary = {}
var _playback_completion_emitted := false
var _confirmation_elapsed := 0.0
const CONFIRMATION_SECONDS := 2.4
var focus_skater_ids: Array[String] = []
var auto_slow_enabled := true
var playback_mode := "normal"
var _replay_athlete_id := ""
var _clock_windows: Array[Dictionary] = []
var _normal_duration := 160.0
var _focus_event := ""
var _focus_manually_selected := false
var _return_to_short := false
var _return_playback: Dictionary = {}
var _stage_button: Button
var _stage_preview: Window
var _record_books: Dictionary = {}
var _career = null
var _kc_stage_index := 0
var _opponent_contexts: Array[Dictionary] = []

func _ready() -> void:
	%ShowRosterButton.pressed.connect(show_roster)
	%CloseRosterButton.pressed.connect(func(): %RosterOverlay.visible = false)
	%SafeStrategyButton.pressed.connect(_select_strategy.bind("safe"))
	%BalancedStrategyButton.pressed.connect(_select_strategy.bind("balanced"))
	%AttackStrategyButton.pressed.connect(_select_strategy.bind("attack"))
	%StartPlaybackButton.pressed.connect(_start_playback)
	%PauseButton.pressed.connect(_toggle_playback)
	%Speed1x.pressed.connect(_set_speed.bind(1.0))
	%Speed15x.pressed.connect(_set_speed.bind(1.5))
	%Speed2x.pressed.connect(_set_speed.bind(2.0))
	%NextActionButton.pressed.connect(_next_action)
	%SkipResultButton.pressed.connect(_skip_result)
	%QuickButton.toggled.connect(func(enabled): set_playback_mode("quick" if enabled else "normal"))
	%AutoSlowButton.toggled.connect(func(enabled): auto_slow_enabled = enabled)
	%FocusButton.pressed.connect(show_roster)
	%StandingsFocusButton.pressed.connect(show_roster)
	%ReturnStandingsButton.pressed.connect(_return_from_replay)
	%OpenKissAndCryButton.pressed.connect(func(): %KissAndCryOverlay.visible = true; %OpenKissAndCryButton.visible = false)
	resized.connect(_update_layout)
	%ArchiveConfirmButton.pressed.connect(func(): archive_confirmed.emit())
	%CloseProtocolButton.pressed.connect(func(): %ProtocolOverlay.visible = false)
	%KissAndCryPanel.continue_requested.connect(_acknowledge_score)
	%KissAndCryPanel.view_protocol_requested.connect(_open_player_protocol_from_kc)
	%KissAndCryPanel.return_requested.connect(_return_from_kiss_and_cry)
	%KissAndCryPanel.main_menu_requested.connect(func(): main_menu_requested.emit())
	%KeepAdjustmentButton.pressed.connect(func(): adjustment_selected.emit("keep"))
	%ProtectAdjustmentButton.pressed.connect(func(): adjustment_selected.emit("protect"))
	%ChaseAdjustmentButton.pressed.connect(func(): adjustment_selected.emit("chase"))
	_select_strategy("balanced", false)
	set_process(false)

func present_session(session: Dictionary, career = null) -> void:
	if _stage_button != null: _stage_button.hide()
	_session = session.duplicate(true)
	_career = career
	_archive = preload("res://src/persistence/competition_archive_codec.gd").expand(Dictionary(session.get("archive",{})))
	set_process(false)
	_replay_athlete_id = ""
	_return_playback = {}
	_record_books = {}
	if career != null:
		_record_books.player = career.record_book.duplicate(true)
		for id in career.world_athletes: _record_books[id] = career.world_athletes[id].get("record_book",{}).duplicate(true)
	var event_key := str(session.get("event_id",session.get("event",{}).get("event_id","")))
	if event_key != _focus_event: _focus_manually_selected = false
	if not _focus_manually_selected:
		focus_skater_ids = preload("res://src/simulation/focus_skater_service.gd").select(session,career)
		_focus_event = event_key
	var event: Dictionary = Dictionary(session.get("event", {}))
	%EventTitle.text = str(event.get("name", "正式比赛"))
	var levels: Array = event.get("level_options",["junior"])
	var level := str(event.get("level","junior" if levels.has("junior") else levels[0]))
	var level_label := str({"junior":"青年组","senior":"成年组"}.get(level,level))
	var discipline := str(event.get("discipline","women_singles"))
	var discipline_label := str({"women_singles":"女子单人滑","men_singles":"男子单人滑","pairs":"双人滑","ice_dance":"冰上舞蹈"}.get(discipline,discipline))
	var category := level_label if level_label.contains(discipline_label) else level_label + discipline_label
	var start_year := int(str(event.get("start_date","0")).left(4))
	var season_year := int(event.get("ruleset_season_start_year",start_year))
	var season_label := "%d—%02d" % [season_year,(season_year+1)%100] if season_year > 0 else "本赛季"
	get_node("PreparationView/Eyebrow").text = "%s  正式%s赛事" % [season_label,level_label]
	get_node("PreparationView/Eligibility").text = "✓ 报名资格与%s年龄要求已确认" % level_label
	%EventMeta.text = "%s 至 %s  ·  %s\n%s" % [str(event.get("start_date", "日期待定")), str(event.get("end_date", event.get("start_date", ""))), str(event.get("location", "地点待定")),category]
	%RosterCount.text = "参赛阵容  %d 人  ·  完整名单已生成，比赛不会因玩家强弱动态调节" % Array(session.get("roster", [])).size()
	_opponent_contexts = []
	if career != null: _opponent_contexts = preload("res://src/presentation/opponent_context_presenter.gd").build(career,event,session.get("roster",[]))
	var familiar: Array[String] = []
	for opponent in _opponent_contexts:
		if not opponent.previous_meeting.is_empty(): familiar.append(opponent.display_name)
	if not familiar.is_empty(): %RosterCount.text = "参赛阵容 %d 人 · 再次交手：%s（名单内可查看）" % [Array(session.get("roster",[])).size(),"、".join(familiar)]
	if career != null:
		var public_event := event.duplicate(true)
		public_event.scoring_era_id = str(session.get("resolved_rules",{}).get("scoring_catalog",{}).get("scoring_era_id",""))
		var meaning := preload("res://src/presentation/career_meaning_presenter.gd").build(career,{"event":public_event,"roster":session.get("roster",[])})
		if not meaning.pre_event.is_empty():
			%RosterCount.text = "\n".join(meaning.pre_event.lines)
			%RosterCount.tooltip_text = meaning.pre_event.detail
	_build_roster(Array(session.get("roster", [])))
	selected_strategy_id = str(session.get("strategy_id", "balanced"))
	_select_strategy(selected_strategy_id, false)
	%RosterOverlay.visible = false
	%PracticeOverlay.visible = false
	%KissAndCryOverlay.visible = false
	%ProtocolOverlay.visible = false
	_archive = preload("res://src/persistence/competition_archive_codec.gd").expand(Dictionary(session.get("archive",{})))
	%BroadcastView.visible = false
	%StandingsView.visible = false
	%PreparationView.visible = true

func show_roster() -> void:
	%RosterOverlay.visible = true

func show_practice() -> void:
	var observation: Dictionary = Dictionary(_session.get("practice", {}))
	if not bool(observation.get("meaningful", false)):
		%PracticeOverlay.visible = false
		return
	%PracticeHeadline.text = str(observation.get("headline", "公开训练出现值得处理的信号"))
	_clear(%PracticeChoices)
	for raw_option in observation.get("response_options", []):
		var option: Dictionary = Dictionary(raw_option) if raw_option is Dictionary else {"id":str(raw_option), "label":_practice_label(str(raw_option))}
		var button := Button.new()
		button.text = str(option.get("label", option.get("id", "继续")))
		button.custom_minimum_size = Vector2(210, 42)
		button.pressed.connect(_practice_selected.bind(str(option.get("id", "accept"))))
		%PracticeChoices.add_child(button)
	%PracticeOverlay.visible = true

func _practice_label(id: String) -> String:
	return str({
		"replace_equipment":"立即更换冰鞋", "emergency_adjustment":"紧急调整装备", "accept_equipment_risk":"接受装备风险",
		"medical_check":"接受医疗检查", "protect_layout":"保护性降低难度", "continue_as_planned":"坚持原方案",
		"simplify_combination":"简化关键连跳", "focused_runthrough":"专项合乐训练", "keep_layout":"保持编排",
		"controlled_upgrade":"谨慎升级难度", "preserve_plan":"保留原计划",
	}.get(id, id))

func show_segment(segment_record: Dictionary) -> void:
	set_process(false)
	_segment_record = segment_record.duplicate(true)
	# Committed action calls do not change during playback. Prepare this private
	# display snapshot once, including when switching to or returning from a replay.
	_prepared_live_elements = []
	var timeline: Dictionary = load("res://src/presentation/competition_broadcast_builder.gd").build(_segment_record, 0.0, 60.0)
	for event in timeline.events: _prepared_live_elements.append(event.record)
	%BroadcastView.visible = true
	%KissAndCryOverlay.visible = false
	%OpenKissAndCryButton.visible = false
	%StandingsView.visible = false
	%PreparationView.visible = false
	var segment := str(segment_record.get("segment", "short"))
	var athlete_id := "player" if _replay_athlete_id.is_empty() else _replay_athlete_id
	var scope := "international" if str(_session.get("event",{}).get("record_eligibility","")) == "isu_recognized" else "all_formal"
	for era in _record_books.get(athlete_id,{}).get(scope,{}).values():
		var pb: Dictionary = era.get(segment,{})
		var score := float(_segment_record.get("protocol",{}).get("total",0.0))
		if float(pb.get("pb",0.0)) > 0 and score >= float(pb.pb): _segment_record.pb_candidate = true
	var name_text := "你的节目" if _replay_athlete_id.is_empty() else _athlete_name(_replay_athlete_id)
	%BroadcastTitle.text = "%s · %s" % [name_text, "短节目" if segment == "short" else "自由滑"]
	%ReturnStandingsButton.visible = not _replay_athlete_id.is_empty()
	_normal_duration = float(_session.get("resolved_rules",{}).get(segment,{}).get("segment_rules",{}).get("duration_seconds", segment_record.get("route_execution",{}).get("duration_seconds",160.0 if segment == "short" else 210.0)))
	_build_clock_windows()
	%StartPlaybackButton.set_meta("segment", segment)
	%StartPlaybackButton.disabled = false
	%CompetitionIceView.load_timeline(Dictionary(segment_record.get("route_execution", {})), _live_elements())
	%TechnicalPanel.reset_segment("短节目" if segment == "short" else "自由滑")
	%CommentaryDesk.text = "解说台  ·  选手已经进入冰面，留意她如何把准备带到这套节目里。"
	_elapsed = 0.0
	_revealed_elements = 0
	_playback_completion_emitted = false
	_confirmation_elapsed = 0.0
	playback_state = "ready"
	%PauseButton.text = "暂停"
	_set_speed(playback_speed)
	_update_layout()

func present_short_standings(rows: Array) -> void:
	if _stage_button != null: _stage_button.hide()
	set_process(false)
	_return_to_short = true
	%PreparationView.visible = false; %BroadcastView.visible = false; %StandingsView.visible = true
	%StandingsHeading.text = "短节目成绩  ·  前24名晋级自由滑"
	_build_standings(rows, true)
	var player_rows := rows.filter(func(row): return bool(row.get("is_player", false)))
	var qualified := not player_rows.is_empty() and bool(player_rows[0].get("qualified", false))
	%AdjustmentChoices.visible = qualified
	%ArchiveConfirmButton.visible = not qualified and not _archive.is_empty()

func present_final_archive(archive: Dictionary) -> void:
	set_process(false)
	_return_to_short = false
	_archive = preload("res://src/persistence/competition_archive_codec.gd").expand(archive)
	%PreparationView.visible = false; %BroadcastView.visible = false; %StandingsView.visible = true
	%StandingsHeading.text = "比赛完整档案  ·  点击任意选手查看小分表"
	var rows: Array = Array(archive.get("final_standings", [])).duplicate(true)
	var consequence: Dictionary = Dictionary(archive.get("consequence_summary", {}))
	var badges: Array[String] = []
	for raw in consequence.get("record_changes", []):
		var change: Dictionary = Dictionary(raw)
		if str(change.get("scope", "")) == "all_formal" and not badges.has(str(change.get("kind", "")).to_upper()): badges.append(str(change.get("kind", "")).to_upper())
	var event: Dictionary = _archive.get("event",{})
	if event.get("scope") == "domestic" and event.get("ranking_points_system") == "domestic":
		%ConsequenceLabel.text = "本场国内积分 +%d  ·  外赛候选观察档 %s  ·  %s" % [int(consequence.get("domestic_points_awarded", 0)), str(consequence.get("candidate_band", "待评估")), " / ".join(badges)]
	else:
		%ConsequenceLabel.text = "比赛成绩已确认；积分与派遣以赛后回执为准" + ("  ·  "+" / ".join(badges) if not badges.is_empty() else "")
	for row in rows:
		if bool(row.get("is_player", false)): row.record_badges = badges.duplicate()
	var present_ids := {}
	for row in rows: present_ids[str(row.get("athlete_id", ""))] = true
	for raw in archive.get("short_standings", []):
		if not present_ids.has(str(raw.get("athlete_id", ""))): rows.append(Dictionary(raw).duplicate(true))
	_build_standings(rows, false)
	%AdjustmentChoices.visible = false
	%ArchiveConfirmButton.visible = true
	if _stage_button == null:
		_stage_button = Button.new()
		_stage_button.name = "IceStagePreviewButton"
		_stage_button.text = "冰场舞台 · 30 秒回放"
		%ArchiveConfirmButton.get_parent().add_child(_stage_button)
		_stage_button.pressed.connect(_open_ice_stage)
	_stage_button.hide()
	for field in ["free_results","short_results"]:
		var record: Dictionary = _archive.get(field,{}).get("player",{})
		if record.get("route_source",{}).get("version") == 1 or not record.get("route_execution",{}).get("points",[]).is_empty():
			_stage_button.show()
			break

func _open_ice_stage() -> void:
	var record := _replay_record("player","free")
	if record.get("route_execution",{}).get("points",[]).is_empty(): record = _replay_record("player","short")
	if record.get("route_execution",{}).get("points",[]).is_empty(): return
	if _stage_preview == null:
		_stage_preview = preload("res://src/app/ice_stage_preview.gd").new()
		add_child(_stage_preview)
	_stage_preview.present(record)

func standing_button_for(athlete_id: String) -> Button:
	return _standing_buttons.get(athlete_id, null)

func _build_standings(rows: Array, short_only: bool) -> void:
	_clear(%StandingsList); _standing_buttons.clear()
	for raw in rows:
		var row: Dictionary = Dictionary(raw)
		var athlete_id := str(row.get("athlete_id", ""))
		var rank := int(row.get("rank", 0))
		var qualified := bool(row.get("qualified", rank <= cut_after_rank))
		var state := "晋级" if qualified else "未晋级"
		var free_text := "—" if not row.has("free_score") else "%.2f" % float(row.free_score)
		var total_text := "—" if not row.has("total_score") else "%.2f" % float(row.total_score)
		var badges := " ".join(Array(row.get("record_badges", [])))
		var button := Button.new(); button.name = "Standing_%s" % athlete_id
		button.text = "%02d  %-11s  %-4s  %-10s  SP %6.2f  FS %7s  总分 %7s  %-5s %s%s" % [rank, str(row.get("name", "")), str(row.get("federation", "")), str(row.get("club_id", "")), float(row.get("short_score", 0.0)), free_text, total_text, state, badges, "  ← 你" if bool(row.get("is_player", false)) else ""]
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT; button.custom_minimum_size = Vector2(0, 36)
		button.disabled = short_only and _archive.is_empty()
		button.pressed.connect(_open_protocol.bind(athlete_id, row))
		%StandingsList.add_child(button); _standing_buttons[athlete_id] = button

func _open_protocol(athlete_id: String, row: Dictionary) -> void:
	var protocols := {}
	var short_result: Dictionary = Dictionary(_archive.get("short_results", {}).get(athlete_id, {}))
	var free_result: Dictionary = Dictionary(_archive.get("free_results", {}).get(athlete_id, {}))
	if not short_result.is_empty(): protocols.short = _public_protocol(short_result)
	if not free_result.is_empty(): protocols.free = _public_protocol(free_result)
	%ProtocolView.present(row, protocols)
	%ProtocolOverlay.visible = true

func _public_protocol(result: Dictionary) -> Dictionary:
	var protocol: Dictionary = Dictionary(result.get("protocol", result.get("score", {}))).duplicate(true)
	var calls := {}
	for raw in result.get("technical_review", {}).get("final_elements", []): calls[str(raw.get("element_id", ""))] = Array(raw.get("info", [])).duplicate(true)
	for element in protocol.get("element_scores", []): element.info = calls.get(str(element.get("element_id", "")), [])
	return protocol

func _process(delta: float) -> void:
	if playback_state == "confirming":
		_confirmation_elapsed += delta
		if _confirmation_elapsed >= 0.6 and _kc_stage_index < 1: %KissAndCryPanel.advance_reveal(); _kc_stage_index = 1
		if _confirmation_elapsed >= 1.2 and _kc_stage_index < 2: %KissAndCryPanel.advance_reveal(); _kc_stage_index = 2
		if _confirmation_elapsed >= 1.8 and _kc_stage_index < 3: %KissAndCryPanel.advance_reveal(); _kc_stage_index = 3
		if _confirmation_elapsed >= CONFIRMATION_SECONDS:
			playback_state = "awaiting_acknowledgment"
			set_process(false)
		return
	if playback_state != "playing": return
	_advance_clock(delta * playback_speed)
	_refresh_progress()
	if _elapsed >= 1.0:
		_begin_confirmation()

func _start_playback() -> void:
	if playback_state == "ready":
		playback_requested.emit(str(%StartPlaybackButton.get_meta("segment", "short")))
		playback_state = "playing"
		set_process(true)
		%StartPlaybackButton.disabled = true

func _toggle_playback() -> void:
	if playback_state == "ready": _start_playback(); return
	if playback_state not in ["playing", "paused"]: return
	playback_state = "paused" if playback_state == "playing" else "playing"
	%PauseButton.text = "继续" if playback_state == "paused" else "暂停"
	set_process(playback_state == "playing")

func _set_speed(value: float) -> void:
	playback_speed = value
	%Speed1x.button_pressed = is_equal_approx(value, 1.0)
	%Speed15x.button_pressed = is_equal_approx(value, 1.5)
	%Speed2x.button_pressed = is_equal_approx(value, 2.0)

func _next_action() -> void:
	for raw in _segment_record.get("route_execution", {}).get("action_anchors", []):
		var target := float(raw.get("progress", 0.0))
		if target > _elapsed + 0.001:
			_elapsed = target
			_refresh_progress()
			return

func _skip_result() -> void:
	_elapsed = 1.0
	_refresh_progress()
	_finalize_technical_calls()
	playback_state = "awaiting_acknowledgment"
	_show_kiss_and_cry()
	while _kc_stage_index < 3: %KissAndCryPanel.advance_reveal(); _kc_stage_index += 1
	set_process(false)
	%CommentaryDesk.text = "解说台  ·  最终技术分与动作定级已经确认。"

func _begin_confirmation() -> void:
	playback_state = "confirming"
	_confirmation_elapsed = 0.0
	_finalize_technical_calls()
	_show_kiss_and_cry()
	%CommentaryDesk.text = "解说台  ·  技术组已确认旋转、步法定级与最终动作得分，即将公布排名。"
	set_process(true)

func _show_kiss_and_cry() -> void:
	var segment := str(_segment_record.get("segment","short"))
	var standings: Array = _session.get("short_standings",[]) if segment == "short" else _session.get("final_standings",_session.get("archive",{}).get("final_standings",[]))
	var player_rows := standings.filter(func(row): return bool(row.get("is_player",false)) or str(row.get("athlete_id","")) == "player")
	var current_rank := int(player_rows[0].get("rank",0)) if not player_rows.is_empty() else 0
	var total_score := float(player_rows[0].get("total_score",_segment_record.get("protocol",{}).get("total",0.0))) if not player_rows.is_empty() else float(_segment_record.get("protocol",{}).get("total",0.0))
	var rank_scope := "segment" if segment == "short" else ("final" if _session.get("status") == "complete" else "provisional")
	var model := preload("res://src/presentation/kiss_and_cry_builder.gd").build(_career,_segment_record,{"current_rank":current_rank,"total_score":total_score,"review_complete":true,"ranking_scope":rank_scope,"event_family":_session.get("event",{}).get("event_family","")})
	%KissAndCryPanel.setup(model); _kc_stage_index = 0; %KissAndCryOverlay.visible = true; %OpenKissAndCryButton.visible = false

func _acknowledge_score() -> void:
	if %KissAndCryPanel.reveal_stage != "final" or _playback_completion_emitted: return
	%KissAndCryOverlay.visible = false
	%OpenKissAndCryButton.visible = false
	playback_state = "complete"
	var segment := str(%StartPlaybackButton.get_meta("segment", "short"))
	score_acknowledged.emit(segment)
	_emit_playback_complete()

func _return_from_kiss_and_cry() -> void:
	%KissAndCryOverlay.visible = false
	%OpenKissAndCryButton.visible = true
	broadcast_return_requested.emit()

func _open_player_protocol_from_kc() -> void:
	var segment := str(_segment_record.get("segment", "short"))
	var row := {"athlete_id": "player", "name": "你的节目", "federation": "CHN"}
	var protocols := {}
	protocols[segment] = _public_protocol(_segment_record)
	%ProtocolView.present(row, protocols)
	%ProtocolOverlay.visible = true

func _finalize_technical_calls() -> void:
	var scores := {}
	for raw in _segment_record.get("protocol", {}).get("element_scores", []): scores[str(raw.get("element_id", ""))] = raw
	for raw in _segment_record.get("technical_review", {}).get("final_elements", []):
		var element: Dictionary = Dictionary(raw)
		var score: Dictionary = Dictionary(scores.get(str(element.get("element_id", "")), {}))
		var status := "error" if float(score.get("goe",0.0)) < 0 else str(element.get("status","success"))
		%TechnicalPanel.finalize_review(str(element.get("element_id", "")), {"abbreviation":load("res://src/presentation/competition_broadcast_builder.gd").display_abbreviation(element), "base_value":float(element.get("base_value", 0.0)), "live_goe":float(score.get("goe", 0.0)), "element_score":float(score.get("total", 0.0)), "status":status})
		%CompetitionIceView.update_element_status(str(element.get("element_id", "")), status)

func _emit_playback_complete() -> void:
	if _playback_completion_emitted: return
	_playback_completion_emitted = true
	if not _replay_athlete_id.is_empty(): return
	playback_completed.emit(str(%StartPlaybackButton.get_meta("segment", "short")))

func _reveal_due_elements() -> void:
	var elements: Array = _live_elements()
	var anchors: Array = _segment_record.get("route_execution", {}).get("action_anchors", [])
	while _revealed_elements < elements.size():
		var threshold := float(_revealed_elements + 1) / float(elements.size() + 1)
		for raw in anchors:
			if str(raw.get("element_id", "")) == str(elements[_revealed_elements].get("element_id", "")) and int(raw.get("part_index", 0)) == 0:
				threshold = float(raw.get("progress", threshold)); break
		if _elapsed + 0.0001 < threshold: return
		var record: Dictionary = Dictionary(elements[_revealed_elements]).duplicate(true)
		if not record.has("element_score"): record.element_score = snappedf(float(record.get("base_value", 0.0)) + float(record.get("live_goe", 0.0)), 0.01)
		%TechnicalPanel.push_element(record)
		if str(record.get("status", "")) == "review": %CommentaryDesk.text = "解说台  ·  %s进入技术组复核，最终符号与分值稍后确认。" % str(record.get("abbreviation", "该动作"))
		elif str(record.get("status", "")) == "error": %CommentaryDesk.text = "解说台  ·  %s的完成质量受到扣分，负GOE并不一定代表摔倒。" % str(record.get("abbreviation", "该动作"))
		if record.has("turning_point"):
			var phrases := {"repetition_invalid":"这个跳跃重复失效，完成漂亮也不能消除重复规则。","lost_combination":"这次连跳中断，能否补回要看后续实际动作。","recovered_combination":"她在后面的跳跃接上连跳，补回了追加跳跃。","late_completion":"进入节目后半段，她仍完成了这个跳跃。"}
			%CommentaryDesk.text = "解说台  ·  "+str(phrases.get(record.turning_point.kind,""))
		if record.has("meaning_cue"): %CommentaryDesk.text = "解说台  ·  "+str(record.meaning_cue)
		_revealed_elements += 1

func _live_elements() -> Array:
	return _prepared_live_elements

func _select_strategy(strategy_id: String, emit_signal := true) -> void:
	selected_strategy_id = strategy_id
	%SafeStrategyButton.button_pressed = strategy_id == "safe"
	%BalancedStrategyButton.button_pressed = strategy_id == "balanced"
	%AttackStrategyButton.button_pressed = strategy_id == "attack"
	if emit_signal: strategy_selected.emit(strategy_id)

func _practice_selected(response_id: String) -> void:
	%PracticeOverlay.visible = false
	practice_response_selected.emit(response_id)

func _build_roster(roster: Array) -> void:
	_clear(%RosterList)
	var memories: Array[String] = []
	for opponent in _opponent_contexts:
		if not opponent.previous_meeting.is_empty(): memories.append(opponent.display_name+" · "+opponent.reason)
	if not memories.is_empty():
		var memory := Label.new()
		memory.name = "OpponentMemories"
		memory.text = "\n".join(memories)
		memory.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		%RosterList.add_child(memory)
	for index in roster.size():
		var entrant: Dictionary = Dictionary(roster[index])
		var row := HBoxContainer.new()
		var id := str(entrant.get("athlete_id",""))
		var label := CheckBox.new()
		label.text = "%02d  %s  %s%s" % [index + 1, str(entrant.get("name","未命名选手")), str(entrant.get("federation","")), "  ← 你" if bool(entrant.get("is_player",false)) else ""]
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.button_pressed = focus_skater_ids.has(id)
		label.disabled = bool(entrant.get("is_player",false))
		label.toggled.connect(func(enabled): set_focus_skater(id,enabled))
		row.add_child(label)
		for segment in ["short","free"]:
			var button := Button.new()
			button.text = "观看短节目" if segment == "short" else "观看自由滑"
			button.disabled = _replay_record(id,segment).is_empty()
			button.pressed.connect(func(): set_focus_skater(id,true); show_replay(id,segment))
			row.add_child(button)
		row.custom_minimum_size = Vector2(0, 30)
		row.add_theme_font_size_override("font_size", 15)
		%RosterList.add_child(row)

func set_focus_skater(athlete_id: String, enabled: bool) -> void:
	_focus_manually_selected = true
	if enabled and not focus_skater_ids.has(athlete_id): focus_skater_ids.append(athlete_id)
	elif not enabled: focus_skater_ids.erase(athlete_id)

func _replay_record(athlete_id: String, segment: String) -> Dictionary:
	if segment not in ["short","free"]: return {}
	# Archive is authoritative; live locked SP records are available before FS exists.
	return preload("res://src/persistence/competition_archive_codec.gd").replay_record(Dictionary(_archive.get(segment+"_results",_session.get(segment+"_results",{})).get(athlete_id,{})))

func show_replay(athlete_id: String, segment: String) -> bool:
	if athlete_id != "player" and not focus_skater_ids.has(athlete_id): return false
	var record := _replay_record(athlete_id,segment)
	if record.is_empty(): return false
	if _replay_athlete_id.is_empty() and %BroadcastView.visible:
		_return_playback = {"record":_segment_record.duplicate(true),"elapsed":_elapsed,"state":playback_state,"completion":_playback_completion_emitted,"speed":playback_speed,"confirmation_elapsed":_confirmation_elapsed,"kc_stage_index":_kc_stage_index,"kc_visible":%KissAndCryOverlay.visible,"kc_button_visible":%OpenKissAndCryButton.visible}
	_replay_athlete_id = athlete_id
	%RosterOverlay.visible = false
	record.segment = segment
	show_segment(record)
	return true

func _return_from_replay() -> void:
	_replay_athlete_id = ""
	if not _return_playback.is_empty():
		var previous := _return_playback.duplicate(true)
		_return_playback = {}
		show_segment(previous.record)
		_elapsed = previous.elapsed
		_refresh_progress()
		_set_speed(previous.speed)
		playback_state = "paused" if previous.state in ["playing","paused"] else str(previous.state)
		%PauseButton.text = "继续" if playback_state == "paused" else "暂停"
		_playback_completion_emitted = previous.completion
		if playback_state in ["confirming","awaiting_acknowledgment","complete"]: _finalize_technical_calls()
		if playback_state in ["confirming","awaiting_acknowledgment"]:
			_show_kiss_and_cry()
			while _kc_stage_index < int(previous.get("kc_stage_index",0)):
				%KissAndCryPanel.advance_reveal()
				_kc_stage_index += 1
			_confirmation_elapsed = float(previous.get("confirmation_elapsed",0.0))
			%KissAndCryOverlay.visible = bool(previous.get("kc_visible",true))
			%OpenKissAndCryButton.visible = bool(previous.get("kc_button_visible",false))
		set_process(playback_state == "confirming")
		return
	if _return_to_short: present_short_standings(_session.get("short_standings",[]))
	elif not _archive.is_empty(): present_final_archive(_archive)
	else:
		set_process(false)
		%BroadcastView.visible = false
		%PreparationView.visible = true

func _athlete_name(id: String) -> String:
	for row in _session.get("roster",[]):
		if str(row.get("athlete_id","")) == id: return str(row.get("name",id))
	return id

func set_playback_mode(mode: String) -> void:
	playback_mode = "quick" if mode == "quick" else "normal"
	_build_clock_windows()
	_refresh_clock()

func playback_duration_seconds(mode: String, rules: Dictionary) -> float:
	var duration := float(rules.get("duration_seconds",_normal_duration))
	return clampf(duration * 0.42,55.0,110.0) if mode == "quick" else duration

func _build_clock_windows() -> void:
	_clock_windows.clear()
	var phases: Array = _segment_record.get("route_execution",{}).get("action_phases",[])
	var cursor := 0.0
	var action_fraction := 0.0
	for phase in phases:
		if str(phase.get("kind","")) == "approach": continue
		var start := maxf(cursor,float(phase.start)); var end := maxf(start,float(phase.end))
		if start > cursor: _clock_windows.append({"start":cursor,"end":start,"action":false})
		_clock_windows.append({"start":start,"end":end,"action":true,"element_id":str(phase.get("element_id",""))})
		action_fraction += end-start
		cursor = end
	if cursor < 1.0: _clock_windows.append({"start":cursor,"end":1.0,"action":false})
	var quick_target := playback_duration_seconds("quick",{"duration_seconds":_normal_duration})/_normal_duration
	# Dense programs may exceed the 42% target: action time always wins, travel keeps 5%.
	var travel_ratio := maxf(0.05,(quick_target-action_fraction)/maxf(0.001,1.0-action_fraction))
	for window in _clock_windows: window.seconds_per_progress = _normal_duration * (travel_ratio if playback_mode == "quick" and not window.action else 1.0)

func _advance_clock(seconds: float) -> void:
	for window in _clock_windows:
		if _elapsed >= float(window.end): continue
		var scale := float(window.seconds_per_progress)
		if auto_slow_enabled and window.action and _slow_candidate(str(window.get("element_id",""))): scale *= 2.0
		var needed := (float(window.end)-_elapsed)*scale
		if seconds < needed:
			_elapsed += seconds/scale
			return
		_elapsed = float(window.end)
		seconds -= needed
	_elapsed = 1.0

func _slow_candidate(element_id: String) -> bool:
	var elements: Array = _segment_record.get("performance",{}).get("elements",[])
	if bool(_segment_record.get("pb_candidate",false)) and not elements.is_empty() and str(elements.back().get("element_id","")) == element_id: return true
	for record in _live_elements():
		if str(record.get("element_id","")) != element_id: continue
		if record.get("status","") == "review" or bool(record.get("actual",{}).get("fall",false)): return true
		for final in _segment_record.get("technical_review",{}).get("final_elements",[]):
			if str(final.get("element_id","")) == element_id and final.has("final_level") and absi(int(final.final_level)-int(record.get("facts",{}).get("attempted_features",final.final_level))) >= 2: return true
	return false

func _clock_text(seconds: float) -> String:
	return "%d:%02d" % [int(seconds)/60,int(seconds)%60]

func _refresh_progress() -> void:
	%CompetitionIceView.set_progress(_elapsed)
	_reveal_due_elements()
	_refresh_clock()

func _refresh_clock() -> void:
	%ClockLabel.text = "%s / %s  ·  %s" % [_clock_text(_elapsed*_normal_duration),_clock_text(_normal_duration),"快速" if playback_mode == "quick" else "实时时长"]

func _update_layout() -> void:
	if not is_node_ready(): return
	var narrow := size.x < 1000
	%Stage.vertical = false
	%IceShell.custom_minimum_size = Vector2(0,220 if narrow else 340)
	%TechnicalPanel.custom_minimum_size = Vector2(300,180)
	%BroadcastLegend.visible = not narrow
	%ControlHint.visible = not narrow
	%Speed15x.visible = not narrow
	%QuickButton.visible = not narrow
	%AutoSlowButton.visible = not narrow
	%FocusButton.visible = not narrow
	%CommentaryDesk.custom_minimum_size = Vector2(0,38 if narrow else 56)
	add_theme_constant_override("margin_top",10 if narrow else 22)
	add_theme_constant_override("margin_bottom",10 if narrow else 36)
	_refresh_clock()

func _clear(node: Node) -> void:
	for child in node.get_children(): child.free()

