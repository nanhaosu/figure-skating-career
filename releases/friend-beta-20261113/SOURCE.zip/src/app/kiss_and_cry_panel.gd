class_name KissAndCryPanel
extends PanelContainer

signal reveal_completed
signal continue_requested
signal view_protocol_requested
signal return_requested
signal main_menu_requested

var reveal_stage := "waiting"
var view_model: Dictionary = {}

func _ready() -> void:
	%AdvanceButton.pressed.connect(advance_reveal)
	%ContinueButton.pressed.connect(func(): continue_requested.emit())
	%ProtocolButton.pressed.connect(func(): view_protocol_requested.emit())
	%ReturnButton.pressed.connect(func(): return_requested.emit())
	%MainMenuButton.pressed.connect(func(): main_menu_requested.emit())

func setup(model: Dictionary) -> void:
	view_model = model.duplicate(true); reveal_stage = "waiting"
	%AthleteReaction.text = str(model.get("athlete_reaction","运动员正在等待分数。")); %CoachReaction.text = str(model.get("coach_reaction","教练在身边。"))
	%ReviewStatus.text = "技术组正在确认 %d 个动作" % int(model.get("pending_reviews",0))
	%TesValue.text = "TES  %.2f" % float(model.get("tes",0.0)); %PcsValue.text = "PCS  %.2f  ·  扣分 -%.2f" % [float(model.get("pcs",0.0)),float(model.get("deductions",0.0))]
	%SegmentScore.text = "本段  %.2f" % float(model.get("segment_score",0.0)); %TotalScore.text = "总分  %.2f" % float(model.get("total_score",0.0))
	%Rank.text = str(model.get("rank_label","当前第 %d 名" % int(model.get("current_rank",0)) if int(model.get("current_rank",0)) > 0 else "排名等待确认"))
	%ScoreBlock.visible = false; %TesValue.visible = false; %PcsValue.visible = false; %FinalBlock.visible = false; %FinalActions.visible = false; %ContinueButton.visible = false; %AdvanceButton.visible = true

func advance_reveal() -> void:
	if reveal_stage == "waiting": reveal_stage = "technical_confirmed"; %ScoreBlock.visible = true; %TesValue.visible = true; %ReviewStatus.text = "技术分已确认"
	elif reveal_stage == "technical_confirmed": reveal_stage = "components_confirmed"; %PcsValue.visible = true; %ReviewStatus.text = "节目内容分已确认"
	elif reveal_stage == "components_confirmed":
		reveal_stage = "final"; %FinalBlock.visible = true; %FinalActions.visible = true; %ContinueButton.visible = true; %AdvanceButton.visible = false; %AthleteReaction.text = str(view_model.get("revealed_athlete_reaction",view_model.get("athlete_reaction",""))); reveal_completed.emit()
