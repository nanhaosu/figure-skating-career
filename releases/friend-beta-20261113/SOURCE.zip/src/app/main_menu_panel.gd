class_name MainMenuPanel
extends Control

signal continue_requested(slot_id: String)
signal new_career_requested
signal load_requested
signal settings_requested

var _continue_slot_id := ""

@onready var continue_button: Button = %ContinueButton
@onready var new_career_button: Button = %NewCareerButton
@onready var load_button: Button = %LoadButton
@onready var settings_button: Button = %SettingsButton
@onready var career_summary: Label = %CareerSummary
@onready var status_text: Label = %StatusText

func _ready() -> void:
	continue_button.pressed.connect(func():
		if not _continue_slot_id.is_empty(): continue_requested.emit(_continue_slot_id))
	new_career_button.pressed.connect(func(): new_career_requested.emit())
	load_button.pressed.connect(func(): load_requested.emit())
	settings_button.pressed.connect(func(): settings_requested.emit())

func present(slots: Array) -> void:
	_continue_slot_id = ""
	var latest: Dictionary = {}
	var has_unreadable := false
	for slot in slots:
		if str(slot.get("status", "")) == "unreadable":
			has_unreadable = true
			continue
		if str(slot.get("status", "")) != "saved" or str(slot.get("athlete", "")).is_empty():
			continue
		if latest.is_empty() or int(slot.get("saved_at_unix", 0)) > int(latest.get("saved_at_unix", 0)):
			latest = slot
	continue_button.disabled = latest.is_empty()
	if latest.is_empty():
		career_summary.text = "没有可继续的生涯"
	else:
		_continue_slot_id = str(latest.get("id", ""))
		var clock: Dictionary = Dictionary(latest.get("clock", {}))
		career_summary.text = "%s\n%d年 · 第%d季度" % [str(latest.get("athlete", "未命名选手")), int(clock.get("year", 0)), int(clock.get("quarter", 1))]
	status_text.text = "有存档无法读取；你仍可新建生涯或读取其他存档。" if has_unreadable else "选择一条明确的入口开始。"
