class_name PrimaryActionCard
extends PanelContainer

signal action_requested(action_id: String)

var action_id := ""

func present(data: Dictionary) -> void:
	action_id = str(data.get("id",""))
	get_node("Margin/Content/Detail").text = str(data.get("detail",""))
	get_node("Margin/Content/PrimaryAction").text = str(data.get("label","继续"))

func _ready() -> void:
	get_node("Margin/Content/PrimaryAction").pressed.connect(func(): action_requested.emit(action_id))
