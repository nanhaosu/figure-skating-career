class_name StatusPill
extends PanelContainer

func present(label_text: String, value_text: String) -> void:
	get_node("Margin/Content/Label").text = label_text
	get_node("Margin/Content/Value").text = value_text
