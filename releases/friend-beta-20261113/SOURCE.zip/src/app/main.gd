extends Control

signal onboarding_state_saved(stage: String, ok: bool)

const CareerState = preload("res://src/domain/career_state.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")
const QuarterPanelScript = preload("res://src/app/quarter_panel.gd")
const CareerHomePanelScript = preload("res://src/app/career_home_panel.gd")
const SummaryPanelScript = preload("res://src/app/summary_panel.gd")
const InternalCompetitionSimulator = preload("res://src/simulation/internal_competition_simulator.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const SeasonCalendarPlanner = preload("res://src/simulation/season_calendar_planner.gd")
const CareerCommandService = preload("res://src/simulation/career_command_service.gd")
const FormalCompetitionSimulator = preload("res://src/simulation/formal_competition_simulator.gd")
const ProgramDraftService = preload("res://src/simulation/program_draft_service.gd")
const ProgramRevisionService = preload("res://src/simulation/program_revision_service.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const MusicCatalogRepository = preload("res://src/content/music_catalog_repository.gd")
const InternalInvitationService = preload("res://src/simulation/internal_invitation_service.gd")
const MilestoneAdvanceService = preload("res://src/simulation/milestone_advance_service.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const ThemeFactory = preload("res://src/app/theme_factory.gd")
const OnboardingService = preload("res://src/app/onboarding_service.gd")
const CoachHandoffPresenter = preload("res://src/presentation/coach_handoff_presenter.gd")
const ScreenRoute = preload("res://src/app/screen_route.gd")
const CareerScreenRouter = preload("res://src/app/career_screen_router.gd")

const SAVE_PATH := "user://saves/manual-1.json"
const AUTOSAVE_PATH := "user://saves/autosave.json"
var browser_saves = preload("res://src/persistence/browser_save_service.gd").new()

var active_career: CareerState
var catalog: Dictionary = {}
var has_unsaved_changes := false
var save_path := SAVE_PATH
var autosave_path := AUTOSAVE_PATH
var _pending_new_career: CareerState
var _persistence_wait: Window
var _persistence_suspended_windows: Array[WeakRef] = []
var _persistence_progress_label: Label
var _persistence_progress_bar: ProgressBar
var _viewing_archive := false
var _pending_program_event_id := ""
var _pending_registration_tutorial: Dictionary = {}
var screen_router = CareerScreenRouter.new(["career_home", "training", "programs", "season", "records", "relationships", "health","repertoire", "summary", "save_manager", "formal_archive"])
var health_panel: Control
var repertoire_panel: Control
var _decision_dialog: Window
var _information_dialog: Window
var _decision_busy := false
var _season_planning_draft: Dictionary = {}
var _season_editing := false
var _auto_advance_running := false
var _auto_advance_continue := false
var _auto_overlay

@onready var creation_screen: Control = %CreationScreen
@onready var creation_panel: CreationPanel = %CreationPanel
@onready var career_home_panel: CareerHomePanelScript = %CareerHomePanel
@onready var pre_career_history_panel: Control = %PreCareerHistoryPanel
@onready var coach_handoff_panel: Control = %CoachHandoffPanel
@onready var quarter_panel: QuarterPanelScript = %QuarterPanel
@onready var summary_panel: SummaryPanelScript = %SummaryPanel
@onready var competition_panel: Control = %CompetitionPanel
@onready var season_overview_panel: Control = %SeasonOverviewPanel
@onready var formal_competition_panel: Control = %FormalCompetitionPanel
@onready var program_editor_panel: Control = %ProgramEditorPanel
@onready var load_button: Button = %LoadButton
@onready var global_message: Label = %GlobalMessage
@onready var new_career_confirmation: ConfirmationDialog = %NewCareerConfirmation
@onready var onboarding_overlay: Control = %OnboardingOverlay
@onready var main_menu_panel: Control = %MainMenuPanel
@onready var career_shell_panel: Control = %CareerShellPanel
@onready var career_reference_panel: Control = %CareerReferencePanel

func _enter_tree() -> void:
	catalog = CatalogRepository.load_catalog()
	var embedded_creation_panel = get_node_or_null("CreationScreen/CreationPanel")
	if embedded_creation_panel != null:
		embedded_creation_panel.catalog = catalog

func _ready() -> void:
	theme = ThemeFactory.create()
	browser_saves.busy_changed.connect(_set_persistence_pending)
	browser_saves.load_progress.connect(_set_persistence_progress)
	%SaveManagerButton.pressed.connect(func(): %SaveManagerPanel.present(browser_saves,active_career))
	%SaveManagerPanel.career_saved.connect(func(id):
		if id != "autosave": save_path = browser_saves.slot_path(id)
		has_unsaved_changes = false)
	%SaveManagerPanel.career_loaded.connect(func(career, id):
		active_career = career
		save_path = browser_saves.slot_path(id)
		has_unsaved_changes = false
		_open_loaded_career())
	get_viewport().get_window().title = "花样滑冰生涯"
	creation_panel.career_created.connect(offer_new_career)
	main_menu_panel.continue_requested.connect(_on_menu_continue_requested)
	main_menu_panel.new_career_requested.connect(_offer_skating_intro)
	%CreationBackButton.pressed.connect(show_main_menu)
	main_menu_panel.load_requested.connect(func(): %SaveManagerPanel.present(browser_saves, active_career))
	main_menu_panel.settings_requested.connect(func(): _present_skating_guide())
	main_menu_panel.settings_button.text = "花滑入门与帮助"
	career_shell_panel.navigation_requested.connect(_on_shell_navigation_requested)
	career_reference_panel.archive_requested.connect(open_archived_competition)
	career_shell_panel.save_manager_requested.connect(func(): %SaveManagerPanel.present(browser_saves, active_career))
	career_shell_panel.main_menu_requested.connect(exit_to_main_menu)
	pre_career_history_panel.continued.connect(_on_pre_career_history_continued)
	pre_career_history_panel.main_menu_requested.connect(exit_to_main_menu)
	coach_handoff_panel.goal_confirmed.connect(_on_career_goal_confirmed)
	coach_handoff_panel.main_menu_requested.connect(exit_to_main_menu)
	career_home_panel.action_requested.connect(_on_home_action_requested)
	quarter_panel.quarter_advanced.connect(_on_quarter_advanced)
	quarter_panel.training_period_completed.connect(_on_training_period_completed)
	quarter_panel.persist = func(candidate):
		var saved: Dictionary = await _save_career(candidate,autosave_path)
		if saved.ok: _set_message("训练进度与安排已保存")
		return saved
	quarter_panel.advance_blocked.connect(_present_season_node)
	quarter_panel.persistence_failed.connect(func(): _set_message("保存失败，进度未变更",true))
	quarter_panel.program_requested.connect(open_program_editor)
	quarter_panel.program_upgrade_requested.connect(_review_program_upgrade)
	quarter_panel.internal_competition_requested.connect(func(): start_internal_competition())
	quarter_panel.internal_competition_deferred.connect(_on_internal_competition_deferred)
	quarter_panel.training_after_defer_requested.connect(func():
		await _on_internal_competition_deferred()
		if active_career != null and active_career.internal_invitation_state.get("status") == "deferred":
			await quarter_panel.continue_training())
	program_editor_panel.program_saved.connect(_on_program_saved)
	program_editor_panel.closed.connect(_close_program_editor)
	var guide_button := Button.new()
	guide_button.name = "SkatingGuideButton"
	guide_button.text = "看懂动作与规则"
	guide_button.pressed.connect(func(): _present_skating_guide(2))
	program_editor_panel.close_button.get_parent().add_child(guide_button)
	summary_panel.next_quarter_requested.connect(open_next_quarter)
	summary_panel.home_requested.connect(_open_player_home)
	summary_panel.milestone_advance_requested.connect(_on_milestone_advance_requested)
	summary_panel.save_requested.connect(save_active_career)
	summary_panel.key_node_response_requested.connect(_on_key_node_response)
	summary_panel.main_menu_requested.connect(return_to_main_menu)
	load_button.pressed.connect(load_active_career_responsive)
	new_career_confirmation.confirmed.connect(confirm_new_career_replacement)
	new_career_confirmation.canceled.connect(func(): _pending_new_career = null)
	new_career_confirmation.get_ok_button().theme_type_variation = "DangerButton"
	new_career_confirmation.get_cancel_button().theme_type_variation = "SecondaryButton"
	new_career_confirmation.dialog_autowrap = true
	onboarding_overlay.dismissed.connect(_on_onboarding_dismissed)
	competition_panel.segment_completed.connect(_on_competition_segment_completed)
	competition_panel.adjustment_selected.connect(_on_competition_adjustment_selected)
	competition_panel.competition_confirmed.connect(_on_competition_confirmed)
	competition_panel.main_menu_requested.connect(exit_to_main_menu)
	season_overview_panel.entry_adjustment_requested.connect(_on_season_entry_adjustment_requested)
	season_overview_panel.birth_date_requested.connect(_present_birth_date)
	season_overview_panel.adjustment_selected.connect(_on_season_adjustment_selected)
	season_overview_panel.domestic_schedule_requested.connect(_on_domestic_schedule_requested)
	season_overview_panel.domestic_schedule_selected.connect(_on_domestic_schedule_selected)
	season_overview_panel.target_selected.connect(_on_season_target_selected)
	season_overview_panel.preparation_requested.connect(_on_preparation_route_selected)
	season_overview_panel.auto_advance_requested.connect(_on_season_auto_advance_requested)
	season_overview_panel.advance_requested.connect(_on_season_advance_requested)
	season_overview_panel.event_launch_requested.connect(_on_formal_event_launch_requested)
	season_overview_panel.pre_competition_action_requested.connect(_on_pre_competition_action_requested)
	season_overview_panel.archive_view_requested.connect(open_archived_competition)
	formal_competition_panel.strategy_selected.connect(_on_formal_strategy_selected)
	formal_competition_panel.practice_response_selected.connect(_on_formal_practice_response_selected)
	formal_competition_panel.playback_completed.connect(_on_formal_playback_completed)
	formal_competition_panel.main_menu_requested.connect(exit_to_main_menu)
	formal_competition_panel.adjustment_selected.connect(_on_formal_adjustment_selected)
	formal_competition_panel.archive_confirmed.connect(_on_formal_archive_confirmed)
	_mount_career_content()
	for kind in ["health","repertoire"]:
		var panel = preload("res://src/app/career_detail_panel.gd").new()
		panel.name = "HealthPanel" if kind == "health" else "RepertoirePanel"
		career_shell_panel.content_host.add_child(panel)
		panel.close_requested.connect(back_route)
		panel.action_requested.connect(func(action_id: String):
			if action_id.begins_with("reassess:"):
				var id := action_id.trim_prefix("reassess:")
				var offered := preload("res://src/simulation/rehabilitation_service.gd").options(active_career,id)
				_present_treatment({"injury_id":id,"reason":"可以选择继续安全训练，或暂停高冲击训练，申请更长周期的完整康复。","treatment":offered,"choices":offered.routes}))
		panel.hide()
		if kind == "health": health_panel = panel
		else: repertoire_panel = panel
	show_main_menu()
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--internal-demo-path="):
			var demo_path := argument.trim_prefix("--internal-demo-path=")
			save_path = demo_path
			autosave_path = "%s.autosave" % demo_path
			_load_career_from(demo_path)
			return
		if argument.begins_with("--formal-demo-path="):
			var formal_demo_path := argument.trim_prefix("--formal-demo-path=")
			save_path = formal_demo_path
			autosave_path = "%s.autosave" % formal_demo_path
			_load_career_from(formal_demo_path)
			return

func show_main_menu() -> void:
	main_menu_panel.present(browser_saves.list_slots())
	_show_screen(main_menu_panel)
	_set_message("")

func _on_menu_continue_requested(slot_id: String) -> void:
	await load_active_career_responsive(browser_saves.slot_path(slot_id))

func _mount_career_content() -> void:
	for panel in [career_home_panel, quarter_panel, summary_panel, season_overview_panel, program_editor_panel, career_reference_panel]:
		panel.reparent(career_shell_panel.content_host)
		panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _on_shell_navigation_requested(screen_id: String) -> void:
	match screen_id:
		"career_home": _open_player_home()
		"training": open_next_quarter()
		"programs": open_program_editor("short")
		"season": _open_career_home()
		"records", "relationships","health","repertoire": open_route(screen_id, {}, screen_router.current())

func open_route(screen_id: String, context: Dictionary = {}, return_route: Dictionary = {}) -> void:
	var route := ScreenRoute.create(screen_id, context, return_route)
	screen_router.open(route, ScreenRoute.create("career_home"))
	_render_current_route()

func back_route() -> void:
	screen_router.back()
	_render_current_route()

func _render_current_route() -> void:
	var route := screen_router.current()
	match str(route.get("screen_id", "career_home")):
		"health","repertoire":
			var detail_panel = health_panel if route.screen_id == "health" else repertoire_panel
			var presenter = preload("res://src/presentation/health_presenter.gd") if route.screen_id == "health" else preload("res://src/presentation/repertoire_presenter.gd")
			detail_panel.present(presenter.build(active_career))
			_show_screen(detail_panel)
		"career_home":
			career_home_panel.present(active_career)
			_show_screen(career_home_panel)
		"training": _show_screen(quarter_panel)
		"programs": _show_screen(program_editor_panel)
		"season": _show_screen(season_overview_panel)
		"summary": _show_screen(summary_panel)
		"records", "relationships":
			career_reference_panel.present(active_career, str(route.screen_id))
			_show_screen(career_reference_panel)
		_:
			screen_router.replace(ScreenRoute.create("career_home"))
			career_home_panel.present(active_career)
			_show_screen(career_home_panel)

func exit_to_main_menu() -> void:
	if active_career != null and competition_panel.visible and not active_career.competition_state.is_empty() and str(active_career.competition_state.get("kind","")) != "formal":
		var was_processing := competition_panel.is_processing()
		competition_panel.set_process(false)
		var working := active_career.transaction_copy()
		working.competition_state.playback_checkpoint = competition_panel.playback_checkpoint()
		var saved := await _persist_candidate(working,autosave_path)
		if not saved.ok:
			competition_panel.set_process(was_processing)
			return
	if active_career != null and has_unsaved_changes:
		var result := await _save_career(active_career, autosave_path)
		if not result.ok:
			_set_message("保存失败，仍停留在当前页面：%s" % "；".join(result.errors), true)
			return
		has_unsaved_changes = false
	show_main_menu()

func offer_new_career(career: CareerState) -> void:
	var existing_autosave := FileAccess.file_exists(autosave_path)
	if existing_autosave or (active_career != null and has_unsaved_changes):
		_pending_new_career = career
		new_career_confirmation.dialog_text = "已有自动存档。新生涯第一次保存时会替换它，手动存档不会受影响。\n如需保留，请先取消并到存档管理中另存。是否开始新生涯？" if existing_autosave else "当前生涯有未保存的变化。\n创建新生涯会替换这些变化，是否继续？"
		new_career_confirmation.popup_centered(Vector2i(560, 220))
		return
	_activate_new_career(career)

func confirm_new_career_replacement() -> void:
	if _pending_new_career == null:
		return
	new_career_confirmation.hide()
	_activate_new_career(_pending_new_career)

func open_next_quarter() -> void:
	if active_career == null:
		return
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(active_career)
	var node := preload("res://src/simulation/season_progression_service.gd").training_entry_gate(active_career,bundle)
	if not node.is_empty() and not node.kind in ["training_decision","internal_invitation"]:
		_present_season_node(node)
		return
	quarter_panel.setup(active_career, catalog)
	screen_router.replace(ScreenRoute.create("training"))
	_show_screen(quarter_panel)
	_set_message("")
	_maybe_show_onboarding("training")

func _on_key_node_response(node_id: String) -> void:
	var result := preload("res://src/simulation/career_command_service.gd").apply(active_career, {"type":"resolve_key_node", "node_id":node_id, "response_id":"acknowledge"})
	if not result.ok:
		summary_panel.show_message(result.error, true)
		return
	var saved := await _save_career(result.career, autosave_path)
	if not saved.ok:
		summary_panel.show_message("保存失败，请重试该决定：%s" % "；".join(saved.errors),true)
		return
	active_career = result.career
	_viewing_archive = false
	has_unsaved_changes = false
	summary_panel.present(active_career, [])

func return_to_main_menu() -> void:
	await exit_to_main_menu()

func save_active_career() -> Dictionary:
	var result := await _save_career(active_career, save_path)
	if result.ok:
		has_unsaved_changes = false
		_set_message("已保存到 %s" % save_path)
		if summary_panel.visible:
			summary_panel.show_message("已保存到 %s" % save_path)
	else:
		var error_text := "\n".join(result.errors)
		_set_message(error_text, true)
		if summary_panel.visible:
			summary_panel.show_message(error_text, true)
	return result

func load_active_career() -> Dictionary:
	return _load_career_from(save_path)

func load_active_career_responsive(path: String = "") -> Dictionary:
	var target_path := save_path if path.is_empty() else path
	var result: Dictionary
	var matched_slot := ""
	for id in browser_saves.IDS:
		if target_path == browser_saves.slot_path(id):
			matched_slot = id
			break
	if not matched_slot.is_empty():
		result = await browser_saves.load_slot(matched_slot)
	else:
		_set_persistence_pending(true)
		result = await SaveRepository.load_save_responsive(target_path,_set_persistence_progress)
		_set_persistence_pending(false)
	if not result.ok:
		var error_text := "\n".join(result.errors)
		_set_message(error_text,true)
		if summary_panel.visible: summary_panel.show_message(error_text,true)
		return result
	active_career = result.career
	_viewing_archive = false
	has_unsaved_changes = false
	_pending_new_career = null
	_open_loaded_career()
	_set_message("已读取 %s" % target_path)
	return result

func _save_career(career, path: String) -> Dictionary:
	if browser_saves.busy: return {"ok":false,"errors":["正在等待持久化确认，请稍后重试"]}
	for id in browser_saves.IDS:
		if path == browser_saves.slot_path(id):
			_set_persistence_pending(true)
			var result: Dictionary = await browser_saves.save_slot(id,career)
			_set_persistence_pending(false)
			return result
	return SaveRepository.save(career,path)

func _set_persistence_pending(pending: bool) -> void:
	if pending:
		# A storage acknowledgement may be requested from an existing decision
		# window. Godot permits only one exclusive sibling. Keep the decision
		# visible (and recoverable on save failure), but give the wait sole input.
		for child in find_children("*","Window",true,false):
			if child != _persistence_wait and child.visible and child.exclusive:
				_persistence_suspended_windows.append(weakref(child))
				child.exclusive = false
		if _persistence_wait == null:
			_persistence_wait = Window.new()
			_persistence_wait.hide()
			_persistence_wait.name = "PersistenceWait"
			_persistence_wait.title = "正在读取或确认本机存档"
			_persistence_wait.exclusive = true
			_persistence_wait.unresizable = true
			var surface := PanelContainer.new()
			surface.name = "ContentSurface"
			surface.mouse_filter = Control.MOUSE_FILTER_IGNORE
			surface.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			_persistence_wait.add_child(surface)
			var margin := MarginContainer.new()
			margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_" + side,24)
			var column := VBoxContainer.new()
			column.add_theme_constant_override("separation",12)
			margin.add_child(column)
			_persistence_progress_label = Label.new()
			_persistence_progress_label.text = "正在读取或等待存储确认，请勿关闭页面……"
			_persistence_progress_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			column.add_child(_persistence_progress_label)
			_persistence_progress_bar = ProgressBar.new()
			_persistence_progress_bar.min_value = 0
			_persistence_progress_bar.max_value = 100
			_persistence_progress_bar.value = 0
			_persistence_progress_bar.show_percentage = true
			column.add_child(_persistence_progress_bar)
			var hint := Label.new()
			hint.text = "大型旧存档首次载入可能需要十几秒；完成整理后，后续日常读写会明显加快。"
			hint.modulate = Color(0.72,0.76,0.84)
			hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			column.add_child(hint)
			_persistence_wait.add_child(margin)
			add_child(_persistence_wait)
		if not _persistence_wait.visible:
			_persistence_progress_label.text = "正在读取或等待存储确认，请勿关闭页面……"
			_persistence_progress_bar.value = 0
			_persistence_wait.popup_centered(Vector2i(560,170))
	else:
		if _persistence_wait != null: _persistence_wait.hide()
		for reference in _persistence_suspended_windows:
			var child = reference.get_ref()
			if child != null: child.exclusive = true
		_persistence_suspended_windows.clear()

func _set_persistence_progress(report: Dictionary) -> void:
	if _persistence_progress_label == null or _persistence_progress_bar == null: return
	var stage := str(report.get("stage",""))
	var messages := {
		"reading":"正在读取存档文件……",
		"schema":"正在检查存档结构……",
		"career":"正在整理生涯数据……",
		"constructing":"正在建立可游玩的生涯……",
		"complete":"载入完成",
		"save_preparing":"正在准备本次进度……",
		"save_validating":"正在检查生涯与比赛记录……",
		"save_checking":"正在检查存档数值……",
		"save_normalizing":"正在整理生涯数据……",
		"save_encoding":"正在生成存档……",
		"save_writing":"正在写入本机存档……",
		"save_acknowledging":"正在等待浏览器确认保存……",
		"save_complete":"保存完成",
	}
	if stage == "archives":
		_persistence_progress_label.text = "正在验证历史比赛 %d / %d……" % [int(report.get("current",0)),int(report.get("total",0))]
	else:
		_persistence_progress_label.text = messages.get(stage,"正在安全载入存档……")
	_persistence_progress_bar.value = int(report.get("percent",0))

func _persist_candidate(candidate: CareerState, path: String) -> Dictionary:
	var result := await _save_career(candidate,path)
	if result.ok:
		active_career.commit_from(candidate)
		has_unsaved_changes = false
	else: _set_message("保存失败，进度未变更，可重试：%s" % "；".join(result.errors),true)
	return result

func _load_career_from(path: String) -> Dictionary:
	var result := SaveRepository.load_save(path)
	if not result.ok:
		var error_text := "\n".join(result.errors)
		_set_message(error_text, true)
		if summary_panel.visible:
			summary_panel.show_message(error_text, true)
		return result
	active_career = result.career
	_viewing_archive = false
	has_unsaved_changes = false
	_pending_new_career = null
	_open_loaded_career()
	_set_message("已读取 %s" % path)
	return result

func try_resume_career() -> Dictionary:
	var resume_path := autosave_path if FileAccess.file_exists(autosave_path) else save_path
	var original_path := save_path
	save_path = resume_path
	var result := load_active_career()
	save_path = original_path
	return result

func _activate_new_career(career: CareerState) -> void:
	active_career = career
	_viewing_archive = false
	has_unsaved_changes = true
	_pending_new_career = null
	_open_opening_or_home()
	_set_message("")
	if career.opening_stage == "complete": _maybe_show_onboarding("intro")

func _open_opening_or_home() -> void:
	if active_career == null: return
	match active_career.opening_stage:
		"history":
			pre_career_history_panel.present(active_career)
			_show_screen(pre_career_history_panel)
		"handoff":
			coach_handoff_panel.present(active_career, CoachHandoffPresenter.build(active_career))
			_show_screen(coach_handoff_panel)
		_: _open_player_home()

func _on_pre_career_history_continued() -> void:
	if active_career == null or active_career.opening_stage != "history": return
	var working := active_career.transaction_copy()
	working.opening_stage = "handoff"
	var saved := await _persist_candidate(working, autosave_path)
	if not saved.ok:
		pre_career_history_panel.present(active_career)
		return
	coach_handoff_panel.present(active_career, CoachHandoffPresenter.build(active_career))
	_show_screen(coach_handoff_panel)

func _on_career_goal_confirmed(goal_id: String) -> void:
	if active_career == null or active_career.opening_stage != "handoff": return
	if not ["love_the_sport", "highest_stage", "leave_a_mark"].has(goal_id): return
	var working := active_career.transaction_copy()
	working.career_goal = {"id": goal_id, "chosen_clock": working.clock.to_dict(), "scoring_effect": false}
	working.opening_stage = "complete"
	var saved := await _persist_candidate(working, autosave_path)
	if not saved.ok:
		coach_handoff_panel.present(active_career, CoachHandoffPresenter.build(active_career))
		return
	_open_player_home()
	_maybe_show_onboarding("intro")

func _open_player_home() -> void:
	if active_career == null: return
	career_home_panel.present(active_career)
	screen_router.replace(ScreenRoute.create("career_home"))
	_show_screen(career_home_panel)

func _on_home_action_requested(action_id: String) -> void:
	match action_id:
		"open_offseason_memory":
			var memory := preload("res://src/simulation/offseason_event_service.gd").pending(active_career)
			if not memory.is_empty(): _present_offseason_event(memory)
		"open_training", "review_internal_invitation", "review_health_decision": open_next_quarter()
		"open_programs":
			open_next_quarter()
			_set_message("可在本页分别打开短节目和自由滑编排。")
		"open_season": _open_career_home()
		"open_records":
			open_route("records", {}, screen_router.current())
		"open_saves": %SaveManagerPanel.present(browser_saves,active_career)
		"resume_competition": _open_loaded_career()
		_: _set_message("当前行动暂不可用，请返回生涯主页重试。",true)

func open_program_editor(segment: String) -> void:
	if active_career == null or not ["short", "free"].has(segment): return
	_pending_program_event_id = ""
	var source_screen := str(screen_router.current().get("screen_id", "career_home"))
	var current_level: String = preload("res://src/simulation/competitive_level_service.gd").current(active_career)
	var target_rules := InternalEventRules.for_season(preload("res://src/content/season_bundle_repository.gd").season_year(active_career), "senior" if current_level == "senior" else "junior", segment) if active_career.clock.year >= 2018 else InternalEventRules.for_teaching_group(segment)
	var works: Array = MusicCatalogRepository.load_catalog().get("works", [])
	var suggested_music: Dictionary = {"title": str(works[0].get("title", "练习曲"))} if not works.is_empty() else {"title":"练习曲"}
	var proposal := ProgramDraftService.propose(active_career.athlete, segment, target_rules, suggested_music, active_career.seed + (1 if segment == "short" else 2))
	program_editor_panel.present(active_career, segment, target_rules, proposal)
	program_editor_panel.set_return_screen(source_screen)
	open_route("programs", {"segment": segment, "source_screen": source_screen}, screen_router.current())
	_set_message("")
	_maybe_show_onboarding("program")

func _close_program_editor() -> void:
	if _season_editing:
		_season_editing = false
		_open_player_home()
		_present_season_planning(_season_planning_draft.season_id)
		return
	if not _pending_free_adjustment.is_empty():
		_pending_free_adjustment = ""
		_resume_formal_competition()
		return
	if not _pending_program_event_id.is_empty():
		_pending_program_event_id = ""
		_open_career_home()
		_set_message("已返回赛季主页；节目问题仍会保留，准备好后可以再次修复。")
		return
	back_route()
	_set_message("")

func _on_program_saved(segment: String, program_data: Dictionary) -> void:
	if _season_editing:
		var level: String = _season_planning_draft.editing_level
		_season_planning_draft.programs_by_level[level][segment] = program_data.duplicate(true)
		if level == _planning_primary_level(): _season_planning_draft.programs = _season_planning_draft.programs_by_level[level].duplicate(true)
		_season_editing = false
		_open_player_home()
		_present_season_planning(_season_planning_draft.season_id)
		return
	if not _pending_free_adjustment.is_empty():
		_confirm_formal_free(program_data)
		return
	var edited = SkatingProgram.from_dict(program_data)
	if edited == null or edited.segment != segment:
		_set_message("节目草案无效，未保存", true)
		return
	var working := active_career.transaction_copy()
	var edit_event := {}
	var event_programs: Dictionary = working.active_programs
	if not _pending_program_event_id.is_empty():
		var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(working)
		for candidate in bundle.get("calendar",{}).get("events",[]):
			if candidate.event_id == _pending_program_event_id: edit_event = candidate; break
		if edit_event.is_empty(): _set_message("未找到待编辑赛事，节目未修改",true); return
		event_programs = preload("res://src/simulation/season_program_service.gd").programs_for_event(working,edit_event)
	var existing_data: Dictionary = Dictionary(event_programs.get(segment, {}))
	if existing_data.is_empty():
		event_programs[segment] = edited.to_dict()
	else:
		# This signal only comes from the visible editor, so changing a previously
		# locked program is an explicit player-authored new version. Background
		# systems still use ProgramRevisionService directly and cannot alter locks.
		var revised := ProgramDraftService.save_draft(SkatingProgram.from_dict(existing_data), edited)
		if not revised.errors.is_empty():
			_set_message("节目修改失败：%s" % "；".join(revised.errors), true)
			return
		if edited.draft_status == "locked":
			revised.program.draft_status = "locked"
			if not revised.program.locked_segments.has(segment): revised.program.locked_segments.append(segment)
		if bool(revised.get("changed", false)) and revised.archived != null: working.program_archive.append(revised.archived.to_dict())
		event_programs[segment] = revised.program.to_dict()
	if not edit_event.is_empty():
		var stored := preload("res://src/simulation/season_program_service.gd").store_event_program(working,edit_event,segment,event_programs[segment])
		if not stored.ok: _set_message(stored.error,true); return
	InternalInvitationService.ensure_offer(working)
	var saved := await _persist_candidate(working, autosave_path)
	if not saved.ok: return
	if not _pending_program_event_id.is_empty():
		_pending_program_event_id = ""
		_open_career_home()
		_set_message("节目已保存。本场比赛的赛前清单会重新检查两套节目。")
		return
	quarter_panel.refresh_programs()
	back_route()
	_set_message("节目已保存，可在季度安排中练习" if saved.ok else "节目已修改，但自动保存失败：%s" % "；".join(saved.errors), not saved.ok)

func _on_internal_competition_deferred() -> void:
	if active_career == null: return
	var working := active_career.transaction_copy()
	InternalInvitationService.defer(working)
	var saved := await _persist_candidate(working, autosave_path)
	if not saved.ok: return
	quarter_panel.refresh_programs()
	_set_message("已暂缓内部赛，准备好后仍可参加" if saved.ok else "暂缓选择未能自动保存", not saved.ok)

func start_internal_competition(config: Dictionary = {}) -> Dictionary:
	if active_career == null: return {"ok": false, "errors": ["没有可参赛的生涯"]}
	if not preload("res://src/simulation/athlete_condition_service.gd").can_compete(active_career): return {"ok":false, "errors":["伤病尚未恢复，暂不能参赛"]}
	if not active_career.competition_state.is_empty() and str(active_career.competition_state.get("status", "")) != "ready":
		return {"ok": false, "errors": ["已有进行中的比赛"]}
	var short_program = SkatingProgram.from_dict(active_career.active_programs.get("short", {}))
	var free_program = SkatingProgram.from_dict(active_career.active_programs.get("free", {}))
	if short_program == null or free_program == null: return {"ok": false, "errors": ["请先准备短节目和自由滑"]}
	var working := active_career.transaction_copy()
	if str(config.get("status", "")) != "ready":
		var short_errors := ProgramValidator.validate(short_program, active_career.athlete, InternalEventRules.for_teaching_group("short"))
		var free_errors := ProgramValidator.validate(free_program, active_career.athlete, InternalEventRules.for_teaching_group("free"))
		if not short_errors.is_empty() or not free_errors.is_empty():
			return {"ok":false, "errors":short_errors + free_errors}
		if not InternalInvitationService.status(active_career).ready:
			return {"ok":false, "errors":InternalInvitationService.status(active_career).missing}
		InternalInvitationService.accept(working)
	var seed := int(config.get("seed", active_career.seed + active_career.rng_step + 7001))
	var context: Dictionary = Dictionary(config.get("context", _default_competition_context(config))).duplicate(true)
	working.competition_state = InternalCompetitionSimulator.start_event(
		working, short_program, free_program,
		Dictionary(config.get("strategy", {"risk": "balanced"})), context, seed,
		int(config.get("rival_count", 5)),
	)
	var saved := await _persist_candidate(working,autosave_path)
	if not saved.ok: return saved
	_present_competition_short()
	return {"ok": true, "errors": []}

func _open_loaded_career() -> void:
	if active_career.opening_stage != "complete":
		_open_opening_or_home()
		return
	if str(active_career.competition_state.get("kind", "")) == "formal":
		_resume_formal_competition()
		return
	var status := str(active_career.competition_state.get("status", ""))
	if status == "ready":
		start_internal_competition(active_career.competition_state)
	elif status == "awaiting_adjustment":
		_present_competition_short()
	elif status == "complete":
		_present_competition_free()
	else:
		_open_player_home()

func start_formal_competition(event_id: String) -> Dictionary:
	if active_career == null: return {"ok":false, "errors":["没有可参赛的生涯"]}
	if not active_career.competition_state.is_empty(): return {"ok":false, "errors":["已有进行中的比赛，请先完成当前比赛"]}
	var working := active_career.transaction_copy()
	var season_result := _ensure_2018_season_plan(working)
	if not season_result.ok: return {"ok":false, "errors":season_result.errors}
	var calendar_result := preload("res://src/content/season_bundle_repository.gd").for_career(working)
	var event := {}
	for candidate in calendar_result.calendar.get("events", []):
		if str(candidate.get("event_id", "")) == event_id: event = Dictionary(candidate).duplicate(true); break
	var entry: Dictionary = Dictionary(working.season_state.get("entry_plan", {}).get("entries", {}).get(event_id, {}))
	if event.is_empty() or str(entry.get("status", "")) != "confirmed" or not bool(entry.get("eligibility_snapshot", {}).get("eligible", false)):
		return {"ok":false, "errors":["该赛事尚未确认报名或不满足资格"]}
	if working.competition_timeline.get("mode") == "dated":
		# The cursor is the last settled day, not an unconsumed training day.
		var today := Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_datetime_string(str(working.competition_timeline.date)+"T00:00:00"))+86400)
		if today < str(event.get("start_date","")) or today > str(event.get("end_date",event.get("start_date",""))):
			return {"ok":false,"errors":["当前日期不在赛事日期范围内，请按日程推进训练或查看已结束赛事的档案"]}
	var checklist: Dictionary = preload("res://src/app/pre_competition_checklist_service.gd").inspect(working,event)
	if not checklist.ready:
		var checklist_errors: Array[String] = []
		for item in checklist.items:
			if str(item.status) != "ready": checklist_errors.append(str(item.reason))
		return {"ok":false,"errors":checklist_errors if not checklist_errors.is_empty() else checklist.errors}
	var current_gate := preload("res://src/simulation/entry_application_service.gd").current_eligibility(working,event,calendar_result,true)
	if not current_gate.eligible: return {"ok":false,"errors":current_gate.explanations}
	var date_parts := str(event.get("start_date", "")).split("-")
	var end_parts := str(event.get("end_date",event.get("start_date",""))).split("-")
	var current_quarter: int = active_career.clock.year * 4 + active_career.clock.quarter
	if date_parts.size() < 2 or end_parts.size() < 2:
		return {"ok":false,"errors":["赛事日期无效"]}
	var first_quarter := int(date_parts[0])*4 + int((int(date_parts[1])-1)/3)+1
	var final_quarter := int(end_parts[0])*4 + int((int(end_parts[1])-1)/3)+1
	if current_quarter < first_quarter or current_quarter > final_quarter:
		return {"ok":false, "errors":["当前季度不在赛事起止日期范围内"]}
	if active_career.competition_archive.any(func(archive): return str(archive.get("event_id", "")) == event_id): return {"ok":false, "errors":["该赛事已经结束并归档，不能重复参赛"]}
	if str(event.get("formal_scoring_catalog", "")).is_empty(): return {"ok":false, "errors":["当前版本先开放U系列正式青年组比赛"]}
	var resolved_event := preload("res://src/content/season_bundle_repository.gd").competition_for_career(working,event)
	if not resolved_event.errors.is_empty(): return {"ok":false,"errors":resolved_event.errors}
	var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(working,resolved_event.event)
	working.competition_state = FormalCompetitionSimulator.create_session(working, resolved_event.event, event_programs, "balanced", working.seed + 12001, 34)
	if not Array(working.competition_state.get("errors", [])).is_empty(): return {"ok":false, "errors":working.competition_state.errors}
	var saved := await _persist_candidate(working,autosave_path)
	if not saved.ok: return saved
	formal_competition_panel.present_session(active_career.competition_state, active_career)
	_show_screen(formal_competition_panel)
	_set_message("阵容与公开训练信息已经锁定。先查看名单，再选择比赛策略。")
	_maybe_show_onboarding("competition")
	return {"ok":true, "errors":[]}

func _on_formal_event_launch_requested(event_id: String) -> void:
	if active_career == null: return
	if not active_career.competition_state.is_empty() and str(active_career.competition_state.get("kind", "")) == "formal" and str(active_career.competition_state.get("event_id", "")) == event_id:
		_resume_formal_competition()
		return
	var season_result := _ensure_2018_season_plan()
	if not season_result.ok:
		_set_message("无法读取本场赛事：%s" % "；".join(season_result.errors),true)
		return
	var matches: Array = season_result.calendar.events.filter(func(candidate): return str(candidate.get("event_id", "")) == event_id)
	if matches.is_empty():
		_set_message("赛事资料不存在",true)
		return
	var resolved := preload("res://src/content/season_bundle_repository.gd").competition_for_career(active_career,matches[0])
	if resolved.errors.is_empty():
		var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(active_career,resolved.event)
		var replacement := preload("res://src/simulation/program_fallback_service.gd").propose(active_career,event_programs,{"short":resolved.rules.short.segment_rules,"free":resolved.rules.free.segment_rules},resolved.event)
		if replacement.changed:
			_present_program_replacement(replacement,event_id)
			return
	var checklist: Dictionary = preload("res://src/app/pre_competition_checklist_service.gd").inspect(active_career,matches[0])
	if not checklist.ready:
		season_overview_panel.present_pre_competition_checklist(event_id,checklist)
		_set_message("赛前检查发现尚未完成的准备；可采用教练方案、自己调整或返回。")
		return
	var started := await start_formal_competition(event_id)
	if not started.ok: _set_message("暂时无法开始比赛：%s" % "；".join(started.errors),true)

var _coach_accept_in_flight := false

func _on_pre_competition_action_requested(event_id: String, action_id: String, segment: String) -> void:
	if active_career == null: return
	if _coach_accept_in_flight:
		_set_message("正在保存教练方案，请稍候。",true)
		return
	if action_id == "adopt_coach_program":
		await _accept_coach_program(event_id,segment)
		return
	if action_id == "return_to_season": return
	if action_id == "decline_entry":
		_on_season_adjustment_selected(event_id,"skip")
		return
	if action_id == "withdraw":
		_on_season_adjustment_selected(event_id,"withdraw")
		return
	var season_result := _ensure_2018_season_plan()
	if not season_result.ok: _set_message("无法读取赛事资料",true); return
	var matches: Array = season_result.calendar.events.filter(func(candidate): return str(candidate.get("event_id", "")) == event_id)
	if matches.is_empty() or not ["short","free"].has(segment): _set_message("节目修复目标无效",true); return
	var event: Dictionary = matches[0]
	var resolved := preload("res://src/content/season_bundle_repository.gd").competition_for_career(active_career,event)
	if not resolved.errors.is_empty(): _set_message("无法读取比赛规则：%s" % "；".join(resolved.errors),true); return
	var rules: Dictionary = resolved.rules[segment].segment_rules
	if action_id == "edit_program":
		var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(active_career,resolved.event)
		var saved_program = SkatingProgram.from_dict(event_programs.get(segment, {}))
		var proposal: Dictionary
		if saved_program != null and ProgramValidator.validate(saved_program, active_career.athlete, rules).is_empty():
			proposal = {"program":saved_program, "missing":[], "errors":[], "replace_saved":true}
		else:
			proposal = ProgramDraftService.propose(active_career.athlete,segment,rules,{"title":"新赛季节目"},active_career.seed)
		program_editor_panel.present(active_career,segment,rules,proposal)
	else:
		_set_message("未知的赛前处理方式",true)
		return
	_pending_program_event_id = event_id
	_show_screen(program_editor_panel)
	_set_message("请检查节目；只有点击“锁定为参赛节目”后，赛前检查才会通过。")

func _accept_coach_program(event_id: String, segment: String) -> void:
	if not active_career.competition_state.is_empty():
		_set_message("已有比赛会话，请完成当前比赛后再修改节目。",true)
		return
	if active_career.competition_archive.any(func(item):return str(item.get("event_id","")) == event_id):
		_set_message("该比赛已归档，不能修改其参赛节目。",true)
		return
	if not segment in ["short","free"]:
		_set_message("节目修复目标无效",true)
		return
	var working := active_career.transaction_copy()
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(working)
	var matches: Array = bundle.get("calendar",{}).get("events",[]).filter(func(item):return str(item.get("event_id","")) == event_id)
	if not bundle.errors.is_empty() or matches.is_empty():
		_set_message("无法读取赛事资料",true)
		return
	var event: Dictionary = matches[0]
	var resolved := preload("res://src/content/season_bundle_repository.gd").competition_for_career(working,event)
	if not resolved.errors.is_empty():
		_set_message("无法读取比赛规则：%s" % "；".join(resolved.errors),true)
		return
	var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(working,resolved.event)
	var existing = SkatingProgram.from_dict(event_programs.get(segment,{}))
	# A stale repeated click must preserve an already accepted legal programme.
	if existing != null and existing.draft_status == "locked" and existing.locked_segments.has(segment) and ProgramValidator.validate(existing,working.athlete,resolved.rules[segment].segment_rules).is_empty():
		season_overview_panel.present_pre_competition_checklist(event_id,preload("res://src/app/pre_competition_checklist_service.gd").inspect(active_career,event))
		_set_message("本段节目已锁定，无需重复采用。")
		return
	var repaired := preload("res://src/app/pre_competition_checklist_service.gd").repair(working,event,[segment])
	if not repaired.errors.is_empty():
		_set_message("教练暂时无法修复：%s" % "；".join(repaired.errors),true)
		return
	var revised := ProgramDraftService.save_draft(existing,SkatingProgram.from_dict(repaired.programs[segment]))
	if not revised.errors.is_empty():
		_set_message("节目修改失败：%s" % "；".join(revised.errors),true)
		return
	var locked := ProgramDraftService.lock_for_competition(revised.program,working.athlete,resolved.rules[segment].segment_rules)
	if not locked.errors.is_empty():
		_set_message("节目锁定失败：%s" % "；".join(locked.errors),true)
		return
	var stored := preload("res://src/simulation/season_program_service.gd").store_event_program(working,resolved.event,segment,locked.program.to_dict())
	if not stored.ok:
		_set_message(stored.error,true)
		return
	if revised.archived != null: working.program_archive.append(revised.archived.to_dict())
	_coach_accept_in_flight = true
	var saved := await _persist_candidate(working,autosave_path)
	_coach_accept_in_flight = false
	if not saved.ok: return
	season_overview_panel.present_pre_competition_checklist(event_id,preload("res://src/app/pre_competition_checklist_service.gd").inspect(active_career,event))
	_set_message("已采用并锁定教练合规方案；请查看更新后的赛前清单。")

func _on_formal_strategy_selected(strategy_id: String) -> void:
	if active_career == null or str(active_career.competition_state.get("kind", "")) != "formal": return
	if _competition_medically_blocked(): return
	var working := active_career.transaction_copy()
	working.competition_state.strategy_id = strategy_id
	if not (await _persist_candidate(working,autosave_path)).ok: return
	formal_competition_panel.present_session(active_career.competition_state, active_career)
	if bool(active_career.competition_state.get("practice", {}).get("meaningful", false)):
		formal_competition_panel.show_practice()
	else:
		_on_formal_practice_response_selected("accept")

func _on_formal_practice_response_selected(response_id: String) -> void:
	if _competition_medically_blocked(): return
	var session := FormalCompetitionSimulator.complete_practice(active_career.competition_state, response_id)
	if not Array(session.get("errors", [])).is_empty(): _set_message("公开训练选择无效：%s" % session.errors[0], true); return
	var working := CareerState.from_dict(active_career.to_dict())
	var locked := FormalCompetitionSimulator.lock_short(working, session)
	if _competition_result_failed(locked): return
	working.competition_state = locked
	if not (await _persist_candidate(working,autosave_path)).ok: return
	formal_competition_panel.present_session(active_career.competition_state, active_career)
	formal_competition_panel.show_segment(Dictionary(active_career.competition_state.short_results.player).merged({"segment":"short"}, true))
	_show_screen(formal_competition_panel)

func _on_formal_playback_completed(segment: String) -> void:
	if _viewing_archive or active_career == null or active_career.competition_state.is_empty(): return
	if not formal_competition_panel._replay_athlete_id.is_empty(): return
	if segment == "short" and bool(active_career.competition_state.get("player_qualified", false)):
		formal_competition_panel.present_short_standings(active_career.competition_state.short_standings)
		_set_message("短节目结束：前24名晋级；未晋级不会获得玩家自由滑入口。")
	else:
		await _on_formal_archive_confirmed()

var _pending_free_adjustment := ""
var _formal_transition_busy := false

func _on_formal_adjustment_selected(adjustment_id: String) -> void:
	if _formal_transition_busy or _viewing_archive: return
	if _competition_medically_blocked(): return
	if str(active_career.competition_state.get("status", "")) != "free_adjustment" or not ["keep", "protect", "chase"].has(adjustment_id): return
	var player_rows: Array = active_career.competition_state.roster.filter(func(row): return bool(row.is_player))
	if player_rows.is_empty(): return
	if adjustment_id == "keep":
		_pending_free_adjustment = "keep"
		await _confirm_formal_free(Dictionary(player_rows[0].free_program))
		return
	var original = SkatingProgram.from_dict(player_rows[0].free_program)
	var proposal := preload("res://src/simulation/between_segment_adjuster.gd").propose(original, adjustment_id)
	proposal.original_between_program = original
	proposal.load_context = FormalCompetitionSimulator.free_segment_context(active_career, active_career.competition_state, player_rows[0])
	proposal.load_athlete = preload("res://src/domain/athlete_state.gd").from_dict(player_rows[0].athlete)
	_pending_free_adjustment = adjustment_id
	program_editor_panel.present(active_career, "free", active_career.competition_state.resolved_rules.free.segment_rules, proposal)
	_show_screen(program_editor_panel)
	_set_message("请检查完整自由滑编排。确认后才会执行，取消将保留原方案。")

func _confirm_formal_free(program_data: Dictionary) -> void:
	if _formal_transition_busy or _viewing_archive: return
	if str(active_career.competition_state.get("status", "")) != "free_adjustment": return
	if _competition_medically_blocked(): return
	var working := CareerState.from_dict(active_career.to_dict())
	var next := FormalCompetitionSimulator.lock_free(working, working.competition_state, _pending_free_adjustment, program_data)
	if _competition_result_failed(next): return
	working.competition_state = next
	if next.has("free_revision"):
		var stored := preload("res://src/simulation/season_program_service.gd").store_event_program(working,next.event,"free",next.free_revision.program)
		if not stored.ok: _set_message(stored.error,true); return
	_formal_transition_busy = true
	var saved := await _persist_candidate(working,autosave_path)
	_formal_transition_busy = false
	if not saved.ok: return
	_pending_free_adjustment = ""
	formal_competition_panel.present_session(active_career.competition_state, active_career)
	formal_competition_panel.show_segment(Dictionary(active_career.competition_state.free_results.player).merged({"segment":"free"}, true))
	_show_screen(formal_competition_panel)

func open_archived_competition(event_id: String) -> void:
	if active_career == null: return
	for archive in active_career.competition_archive:
		if archive.get("event_id") != event_id: continue
		_viewing_archive = true
		formal_competition_panel.present_session(archive.merged({"archive":archive}),active_career)
		formal_competition_panel.present_final_archive(archive)
		screen_router.open(ScreenRoute.create("formal_archive", {"event_id": event_id}, screen_router.current()))
		_show_screen(formal_competition_panel)
		return

func _on_formal_archive_confirmed() -> void:
	if _formal_transition_busy: return
	if _viewing_archive:
		_viewing_archive = false
		back_route()
		return
	if active_career.competition_state.get("status") != "complete": return
	var completed_archive: Dictionary = active_career.competition_state.get("archive",{}).duplicate(true)
	var acknowledged: Dictionary = preload("res://src/simulation/career_command_service.gd").apply(active_career,{"type":"acknowledge_formal_result"})
	if not acknowledged.ok: _set_message(str(acknowledged.error),true);return
	var working = acknowledged.career
	_formal_transition_busy = true
	var saved := await _persist_candidate(working,autosave_path)
	_formal_transition_busy = false
	if not saved.ok:
		formal_competition_panel.present_final_archive(completed_archive)
		formal_competition_panel.get_node("%ArchiveConfirmButton").text = "重试保存并查看赛后复盘"
		return
	summary_panel.present_post_competition(active_career,completed_archive)
	screen_router.replace(ScreenRoute.create("summary"))
	_show_screen(summary_panel)
	_set_message("正式比赛档案已经写入生涯，世界排名与名额证据同步更新。")

func _resume_formal_competition() -> void:
	var session: Dictionary = active_career.competition_state
	if str(session.get("status", "")) != "complete" and _competition_medically_blocked(): return
	formal_competition_panel.present_session(session, active_career)
	match str(session.get("status", "")):
		"practice_ready": pass
		"short_ready":
			var working := CareerState.from_dict(active_career.to_dict())
			var locked := FormalCompetitionSimulator.lock_short(working, session)
			if _competition_result_failed(locked): return
			if str(locked.get("status", "")) == "short_ready":
				_set_message("短节目尚未完成，请检查参赛条件。", true)
				return
			working.competition_state = locked
			if not (await _persist_candidate(working,autosave_path)).ok: return
			formal_competition_panel.present_session(locked, active_career)
			formal_competition_panel.show_segment(Dictionary(locked.short_results.player).merged({"segment":"short"}, true))
		"free_adjustment": formal_competition_panel.present_short_standings(session.short_standings)
		"complete": formal_competition_panel.present_final_archive(session.archive)
	_show_screen(formal_competition_panel)

func _competition_medically_blocked() -> bool:
	var programs: Variant = null
	if active_career.competition_state.get("kind","") == "formal":
		programs = FormalCompetitionSimulator._player_programs(active_career.competition_state)
	if preload("res://src/simulation/athlete_condition_service.gd").can_compete(active_career,programs): return false
	_set_message("伤病尚未恢复，暂不能参赛。当前比赛进度已保留。", true)
	return true

func _competition_result_failed(result: Dictionary) -> bool:
	if Array(result.get("errors", [])).is_empty() and str(result.get("status", "")) != "error": return false
	_set_message(str(Array(result.get("errors", ["比赛未完成"]))[0]), true)
	return true

func _open_career_home() -> void:
	if active_career != null and not active_career.season_state.get("season_history",{}).is_empty() and not preload("res://src/content/season_bundle_repository.gd").for_career(active_career).errors.is_empty():
		summary_panel.present(active_career,[])
		summary_panel.show_message(str(active_career.season_state.get("coach_feedback","本季已归档。"))+" 下一赛季历史赛历尚未收录。")
		_show_screen(summary_panel)
		return
	if active_career != null and active_career.clock.year >= 2018:
		var season_result := _ensure_2018_season_plan()
		if season_result.ok:
			season_overview_panel.present(active_career, season_result.calendar, active_career.season_state.entry_plan)
			screen_router.replace(ScreenRoute.create("season"))
			_show_screen(season_overview_panel)
			return
		_set_message("无法打开当前赛历：%s" % "\n".join(season_result.errors), true)
	quarter_panel.setup(active_career, catalog)
	screen_router.replace(ScreenRoute.create("training"))
	_show_screen(quarter_panel)

func _ensure_2018_season_plan(candidate: CareerState = null) -> Dictionary:
	var career := active_career if candidate == null else candidate
	var calendar_result := preload("res://src/content/season_bundle_repository.gd").for_career(career)
	if not calendar_result.errors.is_empty(): return {"ok": false, "calendar": {}, "errors": calendar_result.errors}
	var current_state: Dictionary = career.season_state
	var qualification_state := SeasonCalendarPlanner.qualification_state_for(career)
	var eligibility_rules := {"junior_min_age": 13, "junior_max_age": 18, "age_cutoff": {"month": 7, "day": 1}}
	if str(current_state.get("season_id", "")) == str(calendar_result.calendar.season_id) and not Dictionary(current_state.get("entry_plan", {})).is_empty():
		if Dictionary(current_state.get("qualification_state", {})) != qualification_state or SeasonCalendarPlanner.needs_unoffered_decline_repair(career,calendar_result.calendar,current_state.entry_plan):
			var refreshed := SeasonCalendarPlanner.refresh_eligibility(career, calendar_result.calendar, eligibility_rules, current_state.entry_plan)
			if not refreshed.errors.is_empty(): return {"ok":false, "calendar":{}, "errors":refreshed.errors}
			career.season_state.entry_plan = refreshed.plan.to_dict()
			career.season_state.qualification_state = qualification_state
			for refreshed_id in refreshed.plan.entries:
				career.season_state.event_statuses[refreshed_id] = refreshed.plan.entries[refreshed_id].status
			if candidate == null: has_unsaved_changes = true
		return {"ok": true, "calendar": calendar_result.calendar, "errors": []}
	var proposal := SeasonCalendarPlanner.propose(career, calendar_result.calendar, eligibility_rules)
	if not proposal.errors.is_empty(): return {"ok": false, "calendar": {}, "errors": proposal.errors}
	var event_statuses := {}
	for event_id in proposal.plan.entries: event_statuses[event_id] = proposal.plan.entries[event_id].status
	career.season_state["season_id"] = calendar_result.calendar.season_id
	career.season_state["entry_plan"] = proposal.plan.to_dict()
	career.season_state["qualification_state"] = qualification_state
	career.season_state["event_statuses"] = event_statuses
	if candidate == null: has_unsaved_changes = true
	return {"ok": true, "calendar": calendar_result.calendar, "errors": []}

func _on_season_entry_adjustment_requested(event_id: String) -> void:
	var season_result := _ensure_2018_season_plan()
	if not season_result.ok: _set_message("报名资格刷新失败：%s" % "\n".join(season_result.errors), true); return
	season_overview_panel.refresh_entry_plan(active_career.season_state.entry_plan)
	var event: Dictionary = season_result.calendar.events.filter(func(e): return e.event_id == event_id)[0]
	var options := preload("res://src/simulation/entry_application_service.gd").options(active_career,event,{"rules":{"junior_min_age":13,"junior_max_age":18}})
	season_overview_panel.present_adjustment_options(event_id, options)

func _on_season_adjustment_selected(event_id: String, adjustment_id: String) -> void:
	var working := active_career.transaction_copy()
	var season_result := _ensure_2018_season_plan(working)
	if not season_result.ok: _set_message("报名资格刷新失败：%s" % "\n".join(season_result.errors), true); return
	var changed := CareerCommandService.apply(working,{"type":"withdraw_entry" if adjustment_id == "withdraw" else "apply_entry","event_id":event_id,"route_id":adjustment_id})
	if not changed.ok:
		_set_message("报名调整失败：%s" % changed.error, true)
		return
	var saved := await _persist_candidate(changed.career, autosave_path)
	if saved.ok:
		season_overview_panel.refresh_entry_plan(active_career.season_state.entry_plan)
		_set_message("报名选择已自动保存")
	else:
		_set_message("报名选择保存失败：%s" % "\n".join(saved.errors), true)

func _on_domestic_schedule_requested() -> void:
	if active_career == null: return
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(active_career)
	season_overview_panel.present_domestic_schedule(preload("res://src/simulation/entry_application_service.gd").domestic_schedule_options(active_career, bundle))
	_set_message("选择本季国内赛报名安排；查看或返回不会推进时间。")

func _on_season_target_selected(event_id: String) -> void:
	if active_career == null: return
	var result := CareerCommandService.apply(active_career,{"type":"set_season_target","event_id":event_id})
	if not result.ok:
		_set_message(str(result.error),true)
		return
	if not (await _persist_candidate(result.career,autosave_path)).ok: return
	season_overview_panel.present_target_board()
	_set_message("赛季目标已保存，可查看资格缺口和竞争形势。")

func _on_preparation_route_selected(route_id: String, event_id: String, base_revision: int) -> void:
	if active_career == null or _decision_busy: return
	_decision_busy = true
	var receipt := "preparation:%s:%d" % [str(active_career.season_state.get("season_id","")),base_revision]
	var result := CareerCommandService.apply(active_career,{"type":"choose_preparation_route","route_id":route_id,"event_id":event_id,"base_revision":base_revision,"receipt_id":receipt})
	if not result.ok:
		_decision_busy = false
		_set_message(str(result.error),true)
		return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	season_overview_panel.present_target_board()
	_set_message("备战方向、培养目标和赛事目标已一起保存；现有比赛构成与派遣标准保持原样。")

func _on_domestic_schedule_selected(event_ids: Array) -> void:
	var result := CareerCommandService.apply(active_career, {"type":"apply_domestic_schedule", "event_ids":event_ids})
	if not result.ok:
		_set_message("参赛安排未修改：%s" % result.error, true)
		return
	var saved := await _persist_candidate(result.career, autosave_path)
	if not saved.ok:
		_set_message("参赛安排保存失败，原进度保留", true)
		return
	season_overview_panel.refresh_entry_plan(active_career.season_state.entry_plan)
	_set_message("本季国内赛已安排。可以继续训练，到期进入比赛。")

func _present_competition_short() -> void:
	var session: Dictionary = active_career.competition_state
	competition_panel.present({
		"event_name": str(session.get("event_name", "俱乐部内部赛")), "segment_name": "短节目", "segment": "short",
		"current_rank":int(session.get("provisional_rank",0)),"total_score":float(session.short.get("score",{}).get("total",0.0)),
		"athlete_name": active_career.athlete.display_name,
		"music_title": str(active_career.active_programs.short.get("music", {}).get("title", "未命名曲目")),
	})
	competition_panel.load_segment(session.short)
	_show_screen(competition_panel)
	competition_panel.restore_playback_checkpoint(Dictionary(session.get("playback_checkpoint",{})))
	_set_message("短节目已抽签完毕。点击“开始自动播放”后，路线与技术面板会同步推进。")

func _present_competition_free() -> void:
	var session: Dictionary = active_career.competition_state
	competition_panel.present({
		"event_name": str(session.get("event_name", "俱乐部内部赛")), "segment_name": "自由滑", "segment": "free",
		"current_rank":int(session.get("public_rank",0)),"total_score":float(session.get("total_score",0.0)),
		"athlete_name": active_career.athlete.display_name,
		"music_title": str(active_career.active_programs.free.get("music", {}).get("title", "未命名曲目")),
	})
	competition_panel.load_segment(session.free)
	_show_screen(competition_panel)
	competition_panel.restore_playback_checkpoint(Dictionary(session.get("playback_checkpoint",{})))
	_set_message("自由滑方案已锁定，比赛结果不会因观看速度改变。")

func _on_competition_segment_completed(segment: String) -> void:
	if active_career == null: return
	var checkpoint: Dictionary = competition_panel.playback_checkpoint()
	if Dictionary(active_career.competition_state.get("playback_checkpoint",{})) != checkpoint:
		var working := active_career.transaction_copy()
		working.competition_state.playback_checkpoint = checkpoint
		if not (await _persist_candidate(working,autosave_path)).ok:
			# Keep the revealed score available for retry, rather than letting
			# the player advance past a checkpoint that was not saved.
			competition_panel._completion_emitted = false
			competition_panel.playback_state = "awaiting_confirmation"
			competition_panel.get_node("%KissAndCryOverlay").show()
			competition_panel.get_node("%PlaybackButton").disabled = false
			return
	if segment == "short":
		competition_panel.present_adjustment_options(active_career.competition_state.get("available_adjustments", []))
		_set_message("短节目结束，当前暂列第 %d。选择一次自由滑策略。" % int(active_career.competition_state.get("provisional_rank", 1)))
	elif segment == "free":
		competition_panel.present_final_result(active_career.competition_state)
		_set_message("自由滑结束：公开成绩与俱乐部资源决定分别结算。")

func _on_competition_adjustment_selected(option_id: String) -> void:
	if _competition_medically_blocked(): return
	var working := CareerState.from_dict(active_career.to_dict())
	var next := InternalCompetitionSimulator.finish_event(working, working.competition_state, option_id)
	if _competition_result_failed(next): return
	working.competition_state = next
	if not (await _persist_candidate(working,autosave_path)).ok: return
	_present_competition_free()

func _on_competition_confirmed() -> void:
	if active_career == null or str(active_career.competition_state.get("status", "")) != "complete": return
	var working := active_career.transaction_copy()
	var result: Dictionary = active_career.competition_state
	for segment in ["short","free"]:
		preload("res://src/simulation/repertoire_evidence_service.gd").record_competition(working,result.get(segment,{}).get("performance",{}),"internal:%s:%d:%d:%s" % [str(result.get("event_id","first_internal")),working.clock.year,working.clock.quarter,segment])
	var completed_archive := {
		"event_id":str(result.get("event_id","first_internal")),
		"event_name":str(result.get("event_name","俱乐部内部赛")),
		"player_result":{"rank":int(result.get("public_rank",0)),"total_score":float(result.get("total_score",0.0))},
		"final_standings":Array(result.get("standings",[])).duplicate(true),
		"execution_scores":[Dictionary(result.get("short",{})).get("score",{}),Dictionary(result.get("free",{})).get("score",{})],
		"applied_resource_changes":Dictionary(Dictionary(result.get("club_decision",{})).get("resource_changes",{})).duplicate(true),
	}
	var decision: Dictionary = Dictionary(result.get("club_decision", {}))
	var changes: Dictionary = Dictionary(decision.get("resource_changes", {}))
	working.athlete.resources.ice_access = clampf(float(working.athlete.resources.ice_access) + float(changes.get("ice_access", 0.0)), 0.0, 100.0)
	if working.relationships.has("coach"):
		working.relationships.coach.professional_trust = clampf(float(working.relationships.coach.professional_trust) + float(changes.get("coach_attention", 0.0)), 0.0, 100.0)
	working.history.append({
		"category": "internal_competition", "target": "public_rank", "delta": 0.0,
		"cause_codes": ["two_segment_result", "club_decision_separated"], "summary_key": "内部赛第%d名，总分%.2f" % [int(result.public_rank), float(result.total_score)],
		"event_name": str(result.event_name), "public_rank": int(result.public_rank), "total_score": float(result.total_score),
		"standings": Array(result.standings).duplicate(true), "club_decision": decision.duplicate(true),
	})
	working.competition_state = {}
	InternalInvitationService.complete(working)
	if not (await _persist_candidate(working,autosave_path)).ok: return
	summary_panel.present_post_competition(active_career,completed_archive)
	_show_screen(summary_panel)
	_set_message("内部赛结果已写入生涯：公开名次与俱乐部资源变化均已保存。")

func _default_competition_context(config: Dictionary) -> Dictionary:
	return {
		"event_name": str(config.get("event_name", "俱乐部内部选拔（内部规则）")),
		"season_start_year": active_career.clock.year, "pressure": 36.0,
		"reputation": {"edge_reputation": 15.0},
		"influence": {"event_scope": "internal", "priority": 35.0, "coach_voice": 40.0},
		"club": {"priority": 35.0, "coach_favor": 45.0, "available_external_slots": 1},
		"peer_ids": Array(active_career.internal_invitation_state.get("peer_ids", [])).duplicate() if active_career != null else [],
	}

func _on_quarter_advanced(outcomes: Array) -> void:
	has_unsaved_changes = false
	summary_panel.present(active_career, outcomes)
	_show_screen(summary_panel)
	_set_message("季度进度已自动保存")

func _on_training_period_completed(result: Dictionary) -> void:
	has_unsaved_changes = false
	summary_panel.present_training_period(active_career, result)
	_show_screen(summary_panel)
	_set_message("本期训练已完成并自动保存")

func _on_milestone_advance_requested() -> void:
	_on_season_advance_requested()

func _on_season_advance_requested() -> void:
	if active_career == null or _auto_advance_running: return
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(active_career)
	var result := await preload("res://src/simulation/season_progression_service.gd").advance_to_next_node_durable(active_career,bundle,func(career): return bool((await _save_career(career,autosave_path)).ok))
	active_career = result.career
	if not result.errors.is_empty():
		_set_message("保存失败，已恢复最近成功保存的进度" if result.errors.has("save_failed") else "推进暂停：%s" % "；".join(result.errors),true)
		return
	has_unsaved_changes = false
	var node: Dictionary = result.stop_node
	_present_season_node(node,result.ledger)

func _on_season_auto_advance_requested() -> void:
	if active_career == null or _auto_advance_running: return
	if str(active_career.season_state.get("target_event_id","")).is_empty():
		_set_message("请先保存本赛季目标。",true)
		return
	if _auto_overlay == null:
		_auto_overlay = preload("res://src/app/season_auto_overlay.gd").new()
		_auto_overlay.name = "SeasonAutoOverlay"
		add_child(_auto_overlay)
		_auto_overlay.pause_requested.connect(func(): _auto_advance_continue = false)
	_auto_advance_running = true
	_auto_advance_continue = true
	_auto_overlay.begin()
	var result: Dictionary = await preload("res://src/app/season_auto_advance.gd").run(self,func():return _auto_advance_continue,func(message):_auto_overlay.report(message))
	_auto_advance_running = false
	_auto_advance_continue = false
	_auto_overlay.hide()
	if not active_career.competition_state.is_empty(): _resume_formal_competition()
	elif result.get("reason") in ["target_event","dispatch_or_quota_changed","cancelled"] or not result.get("errors",[]).is_empty():
		_open_career_home()
		var event_id := str(result.get("node",{}).get("event_id",active_career.season_state.get("target_event_id","")))
		if not event_id.is_empty(): season_overview_panel.select_event(event_id)
	elif not result.get("node",{}).is_empty(): _present_season_node(result.node,result.get("ledger",[]))
	else: _open_career_home()
	var lines: Array[String] = [str(result.get("reason_label",result.get("reason","托管已暂停。")))]
	for record in result.get("completed_events",[]):
		var line := str(record.get("name",record.get("event_id","")))
		if record.get("rank") != null: line += " · 第 %d 名" % int(record.rank)
		if record.get("total") != null: line += " · %.2f 分" % float(record.total)
		lines.append(line)
	_set_message("\n".join(lines),not result.get("errors",[]).is_empty())

func _present_season_node(node: Dictionary, ledger: Array = []) -> void:
	match str(node.get("kind","")):
		"season_transition":
			await _on_season_advance_requested()
			return
		"season_complete":
			summary_panel.present_season_reflection(active_career,str(node.get("closed_season_id","")))
			_show_screen(summary_panel)
			return
		"offseason_event":
			_present_offseason_event(node)
			return
		"rehabilitation_decision":
			_present_treatment(node)
			return
		"season_program_planning":
			_present_season_planning(str(node.season_id))
			return
		"program_replacement":
			_present_program_replacement(node.proposal,str(node.get("event_id","")))
			return
		"registration","selection","competition_check_in","entry_revalidation":
			_open_career_home()
			season_overview_panel.select_event(node.event_id)
			if node.kind == "competition_check_in":
				_on_formal_event_launch_requested(node.event_id)
				return
			var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(active_career)
			var matches: Array = bundle.calendar.events.filter(func(event): return str(event.event_id) == str(node.event_id))
			if node.kind == "registration" and not matches.is_empty() and str(matches[0].get("scope", "")) == "domestic" and not bool(active_career.season_state.get("domestic_schedule_selected", false)):
				_on_domestic_schedule_requested()
				return
			if node.kind != "competition_check_in":
				if _maybe_show_onboarding("registration"):
					_pending_registration_tutorial = {"event_id":str(node.event_id),"choices":Array(node.choices).duplicate(true)}
				else: season_overview_panel.present_adjustment_options(node.event_id,node.choices)
		"program_adjustment":
			_present_program_adjustment(node)
		"competition_practice","competition_short","between_segments","competition_free","result_acknowledgement": _resume_formal_competition()
		"medical_restriction":
			if not str(node.get("event_id","")).is_empty():
				_open_career_home()
				_on_season_entry_adjustment_requested(node.event_id)
			else: open_next_quarter()
		"authority_conflict","quarter_event","training_plan","internal_invitation","training_decision": open_next_quarter()
		_:
			summary_panel.present(active_career,[])
			summary_panel.show_message("已安全推进至关键节点：%s" % node.get("reason",""))
			_show_screen(summary_panel)
	var ledger_lines: Array[String] = []
	for entry in ledger.slice(maxi(0,ledger.size()-6)):
		ledger_lines.append("%s %s" % [str(entry.get("date","")),str(entry.get("reason",entry.get("kind","")))])
	summary_panel.details_text.text += "\n" + "\n".join(ledger_lines)
	_set_message(str(node.get("reason","已推进到下一关键节点")))

func _show_screen(screen: Control) -> void:
	# Window descendants are independent of their Control parent's visibility.
	# Navigation closes inspection UI, never answers its pending decision.
	for panel in [main_menu_panel,creation_screen,pre_career_history_panel,coach_handoff_panel,career_home_panel,quarter_panel,summary_panel,competition_panel,season_overview_panel,formal_competition_panel,program_editor_panel,career_reference_panel,health_panel,repertoire_panel]:
		if panel == null or panel == screen: continue
		for window in panel.find_children("*","Window",true,false):
			if window.visible: window.hide()
	if health_panel != null: health_panel.visible = screen == health_panel
	if repertoire_panel != null: repertoire_panel.visible = screen == repertoire_panel
	if screen == competition_panel:
		screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		screen.set_deferred("size",size)
	main_menu_panel.visible = screen == main_menu_panel
	creation_screen.visible = screen == creation_screen
	pre_career_history_panel.visible = screen == pre_career_history_panel
	coach_handoff_panel.visible = screen == coach_handoff_panel
	career_home_panel.visible = screen == career_home_panel
	quarter_panel.visible = screen == quarter_panel
	summary_panel.visible = screen == summary_panel
	competition_panel.visible = screen == competition_panel
	season_overview_panel.visible = screen == season_overview_panel
	formal_competition_panel.visible = screen == formal_competition_panel
	program_editor_panel.visible = screen == program_editor_panel
	career_reference_panel.visible = screen == career_reference_panel
	var career_screens := [career_home_panel, quarter_panel, summary_panel, season_overview_panel, program_editor_panel, career_reference_panel,health_panel,repertoire_panel]
	career_shell_panel.visible = screen in career_screens
	if career_shell_panel.visible and active_career != null:
		var screen_id := "career_home"
		if screen == quarter_panel: screen_id = "training"
		elif screen == health_panel: screen_id = "health"
		elif screen == repertoire_panel: screen_id = "repertoire"
		elif screen == program_editor_panel: screen_id = "programs"
		elif screen == season_overview_panel: screen_id = "season"
		elif screen == summary_panel: screen_id = "summary"
		elif screen == career_reference_panel: screen_id = str(screen_router.current().get("screen_id", "records"))
		var current_route := screen_router.current()
		if str(current_route.get("screen_id", "")) != screen_id and not (screen == career_reference_panel and str(current_route.get("screen_id", "")) in ["records", "relationships"]):
			current_route = ScreenRoute.create(screen_id)
		career_shell_panel.present(active_career, current_route, "有未保存变化" if has_unsaved_changes else "当前进度已保留")
	# The home has its own footer entry. Keeping the legacy floating button only
	# on the creation screen avoids covering game controls at compact viewports.
	%SaveManagerButton.visible = screen == creation_screen

func _maybe_show_onboarding(stage: String) -> bool:
	if active_career == null or onboarding_overlay.visible or not OnboardingService.should_show(active_career,stage): return false
	return onboarding_overlay.present(stage)

func _on_onboarding_dismissed(stage: String, skip_all: bool) -> void:
	if active_career == null: return
	var working := active_career.transaction_copy()
	OnboardingService.mark_seen(working,stage,skip_all)
	var saved := await _persist_candidate(working,autosave_path)
	if not saved.ok: _set_message("新手提示状态未能保存，下次可能再次出现。",true)
	onboarding_state_saved.emit(stage,bool(saved.ok))
	if stage == "registration" and not _pending_registration_tutorial.is_empty():
		var pending := _pending_registration_tutorial.duplicate(true)
		_pending_registration_tutorial.clear()
		var options: Array[Dictionary] = []
		for choice in pending.choices:
			if choice is Dictionary: options.append(choice)
		season_overview_panel.present_adjustment_options(str(pending.event_id),options)

func _new_decision_dialog(title_text: String, fixed_actions: bool = false) -> VBoxContainer:
	if is_instance_valid(_decision_dialog):
		remove_child(_decision_dialog)
		_decision_dialog.queue_free()
	_decision_dialog = Window.new()
	_decision_dialog.name = "CareerDecisionDialog"
	_decision_dialog.title = title_text
	_decision_dialog.size = Vector2i(720,430)
	if fixed_actions:
		var available := get_viewport().get_visible_rect().size
		_decision_dialog.size = Vector2i(maxi(560,mini(880,int(available.x)-48)),maxi(320,mini(600,int(available.y)-64)))
	_decision_dialog.transient = true
	_decision_dialog.exclusive = true
	_decision_dialog.close_requested.connect(func(): _decision_dialog.hide())
	add_child(_decision_dialog)
	var background := PanelContainer.new()
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.add_theme_stylebox_override("panel",ThemeFactory.card_style())
	_decision_dialog.add_child(background)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",12)
	if fixed_actions:
		var layout := VBoxContainer.new()
		layout.add_theme_constant_override("separation",12)
		background.add_child(layout)
		var scroll := ScrollContainer.new()
		scroll.name = "DecisionScroll"
		scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		layout.add_child(scroll)
		box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		scroll.add_child(box)
		var actions := VBoxContainer.new()
		actions.name = "DecisionActions"
		layout.add_child(actions)
	else:
		background.add_child(box)
	_decision_dialog.popup_centered()
	return box

func _decision_text(box: VBoxContainer, value: String) -> void:
	var label := Label.new()
	label.text = value
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(label)

func _present_program_adjustment(node: Dictionary) -> void:
	var box := _new_decision_dialog("这场比赛的节目尚未准备好")
	_decision_text(box,str(node.get("reason","当前节目不符合本场规则。")))
	_decision_text(box,"可以调整构成再参赛；如果暂时还没有所需技术，也可以退出这场比赛继续训练。查看或返回不会推进时间。")
	var edit := Button.new()
	edit.name = "EditProgram"
	edit.text = "查看规则并编辑节目"
	edit.pressed.connect(func():
		_decision_dialog.hide()
		_pending_program_event_id = str(node.get("event_id",""))
		var proposal := ProgramDraftService.propose(active_career.athlete,node.segment,node.rules,{"title":"新赛季节目"},active_career.seed)
		var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(active_career)
		for event in bundle.get("calendar",{}).get("events",[]):
			if str(event.event_id) != _pending_program_event_id: continue
			var programmes := preload("res://src/simulation/season_program_service.gd").programs_for_event(active_career,event)
			var existing = SkatingProgram.from_dict(programmes.get(node.segment,{}))
			if existing != null:
				proposal = {"program":existing,"replace_saved":true,"missing":[],"errors":[]}
			elif proposal.get("program") != null:
				proposal.replace_saved = true
			break
		program_editor_panel.present(active_career,node.segment,node.rules,proposal)
		_show_screen(program_editor_panel))
	box.add_child(edit)
	if not str(node.get("event_id","")).is_empty():
		var withdraw := Button.new()
		withdraw.name = "WithdrawEvent"
		withdraw.text = "退出这场比赛，继续训练（报名费不退）"
		withdraw.pressed.connect(_withdraw_program_event.bind(str(node.event_id)))
		box.add_child(withdraw)
	var back := Button.new()
	back.name = "InspectReturn"
	back.text = "先返回主页查看"
	back.pressed.connect(func(): _decision_dialog.hide(); _open_player_home())
	box.add_child(back)

func _withdraw_program_event(event_id: String) -> void:
	if _decision_busy: return
	_decision_busy = true
	var result := CareerCommandService.apply(active_career,{"type":"withdraw_entry","event_id":event_id})
	if not result.ok:
		_decision_busy = false
		_set_message(result.error,true)
		return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	if is_instance_valid(_decision_dialog): _decision_dialog.hide()
	_open_player_home()

func _present_program_replacement(proposal: Dictionary, event_id: String) -> void:
	var box := _new_decision_dialog("调整暂不可用动作")
	_decision_text(box,"；".join(proposal.get("reasons",[])))
	_decision_text(box,"确认后会在后续比赛继续沿用；恢复训练不会自动换回旧构成。")
	if bool(proposal.get("legal",false)):
		var lines: Array[String] = []
		for segment in proposal.programs:
			var codes: Array[String] = []
			for element in proposal.programs[segment].get("elements",[]):
				if element.kind != "jump": continue
				var parts: Array = [{"jump_id":element.jump_id,"rotations":element.rotations}]
				parts.append_array(element.get("combination_parts",[]))
				codes.append(preload("res://src/domain/technical_repertoire.gd").action_id({"kind":"jump","parts":parts}))
			lines.append("%s：%s" % ["短节目" if segment == "short" else "自由滑"," · ".join(codes)])
		_decision_text(box,"\n".join(lines))
		var accept := Button.new()
		accept.text = "确认合法替代并沿用"
		accept.pressed.connect(_confirm_program_replacement.bind(proposal,event_id))
		box.add_child(accept)
	if not event_id.is_empty():
		var withdraw := Button.new()
		withdraw.text = "退出这场比赛，继续恢复训练"
		withdraw.pressed.connect(_withdraw_program_event.bind(event_id))
		box.add_child(withdraw)
	var cancel := Button.new()
	cancel.text = "先返回查看（不修改节目）"
	cancel.pressed.connect(func(): _decision_dialog.hide(); _open_player_home())
	box.add_child(cancel)

func _review_program_upgrade() -> void:
	if active_career == null or _decision_busy: return
	var service = preload("res://src/simulation/program_upgrade_service.gd")
	var year := preload("res://src/content/season_bundle_repository.gd").season_year(active_career)
	var level := "senior" if preload("res://src/simulation/competitive_level_service.gd").current(active_career) == "senior" else "junior"
	for segment in ["short","free"]:
		var proposal: Dictionary = service.propose(active_career,segment,service.rules_for_career(active_career,segment),true)
		if not proposal.changed: continue
		var box := _new_decision_dialog("把训练储备带进节目",true)
		_decision_text(box,"%s：赛季目标已有可用储备，可以尝试这次有限调整。训练可用不等于比赛稳定，教练不会替你自动更改构成。" % ("短节目" if segment == "short" else "自由滑"))
		var lines: Array[String] = []
		var old_elements: Array = active_career.active_programs[segment].elements
		for index in proposal.programs[segment].elements.size():
			var element: Dictionary = proposal.programs[segment].elements[index]
			if element == old_elements[index]: continue
			var parts: Array = [{"jump_id":element.jump_id,"rotations":element.rotations}]
			parts.append_array(element.get("combination_parts",[]))
			lines.append("第%d个动作 → %s" % [index+1,preload("res://src/domain/technical_repertoire.gd").action_id({"kind":"jump","parts":parts})])
		var comparison := preload("res://src/presentation/program_upgrade_presenter.gd").build(active_career,proposal)
		_decision_text(box,str(comparison.text) if comparison.ok else "\n".join(lines))
		_decision_text(box,"保存为修订草稿，仍需在编排页确认节目；不采用会保留原构成。")
		for option in [{"name":"UpgradeAccept","text":"采用调整并保存","choice":"accept"},{"name":"UpgradeDecline","text":"暂不采用这份建议","choice":"decline"}]:
			var button := Button.new()
			button.name = option.name
			button.text = option.text
			button.pressed.connect(_resolve_program_upgrade.bind(proposal,option.choice))
			box.add_child(button)
		var back := Button.new()
		back.name = "UpgradeReturn"
		back.text = "返回查看（不修改节目）"
		back.pressed.connect(func(): _decision_dialog.hide())
		box.add_child(back)
		return
	_set_message("目前没有新的节目调整建议。继续练习即可；你也可以随时自己编辑节目。")

func _resolve_program_upgrade(proposal: Dictionary, choice: String) -> void:
	if _decision_busy or active_career == null: return
	_decision_busy = true
	var result := CareerCommandService.apply(active_career,{"type":"resolve_program_upgrade","proposal":proposal,"choice":choice,"receipt_id":"upgrade:"+str(proposal.get("id",""))+":"+choice})
	if not result.ok: _decision_busy = false; _set_message(result.error,true); return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	if is_instance_valid(_decision_dialog): _decision_dialog.hide()
	_open_player_home()
	_set_message("节目修订已保存，请在编排页确认后参赛。" if choice == "accept" else "继续沿用原节目；这份建议不会反复打断你。")

func _confirm_program_replacement(proposal: Dictionary, event_id: String) -> void:
	if _decision_busy: return
	_decision_busy = true
	var receipt := "replacement:%s:%s" % [event_id,str(proposal.get("source_hash",""))]
	var result := CareerCommandService.apply(active_career,{"type":"confirm_program_replacement","proposal":proposal,"receipt_id":receipt})
	if not result.ok: _decision_busy = false; _set_message(result.error,true); return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	if is_instance_valid(_decision_dialog): _decision_dialog.hide()
	_open_player_home()
	_set_message("替代节目已确认并保存，后续比赛沿用这个版本。")

func _present_treatment(node: Dictionary) -> void:
	var box := _new_decision_dialog("与医疗团队商量下一步")
	_decision_text(box,"%s\n%s" % [node.get("reason",""),node.get("treatment",{}).get("uncertainty","")])
	for route in node.get("choices",[]):
		var button := Button.new()
		button.name = "Route_"+str(route.id)
		button.text = str(route.label)
		button.pressed.connect(_confirm_treatment.bind(str(node.injury_id),str(route.id)))
		box.add_child(button)
		_decision_text(box,"%s\n%s" % [route.get("risk",""),route.get("resource_impact","")])
	var later := Button.new()
	later.text = "先返回查看身体（不推进时间）"
	later.pressed.connect(func(): _decision_dialog.hide(); open_route("health",{},screen_router.current()))
	box.add_child(later)

func _confirm_treatment(injury_id: String, route_id: String) -> void:
	if _decision_busy: return
	_decision_busy = true
	var count := Array(active_career.condition_state.rehabilitation.get(injury_id,{}).get("receipts",[])).size()
	var result := CareerCommandService.apply(active_career,{"type":"choose_rehabilitation","injury_id":injury_id,"route_id":route_id,"receipt_id":"treatment:%s:%d:%s" % [injury_id,count,route_id]})
	if not result.ok:
		_decision_busy = false
		_set_message(result.error,true)
		return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	_decision_dialog.hide()
	_open_player_home()
	_set_message("治疗路线已保存。教练将安排允许的基础与恢复训练；已完成的训练不会重跑。")

func _offer_skating_intro() -> void:
	var box := _new_decision_dialog("开始之前 · 你熟悉花样滑冰吗？")
	_decision_text(box,"不了解动作代号也可以玩。入门介绍可以随时退出，以后也能重看。")
	var learn := Button.new()
	learn.name = "LearnSkating"
	learn.text = "第一次接触，先看入门介绍"
	learn.pressed.connect(func(): _present_skating_guide(0,true))
	box.add_child(learn)
	var skip := Button.new()
	skip.name = "SkipSkatingIntro"
	skip.text = "我了解一些，直接新建生涯"
	skip.pressed.connect(func(): _decision_dialog.hide(); _show_screen(creation_screen))
	box.add_child(skip)
	var back := Button.new()
	back.text = "返回主菜单"
	back.pressed.connect(func(): _decision_dialog.hide())
	box.add_child(back)

func _present_skating_guide(page: int = 0, start_new: bool = false) -> void:
	var pages: Array = preload("res://src/presentation/skating_beginner_guide.gd").pages_for(active_career.clock.to_dict() if active_career != null else {})
	page = clampi(page,0,pages.size()-1)
	# A help window is a child of the active modal, not a replacement for it.
	# Closing it therefore restores the same decision and unsaved draft.
	var owner_node: Node = _decision_dialog if is_instance_valid(_decision_dialog) and _decision_dialog.visible else self
	if not is_instance_valid(_information_dialog):
		_information_dialog = preload("res://src/app/readable_information_dialog.tscn").instantiate()
		_information_dialog.name = "SkatingInformationDialog"
		owner_node.add_child(_information_dialog)
	elif _information_dialog.get_parent() != owner_node:
		_information_dialog.hide()
		_information_dialog.reparent(owner_node)
	var sections: Array = []
	for entry in pages: sections.append({"heading":entry.title,"body":entry.body})
	_information_dialog.present("花滑入门与帮助",sections)
	_information_dialog.show_page(page)
	_information_dialog.close_button.text = "返回入门选择" if start_new else "返回，不修改进度"

func _present_offseason_event(event: Dictionary) -> void:
	var box := _new_decision_dialog(str(event.title))
	_decision_text(box,str(event.reason))
	_decision_text(box,str(event.impact))
	for choice in event.choices:
		var button := Button.new()
		button.name = "OffseasonChoice_"+str(choice.id)
		button.text = str(choice.label)
		button.pressed.connect(func(): _resolve_offseason_event(str(event.id),str(choice.id)))
		box.add_child(button)
	var back := Button.new()
	back.name = "OffseasonReturn"
	back.text = "先返回，稍后再选"
	back.pressed.connect(func(): _decision_dialog.hide(); _open_player_home())
	box.add_child(back)

func _resolve_offseason_event(event_id: String, choice_id: String) -> void:
	if _decision_busy: return
	_decision_busy = true
	var result := CareerCommandService.apply(active_career,{"type":"resolve_offseason_event","event_id":event_id,"choice_id":choice_id})
	if not result.ok:
		_decision_busy = false
		_set_message(result.error,true)
		return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	_decision_dialog.hide()
	_open_player_home()
	if not result.events.is_empty(): _set_message(str(result.events[0].get("response","这段经历已记下。")))

func _present_birth_date() -> void:
	if active_career == null or _decision_busy: return
	var box := _new_decision_dialog("出生日期与参赛年龄",true)
	var date: Dictionary = active_career.athlete.birth_date
	var unknown := date.is_empty()
	_decision_text(box,"出生年份：%d。国际赛事按赛季开始前的7月1日年龄判定，不是只看今年几岁。" % active_career.athlete.birth_year)
	_decision_text(box,"原档没有月日；不会替你编造生日。可以先返回继续训练和符合资格的国内赛，需要精确年龄时再补充。确定后不可反复修改。" if unknown else "已确定：%d年%d月%d日。生日不会随升组变化。年龄达标也不等于获得国际名额或派遣。" % [int(date.year),int(date.month),int(date.day)])
	var actions = _decision_dialog.find_child("DecisionActions",true,false)
	if unknown:
		var row := HBoxContainer.new()
		box.add_child(row)
		var month := SpinBox.new()
		month.name = "BirthMonthInput"
		month.max_value = 12
		month.suffix = "月（0为未填）"
		row.add_child(month)
		var day := SpinBox.new()
		day.name = "BirthDayInput"
		day.max_value = 31
		day.suffix = "日（0为未填）"
		row.add_child(day)
		var error := Label.new()
		error.name = "BirthDateError"
		error.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(error)
		var confirm := Button.new()
		confirm.text = "确定出生日期并保存"
		confirm.pressed.connect(func(): _record_birth_date(int(month.value),int(day.value)))
		actions.add_child(confirm)
	var cancel := Button.new()
	cancel.text = "返回（不改变进度）"
	cancel.pressed.connect(func(): _decision_dialog.hide())
	actions.add_child(cancel)

func _record_birth_date(month: int, day: int) -> void:
	if active_career == null or _decision_busy: return
	_decision_busy = true
	var result := CareerCommandService.apply(active_career,{"type":"record_birth_date","birth_date":{"year":active_career.athlete.birth_year,"month":month,"day":day},"receipt_id":"player-birth-date"})
	if not result.ok:
		_decision_busy = false
		var error = _decision_dialog.find_child("BirthDateError",true,false)
		if error != null: error.text = result.error
		return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	_decision_dialog.hide()
	_open_player_home()
	_set_message("出生日期已保存。年龄资格会据此更新；不会自动获得名额或派遣。")

func _present_season_planning(season_id: String) -> void:
	# Reopening after a separately committed direction change must really
	# reload its version. Keep the command's stale-write rejection intact.
	var stale_direction: bool = int(_season_planning_draft.get("direction",{}).get("revision",-1)) != int(active_career.training_direction.revision)
	if _season_planning_draft.get("season_id","") != season_id or stale_direction:
		_season_planning_draft = {"season_id":season_id,"mode":"retain","competitive_level":preload("res://src/simulation/competitive_level_service.gd").current(active_career),"programs":active_career.active_programs.duplicate(true),"targets":{},"direction":active_career.training_direction.duplicate(true),"base_revision":int(active_career.season_program_plan.get("revision",0))}
		for segment in _season_planning_draft.programs.keys():
			if _season_planning_draft.programs[segment].is_empty(): _season_planning_draft.programs.erase(segment)
		_season_planning_draft.programs_by_level = Dictionary(active_career.season_program_plan.get("programs_by_level",{})).duplicate(true)
		_season_planning_draft.programs_by_level[_planning_primary_level()] = _season_planning_draft.programs.duplicate(true)
		_season_planning_draft.editing_level = _planning_primary_level()
	var box := _new_decision_dialog("%s · 赛季节目与专项" % season_id,true)
	_decision_text(box,"节目和两个重点一起定，也可直接沿用教练安排；叉号仅返回，不保存。")
	if season_id == "2022-23":
		_decision_text(box,"2022–23 正式赛事试点：成年组可申请内贝尔霍恩杯和布达佩斯杯。国内赛与青年路线仍含内部测试赛事。")
	var level_service = preload("res://src/simulation/competitive_level_service.gd")
	var levels := OptionButton.new()
	levels.name = "CompetitiveLevelChoice"
	for level in level_service.LABELS:
		levels.add_item(level_service.LABELS[level])
		var index := levels.item_count-1
		levels.set_item_metadata(index,level)
		var reason: String = level_service.validate_choice(active_career,season_id,level)
		levels.set_item_disabled(index,not reason.is_empty())
		levels.set_item_tooltip(index,reason)
		if level == _season_planning_draft.get("competitive_level","junior"): levels.select(index)
	levels.item_selected.connect(func(index): _set_planning_level(str(levels.get_item_metadata(index))))
	levels.tooltip_text = "升组保留所有技术储备。过渡赛季可分别申请青年与成年赛事，但派遣不互通。成年自由滑增加编舞步法；改组后请检查两套节目。"
	box.add_child(levels)
	if _season_planning_draft.competitive_level == "transition":
		var group := OptionButton.new()
		group.name = "ProgramLevelChoice"
		for level in ["junior","senior"]:
			group.add_item("查看 / 编辑：" + level_service.LABELS[level])
			group.set_item_metadata(group.item_count-1,level)
			if level == _season_planning_draft.editing_level: group.select(group.item_count-1)
		group.item_selected.connect(func(index): _season_planning_draft.editing_level = group.get_item_metadata(index); _ensure_planning_group(_season_planning_draft.editing_level); _present_season_planning(season_id))
		box.add_child(group)
	levels.tooltip_text += " 首次改组先生成候选方案，可自行调整；确认前不改存档。"
	var modes := OptionButton.new()
	for entry in [{"id":"retain","label":"沿用节目，继续打磨"},{"id":"upgrade","label":"沿用音乐，调整构成"},{"id":"new_program","label":"编排新节目"}]:
		modes.add_item(entry.label)
		modes.set_item_metadata(modes.item_count-1,entry.id)
		if entry.id == _season_planning_draft.mode: modes.select(modes.item_count-1)
	modes.item_selected.connect(func(index): _season_planning_draft.mode = modes.get_item_metadata(index))
	box.add_child(modes)
	var edits := HBoxContainer.new()
	box.add_child(edits)
	for segment in ["short","free"]:
		var edit := Button.new()
		edit.name = "SeasonEditShort" if segment == "short" else "SeasonEditFree"
		edit.text = "查看 / 编排短节目" if segment == "short" else "查看 / 编排自由滑"
		edit.pressed.connect(func(): _open_season_program_editor(segment))
		edits.add_child(edit)
	_add_season_focus_controls(box)
	var footer := HBoxContainer.new()
	_decision_dialog.find_child("DecisionActions",true,false).add_child(footer)
	var clear := Button.new()
	clear.text = "清空专项目标"
	clear.pressed.connect(func(): _season_planning_draft.direction.focuses = []; _season_planning_draft.erase("focus_slots"); _season_planning_draft.targets = {}; _present_season_planning(season_id))
	footer.add_child(clear)
	var confirm := Button.new()
	confirm.name = "SeasonConfirm"
	confirm.text = "确认本季方案"
	confirm.theme_type_variation = "PrimaryButton"
	confirm.pressed.connect(_confirm_season_planning)
	footer.add_child(confirm)
	var cancel := Button.new()
	cancel.text = "先返回（不保存草稿）"
	cancel.pressed.connect(func(): _season_planning_draft = {}; _decision_dialog.hide(); _open_player_home())
	footer.add_child(cancel)
	_refresh_season_focus_preview()

func _planning_primary_level() -> String:
	return "senior" if _season_planning_draft.get("competitive_level","junior") == "senior" else "junior"

func _set_planning_level(level: String) -> void:
	var season_id: String = _season_planning_draft.season_id
	var reason := preload("res://src/simulation/competitive_level_service.gd").validate_choice(active_career,season_id,level)
	if not reason.is_empty(): _set_message(reason,true); return
	_season_planning_draft.competitive_level = level
	_season_planning_draft.editing_level = _planning_primary_level()
	_ensure_planning_group(_planning_primary_level())
	if level == "transition": _ensure_planning_group("senior")
	_season_planning_draft.programs = _season_planning_draft.programs_by_level[_planning_primary_level()].duplicate(true)
	_present_season_planning(season_id)

func _ensure_planning_group(level: String) -> void:
	if _season_planning_draft.programs_by_level.has(level): return
	var programs := {}
	for segment in ["short","free"]:
		var source: Dictionary = _season_planning_draft.programs.get(segment,{})
		var candidate = SkatingProgram.from_dict(source)
		var rules := InternalEventRules.for_season(int(str(_season_planning_draft.season_id).get_slice("-",0)),level,segment)
		if candidate != null and segment == "free":
			if level == "senior" and not candidate.elements.any(func(e): return e.kind == "choreographic_sequence"):
				candidate.elements.append(preload("res://src/domain/program_element.gd").create("senior-choreo","choreographic_sequence").element)
			elif level == "junior": candidate.elements.assign(candidate.elements.filter(func(e): return e.kind != "choreographic_sequence"))
		if not preload("res://src/simulation/program_validator.gd").validate(candidate,active_career.athlete,rules).is_empty():
			candidate = ProgramDraftService.legal_draft(active_career.athlete,segment,rules,source.get("music",{}),active_career.seed).program
		if candidate != null:
			candidate.draft_status = "draft"
			candidate.locked_segments.clear()
			programs[segment] = candidate.to_dict()
	_season_planning_draft.programs_by_level[level] = programs

func _open_season_program_editor(segment: String) -> void:
	_decision_dialog.hide()
	open_program_editor(segment)
	_season_editing = true
	_season_planning_draft.mode = "upgrade"
	var level: String = _season_planning_draft.editing_level
	_ensure_planning_group(level)
	var data: Dictionary = _season_planning_draft.programs_by_level[level].get(segment,{})
	var rules := InternalEventRules.for_season(int(str(_season_planning_draft.season_id).get_slice("-",0)),level,segment)
	var proposal := {"program":SkatingProgram.from_dict(data),"missing":[],"errors":[]} if not data.is_empty() else ProgramDraftService.propose(active_career.athlete,segment,rules,{},active_career.seed)
	program_editor_panel.present(active_career,segment,rules,proposal)

func _add_season_focus_controls(box: VBoxContainer) -> void:
	var presenter = preload("res://src/presentation/training_focus_presenter.gd")
	var options: Array = presenter.options(active_career)
	if not _season_planning_draft.has("focus_slots"):
		_season_planning_draft.focus_slots = [{},{}]
		for slot in _season_planning_draft.direction.focuses.size(): _season_planning_draft.focus_slots[slot] = _season_planning_draft.direction.focuses[slot].duplicate(true)
	_decision_text(box,"本季培养重点（可并行，基础维护交给教练）：")
	var focus_row := HBoxContainer.new()
	focus_row.add_theme_constant_override("separation",12)
	box.add_child(focus_row)
	for slot in 2:
		var picker := OptionButton.new()
		picker.name = "SeasonFocus%d" % slot
		picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		picker.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		for option in options:
			picker.add_item(option.label)
			picker.set_item_metadata(picker.item_count-1,option.focus.duplicate(true))
			var current: Dictionary = _season_planning_draft.focus_slots[slot]
			if option.focus.get("kind") == current.get("kind") and option.focus.get("target") == current.get("target"): picker.select(picker.item_count-1)
		picker.item_selected.connect(func(index):
			_season_planning_draft.focus_slots[slot] = picker.get_item_metadata(index).duplicate(true)
			_season_planning_draft.direction.focuses = _season_planning_draft.focus_slots.filter(func(focus): return not focus.is_empty()).duplicate(true)
			_refresh_season_focus_preview())
		focus_row.add_child(picker)
	var priority := OptionButton.new()
	priority.name = "SeasonFocusPriority"
	for item in [["balanced","均衡推进"],["first","冲突时优先第一个重点"],["second","冲突时优先第二个重点"]]:
		priority.add_item(item[1]); priority.set_item_metadata(priority.item_count-1,item[0])
		if item[0] == _season_planning_draft.direction.priority: priority.select(priority.item_count-1)
	priority.item_selected.connect(func(index): _season_planning_draft.direction.priority = priority.get_item_metadata(index); _refresh_season_focus_preview())
	box.add_child(priority)
	var preview := Label.new()
	preview.name = "SeasonTrainingPreview"
	preview.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	preview.add_theme_font_size_override("font_size",15)
	box.add_child(preview)

func _season_focus_targets() -> Dictionary:
	var targets: Array = []
	for focus in _season_planning_draft.direction.focuses:
		if focus.target.get("kind") != "jump": continue
		# A distant focus is a valid long-term direction, not a declaration that
		# the next programme can already contain that difficulty.
		if focus.target.parts.any(func(part): return int(part.rotations) > int(active_career.athlete.jumps[part.jump_id].unlocked_rotations)+1): continue
		targets.append({"element_id":"target:"+preload("res://src/domain/technical_repertoire.gd").action_id(focus.target),"action":focus.target.duplicate(true)})
	return {"free":targets} if not targets.is_empty() else {}

func _refresh_season_focus_preview() -> void:
	var candidate := active_career.transaction_copy()
	candidate.training_direction = _season_planning_draft.direction.duplicate(true)
	candidate.season_program_plan.targets = _season_focus_targets()
	var view: Dictionary = preload("res://src/presentation/training_focus_presenter.gd").build(candidate)
	var preview = _decision_dialog.find_child("SeasonTrainingPreview",true,false)
	var confirm = _decision_dialog.find_child("SeasonConfirm",true,false)
	if confirm != null: confirm.disabled = not view.errors.is_empty()
	if preview != null:
		var lines: Array[String] = []
		for focus in candidate.training_direction.focuses:
			var rows: Array = view.states.filter(func(state): return state.id == focus.id)
			var stage := str(rows[0].stage) if not rows.is_empty() else "maintenance"
			var explanation := str({"preparation":"先推进前置基础，尚未安排目标动作尝试","practice":"本期安排专项练习","maintenance":"本期保留维护，可调整优先级"}.get(stage,stage))
			lines.append("%s：%s。" % [preload("res://src/presentation/training_focus_presenter.gd").label(focus),explanation])
		lines.append("使用现有课时，完整基础与恢复继续保留。" if not lines.is_empty() else "沿用教练的均衡基础课程，不需要另填专项。")
		preview.tooltip_text = "\n".join(view.reasons)
		preview.text = "教练安排预览：\n" + ("；".join(view.errors) if not view.errors.is_empty() else "\n".join(lines))

func _confirm_season_planning() -> void:
	if _decision_busy: return
	var service = preload("res://src/simulation/season_program_service.gd")
	_season_planning_draft.targets = _season_focus_targets()
	var draft: Dictionary = service.preview(active_career,_season_planning_draft.season_id,_season_planning_draft.mode,_season_planning_draft.programs,_season_planning_draft.targets,str(_season_planning_draft.get("competitive_level","junior")),_season_planning_draft.programs_by_level)
	if not draft.errors.is_empty(): _set_message("；".join(draft.errors),true); return
	_decision_busy = true
	var result := CareerCommandService.apply(active_career,{"type":"confirm_season_program","draft":draft,"receipt_id":"season:%s:%d" % [draft.season_id,draft.base_revision+1]})
	if not result.ok: _decision_busy = false; _set_message(result.error,true); return
	# Both commands run on private candidates; one durable write commits both.
	result = CareerCommandService.apply(result.career,{"type":"set_training_direction","direction":_season_planning_draft.direction,"receipt_id":"season-focus:%s:%d" % [draft.season_id,draft.base_revision+1]})
	if not result.ok: _decision_busy = false; _set_message(result.error,true); return
	var saved := await _persist_candidate(result.career,autosave_path)
	_decision_busy = false
	if not saved.ok: return
	_season_planning_draft = {}
	_decision_dialog.hide()
	_open_player_home()
	_set_message("赛季方案已保存，教练会据此安排专项；比赛继续沿用确认后的节目。")

func _set_message(message: String, is_error: bool = false) -> void:
	global_message.text = message
	global_message.modulate = Color(1.0,0.48,0.45) if is_error else Color(0.55,0.86,0.68)
