class_name QuarterPanel
extends MarginContainer

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const AuthorityResolver = preload("res://src/simulation/authority_resolver.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const EventEngine = preload("res://src/simulation/event_engine.gd")
const JumpMasteryView = preload("res://src/presentation/jump_mastery_view.gd")
const TrainingPolicy = preload("res://src/domain/training_policy.gd")
const TrainingPolicyPlanner = preload("res://src/simulation/training_policy_planner.gd")
const TrainingRecommendationPresenter = preload("res://src/app/training_recommendation_presenter.gd")
const DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
const DevelopmentRoadmapEvaluator = preload("res://src/simulation/development_roadmap_evaluator.gd")
const RoadmapTrainingAdapter = preload("res://src/simulation/roadmap_training_adapter.gd")
const InternalInvitationService = preload("res://src/simulation/internal_invitation_service.gd")
const CareerCommandService = preload("res://src/simulation/career_command_service.gd")
const PlanProposal = preload("res://src/domain/plan_proposal.gd")
const AthleteConditionService = preload("res://src/simulation/athlete_condition_service.gd")
const TrainingIntent = preload("res://src/domain/training_intent.gd")
const CoachTrainingPlanService = preload("res://src/simulation/coach_training_plan_service.gd")
const MeaningfulAdvanceService = preload("res://src/simulation/meaningful_advance_service.gd")

signal quarter_advanced(outcomes: Array)
signal training_period_completed(result: Dictionary)
signal advance_blocked(node: Dictionary)
signal persistence_failed()
signal program_requested(segment: String)
signal program_upgrade_requested
signal internal_competition_requested()
signal internal_competition_deferred()
signal training_after_defer_requested()

var teaching_invitation_dialog: ConfirmationDialog
var _invitation_program_segment := "short"

const DEFAULT_ALLOCATIONS := {
	"skating_foundation": 30,
	"jump_toe_loop": 10, "jump_salchow": 5, "jump_loop": 0,
	"jump_flip": 0, "jump_lutz": 0, "jump_axel": 5,
	"rotation": 15, "conditioning": 15, "rest": 20,
}
const CATEGORY_LABELS := {
	"skating_foundation": "滑行基础",
	"jump_toe_loop": "后外点冰跳", "jump_salchow": "后内结环跳",
	"jump_loop": "后外结环跳", "jump_flip": "后内点冰跳",
	"jump_lutz": "勾手跳", "jump_axel": "阿克塞尔跳",
	"rotation": "旋转训练",
	"conditioning": "体能与力量",
	"rest": "恢复与自由活动",
	"program_short": "短节目合练",
	"program_free": "自由滑合练",
}
const REASON_LABELS := {
	"guardian_health_protection": "监护人因健康优先调整计划",
	"guardian_achievement_pressure": "监护人因成绩期待调整计划",
	"coach_foundation_priority": "教练因基础训练优先调整计划",
	"coach_jump_priority": "教练认为跳跃训练不足并调整计划",
	"coach_jump_load_safety": "教练认为跳跃负荷过于激进",
	"medical_recovery_required": "疼痛报告后必须优先恢复",
	"fatigue_recovery_required": "当前疲劳或身体负荷已不允许继续原训练量",
	"coach_rotation_risk": "教练认为当前身体与技术准备不足以升周",
	"extreme_child_load": "跳跃安排明显过量，家长与教练要求降低负荷",
}

var career: CareerState
var _continuous_running := false
var _continuous_stop := false
var persist: Callable
var season_bundle: Dictionary = {}
var catalog: Dictionary = {}
var _setting_up := false
var _allocation_inputs: Dictionary = {}
var _rotation_inputs: Dictionary = {}
var _active_proposal
var _preview_signature := ""
var _response_buttons: Array[Button] = []
var _pending_events: Array = []
var _event_outcomes: Array = []
var _completed_outcomes: Array = []
var _quarter_completed := false
var _coach_period_pending := false
var _policy_id := "balanced_foundation"
var _risk_attitude := "normal"
var _focus_slots: Array[Dictionary] = [{"jump_id": "", "rotations": 1}, {"jump_id": "", "rotations": 1}]
var _policy_selector: OptionButton
var _risk_selector: OptionButton
var _focus_jump_inputs: Array[OptionButton] = []
var _focus_rotation_inputs: Array[OptionButton] = []
var _policy_forecast: Label
var _advanced_editor: VBoxContainer
var _recommendation_list: VBoxContainer
var _recommendation_note: Label
var _custom_policy_container: VBoxContainer
var _recommendations: Array[Dictionary] = []
var _roadmap_status: Label
var _roadmap_button: Button
var _roadmap_dialog
var _training_intent
var _coach_proposal_summary: Label
var _requested_element_picker: OptionButton
var _intent_buttons: Dictionary = {}

@onready var date_label: Label = %DateLabel
@onready var technique_summary: Label = %TechniqueSummary
@onready var jump_mastery_summary: Label = %JumpMasterySummary
@onready var body_summary: Label = %BodySummary
@onready var motivation_summary: Label = %MotivationSummary
@onready var resources_summary: Label = %ResourcesSummary
@onready var relationships_summary: Label = %RelationshipsSummary
@onready var allocation_total: Label = %AllocationTotal
@onready var plan_error_label: Label = %PlanErrorLabel
@onready var authority_status_label: Label = %AuthorityStatusLabel
@onready var advance_button: Button = %AdvanceButton
@onready var authority_confirmation: ConfirmationDialog = %AuthorityConfirmation
@onready var event_dialog: Window = %EventDialog

func _ready() -> void:
	_allocation_inputs = {
		"skating_foundation": %SkatingFoundationInput,
		"rotation": %RotationInput,
		"conditioning": %ConditioningInput,
		"rest": %RestInput,
	}
	var jump_row := get_node("Layout/Columns/PlanPanel/PlanMargin/Plan/JumpRow")
	jump_row.visible = false
	var jump_grid := GridContainer.new()
	jump_grid.columns = 3
	jump_grid.name = "JumpGrid"
	jump_row.get_parent().add_child(jump_grid)
	jump_row.get_parent().move_child(jump_grid, jump_row.get_index())
	for category_id in ["jump_toe_loop", "jump_salchow", "jump_loop", "jump_flip", "jump_lutz", "jump_axel"]:
		var label := Label.new()
		label.text = CATEGORY_LABELS[category_id]
		jump_grid.add_child(label)
		var input := SpinBox.new()
		input.custom_minimum_size = Vector2(72, 24)
		_configure_share_input(input)
		jump_grid.add_child(input)
		_allocation_inputs[category_id] = input
		var rotation_input := OptionButton.new()
		rotation_input.custom_minimum_size = Vector2(92, 24)
		jump_grid.add_child(rotation_input)
		_rotation_inputs[category_id.trim_prefix("jump_")] = rotation_input
		rotation_input.item_selected.connect(func(_index): _on_allocation_changed(0.0))
	var program_grid := GridContainer.new()
	program_grid.columns = 2
	program_grid.name = "ProgramPracticeGrid"
	jump_row.get_parent().add_child(program_grid)
	jump_row.get_parent().move_child(program_grid, jump_grid.get_index() + 1)
	for category_id in TrainingPlan.PROGRAM_CATEGORY_IDS:
		var label := Label.new()
		label.text = CATEGORY_LABELS[category_id]
		program_grid.add_child(label)
		var input := SpinBox.new()
		input.name = "ProgramShortInput" if category_id == "program_short" else "ProgramFreeInput"
		input.tooltip_text = "需要先拥有对应的比赛节目"
		program_grid.add_child(input)
		_allocation_inputs[category_id] = input
	for input: SpinBox in _allocation_inputs.values():
		_configure_share_input(input)
		input.value_changed.connect(_on_allocation_changed)
	advance_button.pressed.connect(continue_training)
	teaching_invitation_dialog = ConfirmationDialog.new()
	teaching_invitation_dialog.title = "第一场教学赛邀请"
	teaching_invitation_dialog.ok_button_text = "准备短节目"
	teaching_invitation_dialog.cancel_button_text = "返回训练安排"
	add_child(teaching_invitation_dialog)
	teaching_invitation_dialog.add_button("参加教学赛", false, "enter")
	teaching_invitation_dialog.add_button("暂缓，继续训练", false, "defer")
	teaching_invitation_dialog.confirmed.connect(func(): program_requested.emit(_invitation_program_segment))
	teaching_invitation_dialog.custom_action.connect(func(action: StringName):
		teaching_invitation_dialog.hide()
		if action == &"enter": internal_competition_requested.emit()
		elif action == &"defer": training_after_defer_requested.emit())
	$Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/ProgramActionRow/ProgramShortButton.pressed.connect(func(): program_requested.emit("short"))
	$Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/ProgramActionRow/ProgramFreeButton.pressed.connect(func(): program_requested.emit("free"))
	$Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/InternalActionRow/InternalStartButton.pressed.connect(func(): internal_competition_requested.emit())
	$Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/InternalActionRow/InternalDeferButton.pressed.connect(func(): internal_competition_deferred.emit())
	authority_confirmation.confirmed.connect(confirm_authority_adjustment)
	authority_confirmation.custom_action.connect(_on_authority_response)
	event_dialog.event_choice.connect(func(_event_id, choice_id): resolve_event_choice(choice_id))
	_roadmap_dialog = preload("res://src/app/development_roadmap_dialog.tscn").instantiate()
	add_child(_roadmap_dialog)
	_roadmap_dialog.roadmap_confirmed.connect(apply_roadmap)
	_build_policy_ui()
	_make_plan_scrollable()
	set_allocations(DEFAULT_ALLOCATIONS)
	advance_button.text = "按这个方向继续训练"

func setup(active_career: CareerState, content_catalog: Dictionary) -> void:
	_setting_up = true
	career = active_career
	season_bundle = preload("res://src/content/season_bundle_repository.gd").for_career(career)
	catalog = content_catalog
	_active_proposal = null
	_preview_signature = ""
	_pending_events.clear()
	_completed_outcomes.clear()
	_quarter_completed = false
	_coach_period_pending = false
	_event_outcomes.clear()
	authority_confirmation.hide()
	event_dialog.hide()
	_refresh_career_summary()
	_refresh_rotation_choices()
	_refresh_program_training_inputs()
	_refresh_internal_invitation()
	var saved_plan: Dictionary = career.last_generated_plan.duplicate(true)
	var saved_policy: Dictionary = career.last_training_policy.duplicate(true)
	_generate_policy_plan()
	_refresh_recommendations()
	var period_intent: Dictionary = Dictionary(career.training_period_state.get("intent", {}))
	if str(period_intent.get("mode", "")) == "requested_element":
		_refresh_requested_elements()
		for index in _requested_element_picker.item_count:
			if str(_requested_element_picker.get_item_metadata(index)) == str(period_intent.get("element_id", "")):
				_requested_element_picker.select(index)
	select_training_intent(str(period_intent.get("mode", "accept")))
	career.last_generated_plan = saved_plan
	career.last_training_policy = saved_policy
	_refresh_roadmap_card()
	_setting_up = false
	for data in career.condition_state.get("pending_training_events",[]):
		_pending_events.append(_training_event(data))
	if not _pending_events.is_empty():
		_quarter_completed = true
		event_dialog.present(_pending_events[0])

func select_training_intent(mode: String) -> void:
	var element_id := ""
	if mode == "requested_element":
		if _requested_element_picker == null or _requested_element_picker.item_count == 0:
			plan_error_label.text = "当前还没有具备前置训练证据、可以主动争取的动作。"
			return
		element_id = str(_requested_element_picker.get_item_metadata(_requested_element_picker.selected))
	var created := TrainingIntent.create(mode, element_id)
	if not created.errors.is_empty():
		plan_error_label.text = "；".join(created.errors)
		return
	var period_intent: Dictionary = Dictionary(career.training_period_state.get("intent", {})) if career != null else {}
	if not period_intent.is_empty() and created.intent.to_dict() != period_intent:
		for intent_id in _intent_buttons:
			_intent_buttons[intent_id].button_pressed = intent_id == str(period_intent.mode)
		plan_error_label.text = "本期已训练%d周。先处理当前事件并完成本期；下一期可以再换方向。" % int(career.training_period_state.get("weeks_elapsed", 0))
		return
	_training_intent = created.intent
	for intent_id in _intent_buttons:
		var button: Button = _intent_buttons[intent_id]
		button.button_pressed = intent_id == mode
	if _requested_element_picker != null:
		_requested_element_picker.visible = mode == "requested_element"
	_refresh_coach_proposal()

func open_training_focus() -> void:
	if career == null: return
	var dialog = get_node_or_null("TrainingFocusPanel")
	if dialog == null:
		dialog = load("res://src/app/training_focus_panel.tscn").instantiate()
		add_child(dialog)
		dialog.direction_requested.connect(_on_training_direction_requested)
	dialog.present(career)

func open_external_training() -> void:
	if career == null: return
	var dialog = get_node_or_null("ExternalTrainingPanel")
	if dialog == null:
		dialog = load("res://src/app/external_training_panel.tscn").instantiate()
		add_child(dialog)
		dialog.command_requested.connect(_on_external_training_requested)
	dialog.present(career)

func _on_external_training_requested(command: Dictionary) -> void:
	var dialog = get_node("ExternalTrainingPanel")
	dialog.set_busy(true)
	var result: Dictionary = load("res://src/simulation/career_command_service.gd").apply(career,command)
	if not result.ok: dialog.show_error(result.error); return
	if not await _commit_candidate(result.career): dialog.show_error(plan_error_label.text); return
	dialog.hide()
	_refresh_coach_proposal()
	_refresh_career_summary()

func _on_training_direction_requested(direction: Dictionary) -> void:
	var dialog = get_node("TrainingFocusPanel")
	dialog.set_busy(true)
	var result: Dictionary = load("res://src/simulation/career_command_service.gd").apply(career,{"type":"set_training_direction","direction":direction,"receipt_id":"focus:%d:%d:%d" % [career.clock.year,career.clock.quarter,int(direction.revision)]})
	if not result.ok: dialog.show_error(result.error); return
	if not await _commit_candidate(result.career): dialog.show_error(plan_error_label.text); return
	dialog.hide()
	_refresh_coach_proposal()

var _dated_coach_requested := false
var _pending_coach_course: TrainingPlan

func continue_training() -> void:
	if _continuous_running:
		_continuous_stop = true
		advance_button.text = "正在保存当前阶段，随后暂停……"
		return
	if career == null or _training_intent == null: return
	if not await _ensure_dated_training(): return
	if career.competition_timeline.mode == "dated":
		var built := _actual_coach_course()
		if built.plan == null: plan_error_label.text = "；".join(built.errors);return
		_dated_coach_requested = true
		_setting_up = true
		set_allocations(built.plan.shares)
		for jump_id in built.plan.jump_rotations: set_jump_rotation(str(jump_id),int(built.plan.jump_rotations[jump_id]))
		_setting_up = false
		_pending_coach_course = built.plan
		await request_advance()
		return
	if not career.season_state.get("season_history",{}).is_empty():
		await _continue_to_review()
		return
	if not _quarter_preflight(): return
	advance_button.disabled = true
	plan_error_label.text = "正在训练并保存本期进度……"
	if DisplayServer.get_name() != "headless": await get_tree().process_frame
	var before := career.transaction_copy()
	var result: Dictionary = MeaningfulAdvanceService.advance(career, _training_intent)
	if not Array(result.get("errors", [])).is_empty():
		plan_error_label.text = "；".join(result.errors)
		advance_button.disabled = false
		return
	var candidate: CareerState = result.get("career")
	if candidate == null or not await _commit_candidate(candidate):
		advance_button.disabled = false
		return
	result["before"] = before
	result["career"] = career
	if not career.training_direction.focuses.is_empty():
		var review: Dictionary = preload("res://src/presentation/training_focus_review_presenter.gd").build(before.to_dict(),career)
		result.facts = Array(result.get("facts",[]))+review.facts
	if str(result.get("stop_reason", "")) == "quarter_complete":
		training_period_completed.emit(result)
		return
	_refresh_career_summary()
	_refresh_internal_invitation()
	_refresh_coach_proposal()
	advance_button.disabled = false
	var pending: Dictionary = result.get("pending_action", {})
	plan_error_label.text = str(pending.get("message", pending.get("reason", "训练已暂停，可稍后从当前进度继续。")))
	if str(pending.get("kind", "")) == "teaching_competition":
		_present_teaching_invitation()
	elif str(pending.get("kind", "")) in ["quarter_event", "authority_conflict"]:
		_present_coach_period_stop(str(pending.kind))
	elif not pending.is_empty():
		advance_blocked.emit(pending)

func _continue_to_review() -> void:
	if not _quarter_preflight(): return
	var before := career.transaction_copy()
	_continuous_running = true
	_continuous_stop = false
	advance_button.disabled = false
	advance_button.text = "暂停连续训练（保留已保存阶段）"
	for id in _intent_buttons: _intent_buttons[id].disabled = true
	for name in ["EditTrainingFocus","ExternalTraining","ProgramUpgrade"]:
		var button = find_child(name,true,false)
		if button != null: button.disabled = true
	plan_error_label.text = "按当前重点连续训练，遇到赛事、重大事件或两季度验收自动停止。"
	var result: Dictionary = await load("res://src/simulation/focus_training_run_service.gd").advance(career,_training_intent,func(candidate): return await _commit_candidate(candidate),func(): return _continuous_stop or not is_visible_in_tree())
	_continuous_running = false
	for id in _intent_buttons: _intent_buttons[id].disabled = false
	for name in ["EditTrainingFocus","ExternalTraining","ProgramUpgrade"]:
		var button = find_child(name,true,false)
		if button != null: button.disabled = false
	_refresh_career_summary()
	_refresh_coach_proposal()
	advance_button.disabled = false
	if not result.errors.is_empty(): plan_error_label.text = "；".join(result.errors); return
	result.before = before
	result.career = career
	if result.stop_reason == "quarter_complete": training_period_completed.emit(result); return
	var pending: Dictionary = result.pending_action
	plan_error_label.text = "已暂停，已执行阶段均已保存；可以修改重点后继续。" if result.stop_reason == "user_pause" else str(pending.get("message",pending.get("reason","训练已暂停")))
	if pending.get("kind") in ["quarter_event","authority_conflict"]: _present_coach_period_stop(str(pending.kind))
	elif not pending.is_empty(): advance_blocked.emit(pending)

func _present_coach_period_stop(kind: String) -> void:
	var plan = TrainingPlan.from_dict(career.training_period_state.get("plan", {}))
	if plan == null:
		plan = CoachTrainingPlanService.build(career, _training_intent).plan
	_active_proposal = AuthorityResolver.preview(career, plan)
	_coach_period_pending = true
	if kind == "authority_conflict":
		_show_current_conflict()
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = career.seed + career.rng_step * CareerSimulator.RNG_STEP_OFFSET + 17
	_pending_events = EventEngine.generate(career, _active_proposal, rng)
	if not _pending_events.is_empty(): event_dialog.present(_pending_events[0])

func _present_teaching_invitation() -> void:
	var status := InternalInvitationService.status(career)
	_invitation_program_segment = "short" if Dictionary(status.get("details",{})).has("short") else "free"
	teaching_invitation_dialog.ok_button_text = "准备短节目" if _invitation_program_segment=="short" else "准备自由滑"
	teaching_invitation_dialog.dialog_text = "第%d周｜教练已为你安排第一场教学赛。你可以先查看和准备节目，也可以暂缓比赛后继续训练。" % int(status.get("schedule", {}).get("current_week", 0))
	if not bool(status.ready):
		teaching_invitation_dialog.dialog_text += "\n\n参赛前还需：%s" % "；".join(status.missing)
	for button in teaching_invitation_dialog.find_children("*", "Button", true, false):
		if button is Button and button.text == "参加教学赛": button.disabled = not bool(status.ready)
	teaching_invitation_dialog.popup_centered(Vector2i(560, 260))

func refresh_programs() -> void:
	_refresh_program_training_inputs()
	_refresh_internal_invitation()
	_refresh_career_summary()
	_validate_plan()

func _refresh_internal_invitation() -> void:
	if career == null: return
	var state := InternalInvitationService.ensure_offer(career)
	var start_button: Button = $Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/InternalActionRow/InternalStartButton
	var defer_button: Button = $Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/InternalActionRow/InternalDeferButton
	var status_label: Label = $Layout/Columns/StatusPanel/StatusMargin/StatusScroll/Status/InternalStatusLabel
	var schedule: Dictionary = state.get("schedule", {})
	var invitation_due := bool(schedule.get("available", false))
	var peer_names: Array[String] = []
	for peer_id in schedule.get("peer_ids", []):
		if career.world_athletes.has(peer_id): peer_names.append(str(career.world_athletes[peer_id].name))
	var peer_text := "\n同组学员：%s" % "、".join(peer_names) if not peer_names.is_empty() else ""
	start_button.disabled = not bool(state.ready)
	defer_button.disabled = not invitation_due or ["deferred", "accepted", "completed"].has(str(state.invitation))
	if state.ready:
		status_label.text = "第%d周｜教学赛邀请已到，可以参加或暂缓%s" % [int(schedule.get("current_week", 0)), peer_text]
	elif invitation_due:
		status_label.text = "第%d周｜教学赛邀请已到；参赛前还需：%s%s" % [int(schedule.get("current_week", 0)), "；".join(state.missing), peer_text]
	else:
		status_label.text = "第一场教学赛预计在第%d周前后出现；现在先训练和准备节目。" % int(schedule.get("week", 12))

func apply_roadmap(roadmap) -> void:
	if career == null or roadmap == null: return
	var checked = DevelopmentRoadmap.from_dict(roadmap.to_dict())
	if checked == null:
		plan_error_label.text = "成长路线无效，原安排未变更。"
		return
	var desired: Dictionary = checked.to_dict()
	var saved_roadmap = DevelopmentRoadmap.from_dict(career.development_roadmap)
	var previous: Dictionary = saved_roadmap.to_dict() if saved_roadmap != null else {}
	for key in ["status","last_evaluation"]:
		desired.erase(key)
		previous.erase(key)
	if desired == previous: return
	var working := career.transaction_copy(true)
	var evaluation := DevelopmentRoadmapEvaluator.evaluate(working, checked)
	working.development_roadmap = checked.to_dict()
	working.development_roadmap.status = evaluation.status
	working.development_roadmap.last_evaluation = evaluation.duplicate(true)
	working.roadmap_revision_history.append({"clock": working.clock.to_dict(), "route_id": checked.route_id, "reason": "玩家确认成长路线"})
	if not await _commit_candidate(working): return
	_refresh_roadmap_card()
	_refresh_coach_proposal()
	if TrainingPlan.from_dict(career.training_period_state.get("plan",{})) != null:
		_roadmap_status.text += "\n新路线下期生效；本期按原有约定完成。"

func set_policy(policy_id: String) -> void:
	if not TrainingPolicy.POLICY_IDS.has(policy_id): return
	_policy_id = policy_id
	_select_metadata(_policy_selector, policy_id)
	_generate_policy_plan()

func set_focus_jump(slot: int, jump_id: String, rotations: int) -> void:
	if slot < 0 or slot >= _focus_slots.size(): return
	if not jump_id.is_empty() and not TrainingPlan.JUMP_LABELS.has(jump_id): return
	_focus_slots[slot] = {"jump_id": jump_id, "rotations": clampi(rotations, 1, 4)}
	_select_metadata(_focus_jump_inputs[slot], jump_id)
	_select_metadata(_focus_rotation_inputs[slot], clampi(rotations, 1, 4))
	_generate_policy_plan()

func toggle_advanced_editor(visible: bool) -> void:
	_advanced_editor.visible = visible

func choose_recommendation(recommendation_id: String) -> void:
	for option in _recommendations:
		if str(option.id) != recommendation_id: continue
		var policy: Dictionary = option.policy
		_policy_id = str(policy.policy_id)
		_risk_attitude = str(policy.risk_attitude)
		_select_metadata(_policy_selector,_policy_id)
		_select_metadata(_risk_selector,_risk_attitude)
		var plan: Dictionary = option.plan
		set_allocations(Dictionary(plan.shares))
		for jump_id in Dictionary(plan.jump_rotations): set_jump_rotation(str(jump_id),int(plan.jump_rotations[jump_id]))
		career.last_training_policy = policy.duplicate(true)
		career.last_generated_plan = {"shares":Dictionary(plan.shares).duplicate(true),"jump_rotations":Dictionary(plan.jump_rotations).duplicate(true)}
		_policy_forecast.text = "%s：%s\n取舍：%s" % [str(option.title),str(option.benefit),str(option.tradeoff)]
		return

func reuse_last_plan() -> void:
	if career == null or career.last_generated_plan.is_empty(): return
	var plan = TrainingPlan.from_dict(career.last_generated_plan)
	if plan == null: return
	set_allocations(plan.shares)
	for jump_id in plan.jump_rotations: set_jump_rotation(jump_id, int(plan.jump_rotations[jump_id]))
	_policy_forecast.text = "已恢复上季度的完整训练比例。"

func set_allocations(allocations: Dictionary) -> void:
	var display_values := _legacy_units_to_shares(allocations) if _sum_values(allocations) == TrainingPlan.UNITS_PER_QUARTER else allocations
	for category_id in TrainingPlan.CATEGORY_IDS:
		if _allocation_inputs.has(category_id):
			_allocation_inputs[category_id].value = int(display_values.get(category_id, 0))
	_validate_plan()

func set_jump_rotation(jump_id: String, rotations: int) -> void:
	if not _rotation_inputs.has(jump_id): return
	var input: OptionButton = _rotation_inputs[jump_id]
	for index in input.item_count:
		if int(input.get_item_metadata(index)) == rotations:
			input.select(index)
			_validate_plan()
			return

func get_jump_rotation(jump_id: String) -> int:
	if not _rotation_inputs.has(jump_id): return 1
	var input: OptionButton = _rotation_inputs[jump_id]
	return int(input.get_item_metadata(input.selected)) if input.item_count > 0 else 1

func available_rotations(jump_id: String) -> Array[int]:
	var highest := 1
	if career != null and career.athlete.jumps.has(jump_id):
		highest = clampi(int(career.athlete.jumps[jump_id].unlocked_rotations) + 1, 1, 4)
	var result: Array[int] = []
	for rotations in range(1, highest + 1): result.append(rotations)
	return result

func request_advance() -> void:
	if not _pending_training_preflight(): return
	var plan_result := TrainingPlan.create(_current_allocations(), _current_jump_rotations())
	# Only this coach-button request owns the complete generated course.
	# Manual edits continue to create their own plan through the editor.
	var coach_course := _pending_coach_course
	_pending_coach_course = null
	if coach_course != null and plan_result.plan != null and coach_course.shares == plan_result.plan.shares and coach_course.jump_rotations == plan_result.plan.jump_rotations:
		plan_result.plan = TrainingPlan.from_dict(coach_course.to_dict())
	if not plan_result.errors.is_empty():
		_apply_plan_validation(plan_result)
		return
	if not _medical_preflight(plan_result.plan): return
	if not await _ensure_dated_training(): return
	if not _quarter_preflight(): return
	if _active_proposal == null or _active_proposal.desired.to_dict() != plan_result.plan.to_dict():
		_preview_authority(plan_result.plan)
	if _active_proposal.status != "resolved":
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = career.seed + career.rng_step * CareerSimulator.RNG_STEP_OFFSET + 17
	_pending_events = EventEngine.generate(career, _active_proposal, rng)
	_event_outcomes.clear()
	if not _pending_events.is_empty():
		event_dialog.present(_pending_events[0])
		return
	await _apply_pending_plan()

func resolve_event_choice(choice_id: String) -> void:
	if _pending_events.is_empty(): return
	if not _quarter_completed and (_active_proposal == null or not _medical_preflight(_active_proposal.executed)): return
	var event = _pending_events[0]
	if not event.choices.any(func(choice): return choice.id == choice_id): return
	var working := career.transaction_copy()
	var proposal = PlanProposal.from_dict(_active_proposal.to_dict()) if _active_proposal != null else null
	if _quarter_completed and not working.condition_state.get("pending_training_events",[]).is_empty():
		working.condition_state.pending_training_events.pop_front()
	var rng := RandomNumberGenerator.new()
	rng.seed = career.seed + career.rng_step * CareerSimulator.RNG_STEP_OFFSET + 31 + _event_outcomes.size()
	var outcomes := EventEngine.resolve(working, event, choice_id, rng, proposal)
	if proposal != null: working.last_generated_plan = proposal.to_dict()
	if _coach_period_pending and proposal != null:
		_set_response_period(working,proposal)
	if not await _commit_candidate(working):
		event_dialog.present(event)
		return
	_active_proposal = proposal
	_pending_events.pop_front()
	_event_outcomes.append_array(outcomes)
	if not _pending_events.is_empty():
		event_dialog.present(_pending_events[0])
	else:
		if _quarter_completed:
			_finish_completed_quarter()
		elif _coach_period_pending:
			_coach_period_pending = false
			event_dialog.hide()
			await continue_training()
		else:
			_apply_pending_plan()

func confirm_authority_adjustment() -> void:
	_on_authority_response("accept")

func _on_authority_response(response_id: StringName) -> void:
	if _active_proposal == null or _active_proposal.conflicts.is_empty():
		return
	if not _medical_preflight(_active_proposal.desired): return
	var result := CareerCommandService.apply(career, {"type":"resolve_authority_conflict", "proposal":_active_proposal.to_dict(), "conflict_id":_active_proposal.conflicts[0].id, "response_id":str(response_id)})
	if not result.ok:
		plan_error_label.text = result.error
		return
	if _coach_period_pending:
		var responded = PlanProposal.from_dict(result.career.last_generated_plan)
		_set_response_period(result.career,responded)
	if not await _commit_candidate(result.career): return
	_active_proposal = PlanProposal.from_dict(career.last_generated_plan)
	if str(response_id) == "ask_reason":
		authority_confirmation.dialog_text += "\n\n对方解释：现阶段的训练安全与基础，会影响以后能否持续进步。"
		return
	if _active_proposal.status == "resolved":
		authority_confirmation.hide()
		if _coach_period_pending:
			_coach_period_pending = false
			await continue_training()
	else:
		_show_current_conflict()

func _set_response_period(working: CareerState, proposal) -> void:
	if working.training_period_state.is_empty():
		working.training_period_state = {"weeks_elapsed":0,"intent":_training_intent.to_dict(),"plan":proposal.executed.to_dict(),"started_clock":working.clock.to_dict()}
	else:
		working.training_period_state["plan"] = proposal.executed.to_dict()

func _medical_preflight(plan) -> bool:
	if AthleteConditionService.can_train(career, plan): return true
	plan_error_label.text = "伤病恢复期间，请取消跳跃与节目合练，安排恢复训练。"
	return false

func _apply_pending_plan() -> void:
	if not preload("res://src/simulation/athlete_condition_service.gd").can_train(career, _active_proposal.executed):
		plan_error_label.text = "伤病恢复期间，请取消跳跃与节目合练，安排恢复训练。"
		return
	if not _quarter_preflight(): return
	advance_button.disabled = true
	plan_error_label.text = "正在推进季度并保存世界赛季，请稍候……"
	# Let the browser paint feedback before deterministic simulation and the
	# durable save occupy the main thread.
	if DisplayServer.get_name() != "headless": await get_tree().process_frame
	var working := career.transaction_copy()
	working.last_generated_plan = _active_proposal.to_dict()
	if career.competition_timeline.mode == "dated":
		var configured_command := {"type":"configure_dated_training","proposal":_active_proposal.to_dict()}
		if _dated_coach_requested: configured_command.intent = _training_intent.to_dict()
		var configured: Dictionary = CareerCommandService.apply(working,configured_command)
		if not configured.ok:
			advance_button.disabled = false;plan_error_label.text = str(configured.error);return
		if not await _commit_candidate(configured.career): advance_button.disabled = false;return
		var progression: Dictionary = await preload("res://src/simulation/season_progression_service.gd").advance_to_next_node_durable(career,season_bundle,func(candidate):return await _commit_candidate(candidate))
		advance_button.disabled = false
		_active_proposal = null;_preview_signature = "";_dated_coach_requested = false
		if not progression.errors.is_empty(): plan_error_label.text = "；".join(progression.errors);return
		_refresh_career_summary();_refresh_coach_proposal()
		if not progression.stop_node.is_empty(): advance_blocked.emit(progression.stop_node)
		return
	var result := CareerCommandService.apply(working,{"type":"advance_quarter","bundle":season_bundle})
	if not result.ok:
		var failure_message := str(result.get("stop_node",{}).get("reason",result.error))
		if result.has("stop_node"): advance_blocked.emit(result.stop_node)
		_validate_plan()
		plan_error_label.text = failure_message
		return
	if not await _commit_candidate(result.career):
		var persistence_message := plan_error_label.text
		_validate_plan()
		plan_error_label.text = persistence_message
		return
	var outcomes: Array = result.outcomes
	outcomes.append_array(_event_outcomes)
	_event_outcomes.clear()
	_completed_outcomes = outcomes
	_quarter_completed = true
	_active_proposal = null
	_preview_signature = ""
	_pending_events.clear()
	for data in career.condition_state.get("pending_training_events",[]):
		_pending_events.append(_training_event(data))
	if not _pending_events.is_empty():
		event_dialog.present(_pending_events[0])
		return
	_finish_completed_quarter()

func _training_event(data: Dictionary):
	var event = preload("res://src/domain/quarter_event.gd").new()
	for field in ["id","signature","title","description"]: event.set(field,str(data.get(field,"")))
	event.choices.assign(data.get("choices",[])); event.trigger_codes.assign(data.get("trigger_codes",[])); event.cause_ids.assign(data.get("cause_ids",[]))
	return event

func _quarter_preflight() -> bool:
	if career == null: return false
	var coordinator = preload("res://src/simulation/season_progression_service.gd")
	var node: Dictionary = coordinator._pending(career) if career.competition_timeline.mode == "dated" else coordinator.quarter_gate(career,season_bundle)
	return _accept_training_gate(node)

func _accept_training_gate(node: Dictionary) -> bool:
	if node.is_empty(): return true
	if str(node.get("kind", "")) == "internal_invitation":
		_present_teaching_invitation()
		return false
	plan_error_label.text = node.reason
	advance_blocked.emit(node)
	return false

func _ensure_dated_training() -> bool:
	# An open training screen may become stale after a decision is queued.
	# Surface that decision before even attempting a saved date migration.
	if not _pending_training_preflight(): return false
	if not preload("res://src/simulation/dated_training_service.gd").can_auto_activate(career): return true
	var begun: Dictionary = CareerCommandService.apply(career,{"type":"begin_dated_training"})
	if not begun.ok: plan_error_label.text = str(begun.error);return false
	return await _commit_candidate(begun.career)

func _pending_training_preflight() -> bool:
	if career == null: return false
	return _accept_training_gate(preload("res://src/simulation/season_progression_service.gd")._pending(career))

func _commit_candidate(candidate: CareerState) -> bool:
	# Normalize and persist the private transaction before publishing any state.
	var normalized := candidate.transaction_copy(true)
	var persistence_result = await persist.call(normalized) if persist.is_valid() else true
	var persisted := bool(persistence_result.get("ok",false)) if persistence_result is Dictionary else bool(persistence_result)
	if not persisted:
		var errors: Array = persistence_result.get("errors",[]) if persistence_result is Dictionary else []
		plan_error_label.text = "保存失败，进度未变更%s" % ("：" + "；".join(errors) if not errors.is_empty() else "")
		persistence_failed.emit()
		return false
	career.commit_from(normalized)
	return true

func _finish_completed_quarter() -> void:
	_completed_outcomes.append_array(_event_outcomes)
	_event_outcomes.clear()
	var outcomes := _completed_outcomes.duplicate()
	_completed_outcomes.clear()
	_quarter_completed = false
	quarter_advanced.emit(outcomes)

func _latest_roadmap_progress() -> Dictionary:
	for index in range(career.history.size() - 1, -1, -1):
		var entry: Dictionary = career.history[index]
		if entry.get("category") == "roadmap_progress":
			return entry
		if entry.get("category") == "quarter_plan":
			break
	return {}

func _on_allocation_changed(_value: float) -> void:
	_validate_plan()

func _validate_plan() -> void:
	_apply_plan_validation(TrainingPlan.create(_current_allocations(), _current_jump_rotations()))

func _apply_plan_validation(result: Dictionary) -> void:
	var total := 0
	for value in _current_allocations().values():
		total += int(value)
	allocation_total.text = "已分配 %d%% / 100%%" % total
	plan_error_label.text = "\n".join(result.errors)
	if not result.errors.is_empty(): authority_status_label.text = ""
	advance_button.disabled = not result.errors.is_empty() or career == null
	if result.errors.is_empty() and career != null:
		_preview_authority(result.plan)

func _preview_authority(plan: TrainingPlan) -> void:
	if _setting_up: return
	var signature := JSON.stringify(plan.to_dict())
	if signature == _preview_signature:
		return
	_preview_signature = signature
	_active_proposal = AuthorityResolver.preview(career, plan)
	if not _active_proposal.conflicts.is_empty():
		authority_status_label.text = "%s提出异议：%s" % ["监护人" if _active_proposal.conflicts[0].actor_id == "guardian" else "教练", REASON_LABELS.get(_active_proposal.conflicts[0].reason_code, "训练安排需要协商")]
		_show_current_conflict()
	else:
		authority_confirmation.hide()
		authority_status_label.text = "当前计划已获得家长与教练认可"

func _show_current_conflict() -> void:
	for button in _response_buttons:
		button.queue_free()
	_response_buttons.clear()
	var conflict = _active_proposal.conflicts[0]
	var decisions: Array = [{"reason_code": conflict.reason_code, "before": _active_proposal.desired.shares if not _active_proposal.desired.shares.is_empty() else _active_proposal.desired.allocations, "after": conflict.proposed_shares if not conflict.proposed_shares.is_empty() else conflict.proposed_allocations}]
	authority_confirmation.dialog_text = _describe_authority_decisions(decisions).replace("确认后才会推进季度。", "你可以回应，也可以返回修改自己的计划。")
	for response in conflict.responses:
		if response.id == "accept":
			continue
		var button := authority_confirmation.add_button(response.label, true, response.id)
		button.name = "Response_%s" % response.id
		_response_buttons.append(button)
	authority_confirmation.popup_centered(Vector2i(640, 300))

func _current_allocations() -> Dictionary:
	var allocations: Dictionary = {}
	for category_id in TrainingPlan.CATEGORY_IDS:
		allocations[category_id] = int(_allocation_inputs[category_id].value)
	return allocations

func _current_jump_rotations() -> Dictionary:
	var result := {}
	for jump_id in _rotation_inputs:
		result[jump_id] = get_jump_rotation(jump_id)
	return result

func _configure_share_input(input: SpinBox) -> void:
	input.custom_minimum_size = Vector2(92, 28)
	input.min_value = 0
	input.max_value = 100
	input.step = TrainingPlan.SHARE_STEP
	input.suffix = "%"

func _build_policy_ui() -> void:
	var plan: VBoxContainer = get_node("Layout/Columns/PlanPanel/PlanMargin/Plan")
	_advanced_editor = VBoxContainer.new()
	_advanced_editor.name = "AdvancedEditorContainer"
	for child in plan.get_children():
		plan.remove_child(child)
		_advanced_editor.add_child(child)
	_advanced_editor.visible = false

	var policy_mode := VBoxContainer.new()
	policy_mode.name = "PolicyModeContainer"
	var coach_heading := Label.new()
	coach_heading.text = "教练给你的本期安排"
	coach_heading.add_theme_font_size_override("font_size", 20)
	policy_mode.add_child(coach_heading)
	_coach_proposal_summary = Label.new()
	_coach_proposal_summary.name = "CoachProposalSummary"
	_coach_proposal_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_coach_proposal_summary.add_theme_font_size_override("font_size", 15)
	policy_mode.add_child(_coach_proposal_summary)
	var response_heading := Label.new()
	response_heading.text = "本期强度"
	response_heading.add_theme_font_size_override("font_size", 16)
	var focus_actions := HBoxContainer.new()
	policy_mode.add_child(focus_actions)
	var course_details := Button.new()
	course_details.name = "CoachCourseDetails"
	course_details.text = "本期课程"
	course_details.pressed.connect(_show_coach_courses)
	focus_actions.add_child(course_details)
	response_heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	focus_actions.add_child(response_heading)
	var edit_focus := Button.new(); edit_focus.name = "EditTrainingFocus"; edit_focus.text = "培养重点"; edit_focus.pressed.connect(open_training_focus); focus_actions.add_child(edit_focus)
	var external := Button.new(); external.name = "ExternalTraining"; external.text = "申请外训"; external.pressed.connect(open_external_training); focus_actions.add_child(external)
	var upgrade := Button.new(); upgrade.name = "ProgramUpgrade"; upgrade.text = "节目建议"; upgrade.pressed.connect(func(): program_upgrade_requested.emit()); focus_actions.add_child(upgrade)
	var intent_responses := GridContainer.new()
	intent_responses.name = "TrainingIntentResponses"
	intent_responses.columns = 2
	var intent_labels := {
		"accept":"就按教练说的",
		"safer":"这期稳一点",
		"more_aggressive":"我想冲快一点",
		"requested_element":"重点练一个动作",
	}
	var group := ButtonGroup.new()
	for intent_id in TrainingIntent.MODES:
		var button := Button.new()
		button.text = intent_labels[intent_id]
		button.toggle_mode = true
		button.button_group = group
		button.custom_minimum_size = Vector2(0, 38)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.add_theme_font_size_override("font_size",14)
		button.pressed.connect(select_training_intent.bind(intent_id))
		intent_responses.add_child(button)
		_intent_buttons[intent_id] = button
	policy_mode.add_child(intent_responses)
	_requested_element_picker = OptionButton.new()
	_requested_element_picker.name = "RequestedElementPicker"
	_requested_element_picker.visible = false
	_requested_element_picker.item_selected.connect(func(_index):
		if _training_intent != null and _training_intent.mode == "requested_element": select_training_intent("requested_element"))
	policy_mode.add_child(_requested_element_picker)
	policy_mode.add_child(HSeparator.new())
	_build_roadmap_card(policy_mode)
	var legacy := VBoxContainer.new()
	legacy.name = "LegacyPlanningControls"
	legacy.visible = false
	var recommendation_heading := Label.new(); recommendation_heading.text = "和教练商量本季度"; recommendation_heading.add_theme_font_size_override("font_size",20); policy_mode.add_child(recommendation_heading)
	_recommendation_note = Label.new(); _recommendation_note.name = "RecommendationNote"; _recommendation_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; policy_mode.add_child(_recommendation_note)
	_recommendation_list = VBoxContainer.new(); _recommendation_list.name = "RecommendationList"; _recommendation_list.add_theme_constant_override("separation",6); policy_mode.add_child(_recommendation_list)
	_custom_policy_container = VBoxContainer.new(); _custom_policy_container.name = "CustomPolicyContainer"; _custom_policy_container.visible = false; policy_mode.add_child(_custom_policy_container)
	var heading := Label.new(); heading.text = "自己调整训练方向"; heading.add_theme_font_size_override("font_size", 18); _custom_policy_container.add_child(heading)
	_policy_selector = OptionButton.new(); _policy_selector.name = "PolicySelector"
	var policy_labels := {"balanced_foundation": "均衡打基础", "rotation_push": "推进跳跃周数", "technique_rebuild": "技术重建", "competition_stability": "比赛稳定性", "recovery": "恢复调整"}
	for policy_id in TrainingPolicy.POLICY_IDS:
		_policy_selector.add_item(policy_labels[policy_id]); _policy_selector.set_item_metadata(_policy_selector.item_count - 1, policy_id)
	_policy_selector.item_selected.connect(func(index): set_policy(str(_policy_selector.get_item_metadata(index))))
	_custom_policy_container.add_child(_policy_selector)
	for slot in 2:
		var row := HBoxContainer.new()
		var label := Label.new(); label.text = "重点跳跃 %d" % (slot + 1); label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; row.add_child(label)
		var jump_input := OptionButton.new(); jump_input.name = "FocusJump%d" % slot; jump_input.add_item("不指定"); jump_input.set_item_metadata(0, "")
		for jump_id in TrainingPlan.JUMP_LABELS:
			jump_input.add_item(TrainingPlan.JUMP_LABELS[jump_id]); jump_input.set_item_metadata(jump_input.item_count - 1, jump_id)
		jump_input.item_selected.connect(_on_focus_jump_selected.bind(slot)); row.add_child(jump_input); _focus_jump_inputs.append(jump_input)
		var rotation_input := OptionButton.new(); rotation_input.name = "FocusRotation%d" % slot
		for rotations in range(1, 5):
			rotation_input.add_item("%d周" % rotations); rotation_input.set_item_metadata(rotation_input.item_count - 1, rotations)
		rotation_input.item_selected.connect(_on_focus_rotation_selected.bind(slot)); row.add_child(rotation_input); _focus_rotation_inputs.append(rotation_input)
		_custom_policy_container.add_child(row)
	var risk_row := HBoxContainer.new(); var risk_label := Label.new(); risk_label.text = "风险态度"; risk_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; risk_row.add_child(risk_label)
	_risk_selector = OptionButton.new()
	for risk in [["cautious", "谨慎"], ["normal", "正常"], ["aggressive", "激进"]]:
		_risk_selector.add_item(risk[1]); _risk_selector.set_item_metadata(_risk_selector.item_count - 1, risk[0])
	_risk_selector.select(1); _risk_selector.item_selected.connect(_on_risk_selected); risk_row.add_child(_risk_selector); _custom_policy_container.add_child(risk_row)
	_policy_forecast = Label.new(); _policy_forecast.name = "PolicyForecast"; _policy_forecast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; policy_mode.add_child(_policy_forecast)
	var actions := HBoxContainer.new(); var reuse := Button.new(); reuse.text = "沿用上季度方案"; reuse.pressed.connect(reuse_last_plan); actions.add_child(reuse)
	var custom_toggle := Button.new(); custom_toggle.name = "CustomPolicyToggle"; custom_toggle.text = "自己调整"; custom_toggle.toggle_mode = true; custom_toggle.toggled.connect(func(pressed): _custom_policy_container.visible = pressed); actions.add_child(custom_toggle)
	var advanced_toggle := Button.new(); advanced_toggle.text = "高级比例"; advanced_toggle.toggle_mode = true; advanced_toggle.toggled.connect(toggle_advanced_editor); actions.add_child(advanced_toggle); policy_mode.add_child(actions)
	plan.add_child(policy_mode)
	plan.add_child(_advanced_editor)
	# Progress and blocking explanations belong to the main action, not the
	# collapsed legacy editor. Keep its legacy authority overlay separate.
	authority_status_label.reparent(_advanced_editor)
	plan_error_label.reparent($Layout)
	$Layout.move_child(plan_error_label, advance_button.get_index())
	plan_error_label.custom_minimum_size = Vector2.ZERO
	plan_error_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	plan_error_label.add_theme_color_override("font_color", Color(0.96, 0.55, 0.48))
	recommendation_heading.reparent(legacy)
	_recommendation_note.reparent(legacy)
	_recommendation_list.reparent(legacy)
	_custom_policy_container.reparent(legacy)
	_policy_forecast.reparent(legacy)
	actions.reparent(legacy)
	policy_mode.add_child(legacy)

func _refresh_coach_proposal() -> void:
	if career == null or _coach_proposal_summary == null or _training_intent == null: return
	_refresh_requested_elements()
	var built := _actual_coach_course()
	if built.plan == null:
		_coach_proposal_summary.text = "教练暂时不能接受这个要求：%s" % "；".join(built.errors)
		advance_button.disabled = true
		return
	var plan: TrainingPlan = built.plan
	var jump_focus: Array[String] = []
	for jump_id in TrainingPlan.JUMP_LABELS:
		jump_focus.append("%s%s" % [TrainingPlan.JUMP_LABELS[jump_id], _rotation_label(int(plan.jump_rotations.get(jump_id, 1)))])
	var direction := {"accept":"完整训练，兼顾跳跃与基础。", "safer":"降低负荷，给身体和动作更多恢复时间。", "more_aggressive":"加快技术积累，同时保留恢复训练。", "requested_element":"重点练指定动作，其余课程仍会继续。"}
	built.plan = plan
	var coaching: Dictionary = preload("res://src/presentation/coach_training_presenter.gd").proposal(career,built)
	_coach_proposal_summary.text = coaching.headline+"\n滑行%d%% · 跳跃%d%% · 旋转%d%% · 恢复%d%%" % [int(plan.shares.skating_foundation),_jump_share(plan.shares),int(plan.shares.rotation),int(plan.shares.rest)]
	_coach_proposal_summary.tooltip_text = "%s\n%s\n跳跃安排：%s" % [direction.get(_training_intent.mode,"完整训练"),"；".join(built.reasons), "、".join(jump_focus)]
	if not career.training_direction.focuses.is_empty():
		_coach_proposal_summary.text = coaching.headline+"\n"+load("res://src/presentation/training_focus_presenter.gd").build(career).summary
	var elapsed := clampi(int(career.training_period_state.get("weeks_elapsed",0)),0,12)
	advance_button.text = "处理当前安排，继续剩余%d周训练" % (12-elapsed) if elapsed > 0 else "按这个方向训练本期（12周）"
	if not career.season_state.get("season_history",{}).is_empty() and not _continuous_running: advance_button.text = "按当前重点连续训练，直到阶段验收或赛事"
	if career.competition_timeline.mode == "dated": advance_button.text = "按当前方向训练至下一赛期或必要决定"
	plan_error_label.text = ""

func _show_coach_courses() -> void:
	if career == null: return
	var built: Dictionary = _actual_coach_course()
	var coaching: Dictionary = preload("res://src/presentation/coach_training_presenter.gd").proposal(career,built)
	var dialog = get_node_or_null("CoachCourseDialog")
	if dialog == null:
		dialog = preload("res://src/app/readable_information_dialog.gd").new()
		dialog.name = "CoachCourseDialog"
		dialog.visible = false
		add_child(dialog)
	dialog.present("本期教练课程",[{"heading":coaching.headline,"body":coaching.detail}])
	advance_button.disabled = false

func _actual_coach_course() -> Dictionary:
	var agreed = TrainingPlan.from_dict(career.training_period_state.get("plan",{}))
	if agreed != null:
		return {"plan":agreed,"errors":[],"reasons":["本期按原有约定执行；新的路线与重点用于下一期，不重排已经约定的课程。"]}
	return CoachTrainingPlanService.build(career,_training_intent)

func _compact_jump_plan(plan) -> String:
	var rotations := {}
	for jump_id in TrainingPlan.JUMP_LABELS: rotations[int(plan.jump_rotations.get(jump_id,1))] = true
	if rotations.size() == 1: return "六类跳跃均练%s" % _rotation_label(int(rotations.keys()[0]))
	var codes := {"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz","axel":"A"}
	var entries: Array[String] = []
	for jump_id in TrainingPlan.JUMP_LABELS: entries.append("%d%s" % [int(plan.jump_rotations.get(jump_id,1)),codes[jump_id]])
	return " / ".join(entries)

func _refresh_requested_elements() -> void:
	if _requested_element_picker == null: return
	var selected_id := ""
	if _requested_element_picker.item_count > 0:
		selected_id = str(_requested_element_picker.get_item_metadata(_requested_element_picker.selected))
	_requested_element_picker.clear()
	for jump_id in TrainingPlan.JUMP_LABELS:
		var max_rotation := mini(4, int(career.athlete.jumps[jump_id].unlocked_rotations) + 1)
		for rotations in range(1, max_rotation + 1):
			var element_id := "jump:%s:%d" % [jump_id, rotations]
			var checked := TrainingIntent.create("requested_element", element_id)
			if checked.intent == null: continue
			if CoachTrainingPlanService.build(career, checked.intent).plan == null: continue
			_requested_element_picker.add_item("%s · %s" % [TrainingPlan.JUMP_LABELS[jump_id], _rotation_label(rotations)])
			_requested_element_picker.set_item_metadata(_requested_element_picker.item_count - 1, element_id)
			if element_id == selected_id: _requested_element_picker.select(_requested_element_picker.item_count - 1)

func _jump_share(shares: Dictionary) -> int:
	var total := 0
	for jump_id in TrainingPlan.JUMP_LABELS: total += int(shares.get("jump_%s" % jump_id, 0))
	return total

func _rotation_label(rotations: int) -> String:
	return {1:"单周", 2:"双周", 3:"三周", 4:"四周"}.get(rotations, "%d周" % rotations)

func _refresh_recommendations() -> void:
	if career == null or _recommendation_list == null: return
	for child in _recommendation_list.get_children(): child.queue_free()
	var presentation := TrainingRecommendationPresenter.for_career(career,catalog)
	_recommendations.assign(presentation.options)
	_recommendation_note.text = str(presentation.coach_note)
	for option in _recommendations:
		var button := Button.new()
		button.custom_minimum_size = Vector2(0,52)
		button.text = "%s%s\n%s" % ["推荐｜" if bool(option.recommended) else "",str(option.title),str(option.benefit)]
		button.tooltip_text = "取舍：%s" % str(option.tradeoff)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.pressed.connect(choose_recommendation.bind(str(option.id)))
		_recommendation_list.add_child(button)

func _build_roadmap_card(parent: VBoxContainer) -> void:
	var card := VBoxContainer.new(); card.name = "RoadmapCard"
	_roadmap_status = Label.new(); _roadmap_status.name = "RoadmapStatus"; _roadmap_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; card.add_child(_roadmap_status)
	_roadmap_button = Button.new(); _roadmap_button.name = "RoadmapButton"; _roadmap_button.pressed.connect(func(): _roadmap_dialog.begin(career)); card.add_child(_roadmap_button)
	parent.add_child(card)

func _refresh_roadmap_card() -> void:
	if _roadmap_status == null or career == null: return
	if career.development_roadmap.is_empty():
		_roadmap_status.text = "成长路线尚未制定，可稍后安排。"
		_roadmap_button.text = "制定成长路线"
		return
	var roadmap = DevelopmentRoadmap.from_dict(career.development_roadmap)
	var evaluation := DevelopmentRoadmapEvaluator.evaluate(career, roadmap)
	var status_labels := {"ahead": "领先", "on_track": "按计划", "slightly_behind": "轻微落后", "far_behind": "明显落后", "reassess": "需要重估"}
	_roadmap_status.text = "成长路线：%s｜教练判断：%s" % [roadmap.route_id, status_labels[evaluation.status]]
	_roadmap_button.text = "重新评估路线"

func _on_focus_jump_selected(index: int, slot: int) -> void:
	_focus_slots[slot].jump_id = str(_focus_jump_inputs[slot].get_item_metadata(index))
	_generate_policy_plan()

func _on_focus_rotation_selected(index: int, slot: int) -> void:
	_focus_slots[slot].rotations = int(_focus_rotation_inputs[slot].get_item_metadata(index))
	_generate_policy_plan()

func _on_risk_selected(index: int) -> void:
	_risk_attitude = str(_risk_selector.get_item_metadata(index))
	_generate_policy_plan()

func _generate_policy_plan() -> void:
	if career == null: return
	var focus_jumps: Array[String] = []
	var targets := {}
	for slot in _focus_slots:
		var jump_id := str(slot.jump_id)
		if jump_id.is_empty() or focus_jumps.has(jump_id): continue
		focus_jumps.append(jump_id); targets[jump_id] = int(slot.rotations)
	var policy_result := TrainingPolicy.create(_policy_id, focus_jumps, targets, _risk_attitude)
	if not policy_result.errors.is_empty():
		_policy_forecast.text = "\n".join(policy_result.errors); return
	var result := TrainingPolicyPlanner.build(career, policy_result.policy, catalog)
	if result.plan == null:
		_policy_forecast.text = "\n".join(result.reasons); return
	set_allocations(result.plan.shares)
	for jump_id in result.plan.jump_rotations: set_jump_rotation(jump_id, int(result.plan.jump_rotations[jump_id]))
	_policy_forecast.text = "%s\n预计负荷：%s｜成人异议：%s" % ["；".join(result.reasons), result.forecast.load_band, "可能" if result.forecast.adult_objection else "暂无"]

func _select_metadata(input: OptionButton, value) -> void:
	for index in input.item_count:
		if input.get_item_metadata(index) == value:
			input.select(index); return

func _make_plan_scrollable() -> void:
	var plan: Control = get_node("Layout/Columns/PlanPanel/PlanMargin/Plan")
	var parent := plan.get_parent()
	var scroll := ScrollContainer.new()
	scroll.name = "PlanScroll"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.remove_child(plan)
	scroll.add_child(plan)
	parent.add_child(scroll)

func _sum_values(values: Dictionary) -> int:
	var total := 0
	for value in values.values(): total += int(value)
	return total

func _legacy_units_to_shares(units: Dictionary) -> Dictionary:
	var result := {}
	var assigned := 0
	for category_id in TrainingPlan.CATEGORY_IDS:
		var share := int(floor(float(int(units.get(category_id, 0))) * 100.0 / 12.0 / 5.0)) * 5
		result[category_id] = share
		assigned += share
	var index := 0
	while assigned < 100:
		var category_id: String = TrainingPlan.CATEGORY_IDS[index % TrainingPlan.CATEGORY_IDS.size()]
		if int(units.get(category_id, 0)) > 0:
			result[category_id] += 5
			assigned += 5
		index += 1
	return result

func _refresh_rotation_choices() -> void:
	var labels := {1: "单周", 2: "双周", 3: "三周", 4: "四周"}
	for jump_id in _rotation_inputs:
		var input: OptionButton = _rotation_inputs[jump_id]
		var previous := get_jump_rotation(jump_id)
		input.clear()
		for rotations in available_rotations(jump_id):
			input.add_item(labels[rotations])
			input.set_item_metadata(input.item_count - 1, rotations)
		set_jump_rotation(jump_id, mini(previous, available_rotations(jump_id)[-1]))

func _refresh_program_training_inputs() -> void:
	if career == null:
		return
	for segment in ["short", "free"]:
		var input: SpinBox = _allocation_inputs["program_%s" % segment]
		var available := not Dictionary(career.active_programs.get(segment, {})).is_empty()
		input.editable = available
		if not available:
			input.value = 0
		input.tooltip_text = "已有节目：可分配整套、动作顺序与连接合练" if available else "尚无对应节目，请先选曲并编排"

func _refresh_career_summary() -> void:
	if career == null or career.clock == null or career.athlete == null:
		return
	var age := career.clock.age_on(career.athlete.birth_year)
	date_label.text = "%d年 第%d季度 · %d岁 · %s" % [
		career.clock.year,
		career.clock.quarter,
		age,
		career.athlete.display_name,
	]
	var elapsed := clampi(int(career.training_period_state.get("weeks_elapsed",0)),0,12)
	if elapsed > 0:
		date_label.text = "%d年 第%d季度 · 本期已练%d周，剩余%d周" % [career.clock.year,career.clock.quarter,elapsed,12-elapsed]
	var technique := career.athlete.technique
	technique_summary.text = "技术：滑行基础 %.1f｜单跳综合 %.1f｜旋转 %.1f｜落冰 %.1f" % [
		float(career.athlete.skating.get("deep_edge", 0.0)),
		_average_single_jump_proficiency(),
		float(technique.get("rotation", 0.0)),
		float(technique.get("landing", 0.0)),
	]
	jump_mastery_summary.text = _describe_jump_mastery()
	var body := career.athlete.body
	body_summary.text = "身体：即时疲劳 %.1f｜累积疲劳 %.1f｜踝部负荷 %.1f｜成长趋势 %.1f" % [
		float(body.get("acute_fatigue", 0.0)),
		float(body.get("cumulative_fatigue", 0.0)),
		float(body.get("ankle_load", 0.0)),
		float(body.get("growth_trend", 0.0)),
	]
	motivation_summary.text = "训练动力：%.1f（%s）" % [
		float(career.athlete.mind.get("motivation", 0.0)),
		_describe_level(float(career.athlete.mind.get("motivation", 0.0))),
	]
	resources_summary.text = "资源：训练资金 %.1f｜冰时条件 %.1f" % [
		float(career.athlete.resources.get("money", 0.0)),
		float(career.athlete.resources.get("ice_access", 0.0)),
	]
	relationships_summary.text = _describe_relationships()

func _describe_relationships() -> String:
	var descriptions: Array[String] = []
	if career.relationships.has("guardian"):
		var guardian = career.relationships.guardian
		descriptions.append("监护人：亲近%s、控制%s、健康优先%s" % [
			_describe_level(guardian.closeness),
			_describe_level(guardian.control),
			_describe_level(guardian.health_priority),
		])
	if career.relationships.has("coach"):
		var coach = career.relationships.coach
		descriptions.append("教练：亲近%s、专业信任%s" % [
			_describe_level(coach.closeness),
			_describe_level(coach.professional_trust),
		])
	return "\n".join(descriptions)

func _describe_jump_mastery() -> String:
	var lines: Array[String] = ["动作掌握（成功区间会随状态变化）"]
	var available_triples := 0
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		var ready: Dictionary = preload("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,id,3)
		var code: String = "3"+str(preload("res://src/domain/technical_repertoire.gd").CODES[id])
		if ready.stage_id in ["official_ready","core"] and career.technical_repertoire.entries.get(code,{}).get("state") == "available": available_triples += 1
	lines.append("五种普通三周储备：%d/5正式比赛可用（不含3A；不代表每场必成）。" % available_triples)
	var rotation_labels := ["未解锁", "单周", "双周", "三周", "四周"]
	for jump_id in ["toe_loop", "salchow", "loop", "flip", "lutz", "axel"]:
		var profile = career.athlete.jumps[jump_id]
		var view := JumpMasteryView.describe(profile, career.athlete.body)
		var rotations: int = clampi(int(profile.unlocked_rotations), 0, 4)
		var current: Dictionary = preload("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,jump_id,maxi(1,rotations))
		lines.append("%s·%s｜%s｜训练预估 %d%%～%d%%｜%s" % [
			CATEGORY_LABELS["jump_%s" % jump_id], rotation_labels[rotations], current.stage_label,
			view.success_min, view.success_max, view.issue_text,
		])
	return "\n".join(lines)

func _average_single_jump_proficiency() -> float:
	var total := 0.0
	for profile in career.athlete.jumps.values():
		total += float(profile.proficiency.single)
	return total / maxf(1.0, float(career.athlete.jumps.size()))

func _describe_level(value: float) -> String:
	if value >= 70.0:
		return "高"
	if value >= 40.0:
		return "中"
	return "低"

func _describe_authority_decisions(decisions: Array) -> String:
	var lines: Array[String] = ["人物对训练计划作出了修改："]
	for decision in decisions:
		var changes: Array[String] = []
		var before: Dictionary = decision.get("before", {})
		var after: Dictionary = decision.get("after", {})
		for category_id in TrainingPlan.CATEGORY_IDS:
			if before.get(category_id) != after.get(category_id):
				changes.append("%s %d → %d" % [
					CATEGORY_LABELS[category_id],
					int(before.get(category_id, 0)),
					int(after.get(category_id, 0)),
				])
		lines.append("%s：%s。" % [
			REASON_LABELS.get(str(decision.get("reason_code", "")), "人物调整训练计划"),
			"，".join(changes),
		])
	lines.append("确认后才会推进季度。")
	return "\n".join(lines)

