class_name PreCompetitionChecklistService
extends RefCounted

const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Validator = preload("res://src/simulation/program_validator.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Condition = preload("res://src/simulation/athlete_condition_service.gd")

static func inspect(career, event: Dictionary) -> Dictionary:
	if career == null or event.is_empty(): return {"ready":false,"items":[],"actions":[],"errors":["缺少选手或赛事资料"]}
	var resolved := Bundle.competition_for_career(career,event)
	if not resolved.errors.is_empty(): return {"ready":false,"items":[],"actions":_exit_actions(event),"errors":resolved.errors}
	var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(career,resolved.event)
	var items: Array[Dictionary] = []
	var ready := true
	for segment in ["short", "free"]:
		var rules: Dictionary = resolved.rules[segment].segment_rules
		var saved: Dictionary = event_programs.get(segment, {})
		var program = Program.from_dict(saved)
		var validation: Array[String] = Validator.validate(program, career.athlete, rules)
		if validation.is_empty():
			var season_confirmed: bool = career.season_program_plan.get("status") == "confirmed" and career.season_program_plan.get("programs",{}).get(segment,{}) == saved
			if (program.draft_status == "locked" and program.locked_segments.has(segment)) or season_confirmed:
				items.append(_program_item(segment,"ready","节目符合本场规则，且已锁定参赛版本",[]))
				continue
			ready = false
			items.append(_program_item(segment,"repairable","节目内容合规，但仍是草稿；请检查后锁定参赛版本",[
				{"id":"edit_program","segment":segment,"label":"检查并锁定节目"},
			]))
			continue
		ready = false
		var music: Dictionary = Dictionary(saved.get("music", {"title":"新赛季节目"})).duplicate(true)
		var draft := Draft.legal_draft(career.athlete,segment,rules,music,career.seed + (1 if segment == "short" else 2))
		if draft.program != null:
			items.append(_program_item(segment,"repairable","当前节目不合规：%s" % "；".join(validation),[
				{"id":"adopt_coach_program","segment":segment,"label":"采用并锁定教练合规方案"},
				{"id":"edit_program","segment":segment,"label":"自己调整节目"},
			]))
		else:
			items.append(_program_item(segment,"blocked","当前已掌握动作不足以满足本场规则：%s" % "；".join(draft.missing),[
				{"id":"edit_program","segment":segment,"label":"查看节目与规则"},
			]))
	var medically_ready := Condition.can_compete(career,event_programs)
	items.append({"id":"health","label":"身体状态","status":"ready" if medically_ready else "blocked","reason":"身体状态允许比赛" if medically_ready else "伤病或负荷状态暂不允许参赛","actions":[]})
	ready = ready and medically_ready
	return {"ready":ready,"items":items,"actions":_exit_actions(event),"errors":[]}

static func repair(career, event: Dictionary, requested_segments: Array = ["short", "free"]) -> Dictionary:
	if career == null: return {"programs":{},"errors":["缺少选手资料"]}
	var resolved := Bundle.competition_for_career(career,event)
	if not resolved.errors.is_empty(): return {"programs":{},"errors":resolved.errors}
	var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(career,resolved.event)
	var programs := {}
	var errors: Array[String] = []
	for segment in requested_segments:
		if not ["short","free"].has(segment): errors.append("未知节目阶段：%s" % segment); continue
		var saved: Dictionary = event_programs.get(segment,{})
		var music: Dictionary = Dictionary(saved.get("music", {"title":"新赛季节目"})).duplicate(true)
		var draft := Draft.legal_draft(career.athlete,segment,resolved.rules[segment].segment_rules,music,career.seed + (1 if segment == "short" else 2))
		if draft.program == null:
			errors.append("%s：%s" % [_segment_label(segment),"；".join(draft.missing if not draft.missing.is_empty() else draft.errors)])
		else:
			programs[segment] = draft.program.to_dict()
	return {"programs":programs,"errors":errors}

static func _program_item(segment: String, status: String, reason: String, actions: Array) -> Dictionary:
	return {"id":"program_%s" % segment,"label":"%s节目" % _segment_label(segment),"status":status,"reason":reason,"actions":actions}

static func _segment_label(segment: String) -> String:
	return "短" if segment == "short" else "自由滑"

static func _exit_actions(event: Dictionary) -> Array[Dictionary]:
	return [
		{"id":"return_to_season","label":"返回赛季主页"},
		{"id":"withdraw","event_id":str(event.get("event_id","")),"label":"暂不参赛或退赛"},
	]
