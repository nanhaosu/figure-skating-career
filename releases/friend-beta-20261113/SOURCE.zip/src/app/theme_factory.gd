class_name ThemeFactory
extends RefCounted

const BACKGROUND := Color("07131d")
const SURFACE_PRIMARY := Color("102534")
const SURFACE_SECONDARY := Color("183244")
const DIVIDER := Color("315064")
const INK := Color("eef5f9")
const MUTED := Color("9db1bf")
const ICE := SURFACE_PRIMARY
const ICE_RAISED := SURFACE_SECONDARY
const ICE_BLUE := Color("79c8e8")
const GOLD := Color("e2b96b")
const GOLD_DARK := Color("2c2518")
const DANGER := Color("df7379")

static func semantic_palette() -> Dictionary:
	return {
		"background": BACKGROUND,
		"surface_primary": SURFACE_PRIMARY,
		"surface_secondary": SURFACE_SECONDARY,
		"divider": DIVIDER,
		"text": INK,
		"text_muted": MUTED,
		"ice_blue": ICE_BLUE,
		"gold": GOLD,
		"danger": DANGER,
	}

static func create() -> Theme:
	var result := Theme.new()
	result.default_font = load("res://assets/fonts/NotoSansCJKsc-Regular.otf")
	result.default_font_size = 17
	result.set_color("font_color","Label",INK)
	result.set_color("font_color","Button",INK)
	result.set_color("font_hover_color","Button",Color.WHITE)
	result.set_color("font_pressed_color","Button",GOLD_DARK)
	result.set_stylebox("normal","Button",_box(ICE_RAISED,12,Color("355368")))
	result.set_stylebox("hover","Button",_box(Color("29485e"),12,GOLD))
	result.set_stylebox("pressed","Button",_box(GOLD,12,GOLD))
	result.set_stylebox("disabled","Button",_box(Color("22303a"),12,Color("31414d")))
	result.set_constant("outline_size","Label",0)
	result.set_constant("separation", "VBoxContainer", 8)
	result.set_constant("separation", "HBoxContainer", 8)
	result.set_stylebox("panel", "PanelContainer", _box(SURFACE_PRIMARY, 6, DIVIDER, 10))
	result.set_stylebox("panel", "AcceptDialog", _box(SURFACE_PRIMARY, 6, DIVIDER, 20))
	result.set_stylebox("panel", "PopupMenu", _box(SURFACE_PRIMARY, 6, DIVIDER, 8))
	result.set_stylebox("hover", "PopupMenu", _box(SURFACE_SECONDARY, 4, ICE_BLUE, 4))
	result.set_color("font_color", "PopupMenu", INK)
	result.set_color("font_hover_color", "PopupMenu", INK)
	result.set_stylebox("panel", "ItemList", _box(SURFACE_PRIMARY, 6, DIVIDER, 4))
	result.set_stylebox("selected", "ItemList", _box(SURFACE_SECONDARY, 4, ICE_BLUE, 4))
	result.set_stylebox("selected_focus", "ItemList", _box(SURFACE_SECONDARY, 4, ICE_BLUE, 4))
	result.set_color("font_color", "ItemList", INK)
	result.set_color("font_selected_color", "ItemList", INK)
	result.set_constant("buttons_min_height", "AcceptDialog", 40)
	result.set_constant("buttons_separation", "AcceptDialog", 16)
	result.set_color("title_color", "Window", INK)
	result.set_font("title_font", "Window", result.default_font)
	result.set_font_size("title_font_size", "Window", 17)
	for state in ["embedded_border", "embedded_unfocused_border"]:
		# Keep the engine's title/resize geometry; replace only the default
		# gray chrome with the same surfaces as the career workspace.
		var frame: StyleBoxFlat = ThemeDB.get_default_theme().get_stylebox(state, "Window").duplicate()
		frame.bg_color = SURFACE_PRIMARY
		frame.border_color = DIVIDER
		frame.set_corner_radius_all(6)
		result.set_stylebox(state, "Window", frame)
	_button_variation(result, "PrimaryButton", GOLD, GOLD, GOLD_DARK)
	_button_variation(result, "SecondaryButton", SURFACE_SECONDARY, ICE_BLUE, INK)
	_button_variation(result, "GhostButton", Color(0, 0, 0, 0), DIVIDER, INK)
	_button_variation(result, "DangerButton", Color(DANGER, 0.18), DANGER, INK)
	_button_variation(result, "NavButton", Color(0, 0, 0, 0), Color(0, 0, 0, 0), MUTED)
	_button_variation(result, "SelectedNavButton", Color(ICE_BLUE, 0.16), ICE_BLUE, ICE_BLUE)
	return result

static func _button_variation(theme: Theme, variation: String, background: Color, border: Color, font_color: Color) -> void:
	theme.set_type_variation(variation, "Button")
	for state in ["normal", "hover", "pressed"]:
		var state_background := background.lightened(0.05) if state == "hover" else background
		theme.set_stylebox(state, variation, _box(state_background, 6, border, 10))
		theme.set_color("font_%s_color" % state if state != "normal" else "font_color", variation, font_color)
	# Disabled actions share a muted surface across semantic button roles.
	theme.set_stylebox("disabled", variation, _box(Color("22303a"), 6, Color("31414d"), 10))
	theme.set_color("font_disabled_color", variation, MUTED)

static func card_style() -> StyleBoxFlat:
	return _box(ICE,16,Color("2a485d"))

static func primary_style() -> StyleBoxFlat:
	return _box(GOLD,14,GOLD)

static func _box(color: Color, radius: int, border: Color, padding: int = 12) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.border_color = border
	box.set_border_width_all(1)
	box.set_corner_radius_all(radius)
	box.content_margin_left = padding
	box.content_margin_right = padding
	box.content_margin_top = padding
	box.content_margin_bottom = padding
	return box

