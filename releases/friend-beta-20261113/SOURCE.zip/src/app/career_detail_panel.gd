extends MarginContainer
signal close_requested
signal action_requested(action_id: String)
var _rows: Array = []
var _page := 0
var _list: ItemList
var _detail: Label
var _title: Label
var _subtitle: Label
var _page_label: Label
var _action: Button
const PAGE_SIZE := 6
func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: add_theme_constant_override("margin_"+side,20)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",10)
	add_child(box)
	var heading := HBoxContainer.new()
	box.add_child(heading)
	_title = Label.new()
	_title.add_theme_font_size_override("font_size",26)
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.add_child(_title)
	var close := Button.new()
	close.name = "CloseButton"
	close.text = "返回"
	close.pressed.connect(func(): close_requested.emit())
	heading.add_child(close)
	_subtitle = Label.new()
	_subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(_subtitle)
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(body)
	_list = ItemList.new()
	_list.custom_minimum_size.x = 220
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.item_selected.connect(_select)
	body.add_child(_list)
	_detail = Label.new()
	_detail.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_detail.size_flags_stretch_ratio = 1.3
	_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_detail.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	body.add_child(_detail)
	var footer := HBoxContainer.new()
	box.add_child(footer)
	for delta in [-1,1]:
		var button := Button.new()
		button.text = "上一页" if delta < 0 else "下一页"
		button.pressed.connect(func(): _page = clampi(_page+delta,0,maxi(0,(_rows.size()-1)/PAGE_SIZE)); _render())
		footer.add_child(button)
	_page_label = Label.new()
	footer.add_child(_page_label)
	_action = Button.new()
	_action.pressed.connect(func(): action_requested.emit(str(_action.get_meta("action_id",""))))
	footer.add_child(_action)
func present(view_model: Dictionary) -> void:
	_title.text = str(view_model.get("title",""))
	_subtitle.text = str(view_model.get("subtitle",""))
	_rows = Array(view_model.get("rows",[])).duplicate(true)
	if _rows.is_empty(): _rows = [{"label":"暂无记录","detail":str(view_model.get("empty","暂无记录"))}]
	_page = 0
	_render()
func _render() -> void:
	_list.clear()
	for row in _rows.slice(_page*PAGE_SIZE,(_page+1)*PAGE_SIZE): _list.add_item(str(row.label))
	_page_label.text = "%d / %d" % [_page+1,maxi(1,ceili(float(_rows.size())/PAGE_SIZE))]
	_list.select(0)
	_select(0)
func _select(index: int) -> void:
	var row: Dictionary = _rows[_page*PAGE_SIZE+index]
	_detail.text = str(row.get("detail",""))
	_action.visible = row.has("action_id")
	_action.text = str(row.get("action_label",""))
	_action.set_meta("action_id",row.get("action_id",""))
