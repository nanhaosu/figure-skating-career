extends Window

signal command_requested(command: Dictionary)
var _career
var _offers: Array = []
var _picker: OptionButton
var _description: Label
var _confirm: Button
var _cancel_booking: Button
var _booking_id := ""

func _ready() -> void:
	title = "申请专项外训"
	size = Vector2i(620,520); min_size = Vector2i(620,520); transient = true; exclusive = true
	close_requested.connect(hide)
	var margin := MarginContainer.new(); margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,18)
	add_child(margin)
	var background := ColorRect.new(); background.color = Color("#102332"); background.mouse_filter = Control.MOUSE_FILTER_IGNORE; margin.add_child(background)
	var layout := VBoxContainer.new(); layout.add_theme_constant_override("separation",14); margin.add_child(layout)
	var heading := Label.new(); heading.text = "外训服务于当前重点，不是第三份额外训练。"; layout.add_child(heading)
	_picker = OptionButton.new(); _picker.name = "ExternalCourse"; _picker.item_selected.connect(func(_index): _refresh()); layout.add_child(_picker)
	_description = Label.new(); _description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; _description.size_flags_vertical = Control.SIZE_EXPAND_FILL; layout.add_child(_description)
	_cancel_booking = Button.new(); _cancel_booking.text = "取消已预约外训，退还未执行课程费用"; _cancel_booking.pressed.connect(func(): command_requested.emit({"type":"cancel_external_training","booking_id":_booking_id,"receipt_id":"cancel:"+_booking_id})); layout.add_child(_cancel_booking)
	var row := HBoxContainer.new(); layout.add_child(row)
	var back := Button.new(); back.text = "返回，不预约"; back.custom_minimum_size = Vector2(140,38); back.pressed.connect(hide); row.add_child(back)
	_confirm = Button.new(); _confirm.text = "确认预约并支付"; _confirm.custom_minimum_size.y = 38; _confirm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_confirm.pressed.connect(_book); row.add_child(_confirm)

func present(career) -> void:
	_career = career
	_offers = load("res://src/simulation/external_training_service.gd").offers(career)
	_picker.clear()
	for offer in _offers:
		_picker.add_item("%s · %s" % [offer.course.name,load("res://src/presentation/training_focus_presenter.gd").label(offer.focus)])
	_booking_id = ""
	for booking in career.training_direction.external_schedule:
		if booking.status == "booked": _booking_id = booking.id; break
	_cancel_booking.visible = not _booking_id.is_empty()
	set_busy(false); _refresh(); popup_centered(Vector2i(620,520))

func set_busy(busy: bool) -> void:
	_picker.disabled = busy; _confirm.disabled = busy or _offers.is_empty(); _cancel_booking.disabled = busy

func show_error(message: String) -> void:
	set_busy(false); _description.text = message

func _refresh() -> void:
	_confirm.disabled = _offers.is_empty()
	if _offers.is_empty():
		_description.text = "请先在培养重点中选择想提升的方向，再来寻找匹配课程。\n目前有跳跃、滑行步法、音乐表达和旋转专项。"
		return
	var offer: Dictionary = _offers[_picker.selected]
	var year: int = _career.clock.year; var quarter: int = _career.clock.quarter
	if int(_career.training_period_state.get("weeks_elapsed",0)) > 0:
		quarter += 1
		if quarter > 4: quarter = 1; year += 1
	_description.text = "%s\n\n安排：%d年第%d季度，共四个训练阶段。替代原有专项课程，不额外加量。\n费用：%d训练资金；当前资金：%.1f（游戏资源单位，非人民币）。\n\n退款：未开始全退；开始后只退未执行阶段，整数余款计入最后阶段。重大伤病中止同规则。\n保留长期教练；不保证突破或比赛得分。" % [offer.course.description,year,quarter,int(offer.course.cost),float(_career.athlete.resources.money)]

func _book() -> void:
	if _offers.is_empty(): return
	var offer: Dictionary = _offers[_picker.selected]
	command_requested.emit({"type":"book_external_training","offer_id":offer.course.id,"focus_id":offer.focus.id,"receipt_id":"external:%d:%d:%d:%s" % [_career.clock.year,_career.clock.quarter,int(_career.training_direction.revision),offer.course.id]})
