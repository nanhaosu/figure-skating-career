class_name EventDialog
extends Window

signal event_choice(event_id: String, choice_id: String)

var _event_id := ""
@onready var event_title: Label = %EventTitle
@onready var event_description: Label = %EventDescription
@onready var choice_buttons: VBoxContainer = %ChoiceButtons

func _ready() -> void:
	close_requested.connect(hide)

func present(event) -> void:
	_event_id = event.id
	event_title.text = event.title
	event_description.text = event.description
	for child in choice_buttons.get_children(): child.queue_free()
	for choice in event.choices:
		var button := Button.new()
		button.text = choice.label
		button.custom_minimum_size = Vector2(0, 42)
		button.pressed.connect(_choose.bind(str(choice.id)))
		choice_buttons.add_child(button)
	popup_centered(Vector2i(620, 380))

func _choose(choice_id: String) -> void:
	hide()
	event_choice.emit(_event_id, choice_id)
