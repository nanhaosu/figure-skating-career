extends RefCounted

const Progression = preload("res://src/simulation/season_progression_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")

static func run(main, keep_running: Callable, progress: Callable, max_steps: int = 32) -> Dictionary:
	var result: Dictionary = {"node":{},"ledger":[],"completed_events":[],"reason":"step_limit","errors":[]}
	if main.active_career == null: result.reason = "no_career"; return result
	var initial_count: int = main.active_career.competition_archive.size()
	result["initial_record_count"] = initial_count
	if not keep_running.is_valid() or not bool(keep_running.call()): result.reason = "cancelled"; return _finish(result,main)
	var season: String = str(main.active_career.season_state.get("season_id",""))
	var owned_event: String = ""
	var target_id: String = str(main.active_career.season_state.get("target_event_id",""))
	if not main.active_career.competition_state.is_empty():
		result.reason = "target_event" if not target_id.is_empty() and main.active_career.competition_state.get("event_id") == target_id else "existing_manual_competition"
		return _finish(result,main)
	if target_id.is_empty(): result.reason = "no_target"; return _finish(result,main)
	var initial_bundle: Dictionary = Bundle.for_career(main.active_career)
	if not initial_bundle.get("errors",[]).is_empty(): result.reason = "advance_failed"; result.errors = initial_bundle.errors; return _finish(result,main)
	if not initial_bundle.calendar.get("events",[]).any(func(event): return event.get("event_id") == target_id): result.reason = "target_not_in_calendar"; return _finish(result,main)
	if main.active_career.competition_archive.any(func(record): return record.get("event_id") == target_id and not record.get("world_only",false)): result.reason = "target_already_complete"; return _finish(result,main)
	var initial_boundary: Dictionary = _boundary(main.active_career)
	for step in maxi(0,max_steps):
		if main.is_inside_tree(): await main.get_tree().process_frame
		if not keep_running.is_valid() or not bool(keep_running.call()): result.reason = "cancelled"; break
		var career = main.active_career
		if str(career.season_state.get("season_id","")) != season: result.reason = "season_boundary"; break
		if _boundary(career) != initial_boundary: result.reason = "dispatch_or_quota_changed"; break
		var session: Dictionary = career.competition_state
		var target: String = str(career.season_state.get("target_event_id",""))
		if not session.is_empty():
			var event_id: String = str(session.get("event_id",""))
			if not target.is_empty() and event_id == target: result.reason = "target_event"; break
			if owned_event != event_id: result.reason = "existing_manual_competition"; break
			var action: String = _session_action(session)
			if action == "meaningful_practice" or action == "unsupported_session": result.reason = action; break
			if action != "archive" and main._competition_medically_blocked(): result.reason = "medical_restriction"; break
			if progress.is_valid(): progress.call(str({"practice":"沿用准备方案，进行短节目","free":"保持原方案，进行自由滑","archive":"保存正式比赛结果"}.get(action,"推进比赛")))
			var before: Dictionary = session.duplicate(true)
			match action:
				"practice": await main._on_formal_practice_response_selected("accept")
				"free": await main._on_formal_adjustment_selected("keep")
				"archive": await main._on_formal_archive_confirmed()
			if main.active_career.competition_state == before:
				result.reason = "transition_not_saved"; result.errors = ["transition_not_saved"]; break
			if action == "archive":
				var archive: Dictionary = before.get("archive",{})
				var standings: Array = archive.get("final_standings",[]).filter(func(row):return row.get("athlete_id") == "player")
				var player: Dictionary = standings[0] if not standings.is_empty() else {}
				result.completed_events.append({"event_id":event_id,"name":str(before.get("event",{}).get("name",event_id)),"rank":player.get("rank",null),"total":player.get("total_score",null)})
				owned_event = ""
			continue
		var bundle: Dictionary = Bundle.for_career(career)
		var boundary_stop: Array = [false]
		var advanced: Dictionary = await Progression.advance_to_next_node_durable(career,bundle,func(candidate):
			if not bool(keep_running.call()): return false
			var saved: Dictionary = await main._save_career(candidate,main.autosave_path)
			if not saved.ok: return false
			main.active_career = candidate
			if main.is_inside_tree(): await main.get_tree().process_frame
			if _boundary(candidate) != initial_boundary:
				boundary_stop[0] = true
				return false
			return true)
		if boundary_stop[0]:
			result.reason = "dispatch_or_quota_changed"
			result.ledger.append_array(advanced.get("ledger",[]))
			break
		main.active_career = advanced.career
		result.ledger.append_array(advanced.get("ledger",[]))
		result.node = advanced.get("stop_node",{})
		if not bool(keep_running.call()): result.reason = "cancelled"; break
		if not advanced.get("errors",[]).is_empty(): result.reason = "advance_failed"; result.errors = advanced.errors; break
		if str(main.active_career.season_state.get("season_id","")) != season: result.reason = "season_boundary"; break
		if _boundary(main.active_career) != initial_boundary: result.reason = "dispatch_or_quota_changed"; break
		var node: Dictionary = result.node
		if not target.is_empty() and node.get("event_id","") == target: result.reason = "target_event"; break
		if node.get("kind") != "competition_check_in": result.reason = str(node.get("kind","no_action")); break
		var event_id: String = str(node.get("event_id",""))
		var started: Dictionary = await main.start_formal_competition(event_id)
		if not started.get("ok",false): result.reason = "check_in_failed"; result.errors = started.get("errors",["check_in_failed"]); break
		owned_event = event_id
		result.node = {}
		var tutorial = main.get_node_or_null("%OnboardingOverlay")
		if tutorial != null and tutorial.visible:
			result.reason = "onboarding"
			break
	return _finish(result,main)

static func _finish(result: Dictionary, main) -> Dictionary:
	result["final_record_count"] = main.active_career.competition_archive.size()
	result["reason_label"] = {"no_target":"请先选择赛季目标","target_not_in_calendar":"目标不在当前赛历，请重新选择","target_already_complete":"目标比赛已经完成","cancelled":"已暂停，保留最近保存的进度","target_event":"已到赛季目标，请亲自处理","existing_manual_competition":"当前比赛由你手动开始或恢复，请先继续处理","meaningful_practice":"公开训练提供了重要信息，请亲自选择","medical_restriction":"身体状态需要你处理","dispatch_or_quota_changed":"派遣或国家名额发生变化，请查看","transition_not_saved":"比赛推进未保存，请重试或查看提示","step_limit":"已达本次自动推进步数上限","season_boundary":"已到赛季边界","advance_failed":"日程推进暂停，请查看错误","check_in_failed":"比赛签到未完成，请查看错误"}.get(result.reason,"需要你处理下一项安排")
	if result.reason == "onboarding": result.reason_label = "首次比赛说明需要你查看。"
	return result

static func _session_action(session: Dictionary) -> String:
	if session.get("kind") != "formal": return "unsupported_session"
	match str(session.get("status","")):
		"practice_ready": return "meaningful_practice" if session.get("practice",{}).get("meaningful",false) else "practice"
		"free_adjustment": return "free"
		"complete": return "archive"
	return "unsupported_session"

static func _boundary(career) -> Dictionary:
	return {"assignments":career.selection_state.get("assignments",{}).duplicate(true),"decisions":career.selection_state.get("decisions",{}).duplicate(true),"olympic":career.olympic_quota_state.duplicate(true),"milano":career.milano_olympic_quota_state.duplicate(true)}

