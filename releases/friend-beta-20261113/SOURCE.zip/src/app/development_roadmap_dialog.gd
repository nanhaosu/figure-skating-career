class_name DevelopmentRoadmapDialog
extends Window

const DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
const DevelopmentRoadmapEvaluator = preload("res://src/simulation/development_roadmap_evaluator.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")

signal roadmap_confirmed(roadmap)

var career
var current_step := 0
var _route_id := "balanced"
var _milestones: Array[Dictionary] = [{"age": 10, "rotations": 2, "count": 6}, {"age": 13, "rotations": 3, "count": 4}]
var _priorities: Array[String] = ["", ""]
var _deferred := ""
var _pages: Array[Control] = []
var _route_selector: OptionButton
var _priority_inputs: Array[OptionButton] = []
var _deferred_input: OptionButton
var _evaluation_text: Label
var _confirm_button: Button

func _ready() -> void:
	close_requested.connect(hide)
	_build_ui()
	_show_step(0)

func begin(active_career) -> void:
	career = active_career
	select_route("balanced")
	_show_step(0)
	popup_centered(Vector2i(720, 500))

func step_count() -> int: return _pages.size()
func selected_route_id() -> String: return _route_id

func select_route(route_id: String) -> void:
	if not DevelopmentRoadmap.ROUTE_IDS.has(route_id): return
	_route_id = route_id
	var age: int = int(career.clock.age_on(career.athlete.birth_year)) if career != null else 7
	if route_id == "steady": _milestones = [{"age": maxi(10, age + 3), "rotations": 2, "count": 5}, {"age": maxi(14, age + 6), "rotations": 3, "count": 3}]
	elif route_id == "fast": _milestones = [{"age": maxi(9, age + 2), "rotations": 2, "count": 6}, {"age": maxi(11, age + 4), "rotations": 3, "count": 5}]
	else: _milestones = [{"age": maxi(10, age + 2), "rotations": 2, "count": 6}, {"age": maxi(13, age + 5), "rotations": 3, "count": 4}]
	_select_metadata(_route_selector, route_id)
	_validate()

func set_milestone(slot: int, age: int, rotations: int, count: int) -> void:
	if slot < 0 or slot >= _milestones.size(): return
	_milestones[slot] = {"age": age, "rotations": rotations, "count": count}
	_validate()

func set_priority_jump(slot: int, jump_id: String) -> void:
	if slot < 0 or slot >= 2: return
	_priorities[slot] = jump_id
	_select_metadata(_priority_inputs[slot], jump_id)
	_validate()

func set_deferred_jump(jump_id: String) -> void:
	_deferred = jump_id
	_select_metadata(_deferred_input, jump_id)
	_validate()

func show_evaluation() -> void:
	var roadmap = _build_roadmap()
	if roadmap == null or career == null: return
	var evaluation := DevelopmentRoadmapEvaluator.evaluate(career, roadmap)
	var feasibility_labels := {"conservative": "保守", "feasible": "可行", "aggressive": "激进", "not_recommended": "当前不建议"}
	var lines: Array[String] = ["教练评估：%s" % feasibility_labels[evaluation.feasibility]]
	for forecast in evaluation.milestone_forecasts:
		lines.append("%d周跳%d种：预计%d～%d岁" % [int(forecast.rotations), int(forecast.count), int(forecast.earliest_age), int(forecast.late_age)])
	if not evaluation.visible_reasons.is_empty(): lines.append("主要因素：%s" % "；".join(evaluation.visible_reasons))
	_evaluation_text.text = "\n".join(lines)
	_show_step(2)

func _build_roadmap():
	var priorities: Array[String] = []
	for jump_id in _priorities:
		if not jump_id.is_empty() and not priorities.has(jump_id): priorities.append(jump_id)
	var risk := "cautious" if _route_id == "steady" else ("aggressive" if _route_id == "fast" else "normal")
	return DevelopmentRoadmap.create(_route_id, _milestones, priorities, _deferred, risk).roadmap

func _build_ui() -> void:
	var margin := MarginContainer.new(); margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); margin.add_theme_constant_override("margin_left", 20); margin.add_theme_constant_override("margin_top", 16); margin.add_theme_constant_override("margin_right", 20); margin.add_theme_constant_override("margin_bottom", 16); add_child(margin)
	var layout := VBoxContainer.new(); margin.add_child(layout)
	var title := Label.new(); title.text = "三步制定成长路线"; title.add_theme_font_size_override("font_size", 24); layout.add_child(title)
	var pages := VBoxContainer.new(); pages.size_flags_vertical = Control.SIZE_EXPAND_FILL; layout.add_child(pages)
	_pages = [_route_page(), _goal_page(), _evaluation_page()]
	for page in _pages: pages.add_child(page)
	var actions := HBoxContainer.new(); layout.add_child(actions)
	var back := Button.new(); back.text = "上一步"; back.pressed.connect(func(): _show_step(maxi(0, current_step - 1))); actions.add_child(back)
	var next := Button.new(); next.text = "下一步 / 查看评估"; next.size_flags_horizontal = Control.SIZE_EXPAND_FILL; next.pressed.connect(_advance_step); actions.add_child(next)
	_confirm_button = Button.new(); _confirm_button.name = "ConfirmButton"; _confirm_button.text = "确认路线"; _confirm_button.pressed.connect(_confirm); actions.add_child(_confirm_button)

func _route_page() -> VBoxContainer:
	var page := VBoxContainer.new(); page.name = "RouteStep"
	var intro := Label.new(); intro.text = "第一步：选择总体方向。预设只决定目标节奏，不提供属性加成。"; intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; page.add_child(intro)
	_route_selector = OptionButton.new()
	for item in [["steady", "稳健成长"], ["balanced", "均衡发展"], ["fast", "快速冲击"], ["custom", "自定义"]]: _route_selector.add_item(item[1]); _route_selector.set_item_metadata(_route_selector.item_count - 1, item[0])
	_route_selector.select(1); _route_selector.item_selected.connect(func(index): select_route(str(_route_selector.get_item_metadata(index)))); page.add_child(_route_selector)
	return page

func _goal_page() -> VBoxContainer:
	var page := VBoxContainer.new(); page.name = "GoalStep"
	var intro := Label.new(); intro.text = "第二步：保留少量关键选择。年龄节点使用路线预设，也可通过接口微调。"; intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; page.add_child(intro)
	for slot in 2:
		var row := HBoxContainer.new(); var label := Label.new(); label.text = "优先跳跃 %d" % (slot + 1); label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; row.add_child(label)
		var input := _jump_selector("PriorityJump%d" % slot); input.item_selected.connect(func(index): set_priority_jump(slot, str(input.get_item_metadata(index)))); row.add_child(input); _priority_inputs.append(input); page.add_child(row)
	var deferred_row := HBoxContainer.new(); var deferred_label := Label.new(); deferred_label.text = "暂缓或优先修正"; deferred_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL; deferred_row.add_child(deferred_label)
	_deferred_input = _jump_selector("DeferredJump"); _deferred_input.item_selected.connect(func(index): set_deferred_jump(str(_deferred_input.get_item_metadata(index)))); deferred_row.add_child(_deferred_input); page.add_child(deferred_row)
	return page

func _evaluation_page() -> VBoxContainer:
	var page := VBoxContainer.new(); page.name = "EvaluationStep"
	_evaluation_text = Label.new(); _evaluation_text.name = "EvaluationText"; _evaluation_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; _evaluation_text.text = "教练评估将在这里显示。"; page.add_child(_evaluation_text)
	return page

func _jump_selector(node_name: String) -> OptionButton:
	var input := OptionButton.new(); input.name = node_name; input.add_item("不指定"); input.set_item_metadata(0, "")
	for jump_id in TrainingPlan.JUMP_LABELS: input.add_item(TrainingPlan.JUMP_LABELS[jump_id]); input.set_item_metadata(input.item_count - 1, jump_id)
	return input

func _show_step(step: int) -> void:
	current_step = clampi(step, 0, 2)
	for index in _pages.size(): _pages[index].visible = index == current_step

func _advance_step() -> void:
	if current_step == 0: _show_step(1)
	else: show_evaluation()

func _validate() -> void:
	if _confirm_button != null: _confirm_button.disabled = _build_roadmap() == null

func _confirm() -> void:
	var roadmap = _build_roadmap()
	if roadmap != null: hide(); roadmap_confirmed.emit(roadmap)

func _select_metadata(input: OptionButton, value) -> void:
	if input == null: return
	for index in input.item_count:
		if input.get_item_metadata(index) == value: input.select(index); return

