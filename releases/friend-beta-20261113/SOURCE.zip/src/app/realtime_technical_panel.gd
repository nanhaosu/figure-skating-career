class_name RealtimeTechnicalPanel
extends PanelContainer

const SUCCESS_COLOR := Color("43a86b")
const ERROR_COLOR := Color("d95757")
const REVIEW_COLOR := Color("d5a632")
const STATUS_TEXT := {"success": "完成", "error": "扣分", "review": "技术组复核中"}

var _rows: Dictionary = {}
var _records: Dictionary = {}

@onready var segment_label: Label = %SegmentLabel
@onready var element_list: VBoxContainer = %ElementList

func reset_segment(segment_name: String) -> void:
	segment_label.text = "%s · 实时技术框" % segment_name
	for child in element_list.get_children():
		child.free()
	_rows.clear()
	_records.clear()

func push_element(record: Dictionary) -> void:
	var element_id := str(record.get("element_id", ""))
	if element_id.is_empty():
		return
	if _records.has(element_id):
		finalize_review(element_id,record)
		return
	var row := HBoxContainer.new()
	row.name = "Element_%s" % element_id
	var status_bar := ColorRect.new()
	status_bar.name = "StatusBar"
	status_bar.custom_minimum_size = Vector2(5, 48)
	row.add_child(status_bar)
	var score := Label.new()
	score.name = "Score"
	score.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	score.add_theme_font_size_override("font_size", 16)
	score.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(score)
	var status := Label.new()
	status.name = "Status"
	status.visible = false
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(status)
	element_list.add_child(row)
	_rows[element_id] = row
	_records[element_id] = record.duplicate(true)
	_render_row(element_id)

func finalize_review(element_id: String, final_values: Dictionary) -> void:
	if not _records.has(element_id):
		return
	var record: Dictionary = _records[element_id]
	for key in final_values:
		record[key] = final_values[key]
	_records[element_id] = record
	_render_row(element_id)

func _render_row(element_id: String) -> void:
	var row: HBoxContainer = _rows[element_id]
	var record: Dictionary = _records[element_id]
	var status_id := str(record.get("status", "review"))
	var goe := float(record.get("live_goe", 0.0))
	var text := "%s  ·  GOE %+.2f\n基础分 %.2f" % [str(record.get("abbreviation", "?")), goe, float(record.get("base_value", 0.0))]
	if record.has("element_score"): text += "  得分 %.2f" % float(record.element_score)
	row.get_node("Score").text = text
	row.get_node("Status").text = STATUS_TEXT.get(status_id, STATUS_TEXT.review)
	row.get_node("StatusBar").color = _status_color(status_id)
	row.tooltip_text = str(STATUS_TEXT.get(status_id,STATUS_TEXT.review))
	if record.has("turning_point"): row.tooltip_text += "\n"+str(record.turning_point.get("text",""))
	row.get_node("Score").modulate = _status_color(status_id)

func _status_color(status_id: String) -> Color:
	if status_id == "success": return SUCCESS_COLOR
	if status_id == "error": return ERROR_COLOR
	return REVIEW_COLOR
