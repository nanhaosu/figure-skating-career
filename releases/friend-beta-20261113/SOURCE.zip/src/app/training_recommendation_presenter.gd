class_name TrainingRecommendationPresenter
extends RefCounted

const TrainingPolicy = preload("res://src/domain/training_policy.gd")
const Planner = preload("res://src/simulation/training_policy_planner.gd")

static func for_career(career, catalog: Dictionary) -> Dictionary:
	if career == null or career.athlete == null:
		return {"coach_note":"暂时无法制定训练方案。","options":[]}
	var recovery_needed := _recovery_needed(career)
	var specifications: Array = _specifications(career,recovery_needed)
	var options: Array[Dictionary] = []
	for index in specifications.size():
		var specification: Dictionary = specifications[index]
		var policy_result := TrainingPolicy.create(
			str(specification.policy_id),
			Array(specification.focus_jumps),
			Dictionary(specification.target_rotations),
			str(specification.risk_attitude),
		)
		if not policy_result.errors.is_empty(): continue
		var preview_career = career.transaction_copy()
		var planned := Planner.build(preview_career,policy_result.policy,catalog)
		if planned.plan == null: continue
		options.append({
			"id":str(specification.id),
			"title":str(specification.title),
			"benefit":str(specification.benefit),
			"tradeoff":str(specification.tradeoff),
			"recommended":index == 0,
			"policy":policy_result.policy.to_dict(),
			"plan":planned.plan.to_dict(),
			"forecast":planned.forecast.duplicate(true),
		})
	return {
		"coach_note":"身体负荷偏高，本季度先恢复，之后再继续追进度。" if recovery_needed else "我准备了三种方向。第一次玩建议采用标有推荐的方案。",
		"options":options,
	}

static func _recovery_needed(career) -> bool:
	var body: Dictionary = career.athlete.body
	return (
		float(body.get("acute_fatigue",0.0)) >= 70.0
		or float(body.get("impact_load",0.0)) >= 72.0
		or float(body.get("ankle_load",0.0)) >= 72.0
		or not Array(career.condition_state.get("injuries",[])).is_empty()
	)

static func _specifications(career, recovery_needed: bool) -> Array[Dictionary]:
	var focus := _focus(career)
	var targets := {}
	for jump_id in focus:
		var unlocked := int(career.athlete.jumps[jump_id].unlocked_rotations)
		targets[jump_id] = mini(3,maxi(1,unlocked + 1))
	var balanced := {
		"id":"balanced_foundation","title":"稳步打基础","benefit":"滑行、跳跃与体能一起增长，最适合长期培养。","tradeoff":"单项突破不会特别快。",
		"policy_id":"balanced_foundation","focus_jumps":[],"target_rotations":{},"risk_attitude":"normal",
	}
	var push := {
		"id":"rotation_push","title":"重点推进跳跃","benefit":"集中尝试%s，较快积累下一周数的证据。" % _focus_names(focus),"tradeoff":"冲击负荷更高，可能触发教练或家长调整。",
		"policy_id":"rotation_push","focus_jumps":focus,"target_rotations":targets,"risk_attitude":"normal",
	}
	var recovery := {
		"id":"recovery","title":"恢复与整理","benefit":"降低疲劳和冲击，保留少量基础训练。","tradeoff":"本季度技术推进会明显放慢。",
		"policy_id":"recovery","focus_jumps":[],"target_rotations":{},"risk_attitude":"cautious",
	}
	return [recovery,balanced,push] if recovery_needed else [balanced,push,recovery]

static func _focus(career) -> Array[String]:
	var saved: Array = career.last_training_policy.get("focus_jumps",[])
	var result: Array[String] = []
	for jump_id in saved:
		if career.athlete.jumps.has(jump_id) and not result.has(str(jump_id)): result.append(str(jump_id))
		if result.size() == 2: return result
	for jump_id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		if career.athlete.jumps.has(jump_id) and not result.has(jump_id): result.append(jump_id)
		if result.size() == 2: break
	return result

static func _focus_names(focus: Array[String]) -> String:
	var labels := {"toe_loop":"后外点冰跳","salchow":"后内结环跳","loop":"后外结环跳","flip":"后内点冰跳","lutz":"勾手跳","axel":"阿克塞尔跳"}
	var names: Array[String] = []
	for jump_id in focus: names.append(labels.get(jump_id,jump_id))
	return "、".join(names)
