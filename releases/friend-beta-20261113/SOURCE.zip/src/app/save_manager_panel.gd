extends Window
signal career_loaded(career, slot_id: String)
signal career_saved(slot_id: String)
var service
var career
var slot_list: ItemList
var message: Label
var confirm_button: Button
var name_edit: LineEdit
var file_dialog: FileDialog
var delete_dialog: ConfirmationDialog
var _action_buttons: Array[Button] = []
var _close_button: Button
var _import_ready := false

func _ready() -> void:
	close_requested.connect(hide)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_" + side,16)
	add_child(margin)
	var column := VBoxContainer.new(); margin.add_child(column)
	var hint := Label.new(); hint.text = "浏览器存档保存在本机。请定期下载备份；清理网站数据会删除本机存档。"; hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; column.add_child(hint)
	slot_list = ItemList.new(); slot_list.custom_minimum_size.y = 210; column.add_child(slot_list)
	slot_list.item_selected.connect(func(_index): _refresh_name())
	var row := HBoxContainer.new(); column.add_child(row)
	_button(row,"保存当前生涯",save_current)
	_button(row,"读取",load_selected)
	_button(row,"下载 / 导出",export_selected)
	_button(row,"上传 / 导入",import_selected)
	_button(row,"删除",func(): delete_dialog.popup_centered())
	var names := HBoxContainer.new(); column.add_child(names)
	name_edit = LineEdit.new(); name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL; names.add_child(name_edit)
	_button(names,"重命名",func(): _result(await service.rename_slot(_selected(),name_edit.text)); refresh())
	message = Label.new(); message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; message.custom_minimum_size.y = 80; column.add_child(message)
	confirm_button = _button(column,"确认导入并替换所选槽位",confirm_import,false); confirm_button.disabled = true
	_close_button = _button(column,"关闭",hide,false)
	file_dialog = FileDialog.new(); file_dialog.access = FileDialog.ACCESS_FILESYSTEM; file_dialog.filters = PackedStringArray(["*.json ; 生涯存档"]); add_child(file_dialog)
	file_dialog.file_selected.connect(func(path):
		if file_dialog.file_mode == FileDialog.FILE_MODE_SAVE_FILE: _result(service.export_slot(_selected(),path))
		else: _preview_result(service.import_slot(path)))
	delete_dialog = ConfirmationDialog.new(); delete_dialog.dialog_text = "确认删除所选存档及其备份？此操作无法撤销。"; add_child(delete_dialog)
	delete_dialog.confirmed.connect(func(): _result(await service.delete_slot(_selected(),true)); refresh())

func present(adapter, active) -> void:
	if service != null and service.busy_changed.is_connected(_on_busy_changed): service.busy_changed.disconnect(_on_busy_changed)
	service = adapter; career = active
	if not service.upload_ready.is_connected(_preview_result): service.upload_ready.connect(_preview_result)
	if not service.busy_changed.is_connected(_on_busy_changed): service.busy_changed.connect(_on_busy_changed)
	_on_busy_changed(bool(service.busy))
	refresh(); popup_centered(Vector2i(900,560))

func refresh() -> void:
	var selected := slot_list.get_selected_items()[0] if not slot_list.get_selected_items().is_empty() else 1
	slot_list.clear()
	for row in service.list_slots():
		var clock: Dictionary = row.clock
		var date := "%d Q%d" % [int(clock.year),int(clock.quarter)] if not clock.is_empty() else "—"
		var saved := Time.get_datetime_string_from_unix_time(int(row.saved_at_unix)) if int(row.saved_at_unix) > 0 else "—"
		slot_list.add_item("%s | %s | %s | v%d | %.2f MiB | %s | %s" % [row.name,row.athlete,date,row.schema_version,float(row.size)/1048576.0,saved,"空" if row.status == "empty" else "已保存"])
	slot_list.select(selected); _refresh_name()

func _refresh_name() -> void:
	name_edit.text = service.list_slots()[slot_list.get_selected_items()[0]].name

func _selected() -> String:
	return service.IDS[slot_list.get_selected_items()[0]]

func save_current() -> void:
	var id := _selected()
	var result: Dictionary = await service.save_slot(id,career)
	_result(result); refresh()
	if result.ok: career_saved.emit(id)

func load_selected() -> void:
	var id := _selected()
	var result: Dictionary = await service.load_slot(id)
	_result(result)
	if result.ok: career_loaded.emit(result.career,id); hide()

func export_selected() -> void:
	if OS.has_feature("web"): _result(service.export_slot(_selected())); return
	file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE; file_dialog.current_file = "花滑生涯.json"; file_dialog.popup_centered(Vector2i(800,500))

func import_selected() -> void:
	_import_ready = false
	confirm_button.disabled = true
	if OS.has_feature("web"): service.request_upload(); return
	file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE; file_dialog.popup_centered(Vector2i(800,500))

func preview_payload(payload: String) -> void:
	_preview_result(service.import_payload(payload))

func _preview_result(result: Dictionary) -> void:
	_import_ready = bool(result.ok)
	confirm_button.disabled = not result.ok
	if not result.ok: _result(result); return
	var p: Dictionary = result.preview
	message.text = "导入预览：%s · %s Q%s · 迁移后 v%d · %.2f MiB\n确认后替换所选槽位；读取按钮可继续该生涯。" % [p.athlete,p.clock.year,p.clock.quarter,p.schema_version,float(p.size)/1048576.0]

func confirm_import() -> void:
	var result: Dictionary = await service.confirm_import(_selected())
	_result(result)
	if result.ok: _import_ready = false; confirm_button.disabled = true; refresh()

func _result(result: Dictionary) -> void:
	message.text = "操作成功，存档已经安全写入。" if result.ok else "失败，可重试：" + "；".join(result.errors)
	if result.ok and not result.get("warnings",[]).is_empty(): message.text += "（存档已保存，显示信息未更新：%s）" % "；".join(result.warnings)

func _on_busy_changed(value: bool) -> void:
	for button in _action_buttons: button.disabled = value
	if confirm_button != null: confirm_button.disabled = true if value else not _import_ready
	if value and message != null: message.text = "正在安全写入并确认浏览器存储，请勿重复点击或关闭页面……"

func _button(parent: Node, text: String, action: Callable, locks_during_busy: bool = true) -> Button:
	var button := Button.new(); button.text = text; button.custom_minimum_size.y = 36; button.pressed.connect(action); parent.add_child(button)
	if locks_during_busy: _action_buttons.append(button)
	return button
