class_name SeasonOverviewPanel
extends MarginContainer

const CertificationService = preload("res://src/simulation/certification_service.gd")
const SeasonJourneyPresenter = preload("res://src/app/season_journey_presenter.gd")

signal entry_adjustment_requested(event_id: String)
signal adjustment_selected(event_id: String, adjustment_id: String)
signal advance_requested
signal birth_date_requested
signal domestic_schedule_requested
signal domestic_schedule_selected(event_ids: Array)
signal target_selected(event_id: String)
signal preparation_requested(route_id: String, event_id: String, base_revision: int)
signal auto_advance_requested
signal event_launch_requested(event_id: String)
signal archive_view_requested(event_id: String)
signal pre_competition_action_requested(event_id: String, action_id: String, segment: String)

const STATUS_LABELS := {
	"cancelled":"已取消",
	"proposed": "待确认", "optional": "可选参赛", "blocked": "暂不可报名",
	"confirmed": "已报名", "declined": "本次不参加", "in_progress":"比赛进行中", "completed":"已完赛",
}

var _career
var _calendar: Dictionary = {}
var _entry_plan: Dictionary = {}
var _events_by_id: Dictionary = {}
var _journey: Dictionary = {}
var _selected_event_id := ""
var _adjustment_ids: Array[String] = []
var _domestic_dialog: ConfirmationDialog
var _domestic_choices: GridContainer
var _policy_dialog: ReadableInformationDialog
var _schedule_summary: Label
var _schedule_impact: Label
var _target_dialog
var _target_summary: Label
var _auto_confirmation: ConfirmationDialog

@onready var season_heading: Label = %SeasonHeading
@onready var athlete_summary: Label = %AthleteSummary
@onready var certification_summary: Label = %CertificationSummary
@onready var key_timeline: HBoxContainer = %KeyTimeline
@onready var next_event_name: Label = %NextEventName
@onready var next_event_meta: Label = %NextEventMeta
@onready var next_event_status: Label = %NextEventStatus
@onready var event_list_region: VBoxContainer = %EventListRegion
@onready var event_list: VBoxContainer = %EventList
@onready var details_heading: Label = %DetailsHeading
@onready var event_details: Label = %EventDetails
@onready var coach_recommendation: Label = %CoachRecommendation
@onready var eligibility_details: Label = %EligibilityDetails
@onready var adjust_entry_button: Button = %AdjustEntryButton
@onready var full_calendar_button: Button = %FullCalendarButton
@onready var advance_button: Button = %AdvanceButton
@onready var launch_event_button: Button = %LaunchEventButton
@onready var adjustment_dialog: ConfirmationDialog = %AdjustmentDialog
@onready var adjustment_option: OptionButton = %AdjustmentOption
@onready var pre_competition_dialog: AcceptDialog = %PreCompetitionDialog
@onready var checklist_summary: Label = %ChecklistSummary
@onready var checklist_actions: VBoxContainer = %ChecklistActions

func _ready() -> void:
	_target_dialog = preload("res://src/app/season_target_dialog.gd").new()
	_target_dialog.name = "SeasonTargetDialog"
	add_child(_target_dialog)
	_target_dialog.target_selected.connect(func(id): target_selected.emit(id))
	_target_dialog.preparation_requested.connect(func(route,id,revision): preparation_requested.emit(route,id,revision))
	_target_dialog.preparation_program_requested.connect(func(id,segment): pre_competition_action_requested.emit(id,"edit_program",segment))
	_target_dialog.event_requested.connect(select_event)
	_target_dialog.auto_requested.connect(_confirm_auto_advance)
	_auto_confirmation = ConfirmationDialog.new()
	_auto_confirmation.name = "AutoAdvanceConfirmation"
	_auto_confirmation.title = "托管已确认的比赛安排"
	_auto_confirmation.ok_button_text = "开始托管"
	_auto_confirmation.cancel_button_text = "返回"
	_auto_confirmation.dialog_autowrap = true
	_auto_confirmation.dialog_text = "沿用已保存的训练和报名安排。非目标比赛采用均衡策略与已锁定节目，自动结算并保存。到目标赛事、新选择、公开训练异常、伤病或赛季结束时暂停。可随时请求暂停。"
	_auto_confirmation.confirmed.connect(func():auto_advance_requested.emit())
	add_child(_auto_confirmation)
	var season_actions := HBoxContainer.new()
	season_actions.name = "SeasonActionRow"
	season_actions.add_theme_constant_override("separation",8)
	var advance_parent := advance_button.get_parent()
	advance_parent.add_child(season_actions)
	advance_button.reparent(season_actions)
	advance_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var target_button := Button.new()
	target_button.name = "SeasonTargetButton"
	target_button.text = "赛季目标与竞争形势"
	target_button.pressed.connect(present_target_board)
	season_actions.add_child(target_button)
	var identity_actions := HBoxContainer.new()
	identity_actions.name = "SeasonIdentityRow"
	athlete_summary.get_parent().add_child(identity_actions)
	_target_summary = Label.new()
	_target_summary.name = "SeasonTargetSummary"
	_target_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_target_summary.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	identity_actions.add_child(_target_summary)
	_policy_dialog = preload("res://src/app/readable_information_dialog.tscn").instantiate()
	_policy_dialog.name = "AnnualPolicyDialog"
	add_child(_policy_dialog)
	%AnnualPolicyButton.pressed.connect(func():
		_policy_dialog.present("年度选拔公告",[{"heading":"本赛季公开选拔政策","body":str(_journey.get("annual_policy",{}).get("announcements","暂无公告。"))}]))
	var schedule_button := Button.new()
	schedule_button.name = "DomesticScheduleButton"
	schedule_button.text = "本季国内赛安排"
	schedule_button.pressed.connect(func(): domestic_schedule_requested.emit())
	season_actions.add_child(schedule_button)
	var birthday_button := Button.new()
	birthday_button.name = "BirthDateButton"
	birthday_button.flat = true
	birthday_button.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	birthday_button.text = "出生日期 / 年龄资格"
	birthday_button.pressed.connect(func(): birth_date_requested.emit())
	identity_actions.add_child(birthday_button)
	_domestic_dialog = ConfirmationDialog.new()
	_domestic_dialog.name = "DomesticScheduleDialog"
	_domestic_dialog.title = "选择本赛季要参加的国内赛"
	_domestic_dialog.dialog_text = ""
	_domestic_dialog.ok_button_text = "保存参赛安排"
	_domestic_dialog.cancel_button_text = "返回，不修改"
	add_child(_domestic_dialog)
	var schedule_layout := VBoxContainer.new()
	schedule_layout.name = "ScheduleLayout"
	_domestic_dialog.add_child(schedule_layout)
	var scroll := ScrollContainer.new()
	scroll.name = "ScheduleScroll"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(820,420)
	schedule_layout.add_child(scroll)
	var layout := VBoxContainer.new()
	layout.name = "Content"
	layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(layout)
	var intro := Label.new()
	intro.name = "ScheduleIntroduction"
	intro.text = "先勾选本季国内赛，再保存安排。未选赛事不逐场打扰；已报名赛事退赛请查看详情。"
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	layout.add_child(intro)
	_schedule_impact = Label.new()
	_schedule_impact.name = "ScheduleImpact"
	_schedule_impact.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_domestic_choices = GridContainer.new()
	_domestic_choices.name = "Events"
	_domestic_choices.columns = 1
	layout.add_child(_domestic_choices)
	layout.add_child(_schedule_impact)
	_schedule_summary = Label.new()
	_schedule_summary.name = "ScheduleSummary"
	_schedule_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_schedule_summary.custom_minimum_size.x = 820
	_schedule_summary.size.x = 820
	schedule_layout.add_child(_schedule_summary)
	_domestic_dialog.confirmed.connect(func():
		var ids: Array = []
		for child in _domestic_choices.get_children():
			if child is CheckButton and child.button_pressed: ids.append(str(child.get_meta("event_id")))
		domestic_schedule_selected.emit(ids))
	full_calendar_button.pressed.connect(show_full_calendar)
	advance_button.pressed.connect(func(): advance_requested.emit())
	adjust_entry_button.pressed.connect(_request_adjustment)
	adjustment_dialog.confirmed.connect(_confirm_adjustment)
	launch_event_button.pressed.connect(_launch_selected_event)
	event_list_region.visible = false
	_apply_styles()

func present_domestic_schedule(rows: Array) -> void:
	for child in _domestic_choices.get_children():
		_domestic_choices.remove_child(child)
		child.queue_free()
	for row in rows:
		var choice := CheckButton.new()
		choice.name = str(row.event_id)
		choice.set_meta("event_id", str(row.event_id))
		choice.set_meta("display_name",str(row.name))
		choice.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		choice.custom_minimum_size = Vector2(0,64)
		var label := Label.new()
		label.name = "RaceLabel"
		label.text = "%s\n%s%s" % [row.name,row.date," · 已报名" if bool(row.selected) else (" · 暂不符合资格" if not bool(row.available) else "")]
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		choice.add_child(label)
		label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		label.offset_left = 56
		label.offset_right = -8

		choice.button_pressed = bool(row.selected)
		choice.disabled = bool(row.selected) or not bool(row.available)
		choice.tooltip_text = "；".join(Array(row.get("reasons", [])))
		_domestic_choices.add_child(choice)
		choice.toggled.connect(func(_pressed): _update_schedule_impact())
	_update_schedule_impact()
	var window_size := Vector2i(get_viewport_rect().size)
	var desired := Vector2i(mini(880,window_size.x-32),mini(500,window_size.y-64))
	var scroll: ScrollContainer = _domestic_dialog.get_node("ScheduleLayout/ScheduleScroll")
	scroll.custom_minimum_size = Vector2(maxi(240,desired.x-32),maxi(160,desired.y-170))
	_domestic_dialog.reset_size()
	_domestic_dialog.popup(Rect2i((window_size-desired)/2,desired))
	_domestic_dialog.position = (window_size-_domestic_dialog.size)/2

func _update_schedule_impact() -> void:
	var groups := {"required":[],"countable":[],"optional":[]}
	var unknown_targets := {}
	var unknown_events := 0
	for choice in _domestic_choices.get_children():
		if not choice is CheckButton or choice.button_pressed or choice.disabled: continue
		var id := str(choice.get_meta("event_id"))
		var name := str(choice.get_meta("display_name",id))
		var roles: Dictionary = _events_by_id.get(id,{}).get("policy_roles",{})
		if roles.is_empty(): unknown_events += 1
		for target in roles:
			var role := str(roles[target].get("role","unknown"))
			if role == "unknown":
				unknown_targets[str(_events_by_id.get(target,{}).get("name","其他目标"))] = true
			else:
				var target_name := "世青" if target == "world_junior" else "JGP分站"
				groups[role].append("%s（%s）" % [name,target_name])
	var lines: Array[String] = ["保存前的机会预览（仅当前可选而未勾选赛事）"]
	if not groups.required.is_empty(): lines.append("必要成绩 · 不参加会失去本目标的指定成绩路径："+"、".join(groups.required))
	if not groups.countable.is_empty(): lines.append("可计入成绩 · 减少一次机会，仍可使用其他指定赛："+"、".join(groups.countable))
	if not groups.optional.is_empty(): lines.append("非指定赛 · 不直接移除对应选拔路径："+"、".join(groups.optional))
	if not unknown_targets.is_empty(): lines.append("未覆盖／未核实的目标（逐场可计入性另行核对）："+"、".join(unknown_targets.keys()))
	if unknown_events > 0: lines.append("另有%d场赛事的当季选拔影响未覆盖／未核实。" % unknown_events)
	lines.append("少参赛可留出训练与恢复安排；实际时间按真实日期与训练窗口计算，不预送固定天数或费用。")
	_schedule_impact.text = "\n".join(lines)
	_schedule_summary.text = "保存影响：%s；减少JGP计分机会%d场，非指定赛%d项。\n未覆盖目标%d类，须另行核对；训练与恢复时间仍按真实日期计算。" % ["未选世青必要赛%d场，会失去本目标路径" % groups.required.size() if not groups.required.is_empty() else "未放弃世青必要成绩场次",groups.countable.size(),groups.optional.size(),unknown_targets.size()]
	_schedule_summary.tooltip_text = _schedule_impact.text

func present_target_board() -> void:
	if _career == null: return
	var target_id := str(_career.season_state.get("target_event_id",""))
	if _events_by_id.has(target_id): _target_summary.text = "赛季目标：%s" % str(_events_by_id[target_id].name)
	_target_dialog.present(_career,_calendar,_entry_plan)

func _confirm_auto_advance() -> void:
	_auto_confirmation.popup_centered(Vector2i(520,260))

func present(career, calendar: Dictionary, entry_plan: Dictionary) -> void:
	_career = career
	_calendar = calendar.duplicate(true)
	_entry_plan = entry_plan.duplicate(true)
	_journey = SeasonJourneyPresenter.build(career, _calendar, _entry_plan)
	_events_by_id = Dictionary(_journey.get("events_by_id", {}))
	var target_id := str(career.season_state.get("target_event_id",""))
	_target_summary.text = "赛季目标：%s" % str(_events_by_id[target_id].name) if _events_by_id.has(target_id) else "选择赛季目标，查看资格、竞争者与减赛影响"
	season_heading.text = "%s赛季 · 女子单人滑" % str(calendar.get("season_id", "赛季"))
	season_heading.tooltip_text = ""
	if calendar.get("season_id") == "2022-23" and calendar.get("events", []).any(func(event): return event.get("world_mode") == "fictional"):
		season_heading.text += " · 正式赛事试点"
		var repository = preload("res://src/content/season_calendar_repository.gd")
		var reference: Dictionary = repository.load_historical_women_reference(2022)
		var rows: Array[String] = ["2022–23 已核实的部分真实赛事（待接入参赛流程）"]
		var quota: Dictionary = career.selection_state.get("jgp_base_quota_history", {}).get("2022-23", {})
		if not quota.is_empty():
			var home := str(career.story_context.home_federation)
			var base: Dictionary = quota.countries.get(home, quota.non_participant)
			rows.append("%s 青年大奖赛基础配额：%d 站，每站 %d 席" % [home, int(base.stations), int(base.per_station)])
		for event in repository.chronological_events(reference.calendar):
			rows.append("%s  %s 至 %s" % [event.name, event.start_date, event.end_date])
		season_heading.tooltip_text = "\n".join(rows)
	if calendar.has("coverage_policy"):
		season_heading.text += " · 游戏处理"
		season_heading.tooltip_text = str(calendar.coverage_policy.get("label",""))
	var age: int = int(career.clock.age_on(career.athlete.birth_year))
	var level_service = preload("res://src/simulation/competitive_level_service.gd")
	athlete_summary.text = "%s  ·  %d岁  ·  %s" % [career.athlete.display_name, age,level_service.LABELS[level_service.current(career)]]
	var grade := int(career.certification_state.get("national_technical_grade", 0))
	var assessment := CertificationService.assess(career)
	certification_summary.text = "技术等级：%s · 游戏准备度 %.0f\n跳跃%.0f 滑行%.0f 节目%.0f 健康%.0f" % ["已记录%d级" % grade if grade > 0 else "未取得", float(assessment.readiness), float(assessment.evidence.jumps), float(assessment.evidence.skating), float(assessment.evidence.program), float(assessment.evidence.health)]
	_build_timeline()
	_build_event_list()
	var next_id := _next_event_id()
	_show_next_event(next_id)
	select_event(next_id)
	event_list_region.visible = false
	get_node("Layout/TimelineScroll").visible = true
	%NextEventPanel.visible = true
	full_calendar_button.text = "查看完整赛历（%d场）" % _events_by_id.size()

func show_full_calendar() -> void:
	get_node("Layout/TimelineScroll").visible = false
	%NextEventPanel.visible = false
	event_list_region.visible = true
	full_calendar_button.text = "完整赛历（%d场）" % _events_by_id.size()

func select_event(event_id: String) -> void:
	if not _events_by_id.has(event_id):
		_selected_event_id=""
		details_heading.text="本阶段安排"
		event_details.text=str(_calendar.get("coverage_policy",{}).get("label","暂无待处理赛事；可以继续训练。"))
		coach_recommendation.text="教练建议\n空档继续训练和恢复，不消耗虚构参赛机会。"
		eligibility_details.text="没有需要逐场确认的报名事项"
		adjust_entry_button.disabled=true
		launch_event_button.disabled=true
		return
	_selected_event_id = event_id
	var event: Dictionary = _events_by_id[event_id]
	var entry: Dictionary = event
	details_heading.text = str(event.get("name", "赛事详情"))
	event_details.text = "%s\n%s\n%s\n组别：%s\n报名路径：%s" % [
		str(event.get("name", "赛事")), _format_date(event), str(event.get("location", "地点待定")),
		" / ".join(Array(event.get("level_options", []))), _route_label(str(entry.get("route", event.get("entry_route", "")))),
	]
	if not str(event.get("gameplay_note","")).is_empty():event_details.text += "\n"+str(event.gameplay_note)
	coach_recommendation.text = "教练建议\n%s" % str(entry.get("coach_recommendation", "等待教练评估"))
	var meaning := preload("res://src/presentation/career_meaning_presenter.gd").build(_career,{"event":event})
	if not meaning.home.is_empty():
		coach_recommendation.text = str(meaning.home.title)+"\n"+" ".join(meaning.home.lines)
		coach_recommendation.tooltip_text = str(entry.get("coach_recommendation",""))+"\n"+str(meaning.home.detail)
	var snapshot: Dictionary = Dictionary(entry.get("eligibility_snapshot", {}))
	var explanations: Array = snapshot.get("explanations", [])
	var warnings: Array = snapshot.get("warnings", [])
	var lines: Array[String] = ["报名状态：%s" % _status_text(str(entry.get("status", "blocked")))]
	for explanation in explanations: lines.append("• %s" % str(explanation))
	for warning in warnings: lines.append("• 提醒：%s" % str(warning))
	if explanations.is_empty() and warnings.is_empty(): lines.append("• 当前未发现硬性报名障碍")
	eligibility_details.text = "\n".join(lines)
	adjust_entry_button.disabled = Array(entry.get("available_adjustment_ids", [])).is_empty()
	adjust_entry_button.text = "调整报名选择" if not adjust_entry_button.disabled else "当前无可调整选项"
	var action_kind := str(entry.get("action_kind", "blocked"))
	launch_event_button.disabled = not action_kind in ["compete", "resume", "view_archive"]
	launch_event_button.text = str(entry.get("action_label", "尚未到可参赛状态"))
	var standard: Dictionary = event.get("policy_standard",{})
	var kind := str(standard.get("kind",""))
	var audit: Dictionary = _career.selection_state.get("decisions",{}).get(kind,{}).get("decision",{}).get("audit",{}).duplicate(true) if not kind.is_empty() else {}
	if not audit.has("public_formula"): audit["public_formula"] = str(standard.get("public_formula","国内赛事：请按目标查看本场角色。"))
	present_selection_audit(audit)
	for role in event.get("policy_roles",{}).values():
		event_details.text += "\n"+str(role.label)
	var routes: Array = load("res://src/simulation/entry_application_service.gd").options(_career,event,{"rules":{"junior_min_age":13,"junior_max_age":18}})
	if event.get("scope") == "international" and not preload("res://src/simulation/entry_application_service.gd").has_entry_choice(routes):
		adjust_entry_button.disabled = true
		adjust_entry_button.text = "无需确认不参加"
	for route in routes:
		var costs: Dictionary = route.costs
		event_details.text += "\n%s · 截止%s · %s\n费用%.0f / 疲劳+%.0f / 训练熟练度−%.0f / 监护人关系%+.0f / 教练信任%+.0f / 声誉%+.1f" % [route.label,route.deadline,"可申请" if route.available else " / ".join(route.reasons),float(costs.get("money",0)),float(costs.get("fatigue",0)),float(costs.get("training_familiarity",0)),float(costs.get("guardian_closeness",0)),float(costs.get("coach_trust",0)),float(costs.get("reputation",0))]

func present_selection_audit(audit: Dictionary) -> void:
	var lines: Array[String] = [str(audit.get("public_formula","尚未进行选拔；可在国际赛事报名选项中提交。"))]
	if audit.has("seed"): lines.append("公开抽签 seed：%d；同分时按 lottery_key 从小到大" % int(audit.seed))
	for row in audit.get("candidate_rows",[]):
		lines.append("%s · %.2f · %s" % [row.get("name",row.athlete_id),float(row.score),", ".join(row.get("reason_codes",[]))])
		if row.has("lottery_key"): lines.append("lottery_key：%d" % int(row.lottery_key))
		if row.has("evidence"): lines.append("成绩证据：%s" % JSON.stringify(row.evidence))
		if row.has("development"):
			var d: Dictionary = row.development
			lines.append("发展观察：%d岁 · %d场完整成绩 · 起点%.2f · 增长%.2f%%（计分上限10%%）· 支持%.2f/100 · 观察分%.2f · %s" % [int(d.age),int(d.complete_events),float(d.earliest_total),float(d.growth_fraction)*100.0,float(row.club_access),float(d.score),"满足观察条件" if d.eligible else "不满足观察条件"])
	for adjustment in audit.get("association_adjustments",[]): lines.append("协会考虑：%s" % JSON.stringify(adjustment))
	for id in audit.get("station_choices",{}): lines.append("%s 分站安排：%s" % [id,JSON.stringify(audit.station_choices[id])])
	%SelectionAudit.text = "\n".join(lines)

func _launch_selected_event() -> void:
	if launch_event_button.disabled or _selected_event_id.is_empty(): return
	var row := Dictionary(_events_by_id.get(_selected_event_id, {}))
	if str(row.get("action_kind", "")) == "view_archive":
		archive_view_requested.emit(_selected_event_id)
		return
	event_launch_requested.emit(_selected_event_id)

func _event_is_due(event: Dictionary) -> bool:
	if _career == null: return false
	var parts := str(event.get("start_date", "")).split("-")
	if parts.size() < 2: return false
	var event_year := int(parts[0]); var month := int(parts[1]); var event_quarter := int((month - 1) / 3) + 1
	return event_year == int(_career.clock.year) and event_quarter == int(_career.clock.quarter)

func present_adjustment_options(event_id: String, options: Array[Dictionary]) -> void:
	if not _events_by_id.has(event_id) or options.is_empty():
		return
	var event: Dictionary = _events_by_id[event_id]
	if event.get("scope") == "domestic" and options[0].get("eligibility",{}).get("missing_qualification_ids",[]).has("program_legal"):
		adjustment_dialog.hide()
		var checklist := preload("res://src/app/pre_competition_checklist_service.gd").inspect(_career,event)
		checklist.actions = [{"id":"return_to_season","label":"先返回，不放弃报名"},{"id":"decline_entry","label":"本次明确不参加"}]
		present_pre_competition_checklist(event_id,checklist)
		return
	_selected_event_id = event_id
	_adjustment_ids.clear()
	adjustment_option.clear()
	for option in options:
		_adjustment_ids.append(str(option.get("id", "")))
		adjustment_option.add_item(str(option.get("label", "未命名选项")))
		var index := adjustment_option.item_count - 1
		adjustment_option.set_item_disabled(index,not bool(option.get("available",true)))
		adjustment_option.set_item_text(index,"%s %s" % [option.get("label","")," / ".join(option.get("reasons",[]))])
		adjustment_option.set_item_tooltip(index,"截止：%s\n影响：%s" % [option.get("deadline","本赛期"),JSON.stringify(option.get("costs",{}))])
	adjustment_dialog.dialog_text = "请选择对「%s」的报名决定。确认后会自动保存。" % str(_events_by_id[event_id].name)
	if _events_by_id[event_id].get("scope") == "international" and not preload("res://src/simulation/entry_application_service.gd").has_entry_choice(options):
		adjustment_dialog.hide()
		return
	adjustment_dialog.popup_centered(Vector2i(520, 230))

func present_pre_competition_checklist(event_id: String, checklist: Dictionary) -> void:
	_selected_event_id = event_id
	_clear_children(checklist_actions)
	var lines: Array[String] = []
	var seen_actions := {}
	for item in checklist.get("items", []):
		var marker := "✓" if str(item.get("status", "")) == "ready" else ("!" if str(item.get("status", "")) == "repairable" else "×")
		lines.append("%s %s：%s" % [marker, str(item.get("label", "检查项")), str(item.get("reason", ""))])
		for action in item.get("actions", []):
			_add_checklist_action(event_id, action, seen_actions)
	for action in checklist.get("actions", []):
		# AcceptDialog already provides the single return control.
		if str(action.get("id","")) != "return_to_season":
			_add_checklist_action(event_id, action, seen_actions)
	checklist_summary.text = "\n".join(lines)
	var viewport_size := Vector2i(get_viewport_rect().size)
	var desired := Vector2i(mini(660,viewport_size.x-32),mini(500,viewport_size.y-64))
	var layout: VBoxContainer = pre_competition_dialog.get_node("ChecklistLayout")
	layout.custom_minimum_size = Vector2(maxi(280,desired.x-40),0)
	var scroll: ScrollContainer = layout.get_node("SummaryScroll")
	scroll.custom_minimum_size = Vector2(0,80)
	scroll.scroll_vertical = 0
	pre_competition_dialog.reset_size()
	pre_competition_dialog.popup(Rect2i((viewport_size-desired)/2,desired))
	pre_competition_dialog.position = (viewport_size-pre_competition_dialog.size)/2

func _add_checklist_action(event_id: String, action: Dictionary, seen: Dictionary) -> void:
	var action_id := str(action.get("id", ""))
	var segment := str(action.get("segment", ""))
	var key := "%s:%s" % [action_id,segment]
	if action_id.is_empty() or seen.has(key): return
	seen[key] = true
	var button := Button.new()
	button.text = str(action.get("label", action_id)) + (" · %s" % ("短节目" if segment == "short" else "自由滑") if not segment.is_empty() else "")
	button.custom_minimum_size = Vector2(0,42)
	button.pressed.connect(func():
		pre_competition_dialog.hide()
		pre_competition_action_requested.emit(event_id,action_id,segment))
	checklist_actions.add_child(button)

func refresh_entry_plan(entry_plan: Dictionary) -> void:
	_entry_plan = entry_plan.duplicate(true)
	_journey = SeasonJourneyPresenter.build(_career, _calendar, _entry_plan)
	_events_by_id = Dictionary(_journey.get("events_by_id", {}))
	_build_timeline()
	_build_event_list()
	_show_next_event(_next_event_id())
	select_event(_selected_event_id if _events_by_id.has(_selected_event_id) else _next_event_id())

func _build_timeline() -> void:
	_clear_children(key_timeline)
	for event in _journey.get("current_chain", []):
		if not event is Dictionary: continue
		var chip := Label.new()
		chip.text = "%02d  %s\n%s" % [int(event.sequence), _short_name(str(event.name)), str(event.status_label)]
		chip.custom_minimum_size = Vector2(150, 52)
		chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		chip.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		chip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		chip.add_theme_stylebox_override("normal", _box(Color("24344e"), Color("50688f"), 10, 1))
		key_timeline.add_child(chip)

func _build_event_list() -> void:
	_clear_children(event_list)
	for event in _journey.get("events", []):
		if not event is Dictionary: continue
		var event_id := str(event.event_id)
		var entry: Dictionary = event
		var card := PanelContainer.new()
		card.set_meta("event_id", event_id)
		card.add_theme_stylebox_override("panel", _box(Color("162237"), Color("334a6d"), 9, 1))
		var layout := VBoxContainer.new()
		layout.name = "CardLayout"
		layout.add_theme_constant_override("separation", 3)
		card.add_child(layout)
		var title := Label.new(); title.text = "%02d  %s" % [int(event.sequence), str(event.name)]; title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; title.add_theme_font_size_override("font_size", 16); layout.add_child(title)
		var meta := Label.new(); meta.text = "%s  ·  %s" % [_format_date(event), str(event.location)]; meta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; meta.modulate = Color("aebbd0"); layout.add_child(meta)
		var status := Label.new(); status.name = "StatusLabel"; status.text = "状态：%s" % _status_text(str(entry.get("status", "blocked"))); status.modulate = _status_color(str(entry.get("status", "blocked"))); layout.add_child(status)
		var choose := Button.new(); choose.text = "查看赛事详情"; choose.pressed.connect(select_event.bind(event_id)); layout.add_child(choose)
		event_list.add_child(card)

func _show_next_event(event_id: String) -> void:
	if not _events_by_id.has(event_id):
		next_event_name.text = "当前没有待确认的参赛安排"
		next_event_meta.text = "可以继续训练；完整赛历可查看资格和成绩"
		next_event_status.text = "无需逐场确认不参加"
		return
	var event: Dictionary = _events_by_id[event_id]
	var entry: Dictionary = event
	next_event_name.text = str(event.name)
	next_event_meta.text = "%s  ·  %s" % [_format_date(event), str(event.location)]
	next_event_status.text = "状态：%s" % _status_text(str(entry.get("status", "blocked")))
	next_event_status.modulate = _status_color(str(entry.get("status", "blocked")))

func _next_event_id() -> String:
	return str(_journey.get("next_event_id", ""))

func _request_adjustment() -> void:
	if not _selected_event_id.is_empty(): entry_adjustment_requested.emit(_selected_event_id)

func _confirm_adjustment() -> void:
	var index := adjustment_option.selected
	if index >= 0 and index < _adjustment_ids.size() and not adjustment_option.is_item_disabled(index): adjustment_selected.emit(_selected_event_id, _adjustment_ids[index])

func _entry_for(event_id: String) -> Dictionary:
	return Dictionary(_events_by_id.get(event_id, {}))

func _status_text(status: String) -> String: return str(STATUS_LABELS.get(status, "未知状态"))
func _route_label(route: String) -> String:
	return str({"club_nomination":"俱乐部报名", "qualification_only":"凭资格晋级", "federation_approved_unit":"协会认可单位报名", "open_self_funded":"开放自费参赛"}.get(route, route))
func _short_name(name: String) -> String:
	return name.replace("2018中国花样滑冰俱乐部联赛", "俱乐部").replace("2018-2019年度全国花样滑冰大奖赛暨", "").replace("2018/2019", "")
func _format_date(event: Dictionary) -> String:
	var date := str(event.get("start_date", "日期待定"))
	if event.get("event_date_scope") == "whole_competition" and event.get("segment_dates") is Dictionary:
		var group := "成年女单" if event.get("level_options", []) == ["senior"] else "青年女单"
		return "大会范围：%s 至 %s\n%s：短节目 %s / 自由滑 %s（官方赛程）" % [date,event.end_date,group,event.segment_dates.short,event.segment_dates.free]
	if str(event.get("date_precision", "")) == "month": return "%s（具体日期待定）" % date
	return "%s 至 %s" % [date, str(event.get("end_date", date))]
func _status_color(status: String) -> Color:
	return Color("6ed6a7") if status in ["confirmed", "completed"] else (Color("72b7ed") if status == "in_progress" else (Color("f0c66f") if status in ["proposed", "optional"] else Color("ef8c92")))
func _clear_children(node: Node) -> void:
	for child in node.get_children():
		# A synchronous action may refresh its own emitting button. Detach now
		# so the new list is unique, then release after signal delivery ends.
		node.remove_child(child)
		child.queue_free()
func _box(background: Color, border: Color, radius: int, width: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new(); style.bg_color = background; style.border_color = border
	style.set_border_width_all(width); style.set_corner_radius_all(radius)
	style.content_margin_left = 12; style.content_margin_right = 12; style.content_margin_top = 8; style.content_margin_bottom = 8
	return style
func _apply_styles() -> void:
	%HeroPanel.add_theme_stylebox_override("panel", _box(Color("111d31"), Color("5673a4"), 12, 1))
	%NextEventPanel.add_theme_stylebox_override("panel", _box(Color("1b2b45"), Color("6c8fc5"), 12, 1))
	%DetailsPanel.add_theme_stylebox_override("panel", _box(Color("121d30"), Color("344b70"), 12, 1))
