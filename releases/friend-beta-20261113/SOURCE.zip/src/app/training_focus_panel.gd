extends Window

signal direction_requested(direction: Dictionary)
const Presenter = preload("res://src/presentation/training_focus_presenter.gd")
var _career
var _pickers: Array[OptionButton] = []
var _priority: OptionButton
var _preview: Label
var _confirm: Button
var _options: Array = []

func _ready() -> void:
	title = "我的培养重点"
	size = Vector2i(620,500)
	min_size = Vector2i(620,500)
	transient = true
	exclusive = true
	close_requested.connect(hide)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+side,18)
	add_child(margin)
	var background := ColorRect.new(); background.color = Color("#102332"); background.mouse_filter = Control.MOUSE_FILTER_IGNORE; margin.add_child(background)
	var layout := VBoxContainer.new(); layout.add_theme_constant_override("separation",12); margin.add_child(layout)
	var heading := Label.new(); heading.text = "两个重点可以并行；基础课由教练维护。"; layout.add_child(heading)
	for slot in 2:
		var label := Label.new(); label.text = "培养重点 %d" % (slot+1); layout.add_child(label)
		var picker := OptionButton.new(); picker.name = "Focus%d" % slot; picker.custom_minimum_size.y = 36
		picker.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		picker.item_selected.connect(func(_index): _refresh_preview())
		layout.add_child(picker); _pickers.append(picker)
	_priority = OptionButton.new(); _priority.name = "Priority"
	for item in [["balanced","均衡推进（默认）"],["first","冲突时优先第一个重点"],["second","冲突时优先第二个重点"]]:
		_priority.add_item(item[1]); _priority.set_item_metadata(_priority.item_count-1,item[0])
	_priority.item_selected.connect(func(_index): _refresh_preview()); layout.add_child(_priority)
	_preview = Label.new(); _preview.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; _preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_preview.add_theme_font_size_override("font_size",14); layout.add_child(_preview)
	var row := HBoxContainer.new(); layout.add_child(row)
	var back := Button.new(); back.text = "返回，不修改"; back.custom_minimum_size = Vector2(150,38); back.pressed.connect(hide); row.add_child(back)
	_confirm = Button.new(); _confirm.name = "ConfirmFocus"; _confirm.text = "确认培养方向"; _confirm.custom_minimum_size.y = 38; _confirm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_confirm.pressed.connect(func(): direction_requested.emit(draft())); row.add_child(_confirm)

func present(career) -> void:
	_career = career
	_options = Presenter.options(career)
	for slot in 2:
		var picker: OptionButton = _pickers[slot]; picker.clear()
		for option in _options: picker.add_item(option.label)
		picker.select(0)
		if slot < career.training_direction.focuses.size():
			var current: Dictionary = career.training_direction.focuses[slot]
			for index in _options.size():
				if _options[index].focus.get("kind") == current.kind and _options[index].focus.get("target") == current.target: picker.select(index); break
	for index in _priority.item_count:
		if _priority.get_item_metadata(index) == career.training_direction.priority: _priority.select(index)
	set_busy(false)
	_refresh_preview()
	popup_centered(Vector2i(620,500))

func draft() -> Dictionary:
	var direction: Dictionary = _career.training_direction.duplicate(true)
	direction.focuses = []
	for picker in _pickers:
		var focus: Dictionary = _options[picker.selected].focus
		if not focus.is_empty(): direction.focuses.append(focus.duplicate(true))
	direction.priority = str(_priority.get_item_metadata(_priority.selected))
	return direction

func set_busy(busy: bool) -> void:
	_confirm.disabled = busy
	for picker in _pickers: picker.disabled = busy
	_priority.disabled = busy

func show_error(message: String) -> void:
	set_busy(false)
	_preview.text = message

func _refresh_preview() -> void:
	if _career == null: return
	var candidate = _career.transaction_copy()
	candidate.training_direction = draft()
	var built: Dictionary = Presenter.build(candidate)
	_confirm.disabled = not built.errors.is_empty()
	if not built.errors.is_empty(): _preview.text = "；".join(built.errors); return
	var lines: Array[String] = []
	for state in built.states:
		var display_name: String = state.id
		for focus in candidate.training_direction.focuses:
			if focus.id == state.id: display_name = Presenter.label(focus); break
		lines.append("%s：%s" % [display_name,{"preparation":"准备期，尚未尝试目标动作","practice":"实际练习","maintenance":"本期维持"}.get(state.stage,state.stage)])
	lines.append("专项使用现有课时，不自动改比赛节目。%s" % ("跳跃专项共享额度，按所选优先级安排。" if not built.conflicts.is_empty() else ""))
	_preview.text = "\n".join(lines)
