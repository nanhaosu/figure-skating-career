class_name CoachHandoffPanel
extends MarginContainer

const CareerState = preload("res://src/domain/career_state.gd")

signal goal_confirmed(goal_id: String)
signal main_menu_requested

const GOALS := {
	"love_the_sport": {"title":"滑到自己不再想滑", "detail":"不预设成绩门槛，认真经历训练、比赛与选择。"},
	"highest_stage": {"title":"尽力走向最高舞台", "detail":"把进入顶级赛场当方向，但不保证冠军，也允许目标随生涯改变。"},
	"leave_a_mark": {"title":"留下值得记住的生涯", "detail":"成绩、节目、坚持或人与人的关系，都可能成为你留下的东西。"},
}

var _selected_goal := ""
var _can_confirm := false

@onready var coach_identity: Label = %CoachIdentity
@onready var coach_style: Label = %CoachStyle
@onready var assessment_columns: HBoxContainer = %AssessmentColumns
@onready var confirm_button: Button = %ConfirmGoalButton

func _ready() -> void:
	%OpeningMainMenuButton.pressed.connect(func(): main_menu_requested.emit())
	%GoalLoveSport.pressed.connect(_select_goal.bind("love_the_sport"))
	%GoalHighestStage.pressed.connect(_select_goal.bind("highest_stage"))
	%GoalLeaveMark.pressed.connect(_select_goal.bind("leave_a_mark"))
	confirm_button.pressed.connect(_confirm_goal)

func present(_career: CareerState, assessment: Dictionary) -> void:
	_selected_goal = ""
	_can_confirm = true
	visible = true
	confirm_button.disabled = true
	for button in [%GoalLoveSport, %GoalHighestStage, %GoalLeaveMark]: button.button_pressed = false
	var coach: Dictionary = assessment.get("coach", {})
	coach_identity.text = "%s · %s" % [str(coach.get("name", "当前教练")), str(coach.get("club_name", "当前俱乐部"))]
	coach_style.text = str(coach.get("style", ""))
	_clear(assessment_columns)
	_add_section("现阶段会什么", assessment.get("existing_ability", []))
	_add_section("已知提醒", assessment.get("known_risks", []))
	_add_section("身体与心理", assessment.get("body_mind", []))
	_add_section("第一阶段怎么练", assessment.get("first_plan", []))

func _select_goal(goal_id: String) -> void:
	if not GOALS.has(goal_id) or not _can_confirm: return
	_selected_goal = goal_id
	confirm_button.disabled = false
	%GoalLoveSport.button_pressed = goal_id == "love_the_sport"
	%GoalHighestStage.button_pressed = goal_id == "highest_stage"
	%GoalLeaveMark.button_pressed = goal_id == "leave_a_mark"

func _confirm_goal() -> void:
	if not _can_confirm or _selected_goal.is_empty(): return
	_can_confirm = false
	confirm_button.disabled = true
	goal_confirmed.emit(_selected_goal)

func _add_section(title: String, statements: Array) -> void:
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(205, 0)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var heading := Label.new()
	heading.text = title
	heading.add_theme_font_size_override("font_size", 17)
	box.add_child(heading)
	for statement in statements:
		var label := Label.new()
		# Web fallback shaping can break after ASCII space before a CJK paragraph.
		label.text = "•%s" % str(statement.get("text", ""))
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(label)
	assessment_columns.add_child(box)

func _clear(node: Node) -> void:
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()
