class_name OnboardingService
extends RefCounted

const VALID_STAGES := ["intro","training","program","registration","competition"]
const KIND := "onboarding_seen"

static func should_show(career, stage: String) -> bool:
	if career == null or not VALID_STAGES.has(stage): return false
	return not career.event_ledger.any(func(entry):
		return str(entry.get("kind", "")) == KIND and (bool(entry.get("skip_all", false)) or str(entry.get("stage", "")) == stage))

static func mark_seen(career, stage: String, skip_all: bool) -> void:
	if career == null or not VALID_STAGES.has(stage) or not should_show(career, stage): return
	career.event_ledger.append({"kind":KIND,"stage":stage,"skip_all":skip_all,"clock":career.clock.to_dict() if career.clock != null else {}})
