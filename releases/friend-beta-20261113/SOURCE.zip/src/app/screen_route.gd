class_name ScreenRoute
extends RefCounted

static func create(screen_id: String, context: Dictionary = {}, return_route: Dictionary = {}) -> Dictionary:
	return {
		"screen_id": screen_id,
		"context": context.duplicate(true),
		"return_route": return_route.duplicate(true),
	}
