class_name OnboardingOverlay
extends Control

signal dismissed(stage: String, skip_all: bool)

const COPY := {
	"intro":{"eyebrow":"欢迎接手这段生涯","title":"你不是从零开始","body":"她已经学滑数年，有自己的技术习惯、家庭关系和身体基础。你要做的不是把数值点满，而是陪她作出每个阶段的选择。","impact":"先看主页的“当前目标”。不知道做什么时，点击唯一的主行动即可。"},
	"training":{"eyebrow":"第一次安排训练","title":"先选方向，再看细节","body":"新手可以直接采用教练推荐；高级配比已折叠。训练会同时改变技术、疲劳、负荷和人物关系，没有永远正确的方案。","impact":"季度结束会把结果归纳为突破、代价、关系变化和下一建议。"},
	"program":{"eyebrow":"第一次编排节目","title":"合法只是底线，不是满分答案","body":"教练方案会先保证符合当季规则。你可以直接采用，也可以展开高级编辑，自由调整动作顺序、跳跃构成和冰面位置。","impact":"难度、熟练度与编排密度会共同影响比赛稳定性。"},
	"registration":{"eyebrow":"第一次面对赛历","title":"报名决定你的赛季路线","body":"顶部只展示当前任务链，完整国内与国际赛历仍可展开。协会派遣、自费报名和国内比赛各有门槛，也各自有价值。","impact":"没有获得国际名额不会结束生涯；国内俱乐部联赛仍会完整进行。"},
	"competition":{"eyebrow":"第一次正式比赛","title":"结果不会为主角保底","body":"先看阵容与公开训练，再决定策略。转播中绿色代表完成、黄色代表复核、红色代表失误；右侧会同步显示基础分、GOE和动作定级。","impact":"短节目前24名晋级自由滑。未晋级也会保留完整成绩与小分表。"},
}

var _stage := ""

func _ready() -> void:
	%OnboardingContinue.pressed.connect(_dismiss.bind(false))
	%OnboardingSkipAll.pressed.connect(_dismiss.bind(true))
	visible = false

func present(stage: String) -> bool:
	if not COPY.has(stage): return false
	_stage = stage
	var copy: Dictionary = COPY[stage]
	%OnboardingEyebrow.text = str(copy.eyebrow)
	%OnboardingTitle.text = str(copy.title)
	%OnboardingBody.text = str(copy.body)
	%OnboardingImpact.text = "这会影响什么\n%s" % str(copy.impact)
	visible = true
	%OnboardingContinue.grab_focus()
	return true

func _dismiss(skip_all: bool) -> void:
	if _stage.is_empty(): return
	var stage := _stage
	_stage = ""
	visible = false
	dismissed.emit(stage,skip_all)
