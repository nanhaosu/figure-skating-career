class_name ProtocolView
extends VBoxContainer

const COMPONENT_NAMES := {
	"skating_skills":"滑行技术", "transitions":"衔接", "performance":"表演",
	"composition":"编排", "interpretation":"音乐诠释", "presentation":"呈现",
}

var _protocols: Dictionary = {}

func _ready() -> void:
	%SegmentSelector.item_selected.connect(_select_segment)

func present(athlete_row: Dictionary, segment_protocols: Dictionary) -> void:
	_protocols = segment_protocols.duplicate(true)
	%AthleteHeading.text = "%s  ·  %s  ·  详细得分表" % [str(athlete_row.get("name", "运动员")), str(athlete_row.get("federation", ""))]
	%SegmentSelector.clear()
	for segment in ["short", "free"]:
		if _protocols.has(segment) and not Dictionary(_protocols[segment]).is_empty():
			%SegmentSelector.add_item("短节目" if segment == "short" else "自由滑")
			%SegmentSelector.set_item_metadata(%SegmentSelector.item_count - 1, segment)
	if %SegmentSelector.item_count > 0: _render(Dictionary(_protocols.get(str(%SegmentSelector.get_item_metadata(0)), {})))
	else: _render({})

func _select_segment(index: int) -> void:
	_render(Dictionary(_protocols.get(str(%SegmentSelector.get_item_metadata(index)), {})))

func _render(protocol: Dictionary) -> void:
	_clear(%ElementRows); _clear(%ComponentRows)
	for raw in protocol.get("element_scores", []):
		var element: Dictionary = Dictionary(raw)
		var row := Label.new()
		var marks: Array[String] = []
		for mark in element.get("judge_goes", []): marks.append("%+d" % int(mark))
		row.text = "%-12s %-5s  %5.2f  %s  GOE %+.2f  = %6.2f" % [str(element.get("abbreviation", "")), "".join(Array(element.get("info", []))), float(element.get("base_value", 0.0)), "  ".join(marks), float(element.get("goe", 0.0)), float(element.get("total", 0.0))]
		var planned: Dictionary = Dictionary(element.get("planned_element", {}))
		if str(planned.get("kind", "")) in ["spin", "step_sequence"]:
			row.text += "  计划 %s%d" % [str(planned.get("spin_code", "")) if planned.kind == "spin" else "StSq", int(planned.get("target_level", 4))]
		row.custom_minimum_size = Vector2(0, 27); row.add_theme_font_size_override("font_size", 14); %ElementRows.add_child(row)
	var component_scores: Dictionary = protocol.get("component_scores", {})
	for component_id in component_scores:
		var component: Dictionary = component_scores[component_id]
		var marks: Array[String] = []
		for mark in component.get("judge_marks", []): marks.append("%.2f" % float(mark))
		var row := Label.new(); row.text = "%-10s  %s   平均 %.2f × %.2f = %.2f" % [COMPONENT_NAMES.get(component_id, component_id), "  ".join(marks), float(component.get("average", 0.0)), float(component.get("factor", protocol.get("pcs_factor", 0.0))), float(component.get("factored", 0.0))]; %ComponentRows.add_child(row)
	%DomesticBonus.text = "TES %.2f  ·  PCS %.2f  ·  扣分 -%.2f  ·  国内奖励 +%.2f" % [float(protocol.get("tes", 0.0)), float(protocol.get("pcs", 0.0)), float(protocol.get("deductions", 0.0)), float(protocol.get("domestic_bonus", 0.0))]
	%ProtocolTotal.text = "本段总分  %.2f" % float(protocol.get("total", 0.0))

func _clear(node: Node) -> void:
	for child in node.get_children(): child.free()
