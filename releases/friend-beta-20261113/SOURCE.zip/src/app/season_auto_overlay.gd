extends PanelContainer

signal pause_requested
var _message: Label
var _pause: Button

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 100
	add_theme_stylebox_override("panel",preload("res://src/app/theme_factory.gd").card_style())
	var center := CenterContainer.new()
	add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size.x = 300
	box.add_theme_constant_override("separation",20)
	center.add_child(box)
	_message = Label.new()
	_message.name = "AutoProgressMessage"
	_message.custom_minimum_size.x = 300
	_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(_message)
	_pause = Button.new()
	_pause.name = "PauseAutoButton"
	_pause.text = "暂停，保留已保存的进度"
	_pause.pressed.connect(_request_pause)
	box.add_child(_pause)
	hide()

func begin() -> void:
	_message.text = "正在按已确认的安排推进……"
	_pause.disabled = false
	show()
	_pause.grab_focus()

func report(message: String) -> void:
	_message.text = message

func _request_pause() -> void:
	_pause.disabled = true
	_message.text = "正在保存当前步骤，随后暂停……"
	pause_requested.emit()

func _input(event: InputEvent) -> void:
	if not visible or not event is InputEventKey or not event.pressed: return
	if event.keycode == KEY_ESCAPE: _request_pause()
	if event.keycode in [KEY_ESCAPE,KEY_TAB]: get_viewport().set_input_as_handled()
