class_name PreCareerHistoryPanel
extends VBoxContainer

const CareerState = preload("res://src/domain/career_state.gd")

signal continued
signal main_menu_requested

var _can_continue := false

@onready var summary_label: Label = %HistorySummary
@onready var episode_list: VBoxContainer = %EpisodeList
@onready var coach_assessment: Label = %CoachAssessment
@onready var observation_list: VBoxContainer = %ObservationList
@onready var continue_button: Button = %ContinueButton

func _ready() -> void:
	%OpeningMainMenuButton.pressed.connect(func(): main_menu_requested.emit())
	continue_button.pressed.connect(_on_continue_pressed)

func present(career: CareerState) -> void:
	var history: Dictionary = career.pre_career_history
	_can_continue = true
	visible = true
	continue_button.disabled = false
	summary_label.text = "%s · %d岁开始学滑 · 累计训练%d年 · 进入生涯时%d岁" % [
		career.athlete.display_name,
		int(history.get("skating_start_age", 0)),
		int(history.get("training_quarters", 0)) / 4,
		2014 - int(career.athlete.birth_year),
	]
	_clear(episode_list)
	for episode in history.get("episodes", []):
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel",_box(Color("122238"),Color("2d4e70"),10))
		var label := Label.new()
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.text = "%d岁 · %s\n%s" % [int(episode.get("age", 0)), _kind_label(str(episode.get("kind", ""))), str(episode.get("fact", episode.get("text", "")))]
		label.add_theme_font_size_override("font_size",16)
		card.add_child(label)
		episode_list.add_child(card)
	coach_assessment.text = "教练的交接评估\n%s" % str(history.get("coach_assessment", ""))
	coach_assessment.add_theme_color_override("font_color",Color("d6e3f0"))
	_clear(observation_list)
	var observations: Array = history.get("known_observations", [])
	if observations.is_empty():
		_add_observation("暂无已经明确的技术提醒；未被指出不代表一定没有问题。")
	else:
		for observation in observations: _add_observation(str(observation))

func _on_continue_pressed() -> void:
	if not _can_continue: return
	_can_continue = false
	continue_button.disabled = true
	continued.emit()

func _add_observation(text: String) -> void:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel",_box(Color("172d3b"),Color("3b7b87"),8))
	var label := Label.new()
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.text = "技术观察  ·  %s" % text
	panel.add_child(label)
	observation_list.add_child(panel)

func _box(background: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background; style.border_color = border
	style.set_border_width_all(1); style.set_corner_radius_all(radius)
	style.content_margin_left = 14; style.content_margin_right = 14
	style.content_margin_top = 10; style.content_margin_bottom = 10
	return style

func _clear(container: Node) -> void:
	for child in container.get_children():
		container.remove_child(child)
		child.queue_free()

func _kind_label(kind: String) -> String:
	return {"entry":"来到冰场", "skating":"滑行基础", "jump":"跳跃进展", "spin":"旋转进展", "routine":"日常训练", "health":"身体记录", "handoff":"教练交接", "family":"家庭安排", "training":"第一次训练"}.get(kind, "成长记录")
