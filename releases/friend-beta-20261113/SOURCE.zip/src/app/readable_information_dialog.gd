class_name ReadableInformationDialog
extends Window

signal dismissed
var _sections: Array[Dictionary] = []
var current_page := 0
var _heading: Label
var _body: RichTextLabel
var previous_button: Button
var next_button: Button
var close_button: Button

func _ready() -> void:
	min_size = Vector2i(320,240)
	transient = true
	exclusive = true
	var panel := PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.add_theme_stylebox_override("panel",preload("res://src/app/theme_factory.gd").card_style())
	add_child(panel)
	var margin := MarginContainer.new()
	for edge in ["left","right","top","bottom"]: margin.add_theme_constant_override("margin_"+edge,16)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",12)
	margin.add_child(box)
	_heading = Label.new()
	_heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(_heading)
	_body = RichTextLabel.new()
	_body.name = "GuideBody"
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.scroll_active = true
	_body.fit_content = false
	box.add_child(_body)
	var footer := HBoxContainer.new()
	box.add_child(footer)
	previous_button = Button.new()
	previous_button.name = "GuidePrevious"
	previous_button.text = "上一页"
	previous_button.pressed.connect(func(): show_page(current_page-1))
	footer.add_child(previous_button)
	next_button = Button.new()
	next_button.name = "GuideNext"
	next_button.text = "下一页"
	next_button.pressed.connect(func(): show_page(current_page+1))
	footer.add_child(next_button)
	close_button = Button.new()
	close_button.name = "GuideClose"
	close_button.text = "返回，不修改进度"
	close_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close_button.pressed.connect(_dismiss)
	footer.add_child(close_button)
	close_requested.connect(_dismiss)

func present(title_text: String, sections: Array) -> void:
	title = title_text
	_sections.clear()
	for section in sections:
		if section is Dictionary: _sections.append(section.duplicate(true))
	var parent_size := get_parent().get_viewport().get_visible_rect().size
	var requested_size := Vector2i(maxi(320,mini(880,int(parent_size.x)-48)),maxi(240,mini(560,int(parent_size.y)-48)))
	show_page(0)
	show()
	size = requested_size
	position = (Vector2i(parent_size)-size)/2

func show_page(index: int) -> void:
	current_page = clampi(index,0,maxi(0,_sections.size()-1))
	var section: Dictionary = _sections[current_page] if not _sections.is_empty() else {}
	_heading.text = "%d / %d · %s" % [current_page+1,maxi(1,_sections.size()),str(section.get("heading","说明"))]
	_body.text = str(section.get("body","暂无说明。"))
	_body.scroll_to_line(0)
	previous_button.disabled = current_page == 0
	next_button.disabled = current_page >= _sections.size()-1

func _dismiss() -> void:
	hide()
	dismissed.emit()
