class_name FormalPracticeService
extends RefCounted

const EMPTY_EFFECTS := {
	"strategy_overrides": {},
	"body_changes": {},
	"relationship_changes": {},
	"errors": [],
}

static func observe(athlete, programs: Dictionary, context: Dictionary, seed: int) -> Dictionary:
	var candidates: Array[Dictionary] = []
	var equipment_risk := clampf(float(context.get("equipment_risk", 0.0)), 0.0, 100.0)
	var pain := clampf(float(context.get("pain", 0.0)), 0.0, 100.0)
	var combination_failures := maxi(0, int(context.get("key_combination_failures", 0)))
	var readiness := clampf(float(context.get("readiness", 0.0)), 0.0, 100.0)
	if equipment_risk >= 60.0:
		candidates.append(_candidate(
			"equipment_response", equipment_risk, "冰鞋状况可能影响比赛",
			{"equipment_risk": equipment_risk},
			["replace_equipment", "emergency_adjustment", "accept_equipment_risk"],
		))
	if pain >= 50.0:
		candidates.append(_candidate(
			"injury_response", pain, "公开训练后疼痛反应明显",
			{"pain": pain, "acute_fatigue": float(athlete.body.get("acute_fatigue", 0.0))},
			["medical_check", "protect_layout", "continue_as_planned"],
		))
	if combination_failures >= 3 and not Dictionary(programs.get("short", {})).is_empty():
		candidates.append(_candidate(
			"combination_response", clampf(35.0 + combination_failures * 6.0, 0.0, 90.0),
			"关键连跳在公开训练中连续中断",
			{"key_combination_failures": combination_failures},
			["simplify_combination", "focused_runthrough", "keep_layout"],
		))
	if readiness >= 86.0 and pain < 35.0 and equipment_risk < 40.0:
		candidates.append(_candidate(
			"readiness_opportunity", readiness - 8.0, "临场状态显著好于日常",
			{"readiness": readiness},
			["controlled_upgrade", "preserve_plan"],
		))
	if candidates.is_empty():
		return {
			"meaningful": false, "kind": "none", "headline": "公开训练按计划完成",
			"evidence": {}, "response_options": [], "alternatives": [], "seed": seed,
		}
	var chosen: Dictionary = candidates[0]
	for candidate in candidates:
		if float(candidate.severity) > float(chosen.severity): chosen = candidate
	var alternatives: Array[Dictionary] = []
	for candidate in candidates:
		if candidate.kind != chosen.kind:
			alternatives.append({"kind": candidate.kind, "severity": candidate.severity})
	return {
		"meaningful": true,
		"kind": chosen.kind,
		"headline": chosen.headline,
		"evidence": Dictionary(chosen.evidence).duplicate(true),
		"response_options": Array(chosen.response_options).duplicate(true),
		"alternatives": alternatives,
		"seed": seed,
	}

static func apply_response(observation: Dictionary, response_id: String) -> Dictionary:
	var allowed = observation.get("response_options", [])
	if not allowed is Array or not allowed.has(response_id):
		return _failure("当前训练观察不支持该应对选项：%s" % response_id)
	match response_id:
		"replace_equipment":
			return _effects({"equipment": "replacement_break_in", "risk": "conservative"}, {"ankle_load": -3.0}, {"coach_trust": 1.0})
		"emergency_adjustment":
			return _effects({"equipment": "emergency_adjustment", "risk": "balanced"}, {"ankle_load": -1.0}, {})
		"accept_equipment_risk":
			return _effects({"equipment": "unchanged", "risk": "aggressive"}, {"ankle_load": 4.0}, {"coach_trust": -2.0})
		"medical_check":
			return _effects({"medical_clearance": "required", "risk": "conservative"}, {"acute_fatigue": -4.0, "impact_load": -3.0}, {"coach_trust": 2.0})
		"protect_layout":
			return _effects({"risk": "conservative", "layout_protection": true}, {"impact_load": -5.0}, {"coach_trust": 1.0})
		"continue_as_planned":
			return _effects({"risk": "aggressive"}, {"impact_load": 5.0, "acute_fatigue": 3.0}, {"coach_trust": -2.0})
		"simplify_combination":
			return _effects({"combination_plan": "simplified", "risk": "conservative"}, {"impact_load": -2.0}, {})
		"focused_runthrough":
			return _effects({"combination_plan": "focused_runthrough", "risk": "balanced"}, {"acute_fatigue": 2.0}, {"coach_trust": 1.0})
		"keep_layout":
			return _effects({"combination_plan": "unchanged", "risk": "balanced"}, {}, {})
		"controlled_upgrade":
			return _effects({"readiness_use": "controlled_upgrade", "risk": "aggressive"}, {"acute_fatigue": 2.0}, {})
		"preserve_plan":
			return _effects({"readiness_use": "preserve_plan", "risk": "balanced"}, {}, {})
	return _failure("当前训练观察不支持该应对选项：%s" % response_id)

static func _candidate(kind: String, severity: float, headline: String, evidence: Dictionary, response_options: Array[String]) -> Dictionary:
	return {
		"kind": kind, "severity": severity, "headline": headline,
		"evidence": evidence, "response_options": response_options,
	}

static func _effects(strategy: Dictionary, body: Dictionary, relationships: Dictionary) -> Dictionary:
	return {
		"strategy_overrides": strategy.duplicate(true),
		"body_changes": body.duplicate(true),
		"relationship_changes": relationships.duplicate(true),
		"errors": [],
	}

static func _failure(message: String) -> Dictionary:
	var result: Dictionary = EMPTY_EFFECTS.duplicate(true)
	result.errors = [message]
	return result
