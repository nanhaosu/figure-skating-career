class_name CompetitionRecoveryDecisionService
extends RefCounted

const CODES := {"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz","axel":"A"}
const KEYS := {1:"single",2:"double",3:"triple",4:"quad"}

static func new_state(_program) -> Dictionary:
	return {"owed_parts":[],"decision_events":[],"actual_jump_counts":{}}

static func decide_immediate_continuation(athlete, _program, slot, first: Dictionary, remaining: Array, state: Dictionary, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var next := state.duplicate(true)
	if remaining.is_empty(): return _decision("none",[],["no_planned_continuation"],next)
	var held := bool(first.get("connection_held",false)) and not bool(first.get("fall",false))
	var popped := int(first.get("called_rotations",1)) < int(first.get("planned_rotations",1))
	var primary = athlete.jumps.get(str(first.get("jump_id",slot.jump_id)))
	var trained := _trained(athlete,str(remaining[0].get("jump_id","")),int(remaining[0].get("rotations",1)))
	var continuity := float(athlete.mind.get("combination_continuity",50.0))
	var trust := float(athlete.mind.get("body_trust",50.0))
	var connection := float(primary.landing.get("combination",0.0)) if primary != null else 0.0
	var utility := continuity*0.38+trust*0.20+connection*0.32+_evidence_score(trained)*0.35-float(athlete.body.get("acute_fatigue",0.0))*0.25-float(context.get("pressure",35.0))*0.08+rng.randf_range(-3.0,3.0)
	if popped: utility -= 14.0
	# A locked, rehearsed combination remains executable in the ordinary case.
	# Extra attempt evidence is required only when a pop changes the take-off
	# rhythm and the athlete must improvise from a damaged landing.
	if held and not popped:
		return _record(_decision("continue",remaining,["planned_connection"],next))
	if held and int(trained.get("attempts",0)) > 0 and utility >= 48.0:
		return _record(_decision("continue",remaining,["trained_connection","landing_window_survived"] if popped else ["trained_connection"],next))
	for part in remaining: next.owed_parts.append(Dictionary(part).duplicate(true))
	return _record(_decision("defer",[],["connection_not_safe","recovery_owed"],next))

static func decide_deferred_recovery(athlete, _program, slot, first: Dictionary, state: Dictionary, _context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var next := state.duplicate(true)
	if next.owed_parts.is_empty(): return _decision("none",[],["nothing_owed"],next)
	if bool(first.get("fall",false)) or not bool(first.get("connection_held",false)): return _record(_decision("abandon",[],["landing_window_closed"],next))
	var fatigue := float(athlete.body.get("acute_fatigue",0.0))
	var composure := float(athlete.mind.get("competition_composure",50.0))
	var urgency := float(athlete.mind.get("recovery_urgency",50.0))
	var awareness := float(athlete.mind.get("rules_awareness",50.0))
	if fatigue >= 82.0 and composure >= 75.0 and urgency < 55.0: return _record(_decision("abandon",[],["composed_abandon","body_signal_heeded"],next))
	var owed: Dictionary = next.owed_parts[0]
	if owed.get("jump_id") == "axel":
		return _record(_decision("abandon",[],["axel_sequence_requires_planned_connection"],next))
	var chosen: Dictionary = {}
	var evidence: Dictionary = {}
	for rotations in range(int(owed.get("rotations",1)),0,-1):
		var candidate_evidence := _trained(athlete,str(owed.get("jump_id","")),rotations)
		if int(candidate_evidence.get("attempts",0)) > 0:
			chosen = {"jump_id":str(owed.get("jump_id","")),"rotations":rotations}; evidence = candidate_evidence; break
	if chosen.is_empty(): return _record(_decision("abandon",[],["no_trained_recovery"],next))
	var primary = athlete.jumps.get(str(first.get("jump_id",slot.jump_id)))
	var connection := float(primary.landing.get("combination",0.0)) if primary != null else 0.0
	var code := "%d%s" % [int(chosen.rotations),CODES.get(str(chosen.jump_id),"")]
	var repetition_risk := int(next.actual_jump_counts.get(code,0)) >= 2
	if repetition_risk and not (urgency >= 80.0 and awareness <= 25.0): return _record(_decision("abandon",[],["repetition_risk_avoided"],next))
	var utility := connection*0.45+_evidence_score(evidence)*0.45+urgency*0.25-fatigue*0.24+rng.randf_range(-3.0,3.0)
	if utility < 28.0: return _record(_decision("abandon",[],["recovery_cost_too_high"],next))
	next.owed_parts.remove_at(0)
	var reasons: Array[String] = ["trained_deferred_recovery"]
	if repetition_risk: reasons.append("repetition_risk_accepted")
	return _record(_decision("recover",[chosen],reasons,next))

static func record_completed_slot(state: Dictionary, _slot, actual_parts: Array) -> Dictionary:
	var next := state.duplicate(true)
	for part in actual_parts:
		var code := "%d%s" % [int(part.get("called_rotations",part.get("rotations",0))),CODES.get(str(part.get("jump_id","")),"")]
		if not code.begins_with("0"): next.actual_jump_counts[code] = int(next.actual_jump_counts.get(code,0))+1
	return next

static func _trained(athlete, jump_id: String, rotations: int) -> Dictionary:
	if not athlete.jumps.has(jump_id) or not KEYS.has(rotations): return {}
	return Dictionary(athlete.jumps[jump_id].attempt_evidence.get(KEYS[rotations],{}))

static func _evidence_score(evidence: Dictionary) -> float:
	var attempts := int(evidence.get("attempts",0)); var successes := int(evidence.get("successes",0))
	return clampf(float(attempts)*0.35+float(successes)*0.9,0.0,100.0)

static func _decision(action: String, parts: Array, reasons: Array, state: Dictionary) -> Dictionary:
	return {"action_id":action,"selected_parts":parts.duplicate(true),"reason_codes":reasons.duplicate(),"state":state}

static func _record(decision: Dictionary) -> Dictionary:
	decision.state.decision_events.append({"action_id":decision.action_id,"selected_parts":decision.selected_parts.duplicate(true),"reason_codes":decision.reason_codes.duplicate()})
	return decision
