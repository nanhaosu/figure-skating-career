class_name EarlyPeerPoolService
extends RefCounted

const WorldGenerationService = preload("res://src/simulation/world_generation_service.gd")

const PEER_COUNT := 5

static func ensure_pool(career) -> Dictionary:
	if career == null or career.athlete == null:
		return {"peer_ids":[], "peers":[], "errors":["缺少可生成同组学员的生涯数据"]}
	var saved_ids: Array = career.world_state.get("early_peer_ids", [])
	var intact := saved_ids.size() == PEER_COUNT
	for peer_id in saved_ids:
		if not career.world_athletes.has(peer_id): intact = false
	if intact:
		return _result(career, saved_ids)
	var start_year := int(career.story_context.start_year)
	var player_age := clampi(start_year - int(career.athlete.birth_year), 6, 10)
	var club_id := str(career.social_state.get("club_id", "club-local"))
	var ids: Array[String] = []
	var staged_records: Dictionary = career.world_athletes.duplicate()
	for index in PEER_COUNT:
		var peer_id := "early-%d-%02d" % [int(career.seed), index + 1]
		ids.append(peer_id)
		if career.world_athletes.has(peer_id): continue
		var peer_club := club_id if index < 3 else "club-regional-%02d" % (index - 2)
		var record := WorldGenerationService.generate_child_record(
			staged_records, peer_id, int(career.seed), index,
			start_year, clampi(player_age + [-1, 0, 1, 0, 1][index], 6, 10), peer_club,
		)
		if record.has("errors"): return {"peer_ids":[], "peers":[], "errors":record.errors}
		staged_records[peer_id] = record
	career.world_athletes = staged_records
	career.world_state["early_peer_ids"] = ids.duplicate()
	career.world_state["athlete_ids"] = career.world_athletes.keys()
	career.world_state.athlete_ids.sort()
	return _result(career, ids)

static func _result(career, ids: Array) -> Dictionary:
	var peers: Array[Dictionary] = []
	for peer_id in ids: peers.append(Dictionary(career.world_athletes[peer_id]).duplicate(true))
	return {"peer_ids":ids.duplicate(), "peers":peers, "errors":[]}
