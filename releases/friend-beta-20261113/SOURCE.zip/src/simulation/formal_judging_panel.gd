class_name FormalJudgingPanel
extends RefCounted

static func score(performance: Dictionary, technical_review: Dictionary, presentation: Dictionary, rules: Dictionary, judge_profiles: Array, seed: int) -> Dictionary:
	var count = rules.get("panel",{}).get("judge_count",9)
	if not (count is int or count is float) or float(count) not in [5.0,7.0,9.0] or judge_profiles.size() != int(count):
		return _error("正式比赛裁判人数与有效计分目录不一致")
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var performance_by_id := {}
	for element in performance.get("elements", []):
		if element is Dictionary: performance_by_id[str(element.get("element_id", ""))] = element
	var element_scores: Array[Dictionary] = []
	var judge_rows: Array[Dictionary] = []
	for judge in judge_profiles: judge_rows.append({"profile":judge.duplicate(true),"judge_id":judge.get("judge_id",""),"goe":{},"pcs":{}})
	var tes := 0.0
	for final_element in technical_review.get("final_elements", []):
		if not final_element is Dictionary: continue
		var source: Dictionary = performance_by_id.get(str(final_element.get("element_id", "")), {})
		var judge_goes: Array[int] = []
		for index in judge_profiles.size():
			var mark := _judge_goe(final_element, source, judge_profiles[index], rng)
			judge_goes.append(mark)
			judge_rows[index].goe[str(final_element.element_id)] = mark
		var average_goe := _trimmed_average(judge_goes)
		var goe_unit := float(final_element.get("goe_base_value", final_element.get("base_value", 0.0))) * float(rules.get("goe_percent_per_step", 0.1))
		goe_unit = float(rules.get("goe_step_values",{}).get(final_element.get("abbreviation",""),goe_unit))
		var goe_points := snappedf(average_goe * goe_unit, 0.01)
		var element_total := snappedf(float(final_element.get("base_value", 0.0)) + goe_points, 0.01)
		element_scores.append({
			"element_id": str(final_element.get("element_id", "")), "abbreviation": str(final_element.get("abbreviation", "")),
			"judge_goes": judge_goes, "trimmed_average": snappedf(average_goe, 0.01),
			"goe": goe_points, "base_value": float(final_element.get("base_value", 0.0)), "total": element_total,
			"info":Array(final_element.get("info",[])).duplicate(),"facts":Dictionary(final_element.get("facts",{})).duplicate(true),
			"parts":Array(final_element.get("parts",[])).duplicate(true),"final_level":int(final_element.get("final_level",-1)),
			"invalid_reason":str(final_element.get("invalid_reason","")),
			"call_confidence":final_element.get("call_confidence","clear"),"review_state":"finalized" if final_element.get("call_confidence") == "ambiguous" else "clear",
			"review_history":_review_history(final_element,technical_review.get("review_events",[])),
			"deductions":float(_fall_count(Dictionary(final_element.get("facts",{})))),
		})
		tes += element_total
	tes = snappedf(tes, 0.01)
	var segment := str(performance.get("segment", "short"))
	var component_rules: Dictionary = Dictionary(rules.get("components", {}))
	var pcs_factor := float(component_rules.get(segment, {}).get("factor", 0.8))
	var component_scores := {}
	var pcs := 0.0
	for component_id in component_rules.get("ids", []):
		var marks: Array[float] = []
		for index in judge_profiles.size():
			var mark := _judge_component(float(presentation.get(component_id, 5.0)), judge_profiles[index], rng)
			marks.append(mark)
			judge_rows[index].pcs[component_id] = mark
		var average := snappedf(_trimmed_average(marks), 0.01)
		var factored := snappedf(average * pcs_factor, 0.01)
		component_scores[component_id] = {"judge_marks": marks, "average": average, "factor": pcs_factor, "factored": factored}
		pcs += factored
	pcs = snappedf(pcs, 0.01)
	var deductions := _deductions(performance, rules,technical_review)
	var bonus := _domestic_bonus(segment, technical_review, rules)
	var domestic_bonus := 0.0
	for item in bonus: domestic_bonus += float(item.value)
	domestic_bonus = snappedf(domestic_bonus, 0.01)
	return {
		"element_scores": element_scores, "tes": tes,
		"component_scores": component_scores, "pcs_factor": pcs_factor, "pcs": pcs,
		"deductions": deductions, "domestic_bonus": domestic_bonus,
		"domestic_bonus_breakdown": bonus,
		"total": snappedf(tes + pcs + domestic_bonus - deductions, 0.01),
		"judge_count": judge_profiles.size(), "judge_rows":judge_rows,"errors": [],
	}

static func _review_history(element: Dictionary, reviews: Array) -> Array:
	var ids: Array = [element.get("element_id", "")]
	for part in element.get("parts", []): ids.append(part.get("element_id", ""))
	# Keep the original part IDs, evidence and yellow -> finalized transitions.
	return reviews.filter(func(review): return ids.has(review.get("element_id"))).duplicate(true)

static func _judge_goe(element: Dictionary, performance_element: Dictionary, judge, rng: RandomNumberGenerator) -> int:
	var facts: Dictionary = Dictionary(element.get("facts", {}))
	var quality := _element_quality(facts, performance_element)
	var mark := int(round((quality - 50.0) / 10.0))
	var two_foot := _has_two_foot(facts) or str(performance_element.get("actual",{}).get("error_type","")) == "two_foot"
	# 2019/20 Communication2254: starting GOE at most+2 for this major
	# error, then a3–4 point reduction. Use the least severe documented−3;
	# the simulator does not yet distinguish degrees of double-foot landing.
	if two_foot: mark = mini(mark,2)-3
	var info: Array = element.get("info", [])
	# Communication2334: q keeps BV; reduce starting GOE by two steps.
	# It is not an automatic negative GOE and never replaces a fall penalty.
	var quarter_count := _quarter_count(element)
	if quarter_count > 1: mark = mini(mark,2)
	mark -= 2*quarter_count
	if info.has("*"): mark = -5
	elif info.has("<<"): mark = mini(mark, -3)
	elif info.has("e"): mark = mini(mark, -2)
	elif info.has("<"): mark = mini(mark, -2)
	elif info.has("!"): mark = mini(mark, -1)
	var clear_fall := _fall_count(facts) > 0 or bool(performance_element.get("actual", {}).get("fall", false))
	var discretion := clampf(float(judge.get("technical_bias", 0.0)) + float(judge.get("affinity", 0.0)), -1.0,1.0)
	var uncertainty := 1.0 - clampf(float(judge.get("consistency",0.0)),0,1)
	mark += clampi(int(round(discretion + rng.randf_range(-0.75, 0.75)*uncertainty)),-1,1)
	# Reapply hard caps AFTER preference: reputation cannot buy full GOE.
	if quarter_count > 0: mark = mini(mark,3 if quarter_count == 1 else 2-2*quarter_count)
	if info.has("<<"): mark = mini(mark,-3)
	if info.has("e") or info.has("<"): mark = mini(mark,-2)
	if clear_fall: mark = -5
	if two_foot: mark = mini(mark,-1)
	if info.has("*"): mark = -5
	return clampi(mark, -5, 5)

static func _quarter_count(element:Dictionary) -> int:
	var count := 0
	for part in element.get("parts",[]):
		if part is Dictionary and part.get("info",[]).has("q"): count += 1
	return maxi(count,1 if element.get("info",[]).has("q") else 0)

static func _has_two_foot(facts: Dictionary) -> bool:
	if bool(facts.get("two_foot",false)): return true
	for part in facts.get("parts",[]):
		if part is Dictionary and _has_two_foot(part): return true
	return false

static func _element_quality(facts: Dictionary, performance_element: Dictionary) -> float:
	if facts.has("execution_quality"): return float(facts.execution_quality)
	if facts.has("landing_quality"): return float(facts.landing_quality)
	if facts.has("parts"):
		var total := 0.0
		var count := 0
		for part in facts.parts:
			if part is Dictionary and part.has("landing_quality"):
				total += float(part.landing_quality); count += 1
		if count > 0: return total / count
	var values: Array[float] = []
	for key in ["speed", "centering", "edge_turn_accuracy", "coverage"]:
		if facts.has(key): values.append(float(facts[key]))
	if not values.is_empty():
		var total := 0.0
		for value in values: total += value
		return total / values.size()
	return float(performance_element.get("actual", {}).get("quality", 50.0))

static func _judge_component(base: float, judge, rng: RandomNumberGenerator) -> float:
	var bias := clampf(float(judge.get("pcs_bias", 0.0)) + float(judge.get("affinity", 0.0)) * 0.2,-0.75,0.75)
	var uncertainty := 1.0 - clampf(float(judge.get("consistency",0.0)),0,1)
	var raw := base + bias + rng.randf_range(-0.25, 0.25)*uncertainty
	return clampf(snappedf(raw, 0.25), 0.25, 10.0)

static func _trimmed_average(values: Array) -> float:
	if values.is_empty(): return 0.0
	var sorted := values.duplicate()
	sorted.sort()
	if sorted.size() >= 3:
		sorted.remove_at(sorted.size() - 1)
		sorted.remove_at(0)
	var total := 0.0
	for value in sorted: total += float(value)
	return total / sorted.size()

static func _deductions(performance: Dictionary, rules: Dictionary, technical_review: Dictionary) -> float:
	var falls := int(performance.get("falls", 0))
	var evidence_falls := 0
	for element in technical_review.get("final_elements",[]): evidence_falls += _fall_count(element.get("facts",{}))
	falls = maxi(falls,evidence_falls)
	var deductions: Dictionary = Dictionary(rules.get("deductions", {}))
	var total: float = min(falls, 2) * float(deductions.get("fall_first_two", 1.0))
	if falls > 2: total += (falls - 2) * float(deductions.get("fall_third_and_later", 2.0))
	total += maxf(0,float(performance.get("required_deductions",0.0)))
	return snappedf(total, 0.01)

static func _fall_count(facts: Dictionary) -> int:
	if facts.has("parts"):
		var count := 0
		for part in facts.parts: count += _fall_count(part)
		return count
	return 1 if bool(facts.get("fall",false)) else 0

static func _domestic_bonus(segment: String, technical_review: Dictionary, rules: Dictionary) -> Array[Dictionary]:
	var bonus_rules: Dictionary = Dictionary(rules.get("domestic_bonus", {}))
	var result: Array[Dictionary] = []
	var distinct_triples := {}
	var has_triple_triple := false
	for element in technical_review.get("final_elements", []):
		if not element is Dictionary: continue
		var triples := _credited_triples(element)
		for code in triples: distinct_triples[code] = true
		if triples.size() >= 2 and bool(element.get("facts", {}).get("connection_held", true)):
			has_triple_triple = true
	if has_triple_triple:
		var value := float(bonus_rules.get(segment, {}).get("triple_triple", 0.0))
		if value > 0.0: result.append({"id": "triple_triple", "value": value})
	if segment == "free" and distinct_triples.size() >= 5:
		var value := float(bonus_rules.get("free", {}).get("five_triple_types", 0.0))
		if value > 0.0: result.append({"id": "five_triple_types", "value": value})
	return result

static func _credited_triples(element: Dictionary) -> Array[String]:
	var result: Array[String] = []
	if Array(element.get("info", [])).any(func(symbol): return symbol in ["<<", "<", "*"]): return result
	var facts: Dictionary = Dictionary(element.get("facts", {}))
	var parts: Array = facts.get("parts", [facts])
	for part in parts:
		if not part is Dictionary: continue
		var code := str(part.get("planned_abbreviation", part.get("credited_abbreviation", "")))
		if int(part.get("planned_rotations", int(code.left(1)))) == 3 and float(part.get("rotation_ratio", part.get("completed_rotation_ratio", 1.0))) >= 0.90 and not bool(part.get("fall", false)):
			result.append(code.substr(1))
	return result

static func _error(message: String) -> Dictionary:
	return {"element_scores": [], "tes": 0.0, "component_scores": {}, "pcs_factor": 0.0, "pcs": 0.0, "deductions": 0.0, "domestic_bonus": 0.0, "domestic_bonus_breakdown": [], "total": 0.0, "judge_count": 0, "errors": [message]}
