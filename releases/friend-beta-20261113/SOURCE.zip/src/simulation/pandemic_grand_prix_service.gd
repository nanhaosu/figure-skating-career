class_name PandemicGrandPrixService
extends RefCounted

const Calendar = preload("res://src/content/season_calendar_repository.gd")
const HOSTS := {"isu_gpusa2020":"USA","isu_gpchn2020":"CHN","isu_gprus2020":"RUS","isu_gpjpn2020":"JPN"}

static func supports(event: Dictionary) -> bool:
	return HOSTS.has(event.get("event_id")) and event.get("event_family") == "gp_stage" and int(event.get("ruleset_season_start_year",0)) == 2020

static func preview(career,event: Dictionary) -> Dictionary:
	var canonical := {}
	var loaded := Calendar.load_international_calendar(2020,"women_singles","senior")
	if loaded.errors.is_empty():
		for candidate in Calendar.playable_events(loaded.calendar):
			if candidate.event_id == event.get("event_id"): canonical = candidate; break
	var valid := supports(event) and not canonical.is_empty() and preload("res://src/simulation/international_personal_eligibility.gd")._matches_event(event,canonical,"senior")
	var host := str(HOSTS.get(event.get("event_id"),"")) if valid else ""
	var local := not host.is_empty() and (str(career.story_context.home_federation) == host or str(career.social_state.get("training_federation","")) == host)
	return {"eligible":local,"host":host,"errors":[] if valid else ["疫情大奖赛规范赛事不匹配"],"label":"2020疫情特别邀请：本国或已记录训练地选手可参加当地举办站；其他地理特邀须有具体记录。本站不计世界积分，也不产生国际最低TES。"}

static func local_record(record: Dictionary,host: String) -> bool:
	return not host.is_empty() and (str(record.get("federation","")) == host or str(record.get("training_federation","")) == host)
