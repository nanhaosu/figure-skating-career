class_name CoachLessonService
extends RefCounted

const Plan = preload("res://src/domain/training_plan.gd")
const Outcome = preload("res://src/domain/outcome_record.gd")

static func observe_archive(career, archive: Dictionary) -> void:
	if archive.get("status") != "complete" or int(archive.get("record_version",0)) != 1 or bool(archive.get("world_only",false)) or Dictionary(archive.get("player_result",{})).is_empty(): return
	var event_id := str(archive.get("event_id",""))
	if event_id.is_empty(): return
	for segment in ["short","free"]:
		var record: Dictionary = archive.get(segment+"_results",{}).get("player",{})
		var review: Dictionary = record.get("technical_review",{})
		var calls := {}
		for final in review.get("final_elements",[]): calls[str(final.get("element_id",""))] = final
		var pending := {}
		for event in review.get("review_events",[]):
			if event.get("status") != "resolved": pending[str(event.get("element_id",""))] = true
		for executed in record.get("performance",{}).get("elements",[]):
			var slot := str(executed.get("element_id",""))
			if slot.is_empty() or pending.has(slot) or not calls.has(slot): continue
			var final: Dictionary = calls[slot]
			var actual_parts: Array = executed.get("parts",[])
			var final_parts: Array = final.get("parts",[])
			if actual_parts.is_empty():
				_observe_edge(career,executed,final,pending,event_id,archive,segment,slot)
			else:
				for index in mini(actual_parts.size(),final_parts.size()):
					_observe_edge(career,actual_parts[index],final_parts[index],pending,event_id,archive,segment,slot)

static func _observe_edge(career, actual: Dictionary, final: Dictionary, pending: Dictionary, event_id: String, archive: Dictionary, segment: String, slot: String) -> void:
	var id := str(actual.get("jump_id",""))
	if not id in ["lutz","flip"] or Dictionary(actual.get("actual",{})).is_empty(): return
	if str(final.get("jump_id",id)) != id: return
	if not str(final.get("abbreviation","")).contains("Lz" if id == "lutz" else "F"): return
	if pending.has(str(actual.get("element_id",slot))) or str(final.get("abbreviation","")).is_empty(): return
	var marks: Array = final.get("info",[])
	if not marks.has("e") and not marks.has("!"): return
	var observations: Array = career.athlete.jumps[id].observations
	var observation_id := "coach:formal-edge:"+id
	# One stable concern per family: replays cannot append or resurrect a
	# resolved observation. It is a judging concern, not a permanent diagnosis.
	if observations.any(func(row): return row.get("id") == observation_id): return
	var event: Dictionary = archive.get("event",{})
	observations.append({"id":observation_id,"kind":"edge","known":true,"status":"observed","text":"正式比赛技术记录出现用刃标记，教练需结合实际训练复核；不等于永久技术缺陷。","source_event":event_id,"event_date":str(event.get("start_date",event.get("actual_dates",{}).get("start",""))),"segment":segment,"slot":slot,"element_id":str(actual.get("element_id",slot)),"symbols":["e" if marks.has("e") else "!"]})

static func project_decision(source, destination) -> void:
	destination.coach_decision = source.coach_decision.duplicate(true)
	if destination.coach_decision.is_empty(): return
	var surviving: Array = []
	var reduced := false
	for id in source.coach_decision.get("allocated_gap_ids",[]):
		if int(destination.shares.get("jump_"+str(id),0)) >= 2*Plan.SHARE_STEP and int(destination.jump_rotations.get(id,0)) >= int(source.jump_rotations.get(id,1)):
			surviving.append(id)
		else: reduced = true
	destination.coach_decision.allocated_gap_ids = surviving
	if reduced:
		var codes: Array = Array(destination.coach_decision.get("reason_codes",[])).duplicate()
		codes.erase("gap_lesson_reduced")
		codes.push_front("gap_lesson_reduced")
		destination.coach_decision.reason_codes = codes.slice(0,12)

static func decorate(career, plan) -> Dictionary:
	var result = Plan.from_dict(plan.to_dict())
	var profile: Dictionary = career.coach_assignment.technical_tendencies
	if float(profile.get("component_development",0.0)) > 0.1:
		result.expression_share = maxi(result.expression_share,mini(5,maxi(0,int(result.shares.skating_foundation)-5)))
	var lessons := {"jump_toe_loop":"toe_jump_mechanics","jump_flip":"toe_jump_mechanics","jump_lutz":"toe_jump_mechanics","skating_foundation":"edge_foundation","expression":"component_development"}
	for category in lessons:
		var factor := clampf(1.0+0.25*float(profile.get(lessons[category],0.0)),0.90,1.10)
		if is_equal_approx(factor,1.0): continue
		result.lesson_quality[category] = maxf(float(result.lesson_quality.get(category,factor)),factor)
	return {"plan":result,"reasons":["专项教学质量进入实际技能增长；外训替代对应课程，不叠加尝试次数"] if not result.lesson_quality.is_empty() else []}

static func settle(career, executed_plan, fraction: float, batches: Array = []) -> Array[Outcome]:
	var outcomes: Array[Outcome] = []
	if fraction <= 0.0 or batches.is_empty(): return outcomes
	var practiced := {}
	for batch in batches:
		var id := str(batch.get("jump_id",""))
		if career.athlete.jumps.has(id) and int(batch.get("attempts",0)) > 0 and int(executed_plan.shares.get("jump_"+id,0)) > 0:
			practiced[id] = true
	if practiced.is_empty(): return outcomes
	var profile: Dictionary = career.coach_assignment.technical_tendencies
	var portion := clampf(fraction,0.0,1.0)
	for id in practiced:
		var jump = career.athlete.jumps[id]
		var issues := ""
		for observation in jump.observations:
			if not bool(observation.get("known",true)) or observation.get("status") == "resolved": continue
			issues += str(observation.get("kind",""))+str(observation.get("code",""))+str(observation.get("label",""))+str(observation.get("text",""))+" "
		for part in [["takeoff","edge_stability","edge","用刃"],["takeoff","edge_quality","edge","用刃"],["air","axis","axis","轴"],["landing","control","landing","落冰"]]:
			if not (str(part[2]) in issues or str(part[3]) in issues): continue
			var support := clampf(0.4+float(profile.get("edge_foundation",0.0)),0.0,1.0)
			if id == "lutz": support *= clampf(1.0+float(profile.get("lutz_edge_guidance",0.0)),0.0,1.0)
			# External teaching substitutes for a local limitation, not a second pool.
			support = maxf(support,maxf(0.0,float(executed_plan.lesson_quality.get("jump_"+id,1.0))-1.0)*5.0)
			var metrics: Dictionary = jump.get(part[0])
			var before := float(metrics[part[1]])
			var change := portion*clampf(support,0.0,1.0)*clampf((95.0-before)/95.0,0.0,1.0)
			if change <= 0.0: continue
			metrics[part[1]] = before+change
			outcomes.append(Outcome.new("coach_correction","%s.%s.%s" % [id,part[0],part[1]],change,["observed_issue","executed_coach_lesson"],"coach_correction"))
	var relationship = career.relationships.get("coach",career.coach_assignment.relationship)
	var trust := clampf(float(relationship.professional_trust)/100.0,0.0,1.0)
	var support := portion*clampf(float(profile.get("psychological_attunement",0.0)),0.0,1.0)*trust
	var before := float(career.condition_state.psychology.get("stress",0.0))
	var after := maxf(0.0,before-support)
	if after < before:
		career.condition_state.psychology.stress = after
		career.condition_state.psychology.label = "压力偏高" if after >= 60.0 else ("有些紧绷" if after >= 30.0 else "心态平稳")
		outcomes.append(Outcome.new("coach_support","stress",after-before,["executed_coach_lesson","professional_trust"],"coach_support"))
	return outcomes
