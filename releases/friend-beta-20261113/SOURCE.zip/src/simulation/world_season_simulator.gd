class_name WorldSeasonSimulator
extends RefCounted

const OpponentDecisionService = preload("res://src/simulation/opponent_decision_service.gd")
const WorldGenerationService = preload("res://src/simulation/world_generation_service.gd")

static func advance_to(career, target_clock: Dictionary, bundle: Dictionary) -> Dictionary:
	if career == null or not _valid_clock(target_clock):
		return {"updated_ids":[], "errors":["世界推进需要有效时钟"]}
	if int(target_clock.year) < int(bundle.get("calendar",{}).get("calendar_year",0)) and career.world_athletes.is_empty():
		career.world_state.last_advanced_clock = target_clock.duplicate()
		return {"updated_ids":[],"errors":[]}
	var ensured := WorldGenerationService.ensure_season(career, bundle, int(career.world_state.get("world_seed", career.seed)))
	if not ensured.errors.is_empty(): return {"updated_ids":[], "errors":ensured.errors}
	var updated: Array[String] = []
	var target := _ordinal(target_clock)
	for id in career.world_athletes:
		var record: Dictionary = career.world_athletes[id]
		# Legacy records remain usable in rosters; only versioned world records
		# carry enough deterministic metadata for trajectory simulation.
		if int(record.get("world_record_version", 0)) != 1: continue
		var start := _ordinal(record.last_advanced_clock)
		if target <= start: continue
		for ordinal in range(start + 1, target + 1):
			_advance_quarter(record, ordinal)
		record.last_advanced_clock = target_clock.duplicate()
		record.last_advanced_season = _season_id(target_clock)
		updated.append(str(id))
	if Dictionary(career.world_state.last_advanced_clock).is_empty() or target > _ordinal(career.world_state.last_advanced_clock):
		career.world_state.last_advanced_clock = target_clock.duplicate()
	return {"updated_ids":updated, "errors":[]}

static func _advance_quarter(record: Dictionary, ordinal: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = WorldGenerationService.stable_seed("%d:%d" % [int(record.career_seed), ordinal])
	var year := ordinal / 4
	var quarter := ordinal % 4 + 1
	var trajectory: Dictionary = record.physical_trajectory
	trajectory.elapsed_quarters = int(trajectory.elapsed_quarters) + 1
	var birthday := str(record.birth_date)
	var month := (quarter - 1) * 3 + 1
	var before_birthday := "%02d-01" % month < birthday.substr(5)
	trajectory.age = year - int(record.athlete.birth_year) - (1 if before_birthday else 0)
	if int(trajectory.age) < 19:
		trajectory.height_cm = snappedf(minf(float(trajectory.mature_height_cm), float(trajectory.height_cm) + 0.35), 0.001)
	var late_bonus := 0.35 if bool(trajectory.late_bloomer) and int(trajectory.age) >= 16 else 0.0
	var growth := float(trajectory.development_rate) * float(trajectory.resource_level) / 100.0 + late_bonus
	var decision := OpponentDecisionService.plan(record, ordinal)
	record.opponent_decision = decision
	var allocation: Dictionary = decision.allocation
	var recovery_scale := 0.45 if decision.focus == "recovery" else 1.0
	var delta := growth + rng.randf_range(-1.0, 1.0) * float(trajectory.volatility)
	for group in ["technique", "skating", "jump_foundation"]:
		var share := float(allocation.jumps) if group == "jump_foundation" else float(allocation[group])
		for key in record.athlete[group]:
			record.athlete[group][key] = snappedf(clampf(float(record.athlete[group][key]) + delta * share * 4.0 * recovery_scale, 0.0, 95.0), 0.001)
	for jump in record.athlete.jumps.values():
		for group in ["takeoff", "air", "landing", "proficiency", "consistency"]:
			for key in jump[group]:
				if group == "proficiency" and record.has("generation_profile_id"):
					var rotations := ["", "single", "double", "triple", "quad"].find(str(key))
					if rotations > int(jump.unlocked_rotations): continue
				jump[group][key] = snappedf(clampf(float(jump[group][key]) + delta * float(allocation.jumps) * 4.0 * recovery_scale, 0.0, 95.0), 0.001)
	for segment in ["short_program", "free_program"]:
		record[segment].whole_run_familiarity = snappedf(minf(95.0, float(record[segment].whole_run_familiarity) + growth * float(allocation.programme) * 4.0 * recovery_scale), 0.001)
	record.last_advanced_clock = {"year":year, "quarter":quarter}
	record.last_advanced_season = _season_id(record.last_advanced_clock)

static func _ordinal(clock: Dictionary) -> int:
	return int(clock.year) * 4 + int(clock.quarter) - 1

static func _season_id(clock: Dictionary) -> String:
	var year := int(clock.year) - (1 if int(clock.quarter) <= 2 else 0)
	return "%d-%02d" % [year, (year + 1) % 100]

static func _valid_clock(clock: Dictionary) -> bool:
	for key in ["year", "quarter"]:
		if not (clock.get(key) is int or clock.get(key) is float): return false
		if float(clock[key]) != floorf(float(clock[key])): return false
	return int(clock.year) >= 1 and int(clock.year) <= 9999 and int(clock.quarter) >= 1 and int(clock.quarter) <= 4
