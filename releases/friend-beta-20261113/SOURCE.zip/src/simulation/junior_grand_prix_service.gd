class_name JuniorGrandPrixService
extends RefCounted

const POINTS := [15,13,11,9,7,5,4,3,2,1]
const SOURCE := "https://www.isuresults.com/events/jgp2018/jgpsladies.htm"

static func placement_points(rank: int) -> int:
	return POINTS[rank-1] if rank >= 1 and rank <= 10 else 0

static func update_points(career, archive: Dictionary) -> Dictionary:
	if archive.get("event",{}).get("event_family") != "jgp_stage": return {"errors":[]}
	var year := str(archive.get("season_id","")).left(4).to_int()
	if archive.get("status") != "complete" or not archive.get("final_standings") is Array:
		return {"errors":["JGP需要当季完整成绩"]}
	var event_id := str(archive.get("event_id",""))
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").load_bundle(year,"women_singles","junior")
	if not bundle.errors.is_empty() or str(archive.get("season_id","")) != str(bundle.get("calendar",{}).get("season_id","")):
		return {"errors":["JGP需要规范赛季的完整成绩"]}
	var stages: Array = preload("res://src/content/season_calendar_repository.gd").playable_events(bundle.calendar).filter(func(e): return e.event_family == "jgp_stage")
	if not stages.any(func(e): return e.event_id == event_id): return {"errors":["未知JGP分站"]}
	var state: Dictionary = career.selection_state.get("jgp",{"events":{},"standings":[],"qualified_ids":[]}).duplicate(true)
	if state.events.has(event_id):
		return {"errors":[] if state.events[event_id] == archive.final_standings else ["已结算分站的成绩不能改写"]}
	var seen := {}
	for row in archive.final_standings:
		if not row is Dictionary or str(row.get("athlete_id", "")).is_empty() or seen.has(row.athlete_id) or int(row.get("rank",0)) < 1: return {"errors":["JGP成绩行无效"]}
		seen[row.athlete_id] = true
		var starts := 0
		for event_rows in state.events.values():
			if event_rows.any(func(r): return r.athlete_id == row.athlete_id): starts += 1
		if starts >= 2: return {"errors":["每人最多两个JGP分站"]}
	state.events[event_id] = archive.final_standings.duplicate(true)
	var by_id := {}
	for event_rows in state.events.values():
		for row in event_rows:
			var id := str(row.athlete_id)
			if not by_id.has(id): by_id[id] = {"athlete_id":id,"points":0,"tiebreak_inputs":[999,0.0,0,0.0,0.0,0.0,0]}
			var entry: Dictionary = by_id[id]; var tie: Array = entry.tiebreak_inputs
			entry.points += placement_points(int(row.rank))
			tie[0] = mini(tie[0],int(row.rank)); tie[1] += float(row.get("total_score",0)); tie[2] += 1
			tie[3] += float(row.get("free_score",0)); tie[4] = maxf(tie[4],float(row.get("free_score",0)))
			tie[5] += float(row.get("short_score",0)); tie[6] += event_rows.size()
	state.standings = by_id.values()
	state.standings.sort_custom(func(a,b): return _compare(a,b) < 0 if _compare(a,b) != 0 else a.athlete_id < b.athlete_id)
	state.qualified_ids = []
	var expected_ids: Array = stages.map(func(event):return event.event_id)
	if year == 2022:
		var reference := preload("res://src/content/season_calendar_repository.gd").load_historical_women_reference(2022)
		expected_ids = reference.get("calendar",{}).get("events",[]).filter(func(event):return event.get("event_family") == "jgp_stage" and event.get("status") == "held").map(func(event):return event.event_id)
	state.expected_event_ids = expected_ids
	state.complete = not expected_ids.is_empty() and expected_ids.all(func(id):return state.events.has(id))
	if state.complete:
		for i in state.standings.size():
			if i < 6 or _compare(state.standings[i],state.standings[5]) == 0:
				state.qualified_ids.append(state.standings[i].athlete_id)
	state.source = SOURCE.replace("2018",str(year))
	if year == 2022: state.source = "https://jgpostrava.cz/wp-content/uploads/2022/08/JGP2022-23_Announcement_Final.pdf"
	state.tiebreak_labels = ["最佳名次","两站总分和","参赛站数","自由滑总分和","最佳自由滑","短节目总分和","两站参赛人数和"]
	career.selection_state.jgp = state
	return {"errors":[]}

static func _compare(a: Dictionary,b: Dictionary) -> int:
	if a.points != b.points: return -1 if a.points > b.points else 1
	for i in 7:
		var x: float = a.tiebreak_inputs[i]; var y: float = b.tiebreak_inputs[i]
		if not is_equal_approx(x,y): return (-1 if x < y else 1) if i == 0 else (-1 if x > y else 1)
	return 0
