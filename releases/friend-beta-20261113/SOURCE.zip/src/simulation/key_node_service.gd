class_name KeyNodeService
extends RefCounted

static func pending(career) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for node in career.condition_state.get("key_nodes", []):
		if not bool(node.get("resolved", false)): result.append(node.duplicate(true))
	return result

static func add(career, id: String, kind: String, label: String) -> Dictionary:
	if not career.condition_state.has("key_nodes"): career.condition_state.key_nodes = []
	for node in career.condition_state.key_nodes:
		if str(node.id) == id: return node
	var node := {"id":id, "kind":kind, "label":label, "resolved":false, "clock":career.clock.to_dict()}
	career.condition_state.key_nodes.append(node)
	return node

static func resolve(career, id: String, response: String) -> Dictionary:
	if response != "acknowledge": return {"ok":false, "error":"无效的节点回应"}
	for node in career.condition_state.get("key_nodes", []):
		if str(node.id) != id or bool(node.resolved): continue
		if str(node.get("kind","")) == "injury_review":
			for injury in career.condition_state.injuries:
				if str(injury.get("id","")) == id and bool(injury.get("rehabilitation_managed",false)) and str(injury.get("status","")) == "active":
					return {"ok":false,"error":"重大伤病需要确认治疗路线，不能仅确认提示"}
		node.resolved = true
		node.response_id = response
		node.resolved_clock = career.clock.to_dict()
		var event := {"kind":"key_node_resolved", "node_id":id, "response_id":response, "clock":career.clock.to_dict()}
		career.event_ledger.append(event)
		return {"ok":true, "events":[event]}
	return {"ok":false, "error":"节点不存在或已处理"}
