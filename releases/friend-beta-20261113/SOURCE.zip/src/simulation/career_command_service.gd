class_name CareerCommandService
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const AuthorityResolver = preload("res://src/simulation/authority_resolver.gd")
const PlanProposal = preload("res://src/domain/plan_proposal.gd")
const KeyNodeService = preload("res://src/simulation/key_node_service.gd")

static func apply(career: CareerState, command: Dictionary) -> Dictionary:
	if career == null:
		return {"ok":false,"career":career,"events":[],"error":"缺少生涯数据"}
	# The career was fully validated when loaded or committed. Validate the
	# mutable command surface here, but do not inflate immutable historical
	# competition payloads on every button press.
	var validation := preload("res://src/persistence/save_repository.gd")._validate_payload({"save_version":preload("res://src/persistence/save_schema.gd").CURRENT_VERSION, "saved_at_unix":0, "career":career.serialization_view()},false)
	if not validation.is_empty(): return {"ok":false,"career":career,"events":[],"error":validation}
	var working := career.transaction_copy()
	var result := _dispatch(working, command)
	if not bool(result.get("ok", false)):
		var failure := {"ok":false,"career":career,"events":[],"error":str(result.get("error","命令失败"))}
		if result.has("stop_node"): failure.stop_node = result.stop_node
		return failure
	var accepted := {"ok":true,"career":working,"events":Array(result.get("events",[])).duplicate(true),"outcomes":Array(result.get("outcomes",[])),"error":""}
	if result.has("stop_node"): accepted.stop_node = result.stop_node.duplicate(true)
	return accepted

static func _dispatch(career: CareerState, command: Dictionary) -> Dictionary:
	if not command.get("type") is String or str(command.get("type", "")).is_empty():
		return {"ok":false,"error":"命令类型无效"}
	match str(command.type):
		"choose_preparation_route":
			if not command.get("route_id") is String or not command.get("receipt_id") is String or not preload("res://src/content/annual_selection_policy_repository.gd").integer(command.get("base_revision"),0,1000000): return {"ok":false,"error":"备战方案参数无效"}
			# Validate the target on this private command candidate; a later error
			# discards both changes, so no half-updated target can escape.
			var checked := _dispatch(career.transaction_copy(),{"type":"set_season_target","event_id":command.get("event_id")})
			if not checked.ok: return checked
			var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(career)
			var event: Dictionary = bundle.calendar.events.filter(func(e):return e.event_id == command.event_id)[0]
			return preload("res://src/simulation/preparation_route_service.gd").apply(career,event,command.route_id,command.receipt_id,int(command.base_revision))
		"set_season_target":
			if not command.get("event_id") is String: return {"ok":false,"error":"赛季目标标识无效"}
			var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(career)
			if not bundle.errors.is_empty(): return {"ok":false,"error":"当前赛季资料不可用"}
			if bundle.calendar.season_id != career.season_state.get("season_id"):
				return {"ok":false,"error":"请先确认本赛季规划"}
			var matches: Array = bundle.calendar.events.filter(func(event): return event.event_id == command.event_id and event.get("status") != "cancelled" and not event.get("reference_only",false))
			if matches.size() != 1: return {"ok":false,"error":"请选择本赛季已接通的赛事"}
			career.season_state.target_event_id = command.event_id
			return {"ok":true,"events":[]}
		"configure_dated_training":
			if career.competition_timeline.mode != "dated": return {"ok":false,"error":"当前不是日期训练模式"}
			if not command.get("proposal") is Dictionary or not preload("res://src/persistence/save_repository.gd")._validate_saved_plan(command.proposal).is_empty() or command.proposal.get("status") != "resolved": return {"ok":false,"error":"请先确认完整训练安排及协商结果"}
			var proposal = PlanProposal.from_dict(command.proposal)
			if not preload("res://src/simulation/athlete_condition_service.gd").can_train(career,proposal.executed): return {"ok":false,"error":"身体状态不允许执行这份训练安排"}
			var intent := {}
			if command.has("intent"):
				if not command.intent is Dictionary: return {"ok":false,"error":"教练训练方向无效"}
				var chosen = preload("res://src/domain/training_intent.gd").from_dict(command.intent)
				if chosen == null: return {"ok":false,"error":"教练训练方向无效"}
				intent = chosen.to_dict()
			career.last_generated_plan = proposal.to_dict()
			if not intent.is_empty():
				var same_receipt := false
				for prior in career.event_ledger:
					if prior.get("kind") == "coach_curriculum" and prior.get("clock") == career.clock.to_dict() and prior.get("intent") == intent and _same_plan(prior.get("executed_plan",{}),proposal.executed.to_dict()): same_receipt = true
				if not same_receipt: career.event_ledger.append({"kind":"coach_curriculum","clock":career.clock.to_dict(),"intent":intent,"executed_plan":proposal.executed.to_dict()})
			return {"ok":true,"events":[]}
		"acknowledge_formal_result":
			if career.competition_state.is_empty(): return {"ok":true,"events":[]}
			if career.competition_state.get("status") != "complete": return {"ok":false,"error":"当前比赛尚未完成，不能跳过剩余环节"}
			var completed_id := str(career.competition_state.get("event_id",""))
			if not career.competition_archive.any(func(archive):return archive.get("event_id") == completed_id and archive.get("status") == "complete" and not archive.get("world_only",false)): return {"ok":false,"error":"比赛结果尚未写入正式档案"}
			if career.competition_timeline.mode == "dated":
				var consumed: Dictionary = load("res://src/simulation/dated_training_service.gd").consume_completed_competition(career,completed_id)
				if not consumed.ok: return consumed
			var trials = load("res://src/simulation/beijing_trial_service.gd")
			if trials.event_ids().has(completed_id):
				var date := str(career.competition_timeline.date) if career.competition_timeline.mode == "dated" else "%04d-%02d-%02d" % [career.clock.year,career.clock.quarter*3,[31,30,30,31][career.clock.quarter-1]]
				var settled: Dictionary = trials.settle_sources(career,date)
				if not settled.ok: return settled
			career.competition_state = {}
			return {"ok":true,"events":[]}
		"enroll_beijing_trials":
			if not command.get("receipt_id") is String: return {"ok":false,"error":"选拔报名确认编号无效"}
			return load("res://src/simulation/beijing_trial_service.gd").enroll(career,"beijing2022_women_trials",command.receipt_id)
		"begin_dated_training":
			return load("res://src/simulation/dated_training_service.gd").activate(career)
		"consume_completed_competition_dates":
			if not command.get("event_id") is String: return {"ok":false,"error":"赛事标识无效"}
			return load("res://src/simulation/dated_training_service.gd").consume_completed_competition(career,command.event_id)
		"advance_dated_training":
			if not command.get("target_date") is String: return {"ok":false,"error":"训练目标日期无效"}
			var data: Dictionary = career.last_generated_plan
			var plan = TrainingPlan.from_dict(data.get("executed",data))
			if plan == null and career.competition_timeline.mode == "dated" and preload("res://src/domain/competition_timeline.gd").validate(career.competition_timeline,career.clock.to_dict()).is_empty():
				return {"ok":false,"stop_node":load("res://src/simulation/season_progression_service.gd")._node(career,"training_plan","请先确定可以沿用的训练方案")}
			return load("res://src/simulation/dated_training_service.gd").advance_until(career,command.target_date,plan)
		"record_birth_date":
			return _record_birth_date(career,command)
		"resolve_program_upgrade":
			if not command.get("proposal") is Dictionary or not command.get("receipt_id") is String or not command.get("choice") in ["accept","decline"]: return {"ok":false,"error":"节目建议命令无效"}
			var service = preload("res://src/simulation/program_upgrade_service.gd")
			return service.apply(career,command.proposal,command.receipt_id) if command.choice == "accept" else service.decline(career,command.proposal,command.receipt_id)
		"resolve_offseason_event":
			if not command.get("event_id") is String or not command.get("choice_id") is String: return {"ok":false,"error":"休赛期选择字段无效"}
			return preload("res://src/simulation/offseason_event_service.gd").resolve(career,command.event_id,command.choice_id)
		"book_external_training":
			for field in ["offer_id","focus_id","receipt_id"]:
				if not command.get(field) is String: return {"ok":false,"error":"外训预约字段无效"}
			return load("res://src/simulation/external_training_service.gd").book(career,command.offer_id,command.focus_id,command.receipt_id)
		"cancel_external_training":
			for field in ["booking_id","receipt_id"]:
				if not command.get(field) is String: return {"ok":false,"error":"外训取消字段无效"}
			return load("res://src/simulation/external_training_service.gd").cancel(career,command.booking_id,command.receipt_id)
		"set_training_direction":
			if not command.get("direction") is Dictionary or not command.get("receipt_id") is String: return {"ok":false,"error":"训练方向命令无效"}
			return load("res://src/simulation/training_direction_service.gd").change(career,command.direction,command.receipt_id)
		"confirm_program_replacement":
			if not command.get("proposal") is Dictionary or not command.get("receipt_id") is String: return {"ok":false,"error":"节目替代确认字段无效"}
			return load("res://src/simulation/program_fallback_service.gd").confirm(career,command.proposal,command.receipt_id)
		"confirm_season_program":
			if not command.get("draft") is Dictionary or not command.get("receipt_id") is String: return {"ok":false,"error":"赛季规划确认字段无效"}
			return load("res://src/simulation/season_program_service.gd").confirm(career,command.draft,command.receipt_id)
		"choose_rehabilitation":
			for field in ["injury_id","route_id","receipt_id"]:
				if not command.get(field) is String: return {"ok":false,"error":"治疗选择字段无效"}
			return load("res://src/simulation/rehabilitation_service.gd").choose(career,command.injury_id,command.route_id,command.receipt_id)
		"withdraw_entry":
			if not command.get("event_id") is String: return {"ok":false,"error":"退赛命令无效"}
			return load("res://src/simulation/entry_application_service.gd").withdraw(career,command.event_id)
		"advance_quarter":
			return _advance_quarter(career,command)
		"apply_entry":
			return load("res://src/simulation/entry_application_service.gd").apply(career,command)
		"apply_domestic_schedule":
			return load("res://src/simulation/entry_application_service.gd").apply_domestic_schedule(career,command.get("event_ids"))
		"resolve_key_node":
			if not command.get("node_id") is String or not command.get("response_id") is String:
				return {"ok":false,"error":"节点命令字段无效"}
			return KeyNodeService.resolve(career, command.node_id, command.response_id)
		"resolve_authority_conflict":
			return _resolve_authority(career, command)
		"record_event":
			if not command.get("event") is Dictionary:
				return {"ok":false,"error":"命令字段 event 必须是对象"}
			var event: Dictionary = Dictionary(command.event).duplicate(true)
			career.event_ledger.append(event)
			return {"ok":true,"events":[event.duplicate(true)]}
		_:
			return {"ok":false,"error":"未知命令：%s" % str(command.type)}

static func _record_birth_date(career, command: Dictionary) -> Dictionary:
	var identity = preload("res://src/domain/athlete_identity.gd")
	if not command.get("birth_date") is Dictionary or not command.get("receipt_id") is String or str(command.get("receipt_id", "")).strip_edges().is_empty():
		return {"ok":false,"error":"请明确填写出生月日"}
	var date: Dictionary = command.birth_date
	var errors: Array[String] = identity.validate_birth_date(date,career.athlete.birth_year)
	if date.is_empty() or not errors.is_empty():
		return {"ok":false,"error":"请明确填写出生月日" if date.is_empty() else "；".join(errors)}
	date = identity.canonical_birth_date(date,career.athlete.birth_year)
	for entry in career.event_ledger:
		if entry.get("kind") == "birth_date_recorded" and entry.get("receipt_id") == command.receipt_id:
			if entry.get("birth_date") == date and career.athlete.birth_date == date:
				return {"ok":true,"events":[]}
			return {"ok":false,"error":"这次生日补充已处理，不能改为其他日期"}
	if not career.athlete.birth_date.is_empty():
		return {"ok":false,"error":"出生日期已确定，不能通过修改生日改变参赛年龄"}
	career.athlete.birth_date = date
	var event := {"kind":"birth_date_recorded","receipt_id":command.receipt_id,"birth_date":date.duplicate(true),"clock":career.clock.to_dict()}
	career.event_ledger.append(event)
	return {"ok":true,"events":[event]}

static func _advance_quarter(career, command: Dictionary) -> Dictionary:
	if career.competition_timeline.mode == "dated": return {"ok":false,"error":"日期模式不能重复领取旧季度训练，请沿日期流程推进"}
	if command.has("expected_clock"):
		if not command.expected_clock is Dictionary or not preload("res://src/persistence/save_repository.gd")._validate_clock(command.expected_clock).is_empty(): return {"ok":false,"error":"预期训练季度无效"}
		if int(command.expected_clock.year) != career.clock.year or int(command.expected_clock.quarter) != career.clock.quarter: return {"ok":false,"error":"该训练请求所属季度已过期"}
	if command.has("expected_stage"):
		var expected = command.expected_stage
		if not expected is int or int(expected) < 0 or int(expected) > 3: return {"ok":false,"error":"预期训练阶段无效"}
		var actual := int(career.training_period_state.get("stage_checkpoint",{}).get("next_stage",0))
		if int(expected) != actual: return {"ok":false,"error":"该阶段请求已处理或已过期"}
	if command.has("stage_limit"):
		var limit = command.stage_limit
		if not limit is int or int(limit) < 1 or int(limit) > 4: return {"ok":false,"error":"训练阶段上限必须为1至4的整数"}
	var coordinator = load("res://src/simulation/season_progression_service.gd")
	var pending: Dictionary = coordinator.quarter_gate(career,command.get("bundle",{"calendar":{"events":[]}}))
	if not pending.is_empty(): return {"ok":false,"stop_node":pending}
	var one_quarter_plan := str(career.last_training_policy.get("policy_id", "")) == "recovery"
	var data: Dictionary = career.last_generated_plan
	var coach_intent := _continuation_intent(career,data) if career.training_period_state.is_empty() and not one_quarter_plan else {}
	if not coach_intent.is_empty():
		var rebuilt: Dictionary = load("res://src/simulation/coach_training_plan_service.gd").build(career,load("res://src/domain/training_intent.gd").from_dict(coach_intent))
		if not rebuilt.errors.is_empty(): return {"ok":false,"stop_node":coordinator._node(career,"training_plan","请重新与教练确认训练方向")}
		data = rebuilt.plan.to_dict()
	if data.is_empty() and not career.last_training_policy.is_empty():
		var policy = load("res://src/domain/training_policy.gd").from_dict(career.last_training_policy)
		if policy != null: data = load("res://src/simulation/training_policy_planner.gd").build(career,policy,{}).plan.to_dict()
	var plan = TrainingPlan.from_dict(data.get("executed",data))
	if plan == null: return {"ok":false,"stop_node":coordinator._node(career,"training_plan","请先确定可以沿用的训练方案")}
	for segment in ["short","free"]:
		if int(plan.shares.get("program_"+segment,plan.allocations.get("program_"+segment,0))) > 0 and career.active_programs.get(segment,{}).is_empty():
			var node: Dictionary = coordinator._node(career,"program_adjustment","训练安排需要先创建节目","",[{"id":"edit_program","segment":segment}])
			node.segment = segment
			var current_level: String = preload("res://src/simulation/competitive_level_service.gd").current(career)
			node.rules = load("res://src/content/internal_event_rules.gd").for_teaching_group(segment) if career.clock.year < 2018 else load("res://src/content/internal_event_rules.gd").for_season(load("res://src/content/season_bundle_repository.gd").season_year(career),"senior" if current_level == "senior" else "junior",segment)
			return {"ok":false,"stop_node":node}
	if not load("res://src/simulation/athlete_condition_service.gd").can_train(career,plan):
		return {"ok":false,"stop_node":coordinator._node(career,"medical_restriction","伤病期间需要修改训练方案")}
	var proposal = PlanProposal.from_dict(data) if data.get("status") == "resolved" else AuthorityResolver.preview(career,plan)
	var agreed: Dictionary = career.training_period_state.get("agreed_proposal",{})
	if career.training_period_state.has("stage_checkpoint") and not agreed.is_empty():
		if agreed.get("status") == "resolved" and _same_plan(agreed.get("executed",{}),plan.to_dict()) and _same_plan(career.training_period_state.stage_checkpoint.get("plan",{}),plan.to_dict()): proposal = PlanProposal.from_dict(agreed)
	if proposal.status != "resolved": return {"ok":false,"stop_node":coordinator._node(career,"authority_conflict","教练或监护人需要与你协商训练安排","",proposal.conflicts[0].responses)}
	var rng := RandomNumberGenerator.new()
	rng.seed = career.seed + career.rng_step * preload("res://src/simulation/career_simulator.gd").RNG_STEP_OFFSET + 17
	var events: Array = load("res://src/simulation/event_engine.gd").generate(career,proposal,rng)
	if not events.is_empty(): return {"ok":false,"stop_node":coordinator._node(career,"quarter_event",events[0].description,"",events[0].choices)}
	var start: Dictionary = career.clock.to_dict(); var history_size: int = career.history.size()
	if command.has("stage_limit"):
		if proposal.executed.shares.is_empty() or career.training_period_state.is_empty(): return {"ok":false,"error":"分阶段推进需要已确认的百分比训练期"}
		career.training_period_state.agreed_proposal = proposal.to_dict()
		career.training_period_state.stage_limit = command.stage_limit
	var outcomes: Array = load("res://src/simulation/career_simulator.gd").advance_proposal(career,proposal,load("res://src/content/catalog_repository.gd").load_catalog())
	career.training_period_state.erase("stage_limit")
	career.last_generated_plan = proposal.executed.to_dict()
	if career.training_period_state.has("stage_checkpoint"):
		var partial_event := {"kind":"training_stage_committed","clock":career.clock.to_dict(),"weeks_elapsed":career.training_period_state.weeks_elapsed}
		career.event_ledger.append(partial_event)
		return {"ok":true,"events":[partial_event],"outcomes":outcomes}
	if not coach_intent.is_empty():
		career.event_ledger.append({"kind":"coach_curriculum", "clock":career.clock.to_dict(), "intent":coach_intent, "executed_plan":career.last_generated_plan.duplicate(true)})
	var training_events: Array = []
	for record in career.history.slice(history_size):
		if record.get("category") == "roadmap_progress": training_events.append_array(load("res://src/simulation/event_engine.gd").from_roadmap_progress(record))
	training_events.append_array(load("res://src/simulation/event_engine.gd").from_training_milestones(career,career.history.slice(history_size)))
	if not training_events.is_empty(): career.condition_state.pending_training_events = training_events.map(func(e): return e.to_dict())
	var world: Dictionary = load("res://src/simulation/world_season_simulator.gd").advance_to(career,career.clock.to_dict(),command.get("bundle",{}))
	if not world.errors.is_empty(): return {"ok":false,"error":str(world.errors)}
	var event := {"kind":"quarter_advanced","clock":career.clock.to_dict(),"from_clock":start,"reason":"沿用训练方案，身体与世界同步推进"}
	career.event_ledger.append(event)
	var committed_events: Array = [event]
	if one_quarter_plan:
		career.last_training_policy = {}
		career.last_generated_plan = {}
		var expired := {"kind":"training_plan_expired","clock":career.clock.to_dict(),"reason":"恢复与整理是一季度临时方案，请根据恢复结果重新安排训练"}
		career.event_ledger.append(expired)
		committed_events.append(expired)
	return {"ok":true,"events":committed_events,"outcomes":outcomes}

static func _continuation_intent(career, plan: Dictionary) -> Dictionary:
	# Receipts distinguish adaptive coaching from deliberately edited/manual
	# allocations without changing the save schema or guessing from percentages.
	for index in range(career.event_ledger.size()-1,-1,-1):
		var entry: Dictionary = career.event_ledger[index]
		if str(entry.get("kind", "")) != "coach_curriculum": continue
		if not entry.get("executed_plan", {}) is Dictionary: return {}
		var recorded_plan: Dictionary = entry.get("executed_plan", {}).duplicate(true)
		CareerState.restore_plan_integers(recorded_plan)
		if recorded_plan != plan: return {}
		if not entry.get("intent", {}) is Dictionary: return {}
		var intent = load("res://src/domain/training_intent.gd").from_dict(entry.get("intent", {}))
		return intent.to_dict() if intent != null else {}
	return {}

static func _same_plan(left: Dictionary, right: Dictionary) -> bool:
	# Extensible checkpoint numbers are restored as JSON floats. Compare the
	# normalized content, never weaken equality to only shares or slot counts.
	return JSON.parse_string(JSON.stringify(left)) == JSON.parse_string(JSON.stringify(right))

static func _resolve_authority(career, command: Dictionary) -> Dictionary:
	var invalid := {"ok":false,"error":"训练冲突命令无效或已过期"}
	if not command.get("proposal") is Dictionary or not command.get("conflict_id") is String or not command.get("response_id") is String: return invalid
	var data: Dictionary = command.proposal.duplicate(true)
	if not data.get("desired") is Dictionary: return invalid
	if not preload("res://src/persistence/save_repository.gd")._validate_saved_plan(data).is_empty(): return invalid
	CareerState.restore_plan_integers(data)
	var receipt := "%d:%d:%s:%s" % [career.clock.year, career.clock.quarter, command.conflict_id, JSON.stringify(data.get("desired", {}))]
	for event in career.event_ledger:
		if event.get("authority_receipt") == receipt: return invalid
	var desired: Dictionary = data.desired
	var plan = TrainingPlan.from_dict(desired)
	if plan == null: return invalid
	if not preload("res://src/simulation/athlete_condition_service.gd").can_train(career, plan): return {"ok":false,"error":"伤病恢复期间不能执行该训练安排"}
	var proposal = AuthorityResolver.preview(career, plan)
	# Never execute caller-supplied caps, approval flags or secret intents.
	if proposal.to_dict() != data:
		if career.last_generated_plan != data or str(data.get("status", "")) != "needs_response": return invalid
		proposal = PlanProposal.from_dict(career.last_generated_plan)
	var conflict = null
	for candidate in proposal.conflicts:
		if candidate.id == command.conflict_id: conflict = candidate
	if conflict == null or not conflict.responses.any(func(r): return r.id == command.response_id): return invalid
	var event_start: int = career.event_ledger.size()
	AuthorityResolver.respond(career, proposal, command.conflict_id, command.response_id, career.random_streams.take_rng("authority"))
	if proposal.desired == null or proposal.approved == null or proposal.executed == null: return invalid
	if command.response_id != "ask_reason": career.event_ledger.append({"kind":"authority_resolved", "authority_receipt":receipt, "clock":career.clock.to_dict()})
	career.last_generated_plan = proposal.to_dict()
	return {"ok":true,"events":career.event_ledger.slice(event_start)}
