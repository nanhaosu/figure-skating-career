class_name BetweenSegmentAdjuster
extends RefCounted

const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")

static func revise(original, edited, athlete, rules: Dictionary) -> Dictionary:
	var errors := ProgramValidator.validate(edited, athlete, rules)
	if original == null or edited == null or original.segment != edited.segment: errors.append("原节目与修订节目分段不一致")
	if not errors.is_empty(): return {"program":original, "familiarity_cost":0.0, "errors":errors}
	var result = SkatingProgram.from_dict(edited.to_dict())
	var cost := 0.0
	var old_by_id := {}
	for index in original.elements.size(): old_by_id[original.elements[index].element_id] = {"element":original.elements[index], "index":index}
	for index in edited.elements.size():
		var element = edited.elements[index]
		var previous: Dictionary = old_by_id.get(element.element_id, {})
		var changed: bool = previous.is_empty() or previous.element.to_dict() != element.to_dict()
		var slot_cost := 0.0
		if changed: slot_cost += 4.0 + element.combination_parts.size() * 2.0 + element.entry_difficulty * 2.0
		if not previous.is_empty() and int(previous.index) != index: slot_cost += 2.0
		cost += slot_cost
		result.slot_familiarity[element.element_id] = maxf(0.0, float(original.slot_familiarity.get(element.element_id, 0.0)) - slot_cost * 2.0)
		old_by_id.erase(element.element_id)
	cost += old_by_id.size() * 4.0
	if original.route_complexity != edited.route_complexity: cost += 4.0
	if original.music != edited.music: cost += 12.0
	result.whole_run_familiarity = maxf(0.0, original.whole_run_familiarity - cost)
	result.revision = original.revision + (1 if cost > 0.0 else 0)
	return {"program":result, "familiarity_cost":cost, "errors":[]}

static func propose(free_program, option_id: String) -> Dictionary:
	var result := apply(free_program, option_id)
	# Presets suggest content/strategy. Familiarity is charged once on confirmation.
	result.program.whole_run_familiarity = free_program.whole_run_familiarity
	result.program.slot_familiarity = free_program.slot_familiarity.duplicate(true)
	result.familiarity_cost = 0.0
	return result

static func options(short_result: Dictionary, free_program) -> Array[Dictionary]:
	var result: Array[Dictionary] = [{"id": "keep", "label": "保持原自由滑方案", "reason": "不增加临时改动代价"}]
	if (int(short_result.get("falls", 0)) > 0 or float(short_result.get("fatigue_end", 0.0)) >= 45.0) and _has_reducible_jump(free_program):
		result.append({"id": "protect", "label": "降低一个高风险跳跃", "reason": "保护体能并减少连锁失误"})
	if int(short_result.get("provisional_rank", 1)) >= 2:
		result.append({"id": "chase", "label": "追赶名次", "reason": "提高执行风险，保留原定难度"})
	return result

static func apply(free_program, option_id: String) -> Dictionary:
	var program = SkatingProgram.from_dict(free_program.to_dict())
	if option_id == "keep": return {"program": program, "strategy_overrides": {}, "familiarity_cost": 0.0}
	if option_id == "protect":
		var target = null
		for element in program.elements:
			if element.kind == "jump" and element.rotations > 1 and (target == null or element.rotations > target.rotations): target = element
		if target != null:
			target.rotations -= 1
			program.slot_familiarity[target.element_id] = maxf(0.0, float(program.slot_familiarity.get(target.element_id, 0.0)) - 18.0)
		program.whole_run_familiarity = maxf(0.0, program.whole_run_familiarity - 10.0)
		return {"program": program, "strategy_overrides": {"risk": "conservative"}, "familiarity_cost": 10.0}
	if option_id == "chase":
		program.whole_run_familiarity = maxf(0.0, program.whole_run_familiarity - 4.0)
		return {"program": program, "strategy_overrides": {"risk": "aggressive"}, "familiarity_cost": 4.0}
	return {"program": program, "strategy_overrides": {}, "familiarity_cost": 0.0}

static func _has_reducible_jump(program) -> bool:
	for element in program.elements:
		if element.kind == "jump" and element.rotations > 1: return true
	return false
