class_name ProgramRevisionService
extends RefCounted

const SkatingProgram = preload("res://src/domain/skating_program.gd")

const MUSIC_CHANGE_WHOLE_RUN_RETENTION := 0.35
const ACTION_CHANGE_WHOLE_RUN_FLOOR := 0.80
const RELATED_ACTION_FAMILIARITY_RETENTION := 0.65

static func change_music(old_program, music, new_program_id: String) -> Dictionary:
	if old_program == null or music == null: return {"program": null, "archived": null, "errors": ["节目或曲目不存在"]}
	var revised = SkatingProgram.from_dict(old_program.to_dict())
	revised.program_id = new_program_id.strip_edges()
	if revised.program_id.is_empty(): return {"program": null, "archived": null, "errors": ["新节目必须有唯一编号"]}
	revised.music = music.to_dict()
	revised.whole_run_familiarity = snappedf(float(old_program.whole_run_familiarity) * MUSIC_CHANGE_WHOLE_RUN_RETENTION, 0.01)
	return {"program": revised, "archived": SkatingProgram.from_dict(old_program.to_dict()), "errors": []}

static func replace_program(old_program, replacement) -> Dictionary:
	if old_program == null or replacement == null: return {"program": null, "archived": null, "errors": ["原节目或替换节目不存在"]}
	if old_program.segment != replacement.segment: return {"program": null, "archived": null, "errors": ["短节目与自由滑不能互相替换"]}
	return {"program": SkatingProgram.from_dict(replacement.to_dict()), "archived": SkatingProgram.from_dict(old_program.to_dict()), "errors": []}

static func revise(old_program, edited_program) -> Dictionary:
	if old_program == null or edited_program == null:
		return {"program":null, "archived":null, "errors":["节目不存在"]}
	if old_program.segment != edited_program.segment:
		return {"program":null, "archived":null, "errors":["短节目与自由滑不能互相替换"]}
	var original_data: Dictionary = old_program.to_dict()
	var edited_data: Dictionary = edited_program.to_dict()
	var action_changed: bool = original_data.elements != edited_data.elements
	var music_changed: bool = original_data.music != edited_data.music
	var route_changed: bool = original_data.route_complexity != edited_data.route_complexity or original_data.choreography_quality != edited_data.choreography_quality
	var renamed: bool = original_data.program_id != edited_data.program_id
	var workflow_changed: bool = original_data.draft_status != edited_data.draft_status or original_data.locked_segments != edited_data.locked_segments
	if old_program.draft_status == "locked" and old_program.locked_segments.has(old_program.segment) and (action_changed or music_changed or route_changed or renamed):
		var segment_label := "短节目" if old_program.segment == "short" else "自由滑"
		return {"program":null, "archived":null, "errors":["%s已锁定参赛，不能在未解锁的情况下修改" % segment_label]}
	if not action_changed and not music_changed and not route_changed and not renamed and workflow_changed:
		return {"program":SkatingProgram.from_dict(edited_data), "archived":null, "changed":false, "errors":[]}
	if not action_changed and not music_changed and not route_changed and not renamed:
		return {"program":SkatingProgram.from_dict(original_data), "archived":null, "changed":false, "errors":[]}
	var revised = SkatingProgram.from_dict(edited_program.to_dict())
	revised.revision = old_program.revision + 1
	for element in revised.elements:
		var previous_familiarity := float(old_program.slot_familiarity.get(element.element_id, 0.0))
		if _same_action(old_program, element):
			revised.slot_familiarity[element.element_id] = previous_familiarity
		elif _related_action(old_program, element):
			# Changing a following jump still requires fresh connection practice,
			# but it does not erase the skater's entry, take-off and landing memory
			# for the primary jump in this slot.
			revised.slot_familiarity[element.element_id] = snappedf(previous_familiarity * RELATED_ACTION_FAMILIARITY_RETENTION, 0.01)
		else:
			revised.slot_familiarity[element.element_id] = 0.0
	var action_retention := _action_change_retention(old_program, revised)
	var retention := MUSIC_CHANGE_WHOLE_RUN_RETENTION if music_changed else (action_retention if action_changed else (0.65 if route_changed else 1.0))
	revised.whole_run_familiarity = snappedf(float(old_program.whole_run_familiarity) * retention, 0.01)
	return {"program":revised, "archived":SkatingProgram.from_dict(original_data), "changed":true, "errors":[]}

static func _same_action(old_program, candidate) -> bool:
	for previous in old_program.elements:
		if previous.element_id == candidate.element_id:
			return previous.to_dict() == candidate.to_dict()
	return false

static func _related_action(old_program, candidate) -> bool:
	for previous in old_program.elements:
		if previous.element_id != candidate.element_id or previous.kind != candidate.kind:
			continue
		if candidate.kind == "jump":
			return previous.jump_id == candidate.jump_id and previous.rotations == candidate.rotations
		if candidate.kind == "spin":
			return previous.spin_code == candidate.spin_code
		return true
	return false

static func _action_change_retention(old_program, revised_program) -> float:
	var old_by_id := {}
	for element in old_program.elements: old_by_id[element.element_id] = element
	var changed := 0
	for element in revised_program.elements:
		if not old_by_id.has(element.element_id) or old_by_id[element.element_id].to_dict() != element.to_dict(): changed += 1
	for element in old_program.elements:
		if not revised_program.elements.any(func(candidate): return candidate.element_id == element.element_id): changed += 1
	var denominator: float = maxf(float(maxi(old_program.elements.size(), revised_program.elements.size())), 1.0)
	var changed_fraction := clampf(float(changed) / denominator, 0.0, 1.0)
	return lerpf(1.0, ACTION_CHANGE_WHOLE_RUN_FLOOR, changed_fraction)
