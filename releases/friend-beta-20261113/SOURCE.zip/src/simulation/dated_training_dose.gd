class_name DatedTrainingDose
extends RefCounted

const Repertoire = preload("res://src/domain/technical_repertoire.gd")
# LCM(90,91,92). Fractions stay exact across all calendar quarter lengths.
const MAX_DENOMINATOR := 376740

# Exact elapsed-period bookkeeping shared with calendar rehabilitation. A day
# is a fraction of its actual calendar quarter, including leap-year Q1.
static func accrue_period(fraction: Dictionary,days: Variant,period_days: Variant) -> Dictionary:
	if not _integer(days) or not _integer(period_days) or int(period_days) not in [90,91,92] or int(days) < 0 or int(days) > int(period_days): return {"errors":["康复日数无效"]}
	if not fraction.is_empty():
		if fraction.size() != 2 or not _integer(fraction.get("n")) or not _integer(fraction.get("d")) or int(fraction.d) < 1 or int(fraction.d) > MAX_DENOMINATOR or MAX_DENOMINATOR % int(fraction.d) != 0 or int(fraction.n) < 0 or int(fraction.n) >= int(fraction.d): return {"errors":["康复剩余日历时长无效"]}
	var pending := {}
	if not fraction.is_empty(): pending.elapsed = fraction.duplicate(true)
	var completed := _take(1,int(days),int(period_days),"elapsed",pending)
	return {"errors":[],"completed_periods":completed,"fraction":pending.get("elapsed",{"n":0,"d":1})}

# Amount allocation only, not a quarter simulation followed by scaling.
# The dated executor must consume chronological days and apply these actual
# attempts through the shared training/health services before committing time.
static func slice(reference: Dictionary,days: Variant,period_days: Variant,remainders: Dictionary,rotations: Dictionary) -> Dictionary:
	if not _integer(days) or not _integer(period_days) or int(period_days) not in [90,91,92] or int(days) < 0 or int(days) > int(period_days): return _failure("训练剂量需要本季度内的非负整数日数",remainders)
	for key in remainders:
		var fraction = remainders[key]
		if not key is String or not fraction is Dictionary or not _integer(fraction.get("n")) or not _integer(fraction.get("d")) or int(fraction.d) < 1 or int(fraction.d) > MAX_DENOMINATOR or MAX_DENOMINATOR % int(fraction.d) != 0 or int(fraction.n) < 0 or int(fraction.n) >= int(fraction.d): return _failure("训练尝试余数不是有界有效分数",remainders)
	if not reference.get("category_volumes") is Dictionary or not reference.get("jump_attempts") is Dictionary or not reference.get("specialist_attempts",[]) is Array: return _failure("训练参考剂量结构无效",remainders)
	var volume := reference.duplicate(true)
	var pending := remainders.duplicate(true)
	for category in volume.category_volumes:
		var amount = volume.category_volumes[category]
		if not _amount(amount): return _failure("训练分类剂量无效",remainders)
		volume.category_volumes[category] = float(amount) if int(days) == int(period_days) else float(amount)*float(days)/float(period_days)
	var budget := 0
	for jump_id in volume.jump_attempts:
		var rate = volume.jump_attempts[jump_id]
		if not _integer(rate) or not _amount(rate): return _failure("训练尝试率必须是非负整数",remainders)
		var action := {"parts":[{"jump_id":jump_id,"rotations":rotations.get(jump_id,1)}]}
		var id := Repertoire.action_id(action)
		if id.is_empty(): return _failure("训练单跳目标无效",remainders)
		var count := _take(int(rate),int(days),int(period_days),"single:"+id,pending)
		volume.jump_attempts[jump_id] = count
		budget += count
	for specialist in volume.get("specialist_attempts",[]):
		if not specialist is Dictionary or not specialist.get("action") is Dictionary or not _integer(specialist.get("attempts")) or not _amount(specialist.attempts): return _failure("专项参考剂量无效",remainders)
		var id := Repertoire.action_id(specialist.action)
		if id.is_empty() or specialist.action.get("parts",[]).size() < 2: return _failure("专项连跳目标无效",remainders)
		var count := _take(int(specialist.attempts),int(days),int(period_days),"combo:"+id,pending)
		specialist.attempts = count
		budget += count*specialist.action.parts.size()
	volume.jump_attempt_budget = budget
	return {"errors":[],"volume":volume,"remainders":pending,"days":int(days),"period_days":int(period_days)}

static func _take(rate: int,days: int,period: int,key: String,pending: Dictionary) -> int:
	if days == 0: return 0
	var old: Dictionary = pending.get(key,{"n":0,"d":1})
	var d := int(old.d)
	var common := _gcd(d,period)
	var left := period/common
	var right := d/common
	var denominator := d*left
	var numerator := int(old.n)*left+rate*days*right
	var count := numerator/denominator
	var rest := numerator%denominator
	if rest == 0: pending.erase(key)
	else:
		var divisor := _gcd(rest,denominator)
		pending[key] = {"n":rest/divisor,"d":denominator/divisor}
	return count

static func _gcd(a: int,b: int) -> int:
	while b != 0:
		var rest := a%b
		a = b; b = rest
	return a

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value))

static func _amount(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0 and float(value) <= 1000000

static func _failure(message: String,remainders: Dictionary) -> Dictionary:
	return {"errors":[message],"volume":{},"remainders":remainders.duplicate(true)}
