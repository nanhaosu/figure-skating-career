extends RefCounted

const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const Points = preload("res://src/simulation/junior_grand_prix_service.gd")

static func enabled(career) -> bool:
	return career.season_state.get("selection_policy",{}).get("payload",{}).get("targets",{}).get("jgp",{}).get("second_start",{}).get("mode") == "after_first"

static func stages(calendar: Dictionary) -> Array:
	var events: Array = calendar.get("events",[]).filter(func(e):return e.get("event_family") == "jgp_stage" and e.get("status") != "cancelled" and not e.get("reference_only",false))
	events.sort_custom(func(a,b):return a.start_date < b.start_date)
	return events

static func allocate_round(rows: Array, places: int) -> Dictionary:
	var ranked: Array = rows.duplicate(true)
	ranked.sort_custom(func(a,b):
		if a.eligible != b.eligible: return a.eligible
		if int(a.points) != int(b.points): return int(a.points) > int(b.points)
		if float(a.score) != float(b.score): return float(a.score) > float(b.score)
		if float(a.get("free_score",0)) != float(b.get("free_score",0)): return float(a.get("free_score",0)) > float(b.get("free_score",0))
		return str(a.athlete_id) < str(b.athlete_id))
	var eligible: Array = ranked.filter(func(r):return r.eligible).map(func(r):return r.athlete_id)
	return {"candidate_rows":ranked,"selected_ids":eligible.slice(0,maxi(0,places)),"alternate_ids":eligible.slice(maxi(0,places))}

static func initialize(career, decision: Dictionary, calendar: Dictionary) -> void:
	if not enabled(career) or career.selection_state.has("jgp_second_start"): return
	var events := stages(calendar)
	if events.size() < 2: return
	var state := {"season_id":calendar.season_id,"policy":career.season_state.selection_policy.payload.targets.jgp.second_start.duplicate(true),"first_assignments":decision.assignments.duplicate(true),"reserved_event_ids":[],"pre_registered_ids":{},"official_entry_deadlines":{},"substitution_deadlines":{},"station_start_dates":{},"rounds":[]}
	var now := str(career.competition_timeline.get("date",""))
	state["reserved_capacities"] = {}
	state["entry_deadline_sources"] = {}
	var reserved_ids: Array = decision.audit.get("reserved_station_ids",events.slice(maxi(1,events.size()/2)).map(func(e):return e.event_id))
	for event in events.filter(func(e):return reserved_ids.has(e.event_id)):
		var id: String = event.event_id
		state.reserved_event_ids.append(id)
		state.reserved_capacities[id] = int(decision.audit.get("remaining_station_slots",{}).get(id,0))
		var deadline: String = str(event.get("application_deadline",event.start_date))
		state.official_entry_deadlines[id] = deadline
		state.entry_deadline_sources[id] = "game_setting" if event.get("application_deadline_game_policy",false) else str(event.get("application_deadline_source_kind","unverified"))
		state.station_start_dates[id] = event.start_date
		var stamp: int = int(Time.get_unix_time_from_datetime_string(event.start_date)) - int(state.policy.confirmation_days_before_start)*86400
		state.substitution_deadlines[id] = Time.get_date_string_from_unix_time(stamp)
		state.pre_registered_ids[id] = decision.audit.candidate_rows.filter(func(row):return row.eligible and not now.is_empty() and now <= deadline).map(func(row):return row.athlete_id)
	state["published_date"] = now
	state["policy_sha256"] = career.season_state.selection_policy.content_sha256
	career.selection_state.jgp_second_start = state

static func pending(career,event: Dictionary) -> bool:
	var state: Dictionary = career.selection_state.get("jgp_second_start",{})
	return state.get("reserved_event_ids",[]).has(event.get("event_id")) and not state.get("rounds",[]).any(func(r):return r.event_id == event.event_id)

static func substitution_deadline(career,event: Dictionary) -> String:
	var state: Dictionary = career.selection_state.get("jgp_second_start",{})
	if not state.get("pre_registered_ids",{}).get(event.get("event_id"),[]).has("player"): return ""
	if not state.get("rounds",[]).any(func(r):return r.event_id == event.event_id and r.selected_ids.has("player")): return ""
	return str(state.get("substitution_deadlines",{}).get(event.event_id,""))

static func preview(career, calendar: Dictionary) -> Dictionary:
	var state: Dictionary = career.selection_state.get("jgp_second_start",{})
	if state.is_empty() or state.get("season_id") != calendar.get("season_id"): return {}
	var now := str(career.competition_timeline.get("date",""))
	var initial: Dictionary = state.first_assignments.duplicate(true)
	var first_events: Array = []
	for ids in initial.values():
		for id in ids:
			if not first_events.has(id): first_events.append(id)
	for replacement in career.selection_state.get("jgp_replacements",[]):
		if first_events.has(replacement.get("event_id")) and not str(replacement.get("promoted_id","")).is_empty(): initial[replacement.promoted_id] = [replacement.event_id]
	# A reserve's first actual offer can itself come from an earlier round.
	# Wait for that performance before offering the same reserve a second start.
	for earlier in state.rounds:
		for row in earlier.candidate_rows:
			if earlier.selected_ids.has(row.athlete_id) and str(row.get("first_event_id","")).is_empty() and not initial.has(row.athlete_id):
				initial[row.athlete_id] = [earlier.event_id]
				if not first_events.has(earlier.event_id): first_events.append(earlier.event_id)
	var receipts := {}
	var observed_events: Array = []
	for raw in career.competition_archive:
		if not first_events.has(raw.get("event_id")) or raw.get("status") != "complete": continue
		var end := str(raw.get("event",{}).get("end_date",""))
		if end.is_empty() or end > now or not Codec.validate(raw).is_empty(): continue
		var archive := Codec.expand(raw)
		observed_events.append(raw.event_id)
		for row in archive.final_standings:
			if initial.get(row.athlete_id,[]).has(raw.event_id):
				receipts[row.athlete_id] = {"first_event_id":raw.event_id,"points":Points.placement_points(int(row.rank)),"score":float(row.total_score),"free_score":float(row.get("free_score",0)),"complete":archive.free_results.has(row.athlete_id)}
	if observed_events.is_empty(): return {}
	# Concrete station rights were published with the original allocation.
	# Do not move them when a content update adds more official world stages.
	var capacities: Dictionary = state.get("reserved_capacities",career.selection_state.get("decisions",{}).get("jgp",{}).get("decision",{}).get("audit",{}).get("remaining_station_slots",{}))
	for event in stages(calendar):
		if not pending(career,event): continue
		var id: String = event.event_id
		if now > str(state.substitution_deadlines[id]): continue
		# Finish every relevant scheduled first start before freezing this round.
		# Later first starts that cannot precede this station's cutoff are not
		# allowed to hold an earlier station open indefinitely.
		if stages(calendar).any(func(first_event):return first_events.has(first_event.event_id) and str(first_event.end_date) <= str(state.substitution_deadlines[id]) and str(first_event.end_date) > now): return {}
		var rows: Array = []
		for athlete_id in state.pre_registered_ids[id]:
			var first: Dictionary = receipts.get(athlete_id,{})
			# Do not judge an assigned first start before its result exists.
			if initial.has(athlete_id) and first.is_empty(): continue
			var active: bool = athlete_id == "player" or career.world_athletes.get(athlete_id,{}).get("status","missing") == "active"
			var starts: Array = career.selection_state.assignments.get(athlete_id,[]).filter(func(e):return str(e).begins_with("isu_jgp_") and str(e).ends_with("_"+str(calendar.calendar_year)) and not str(e).contains("final"))
			for prior_id in career.selection_state.get("jgp",{}).get("events",{}):
				if not starts.has(prior_id) and career.selection_state.jgp.events[prior_id].any(func(r):return r.athlete_id == athlete_id): starts.append(prior_id)
			var eligible: bool = active and starts.size() < 2 and (first.is_empty() or (first.complete and int(first.points) >= int(state.policy.minimum_first_points)))
			rows.append({"athlete_id":athlete_id,"name":career.athlete.display_name if athlete_id == "player" else str(career.world_athletes[athlete_id].get("name",athlete_id)),"score":first.get("score",0),"free_score":first.get("free_score",0),"points":first.get("points",0),"first_event_id":first.get("first_event_id",""),"eligible":eligible,"reason_codes":["eligible_second_start" if eligible and not first.is_empty() else "eligible_first_start_reserve" if eligible else "first_result_below_standard_or_unavailable"]})
		var round := allocate_round(rows,int(capacities.get(id,0)))
		round.merge({"event_id":id,"start_date":event.start_date,"cutoff":state.substitution_deadlines[id],"published_date":now,"source_kind":"game_setting","policy_sha256":state.policy_sha256,"assignments":{}})
		for athlete_id in round.selected_ids: round.assignments[athlete_id] = [id]
		return round
	return {}

static func commit(career, round: Dictionary) -> void:
	var state: Dictionary = career.selection_state.jgp_second_start
	if state.rounds.any(func(r):return r.event_id == round.event_id): return
	state.rounds.append(round.duplicate(true))
	for id in round.selected_ids:
		if not career.selection_state.assignments.has(id): career.selection_state.assignments[id] = []
		if not career.selection_state.assignments[id].has(round.event_id): career.selection_state.assignments[id].append(round.event_id)
	# Reuse the existing durable withdrawal machinery with the new frozen order.
	var audit: Dictionary = career.selection_state.decisions.jgp.decision.audit
	audit.station_alternates[round.event_id] = round.alternate_ids.duplicate()
	audit.station_starts[round.event_id] = str(round.start_date)
	career.event_ledger.append({"kind":"jgp_second_dispatch_published","season_id":state.season_id,"event_id":round.event_id,"date":round.published_date,"source_kind":"game_setting","selected_ids":round.selected_ids.duplicate()})

static func validate(state, season_state: Dictionary) -> String:
	if not state is Dictionary: return "JGP分阶段派遣必须为对象"
	for key in ["policy","first_assignments","pre_registered_ids","official_entry_deadlines","substitution_deadlines"]:
		if not state.get(key) is Dictionary: return "JGP分阶段派遣字段无效："+key
	if not state.get("reserved_event_ids") is Array or not state.get("rounds") is Array or state.rounds.size() > state.reserved_event_ids.size(): return "JGP派遣轮次无效"
	for id in state.first_assignments:
		if not id is String or not state.first_assignments[id] is Array or state.first_assignments[id].size() > 1: return "JGP首轮派遣记录无效"
	for key in ["reserved_capacities","entry_deadline_sources"]:
		if state.has(key) and not state[key] is Dictionary: return "JGP冻结名额或日期来源无效"
	var snapshot: Dictionary = season_state.get("selection_policy",{})
	if snapshot.get("payload",{}).get("season_id") != state.get("season_id"):
		snapshot = season_state.get("season_history",{}).get(state.get("season_id",""),{}).get("season",{}).get("selection_policy",{})
	if state.get("policy_sha256") != snapshot.get("content_sha256") or state.policy != snapshot.get("payload",{}).get("targets",{}).get("jgp",{}).get("second_start",{}): return "JGP分阶段标准与冻结公告不一致"
	for id in state.reserved_event_ids:
		if not id is String or state.reserved_event_ids.count(id) != 1 or not state.pre_registered_ids.get(id) is Array: return "JGP预报名姓名名单无效"
		for athlete in state.pre_registered_ids[id]:
			if not athlete is String or state.pre_registered_ids[id].count(athlete) != 1: return "JGP预报名姓名无效或重复"
		for key in ["official_entry_deadlines","substitution_deadlines"]:
			if not preload("res://src/simulation/international_personal_eligibility.gd")._valid_date(str(state[key].get(id,""))): return "JGP派遣日期无效"
		if state.has("reserved_capacities") and not preload("res://src/content/annual_selection_policy_repository.gd").integer(state.reserved_capacities.get(id),0,3): return "JGP冻结分站容量无效"
	var seen: Array = []
	for round in state.rounds:
		if not round is Dictionary or not state.reserved_event_ids.has(round.get("event_id")) or seen.has(round.get("event_id")): return "JGP派遣轮次重复或未知"
		seen.append(round.event_id)
		if not round.get("candidate_rows") is Array or not round.get("selected_ids") is Array or not round.get("alternate_ids") is Array or not round.get("assignments") is Dictionary: return "JGP派遣轮次记录无效"
		if round.get("policy_sha256") != state.policy_sha256 or round.get("cutoff") != state.substitution_deadlines[round.event_id]: return "JGP派遣标准或截止日改变"
		for athlete in round.selected_ids + round.alternate_ids:
			if not state.pre_registered_ids[round.event_id].has(athlete) or (round.selected_ids + round.alternate_ids).count(athlete) != 1: return "JGP改派超出预报名名单或重复"
	return ""
