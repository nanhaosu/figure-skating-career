class_name AthleteFunctionService
extends RefCounted

const Repertoire = preload("res://src/domain/technical_repertoire.gd")

# These are gameplay capabilities, not diagnoses. Fatigue is reported separately
# so a bad day cannot overwrite durable physical or learned technical capacity.
static func snapshot(career) -> Dictionary:
	var body: Dictionary = career.athlete.body
	var foundation: Dictionary = career.athlete.jump_foundation.to_dict()
	var limits: Dictionary = career.condition_state.get("function_limits",{}).duplicate(true)
	for injury in career.condition_state.get("injuries",[]):
		for key in injury.get("residual_function_limits",{}):
			_merge_limit(limits,str(key),injury.residual_function_limits[key])
		if injury.get("status") != "active": continue
		var injury_limits = injury.get("function_limits",{})
		if injury_limits is Dictionary and not injury_limits.is_empty():
			for key in injury_limits:
				_merge_limit(limits,str(key),injury_limits[key])
		else:
			# v15 ankle injuries remain restricted until reassessed, but recovered
			# records never keep punishing an athlete for having a long career.
			var severity := clampf(float(injury.get("severity",0.0)),0.0,1.0)
			_merge_limit(limits,"landing",{"blocked":severity >= 0.7,"factor":1.0-severity*0.5,"source_id":str(injury.get("id","legacy")),"review_condition":"复评落冰承受能力与当前伤情"})
	var result := {
		"takeoff":float(body.strength_readiness)*0.6+float(foundation.takeoff_power)*0.4,
		"coordination":(float(foundation.air_axis)+float(foundation.rotation_completion)+float(foundation.spatial_awareness))/3.0,
		"landing":float(body.joint_readiness)*0.5+float(foundation.landing_control)*0.5,
		"recovery":float(body.recovery_capacity),
		"acute_fatigue":float(body.acute_fatigue),"cumulative_load":float(body.cumulative_fatigue),"limits":limits,
	}
	for field in ["takeoff","coordination","landing","recovery"]:
		result[field] = clampf(float(result[field])*float(limits.get(field,{}).get("factor",1.0)),0.0,100.0)
	return result

static func action_constraints(career, action: Dictionary, context: Dictionary = {}) -> Dictionary:
	var physical := snapshot(career)
	var result := {"allowed":true,"reasons":[],"function_factors":{},"review_conditions":[]}
	var demands: Array = []
	var rotations := 0
	match str(action.get("kind","")):
		"jump":
			if Repertoire.action_id(action).is_empty():
				result.allowed = false
				result.reasons.append("跳跃动作无效")
				return result
			demands = ["takeoff","coordination","landing"]
			for part in action.parts: rotations = maxi(rotations,int(part.rotations))
		"spin":
			demands = ["coordination"]
			if bool(action.get("flying",false)) or str(action.get("spin_code","")).begins_with("F"):
				demands.append_array(["takeoff","landing"])
		"step_sequence", "choreographic_sequence": demands = ["coordination"]
		"conditioning", "rest": demands = []
		_:
			result.allowed = false
			result.reasons.append("未知动作类型")
			return result
	for function in demands:
		var limit: Dictionary = physical.limits.get(function,{})
		result.function_factors[function] = float(limit.get("factor",1.0))
		var restricted := bool(limit.get("blocked",false))
		if action.kind == "jump" and limit.has("maximum_rotations"):
			restricted = restricted or rotations > int(limit.maximum_rotations)
		if restricted:
			result.allowed = false
			result.reasons.append("当前身体限制：%s" % function)
			result.review_conditions.append(str(limit.get("review_condition","需要团队复评相关身体功能")))
	return result

static func _merge_limit(limits: Dictionary, key: String, incoming: Dictionary) -> void:
	var existing: Dictionary = limits.get(key,{})
	var merged := incoming.duplicate(true)
	merged.factor = minf(float(existing.get("factor",1.0)),float(incoming.get("factor",1.0)))
	merged.blocked = bool(existing.get("blocked",false)) or bool(incoming.get("blocked",false))
	if existing.has("maximum_rotations"):
		merged.maximum_rotations = mini(int(existing.maximum_rotations),int(incoming.get("maximum_rotations",4)))
	if not existing.get("review_condition","").is_empty(): merged.review_condition = existing.review_condition
	limits[key] = merged

# Execution penalty is applied once to the action that needs the function.
# Low rotations remain easier to accommodate; ordinary steps do not use landing.
static func execution_factor(limits: Dictionary, action: Dictionary) -> float:
	var demands: Array = ["coordination"]
	var rotation := 1
	if action.get("kind") == "jump":
		demands = ["takeoff","coordination","landing"]
		for part in action.get("parts",[]): rotation = maxi(rotation,int(part.rotations))
	var factor := 1.0
	for function in demands: factor = minf(factor,float(limits.get(function,{}).get("factor",1.0)))
	return clampf(1.0-(1.0-factor)*(0.45+float(rotation)*0.15),0.1,1.0)
