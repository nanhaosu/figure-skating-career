class_name OpponentDecisionService
extends RefCounted

# Bounded game-design allocation model, not a physiological training model.
# Four equal shares reproduce the old approximate maintenance rate.
static func plan(record: Dictionary, ordinal: int) -> Dictionary:
	var personality: Dictionary = record.get("personality", {})
	var body: Dictionary = record.get("athlete", {}).get("body", {})
	var focus := "balanced"
	var risk := "balanced"
	var reasons := ["maintenance"]
	var allocation := {"technique":0.25,"skating":0.25,"jumps":0.25,"programme":0.25}
	var fatigue := maxf(float(body.get("acute_fatigue",0.0)),float(body.get("cumulative_fatigue",0.0)))
	var ambition := float(personality.get("ambition",50.0))
	var discipline := float(personality.get("discipline",50.0))
	if fatigue >= 65.0:
		focus = "recovery"
		risk = "conservative"
		reasons = ["high_fatigue"]
		allocation = {"technique":0.25,"skating":0.30,"jumps":0.10,"programme":0.35}
	elif ambition >= 65.0 and ambition > discipline:
		focus = "jump"
		risk = "aggressive"
		reasons = ["ambition"]
		allocation = {"technique":0.20,"skating":0.15,"jumps":0.45,"programme":0.20}
	elif discipline >= 65.0:
		focus = "stability"
		risk = "conservative"
		reasons = ["discipline"]
		allocation = {"technique":0.30,"skating":0.30,"jumps":0.15,"programme":0.25}
	return {"model_version":1,"ordinal":ordinal,"focus":focus,"allocation":allocation,"risk":risk,"reasons":reasons}

static func frozen_risk(record: Dictionary) -> String:
	var decision = record.get("opponent_decision",{})
	if not decision is Dictionary: return "balanced"
	var risk := str(decision.get("risk","balanced"))
	return risk if risk in ["conservative","balanced","aggressive"] else "balanced"

static func validate(value) -> String:
	if not value is Dictionary: return "必须是对象"
	for key in ["model_version","ordinal"]:
		if not (value.get(key) is int or value.get(key) is float): return key + " 无效"
		if not is_finite(float(value[key])) or float(value[key]) != floorf(float(value[key])): return key + " 无效"
	if int(value.model_version) != 1 or int(value.ordinal) < 4 or int(value.ordinal) > 39999: return "版本或时钟无效"
	if not value.get("focus") in ["balanced","jump","stability","recovery"]: return "focus 无效"
	if not value.get("risk") in ["conservative","balanced","aggressive"]: return "risk 无效"
	if not value.get("allocation") is Dictionary or value.allocation.size() != 4: return "allocation 无效"
	var total := 0.0
	for key in ["technique","skating","jumps","programme"]:
		var share = value.allocation.get(key)
		if not (share is int or share is float): return "allocation 无效"
		if not is_finite(float(share)) or float(share) < 0.0 or float(share) > 1.0: return "allocation 无效"
		total += float(share)
	if not is_equal_approx(total,1.0): return "allocation 未归一化"
	if not value.get("reasons") is Array or value.reasons.is_empty() or value.reasons.size() > 4: return "reasons 无效"
	for reason in value.reasons:
		if not reason in ["maintenance","high_fatigue","ambition","discipline"]: return "reasons 无效"
	return ""
