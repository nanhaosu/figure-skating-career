class_name DevelopmentRoadmapEvaluator
extends RefCounted

const JumpStageEvaluator = preload("res://src/simulation/jump_stage_evaluator.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")

const STABLE_STAGES := ["training_stable", "internal_ready", "official_ready", "core"]

static func evaluate(career, roadmap) -> Dictionary:
	if career == null or career.athlete == null or roadmap == null:
		return {"feasibility": "not_recommended", "status": "reassess", "milestone_forecasts": [], "near_term_focus": [], "risk_codes": ["missing_state"], "visible_reasons": ["缺少可评估的成长路线"], "recommended_changes": []}
	var age: int = career.clock.age_on(career.athlete.birth_year)
	var risks: Array[String] = []
	var visible: Array[String] = []
	var recommendations: Array[String] = []
	var forecasts: Array[Dictionary] = []
	var worst_burden := 0.0
	for milestone in roadmap.milestones:
		var stable_count := _stable_count(career, int(milestone.rotations))
		var missing := maxi(0, int(milestone.count) - stable_count)
		var years_left := maxi(0, int(milestone.age) - age)
		var unit_cost := 14.0 if int(milestone.rotations) == 3 else 6.0
		var burden := missing * unit_cost - years_left * (4.0 if int(milestone.rotations) == 3 else 3.0)
		worst_burden = maxf(worst_burden, burden)
		var delay := maxi(0, int(ceil(maxf(0.0, burden) / 20.0)))
		forecasts.append({"age": int(milestone.age), "rotations": int(milestone.rotations), "count": int(milestone.count), "current_count": stable_count, "earliest_age": maxi(age, int(milestone.age) - 1), "likely_age": maxi(age, int(milestone.age) + delay), "late_age": maxi(age + 1, int(milestone.age) + delay + 1)})
	var body: Dictionary = career.athlete.body
	var physical := (float(body.strength_readiness) + float(body.joint_readiness)) / 2.0
	if physical < 40.0: worst_burden += 10.0
	if float(body.impact_load) >= 65.0 or float(body.ankle_load) >= 65.0 or float(body.cumulative_fatigue) >= 60.0:
		risks.append("high_body_load"); visible.append("当前身体负荷要求重新评估路线"); recommendations.append("先降低冲击并观察恢复")
	if float(body.growth_trend) >= 70.0:
		risks.append("growth_acceleration"); visible.append("近期发育速度可能改变动作节奏")
	var latent_risk := false
	for jump_id in career.athlete.jumps:
		var profile = career.athlete.jumps[jump_id]
		if float(profile.habits.rigidity) >= 55.0: latent_risk = true
		for observation in profile.observations:
			var label := str(observation.get("label", ""))
			if not label.is_empty() and not visible.has(label): visible.append(label)
	if latent_risk:
		risks.append("latent_technique_risk"); visible.append("技术稳定性存在风险"); worst_burden += 8.0
	var resource_level := (float(career.athlete.resources.money) + float(career.athlete.resources.ice_access)) / 2.0
	if resource_level < 25.0:
		risks.append("limited_resources"); visible.append("冰时或训练资金限制了计划速度"); worst_burden += 10.0
	worst_burden += {"cautious": 5.0, "normal": 0.0, "aggressive": -5.0}.get(roadmap.risk_attitude, 0.0)
	var feasibility := "conservative" if worst_burden <= 5.0 else ("feasible" if worst_burden <= 30.0 else ("aggressive" if worst_burden <= 60.0 else "not_recommended"))
	var status := _status(age, roadmap.milestones, forecasts)
	if risks.has("high_body_load") or risks.has("growth_acceleration"): status = "reassess"
	if feasibility == "not_recommended": recommendations.append("降低近期动作数量或推迟年龄节点")
	return {"feasibility": feasibility, "status": status, "milestone_forecasts": forecasts, "near_term_focus": _near_term_focus(career,roadmap,forecasts), "risk_codes": risks, "visible_reasons": visible, "recommended_changes": recommendations}

static func _stable_count(career, rotations: int) -> int:
	var count := 0
	for jump_id in TrainingPlan.JUMP_LABELS:
		# Five-triple breadth means T/S/Lo/F/Lz; 3A is a separate difficulty.
		if rotations == 3 and jump_id == "axel": continue
		if _meets_milestone(career,jump_id,rotations): count += 1
	return count

static func _meets_milestone(career, jump_id: String, rotations: int) -> bool:
	var stage: String = JumpStageEvaluator.evaluate(career,jump_id,rotations).stage_id
	return stage in ["official_ready","core"] if rotations == 3 else stage in STABLE_STAGES

static func _status(age: int, milestones: Array[Dictionary], forecasts: Array[Dictionary]) -> String:
	for index in milestones.size():
		var milestone := milestones[index]
		var forecast := forecasts[index]
		if int(forecast.current_count) >= int(milestone.count):
			if age < int(milestone.age): return "ahead"
			continue
		if age > int(milestone.age): return "far_behind"
		if age == int(milestone.age): return "slightly_behind"
		return "on_track"
	return "on_track"

static func _near_term_focus(career, roadmap, forecasts: Array[Dictionary]) -> Array[String]:
	var result: Array[String] = []
	for jump_id in roadmap.priority_jumps:
		if jump_id != roadmap.deferred_jump: result.append(jump_id)
	if not result.is_empty(): return result
	var rotations := int(roadmap.milestones[-1].rotations)
	for forecast in forecasts:
		if int(forecast.current_count) < int(forecast.count):
			rotations = int(forecast.rotations)
			break
	var candidates: Array[String] = []
	for id in TrainingPlan.JUMP_LABELS:
		if id == roadmap.deferred_jump or (rotations == 3 and id == "axel"): continue
		if not _meets_milestone(career,id,rotations): candidates.append(id)
	var key: String = {2:"double",3:"triple"}.get(rotations,"single")
	candidates.sort_custom(func(a,b):
		var left := float(career.athlete.jumps[a].proficiency[key])
		var right := float(career.athlete.jumps[b].proficiency[key])
		if not is_equal_approx(left,right): return left < right
		return Array(TrainingPlan.JUMP_LABELS.keys()).find(a) < Array(TrainingPlan.JUMP_LABELS.keys()).find(b))
	for id in candidates.slice(0,2): result.append(id)
	return result
