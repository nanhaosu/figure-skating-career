class_name OffseasonEventService
extends RefCounted

# Small narrative choices use the existing durable command boundary and ledger.
# No new random draws, training shares, money or skill rewards are introduced.
static func pending(career) -> Dictionary:
	if career.clock.quarter != 3 or career.season_state.get("season_history",{}).is_empty(): return {}
	if not career.competition_state.is_empty() or not career.condition_state.get("pending_decision",{}).is_empty(): return {}
	var weeks := int(career.training_period_state.get("weeks_elapsed",0))
	for slot in 3:
		var recent := _receipt(career,"offseason:%d:%d" % [career.clock.year,slot])
		if not recent.is_empty() and weeks < int(recent.get("elapsed_weeks",slot*3))+3: return {}
	for slot in 3:
		if weeks < slot*3: continue
		var id := "offseason:%d:%d" % [career.clock.year,slot]
		if _receipt(career,id).is_empty(): return _event(career,slot,id)
	return {}

static func resolve(career, event_id: String, choice_id: String) -> Dictionary:
	var previous := _receipt(career,event_id)
	if not previous.is_empty():
		return {"ok":previous.choice_id == choice_id,"events":[],"error":"这段经历已经作出不同选择" if previous.choice_id != choice_id else ""}
	var event := pending(career)
	if event.is_empty() or event.id != event_id: return {"ok":false,"error":"这段休赛期经历尚未到来或已过期"}
	var selected: Array = event.choices.filter(func(row): return row.id == choice_id)
	if selected.size() != 1: return {"ok":false,"error":"无效的休赛期选择"}
	# JSON restores arbitrary ledger numbers as floats; keep the same in-memory
	# representation so replay comparisons do not drift after a disk roundtrip.
	var record := {"kind":"offseason_choice","id":event_id,"choice_id":choice_id,"title":event.title,"response":selected[0].response,"clock":career.clock.to_dict(),"elapsed_weeks":float(career.training_period_state.get("weeks_elapsed",0))}
	career.event_ledger.append(record)
	if event_id.ends_with(":2"):
		var season_id: String = career.clock.season_id()
		career.experience_state.personal_expectations[season_id] = {"choice_id":choice_id,"text":str(selected[0].response),"source_id":event_id}
		var seasons: Array = career.experience_state.personal_expectations.keys()
		seasons.sort()
		while seasons.size() > 2: career.experience_state.personal_expectations.erase(seasons.pop_front())
	else:
		career.experience_state.relationship_memories.append({"memory_id":event_id,"person_id":"coach" if event_id.ends_with(":0") else "friends","event_id":event_id,"choice_id":choice_id,"summary":str(selected[0].response),"clock":career.clock.to_dict()})
		while career.experience_state.relationship_memories.size() > 64: career.experience_state.relationship_memories.pop_front()
	return {"ok":true,"events":[record]}

static func _receipt(career, id: String) -> Dictionary:
	for record in career.event_ledger:
		if record.get("kind") == "offseason_choice" and record.get("id") == id: return record
	return {}

static func _event(career, slot: int, id: String) -> Dictionary:
	var context := _context(career)
	var choices: Array = []
	var title := "下一首音乐，想讲谁的故事？"
	var text := "选曲讨论时，教练把两段音乐放在一起：一段更贴合你熟悉的比赛风格，另一段让你想起自己的生活。你希望从哪里开始试滑？"
	if slot == 0:
		choices = [{"id":"personal","label":"先试我真正喜欢的那一段","response":"你把喜欢的音乐留在了选曲讨论里。最终选曲仍由你在节目规划中确认。"},{"id":"coach","label":"先听听教练为什么推荐另一段","response":"你和教练先讨论了音乐与滑行的匹配，没有因此放弃自己的偏好。"}]
		text = str(context.get("opening",""))+text
	elif slot == 1:
		title = "不在冰场的一个下午"
		text = "朋友约你出去走走。你也想把一段训练视频剪好，给自己留个记录。这次不用证明谁更努力，只是想怎样记住这个夏天？"
		choices = [{"id":"friends","label":"和朋友出去，聊点花滑之外的事","response":"这个夏天有一个下午，你谈论的不只有比赛。"},{"id":"journal","label":"整理训练片段，留下自己的成长记录","response":"你把训练中的笨拙和进步都留在了记录里。"}]
	else:
		title = "下一季，想让人记住什么？"
		text = "教练问你，下季除了名次，还有什么值得期待？"
		var archive := _last_player_archive(career)
		if not archive.is_empty(): text = "聊起上季的《%s》，教练问你：下次站上冰面，除了名次，还有什么值得期待？" % str(archive.get("event_name","比赛"))
		var focus_labels: Array[String] = []
		for focus in career.training_direction.get("focuses",[]): focus_labels.append(preload("res://src/presentation/training_focus_presenter.gd").label(focus))
		if not focus_labels.is_empty(): text += "你们也谈到了当前重点：%s。" % "、".join(focus_labels)
		choices = [{"id":"challenge","label":"想完成一直惦记的那个动作","response":"你希望用一次真正的突破记住下季。具体训练方向仍由训练重点页面决定。"},{"id":"expression","label":"想滑出一套真正属于我的节目","response":"你想让节目留下自己的表达。这个愿望不会直接兑换成内容分。"},{"id":"steady","label":"想比上季更从容，完整地滑完","response":"你把更从容地站上冰面，当作值得认真对待的期待。"}]
	var last := _receipt(career,"offseason:%d:2" % (career.clock.year-1))
	if slot == 2 and not last.is_empty(): text += "去年你说过：%s。现在可以坚持，也可以改变。" % str(last.get("response",""))
	return {"kind":"offseason_event","id":id,"title":title,"reason":text,"choices":choices,"context":context.id,"impact":"这是个人表达，不增加能力或费用，也不修改节目与训练安排。"}

static func _last_player_archive(career) -> Dictionary:
	var previous_season := "%d-%02d" % [career.clock.year-1,career.clock.year%100]
	for index in range(career.competition_archive.size()-1,-1,-1):
		var archive: Dictionary = career.competition_archive[index]
		if archive.get("season_id") != previous_season or bool(archive.get("world_only",false)): continue
		if archive.get("final_standings",[]).any(func(row): return row.get("athlete_id") == "player"): return archive
	return {}

static func _context(career) -> Dictionary:
	var previous_season := "%d-%02d" % [career.clock.year-1,career.clock.year%100]
	var international: Array = []
	for archive in career.competition_archive:
		if bool(archive.get("world_only",false)) or archive.get("event",{}).get("scope") != "international": continue
		if archive.get("final_standings",[]).any(func(row): return row.get("athlete_id") == "player"): international.append(archive)
	if not international.is_empty() and international.all(func(row): return row.get("season_id") == previous_season):
		return {"id":"first_international","opening":"第一次国际赛的经历还留在你们的话题里。《%s》之后，教练没有只问名次，也想听你想滑什么。" % str(international[0].get("event_name",international[0].get("event",{}).get("name","国际赛")))}
	var selections: Dictionary = career.selection_state.get("season_history",{}).get(previous_season,{})
	for decision in selections.get("decisions",{}).values():
		var participated: bool = decision.get("inputs",[]).any(func(row): return row.get("athlete_id") == "player")
		if participated and decision.get("decision",{}).get("assignments",{}).get("player",[]).is_empty():
			return {"id":"not_assigned","opening":"上季争取过的国际名额没有轮到你。教练把那份结果放在一旁：没被派出去的日子，训练也没有白过。"}
	for item in career.technical_repertoire.entries.values():
		for kind in ["program","program_late"]:
			var clock: Dictionary = item.get("learned_history",{}).get("first_success_contexts",{}).get(kind,{}).get("clock",{})
			if int(clock.get("year",0))-(1 if int(clock.get("quarter",3)) < 3 else 0) == career.clock.year-1:
				return {"id":"programme_matured","opening":"上季已有动作从单独练习走进整套节目。教练翻到那段记录：接下来也可以想想，这套节目想留下怎样的感觉。"}
	return {"id":"ordinary_season","opening":"一个赛季结束了，训练和比赛之外，你也有自己的偏好。"}
