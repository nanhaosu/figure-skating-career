class_name ClubDecisionSimulator
extends RefCounted

static func decide(public_result: Dictionary, club_context: Dictionary, _career) -> Dictionary:
	var rank := maxi(1, int(public_result.get("public_rank", 99)))
	var public_score := float(public_result.get("total", 0.0))
	var priority := clampf(float(club_context.get("priority", 0.0)), 0.0, 100.0)
	var coach_favor := clampf(float(club_context.get("coach_favor", 0.0)), 0.0, 100.0)
	var result_weight := maxf(8.0, 58.0 - float(rank) * 8.0) + clampf((public_score - 35.0) * 0.15, -2.0, 4.0)
	var decision_score := snappedf(result_weight + priority * 0.25 + coach_favor * 0.15, 0.01)
	var ice_change := 4.0 if decision_score >= 70.0 else (2.0 if decision_score >= 50.0 else 0.0)
	if rank == 1: ice_change = maxf(1.0, ice_change)
	var attention_change := 5.0 if decision_score >= 70.0 else (2.0 if decision_score >= 50.0 else -1.0)
	var reasons: Array[String] = ["public_result"]
	if priority >= 50.0: reasons.append("priority_treatment")
	if coach_favor >= 60.0: reasons.append("coach_preference")
	if rank == 1 and decision_score < 60.0: reasons.append("winner_not_primary_project")
	return {
		"public_rank": rank,
		"decision_score": decision_score,
		"resource_changes": {"ice_access": ice_change, "coach_attention": attention_change, "choreography_support": 1.0 if decision_score >= 65.0 else 0.0},
		"external_slot_recommended": decision_score >= 60.0 and int(club_context.get("available_external_slots", 0)) > 0,
		"review_requirement": "下次内部考核需证明稳定性" if rank >= 3 else "",
		"observable_reasons": reasons,
		"hidden_weights": {"result": snappedf(result_weight, 0.01), "priority": priority * 0.25, "coach_favor": coach_favor * 0.15},
	}
