class_name ConflictScanner
extends RefCounted

static func scan(career, proposal) -> Array[Dictionary]:
	var conflicts: Array[Dictionary] = []
	var actual = proposal.executed
	if actual.requires_load_review():
		conflicts.append({"signature": "jump_load_conflict", "urgency": 60.0, "trigger_codes": ["jump_load_conflict"], "cause_ids": []})
	var overload_memory_id := ""
	for memory in career.memories:
		if memory.get("signature") == "jump_load_conflict":
			overload_memory_id = str(memory.get("id", ""))
	if float(career.athlete.body.impact_load) >= 15.0 or float(career.athlete.body.ankle_load) >= 20.0:
		var pain_causes: Array[String] = []
		if not overload_memory_id.is_empty(): pain_causes.append(overload_memory_id)
		conflicts.append({"signature": "delayed_pain", "urgency": 90.0, "trigger_codes": ["delayed_body_signal"], "cause_ids": pain_causes})
	if float(career.athlete.body.acute_fatigue) >= 18.0 or float(career.athlete.body.cumulative_fatigue) >= 12.0:
		conflicts.append({"signature": "fatigue_breakdown", "urgency": 75.0, "trigger_codes": ["fatigue_accumulation"], "cause_ids": []})
	conflicts.sort_custom(func(a, b): return a.urgency > b.urgency)
	return conflicts
