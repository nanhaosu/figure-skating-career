class_name CareerMilestoneService
extends RefCounted

static func preview(experience_state: Dictionary, archive: Dictionary) -> Dictionary:
	var state := experience_state.duplicate(true)
	var facts := inspect_archive(archive)
	var new_ids: Array = []
	var candidates := {"first_jgp_start":facts.jgp_start,"first_jgp_complete":facts.jgp_complete,"first_formal_3a":facts.axel_completed[0] if not facts.axel_completed.is_empty() else {}}
	var certainty := "confirmed_first" if str(state.get("milestone_history",{}).get("status","partial")) in ["native","complete"] else "observed"
	for key in candidates:
		if state.get("milestones",{}).has(key) or candidates[key].is_empty(): continue
		state.milestones[key] = record_for(candidates[key],"live",certainty)
		new_ids.append(key)
	return {"next_state":state,"new_ids":new_ids,"errors":[]}

static func record_for(fact: Dictionary, origin: String, certainty: String) -> Dictionary:
	var date := str(fact.get("event_date",""))
	var year := int(date.get_slice("-",0))
	var quarter := clampi((int(date.get_slice("-",1))-1)/3+1,1,4)
	var result: Dictionary = fact.get("result",{})
	return {"id":"%s:%s:%s:%d" % [fact.get("event_id",""),fact.get("segment",""),fact.get("element_id",""),fact.get("part_index",0)],"event_id":str(fact.get("event_id","")),"event_date":date,"event_name":str(fact.get("event_name","正式比赛")),"clock":{"year":year,"quarter":quarter},"segment":str(fact.get("segment","")),"element_id":str(fact.get("element_id","")),"part_index":int(fact.get("part_index",0)),"result":{"rank":int(result.get("final_rank",result.get("short_rank",0))),"total":float(result.get("total_score",0))},"origin":origin,"certainty":certainty,"evidence_refs":Array(fact.get("evidence_refs",[])).duplicate()}

# These are personal, evidence-backed experiences, not world-record claims.
static func inspect_archive(archive: Dictionary) -> Dictionary:
	var result := {"jgp_start":{},"jgp_complete":{},"axel_attempts":[],"axel_completed":[],"errors":[]}
	if bool(archive.get("world_only",false)) or int(archive.get("record_version",0)) != 1: return result
	var event: Dictionary = archive.get("event",{})
	var event_id := str(archive.get("event_id",event.get("event_id","")))
	if event_id.is_empty(): return result
	var date := str(event.get("start_date",event.get("actual_dates",{}).get("start","")))
	var base := {"event_id":event_id,"event_date":date,"event_name":str(event.get("name",archive.get("event_name","正式比赛"))),"season_id":str(archive.get("season_id","")),"result":Dictionary(archive.get("player_result",{})).duplicate(true),"evidence_refs":["competition:"+event_id]}
	var played := []
	for segment in ["short","free"]:
		var record: Dictionary = archive.get(segment+"_results",{}).get("player",{})
		var elements: Array = record.get("performance",{}).get("elements",[])
		if elements.is_empty(): continue
		var actually_skated := false
		for performed in elements:
			actually_skated = actually_skated or not performed.get("actual",{}).is_empty() or not performed.get("facts",{}).is_empty()
			for part in performed.get("parts",[]): actually_skated = actually_skated or not part.get("actual",{}).is_empty() or not part.get("facts",{}).is_empty()
		if not actually_skated: continue
		played.append(segment)
		var calls := {}
		for call in record.get("technical_review",{}).get("final_elements",[]):
			calls[str(call.get("element_id",""))] = call
		var pending := {}
		for review in record.get("technical_review",{}).get("review_events",[]):
			if str(review.get("status","")) != "resolved": pending[str(review.get("element_id",""))] = true
		for index in elements.size():
			var actual_element: Dictionary = elements[index]
			var id := str(actual_element.get("element_id",""))
			if id.is_empty(): continue
			var final: Dictionary = calls.get(id,{})
			var actual_parts: Array = actual_element.get("parts",[])
			var combined := not actual_parts.is_empty()
			if not combined: actual_parts = [actual_element]
			for part_index in actual_parts.size():
				var actual: Dictionary = actual_parts[part_index]
				var final_part: Dictionary = {}
				if combined:
					var final_parts: Array = final.get("parts",[])
					if part_index < final_parts.size(): final_part = final_parts[part_index]
				else: final_part = final
				var planned := str(actual.get("planned_abbreviation",actual.get("abbreviation","")))
				if actual.get("jump_id") == "axel" and int(actual.get("facts",{}).get("planned_rotations",0)) == 3: planned = "3A"
				var outer_plan := str(actual_element.get("planned_abbreviation","")).split("+")
				if part_index < outer_plan.size() and outer_plan[part_index] == "3A": planned = "3A"
				var code := str(final_part.get("abbreviation",""))
				if planned != "3A" and code != "3A": continue
				var fact := base.duplicate(true)
				fact.segment = segment; fact.element_id = id; fact.part_index = part_index; fact.element_index = index
				fact.evidence_refs = ["competition:%s:%s:%s:%d" % [event_id,segment,id,part_index]]
				fact.actual_code = code; fact.confirmed = false
				fact.executed_code = str(actual.get("abbreviation",""))
				var execution: Dictionary = actual.get("actual",{})
				var invalid := not str(final.get("invalid_reason","")).is_empty() or not str(final_part.get("invalid_reason","")).is_empty()
				var info: Array = final_part.get("info",final.get("info",[]))
				for symbol in ["q","<","<<","*","REP","+REP"]:
					invalid = invalid or info.has(symbol) or code.contains(symbol)
				# Performance status is the landing/broadcast color. Recognition uses
				# final technical calls and explicit unresolved review events instead.
				fact.confirmed = str(archive.get("status","")) == "complete" and code == "3A" and not final_part.is_empty() and float(final_part.get("base_value",0)) > 0 and execution.get("success") == true and execution.get("fall") == false and not invalid and not pending.has(id)
				fact.failure_reason = ""
				if not fact.confirmed:
					if pending.has(id): fact.failure_reason = "技术认定尚未完成"
					elif execution.get("fall") == true: fact.failure_reason = "落冰摔倒"
					elif invalid: fact.failure_reason = "周数或动作有效性未满足足周完成口径"
					elif code != "3A" and not code.is_empty(): fact.failure_reason = "没有按计划完成三周半"
					else: fact.failure_reason = "现有执行与最终认定证据不足以确认"
				result.axel_attempts.append(fact)
				if fact.confirmed: result.axel_completed.append(fact.duplicate(true))
	if event.get("event_family") == "jgp_stage" and not played.is_empty():
		result.jgp_start = base.duplicate(true)
		if str(archive.get("status","")) == "complete" and played.has("short") and played.has("free"):
			result.jgp_complete = base.duplicate(true)
	return result
