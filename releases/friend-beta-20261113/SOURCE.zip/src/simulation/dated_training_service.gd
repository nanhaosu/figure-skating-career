class_name DatedTrainingService
extends RefCounted

const Timeline = preload("res://src/domain/competition_timeline.gd")
const Dates = preload("res://src/simulation/dated_training_window.gd")
const Dose = preload("res://src/simulation/dated_training_dose.gd")
const Volume = preload("res://src/simulation/effective_training_calculator.gd")
const Jump = preload("res://src/simulation/dated_jump_practice.gd")
const Nonjump = preload("res://src/simulation/dated_non_jump_training.gd")
const BodyLoad = preload("res://src/simulation/dated_body_load.gd")
const Condition = preload("res://src/simulation/athlete_condition_service.gd")
const Rehab = preload("res://src/simulation/rehabilitation_service.gd")
const External = preload("res://src/simulation/external_training_service.gd")
const CoachMemory = preload("res://src/simulation/coach_training_memory_service.gd")

# These operations mutate a command's private working copy. CareerCommand
# owns rollback; the UI must persist that copy before adopting it.
static func can_auto_activate(career) -> bool:
	if career == null or career.competition_timeline.mode == "dated" or career.clock.year < 2018: return false
	if int(career.training_period_state.get("weeks_elapsed",0)) != 0 or career.training_period_state.has("stage_checkpoint"): return false
	# An old, partly paid course has no exact daily cursor. Let its existing
	# quarterly executor finish it; never rewind it into a fresh dated dose.
	for booking in career.training_direction.external_schedule:
		if booking.get("status") == "booked" and (int(booking.get("executed_stages",0)) > 0 or booking.has("executed_days")): return false
	# A historical race may cross the quarter boundary or lack a provable
	# canonical date. In that case retain its old executor until a safe later
	# boundary, rather than repeatedly forcing an activation that cannot commit.
	return bool(activate(career.transaction_copy()).ok)

static func has_exact_event_dates(event: Dictionary) -> bool:
	var start := str(event.get("actual_dates",{}).get("start",event.get("start_date","")))
	var end := str(event.get("actual_dates",{}).get("end",event.get("end_date",start)))
	return Dates.plan(start,end).errors.is_empty()

static func activate(career) -> Dictionary:
	if career.competition_timeline.mode == "dated": return {"ok":true,"events":[]}
	if int(career.training_period_state.get("weeks_elapsed",0)) != 0 or career.training_period_state.has("stage_checkpoint"): return _failure("请先完成旧季度训练检查点，再从下一季度启用日期推进")
	if not career.competition_state.is_empty() and career.competition_state.get("status") != "complete": return _failure("请先完成或退出当前比赛")
	var first := "%04d-%02d-01" % [career.clock.year,(career.clock.quarter-1)*3+1]
	var next := "%04d-%02d-01" % [career.clock.year+(1 if career.clock.quarter == 4 else 0),1 if career.clock.quarter == 4 else career.clock.quarter*3+1]
	var previous := Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_datetime_string(first+"T00:00:00"))-86400)
	var boundary := previous
	for archive in career.competition_archive:
		if bool(archive.get("world_only",false)): continue
		var event: Dictionary = archive.get("event",{})
		var start := str(event.get("actual_dates",{}).get("start",event.get("start_date","")))
		var old_end := str(event.get("actual_dates",{}).get("end",event.get("end_date",start)))
		if not has_exact_event_dates(event):
			# A valid old player protocol can still have only month-level history.
			# Preserve it, finish its old quarter, and never guess its occupied days.
			if start.length() < 7 or old_end.length() < 7 or (start.left(7) < next.left(7) and old_end.left(7) >= first.left(7)): return _failure("旧赛事只有月份，须完成原季度后再从可核对边界启用日期推进")
			continue
		# Include races beginning in the previous quarter: their remaining
		# occupied days must not become new training after legacy receipts exist.
		if old_end < first or start >= next: continue
		if archive.get("status") != "complete" or not preload("res://src/persistence/competition_archive_codec.gd").validate(archive).is_empty(): return _failure("旧赛事尚无可校验的完整归档，不能推测日期")
		var resolved: Dictionary = preload("res://src/content/season_bundle_repository.gd").competition_event(event)
		if not resolved.get("errors",[]).is_empty(): return _failure("旧赛事日期不在可核对赛历中")
		var end := str(resolved.event.get("actual_dates",{}).get("end",resolved.event.get("end_date","")))
		if end < first or end >= next or not Dates.plan(end,end).errors.is_empty(): return _failure("旧赛事结束日期不能作为本季度前向边界")
		var full: Dictionary = preload("res://src/persistence/competition_archive_codec.gd").expand(archive)
		if not full.get("short_results",{}).has("player") or (bool(full.get("player_qualified",true)) and not full.get("free_results",{}).has("player")): return _failure("旧赛事缺少玩家应完成的分段记录")
		if end > boundary: boundary = end
	for booking in career.training_direction.external_schedule:
		if booking.status == "booked" and (int(booking.executed_stages) > 0 or booking.has("executed_days")): return _failure("请先结算已有部分外训，不能补算旧日期")
	career.competition_timeline = Timeline.empty()
	career.competition_timeline.mode = "dated"
	career.competition_timeline.date = boundary
	career.competition_timeline.origin_date = boundary
	career.competition_timeline.quarter_progress = int((Time.get_unix_time_from_datetime_string(boundary+"T00:00:00")-Time.get_unix_time_from_datetime_string(first+"T00:00:00"))/86400)+1
	return {"ok":true,"events":[]}

static func advance_until(career,target_date: String,plan) -> Dictionary:
	if career.competition_timeline.mode != "dated": return _failure("尚未建立可证实的日期游标")
	var error := Timeline.validate(career.competition_timeline,career.clock.to_dict())
	if not error.is_empty(): return _failure(error)
	if plan == null or plan.shares.is_empty(): return _failure("日期训练需要已确认的百分比计划")
	var window: Dictionary = Dates.plan(career.competition_timeline.date,target_date)
	if not window.errors.is_empty(): return _failure(str(window.errors[0]))
	var outcomes: Array = []
	var stop_node := {}
	var confirmed_events := _confirmed_events(career)
	for day in window.days:
		if plan == null or not career.condition_state.pending_decision.is_empty() or not preload("res://src/simulation/key_node_service.gd").pending(career).is_empty(): break
		var occupied := _confirmed_event_due(career,str(day.date),confirmed_events)
		if not occupied.is_empty():
			stop_node = {"kind":"competition_due" if has_exact_event_dates(occupied) else "entry_revalidation","event_id":str(occupied.event_id),"date":str(occupied.get("actual_dates",{}).get("start",occupied.start_date)),"label":"已报名赛事已到赛期或日期待核对；先处理比赛或明确退赛，不领取本日普通训练"}
			break
		if int(day.year) != career.clock.year or int(day.quarter) != career.clock.quarter: return _failure("日期与已结算季度不一致")
		if not career.competition_state.is_empty() and career.competition_state.get("status") != "complete": return _failure("比赛进行中不能领取普通训练日")
		var technique_before: Dictionary = career.athlete.technique.duplicate(true)
		var fatigue_before := {"acute_fatigue":float(career.athlete.body.acute_fatigue),"cumulative_fatigue":float(career.athlete.body.cumulative_fatigue)}
		var recovery: Dictionary = Condition.advance_injury_day(career,plan,int(day.period_days))
		if not recovery.errors.is_empty(): return _failure(str(recovery.errors[0]))
		for event in recovery.events:
			event.date = day.date; event.clock = career.clock.to_dict(); career.event_ledger.append(event)
		var reference: Dictionary = Volume.calculate(career,plan)
		Volume.apply_efficiency(reference,float(Condition.modifiers(career).training_efficiency))
		Volume.apply_efficiency(reference,float(career.last_generated_plan.get("training_efficiency",1.0)))
		var allocation: Dictionary = Dose.slice(reference,1,int(day.period_days),career.competition_timeline.attempt_remainders,plan.jump_rotations)
		if not allocation.errors.is_empty(): return _failure(str(allocation.errors[0]))
		var random: RandomNumberGenerator = career.random_streams.take_rng("training_dated:"+str(day.date))
		var jumps: Dictionary = Jump.execute(career,plan,allocation.volume,day.date,random)
		if not jumps.errors.is_empty(): return _failure(str(jumps.errors[0]))
		var nonjump: Dictionary = Nonjump.execute(career,plan,allocation.volume,random)
		if not nonjump.errors.is_empty(): return _failure(str(nonjump.errors[0]))
		var body: Dictionary = BodyLoad.apply(career,plan,{"category_volumes":nonjump.actual_category_volumes},int(day.period_days),int(jumps.actual_jump_attempts))
		if not body.errors.is_empty(): return _failure(str(body.errors[0]))
		CoachMemory.record_stage(career,plan,jumps.get("lesson_batches",jumps.aggregate_batches))
		Condition.assess_training_day(career,int(jumps.actual_jump_attempts),plan,int(day.period_days))
		# The reserve used by a same-quarter event must reflect completed
		# practice and today's restrictions, not wait for quarter settlement.
		for action_id in career.technical_repertoire.entries:
			preload("res://src/simulation/repertoire_evaluator.gd").evaluate(career,str(action_id))
		var periods_before := _rehab_periods(career)
		var medical_random: RandomNumberGenerator = career.random_streams.peek_rng("condition_rehabilitation")
		var medical: Dictionary = Rehab.advance_day(career,int(day.period_days),{"completed":true,"jump_attempts":int(jumps.actual_jump_attempts)},medical_random)
		if not medical.get("errors",[]).is_empty(): return _failure(str(medical.errors[0]))
		if _rehab_periods(career) > periods_before: career.random_streams.take_rng("condition_rehabilitation")
		for event in medical.events:
			event.date = day.date; event.clock = career.clock.to_dict(); career.event_ledger.append(event)
		var external: Dictionary = External.settle_day(career,day.date)
		if not external.errors.is_empty(): return _failure(str(external.errors[0]))
		career.competition_timeline.date = day.date
		career.competition_timeline.quarter_progress += 1
		career.competition_timeline.attempt_remainders = allocation.remainders
		career.competition_timeline.applied_intervals = [{"from":career.competition_timeline.origin_date,"through":day.date}]
		var technique_deltas := {}
		for metric in technique_before: technique_deltas[metric] = float(career.athlete.technique[metric])-float(technique_before[metric])
		var fatigue_deltas := {}; var peak := 0.0
		for metric in fatigue_before:
			fatigue_deltas[metric] = float(career.athlete.body[metric])-float(fatigue_before[metric])
			peak = maxf(peak,maxf(float(fatigue_before[metric]),float(career.athlete.body[metric])))
		career.history.append({"category":"dated_training","target":"elapsed_day","delta":1.0,"cause_codes":["actual_dated_practice"],"summary_key":"dated_training_day","date":day.date,"actual_jump_attempts":int(jumps.actual_jump_attempts),"technique_deltas":technique_deltas,"fatigue_deltas":fatigue_deltas,"peak_fatigue":peak})
		outcomes.append_array(jumps.outcomes); outcomes.append_array(nonjump.outcomes); outcomes.append_array(body.outcomes)
		if bool(day.quarter_end):
			var completed: Dictionary = _finish_quarter(career,plan,day.date)
			if not completed.ok: return completed
			plan = completed.plan
			confirmed_events = _confirmed_events(career)
	var result := {"ok":true,"events":[],"outcomes":outcomes,"stopped_date":career.competition_timeline.date}
	if not stop_node.is_empty(): result.stop_node = stop_node
	return result

static func consume_completed_competition(career,event_id: String) -> Dictionary:
	if career.competition_timeline.mode != "dated": return _failure("尚未建立可证实的日期游标")
	var error := Timeline.validate(career.competition_timeline,career.clock.to_dict())
	if not error.is_empty(): return _failure(error)
	var completed: bool = career.competition_archive.any(func(archive):return archive.get("event_id") == event_id and archive.get("status") == "complete" and not bool(archive.get("world_only",false)))
	if not completed: return _failure("只有玩家实际完成归档的赛事才能结算占用日期")
	var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(career)
	if not bundle.get("errors",[]).is_empty(): return _failure(str(bundle.errors))
	var events: Array = bundle.get("calendar",{}).get("events",[]).filter(func(event):return event.get("event_id") == event_id)
	if events.size() != 1: return _failure("赛事日期无法在当前赛历核对")
	var event: Dictionary = events[0]
	var start := str(event.get("actual_dates",{}).get("start",event.start_date))
	var end := str(event.get("actual_dates",{}).get("end",event.get("end_date",start)))
	if str(career.competition_timeline.date) >= end: return {"ok":true,"events":[]}
	var window: Dictionary = Dates.plan(career.competition_timeline.date,end)
	if not window.errors.is_empty(): return _failure(str(window.errors))
	if window.days.is_empty() or str(window.days[0].date) < start: return _failure("请先结算比赛开始前的训练日期，不能将空档当作比赛日跳过")
	# Race consequences have already been applied by the real SP/FS archive.
	# Consume calendar occupancy only: never grant practice or apply race load twice.
	var data: Dictionary = career.last_generated_plan
	var plan = preload("res://src/domain/training_plan.gd").from_dict(data.get("executed",data))
	if plan == null: return _failure("比赛日期结算缺少当前训练计划")
	for day in window.days:
		if int(day.year) != career.clock.year or int(day.quarter) != career.clock.quarter: return _failure("比赛日期与当前季度不一致")
		# A course booked before a later confirmed race cannot consume race
		# days. Refund its unused remainder once, retaining the confirmed plan.
		for booking in career.training_direction.external_schedule:
			if booking.get("status") != "booked" or int(booking.year) != int(day.year) or int(booking.quarter) != int(day.quarter): continue
			var cancelled: Dictionary = External.cancel(career,str(booking.id),"competition-overlap:"+event_id+":"+str(booking.id),false)
			if not cancelled.ok: return _failure(str(cancelled.get("error","外训撞期结算失败")))
		career.competition_timeline.date = day.date
		career.competition_timeline.quarter_progress += 1
		career.competition_timeline.applied_intervals = [{"from":career.competition_timeline.origin_date,"through":day.date}]
		if bool(day.quarter_end):
			var finished: Dictionary = _finish_quarter(career,plan,day.date)
			if not finished.ok: return finished
			plan = finished.plan
	return {"ok":true,"events":[]}

static func _confirmed_events(career) -> Array:
	var entries: Dictionary = career.season_state.get("entry_plan",{}).get("entries",{})
	if not entries.values().any(func(entry):return entry.get("status") == "confirmed"): return []
	# The calendar is invariant during a synchronous interval. Do not rebuild
	# and audit every event's rules on every single simulated day.
	var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(career)
	var calendar = preload("res://src/content/season_calendar_repository.gd")
	return calendar.chronological_events(bundle.get("calendar",{})).filter(func(event):return calendar.event_status(event) in ["scheduled","held"] and entries.get(str(event.event_id),{}).get("status") == "confirmed")

static func _confirmed_event_due(career,date: String,events: Array) -> Dictionary:
	for event in events:
		var completed: bool = career.competition_archive.any(func(archive):return archive.get("event_id") == event.event_id and archive.get("status") == "complete" and not bool(archive.get("world_only",false)))
		if not has_exact_event_dates(event):
			if completed: continue
			return event
		var start := str(event.get("actual_dates",{}).get("start",event.start_date))
		if start > date: continue
		var end := str(event.get("actual_dates",{}).get("end",event.get("end_date",start)))
		if completed and str(career.competition_timeline.date) >= end: continue
		return event
	return {}

static func _finish_quarter(career,plan,date: String) -> Dictionary:
	var commands = load("res://src/simulation/career_command_service.gd")
	var intent: Dictionary = commands._continuation_intent(career,plan.to_dict())
	var clock: Dictionary = career.clock.to_dict()
	var previous: Dictionary = career.development_roadmap.get("last_evaluation",{}).duplicate(true)
	var legacy = load("res://src/simulation/career_simulator.gd")
	# Training and injury time have already been paid one actual day at a time.
	# Only the remaining quarterly lifecycle is settled here.
	Condition.advance_quarter(career,plan,career.seed,false)
	CoachMemory.complete_period(career)
	preload("res://src/simulation/certification_service.gd").process_quarter(career)
	for action_id in career.technical_repertoire.entries:
		preload("res://src/simulation/repertoire_evaluator.gd").evaluate(career,str(action_id))
	if career.clock.quarter == 4: career.history.append(legacy._build_season_summary(career,career.clock.year))
	career.clock.advance_quarter()
	career.competition_timeline.quarter_progress = 0
	career.training_period_state = {}
	legacy._update_roadmap_progress(career,previous)
	preload("res://src/simulation/event_engine.gd").decay_memories(career)
	var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(career)
	var world: Dictionary = preload("res://src/simulation/world_season_simulator.gd").advance_to(career,career.clock.to_dict(),bundle)
	if not world.errors.is_empty(): return _failure(str(world.errors))
	var next_plan = plan
	if str(career.last_training_policy.get("policy_id","")) == "recovery":
		career.last_training_policy = {}; career.last_generated_plan = {}; next_plan = null
	elif not intent.is_empty():
		var rebuilt: Dictionary = preload("res://src/simulation/coach_training_plan_service.gd").build(career,preload("res://src/domain/training_intent.gd").from_dict(intent))
		if not rebuilt.errors.is_empty(): return _failure(str(rebuilt.errors))
		next_plan = rebuilt.plan
		career.last_generated_plan = next_plan.to_dict()
		career.event_ledger.append({"kind":"coach_curriculum","clock":career.clock.to_dict(),"intent":intent,"executed_plan":career.last_generated_plan.duplicate(true)})
	career.event_ledger.append({"kind":"dated_quarter_completed","from_clock":clock,"clock":career.clock.to_dict(),"date":date})
	return {"ok":true,"plan":next_plan,"events":[]}

static func _rehab_periods(career) -> int:
	var count := 0
	for record in career.condition_state.rehabilitation.values(): count += int(record.elapsed_quarters)
	return count

static func _failure(message: String) -> Dictionary:
	return {"ok":false,"events":[],"error":message}
