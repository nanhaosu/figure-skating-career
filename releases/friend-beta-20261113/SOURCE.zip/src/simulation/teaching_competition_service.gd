class_name TeachingCompetitionService
extends RefCounted

const EarlyPeerPoolService = preload("res://src/simulation/early_peer_pool_service.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const WorldGenerationService = preload("res://src/simulation/world_generation_service.gd")

const EARLIEST_WEEK := 18
const LATEST_WEEK := 36

static func evaluate(career) -> Dictionary:
	if career == null or career.athlete == null:
		return _result(false, 0, ["missing_career"], "", [], {})
	var peers := EarlyPeerPoolService.ensure_pool(career)
	if not peers.errors.is_empty(): return _result(false, 0, ["peer_pool_failed"], "", [], {})
	var state: Dictionary = career.internal_invitation_state
	if not state.has("scheduled_week"):
		var readiness := _readiness(career)
		var variation := WorldGenerationService.stable_seed("teaching:%d" % int(career.seed)) % 3
		var week := clampi(26 - int(floor(readiness / 20.0)) + int(variation), EARLIEST_WEEK, LATEST_WEEK)
		state["scheduled_week"] = week
		state["event_id"] = "teaching-%d-first" % int(career.seed)
		state["peer_ids"] = Array(peers.peer_ids).duplicate()
	var scheduled_week := int(state.scheduled_week)
	var window_end := 12 if scheduled_week <= 12 else LATEST_WEEK
	var due_week := scheduled_week
	if str(state.get("status", "not_ready")) == "deferred": due_week = mini(window_end, int(state.get("deferred_until_week", scheduled_week)))
	var current_week := elapsed_week(career)
	var completed := str(state.get("status", "")) == "completed" or _has_completed_match(career)
	# This is a first-season teaching invitation, not a permanent modal that can
	# follow the skater for years. Once its first-season window closes,
	# a player who deferred it is free to continue the career without reoffers.
	var available := not completed and current_week >= due_week and current_week <= window_end
	var ready := _programs_ready(career)
	var reasons: Array[String] = []
	if completed: reasons.append("teaching_event_completed")
	elif not available: reasons.append("invitation_not_due")
	elif not ready: reasons.append("programs_need_preparation")
	else: reasons.append("ready_to_accept")
	if available:
		_record_invitation_once(career, state, current_week)
	return _result(available, scheduled_week, reasons, str(state.event_id), peers.peer_ids, {
		"short":InternalEventRules.for_teaching_group("short"),
		"free":InternalEventRules.for_teaching_group("free"),
	}, current_week)

static func elapsed_week(career) -> int:
	var start_year := int(career.story_context.start_year)
	var completed_quarters := maxi(0, (int(career.clock.year) - start_year) * 4 + int(career.clock.quarter) - 1)
	return completed_quarters * 12 + int(career.training_period_state.get("weeks_elapsed", 0))

static func _readiness(career) -> float:
	return clampf((float(career.athlete.skating.deep_edge) + float(career.athlete.technique.single_jumps) + float(career.athlete.mind.motivation)) / 3.0, 0.0, 100.0)

static func _programs_ready(career) -> bool:
	for segment in ["short", "free"]:
		var data: Dictionary = career.active_programs.get(segment, {})
		var program = SkatingProgram.from_dict(data) if not data.is_empty() else null
		if not ProgramValidator.validate(program, career.athlete, InternalEventRules.for_teaching_group(segment)).is_empty(): return false
		if program.draft_status != "locked" or not program.locked_segments.has(segment): return false
	return true

static func _record_invitation_once(career, state: Dictionary, current_week: int) -> void:
	var event_id := str(state.event_id)
	if career.event_ledger.any(func(entry): return str(entry.get("id", "")) == event_id): return
	career.event_ledger.append({
		"id":event_id, "kind":"teaching_competition_invitation",
		"clock":career.clock.to_dict(), "week":current_week,
		"peer_ids":Array(state.peer_ids).duplicate(),
	})
	state["offered_clock"] = career.clock.to_dict()
	state["offered_week"] = current_week
	if str(state.get("status", "not_ready")) == "not_ready": state.status = "pending"

static func _has_completed_match(career) -> bool:
	return career.history.any(func(entry): return str(entry.get("category", "")) == "internal_competition")

static func _result(available: bool, week: int, reasons: Array, event_id: String, peer_ids: Array, rules: Dictionary, current_week: int = 0) -> Dictionary:
	return {
		"available":available, "week":week, "current_week":current_week,
		"reason_codes":reasons.duplicate(), "event_id":event_id,
		"peer_ids":peer_ids.duplicate(), "eligible_program_rules":rules.duplicate(true),
	}
