class_name TrainingDirectionService
extends RefCounted

static func change(career, direction: Dictionary, receipt_id: String) -> Dictionary:
	if receipt_id.is_empty() or receipt_id.length() > 160: return {"ok":false,"error":"训练方向确认编号无效"}
	for event in career.event_ledger:
		if event.get("kind") == "training_direction_changed" and event.get("receipt_id") == receipt_id: return {"ok":true,"events":[]}
	var error: String = preload("res://src/domain/training_direction.gd").validate(direction)
	if not error.is_empty(): return {"ok":false,"error":error}
	if int(direction.revision) != int(career.training_direction.revision): return {"ok":false,"error":"训练方向已更新，请重新打开再修改"}
	for booking in career.training_direction.external_schedule:
		if booking.status != "booked": continue
		var retained := false
		for focus in direction.focuses:
			if focus.kind == booking.focus.kind and focus.target == booking.focus.target:
				retained = true
				break
		if not retained: return {"ok":false,"error":"这个重点已有付费外训，请先在外训窗口取消预约，退回未执行课程费用后再修改"}
	var working = career.transaction_copy()
	working.training_direction = direction.duplicate(true)
	working.training_direction.external_schedule = career.training_direction.external_schedule.duplicate(true)
	working.training_direction.revision = int(career.training_direction.revision)+1
	var intent = preload("res://src/domain/training_intent.gd").from_dict(career.training_period_state.get("intent",{"mode":"accept","element_id":""}))
	var built: Dictionary = preload("res://src/simulation/coach_training_plan_service.gd").build(working,intent)
	if not built.errors.is_empty(): return {"ok":false,"error":"；".join(built.errors)}
	working.last_generated_plan = built.plan.to_dict()
	if not working.training_period_state.is_empty(): working.training_period_state.plan = built.plan.to_dict()
	var event := {"kind":"training_direction_changed","receipt_id":receipt_id,"clock":working.clock.to_dict(),"revision":working.training_direction.revision}
	working.event_ledger.append(event)
	career.commit_from(working)
	return {"ok":true,"events":[event]}
