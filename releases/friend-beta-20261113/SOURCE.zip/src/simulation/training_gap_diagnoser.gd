class_name TrainingGapDiagnoser
extends RefCounted

const FAMILIES := ["toe_loop","salchow","loop","flip","lutz"]

static func inspect(career) -> Dictionary:
	var result := {"candidates":[],"blocked":[]}
	if career == null or career.athlete == null: return result
	var highest := 1
	for id in FAMILIES: highest = maxi(highest,mini(3,int(career.athlete.jumps[id].unlocked_rotations)))
	# Share the same readiness rules as normal coaching; this is read-only.
	var working: Dictionary = load("res://src/simulation/coach_training_plan_service.gd")._maintenance_targets(career)
	for id in FAMILIES:
		var jump = career.athlete.jumps[id]
		if int(jump.unlocked_rotations) >= highest: continue
		var target := mini(highest,maxi(1,int(jump.unlocked_rotations))+1)
		var constraint: Dictionary = preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,{"kind":"jump","parts":[{"jump_id":id,"rotations":target}]})
		var row := {"jump_id":id,"rotations":target,"stage":"practice" if int(working.get(id,1)) >= target else "preparation","reason_codes":["foundation_gap"]}
		if not constraint.allowed: result.blocked.append(row)
		else: result.candidates.append(row)
	# Acquisition remains first, including medically blocked acquisition. Only
	# after breadth is learned do ordinary triples enter consolidation rotation.
	if result.candidates.is_empty() and result.blocked.is_empty():
		for id in FAMILIES:
			var jump = career.athlete.jumps[id]
			if int(jump.unlocked_rotations) < 3 or str(career.development_roadmap.get("deferred_jump","")) == id: continue
			var readiness: Dictionary = preload("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,id,3)
			var action := {"kind":"jump","parts":[{"jump_id":id,"rotations":3}]}
			var action_id: String = preload("res://src/domain/technical_repertoire.gd").action_id(action)
			var available: bool = career.technical_repertoire.entries.get(action_id,{}).get("state","") == "available"
			var physical: bool = readiness.gaps.has("physical_readiness_low")
			if readiness.stage_id in ["official_ready","core"] and available and not physical: continue
			var constraint: Dictionary = preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,action)
			var row := {"jump_id":id,"rotations":3,"stage":"preparation" if physical else "practice","reason_codes":["consolidation_gap"]}
			if physical: row.reason_codes.append("physical_readiness_low")
			if not constraint.allowed: result.blocked.append(row)
			else: result.candidates.append(row)
	var recent: Dictionary = career.coach_training_state.get("last_practiced",{})
	result.candidates.sort_custom(func(a,b):
		var left := int(recent.get(a.jump_id,0))
		var right := int(recent.get(b.jump_id,0))
		if left != right: return left < right
		if a.stage != b.stage: return a.stage == "practice"
		var a_jump = career.athlete.jumps[a.jump_id]
		var b_jump = career.athlete.jumps[b.jump_id]
		var a_key: String = ["","single","double","triple"][maxi(1,int(a.rotations)-1)]
		var b_key: String = ["","single","double","triple"][maxi(1,int(b.rotations)-1)]
		for metric in ["clean_successes","successes"]:
			var a_value := int(a_jump.attempt_evidence[a_key].get(metric,0))
			var b_value := int(b_jump.attempt_evidence[b_key].get(metric,0))
			if a_value != b_value: return a_value > b_value
		if not is_equal_approx(float(a_jump.proficiency[a_key]),float(b_jump.proficiency[b_key])):
			return float(a_jump.proficiency[a_key]) > float(b_jump.proficiency[b_key])
		return FAMILIES.find(a.jump_id) < FAMILIES.find(b.jump_id))
	return result
