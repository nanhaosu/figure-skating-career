class_name RoadmapProgressUpdater
extends RefCounted

const QuarterEvent = preload("res://src/domain/quarter_event.gd")

static func update(career, previous_evaluation: Dictionary, current_evaluation: Dictionary) -> Dictionary:
	var previous_status := str(previous_evaluation.get("status", ""))
	var current_status := str(current_evaluation.get("status", ""))
	var result := {
		"status_change": {"from": previous_status, "to": current_status} if previous_status != current_status else {},
		"forecast_change": _forecast_change(previous_evaluation, current_evaluation),
		"key_events": [],
		"revision_suggestion": "",
		"behind_streak": _behind_streak(previous_evaluation, current_status),
	}
	var signature := _event_signature(previous_evaluation, current_evaluation, int(result.behind_streak))
	if signature.is_empty():
		return result
	result.key_events.append(_build_event(career, signature, current_evaluation))
	if signature == "roadmap_milestone_reached":
		result.revision_suggestion = "raise_targets_optional"
	elif signature != "":
		result.revision_suggestion = "review_targets"
	return result

static func _behind_streak(previous: Dictionary, current_status: String) -> int:
	if not ["slightly_behind", "far_behind"].has(current_status):
		return 0
	var previous_streak := int(previous.get("behind_streak", 0))
	if previous_streak == 0 and ["slightly_behind", "far_behind"].has(str(previous.get("status", ""))):
		previous_streak = 1
	return previous_streak + 1

static func _event_signature(previous: Dictionary, current: Dictionary, behind_streak: int) -> String:
	if _new_milestone_reached(previous, current):
		return "roadmap_milestone_reached"
	var risks: Array = current.get("risk_codes", [])
	if risks.has("growth_acceleration") or risks.has("high_body_load"):
		return "roadmap_body_reassessment"
	if risks.has("observed_technique_flaw") or _new_visible_technical_reason(previous, current):
		return "roadmap_technical_reassessment"
	if risks.has("limited_resources"):
		return "roadmap_resource_reassessment"
	if behind_streak >= 2 and str(current.get("status", "")) == "far_behind":
		return "roadmap_far_behind"
	return ""

static func _new_milestone_reached(previous: Dictionary, current: Dictionary) -> bool:
	var before: Array = previous.get("milestone_forecasts", [])
	var after: Array = current.get("milestone_forecasts", [])
	for index in mini(before.size(), after.size()):
		if int(before[index].get("current_count", 0)) < int(after[index].get("count", 0)) and int(after[index].get("current_count", 0)) >= int(after[index].get("count", 0)):
			return true
	return false

static func _new_visible_technical_reason(previous: Dictionary, current: Dictionary) -> bool:
	if not current.get("risk_codes", []).has("latent_technique_risk"):
		return false
	var before: Array = previous.get("visible_reasons", [])
	for reason in current.get("visible_reasons", []):
		if not before.has(reason) and str(reason) != "技术稳定性存在风险":
			return true
	return false

static func _forecast_change(previous: Dictionary, current: Dictionary) -> Array[Dictionary]:
	var changes: Array[Dictionary] = []
	var before: Array = previous.get("milestone_forecasts", [])
	var after: Array = current.get("milestone_forecasts", [])
	for index in mini(before.size(), after.size()):
		var old_age := int(before[index].get("likely_age", 0))
		var new_age := int(after[index].get("likely_age", 0))
		if old_age != new_age:
			changes.append({"milestone": index, "from_age": old_age, "to_age": new_age})
	return changes

static func _build_event(career, signature: String, evaluation: Dictionary):
	var event = QuarterEvent.new()
	event.id = "event:%d:%d:%s" % [career.clock.year, career.clock.quarter, signature]
	event.signature = signature
	event.trigger_codes.assign(evaluation.get("risk_codes", []))
	event.cause_ids.assign(["development_roadmap"])
	var copy: Array = {
		"roadmap_milestone_reached": ["路线节点达成", "实际进度已经达到成长路线中的一个节点。要巩固成果，还是考虑提高后续目标？"],
		"roadmap_far_behind": ["成长路线连续落后", "实际进度已连续偏离原定路线，教练建议重新讨论目标。"],
		"roadmap_body_reassessment": ["身体变化需要重评", "近期发育或身体负荷改变了原路线的可行性。"],
		"roadmap_technical_reassessment": ["技术问题影响路线", "近期识别出的技术问题可能改变动作学习顺序。"],
		"roadmap_resource_reassessment": ["训练资源发生变化", "冰时或资金条件已经不足以照原速度推进。"],
	}.get(signature, ["成长路线需要讨论", "教练希望与你重新讨论成长路线。"])
	event.title = copy[0]
	event.description = copy[1]
	if signature == "roadmap_milestone_reached":
		event.choices.assign([{"id": "roadmap_consolidate", "label": "先巩固成果"}, {"id": "roadmap_raise_targets", "label": "提高后续目标"}])
	else:
		event.choices.assign([{"id": "roadmap_accept_revision", "label": "接受教练调整"}, {"id": "roadmap_temporary_safety", "label": "只做暂时保护"}, {"id": "roadmap_keep_targets", "label": "维持原目标"}])
	return event
