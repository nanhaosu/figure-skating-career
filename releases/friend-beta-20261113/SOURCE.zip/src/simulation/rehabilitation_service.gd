class_name RehabilitationService
extends RefCounted

# These are game treatment routes, not medical advice or promised outcomes.
static func options(career, injury_id: String) -> Dictionary:
	var injury := _injury(career,injury_id)
	var reassessment: bool = not injury.get("residual_function_limits",{}).is_empty()
	if injury.is_empty() or (str(injury.get("status","")) != "active" and not reassessment) or float(injury.get("severity",0.0)) < 0.7:
		return {"routes":[],"error":"当前伤情不需要重大治疗选择"}
	var offered := {"injury_id":injury_id,"restrictions":["复评前暂停跳跃与飞行旋转"],"uncertainty":"恢复进度按阶段评估，两条路线都不保证恢复原难度。", "routes":[
		{"id":"conservative","label":"保守治疗，优先恢复安全日常训练","time_range_quarters":[1,4],"risk":"较早恢复低冲击训练，但高难度落冰可能需要长期限制。","resource_impact":"减少停训时间；复评未通过仍需继续康复。"},
		{"id":"full_rehabilitation","label":"较长周期康复，优先恢复身体功能","time_range_quarters":[4,8],"risk":"可能错过一至两个赛季；完成疗程也不保证重新掌握高难度。","resource_impact":"较长时间缺席比赛，赛事收益与待遇影响由实际缺席结算。"}
	]}
	if reassessment and str(injury.get("status","")) == "recovered": offered.routes = offered.routes.filter(func(route): return route.id == "full_rehabilitation")
	return offered

static func choose(career, injury_id: String, route_id: String, receipt_id: String) -> Dictionary:
	if receipt_id.is_empty(): return {"ok":false,"error":"缺少确认凭据"}
	var records: Dictionary = career.condition_state.rehabilitation
	for existing in records.values():
		for receipt in existing.get("receipts",[]):
			if str(receipt.id) == receipt_id:
				return {"ok":str(receipt.injury_id) == injury_id and str(receipt.route_id) == route_id,"replayed":true}
	var offered := options(career,injury_id)
	var valid := false
	for route in offered.routes:
		if str(route.id) == route_id: valid = true
	if not valid: return {"ok":false,"error":"治疗路线不适用于当前伤情"}
	var previous: Dictionary = records.get(injury_id,{})
	var injury := _injury(career,injury_id)
	var reassessment: bool = str(injury.get("status","")) == "recovered" and not injury.get("residual_function_limits",{}).is_empty()
	if not previous.is_empty() and str(previous.get("stage","")) != "review" and not reassessment:
		return {"ok":false,"error":"当前疗程尚未到复评节点"}
	var record: Dictionary = previous.duplicate(true)
	if record.is_empty(): record = {"elapsed_quarters":0,"progress":0.0,"receipts":[]}
	record.route_id = route_id
	record.stage = "protection"
	record.route_quarters = 0
	record.erase("dated_period_fraction")
	record.erase("dated_unsafe_load")
	record.receipts.append({"id":receipt_id,"injury_id":injury_id,"route_id":route_id})
	records[injury_id] = record
	injury.status = "active"
	injury.function_limits = {"landing":{"blocked":true,"factor":0.4,"review_condition":"完成保护期后复评落冰功能"}}
	injury.rehabilitation_managed = true
	if str(career.condition_state.pending_decision.get("injury_id","")) == injury_id:
		career.condition_state.pending_decision = {}
	for node in career.condition_state.get("key_nodes",[]):
		if str(node.get("id","")) == injury_id and str(node.get("kind","")) == "injury_review":
			node.resolved = true
			node.response_id = route_id
			node.resolved_clock = career.clock.to_dict()
	return {"ok":true,"replayed":false}

static func advance(career, executed_load: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	return _advance(career,executed_load,rng,0)

# The dated command calls this exactly once per actually elapsed day, even
# on competition/rest days. Random review happens only after a full elapsed
# treatment period; it is not pre-drawn at treatment choice or per click.
static func advance_day(career,period_days: Variant,executed_load: Dictionary,rng: RandomNumberGenerator) -> Dictionary:
	var periods = preload("res://src/simulation/dated_training_dose.gd")
	var valid: Dictionary = periods.accrue_period({},1,period_days)
	var attempts = executed_load.get("jump_attempts",0)
	if not valid.errors.is_empty() or not (attempts is int or attempts is float) or not is_finite(float(attempts)) or float(attempts) != floorf(float(attempts)) or float(attempts) < 0 or float(attempts) > 1000000: return {"events":[],"necessary_decision":{},"errors":["康复日历或实际负荷无效"]}
	for record in career.condition_state.rehabilitation.values():
		var fraction = record.get("dated_period_fraction",{})
		if not fraction is Dictionary or not periods.accrue_period(fraction,0,period_days).errors.is_empty() or not record.get("dated_unsafe_load",false) is bool: return {"events":[],"necessary_decision":{},"errors":["康复日历余量无效"]}
	return _advance(career,executed_load,rng,int(period_days))

static func _advance(career,executed_load: Dictionary,rng: RandomNumberGenerator,period_days: int) -> Dictionary:
	var result := {"events":[],"necessary_decision":{}}
	if not bool(executed_load.get("completed",false)): return result
	for injury_id in career.condition_state.rehabilitation:
		var record: Dictionary = career.condition_state.rehabilitation[injury_id]
		var injury := _injury(career,str(injury_id))
		if injury.is_empty() or str(injury.status) != "active" or str(record.stage) == "review": continue
		var safe := int(executed_load.get("jump_attempts",0)) == 0
		if period_days > 0:
			var duration: Dictionary = preload("res://src/simulation/dated_training_dose.gd").accrue_period(record.get("dated_period_fraction",{}),1,period_days)
			record.dated_period_fraction = duration.fraction
			record.dated_unsafe_load = bool(record.get("dated_unsafe_load",false)) or not safe
			if int(duration.completed_periods) == 0: continue
			safe = not bool(record.dated_unsafe_load)
			record.dated_unsafe_load = false
		elif record.has("dated_period_fraction"):
			continue # A legacy quarter callback cannot double-count dated time.
		record.elapsed_quarters = int(record.elapsed_quarters)+1
		record.route_quarters = int(record.route_quarters)+1
		var recovery := clampf(float(career.athlete.body.recovery_capacity)/100.0,0.0,1.0)
		var full_route := str(record.route_id) == "full_rehabilitation"
		var gain := rng.randf_range(0.08,0.16)*(0.7+recovery*0.6) if safe else -0.06
		# A plateau/setback is assessed now, not pre-drawn as a final destiny.
		if safe and rng.randf() < 0.10 + (1.0-recovery)*0.10: gain = -rng.randf_range(0.01,0.04)
		record.progress = clampf(float(record.progress)+gain,0.0,1.0)
		var minimum := 4 if full_route else 1
		if int(record.route_quarters) < minimum: continue
		var return_threshold := 0.65 if full_route else 0.35
		if float(record.progress) >= return_threshold:
			injury.status = "recovered"
			injury.function_limits = {}
			if not full_route:
				injury.residual_function_limits = {"landing":{"factor":clampf(0.65+float(record.progress)*0.30,0.65,0.95),"maximum_rotations":3,"review_condition":"保守路线已恢复安全基础；完整康复复评前不练四周，高难度仍需逐项验证"}}
			else:
				injury.erase("residual_function_limits")
			record.stage = "return_to_training"
			result.events.append({"kind":"rehabilitation_return","injury_id":injury_id,"label":"通过基础复评，可恢复安全训练；落冰仍有限制，不能直接恢复原难度" if not full_route else "通过身体复评，可逐步恢复训练；高难度仍需重新验证"})
		elif int(record.route_quarters) >= minimum+2:
			record.stage = "review"
			career.condition_state.pending_decision = {"kind":"rehabilitation_review","injury_id":injury_id,"elapsed_quarters":record.elapsed_quarters}
			result.necessary_decision = career.condition_state.pending_decision.duplicate(true)
		else:
			record.stage = "functional_recovery"
	return result

static func _injury(career, injury_id: String) -> Dictionary:
	for injury in career.condition_state.injuries:
		if str(injury.get("id","")) == injury_id: return injury
	return {}
