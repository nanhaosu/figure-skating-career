class_name JumpAttemptBatchSimulator
extends RefCounted

const ROTATION_KEYS := {1: "single", 2: "double", 3: "triple", 4: "quad"}
const FAILURE_KEYS: Array[String] = ["falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]
const ROTATION_DIFFICULTY_PENALTY := 14.0
const MINIMUM_TRAINING_SUCCESS_PROBABILITY := 0.05
const MINIMUM_CLEAN_RATE_AFTER_SUCCESS := 0.20
const FOUNDATION_READINESS_WEIGHT := 0.22
const PROFICIENCY_SUCCESS_WEIGHT := 0.45

static func simulate(career, jump_id: String, rotations: int, attempts: int, supervision: float, rng: RandomNumberGenerator) -> Dictionary:
	var result := {
		"successes": 0, "clean_successes": 0, "falls": 0, "pops": 0,
		"two_foot": 0, "hand_down": 0, "underrotated": 0, "downgraded": 0,
		"probability": 0.0, "outcomes": [], "milestones": [],
	}
	if career == null or career.athlete == null or not career.athlete.jumps.has(jump_id) or not ROTATION_KEYS.has(rotations) or attempts <= 0:
		return result
	if not preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,{"kind":"jump","parts":[{"jump_id":jump_id,"rotations":rotations}]}).allowed:
		return result
	var profile = career.athlete.jumps[jump_id]
	var rotation_key: String = ROTATION_KEYS[rotations]
	var body: Dictionary = career.athlete.body
	var mind: Dictionary = career.athlete.mind
	var foundation: Dictionary = career.athlete.jump_foundation.to_dict()
	var skill: float = (
		float(profile.proficiency.get(rotation_key, 0.0)) * PROFICIENCY_SUCCESS_WEIGHT
		+ float(profile.takeoff.get("edge_stability", 0.0)) * 0.10
		+ float(profile.air.get("axis", 0.0)) * 0.15
		+ float(profile.landing.get("completion", 0.0)) * 0.15
		+ float(profile.landing.get("control", 0.0)) * 0.10
		+ float(body.get("strength_readiness", 0.0)) * 0.10
		+ float(body.get("joint_readiness", 0.0)) * 0.10
		+ (float(foundation.get("air_axis", 0.0)) + float(foundation.get("rotation_completion", 0.0)) + float(foundation.get("landing_control", 0.0))) / 3.0 * FOUNDATION_READINESS_WEIGHT
	)
	var penalty: float = float(rotations - 1) * ROTATION_DIFFICULTY_PENALTY
	penalty += float(body.get("acute_fatigue", 0.0)) * 0.25
	penalty += float(body.get("cumulative_fatigue", 0.0)) * 0.15
	penalty += float(body.get("ankle_load", 0.0)) * 0.08
	penalty += float(body.get("impact_load", 0.0)) * 0.08
	penalty += float(mind.get("training_fear", 0.0)) * 0.10
	var probability: float = clampf((skill - penalty + (clampf(supervision, 0.0, 1.0) - 0.5) * 10.0) / 100.0, MINIMUM_TRAINING_SUCCESS_PROBABILITY, 0.97)
	# Physical readiness is already represented in skill. Only maturation gates
	# early attempts; mature training retains the existing nonzero learning floor.
	var maturation: float = load("res://src/simulation/jump_maturation.gd").age_factor(career,jump_id,rotations)
	probability = maxf(probability*maturation,MINIMUM_TRAINING_SUCCESS_PROBABILITY*minf(1.0,maturation*3.0))
	var functions = preload("res://src/simulation/athlete_function_service.gd")
	probability *= functions.execution_factor(functions.snapshot(career).limits,{"kind":"jump","parts":[{"jump_id":jump_id,"rotations":rotations}]})
	result.probability = probability
	for attempt_index in attempts:
		if rng.randf() < probability:
			result.successes += 1
			var clean_rate := clampf(MINIMUM_CLEAN_RATE_AFTER_SUCCESS + float(profile.landing.get("control", 0.0)) * 0.005, MINIMUM_CLEAN_RATE_AFTER_SUCCESS, 0.90)
			if rng.randf() < clean_rate:
				result.clean_successes += 1
		else:
			var failure_index: int = mini(int(floor(rng.randf() * FAILURE_KEYS.size())), FAILURE_KEYS.size() - 1)
			result[FAILURE_KEYS[failure_index]] += 1
	var evidence: Dictionary = profile.attempt_evidence[rotation_key]
	var previous_successes: int = int(evidence.successes)
	evidence.attempts += attempts
	for count_key in ["successes", "clean_successes", "falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]:
		evidence[count_key] += int(result[count_key])
	profile.attempts += attempts
	if previous_successes == 0 and int(result.successes) > 0:
		profile.unlocked_rotations = maxi(profile.unlocked_rotations, rotations)
		evidence.first_success_clock = career.clock.to_dict() if career.clock != null else {}
		result.milestones.append({
			"category": "jump_milestone",
			"signature": "first_jump_success:%s:%d" % [jump_id, rotations],
			"jump_id": jump_id, "rotations": rotations,
			"clock": evidence.first_success_clock.duplicate(true),
		})
	result.outcomes.append({
		"category": "jump_attempt_batch", "jump_id": jump_id, "rotations": rotations,
		"attempts": attempts, "successes": result.successes, "clean_successes": result.clean_successes,
		"falls": result.falls, "pops": result.pops, "two_foot": result.two_foot,
		"hand_down": result.hand_down, "underrotated": result.underrotated,
		"downgraded": result.downgraded, "probability": probability,
		"cause_codes": ["%s_practice" % jump_id, "%d_rotation_attempt" % rotations],
	})
	return result
