class_name InternalCompetitionSimulator
extends RefCounted

const ProgramPerformanceSimulator = preload("res://src/simulation/program_performance_simulator.gd")
const TechnicalPanelSimulator = preload("res://src/simulation/technical_panel_simulator.gd")
const JudgingPanelSimulator = preload("res://src/simulation/judging_panel_simulator.gd")
const BetweenSegmentAdjuster = preload("res://src/simulation/between_segment_adjuster.gd")
const ClubDecisionSimulator = preload("res://src/simulation/club_decision_simulator.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const CompetitionRoutePlanner = preload("res://src/simulation/competition_route_planner.gd")
const CompetitionRouteExecutor = preload("res://src/simulation/competition_route_executor.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const AthleteConditionService = preload("res://src/simulation/athlete_condition_service.gd")

const RIVAL_SURNAMES := ["沈", "许", "周", "顾", "乔", "叶", "唐", "韩", "宋", "陆", "夏", "程"]
const RIVAL_GIVEN_NAMES := ["清遥", "雨桐", "知夏", "星澜", "若宁", "舒言", "念初", "映雪", "可心", "芷晴", "安然", "予晨"]

static func start_event(career, short_program, free_program, strategy: Dictionary, context: Dictionary, seed: int, rival_count: int = 5) -> Dictionary:
	if not AthleteConditionService.can_compete(career): return {"status":"error", "errors":["伤病尚未恢复，暂不能参赛"]}
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var reputation: Dictionary = Dictionary(context.get("reputation", {})).duplicate(true)
	var influence: Dictionary = Dictionary(context.get("influence", {})).duplicate(true)
	if not influence.has("event_scope"): influence.event_scope = "internal"
	var short_context := _segment_context(career, context, 0.0)
	var player_context := short_context.duplicate(true)
	player_context.merge(AthleteConditionService.competition_context(career), true)
	var player_short := _simulate_segment(career.athlete, short_program, strategy, player_context, reputation, influence, rng)
	var rivals: Array[Dictionary] = []
	var used_names: Array[String] = [career.athlete.display_name]
	var peer_ids: Array = context.get("peer_ids", [])
	for index in maxi(0, rival_count):
		var peer: Dictionary = career.world_athletes.get(str(peer_ids[index]), {}) if index < peer_ids.size() else {}
		var rival_athlete = AthleteState.from_dict(peer.athlete) if not peer.is_empty() else _generate_rival(career.athlete, used_names, rng)
		used_names.append(rival_athlete.display_name)
		var rival_short_program = SkatingProgram.from_dict(peer.short_program) if not peer.is_empty() else _adapt_program(short_program, "rival-%d-short" % index, rng)
		var rival_free_program = SkatingProgram.from_dict(peer.free_program) if not peer.is_empty() else _adapt_program(free_program, "rival-%d-free" % index, rng)
		var rival_influence := {
			"event_scope": "internal",
			"priority": rng.randf_range(5.0, 78.0),
			"coach_voice": rng.randf_range(10.0, 75.0),
		}
		var rival_strategy := {"risk": ["conservative", "balanced", "aggressive"][rng.randi_range(0, 2)]}
		var rival_short := _simulate_segment(rival_athlete, rival_short_program, rival_strategy, short_context, {}, rival_influence, rng)
		rivals.append({
			"id": str(peer.get("athlete_id", "rival-%d" % index)),
			"name": rival_athlete.display_name,
			"athlete": rival_athlete.to_dict(),
			"short_program": rival_short_program.to_dict(),
			"free_program": rival_free_program.to_dict(),
			"strategy": rival_strategy,
			"influence": rival_influence,
			"short": rival_short,
		})
	var provisional_rank := 1
	for rival in rivals:
		if float(rival.short.score.total) > float(player_short.score.total): provisional_rank += 1
	var short_for_options: Dictionary = player_short.performance.duplicate(true)
	short_for_options.provisional_rank = provisional_rank
	return _json_safe({
		"status": "awaiting_adjustment",
		"rules": {
			"short": InternalEventRules.for_teaching_group("short"),
			"free": InternalEventRules.for_teaching_group("free"),
		},
		"event_name": str(context.get("event_name", "俱乐部内部赛")),
		"season_start_year": int(context.get("season_start_year", career.clock.year)),
		"seed": seed,
		"rng_state": rng.state,
		"strategy": strategy.duplicate(true),
		"context": context.duplicate(true),
		"short_program": short_program.to_dict(),
		"free_program": free_program.to_dict(),
		"short": player_short,
		"provisional_rank": provisional_rank,
		"available_adjustments": BetweenSegmentAdjuster.options(short_for_options, free_program),
		"rivals": rivals,
	})

static func finish_event(career, saved_session: Dictionary, adjustment_id: String) -> Dictionary:
	var session: Dictionary = saved_session.duplicate(true)
	if str(session.get("status", "")) == "complete": return _json_safe(session)
	if not AthleteConditionService.can_compete(career): return {"status":"error", "errors":["伤病尚未恢复，暂不能参赛"]}
	var rng := RandomNumberGenerator.new()
	rng.state = int(session.get("rng_state", 1))
	var context: Dictionary = Dictionary(session.get("context", {})).duplicate(true)
	var reputation: Dictionary = Dictionary(context.get("reputation", {})).duplicate(true)
	var influence: Dictionary = Dictionary(context.get("influence", {})).duplicate(true)
	if not influence.has("event_scope"): influence.event_scope = "internal"
	var available: Array = session.get("available_adjustments", [])
	var chosen_id := adjustment_id if available.any(func(option): return str(option.get("id", "")) == adjustment_id) else "keep"
	var free_program = SkatingProgram.from_dict(session.free_program)
	var adjustment := BetweenSegmentAdjuster.apply(free_program, chosen_id)
	var free_strategy: Dictionary = Dictionary(session.get("strategy", {})).duplicate(true)
	for key in adjustment.strategy_overrides: free_strategy[key] = adjustment.strategy_overrides[key]
	var player_free_context := _segment_context(career, context, float(session.short.performance.fatigue_end))
	player_free_context.merge(AthleteConditionService.competition_context(career), true)
	player_free_context.pressure = float(player_free_context.pressure) + (4.0 if int(session.provisional_rank) >= 3 else 0.0)
	var player_free := _simulate_segment(career.athlete, adjustment.program, free_strategy, player_free_context, reputation, influence, rng)
	var player_total := snappedf(float(session.short.score.total) + float(player_free.score.total), 0.01)
	var standings: Array[Dictionary] = [{
		"id": "player", "name": career.athlete.display_name, "is_player": true,
		"short_total": float(session.short.score.total), "free_total": float(player_free.score.total), "total": player_total,
	}]
	var completed_rivals: Array[Dictionary] = []
	for rival_data in session.get("rivals", []):
		var rival: Dictionary = rival_data.duplicate(true)
		var athlete = AthleteState.from_dict(rival.athlete)
		var rival_free_program = SkatingProgram.from_dict(rival.free_program)
		var short_for_options: Dictionary = Dictionary(rival.short.performance).duplicate(true)
		short_for_options.provisional_rank = _rank_for_score(float(rival.short.score.total), session.short, session.rivals)
		var rival_option := _choose_rival_adjustment(BetweenSegmentAdjuster.options(short_for_options, rival_free_program), rival.short.performance)
		var rival_adjustment := BetweenSegmentAdjuster.apply(rival_free_program, rival_option)
		var rival_strategy: Dictionary = Dictionary(rival.strategy).duplicate(true)
		for key in rival_adjustment.strategy_overrides: rival_strategy[key] = rival_adjustment.strategy_overrides[key]
		var rival_context := _segment_context(career, context, float(rival.short.performance.fatigue_end))
		var rival_free := _simulate_segment(athlete, rival_adjustment.program, rival_strategy, rival_context, {}, rival.influence, rng)
		var rival_total := snappedf(float(rival.short.score.total) + float(rival_free.score.total), 0.01)
		rival.free = rival_free
		rival.adjustment_id = rival_option
		rival.total_score = rival_total
		completed_rivals.append(rival)
		standings.append({
			"id": str(rival.id), "name": str(rival.name), "is_player": false,
			"short_total": float(rival.short.score.total), "free_total": float(rival_free.score.total), "total": rival_total,
		})
	standings.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if not is_equal_approx(float(a.total), float(b.total)): return float(a.total) > float(b.total)
		return float(a.free_total) > float(b.free_total)
	)
	var public_rank := 1
	for index in standings.size():
		standings[index].rank = index + 1
		if standings[index].is_player: public_rank = index + 1
	var public_result := {"public_rank": public_rank, "total": player_total}
	session.status = "complete"
	session.rng_state = rng.state
	session.adjustment = {"id": chosen_id, "familiarity_cost": adjustment.familiarity_cost, "program": adjustment.program.to_dict(), "strategy_overrides": adjustment.strategy_overrides}
	session.free = player_free
	session.rivals = completed_rivals
	session.total_score = player_total
	session.public_rank = public_rank
	session.standings = standings
	session.club_decision = ClubDecisionSimulator.decide(public_result, Dictionary(context.get("club", {})).duplicate(true), career)
	return _json_safe(session)

static func simulate(career, short_program, free_program, strategy: Dictionary, adjustment_id: String, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var reputation: Dictionary = Dictionary(context.get("reputation", {})).duplicate(true)
	var influence: Dictionary = Dictionary(context.get("influence", {})).duplicate(true)
	if not influence.has("event_scope"): influence.event_scope = "internal"
	var short_context := {
		"event_scope":"internal",
		"season_start_year": int(context.get("season_start_year", career.clock.year)),
		"pressure": float(context.get("pressure", 30.0)),
	}
	short_context.segment_rules = InternalEventRules.for_season(int(short_context.season_start_year), "junior", "short")
	var short_performance := ProgramPerformanceSimulator.simulate(career.athlete, short_program, strategy, short_context, rng)
	var short_review := TechnicalPanelSimulator.resolve_performance(short_performance, reputation, influence, rng)
	var short_score := JudgingPanelSimulator.score(short_performance, short_review, _presentation_for(career.athlete, short_program, "short", {}, short_performance), reputation, influence, rng)
	_annotate_score(short_score,short_program,short_performance,short_review)
	var short_for_options: Dictionary = short_performance.duplicate(true)
	short_for_options.provisional_rank = int(context.get("provisional_rank", 1))
	var available_adjustments := BetweenSegmentAdjuster.options(short_for_options, free_program)
	var chosen_id := adjustment_id if available_adjustments.any(func(option): return option.id == adjustment_id) else "keep"
	var adjustment := BetweenSegmentAdjuster.apply(free_program, chosen_id)
	var free_strategy := strategy.duplicate(true)
	for key in adjustment.strategy_overrides: free_strategy[key] = adjustment.strategy_overrides[key]
	var free_context := {
		"event_scope":"internal",
		"season_start_year": short_context.season_start_year,
		"pressure": float(context.get("pressure", 30.0)) + (4.0 if int(context.get("provisional_rank", 1)) >= 3 else 0.0),
		"starting_fatigue": float(short_performance.fatigue_end),
	}
	free_context.segment_rules = InternalEventRules.for_season(int(short_context.season_start_year), "junior", "free")
	var free_performance := ProgramPerformanceSimulator.simulate(career.athlete, adjustment.program, free_strategy, free_context, rng)
	var free_review := TechnicalPanelSimulator.resolve_performance(free_performance, reputation, influence, rng)
	var free_score := JudgingPanelSimulator.score(free_performance, free_review, _presentation_for(career.athlete, adjustment.program, "free", {}, free_performance), reputation, influence, rng)
	_annotate_score(free_score,adjustment.program,free_performance,free_review)
	var total_score := snappedf(float(short_score.total) + float(free_score.total), 0.01)
	var public_result := {"public_rank": int(context.get("public_rank", context.get("provisional_rank", 1))), "total": total_score}
	var club_context: Dictionary = Dictionary(context.get("club", {})).duplicate(true)
	return {
		"event_name": str(context.get("event_name", "俱乐部内部赛")),
		"season_start_year": short_context.season_start_year,
		"short": {"performance": short_performance, "technical_review": short_review, "score": short_score},
		"available_adjustments": available_adjustments,
		"adjustment": {"id": chosen_id, "familiarity_cost": adjustment.familiarity_cost, "program": adjustment.program.to_dict(), "strategy_overrides": adjustment.strategy_overrides},
		"free": {"performance": free_performance, "technical_review": free_review, "score": free_score},
		"total_score": total_score,
		"public_rank": public_result.public_rank,
		"club_decision": ClubDecisionSimulator.decide(public_result, club_context, career),
	}

static func _presentation(career, program, segment: String) -> Dictionary:
	return _presentation_for(career.athlete, program, segment)

static func _presentation_for(athlete, program, segment: String, route_metrics: Dictionary = {}, performance: Dictionary = {}) -> Dictionary:
	var result: Dictionary = load("res://src/simulation/formal_segment_simulator.gd")._presentation(athlete, program, performance, {"actual_metrics":route_metrics})
	for key in result: result[key] = float(result[key])*10.0
	result.pcs_factor = 0.8 if segment == "short" else 1.6
	# Route quality is already included in the shared component model.
	result.route_metrics = {}
	return result

static func _simulate_segment(athlete, program, strategy: Dictionary, segment_context: Dictionary, reputation: Dictionary, influence: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var route_seed := int(rng.randi())
	var route_plan := CompetitionRoutePlanner.plan(athlete, program, {"complexity": program.route_complexity, "choreography_quality": program.choreography_quality}, route_seed)
	var performance_context := segment_context.duplicate(true)
	performance_context.event_scope = "internal"
	if not performance_context.has("segment_rules"):
		performance_context.segment_rules = InternalEventRules.for_season(int(segment_context.get("season_start_year", 2014)), "junior", program.segment)
	performance_context.entry_pressure_by_element = route_plan.entry_pressure_by_element
	var performance := ProgramPerformanceSimulator.simulate(athlete, program, strategy, performance_context, rng)
	var route_execution := CompetitionRouteExecutor.execute(route_plan, performance, athlete, {"starting_fatigue": float(segment_context.get("starting_fatigue", 0.0)), "familiarity": float(program.whole_run_familiarity)})
	var review := TechnicalPanelSimulator.resolve_performance(performance, reputation, influence, rng)
	var score := JudgingPanelSimulator.score(performance, review, _presentation_for(athlete, program, program.segment, route_execution.actual_metrics, performance), reputation, influence, rng)
	_annotate_score(score,program,performance,review)
	return {"performance": performance, "technical_review": review, "score": score, "route_plan": route_plan, "route_execution": route_execution}

static func _annotate_score(score: Dictionary, program, performance: Dictionary, review: Dictionary) -> void:
	var planned_by_id := {}; var actual_by_id := {}; var final_by_id := {}
	for element in program.elements: planned_by_id[element.element_id] = element.to_dict()
	for element in performance.get("elements",[]): actual_by_id[str(element.get("element_id",""))] = element
	for element in review.get("final_elements",[]): final_by_id[str(element.get("element_id",""))] = element
	for row in score.get("element_scores",[]):
		var element_id := str(row.get("element_id",""))
		var actual: Dictionary = actual_by_id.get(element_id,{})
		var final_call: Dictionary = final_by_id.get(element_id,{})
		row.planned_element = Dictionary(planned_by_id.get(element_id,{})).duplicate(true)
		row.actual_execution = {"abbreviation":str(actual.get("abbreviation","")),"parts":Array(actual.get("parts",[])).duplicate(true),"fall":bool(actual.get("actual",{}).get("fall",false))}
		row.recovery_decision = Dictionary(actual.get("recovery_decision",{})).duplicate(true)
		row.final_call = {"abbreviation":str(final_call.get("abbreviation","")),"info":Array(final_call.get("info",[])).duplicate(),"invalid_reason":str(final_call.get("invalid_reason",""))}

static func _segment_context(career, context: Dictionary, starting_fatigue: float) -> Dictionary:
	return {
		"season_start_year": int(context.get("season_start_year", career.clock.year)),
		"pressure": float(context.get("pressure", 30.0)),
		"starting_fatigue": starting_fatigue,
	}

static func _generate_rival(source, used_names: Array[String], rng: RandomNumberGenerator):
	var rival = AthleteState.from_dict(source.to_dict())
	var candidate := ""
	for attempt in 20:
		candidate = RIVAL_SURNAMES[rng.randi_range(0, RIVAL_SURNAMES.size() - 1)] + RIVAL_GIVEN_NAMES[rng.randi_range(0, RIVAL_GIVEN_NAMES.size() - 1)]
		if not used_names.has(candidate): break
	rival.display_name = candidate
	for key in rival.technique: rival.technique[key] = clampf(float(rival.technique[key]) + rng.randf_range(-12.0, 12.0), 5.0, 95.0)
	for key in rival.skating: rival.skating[key] = clampf(float(rival.skating[key]) + rng.randf_range(-14.0, 14.0), 5.0, 95.0)
	for jump_id in rival.jumps:
		var jump = rival.jumps[jump_id]
		for level in jump.proficiency: jump.proficiency[level] = clampf(float(jump.proficiency[level]) + rng.randf_range(-16.0, 16.0), 0.0, 95.0)
		for key in jump.air: jump.air[key] = clampf(float(jump.air[key]) + rng.randf_range(-12.0, 12.0), 0.0, 95.0)
		for key in jump.landing: jump.landing[key] = clampf(float(jump.landing[key]) + rng.randf_range(-12.0, 12.0), 0.0, 95.0)
	rival.body.acute_fatigue = rng.randf_range(6.0, 28.0)
	rival.mind.motivation = rng.randf_range(42.0, 82.0)
	return rival

static func _adapt_program(source, new_id: String, rng: RandomNumberGenerator):
	var program = SkatingProgram.from_dict(source.to_dict())
	program.program_id = new_id
	program.whole_run_familiarity = clampf(float(source.whole_run_familiarity) + rng.randf_range(-18.0, 14.0), 20.0, 92.0)
	for element in program.elements:
		program.slot_familiarity[element.element_id] = clampf(program.whole_run_familiarity + rng.randf_range(-10.0, 10.0), 10.0, 96.0)
	return program

static func _rank_for_score(score: float, player_short: Dictionary, rivals: Array) -> int:
	var rank := 1
	if float(player_short.score.total) > score: rank += 1
	for rival in rivals:
		if float(rival.short.score.total) > score: rank += 1
	return rank

static func _choose_rival_adjustment(options: Array, performance: Dictionary) -> String:
	if options.any(func(option): return option.id == "protect") and (int(performance.get("falls", 0)) > 0 or float(performance.get("fatigue_end", 0.0)) >= 50.0): return "protect"
	if options.any(func(option): return option.id == "chase"): return "chase"
	return "keep"

static func _json_safe(value: Dictionary) -> Dictionary:
	return JSON.parse_string(JSON.stringify(value))
