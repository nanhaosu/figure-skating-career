class_name JumpStageEvaluator
extends RefCounted

const ROTATION_KEYS := {1: "single", 2: "double", 3: "triple", 4: "quad"}
const STAGE_LABELS := {
	"untrained": "尚未正式训练", "attempting": "开始尝试", "first_success": "首次完成",
	"occasional": "偶尔成功", "training_stable": "训练中基本稳定",
	"internal_ready": "可加入内部赛", "official_ready": "正式比赛可用", "core": "核心动作",
}
const NEXT_STAGE := {
	"untrained": "attempting", "attempting": "first_success", "first_success": "occasional",
	"occasional": "training_stable", "training_stable": "internal_ready",
	"internal_ready": "official_ready", "official_ready": "core", "core": "",
}
const TRAINING_STABLE_SUCCESSES := 5
const TRAINING_STABLE_CLEAN_SUCCESSES := 1
const TRAINING_STABLE_SUCCESS_RATE := 0.05
const TRAINING_STABLE_PROFICIENCY := 7.0

static func evaluate(career, jump_id: String, rotations: int) -> Dictionary:
	if career == null or career.athlete == null or not career.athlete.jumps.has(jump_id):
		return _empty_result()
	return evaluate_profile(
		career.athlete.jumps[jump_id], rotations,
		career.athlete.body, career.athlete.jump_foundation.to_dict(),
		_recent_evidence(career,jump_id,rotations),
	)

static func _recent_evidence(career, jump_id: String, rotations: int) -> Dictionary:
	var codes := {"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz","axel":"A"}
	var item: Dictionary = career.technical_repertoire.entries.get("%d%s" % [rotations,codes[jump_id]],{})
	var rows: Array = item.get("evidence",[])
	if rows.is_empty(): return {}
	var window: int = load("res://src/content/repertoire_health_rules.gd").load_rules().evidence_window
	return load("res://src/simulation/repertoire_evaluator.gd")._window(rows,window,false)

static func evaluate_profile(profile, rotations: int, body: Dictionary, foundation: Dictionary = {}, recent: Dictionary = {}) -> Dictionary:
	if not ROTATION_KEYS.has(rotations): return _empty_result()
	var rotation_key: String = ROTATION_KEYS[rotations]
	var evidence: Dictionary = profile.attempt_evidence.get(rotation_key, {})
	var attempts := int(evidence.get("attempts", 0))
	var successes := int(evidence.get("successes", 0))
	var clean_successes := int(evidence.get("clean_successes", 0))
	var success_rate := float(successes) / float(maxi(attempts, 1))
	var proficiency := float(profile.proficiency.get(rotation_key, 0.0))
	var stage_id := "untrained"
	if attempts > 0: stage_id = "attempting"
	if successes > 0: stage_id = "first_success"
	if successes >= 3: stage_id = "occasional"
	if successes >= TRAINING_STABLE_SUCCESSES and clean_successes >= TRAINING_STABLE_CLEAN_SUCCESSES and success_rate >= TRAINING_STABLE_SUCCESS_RATE and proficiency >= TRAINING_STABLE_PROFICIENCY:
		stage_id = "training_stable"
	# Family-wide consistency may come from lower rotations. It cannot promote
	# a newly attempted 3A/quad without that rotation's own reliable evidence.
	var current: Dictionary = evidence if recent.is_empty() else recent
	var current_rate := float(current.get("successes",0))/float(maxi(1,int(current.get("attempts",0))))
	var enough_batches: bool = recent.is_empty() or int(recent.get("batches",0)) >= 3
	var execution_ready: bool = enough_batches and int(current.get("attempts",0)) >= 20 and int(current.get("clean_successes",0)) >= 3 and current_rate >= 0.45 and proficiency >= 25.0
	if stage_id == "training_stable" and execution_ready and float(profile.consistency.get("internal", 0.0)) >= 45.0:
		stage_id = "internal_ready"
	if ["training_stable", "internal_ready"].has(stage_id) and execution_ready and proficiency >= 40.0 and float(profile.consistency.get("official", 0.0)) >= 45.0:
		stage_id = "official_ready"
	if stage_id == "official_ready" and float(profile.consistency.get("official", 0.0)) >= 70.0 and proficiency >= 55.0:
		stage_id = "core"
	var gaps: Array[String] = _gaps(stage_id, rotations, body, foundation, profile, attempts, successes, clean_successes, success_rate)
	var success_max := _success_max(proficiency, float(profile.consistency.get("training", 0.0)), body)
	var label: String = STAGE_LABELS[stage_id]
	if stage_id == "training_stable" and not execution_ready: label = "已形成训练基础，仍需巩固"
	return {
		"stage_id": stage_id, "stage_label": label,
		"next_stage_id": NEXT_STAGE[stage_id], "gaps": gaps,
		"evidence": {"attempts": attempts, "successes": successes, "clean_successes": clean_successes, "success_rate": success_rate,"recent_success_rate":current_rate},
		"success_range": {"min": int(round(maxf(1.0, success_max - 24.0))), "max": int(round(success_max))},
	}

static func _gaps(stage_id: String, rotations: int, body: Dictionary, foundation: Dictionary, profile, attempts: int, successes: int, clean_successes: int, success_rate: float) -> Array[String]:
	var gaps: Array[String] = []
	if attempts == 0: gaps.append("needs_attempts")
	elif successes == 0: gaps.append("needs_first_success")
	elif successes < 3: gaps.append("insufficient_recent_successes")
	elif successes < TRAINING_STABLE_SUCCESSES or success_rate < TRAINING_STABLE_SUCCESS_RATE: gaps.append("insufficient_recent_successes")
	if successes >= 3 and clean_successes < TRAINING_STABLE_CLEAN_SUCCESSES: gaps.append("insufficient_clean_successes")
	var physical_readiness := (float(body.get("strength_readiness", 25.0)) + float(body.get("joint_readiness", 35.0))) / 2.0
	if physical_readiness < rotations * 18.0: gaps.append("physical_readiness_low")
	var landing_control := maxf(float(profile.landing.get("control", 0.0)), float(foundation.get("landing_control", 0.0)))
	if landing_control < rotations * 10.0: gaps.append("landing_control_low")
	if stage_id == "training_stable": gaps.append("needs_internal_evidence")
	elif stage_id == "internal_ready": gaps.append("needs_official_evidence")
	return gaps

static func _success_max(proficiency: float, training_consistency: float, body: Dictionary) -> float:
	var fatigue_penalty := float(body.get("acute_fatigue", 0.0)) * 0.32 + float(body.get("cumulative_fatigue", 0.0)) * 0.18 + float(body.get("ankle_load", 0.0)) * 0.08 + float(body.get("impact_load", 0.0)) * 0.05
	return clampf(15.0 + proficiency * 1.7 + training_consistency * 0.25 - fatigue_penalty, 2.0, 97.0)

static func _empty_result() -> Dictionary:
	return {"stage_id": "untrained", "stage_label": STAGE_LABELS.untrained, "next_stage_id": "attempting", "gaps": ["needs_attempts"], "evidence": {}, "success_range": {"min": 1, "max": 2}}
