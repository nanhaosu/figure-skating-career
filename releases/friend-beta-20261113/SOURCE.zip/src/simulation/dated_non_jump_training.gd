class_name DatedNonJumpTraining
extends RefCounted

const Plan = preload("res://src/domain/training_plan.gd")
const Condition = preload("res://src/simulation/athlete_condition_service.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Rehearsal = preload("res://src/simulation/program_training_simulator.gd")
const BASE_GROWTH := 1.2

# Input is the already resource/condition-adjusted actual daily category dose.
# No time, injury roll, certification or quarterly growth is awarded here.
static func execute(career,plan,volume: Dictionary,rng: RandomNumberGenerator) -> Dictionary:
	var result := {"errors":[],"outcomes":[],"actual_category_volumes":{}}
	if career == null or plan == null or rng == null or not volume.get("category_volumes") is Dictionary: return _failure("非跳跃训练剂量无效")
	for category in volume.category_volumes:
		var amount = volume.category_volumes[category]
		if not Plan.CATEGORY_IDS.has(category) or not _amount(amount): return _failure("非跳跃训练类别或剂量无效")
		if float(amount) > 0.0 and int(plan.shares.get(category,0)) <= 0: return _failure("训练剂量不属于已执行计划")
	if not Condition.can_train(career,plan): return result
	var motivation := 0.8 if float(career.athlete.mind.motivation) < 35.0 else 1.0
	for category in ["skating_foundation","rotation","conditioning","program_short","program_free"]:
		var amount := float(volume.category_volumes.get(category,0.0))
		if amount <= 0.0: continue
		var quality := float(plan.lesson_quality.get(category,1.0))
		if category.begins_with("program_"):
			var segment: String = category.trim_prefix("program_")
			var program = Program.from_dict(career.active_programs.get(segment,{}))
			if program == null: continue
			result.actual_category_volumes[category] = amount
			var connections := clampf(float(plan.focus_lessons.get("connections_"+segment,0.0))/maxf(1.0,float(plan.shares.get(category,0))),0.0,1.0)
			result.outcomes.append_array(Rehearsal.apply(program,amount*quality,career.athlete,connections,true))
			career.active_programs[segment] = program.to_dict()
			continue
		result.actual_category_volumes[category] = amount
		var growth := BASE_GROWTH*(amount/float(Plan.SHARE_STEP))*motivation*rng.randf_range(0.9,1.1)
		if category == "skating_foundation" and plan.expression_share > 0:
			var portion := clampf(float(plan.expression_share)/maxf(1.0,float(plan.shares.skating_foundation)),0.0,1.0)
			var before := float(career.athlete.mind.expression)
			career.athlete.mind.expression = minf(100.0,before+growth*portion*maxf(0.0,1.0-before/120.0)*float(plan.lesson_quality.get("expression",1.0)))
			_record(result,"musical_expression","expression",float(career.athlete.mind.expression)-before)
			growth *= 1.0-portion
		growth *= quality
		if category == "skating_foundation":
			var steps := clampf(float(plan.focus_lessons.get("steps",0.0))/maxf(1.0,float(plan.shares.skating_foundation)-float(plan.expression_share)),0.0,1.0)
			var before := float(career.athlete.skating.turns)
			career.athlete.skating.turns = minf(100.0,before+growth*steps)
			_record(result,category,"turns",float(career.athlete.skating.turns)-before)
			growth *= 1.0-steps
		var target := "deep_edge" if category == "skating_foundation" else ("rotation" if category == "rotation" else "recovery_capacity")
		var state: Dictionary = career.athlete.skating if category == "skating_foundation" else (career.athlete.technique if category == "rotation" else career.athlete.body)
		var before := float(state.get(target,0.0))
		state[target] = clampf(before+growth,0.0,100.0)
		_record(result,category,target,float(state[target])-before)
		if category == "rotation":
			for metric in career.athlete.spin_foundation:
				before = float(career.athlete.spin_foundation[metric])
				career.athlete.spin_foundation[metric] = minf(100.0,before+growth*(1.1 if metric == "flexibility" else 1.6)*maxf(0.0,1.0-before/110.0))
			for spin_id in career.athlete.spins:
				if not preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,{"kind":"spin","flying":str(spin_id) == "flying"}).allowed: continue
				var spin: Dictionary = career.athlete.spins[spin_id]
				before = float(spin.proficiency)
				spin.proficiency = minf(100.0,before+growth*1.8*maxf(0.0,1.0-before/110.0))
				spin.training_consistency = minf(100.0,float(spin.training_consistency)+growth*1.3)
				spin.level_features = clampi(int(float(spin.proficiency)/16.0),0,4)
		var related := {}
		var adaptation := 1.0
		if category == "skating_foundation": related = {"one_foot_stability":0.85,"knee_action":0.8,"ice_efficiency":0.75,"flow":0.7,"speed":0.6,"turns":0.55}
		elif category == "conditioning":
			related = {"strength_readiness":0.75,"joint_readiness":0.45}
			var age: int = career.clock.age_on(career.athlete.birth_year)
			adaptation = (0.75 if age <= 10 else 1.0)*clampf(1.0-float(career.athlete.body.impact_load)/200.0,0.5,1.0)*clampf(float(plan.shares.rest)/25.0,0.2,1.0)
		for metric in related:
			before = float(state[metric])
			state[metric] = minf(95.0,before+growth*float(related[metric])*adaptation*maxf(0.0,1.0-before/100.0)) if before < 95.0 else before
			_record(result,category,metric,float(state[metric])-before)
	return result

static func _amount(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0 and float(value) <= 1000000

static func _record(result: Dictionary,category: String,target: String,change: float) -> void:
	result.outcomes.append({"category":category,"target":target,"delta":change,"cause_codes":["actual_dated_practice"],"summary_key":"training_growth"})

static func _failure(message: String) -> Dictionary:
	return {"errors":[message],"outcomes":[],"actual_category_volumes":{}}
