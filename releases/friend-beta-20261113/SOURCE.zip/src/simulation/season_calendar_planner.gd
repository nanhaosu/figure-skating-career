class_name SeasonCalendarPlanner
extends RefCounted

const SeasonEntryPlan = preload("res://src/domain/season_entry_plan.gd")
const EventEligibilityEvaluator = preload("res://src/simulation/event_eligibility_evaluator.gd")
const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const HistoricalRuleRepository = preload("res://src/content/historical_rule_repository.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const CLUB_FINAL_FORMULA := "游戏俱乐部总决赛资格：本季规范赛历中开放的全部分站完赛后，按每站国内名次积分合计取前六；同分比较最佳名次、最佳总分，再按运动员ID排序。重复档案只计一次。"

static func propose(career, calendar: Dictionary, rules: Dictionary) -> Dictionary:
	var entries := {}
	var qualification_state := qualification_state_for(career)
	for event in SeasonCalendarRepository.playable_events(calendar):
		var requested_levels: Array[String] = []
		var offered_levels := Array(event.get("level_options", []))
		requested_levels.append("junior" if offered_levels.has("junior") else str(offered_levels[0]))
		var eligibility := EventEligibilityEvaluator.evaluate(career.athlete, event, int(event.get("ruleset_season_start_year", career.clock.season_start_year())), requested_levels, qualification_state, rules)
		var routes: Array = []
		var delegated: bool = str(event.get("scope","")) == "international" or event.get("event_id") == "cn_milano_qualifier_trials_2025"
		if delegated:
			routes = load("res://src/simulation/entry_application_service.gd").options(career,event,{"rules":rules})
			eligibility = routes[0].eligibility
		var route := str(event.get("entry_route", "club_nomination"))
		var reason_codes: Array[String] = ["development_value"]
		var recommendation := "建议参赛：积累完整比赛经验"
		if float(career.athlete.resources.money) < 25.0 or float(career.athlete.body.recovery_capacity) < 30.0:
			reason_codes.append("resource_caution")
			recommendation = "可以参赛，但需控制费用与恢复负担"
		var adjustment_ids: Array[String] = ["skip"]
		if eligibility.eligible:
			adjustment_ids.push_front("self_fund_enter" if route == "open_self_funded" else "enter")
		entries[event.event_id] = {
			"status": "blocked" if not eligibility.eligible else ("proposed" if int(event.get("sequence", 0)) <= 2 else "optional"),
			"requested_levels": requested_levels,
			"route": route,
			"funding_source": "self" if route == "open_self_funded" else "club",
			"coach_recommendation": recommendation,
			"player_override": "",
			"available_adjustment_ids": adjustment_ids,
			"eligibility_snapshot": eligibility,
			"reason_codes": reason_codes,
		}
		if delegated:
			# Reuse this event's just-computed preview, not a second identical
			# full-field qualification pass. Detached copy keeps editing isolated;
			# no result survives this proposal or replaces next-call revalidation.
			entries[event.event_id]["route_options"] = routes.duplicate(true)
	return SeasonEntryPlan.create(str(calendar.get("season_id", "")), entries, 1)

static func refresh_entry_eligibility(career, calendar: Dictionary, rules: Dictionary, previous_plan, event_id: String) -> Dictionary:
	var previous = _as_plan(previous_plan)
	if previous == null: return {"plan":null,"errors":["赛季报名计划无效"]}
	if previous.season_id != str(calendar.get("season_id","")): return {"plan":null,"errors":["报名计划不属于当前赛季"]}
	var events: Array = calendar.get("events",[]).filter(func(event):return event.get("event_id") == event_id)
	if events.size() != 1: return {"plan":null,"errors":["找不到唯一规范赛事："+event_id]}
	var scoped: Dictionary = calendar.duplicate(false)
	scoped.events = events
	var refreshed := refresh_eligibility(career,scoped,rules,previous)
	if not refreshed.errors.is_empty(): return refreshed
	if not refreshed.plan.entries.has(event_id): return {"plan":null,"errors":["该赛事当前不可报名"]}
	var entries: Dictionary = previous.entries.duplicate(true)
	entries[event_id] = refreshed.plan.entries[event_id].duplicate(true)
	return SeasonEntryPlan.create(previous.season_id,entries,refreshed.plan.proposal_version)

static func available_adjustments(_career, proposal, event_id: String) -> Array[Dictionary]:
	var plan = _as_plan(proposal)
	if plan == null or not plan.entries.has(event_id): return []
	if plan.entries[event_id].has("route_options"):
		var choices: Array[Dictionary] = []
		choices.assign(plan.entries[event_id].route_options)
		return choices
	var result: Array[Dictionary] = []
	for adjustment_id in plan.entries[event_id].available_adjustment_ids:
		match str(adjustment_id):
			"enter": result.append({"id":"enter", "label":"按教练建议报名"})
			"self_fund_enter": result.append({"id":"self_fund_enter", "label":"自费报名"})
			"skip": result.append({"id":"skip", "label":"本次不参加"})
	return result

static func apply_adjustment(_career, proposal, event_id: String, adjustment_id: String) -> Dictionary:
	var plan = _as_plan(proposal)
	if plan == null or not plan.entries.has(event_id): return {"plan": null, "errors":["找不到赛事：%s" % event_id]}
	var data: Dictionary = plan.to_dict()
	var entry: Dictionary = data.entries[event_id]
	if not Array(entry.available_adjustment_ids).has(adjustment_id): return {"plan": null, "errors":["该赛事不允许此调整：%s" % adjustment_id]}
	entry.player_override = adjustment_id
	entry.status = "declined" if adjustment_id == "skip" else "confirmed"
	return SeasonEntryPlan.create(plan.season_id, data.entries, plan.proposal_version)

static func refresh_eligibility(career, calendar: Dictionary, rules: Dictionary, previous_plan) -> Dictionary:
	var previous = _as_plan(previous_plan)
	if previous == null: return {"plan":null, "errors":["赛季报名计划无效"]}
	var fresh := propose(career, calendar, rules)
	if not fresh.errors.is_empty(): return fresh
	var entries: Dictionary = fresh.plan.entries.duplicate(true)
	for event_id in entries:
		if not previous.entries.has(event_id): continue
		var old: Dictionary = previous.entries[event_id]
		var current: Dictionary = entries[event_id]
		var old_choice := str(old.get("player_override", ""))
		if old.get("status") == "confirmed" and ["enter","self_fund_enter"].has(old_choice):
			# Keep the eligibility snapshot that authorized this accepted decision.
			# Current medical/program legality is checked again at the stop node.
			entries[event_id] = old.duplicate(true)
			continue
		if old_choice == "skip" and not _implicit_unoffered_decline(career,event_id,old,calendar):
			current.player_override = "skip"
			current.status = "declined"
		elif bool(current.eligibility_snapshot.eligible) and ["enter", "self_fund_enter"].has(old_choice):
			current.player_override = old_choice
			current.status = "confirmed"
		current.funding_source = str(old.get("funding_source", current.funding_source))
	return SeasonEntryPlan.create(previous.season_id, entries, previous.proposal_version + 1)

static func _implicit_unoffered_decline(career, event_id: String, old: Dictionary, calendar: Dictionary) -> bool:
	# Repair only the old disabled-checkbox batch bug, not genuine declines or
	# past world-only results. Never manufacture a missed competition result.
	if not bool(career.season_state.get("domestic_schedule_selected",false)) or old.get("status") != "declined": return false
	if bool(old.get("eligibility_snapshot",{}).get("eligible",true)): return false
	if career.selection_state.applications.values().any(func(record): return record.get("event_id") == event_id and record.get("route_id") in ["skip","withdraw"]): return false
	if career.competition_archive.any(func(archive): return archive.get("event_id") == event_id): return false
	var events: Array = calendar.get("events",[]).filter(func(event): return event.get("event_id") == event_id and event.get("scope") == "domestic")
	if events.is_empty(): return false
	var current_month := "%04d-%02d" % [career.clock.year,(career.clock.quarter-1)*3+1]
	return str(events[0].get("application_deadline",events[0].get("start_date",""))).left(7) >= current_month

static func needs_unoffered_decline_repair(career, calendar: Dictionary, previous_plan: Dictionary) -> bool:
	for event_id in previous_plan.get("entries",{}):
		var old: Dictionary = previous_plan.entries[event_id]
		if old.get("player_override") == "skip" and _implicit_unoffered_decline(career,event_id,old,calendar): return true
	return false

static func _as_plan(value):
	if value is SeasonEntryPlan: return value
	if value is Dictionary: return SeasonEntryPlan.from_dict(value)
	return null

static func qualification_state_for(career) -> Dictionary:
	var grade := int(career.certification_state.get("national_technical_grade", 0))
	var qualifications := {"cfsa_registered":true, "registered":true, "club_nomination":true, "club_final_top_six":false, "national_technical_minimum":grade >= 7, "program_legal":junior_programs_legal(career)}
	qualifications.club_final_top_six = Array(club_league_standings(career).qualified_ids).has("player")
	qualifications.federation_assignment = not Array(career.selection_state.assignments.get("player",[])).is_empty()
	qualifications.jgp_final_qualified = Array(career.selection_state.get("jgp",{}).get("qualified_ids",[])).has("player")
	qualifications.federation_world_junior_selection = Array(career.selection_state.assignments.get("player",[])).has("isu_world_junior_%d" % (load("res://src/content/season_bundle_repository.gd").season_year(career)+1))
	qualifications.jgp_selection_decided = career.selection_state.get("decisions",{}).has("jgp")
	qualifications.world_selection_decided = career.selection_state.get("decisions",{}).has("world_junior")
	qualifications.scored_evidence_available = not career.competition_archive.is_empty()
	return qualifications

static func club_league_standings(career) -> Dictionary:
	var year: int = load("res://src/content/season_bundle_repository.gd").season_year(career)
	var season_id := "%d-%02d" % [year,(year+1)%100]
	var events := {}; var athletes := {}
	var calendar := SeasonCalendarRepository.load_calendar(year,"CHN","women_singles")
	var stage_ids: Array = []
	if calendar.errors.is_empty():
		for event in SeasonCalendarRepository.playable_events(calendar.calendar):
			if event.get("event_family") == "club_league_stage": stage_ids.append(str(event.event_id))
	var points: Array = load("res://src/simulation/formal_competition_consequence_service.gd").POINTS
	for archive in career.competition_archive:
		var id := str(archive.get("event_id",""))
		if archive.get("season_id") != season_id or archive.get("status") != "complete" or events.has(id): continue
		if not stage_ids.has(id): continue
		events[id] = true
		var seen := {}
		for result in archive.get("final_standings",[]):
			var athlete_id := str(result.get("athlete_id","")); var rank := int(result.get("rank",0))
			if athlete_id.is_empty() or rank < 1 or seen.has(athlete_id): continue
			seen[athlete_id] = true
			if not athletes.has(athlete_id): athletes[athlete_id] = {"athlete_id":athlete_id,"name":str(result.get("name",athlete_id)),"points":0,"best_rank":rank,"best_total":0.0,"event_ids":[]}
			var row: Dictionary = athletes[athlete_id]
			row.points += int(points[rank-1]) if rank <= points.size() else 0
			row.best_rank = mini(row.best_rank,rank)
			# Canonical two-decimal scores preserve exact audit replay through JSON.
			row.best_total = float("%.2f" % maxf(row.best_total,float(result.get("total_score",0))))
			row.event_ids.append(id)
	var standings: Array = athletes.values()
	standings.sort_custom(func(a,b):
		if a.points != b.points: return a.points > b.points
		if a.best_rank != b.best_rank: return a.best_rank < b.best_rank
		if a.best_total != b.best_total: return a.best_total > b.best_total
		return str(a.athlete_id) < str(b.athlete_id))
	var qualified: Array = []
	if not stage_ids.is_empty() and events.size() == stage_ids.size():
		for row in standings.slice(0,6): qualified.append(row.athlete_id)
	return {"season_id":season_id,"public_formula":CLUB_FINAL_FORMULA,"completed_event_ids":events.keys(),"standings":standings,"qualified_ids":qualified}

static func junior_programs_legal(career) -> bool:
	var loaded := HistoricalRuleRepository.load_season(load("res://src/content/season_bundle_repository.gd").season_year(career), "women_singles")
	if not loaded.errors.is_empty(): return false
	for segment in ["short", "free"]:
		var saved: Dictionary = Dictionary(career.active_programs.get(segment, {}))
		if saved.is_empty(): return false
		var program = SkatingProgram.from_dict(saved)
		var rules := HistoricalRuleRepository.rules_for(loaded.rules, "junior", segment)
		if not ProgramValidator.validate(program, career.athlete, rules).is_empty(): return false
	return true
