class_name ProgramFallbackService
extends RefCounted
const Program = preload("res://src/domain/skating_program.gd")
const Functions = preload("res://src/simulation/athlete_function_service.gd")
const Validator = preload("res://src/simulation/program_validator.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const SeasonPrograms = preload("res://src/simulation/season_program_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")

static func propose(career, programs: Dictionary, rules: Dictionary, event: Dictionary = {}) -> Dictionary:
	var result := {"programs":programs.duplicate(true),"rules":rules.duplicate(true),"source_hash":_hash(career.active_programs),"changed":false,"legal":true,"reasons":[],"withdrawal_available":true}
	if not event.is_empty():
		var resolved := Bundle.competition_for_career(career,event)
		if not resolved.errors.is_empty():
			result.legal = false
			result.reasons = resolved.errors
			return result
		result.event = resolved.event
		result.source_hash = _hash(SeasonPrograms.programs_for_event(career,resolved.event))
	for segment in programs:
		var program = Program.from_dict(programs[segment])
		if program == null: result.legal = false; result.reasons.append("节目不存在"); continue
		if _allowed(career,program): continue
		result.changed = true
		result.reasons.append("%s存在暂不可用动作；替代方案需整套核验重复及组别规则" % ("短节目" if segment == "short" else "自由滑"))
		for element in program.elements:
			if element.kind != "jump": continue
			while not _element_allowed(career,element) and element.rotations > 1: element.rotations -= 1
			for index in element.combination_parts.size():
				while not _element_allowed(career,element) and int(element.combination_parts[index].rotations) > 1: element.combination_parts[index].rotations = int(element.combination_parts[index].rotations)-1
		var segment_rules: Dictionary = rules.get(segment,{})
		if not _allowed(career,program) or not Validator.validate(program,career.athlete,segment_rules).is_empty():
			# A naive downgrade can produce repeated 2T. Rebuild a candidate under
			# the same full rules, never silently approve the invalid replacement.
			var athlete = preload("res://src/domain/athlete_state.gd").from_dict(career.athlete.to_dict())
			for jump_id in athlete.jumps:
				var maximum := int(athlete.jumps[jump_id].unlocked_rotations)
				while maximum > 0:
					var action := {"kind":"jump","parts":[{"jump_id":jump_id,"rotations":maximum}]}
					var id := preload("res://src/domain/technical_repertoire.gd").action_id(action)
					if Functions.action_constraints(career,action).allowed and career.technical_repertoire.entries.get(id,{}).get("state","") != "unavailable": break
					maximum -= 1
				athlete.jumps[jump_id].unlocked_rotations = maximum
			var generated := Draft.legal_draft(athlete,segment,segment_rules,program.music,career.seed)
			program = generated.program
		if program == null or not _allowed(career,program) or not Validator.validate(program,career.athlete,segment_rules).is_empty():
			result.legal = false
			result.reasons.append("当前身体或储备不足以组成合法节目，可以退赛并继续恢复。")
		else: result.programs[segment] = program.to_dict()
	return result

static func confirm(career, proposal: Dictionary, receipt_id: String) -> Dictionary:
	if receipt_id.is_empty() or not proposal.get("programs") is Dictionary or not proposal.get("rules") is Dictionary: return {"ok":false,"error":"替代方案格式无效"}
	var event: Dictionary = {}
	var originals: Dictionary = career.active_programs
	if proposal.has("event"):
		if not proposal.event is Dictionary: return {"ok":false,"error":"替代方案赛事无效"}
		var resolved := Bundle.competition_for_career(career,proposal.event)
		if not resolved.errors.is_empty(): return {"ok":false,"error":"；".join(resolved.errors)}
		event = resolved.event
		originals = SeasonPrograms.programs_for_event(career,event)
		for segment in proposal.programs:
			if segment not in ["short","free"] or _hash(proposal.rules.get(segment,{})) != _hash(resolved.rules[segment].segment_rules):
				return {"ok":false,"error":"替代方案与本场组别规则不符"}
	var receipts: Dictionary = career.season_program_plan.get("replacement_receipts",{})
	var fingerprint := _hash(proposal.programs) if event.is_empty() else _hash({"event_id":event.event_id,"level":event.competition_level,"programs":proposal.programs})
	if receipts.has(receipt_id): return {"ok":receipts[receipt_id] == fingerprint,"error":"确认凭据与替代方案不符" if receipts[receipt_id] != fingerprint else ""}
	if proposal.get("source_hash","") != _hash(originals): return {"ok":false,"error":"原节目已经变化，请重新查看替代建议"}
	for segment in proposal.programs:
		var program = Program.from_dict(proposal.programs[segment])
		if program == null or not _allowed(career,program) or not Validator.validate(program,career.athlete,proposal.rules.get(segment,{})).is_empty(): return {"ok":false,"error":"替代方案未通过整套规则与身体检查"}
	for segment in proposal.programs:
		var old = Program.from_dict(originals.get(segment,{}))
		var edited = Program.from_dict(proposal.programs[segment])
		var revised := Draft.save_draft(old,edited)
		if not revised.errors.is_empty(): return {"ok":false,"error":"；".join(revised.errors)}
		var locked := Draft.lock_for_competition(revised.program,career.athlete,proposal.rules[segment])
		if not locked.errors.is_empty(): return {"ok":false,"error":"；".join(locked.errors)}
		if event.is_empty(): career.active_programs[segment] = locked.program.to_dict()
		else:
			var stored := SeasonPrograms.store_event_program(career,event,segment,locked.program.to_dict())
			if not stored.ok: return stored
		if revised.archived != null: career.program_archive.append(revised.archived.to_dict())
	receipts[receipt_id] = fingerprint
	while receipts.size() > 16: receipts.erase(receipts.keys()[0])
	career.season_program_plan.replacement_receipts = receipts
	career.season_program_plan.programs = career.active_programs.duplicate(true)
	return {"ok":true,"events":[]}

static func _allowed(career, program) -> bool:
	for element in program.elements:
		if not _element_allowed(career,element): return false
	return true
static func _element_allowed(career, element) -> bool:
	var action: Dictionary = element.to_dict()
	if element.kind == "jump":
		action = {"kind":"jump","parts":[{"jump_id":element.jump_id,"rotations":element.rotations}]}
		action.parts.append_array(element.combination_parts)
		var id := preload("res://src/domain/technical_repertoire.gd").action_id(action)
		if career.technical_repertoire.entries.get(id,{}).get("state","") == "unavailable": return false
	return Functions.action_constraints(career,action).allowed
static func _hash(value: Dictionary) -> String:
	return JSON.stringify(preload("res://src/persistence/numeric_state.gd").canonical_copy(value)).sha256_text()
