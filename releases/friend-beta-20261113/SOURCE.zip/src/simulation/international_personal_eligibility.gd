class_name InternationalPersonalEligibility
extends RefCounted

const Identity = preload("res://src/domain/athlete_identity.gd")
const Calendar = preload("res://src/content/season_calendar_repository.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const BeijingPolicy = preload("res://src/content/beijing_qualification_policy.gd")
const JUNIOR_POLICY := "res://data/qualification/world_junior_2022_game_policy.json"

# Personal requirements only. A passing result does not allocate a country
# quota, invite an athlete, or supersede the domestic selection result.
static func policy_for(event: Dictionary) -> Dictionary:
	match str(event.get("event_id","")):
		"isu_wc2024":
			return {"policy_id":"worlds2024_women_tes","event_id":"isu_wc2024","season_start_year":2023,"earned_level":"senior","record_scope":"isu_recognized","minimum_tes":{"short":32,"free":53},"valid_season_start_years":[2022,2023],"minimum_age":16,"maximum_age":1000,"cutoff":"2024-02-26","label":"蒙特利尔世锦赛：认可成年国际赛短节目 TES 32、自由滑 TES 53，截止 2024-02-26。"}
		"isu_wc2025":
			return {"policy_id":"worlds2025_women_2657","event_id":"isu_wc2025","season_start_year":2024,"earned_level":"senior","record_scope":"isu_recognized","minimum_tes":{"short":0,"free":0},"minimum_combined_tes":90.0,"valid_season_start_years":[2023,2024],"minimum_age":17,"maximum_age":1000,"cutoff":"2025-02-25","source":"https://www.faeg.ad/img/web/2657-Entries-ISU-FS-SYS-Championships-2025.pdf","label":"ISU 2657：成年女单最高短节目与自由滑 TES 合计至少 90，截止 2025-02-25。"}
		"isu_owg2026":
			return {"policy_id":"milano2026_women_2741","event_id":"isu_owg2026","season_start_year":2025,"earned_level":"senior","record_scope":"isu_recognized","minimum_tes":{"short":0,"free":0},"minimum_combined_tes":75.0,"valid_season_start_years":[2024,2025],"minimum_age":17,"maximum_age":1000,"cutoff":"2026-01-26","source":"https://isu-d8g8b4b7ece7aphs.a03.azurefd.net/isudamcontainer/CMS/Corporate-Site/Governance/Transparency/ISU-Communications/2741-OWG-Figure-Skating-Qualification-Competition-and-Judges-Draw-Beijing-1758706754-2014.pdf","label":"米兰冬奥会：成年女单最高短节目与自由滑 TES 合计至少 75，截止 2026-01-26。"}
		"isu_fc2022", "isu_wc2022":
			var worlds := str(event.event_id) == "isu_wc2022"
			return {"policy_id":"%s_women_adopted2395" % event.event_id,"event_id":event.event_id,"season_start_year":2021,"earned_level":"senior","record_scope":"isu_recognized","minimum_tes":{"short":30 if worlds else 23,"free":51 if worlds else 40},"valid_season_start_years":[2019,2020,2021],"minimum_age":15,"maximum_age":1000,"cutoff":"2022-02-28" if worlds else "2021-12-28","first_official_practice":"2022-03-21" if worlds else "2022-01-18","practice_source":"https://usfigureskating.org/news/2022/3/21/figure-skating-team-usa-ready-for-world-championships-in-france.aspx" if worlds else "https://results.isu.org/schedules/FC2022_ColouredTimeSchedule.pdf","source_id":"isu2395_20210607","final_revision_status":"unverified","label":"采用已核实ISU2395版本，最终修订未核实：仅认可2019/20至2021/22成年国际TES，两段可分开取得；截止为首个官方训练日前21天。个人达标不等于获得国家名额或派遣。"}
		"isu_wc2021":
			return {"policy_id":"worlds2021_women_2370","event_id":"isu_wc2021","season_start_year":2020,"earned_level":"senior","allowed_earned_levels":["junior","senior"],"record_scope":"isu_recognized","minimum_tes":{"short":30,"free":51},"valid_season_start_years":[2018,2019,2020],"minimum_age":15,"maximum_age":1000,"cutoff":"2021-03-01","source_id":"isu2370","source":"https://ctsu.com.tw/wp-content/uploads/2021/02/2370-TES-video-evaluation-ISU-World-Championships-2021.pdf","label":"2021世锦赛2370特别规定：女单TES30/51，2018/19至2020/21认可青年或成年成绩可用，3月1日截止；青年成绩特例仅适用于本届，不转换为冬奥成年TES。"}
		"isu_owg2022":
			var loaded := BeijingPolicy.load_policy()
			if not loaded.errors.is_empty(): return {}
			var policy: Dictionary = loaded.policy.duplicate(true)
			policy.merge({"event_id":"isu_owg2022","season_start_year":2021,"minimum_age":15,"maximum_age":1000,"cutoff":"2022-01-24","cutoff_source":"https://www.sport.gov.cn/dyzx/n5169/c23811297/content.html"},true)
			return policy
		"isu_world_junior_2022":
			var data = JSON.parse_string(FileAccess.get_file_as_string(JUNIOR_POLICY))
			if not data is Dictionary: return {}
			var expected := {"policy_id":"world_junior2022_women_game_cutoff","event_id":"isu_world_junior_2022","season_start_year":2021,"earned_level":"junior","record_scope":"isu_recognized","minimum_tes":{"short":23,"free":38},"valid_season_start_years":[2019,2020,2021],"minimum_age":13,"maximum_age":18,"cutoff":"2022-03-23","cutoff_precision":"approved_game_date","final_historical_deadline":"unknown","source_id":"isu2395_20210607","user_approved":true,"approved_on":"2026-10-22"}
			for key in expected:
				if not _same_value(data.get(key),expected[key]): return {}
			if not "游戏截止日" in str(data.get("label","")): return {}
			for key in ["season_start_year","minimum_age","maximum_age","valid_season_start_years"]: data[key] = expected[key]
			return data.duplicate(true)
	return {}

static func evaluate(career, event: Dictionary, policy: Dictionary, athlete_id: String = "player") -> Dictionary:
	return _evaluate(career,event,policy,athlete_id,{"validated":{},"expanded":{},"calendars":{}})

static func evaluate_many(career, event: Dictionary, policy: Dictionary, athlete_ids: Array) -> Dictionary:
	# Call-local only: no caller-supplied trust flags, no persistent eligibility
	# cache. The next batch revalidates every archive, even for the same career.
	var context := {"validated":{},"expanded":{},"calendars":{}}
	var results := {}
	for athlete_id in athlete_ids:
		results[str(athlete_id)] = _evaluate(career,event,policy,str(athlete_id),context)
	return results

static func _evaluate(career, event: Dictionary, policy: Dictionary, athlete_id: String, context: Dictionary) -> Dictionary:
	var result := {"status":"unknown","eligible":false,"age":{},"tes":{"eligible":false,"segments":{}},"evidence":[],"reason_codes":[],"warnings":[]}
	var canonical_policy := policy_for(event)
	if canonical_policy.is_empty() or not _same_value(policy,canonical_policy):
		result.reason_codes = ["qualification_policy_unknown_or_mismatched"]
		return result
	var level := str(canonical_policy.earned_level)
	var year := int(canonical_policy.season_start_year)
	var calendars: Dictionary = context.calendars
	var target := _canonical_event(str(event.get("event_id","")),year,level,calendars)
	if target.is_empty() or not _matches_event(event,target,level):
		result.reason_codes = ["canonical_target_mismatch"]
		return result
	result.warnings.append(str(canonical_policy.label))
	var subject = career.athlete
	if athlete_id != "player":
		var record: Dictionary = career.world_athletes.get(athlete_id,{})
		subject = preload("res://src/domain/athlete_state.gd").from_dict(record.get("athlete",{}))
		if subject == null:
			result.reason_codes = ["athlete_identity_missing"]
			return result
		var text := str(record.get("birth_date",""))
		if not text.is_empty():
			if not _valid_date(text):
				result.age = {"status":"unknown","reason_codes":["invalid_birth_date"]}
				result.reason_codes = ["invalid_birth_date"]
				return result
			subject.birth_date = {"year":int(text.left(4)),"month":int(text.substr(5,2)),"day":int(text.right(2))}
	var date = subject.birth_date
	if date.is_empty(): date = subject.get_meta("birth_date",{})
	result.age = Identity.age_gate(subject.birth_year,date,year,int(canonical_policy.minimum_age),int(canonical_policy.maximum_age)) if date is Dictionary else {"status":"unknown","reason_codes":["invalid_birth_date"]}
	var cutoff := str(canonical_policy.cutoff)
	var quarter := int(career.clock.quarter)
	if quarter < 1 or quarter > 4:
		result.reason_codes = ["invalid_current_clock"]
		return result
	# Until dated progression is enabled, completed records may legitimately
	# fall anywhere in the current quarter, never in a later quarter.
	var latest := "%04d-%02d-%02d" % [career.clock.year,quarter*3,[31,30,30,31][quarter-1]]
	if career.competition_timeline.get("mode") == "dated": latest = str(career.competition_timeline.date)
	var evidence_incomplete := false
	for archive_index in career.competition_archive.size():
		var raw_archive = career.competition_archive[archive_index]
		if not raw_archive is Dictionary or raw_archive.get("status") != "complete" or (athlete_id == "player" and raw_archive.get("world_only",false)): continue
		if not context.validated.has(archive_index): context.validated[archive_index] = Codec.validate(raw_archive).is_empty()
		if not context.validated[archive_index]:
			evidence_incomplete = true
			continue
		if not raw_archive.get("short_results",{}) is Dictionary or not raw_archive.get("free_results",{}) is Dictionary:
			evidence_incomplete = true
			continue
		# The codec has already verified that this public index equals its
		# immutable payload. Reject non-provider events before inflating every
		# athlete's full performance, notably the five large domestic trials.
		var archived_event = raw_archive.get("event",{})
		if not archived_event is Dictionary or not _integer(archived_event.get("ruleset_season_start_year")):
			evidence_incomplete = true
			continue
		var earned_year := int(archived_event.ruleset_season_start_year)
		if not canonical_policy.valid_season_start_years.has(earned_year): continue
		var earned_level := str(archived_event.get("competition_level",level))
		if not canonical_policy.get("allowed_earned_levels",[level]).has(earned_level): continue
		var canonical := _canonical_event(str(raw_archive.get("event_id","")),earned_year,earned_level,calendars)
		if canonical.is_empty(): continue
		if not _matches_event(archived_event,canonical,earned_level):
			evidence_incomplete = true
			continue
		if not context.expanded.has(archive_index): context.expanded[archive_index] = _qualification_records(Codec.expand(raw_archive))
		var archive: Dictionary = context.expanded[archive_index]
		for segment in ["short","free"]:
			var performed := str(canonical.get("segment_dates",{}).get(segment,canonical.end_date))
			if not _valid_date(performed) or performed > cutoff or performed > latest: continue
			if performed < "%04d-07-01" % earned_year or performed >= "%04d-07-01" % (earned_year+1): continue
			var records = archive.get(segment+"_results",{})
			if not records is Dictionary: continue
			var record = records.get(athlete_id,{})
			if not record is Dictionary or record.is_empty(): continue
			if not _final_record(record):
				evidence_incomplete = true
				continue
			var score = record.get("score",record.get("protocol",{}))
			if not score is Dictionary or not _tes_number(score.get("tes")):
				evidence_incomplete = true
				continue
			if record.get("protocol") is Dictionary and record.protocol.has("tes") and record.protocol.tes != score.tes:
				evidence_incomplete = true
				continue
			var threshold := float(canonical_policy.minimum_tes[segment])
			if float(score.tes) < threshold: continue
			var receipt := {"event_id":canonical.event_id,"segment":segment,"tes":float(score.tes),"threshold":threshold,"performed_on":performed,"season_start_year":earned_year,"level":earned_level,"record_eligibility":"isu_recognized"}
			var prior: Dictionary = result.tes.segments.get(segment,{})
			if prior.is_empty() or float(receipt.tes) > float(prior.tes): result.tes.segments[segment] = receipt
	result.tes.eligible = result.tes.segments.size() == 2
	if result.tes.eligible and canonical_policy.has("minimum_combined_tes"):
		result.tes.combined = float(result.tes.segments.short.tes) + float(result.tes.segments.free.tes)
		result.tes.minimum_combined = float(canonical_policy.minimum_combined_tes)
		result.tes.eligible = result.tes.combined >= result.tes.minimum_combined
		if not result.tes.eligible: result.reason_codes.append("combined_tes_below_minimum")
	result.tes.cutoff = cutoff
	for segment in ["short","free"]:
		if result.tes.segments.has(segment): result.evidence.append(result.tes.segments[segment].duplicate(true))
		else: result.reason_codes.append(segment+"_tes_not_established")
	if result.age.status != "eligible": result.reason_codes.append_array(result.age.reason_codes)
	if result.age.status == "ineligible": result.status = "ineligible"
	elif result.age.status == "unknown": result.status = "unknown"
	elif result.tes.eligible:
		result.status = "eligible"
		result.eligible = true
	else: result.status = "unknown" if evidence_incomplete else "ineligible"
	return result

static func _canonical_event(id: String, year: int, level: String, calendars: Dictionary) -> Dictionary:
	var key := "%d:%s" % [year,level]
	if not calendars.has(key): calendars[key] = Calendar.load_international_calendar(year,"women_singles",level)
	var loaded: Dictionary = calendars[key]
	if not loaded.errors.is_empty(): return {}
	for candidate in loaded.calendar.events:
		if candidate.event_id != id: continue
		if candidate.get("scope") != "international" or candidate.get("record_eligibility") != "isu_recognized" or not candidate.get("level_options",[]).has(level): return {}
		if Calendar.event_status(candidate) not in ["scheduled","held"]: return {}
		return candidate
	return {}

static func explanations(result: Dictionary, policy: Dictionary) -> Array[String]:
	var messages: Array[String] = []
	if policy.is_empty() or result.get("reason_codes",[]).has("qualification_policy_unknown_or_mismatched") or result.get("reason_codes",[]).has("canonical_target_mismatch"):
		messages.append("赛事或个人资格规则尚不能核对，不据此发放资格。")
		return messages
	if not result.get("tes",{}).get("eligible",false):
		var levels := "青年或成年" if policy.get("allowed_earned_levels",[]).has("junior") and policy.get("allowed_earned_levels",[]).has("senior") else ("成年" if policy.earned_level == "senior" else "青年")
		if policy.has("minimum_combined_tes"):
			messages.append("个人国际 TES 尚未达标：须在 %s 及以前的认可%s国际赛取得短节目与自由滑合计至少 %s；两段可来自不同比赛。" % [policy.cutoff,levels,policy.minimum_combined_tes])
		else:
			messages.append("个人国际TES尚未齐备：短节目至少%s、自由滑至少%s；须在%s及以前的认可%s国际赛取得，两段可来自不同比赛，国内总分不代替TES。" % [policy.minimum_tes.short,policy.minimum_tes.free,policy.cutoff,levels])
	if result.get("age",{}).get("status") == "unknown": messages.append("年龄资料尚不确定，请在赛季资料中补充准确生日；不影响国内训练。")
	elif result.get("age",{}).get("status") == "ineligible": messages.append("出生日期不符合本届国际赛事年龄条件。")
	return messages

static func _matches_event(record: Dictionary, canonical: Dictionary, level: String) -> bool:
	for key in ["event_id","start_date","end_date","scope","ruleset_season_start_year","record_eligibility"]:
		if not record.has(key) or record[key] != canonical.get(key): return false
	for key in ["segment_dates","event_family","qualification_policy_id"]:
		if record.has(key) and JSON.stringify(record[key]) != JSON.stringify(canonical.get(key)): return false
	if record.has("competition_level") and record.competition_level != level: return false
	if record.has("level_options") and record.level_options != canonical.level_options: return false
	return true

static func _qualification_records(archive: Dictionary) -> Dictionary:
	# A batch reuses verified result evidence, not the much larger frozen
	# athlete/programme/performance bodies used only for replay. This remains
	# call-local and detached; every subsequent batch validates its sources.
	var view := {"short_results":{},"free_results":{}}
	for segment in ["short","free"]:
		var records = archive.get(segment+"_results",{})
		if not records is Dictionary: continue
		for id in records:
			var record = records[id]
			if not record is Dictionary or record.is_empty(): continue
			var evidence := {"_record_present":true}
			for field in ["score","protocol","technical_review"]:
				if not record.has(field): continue
				var value = record[field]
				evidence[field] = value.duplicate(true) if value is Dictionary or value is Array else value
			view[segment+"_results"][id] = evidence
	return view

static func _final_record(record: Dictionary) -> bool:
	var review = record.get("technical_review",{})
	if not review is Dictionary or not review.get("review_events",[]) is Array: return false
	for item in review.get("review_events",[]):
		if not item is Dictionary or item.get("status") != "resolved": return false
	return true

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value))

static func _tes_number(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0

static func _valid_date(value: String) -> bool:
	return preload("res://src/simulation/world_junior_minimum_service.gd")._valid_date(value)

static func _same_value(actual: Variant, expected: Variant) -> bool:
	if expected is int or expected is float:
		return (actual is int or actual is float) and is_finite(float(actual)) and float(actual) == float(expected)
	if expected is Dictionary:
		if not actual is Dictionary or actual.size() != expected.size(): return false
		for key in expected:
			if not actual.has(key) or not _same_value(actual[key],expected[key]): return false
		return true
	if expected is Array:
		if not actual is Array or actual.size() != expected.size(): return false
		for i in expected.size():
			if not _same_value(actual[i],expected[i]): return false
		return true
	return typeof(actual) == typeof(expected) and actual == expected
