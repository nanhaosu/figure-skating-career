class_name EventEngine
extends RefCounted

const QuarterEvent = preload("res://src/domain/quarter_event.gd")
const MemoryRecord = preload("res://src/domain/memory_record.gd")
const ConflictScanner = preload("res://src/simulation/conflict_scanner.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")

static func generate(career, proposal, rng: RandomNumberGenerator) -> Array:
	var events: Array = []
	var phrases := _load_phrases()
	for conflict in ConflictScanner.scan(career, proposal):
		if events.size() >= 3 or _is_recent_duplicate(career, conflict.signature):
			continue
		var event = QuarterEvent.new()
		event.id = "event:%d:%d:%s" % [career.clock.year, career.clock.quarter, conflict.signature]
		event.signature = conflict.signature
		event.trigger_codes.assign(conflict.trigger_codes)
		event.cause_ids.assign(conflict.cause_ids)
		if event.signature == "delayed_pain":
			event.title = "落冰后出现不适"
			event.description = _compose_description(phrases, "delayed_pain", rng)
			event.choices.assign([{"id": "report_pain", "label": "告诉大人"}, {"id": "hide_pain", "label": "暂时隐瞒"}])
		elif event.signature == "fatigue_breakdown":
			event.title = "训练状态明显下滑"
			event.description = _compose_description(phrases, "fatigue_breakdown", rng)
			event.choices.assign([{"id": "rest_now", "label": "主动减少训练"}, {"id": "push_through", "label": "咬牙继续"}])
		else:
			event.title = "跳跃训练超过预期"
			event.description = _compose_description(phrases, "jump_load_conflict", rng)
			event.choices.assign([{"id": "continue_training", "label": "继续训练"}, {"id": "reduce_load", "label": "主动减量"}])
		events.append(event)
	return events

static func from_training_milestones(career, milestones: Array) -> Array:
	var events: Array = []
	for milestone in milestones:
		if not milestone is Dictionary or not bool(milestone.get("interrupt", false)):
			continue
		var signature := str(milestone.get("signature", ""))
		if not signature.begins_with("first_jump_success") or _is_recent_duplicate(career, signature):
			continue
		var jump_id := str(milestone.get("jump_id", ""))
		var rotations := int(milestone.get("rotations", 1))
		var event = QuarterEvent.new()
		event.id = "event:%d:%d:%s" % [career.clock.year, career.clock.quarter, signature]
		event.signature = signature
		event.trigger_codes.assign(["jump_breakthrough"])
		event.cause_ids.assign([signature])
		event.title = "首次完成%s周%s" % [_rotation_label(rotations), TrainingPlan.JUMP_LABELS.get(jump_id, jump_id)]
		event.description = "这个动作已经成功过一次，但距离稳定掌握仍有很长距离。接下来要优先巩固，还是保留现有训练方向？"
		event.choices.assign([
			{"id": "consolidate_breakthrough", "label": "优先巩固"},
			{"id": "keep_training_strategy", "label": "维持方向"},
		])
		events.append(event)
	return events

static func from_roadmap_progress(progress_record: Dictionary) -> Array:
	var events: Array = []
	for data in progress_record.get("key_events", []):
		if not data is Dictionary:
			continue
		var event = QuarterEvent.new()
		event.id = str(data.get("id", ""))
		event.signature = str(data.get("signature", ""))
		event.title = str(data.get("title", "成长路线需要讨论"))
		event.description = str(data.get("description", "教练希望与你重新讨论成长路线。"))
		event.trigger_codes.assign(data.get("trigger_codes", []))
		event.cause_ids.assign(data.get("cause_ids", []))
		event.choices.assign(data.get("choices", []))
		events.append(event)
	return events

static func _rotation_label(rotations: int) -> String:
	return {1: "一", 2: "两", 3: "三", 4: "四"}.get(rotations, str(rotations))

static func resolve(career, event, choice_id: String, _rng: RandomNumberGenerator, proposal = null) -> Array:
	var memory = MemoryRecord.new()
	memory.id = "memory:%s:%s" % [event.id, choice_id]
	memory.kind = "event_memory"
	memory.cause_ids = event.cause_ids.duplicate()
	memory.cause_ids.append(event.id)
	memory.strength = 80.0
	memory.credibility = 90.0
	memory.created_clock = career.clock.to_dict()
	memory.decay_per_quarter = 5.0
	memory.signature = event.signature
	var stored := memory.to_dict()
	stored["choice_id"] = choice_id
	stored["body_snapshot"] = career.athlete.body.duplicate(true)
	career.memories.append(stored)
	var outcomes: Array = []
	if choice_id == "continue_training":
		var previous := float(career.athlete.body.impact_load)
		career.athlete.body.impact_load = clampf(previous + 5.0, 0.0, 100.0)
		outcomes.append(OutcomeRecord.new("body", "impact_load", float(career.athlete.body.impact_load) - previous, [event.id, memory.id], "impact_load_change"))
		outcomes.append(_apply_metric(career.athlete.body, "acute_fatigue", 3.0, "body", [event.id, memory.id], "fatigue_change"))
	elif choice_id == "reduce_load" or choice_id == "rest_now":
		_reduce_executed_jump(career,proposal)
		if choice_id == "rest_now" and proposal != null and not proposal.executed.shares.is_empty():
			var shares: Dictionary = proposal.executed.shares.duplicate(true)
			while int(shares.rest) < 40:
				var donor := ""
				for category in TrainingPlan.CATEGORY_IDS:
					if category == "rest": continue
					if int(shares[category]) > (int(shares.get(donor, 0)) if not donor.is_empty() else 0): donor = category
				if donor.is_empty() or int(shares[donor]) <= 0: break
				shares[donor] -= TrainingPlan.SHARE_STEP
				shares.rest += TrainingPlan.SHARE_STEP
			var previous = proposal.executed
			proposal.executed = TrainingPlan.create(shares, previous.jump_rotations).plan
			preload("res://src/simulation/authority_resolver.gd")._preserve_specialists(career,previous,proposal.executed)
	elif choice_id == "push_through":
		outcomes.append(_apply_metric(career.athlete.body, "acute_fatigue", 5.0, "body", [event.id, memory.id], "fatigue_change"))
	elif choice_id == "hide_pain":
		outcomes.append(_apply_metric(career.athlete.mind, "training_fear", 5.0, "mind", [event.id, memory.id], "training_fear_change"))
		outcomes.append(_apply_metric(career.athlete.body, "ankle_load", 5.0, "body", [event.id, memory.id], "ankle_load_change"))
	elif choice_id == "report_pain":
		var restriction := memory.to_dict()
		restriction.id += ":restriction"
		restriction.signature = "medical_restriction"
		restriction.kind = "medical_restriction"
		career.memories.append(restriction)
	elif choice_id == "roadmap_keep_targets":
		outcomes.append(_apply_metric(career.athlete.body, "acute_fatigue", 2.0, "body", [event.id, memory.id], "fatigue_change"))
		if career.relationships.has("coach"):
			career.relationships.coach.professional_trust = clampf(career.relationships.coach.professional_trust - 4.0, 0.0, 100.0)
	elif choice_id == "roadmap_accept_revision":
		career.roadmap_revision_history.append({"clock": career.clock.to_dict(), "route_id": career.development_roadmap.get("route_id", ""), "reason": "接受教练的路线重评建议"})
	elif choice_id == "roadmap_temporary_safety" or choice_id == "roadmap_consolidate":
		var safety := memory.to_dict()
		safety.id += ":roadmap_safety"
		safety.signature = "roadmap_temporary_safety"
		safety.kind = "training_preference"
		career.memories.append(safety)
	elif choice_id == "roadmap_raise_targets":
		career.roadmap_revision_history.append({"clock": career.clock.to_dict(), "route_id": career.development_roadmap.get("route_id", ""), "reason": "达成节点后主动提高后续目标"})
	career.history.append_array(OutcomeRecord.list_to_dict(outcomes))
	return outcomes

static func _reduce_executed_jump(career,proposal) -> void:
	if proposal == null: return
	var percentage_mode: bool = not proposal.executed.shares.is_empty()
	var allocations: Dictionary = proposal.executed.shares if percentage_mode else proposal.executed.allocations
	var chosen := "jump_toe_loop"
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id.begins_with("jump_") and int(allocations[category_id]) > int(allocations[chosen]): chosen = category_id
	if int(allocations[chosen]) <= 0: return
	var amount := TrainingPlan.SHARE_STEP if percentage_mode else 1
	allocations[chosen] = int(allocations[chosen]) - amount
	allocations.rest = int(allocations.rest) + amount
	var previous = proposal.executed
	proposal.executed = TrainingPlan.create(allocations, previous.jump_rotations).plan if percentage_mode else TrainingPlan.create(allocations).plan
	if percentage_mode:
		preload("res://src/simulation/authority_resolver.gd")._preserve_specialists(career,previous,proposal.executed)

static func _apply_metric(state: Dictionary, target: String, delta: float, category: String, causes: Array[String], summary_key: String):
	var previous := float(state.get(target, 0.0))
	state[target] = clampf(previous + delta, 0.0, 100.0)
	return OutcomeRecord.new(category, target, float(state[target]) - previous, causes, summary_key)

static func _is_recent_duplicate(career, signature: String) -> bool:
	for memory in career.memories:
		if memory.get("signature") != signature or float(memory.get("strength", 0.0)) < 40.0:
			continue
		if not memory.get("created_clock") is Dictionary:
			return true
		if int(memory.created_clock.get("year", 0)) == career.clock.year and int(memory.created_clock.get("quarter", 0)) == career.clock.quarter:
			return true
		if signature == "fatigue_breakdown" and str(memory.get("choice_id", "")) == "rest_now":
			var elapsed: int = (career.clock.year - int(memory.created_clock.get("year", 0))) * 4 + career.clock.quarter - int(memory.created_clock.get("quarter", 0))
			var previous: Dictionary = memory.get("body_snapshot", {})
			if elapsed == 1 and not previous.is_empty() and float(career.athlete.body.acute_fatigue) <= float(previous.get("acute_fatigue", 0.0)) + 5.0 and float(career.athlete.body.cumulative_fatigue) <= float(previous.get("cumulative_fatigue", 0.0)) + 3.0:
				return true
	return false

static func decay_memories(career) -> void:
	for memory in career.memories:
		memory.strength = maxf(0.0, float(memory.get("strength", 0.0)) - float(memory.get("decay_per_quarter", 0.0)))

static func _load_phrases() -> Dictionary:
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string("res://data/2014_cn/event_phrases.json")) == OK and json.data is Dictionary:
		return json.data
	return {"locations": ["训练冰场"], "fragments": {}}

static func _compose_description(phrases: Dictionary, signature: String, rng: RandomNumberGenerator) -> String:
	var locations: Array = phrases.get("locations", ["训练冰场"])
	var fragments: Array = phrases.get("fragments", {}).get(signature, ["本季度发生了一件需要你决定的事。"])
	return "%s：%s" % [locations[rng.randi_range(0, locations.size() - 1)], fragments[rng.randi_range(0, fragments.size() - 1)]]
