class_name ProgramLoadEstimator
extends RefCounted

const Scoring = preload("res://src/content/formal_scoring_repository.gd")
const CODES := {"toe_loop":"T", "salchow":"S", "loop":"Lo", "flip":"F", "lutz":"Lz", "axel":"A"}
const ROUTE_LOAD := {"simple":0.0, "standard":4.0, "rich":10.0, "extreme":18.0}

static func estimate_segment(program, athlete, context: Dictionary) -> Dictionary:
	var condition: Dictionary = Dictionary(context.get("condition", {})).duplicate(true)
	condition.fatigue = float(context.get("starting_fatigue", athlete.body.get("acute_fatigue", 0.0)))
	return estimate(program, athlete, condition)

# Transparent gameplay load units, not medical measures or success probabilities.
static func estimate(program, athlete, condition: Dictionary) -> Dictionary:
	var catalog: Dictionary = Scoring.load_catalog(2018, "women_singles").catalog
	var components := {"bv_ambition":0.0, "transitions":0.0, "coverage":float(ROUTE_LOAD.get(program.route_complexity, 4.0)), "late_placement":0.0, "familiarity":0.0, "stamina":0.0, "fatigue":0.0, "injury":0.0, "growth":0.0, "psychology":0.0}
	var previous := Vector2(0.5, 0.5)
	for index in program.elements.size():
		var element = program.elements[index]
		var bv := 0.0
		if element.kind == "jump":
			bv = Scoring.element_value(catalog, "%d%s" % [element.rotations, CODES.get(element.jump_id, "")])
			for part in element.combination_parts: bv += Scoring.element_value(catalog, "%d%s" % [int(part.rotations), CODES.get(str(part.jump_id), "")])
		else:
			bv = Scoring.level_value(catalog, element.spin_code if element.kind == "spin" else "StSq", element.target_level)
		components.bv_ambition += bv
		components.transitions += element.entry_difficulty * 3.0
		if element.kind == "jump": components.late_placement += bv * float(index) / maxi(1, program.elements.size() - 1) * 0.2
		if not element.ice_anchor.is_empty():
			var point := Vector2(float(element.ice_anchor.get("x", 0.5)), float(element.ice_anchor.get("y", 0.5)))
			components.coverage += previous.distance_to(point) * 3.0
			previous = point
	# Unfamiliarity adds a modest coordination load. Familiar programmes should
	# not grant a large hidden physical buff that youth programmes cannot match.
	components.familiarity = maxf(0.0, 30.0 - float(program.whole_run_familiarity)) * 0.08
	var stamina := float(athlete.body.get("stamina", athlete.body.get("strength_readiness", 25.0)))
	components.stamina = -stamina * 0.2
	components.fatigue = float(condition.get("fatigue", athlete.body.get("acute_fatigue", 0.0))) * 0.15 + float(athlete.body.get("cumulative_fatigue", 0.0)) * 0.10
	var severity := float(condition.get("injury", 0.0))
	for injury in condition.get("injuries", []):
		if str(injury.get("status", "")) == "active": severity = maxf(severity, float(injury.get("severity", 0.0)))
	components.injury = severity * 12.0
	components.growth = float(condition.get("growth", float(athlete.body.get("growth_trend", 0.0)) / 100.0)) * 8.0
	if str(condition.get("growth_phase", "")) == "rapid": components.growth = maxf(components.growth, 8.0)
	var psychology = condition.get("psychology", float(athlete.mind.get("training_fear", 0.0)) / 100.0)
	components.psychology = (float(psychology.get("stress", 0.0)) / 100.0 if psychology is Dictionary else float(psychology)) * 10.0
	var total := 0.0
	for value in components.values(): total += float(value)
	var capacity := 40.0 + stamina * 0.2
	var overload := maxf(0.0, total - 40.0)
	var content := clampf(float(components.bv_ambition) / (55.0 if program.segment == "free" else 30.0), 0.0, 1.0)
	return {"total_load":maxf(0.0, total), "components":components, "capacity":capacity, "demand":maxf(0.0, total - float(components.stamina)), "overload":overload, "execution_penalty":overload * 0.5, "content_potential":content, "pcs_potential":clampf(content * (0.75 + float(ROUTE_LOAD.get(program.route_complexity, 4.0)) / 72.0), 0.0, 1.0), "assessment":"负荷超出当前能力" if overload > 0.0 else "负荷可控"}
