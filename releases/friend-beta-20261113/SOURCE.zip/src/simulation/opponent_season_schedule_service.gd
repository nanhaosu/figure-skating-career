class_name OpponentSeasonScheduleService
extends RefCounted

const Policy = preload("res://src/simulation/annual_selection_policy_service.gd")
const PolicyRepository = preload("res://src/content/annual_selection_policy_repository.gd")
const Dates = preload("res://src/simulation/dated_training_window.gd")
const Identity = preload("res://src/domain/athlete_identity.gd")
const DOMESTIC_FEE := 3.0
const ASSIGNED_JUNIOR_FEE := 8.0

# C1 is a bounded, local game-economy model. It does not replace the existing
# quarterly NPC growth or invent player-style daily practice evidence.
static func covered_event(event: Dictionary) -> bool:
	if str(event.get("competition_level","junior")) != "junior": return false
	if not event.get("level_options",[]).has("junior"): return false
	return event.get("event_family") == "jgp_stage" or (event.get("scope") == "domestic" and event.get("event_family") in ["club_league_stage","national_junior"])

static func _eligible(record: Dictionary, year: int) -> bool:
	if record.get("world_record_version") != 1 or record.get("federation") != "CHN" or record.get("status") != "active": return false
	var text := str(record.get("birth_date",""))
	if text.length() != 10: return false
	var date := {"year":int(text.left(4)),"month":int(text.substr(5,2)),"day":int(text.substr(8,2))}
	return Identity.age_gate(int(record.get("athlete",{}).get("birth_year",0)),date,year,13,18).status == "eligible"

static func ensure_plans(career, bundle: Dictionary) -> Dictionary:
	var year := int(bundle.get("calendar",{}).get("calendar_year",0))
	var season := str(bundle.get("calendar",{}).get("season_id",""))
	var effective := Policy.effective(career,year)
	if not effective.errors.is_empty(): return {"changed_ids":[],"errors":effective.errors,"managed":false}
	if effective.status != "frozen": return {"changed_ids":[],"errors":[],"managed":false}
	var existing: bool = career.world_athletes.values().any(func(r):return r.get("opponent_schedule",{}).get("season_id") == season)
	# A later software update cannot manufacture decisions before old starts.
	var event_ids: Array = bundle.get("calendar",{}).get("events",[]).map(func(e):return str(e.event_id))
	var choices: bool = _has_current_choices(career.selection_state,event_ids,season,year)
	if not existing and (choices or career.competition_archive.any(func(a):return a.get("season_id") == season and a.get("status") == "complete")):
		return {"changed_ids":[],"errors":[],"managed":false}
	if career.competition_timeline.mode == "dated": effective.planning_date = career.competition_timeline.date
	else:
		if not existing and (int(career.training_period_state.get("weeks_elapsed",0)) > 0 or career.training_period_state.has("stage_checkpoint")): return {"changed_ids":[],"errors":[],"managed":false}
		var first := "%04d-%02d-01T00:00:00" % [career.clock.year,(career.clock.quarter-1)*3+1]
		effective.planning_date = Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_datetime_string(first))-86400)
	var changed: Array[String] = []
	var ids: Array = career.world_athletes.keys(); ids.sort()
	for id in ids:
		var record: Dictionary = career.world_athletes[id]
		if not _eligible(record,year): continue
		if record.has("opponent_schedule"):
			var error := validate(record.opponent_schedule)
			if not error.is_empty(): return {"changed_ids":[],"errors":[str(id)+": "+error],"managed":false}
			if record.opponent_schedule.athlete_id != str(record.athlete_id): return {"changed_ids":[],"errors":["NPC赛程身份绑定不一致"],"managed":false}
			if record.opponent_schedule.season_id == season:
				if record.opponent_schedule.policy_sha256 != effective.content_sha256: return {"changed_ids":[],"errors":["NPC赛程与当季已公布制度不一致"],"managed":false}
				continue
			if record.get("competition_history",[]).any(func(r):return r.get("season_id") == season): continue
			# Keep the prior economic receipts with the existing career history.
			if not record.has("opponent_schedule_history"): record.opponent_schedule_history = {}
			record.opponent_schedule_history[record.opponent_schedule.season_id] = record.opponent_schedule.duplicate(true)
			if record.opponent_schedule_history.size() > 8: return {"changed_ids":[],"errors":["NPC赛程历史超过本阶段支持上限"],"managed":false}
		elif record.get("competition_history",[]).any(func(r):return r.get("season_id") == season): continue
		var built := preview(record,bundle,effective,record.get("competition_history",[]))
		if not built.errors.is_empty(): return {"changed_ids":[],"errors":built.errors,"managed":false}
		record.opponent_schedule = built.plan
		changed.append(str(id))
	return {"changed_ids":changed,"errors":[],"managed":existing or not changed.is_empty()}

static func _has_current_choices(state: Dictionary, event_ids: Array, season: String, year: int) -> bool:
	if state.get("applications",{}).values().any(func(a):return event_ids.has(str(a.get("event_id","")))): return true
	for assigned in state.get("assignments",{}).values():
		if assigned.any(func(id):return event_ids.has(str(id))): return true
	for decision in state.get("decisions",{}).values():
		if decision.has("season_id"):
			if decision.season_id == season: return true
			continue
		var clock: Dictionary = decision.get("clock",{})
		if clock.is_empty(): return true # Unattributed legacy decisions remain fail-closed.
		var decision_year := int(clock.get("year",0))
		var quarter := int(clock.get("quarter",0))
		if (decision_year == year and quarter >= 3) or (decision_year == year+1 and quarter <= 2): return true
	return false

static func preview(record: Dictionary, bundle: Dictionary, effective: Dictionary, known_results: Array) -> Dictionary:
	var year := int(bundle.get("calendar",{}).get("calendar_year",0))
	var season := str(bundle.get("calendar",{}).get("season_id",""))
	if effective.get("status") != "frozen" or not effective.get("errors",[]).is_empty() or not _eligible(record,year): return {"plan":{},"errors":["NPC自主赛程需要已公布制度和适龄持久中国青年选手"]}
	var body: Dictionary = record.athlete.body
	var fatigue := maxf(float(body.get("acute_fatigue",0.0)),float(body.get("cumulative_fatigue",0.0)))
	var ambition := float(record.get("personality",{}).get("ambition",50.0))
	var money := float(record.athlete.resources.money)
	var goal := "recovery" if fatigue >= 65.0 else ("qualification" if ambition >= 60.0 else "development")
	var policy: Dictionary = effective.policy
	var required: Array = policy.targets.world_junior.designated_event_ids
	var countable: Array = policy.targets.jgp.designated_event_ids
	var complete := known_results.filter(func(r):return r.get("qualified",false) and countable.has(str(r.get("event_id","")))).size()
	var planned_after := str(effective.get("planning_date","%04d-01-01" % year))
	if not Dates.valid_range(planned_after,planned_after): return {"plan":{},"errors":["NPC赛程缺少可核对的前向规划边界"]}
	var plan := {"model_version":1,"season_id":season,"athlete_id":str(record.athlete_id),"origin":"fresh_published_policy","policy_id":str(policy.policy_id),"policy_sha256":str(effective.content_sha256),"planned_after":planned_after,"opening_money":money,"reserved_money":0.0,"max_jgp_starts":int(policy.targets.jgp.max_starts),"goal":goal,"events":{},"fee_receipts":{}}
	var rows: Array = bundle.get("calendar",{}).get("events",[]).duplicate(true)
	# Required opportunities reserve scarce funds before optional score hunts.
	rows.sort_custom(func(a,b):
		if required.has(str(a.event_id)) != required.has(str(b.event_id)): return required.has(str(a.event_id))
		return str(a.event_id) < str(b.event_id))
	var occupied: Array = []
	for event in rows:
		var id := str(event.event_id)
		var start := str(event.get("actual_dates",{}).get("start",event.get("start_date","")))
		var finish := str(event.get("actual_dates",{}).get("end",event.get("end_date",start)))
		var exact: bool = Dates.valid_range(start,finish)
		var row := {"choice":"outside_scope","reason_codes":["senior_or_special_legacy"],"target_role":"required" if required.has(id) else ("countable" if countable.has(id) else "optional"),"date_status":"exact" if exact else "unknown","start_date":start,"end_date":finish,"money_cost":ASSIGNED_JUNIOR_FEE if event.get("event_family") == "jgp_stage" else DOMESTIC_FEE}
		if covered_event(event):
			row.choice = "skip"; row.reason_codes = []
			if not exact: row.reason_codes = ["date_unverified"]
			# The cursor has day precision. A same-day start is still open at publication.
			elif start < planned_after: row.reason_codes = ["past_before_planning"]
			elif goal == "recovery": row.reason_codes = ["recovery_over_selection_opportunity"]
			elif event.get("event_family") == "jgp_stage": row.choice = "pending_assignment"; row.reason_codes = ["requires_published_assignment"]
			elif not required.has(id) and (ambition < 60.0 or complete >= 2): row.reason_codes = ["prepare_instead_of_optional_start"]
			elif float(plan.reserved_money)+DOMESTIC_FEE > money: row.reason_codes = ["insufficient_budget"]
			elif occupied.any(func(interval):return start <= str(interval.end) and finish >= str(interval.start)): row.reason_codes = ["overlapping_competition_dates"]
			else:
				row.choice = "request"
				row.reason_codes = ["preserve_required_score_opportunity" if required.has(id) else "seek_complete_designated_score"]
				plan.reserved_money += DOMESTIC_FEE
				occupied.append({"start":start,"end":finish})
		plan.events[id] = row
	plan.content_sha256 = _hash(plan)
	var error := validate(plan)
	return {"plan":plan if error.is_empty() else {},"errors":[] if error.is_empty() else [error]}

static func participates(career, record: Dictionary, event: Dictionary) -> Dictionary:
	var plan = record.get("opponent_schedule",{})
	if not plan is Dictionary: return {"covered":true,"allowed":false,"reason":"invalid_schedule","errors":["NPC赛程必须为对象"]}
	var season := "%d-%02d" % [int(event.get("ruleset_season_start_year",0)),(int(event.get("ruleset_season_start_year",0))+1)%100]
	if not covered_event(event) or plan.is_empty() or plan.get("season_id") != season: return {"covered":false,"allowed":true,"reason":"legacy_or_outside_scope"}
	var invalid := validate(plan)
	if not invalid.is_empty(): return {"covered":true,"allowed":false,"reason":"invalid_schedule","errors":[invalid]}
	if plan.athlete_id != str(record.athlete_id): return {"covered":true,"allowed":false,"reason":"identity_mismatch","errors":["NPC赛程身份绑定不一致"]}
	var effective := Policy.effective(career,int(event.get("ruleset_season_start_year",0)))
	if not effective.errors.is_empty() or effective.status != "frozen" or effective.content_sha256 != plan.policy_sha256: return {"covered":true,"allowed":false,"reason":"policy_mismatch","errors":["NPC赛程与当季已公布制度不一致"]}
	var id := str(event.event_id)
	var row: Dictionary = plan.events.get(id,{})
	if plan.fee_receipts.has(id): return {"covered":true,"allowed":true,"reason":"already_completed"}
	var accepted := _accepted_assignments(career,record,plan)
	if row.get("choice") == "pending_assignment":
		if not accepted.has(id): return {"covered":true,"allowed":false,"reason":"unassigned_unaffordable_or_overlapping"}
	elif row.get("choice") != "request": return {"covered":true,"allowed":false,"reason":"planned_skip"}
	else:
		for assigned_id in accepted:
			var international: Dictionary = plan.events[assigned_id]
			if str(row.start_date) <= str(international.end_date) and str(row.end_date) >= str(international.start_date): return {"covered":true,"allowed":false,"reason":"accepted_assignment_date_overlap"}
	if float(record.athlete.resources.money) < float(row.get("money_cost",0.0)): return {"covered":true,"allowed":false,"reason":"insufficient_current_money"}
	return {"covered":true,"allowed":true,"reason":"planned_participation"}

static func _accepted_assignments(career, record: Dictionary, plan: Dictionary) -> Array:
	var offered: Array = career.selection_state.assignments.get(record.athlete_id,[]).filter(func(id):return plan.events.get(id,{}).get("choice") == "pending_assignment")
	offered.sort_custom(func(a,b):return str(plan.events[a].start_date) < str(plan.events[b].start_date) if plan.events[a].start_date != plan.events[b].start_date else str(a)<str(b))
	var accepted: Array = []; var funds := float(record.athlete.resources.money)
	for id in offered:
		if accepted.size() >= int(plan.max_jgp_starts): break
		var row: Dictionary = plan.events[id]
		# Actual earlier starts win over a later offer. Never rewrite history to
		# let one athlete skate two overlapping events.
		if not plan.fee_receipts.has(id) and plan.fee_receipts.values().any(func(receipt):return str(row.start_date) <= str(receipt.end_date) and str(row.end_date) >= str(receipt.start_date)): continue
		if accepted.any(func(other):return str(row.start_date) <= str(plan.events[other].end_date) and str(row.end_date) >= str(plan.events[other].start_date)): continue
		if not plan.fee_receipts.has(id):
			if funds < float(row.money_cost): continue
			funds -= float(row.money_cost)
		accepted.append(id)
	return accepted

static func field_covered(career,event: Dictionary) -> bool:
	if not covered_event(event): return false
	var season := "%d-%02d" % [int(event.get("ruleset_season_start_year",0)),(int(event.get("ruleset_season_start_year",0))+1)%100]
	return career.world_athletes.values().any(func(r):return r.get("opponent_schedule",{}).get("season_id") == season)

static func settle_actual_participation(record: Dictionary, archive: Dictionary) -> Dictionary:
	var plan = record.get("opponent_schedule",{})
	if not plan is Dictionary: return {"charged":false,"errors":["NPC赛程必须为对象"]}
	var id := str(archive.get("event_id",""))
	if plan.is_empty() or plan.get("season_id") != archive.get("season_id") or not covered_event(archive.get("event",{})): return {"charged":false,"errors":[]}
	var error := validate(plan)
	if not error.is_empty(): return {"charged":false,"errors":[error]}
	if plan.athlete_id != str(record.athlete_id): return {"charged":false,"errors":["NPC赛程身份绑定不一致"]}
	if plan.fee_receipts.has(id): return {"charged":false,"errors":[]}
	if archive.get("status") != "complete" or not archive.get("short_results",{}).has(record.athlete_id) or not archive.get("short_standings",[]).any(func(r):return r.get("athlete_id") == record.athlete_id): return {"charged":false,"errors":[]}
	var row: Dictionary = plan.events.get(id,{})
	if row.get("choice") not in ["request","pending_assignment"]: return {"charged":false,"errors":["实际NPC出场与已保存赛程不一致"]}
	var fee := float(row.money_cost)
	if float(record.athlete.resources.money) < fee: return {"charged":false,"errors":["NPC实际参赛费用超出剩余预算"]}
	record.athlete.resources.money = snappedf(float(record.athlete.resources.money)-fee,0.001)
	plan.fee_receipts[id] = {"event_id":id,"athlete_id":str(record.athlete_id),"money_cost":fee,"source":"actual_complete_sp_start","qualified":archive.get("free_results",{}).has(record.athlete_id),"start_date":row.start_date,"end_date":row.end_date}
	return {"charged":true,"errors":[]}

static func _hash(plan: Dictionary) -> String:
	var immutable := plan.duplicate(true)
	immutable.erase("fee_receipts"); immutable.erase("content_sha256")
	return PolicyRepository.content_hash(immutable)

static func summary(career, year: int) -> Dictionary:
	var season := PolicyRepository.season_id(year)
	var rows: Array = []; var goals := {}; var choices := {}
	var ids: Array = career.world_athletes.keys(); ids.sort()
	for id in ids:
		var record: Dictionary = career.world_athletes[id]
		var plan: Dictionary = record.get("opponent_schedule",{})
		if plan.get("season_id") != season: plan = record.get("opponent_schedule_history",{}).get(season,{})
		if plan.is_empty(): continue
		goals[plan.goal] = int(goals.get(plan.goal,0))+1
		var requests: Array = []; var skips: Array = []; var spent := 0.0
		for event_id in plan.events:
			var choice: String = plan.events[event_id].choice
			choices[choice] = int(choices.get(choice,0))+1
			if plan.events[event_id].choice == "request": requests.append(event_id)
			elif plan.events[event_id].choice == "skip": skips.append(event_id)
		for receipt in plan.fee_receipts.values(): spent += float(receipt.money_cost)
		requests.sort(); skips.sort()
		rows.append({"athlete_id":str(id),"name":str(record.get("name","")),"season_id":season,"policy_sha256":plan.policy_sha256,"schedule_sha256":plan.content_sha256,"goal":plan.goal,"events":plan.events.duplicate(true),"requests":requests,"skips":skips,"fee_receipts":plan.fee_receipts.duplicate(true),"actual_starts":plan.fee_receipts.size(),"actual_money_spent":spent,"opening_money":plan.opening_money,"current_money":float(record.athlete.resources.money),"competition_history":record.get("competition_history",[]).filter(func(r):return r.get("season_id") == season).duplicate(true)})
	return {"season_id":season,"scope":"CHN junior ordinary and assigned JGP C1; quarterly NPC growth unchanged","managed_count":rows.size(),"covered_npc_count":rows.size(),"goal_distribution":goals,"choice_distribution":choices,"records":rows}

static func validate(plan) -> String:
	if not plan is Dictionary or not PolicyRepository.integer(plan.get("model_version"),1,1): return "NPC赛程版本无效"
	for key in ["season_id","athlete_id","policy_id","policy_sha256","content_sha256","planned_after"]:
		if not plan.get(key) is String or str(plan[key]).is_empty(): return "NPC赛程缺少身份或制度来源"
	var year := int(str(plan.season_id).left(4))
	if year < 2018 or year > 2022 or plan.season_id != PolicyRepository.season_id(year) or plan.get("origin") != "fresh_published_policy": return "NPC赛程启用边界无效"
	if not Dates.valid_range(plan.planned_after,plan.planned_after): return "NPC赛程规划边界日期无效"
	if not PolicyRepository.number(plan.get("opening_money"),0,1000000) or not PolicyRepository.number(plan.get("reserved_money"),0,float(plan.opening_money)): return "NPC赛程预算无效"
	if plan.get("goal") not in ["qualification","development","recovery"]: return "NPC赛程目标无效"
	if not PolicyRepository.integer(plan.get("max_jgp_starts"),1,2): return "NPC赛程分站上限无效"
	if not plan.get("events") is Dictionary or plan.events.is_empty() or plan.events.size() > 64 or not plan.get("fee_receipts") is Dictionary or plan.fee_receipts.size() > plan.events.size(): return "NPC赛程赛事或回执必须有界"
	for id in plan.events:
		var row = plan.events[id]
		if not id is String or id.is_empty() or not row is Dictionary: return "NPC赛程赛事编号无效"
		if row.get("choice") not in ["request","skip","pending_assignment","outside_scope"] or row.get("target_role") not in ["required","countable","optional"]: return "NPC赛程选择无效"
		if not row.get("reason_codes") is Array or row.reason_codes.is_empty() or row.reason_codes.size() > 4: return "NPC赛程理由无效"
		for reason in row.reason_codes:
			if not reason is String or reason.is_empty(): return "NPC赛程理由必须为非空文本"
		if row.get("date_status") not in ["exact","unknown"] or not row.get("start_date") is String or not row.get("end_date") is String: return "NPC赛程日期声明无效"
		if row.date_status == "exact" and not Dates.valid_range(row.start_date,row.end_date): return "NPC赛程日期无效"
		if row.choice in ["request","pending_assignment"] and row.date_status != "exact": return "不能为未知日期建立NPC参赛请求"
		if not PolicyRepository.number(row.get("money_cost"),0,1000): return "NPC参赛费用无效"
	for id in plan.fee_receipts:
		var receipt = plan.fee_receipts[id]
		if not plan.events.has(id) or not receipt is Dictionary: return "NPC实际参赛回执无效"
		var row: Dictionary = plan.events[id]
		if receipt.get("event_id") != id or receipt.get("athlete_id") != plan.athlete_id or receipt.get("source") != "actual_complete_sp_start" or not receipt.get("qualified") is bool: return "NPC实际参赛来源无效"
		if not PolicyRepository.number(receipt.get("money_cost"),0,1000) or float(receipt.money_cost) != float(row.money_cost) or receipt.get("start_date") != row.start_date or receipt.get("end_date") != row.end_date: return "NPC实际参赛费用或日期不一致"
	if plan.content_sha256 != _hash(plan): return "NPC已公布赛程内容哈希不一致"
	return ""
