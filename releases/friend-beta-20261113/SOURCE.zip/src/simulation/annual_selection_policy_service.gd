class_name AnnualSelectionPolicyService
extends RefCounted
const Repository = preload("res://src/content/annual_selection_policy_repository.gd")

static func second_start_band(allowance: Dictionary) -> Dictionary:
	var minimum := 11 if int(allowance.per_station) >= 2 else 7 if int(allowance.stations) >= 5 else 3
	return {"minimum_first_points":minimum,"place":3 if minimum == 11 else 5 if minimum == 7 else 8}

static func validate_snapshot(snapshot, expected_season: String = "") -> String:
	if not snapshot is Dictionary or not snapshot.get("payload") is Dictionary: return "年度政策快照必须为对象"
	var error := Repository.validate(snapshot.payload)
	if not error.is_empty(): return error
	if not expected_season.is_empty() and snapshot.payload.season_id != expected_season: return "年度政策快照不属于所在赛季"
	if not snapshot.get("content_sha256") is String or snapshot.content_sha256 != Repository.content_hash(snapshot.payload): return "年度政策快照内容哈希不一致"
	var clock = snapshot.get("published_clock")
	if not clock is Dictionary or not Repository.integer(clock.get("year"),1,9999) or not Repository.integer(clock.get("quarter"),1,4): return "年度政策公告时钟无效"
	return ""

static func prepare_publication(career, season: String) -> Dictionary:
	if career.season_state.has("selection_policy"):
		var snapshot = career.season_state.selection_policy
		var container := str(career.season_state.get("season_id",""))
		if container.is_empty(): return {"snapshot":{},"status":"invalid","errors":["年度政策缺少所属赛季"]}
		var error := validate_snapshot(snapshot,container)
		if not error.is_empty(): return {"snapshot":{},"status":"invalid","errors":[error]}
		if snapshot.payload.season_id != season: return {"snapshot":{},"status":"invalid","errors":["请先归档旧赛季公告，再发布下一赛季制度"]}
		return {"snapshot":snapshot.duplicate(true),"status":"frozen","errors":[],"new_publication":false}
	var loaded := Repository.load_for_season(season)
	if not loaded.errors.is_empty() or not loaded.covered: return {"snapshot":{},"status":"uncovered","errors":loaded.errors,"new_publication":false}
	var already_confirmed: bool = career.season_program_plan.get("status") == "confirmed" and career.season_program_plan.get("season_id") == season
	var already_played: bool = career.competition_archive.any(func(a):return a.get("season_id") == season and a.get("status") == "complete")
	if already_confirmed or already_played or not career.selection_state.get("decisions",{}).is_empty():
		return {"snapshot":{},"status":"legacy_unfrozen","errors":[],"new_publication":false}
	# Set the game-standard band before publication from the preceding Worlds
	# receipt. A published snapshot is returned above and never recalculated.
	if season == "2022-23" and loaded.policy.targets.jgp.has("second_start"):
		for archive in career.competition_archive:
			if archive.get("event_id") != "isu_world_junior_2022": continue
			var quota := preload("res://src/simulation/junior_grand_prix_quota_service.gd").from_world_junior(archive)
			if not quota.errors.is_empty(): continue
			var allowance: Dictionary = quota.countries.get("CHN",quota.non_participant)
			var band := second_start_band(allowance)
			var minimum: int = band.minimum_first_points
			var place: int = band.place
			var model: Dictionary = loaded.policy.targets.jgp.second_start
			model.minimum_first_points = minimum
			model.policy_version = 2
			model.association_basis = {"source_event_id":quota.source_event_id,"source_fingerprint":quota.source_fingerprint,"allowance":allowance.duplicate(true)}
			var calendar := preload("res://src/content/season_calendar_repository.gd").load_international_calendar(2022,"women_singles","junior")
			var events: Array = calendar.get("calendar",{}).get("events",[]).filter(func(e):return e.get("event_family") == "jgp_stage" and e.get("status") != "cancelled" and not e.get("reference_only",false))
			events.sort_custom(func(a,b):return a.start_date < b.start_date)
			events = events.slice(0,int(allowance.stations))
			var split := maxi(1,events.size()/2)
			if events.size() > split:
				var first_end: String = events[split-1].end_date
				var second_start: String = events[split].start_date
				var gap := int((Time.get_unix_time_from_datetime_string(second_start)-Time.get_unix_time_from_datetime_string(first_end))/86400)
				model.confirmation_days_before_start = maxi(1,mini(7,gap-1))
				model.confirmation_timing_basis = {"first_phase_end":first_end,"next_station_start":second_start,"gap_days":gap,"source_kind":"game_setting","reason":"首站结束后至少保留一天国内决策时间，官方姓名报名期限不变"}
			model.label = "非官方分层游戏政策：按上一届世青赛协会权益在赛季初锁定；本协会%d站、每站%d人。首站前%d（至少%d积分）进入第二站优先池；未首发合格候补填剩余名额，积分、总分、自由滑、固定身份排序。须提前列入正式/候补姓名名单，赛前%d天国内改派确认截止；官方姓名报名期限不变。" % [int(allowance.stations),int(allowance.per_station),place,minimum,int(model.confirmation_days_before_start)]
			break
	var snapshot := {"payload":loaded.policy.duplicate(true),"content_sha256":Repository.content_hash(loaded.policy),"published_clock":career.clock.to_dict()}
	if career.competition_timeline.mode == "dated": snapshot.published_date = career.competition_timeline.date
	return {"snapshot":snapshot,"status":"frozen","errors":[],"new_publication":true}

static func effective(career, year: int) -> Dictionary:
	var season := Repository.season_id(year)
	var snapshot = {}
	if career != null and career.season_state.has("selection_policy"):
		var active = career.season_state.selection_policy
		var container := str(career.season_state.get("season_id",""))
		var active_error := "年度政策缺少所属赛季" if container.is_empty() else validate_snapshot(active,container)
		if not active_error.is_empty(): return {"policy":{},"status":"invalid","content_sha256":"","errors":[active_error]}
		if active.payload.season_id == season: snapshot = active
	if snapshot.is_empty() and career != null:
		var historical = career.season_state.get("season_history",{}).get(season,{}).get("season",{})
		if historical.has("selection_policy"):
			if historical.get("season_id") != season: return {"policy":{},"status":"invalid","content_sha256":"","errors":["历史年度政策所属赛季不一致"]}
			snapshot = historical.selection_policy
	if not snapshot is Dictionary or not snapshot.is_empty():
		var error := validate_snapshot(snapshot,season)
		if not error.is_empty(): return {"policy":{},"status":"invalid","content_sha256":"","errors":[error]}
		return {"policy":snapshot.payload.duplicate(true),"status":"frozen","content_sha256":snapshot.content_sha256,"errors":[]}
	var loaded := Repository.load_for_season(season)
	return {"policy":loaded.policy,"status":"legacy_unfrozen" if loaded.covered else "uncovered","content_sha256":Repository.content_hash(loaded.policy) if loaded.covered else "","errors":loaded.errors}

static func target(career, kind: String, year: int) -> Dictionary:
	var result := effective(career,year)
	result.target = result.policy.get("targets",{}).get(kind,{}).duplicate(true)
	return result

static func public_formula(policy: Dictionary, kind: String) -> String:
	var target: Dictionary = policy.get("targets",{}).get(kind,{})
	if target.is_empty(): return "当季目标未覆盖"
	if kind == "world_junior":
		var pieces: Array[String] = []
		for id in target.designated_event_ids:
			pieces.append(("全国锦标赛" if str(id).contains("national_championships") else "U系列" if str(id).contains("u_series") else str(id))+"总分%d%%" % int(round(float(target.weights[id])*100.0)))
		return "游戏公开世青标准：%d年第%d季度选拔，季度截止（精确日期未核实）；须齐备指定赛事完整成绩。%s；最低%s分。相同权重的自由滑同分优先，再按公开种子抽签。中国%d名。" % [int(target.window.year),int(target.window.quarter)," + ".join(pieces),String.num(float(target.minimum_score),6).trim_suffix(".0"),int(target.places)]
	var d: Dictionary = target.development
	var formula := "游戏公开选拔（非官方办法）：最低%s分；前%d席按指定赛最佳完整总分、同场自由滑、公开抽签排序。发展观察席为%d–%d岁，须至少%d场完整指定赛：最早完整成绩至最佳成绩增幅（上限%s%%）×%s，加年龄分（%d减年龄）×%s、上限%s分，加冰场支持×%s（上限%s分）；无合格者回归成绩席。比赛分数不变，每人最多%d站，每站中国%d名。" % [String.num(float(target.minimum_score),6).trim_suffix(".0"),int(d.merit_places),int(d.minimum_age),int(d.maximum_age),int(d.minimum_complete_events),float(d.growth_cap)*100.0,float(d.growth_factor),int(d.age_origin),float(d.age_factor),float(d.age_cap),float(d.access_factor),float(d.access_cap),int(target.max_starts),int(target.station_places)]
	if target.has("second_start"): formula += " 首轮仅一站。"+str(target.second_start.label)
	return formula
