class_name SeasonProgramService
extends RefCounted

const Plan = preload("res://src/domain/season_program_plan.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Repertoire = preload("res://src/domain/technical_repertoire.gd")

static func planning_node(career, bundle: Dictionary) -> Dictionary:
	var calendar: Dictionary = bundle.get("calendar",{})
	if calendar.get("events",[]).is_empty(): return {}
	var first_year := 9999
	for event in calendar.events:
		var date := str(event.get("start_date",""))
		if date.length() >= 4 and date.substr(0,4).is_valid_int(): first_year = mini(first_year,int(date.substr(0,4)))
	if first_year == 9999: first_year = int(calendar.get("calendar_year",career.clock.year))
	if career.clock.year < first_year-1: return {}
	var season_id := str(calendar.get("season_id",""))
	if season_id.is_empty(): return {}
	if career.season_program_plan.get("status") == "confirmed" and career.season_program_plan.get("season_id") == season_id: return {}
	return {"kind":"season_program_planning","season_id":season_id,"reason":"先确定下季节目方向，教练会据此安排专项；未掌握的目标不会直接变成比赛储备。","choices":[{"id":"retain","label":"沿用节目，继续打磨"},{"id":"upgrade","label":"沿用音乐，调整难度与目标"},{"id":"new_program","label":"编排新节目"}]}

static func preview(career, season_id: String, mode: String, programs: Dictionary, targets: Dictionary, competitive_level: String = "", programs_by_level: Dictionary = {}) -> Dictionary:
	var errors: Array[String] = []
	var mapping_error := Plan.validate_group_programs(programs_by_level)
	if not mapping_error.is_empty(): errors.append(mapping_error)
	if competitive_level.is_empty(): competitive_level = preload("res://src/simulation/competitive_level_service.gd").current(career)
	var level_error := preload("res://src/simulation/competitive_level_service.gd").validate_choice(career,season_id,competitive_level)
	if not level_error.is_empty(): errors.append(level_error)
	var planned_programs := programs.duplicate(true)
	if season_id.is_empty() or not mode in ["retain","upgrade","new_program"]: errors.append("赛季或规划方式无效")
	for segment in programs:
		if not str(segment) in ["short","free"] or not programs[segment] is Dictionary:
			errors.append("节目必须按短节目和自由滑分别规划")
			continue
		if programs[segment].is_empty():
			planned_programs.erase(segment)
			continue
		var program = Program.from_dict(programs[segment])
		if program == null or program.segment != segment: errors.append("节目数据无效")
	for segment in targets:
		if not str(segment) in ["short","free"] or not targets[segment] is Array:
			errors.append("专项目标格式无效")
			continue
		if targets[segment].size() > 32:
			errors.append("专项目标过多")
			continue
		for target in targets[segment]:
			if not target is Dictionary or not target.get("action") is Dictionary or str(target.action.get("kind","")) != "jump" or Repertoire.action_id(target.action).is_empty():
				errors.append("专项必须是明确的跳跃或有序连跳")
				continue
			for part in target.action.parts:
				if int(part.rotations) > int(career.athlete.jumps[part.jump_id].unlocked_rotations)+1: errors.append("%s跨度过大，先练好前置周数" % Repertoire.action_id(target.action))
	var grouped := programs_by_level.duplicate(true)
	if grouped.is_empty() and career.season_program_plan.get("season_id") == season_id:
		grouped = Dictionary(career.season_program_plan.get("programs_by_level",{})).duplicate(true)
	var primary := "senior" if competitive_level == "senior" else "junior"
	grouped[primary] = planned_programs.duplicate(true)
	return {"season_id":season_id,"mode":mode,"competitive_level":competitive_level,"programs":planned_programs,"programs_by_level":grouped,"targets":targets.duplicate(true),"base_revision":int(career.season_program_plan.get("revision",0)),"errors":errors}

static func confirm(career, draft: Dictionary, receipt_id: String) -> Dictionary:
	if receipt_id.is_empty(): return {"ok":false,"error":"缺少赛季确认凭据"}
	var state: Dictionary = career.season_program_plan
	var hash_data := {"season_id":draft.get("season_id"),"mode":draft.get("mode"),"programs":draft.get("programs"),"targets":draft.get("targets")}
	if draft.has("competitive_level"): hash_data.competitive_level = draft.competitive_level
	if draft.has("programs_by_level"): hash_data.programs_by_level = draft.programs_by_level
	var fingerprint := JSON.stringify(hash_data).sha256_text()
	if state.get("receipts",[]).has(receipt_id):
		return {"ok":state.get("confirmation_hash","") == fingerprint,"error":"确认凭据已用于不同方案" if state.get("confirmation_hash","") != fingerprint else ""}
	if not draft.get("programs") is Dictionary or not draft.get("targets") is Dictionary: return {"ok":false,"error":"规划内容无效"}
	var group_error := Plan.validate_group_programs(draft.get("programs_by_level",{}))
	if not group_error.is_empty(): return {"ok":false,"error":group_error}
	if int(draft.get("base_revision",-1)) != int(state.get("revision",0)): return {"ok":false,"error":"规划版本已过期，请重新预览"}
	var checked := preview(career,str(draft.get("season_id","")),str(draft.get("mode","")),draft.programs,draft.targets,str(draft.get("competitive_level","")),draft.get("programs_by_level",{}))
	if not checked.errors.is_empty(): return {"ok":false,"error":"；".join(checked.errors)}
	var publication := preload("res://src/simulation/annual_selection_policy_service.gd").prepare_publication(career,checked.season_id)
	if not publication.errors.is_empty(): return {"ok":false,"error":"；".join(publication.errors)}
	# Prepare NPC world/plans before mutating this publication transaction.
	# Prior season starts remain historical; no plans are created on load.
	var planned_world = null
	if publication.get("new_publication",false):
		planned_world = career.transaction_copy()
		planned_world.season_state.season_id = checked.season_id
		planned_world.season_state.selection_policy = publication.snapshot.duplicate(true)
		var season_year := int(checked.season_id.get_slice("-",0))
		var bundle := preload("res://src/content/season_bundle_repository.gd").load_bundle(season_year,"women_singles","junior")
		if not bundle.errors.is_empty(): return {"ok":false,"error":"；".join(bundle.errors)}
		var planned := preload("res://src/simulation/world_generation_service.gd").ensure_season(planned_world,bundle,int(career.world_state.get("world_seed",career.seed)))
		if not planned.errors.is_empty(): return {"ok":false,"error":"；".join(planned.errors)}
	var next := Plan.create(checked.season_id)
	next.status = "confirmed"
	next.competitive_level = checked.competitive_level
	next.revision = int(state.get("revision",0))+1
	next.programs = checked.programs.duplicate(true)
	next.programs_by_level = checked.programs_by_level.duplicate(true)
	next.targets = checked.targets.duplicate(true)
	next.receipts = [receipt_id]
	next.confirmation_hash = fingerprint
	# Future difficulty is deliberately stored only in targets.
	var primary := "senior" if checked.competitive_level == "senior" else "junior"
	var previous_primary := "senior" if preload("res://src/simulation/competitive_level_service.gd").current(career) == "senior" else "junior"
	var previous_groups: Dictionary = Dictionary(state.get("programs_by_level",{})).duplicate(true)
	previous_groups[previous_primary] = career.active_programs.duplicate(true)
	if primary != previous_primary:
		# The selected group's confirmed layout is its own programme, not a
		# revision of the other group's training programme.
		career.active_programs = checked.programs.duplicate(true)
	elif checked.mode != "retain":
		for segment in checked.programs:
			var edited = Program.from_dict(checked.programs[segment])
			var existing = Program.from_dict(career.active_programs.get(segment,{}))
			if existing != null and existing.to_dict() == edited.to_dict(): continue
			if existing == null: career.active_programs[segment] = edited.to_dict()
			else:
				var revision: Dictionary = preload("res://src/simulation/program_draft_service.gd").save_draft(existing,edited)
				if not revision.errors.is_empty(): return {"ok":false,"error":"；".join(revision.errors)}
				career.active_programs[segment] = revision.program.to_dict()
				if revision.archived != null: career.program_archive.append(revision.archived.to_dict())
	# Store the actual confirmed primary, including its training progress.
	next.programs = career.active_programs.duplicate(true)
	for segment in next.programs.keys():
		if next.programs[segment].is_empty(): next.programs.erase(segment)
	next.programs_by_level[primary] = next.programs.duplicate(true)
	for level in next.programs_by_level:
		if level == primary: continue
		for segment in next.programs_by_level[level]:
			var edited = Program.from_dict(next.programs_by_level[level][segment])
			var existing = Program.from_dict(previous_groups.get(level,{}).get(segment,{}))
			if existing != null and existing.to_dict() != edited.to_dict():
				var revision := preload("res://src/simulation/program_draft_service.gd").save_draft(existing,edited)
				if not revision.errors.is_empty(): return {"ok":false,"error":"；".join(revision.errors)}
				edited = revision.program
				if revision.archived != null: career.program_archive.append(revision.archived.to_dict())
			var rules := preload("res://src/content/internal_event_rules.gd").for_season(int(checked.season_id.get_slice("-",0)),level,segment)
			next.programs_by_level[level][segment] = edited.to_dict()
			var locked := preload("res://src/simulation/program_draft_service.gd").lock_for_competition(edited,career.athlete,rules)
			if locked.errors.is_empty(): next.programs_by_level[level][segment] = locked.program.to_dict()
	if planned_world != null:
		career.world_athletes = planned_world.world_athletes
		career.world_state = planned_world.world_state
	career.season_program_plan = next
	if not publication.snapshot.is_empty():
		career.season_state.season_id = checked.season_id
		career.season_state.selection_policy = publication.snapshot.duplicate(true)
	if publication.get("new_publication",false):
		career.event_ledger.append({"kind":"selection_policy_published","season_id":checked.season_id,"policy_id":publication.snapshot.payload.policy_id,"content_sha256":publication.snapshot.content_sha256,"clock":career.clock.to_dict(),"source_kind":"game_setting"})
	career.event_ledger.append({"kind":"season_program_confirmed","season_id":checked.season_id,"mode":checked.mode,"clock":career.clock.to_dict()})
	if checked.season_id == "2022-23":
		career.season_state["content_pack"] = {"world_mode":"historical_pilot","rule_era":"event_specific","content_pack_version":2}
		var quota_history: Dictionary = career.selection_state.get("jgp_base_quota_history", {})
		if not quota_history.has(checked.season_id):
			for archive in career.competition_archive:
				if archive.get("event_id") != "isu_world_junior_2022": continue
				var quota := preload("res://src/simulation/junior_grand_prix_quota_service.gd").from_world_junior(archive)
				if quota.errors.is_empty():
					quota_history[checked.season_id] = quota
					career.selection_state.jgp_base_quota_history = quota_history
				break
	return {"ok":true,"events":[]}

static func programs_for_event(career, event: Dictionary) -> Dictionary:
	var level := preload("res://src/simulation/competitive_level_service.gd").event_level(career,event)
	var groups: Dictionary = career.season_program_plan.get("programs_by_level",{})
	var primary := "senior" if preload("res://src/simulation/competitive_level_service.gd").current(career) == "senior" else "junior"
	if groups.has(level):
		return career.active_programs.duplicate(true) if level == primary else Dictionary(groups[level]).duplicate(true)
	if not groups.is_empty(): return {}
	# Old plans predate separate group storage. Keep their primary programme,
	# but do not silently reuse a junior layout for a transition senior start.
	return career.active_programs.duplicate(true) if level == primary else {}

static func store_event_program(career, event: Dictionary, segment: String, data: Dictionary) -> Dictionary:
	var program = Program.from_dict(data)
	if segment not in ["short","free"] or program == null or program.segment != segment: return {"ok":false,"error":"节目数据无效"}
	var resolved := preload("res://src/content/season_bundle_repository.gd").competition_for_career(career,event)
	if not resolved.errors.is_empty(): return {"ok":false,"error":"；".join(resolved.errors)}
	var level := str(resolved.event.competition_level)
	var primary := "senior" if preload("res://src/simulation/competitive_level_service.gd").current(career) == "senior" else "junior"
	if not career.season_program_plan.has("programs_by_level"):
		career.season_program_plan.programs_by_level = {primary:career.active_programs.duplicate(true)}
	if not career.season_program_plan.programs_by_level.has(level): career.season_program_plan.programs_by_level[level] = {}
	career.season_program_plan.programs_by_level[level][segment] = program.to_dict()
	if level == primary: career.active_programs[segment] = program.to_dict()
	return {"ok":true,"error":""}
