class_name JumpTrainingSimulator
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")

const ROTATION_KEYS := {1: "single", 2: "double", 3: "triple", 4: "quad"}
# Quarterly training abstraction: one recorded attempt represents a supervised
# practice block, not a claim that a real athlete learns 0.60 skill per jump.
# A player makes only one training decision per quarter, so its payoff must be
# visible at game speed even though maturation, readiness and supervision still
# prevent young or unprepared athletes from skipping the development process.
const PROFICIENCY_GAIN_PER_ATTEMPT := 0.60

static func apply(
	career,
	jump_id: String,
	rotations: int,
	attempts: int,
	supervision: float,
	rng: RandomNumberGenerator,
	record_legacy_progress: bool = true,
) -> Array[OutcomeRecord]:
	var outcomes: Array[OutcomeRecord] = []
	if not JumpCatalog.JUMP_IDS.has(jump_id) or not ROTATION_KEYS.has(rotations) or attempts <= 0:
		return outcomes
	var profile = career.athlete.jumps[jump_id]
	var rotation_key: String = ROTATION_KEYS[rotations]
	var body: Dictionary = career.athlete.body
	var readiness := clampf(
		0.30 * float(body.strength_readiness)
		+ 0.25 * float(body.joint_readiness)
		+ 0.20 * float(profile.air.axis)
		+ 0.15 * float(profile.landing.control)
		+ 0.10 * float(profile.proficiency[rotation_key]),
		0.0,
		100.0,
	)
	var difficulty_gap := maxf(0.0, rotations * 25.0 - readiness)
	var impact_delta := attempts * (0.08 + rotations * 0.04) * (1.0 + difficulty_gap / 100.0)
	var previous_impact := float(body.impact_load)
	body.impact_load = clampf(previous_impact + impact_delta, 0.0, 100.0)
	var causes: Array[String] = ["%s_practice" % jump_id, "%d_rotation_attempt" % rotations]
	if difficulty_gap > 0.0:
		causes.append("readiness_gap")
	outcomes.append(OutcomeRecord.new("body", "impact_load", body.impact_load - previous_impact, causes, "impact_load_change"))

	var previous_proficiency := float(profile.proficiency[rotation_key])
	var gain := attempts * PROFICIENCY_GAIN_PER_ATTEMPT * clampf(supervision, 0.0, 1.15) * rng.randf_range(0.9, 1.1)
	gain *= clampf(1.0 - difficulty_gap / 125.0, 0.1, 1.0)
	gain *= load("res://src/simulation/jump_maturation.gd").factor(career,jump_id,rotations)
	profile.proficiency[rotation_key] = clampf(previous_proficiency + gain, 0.0, 100.0)
	# Practice already pays for volume, supervision, fatigue, age and medical
	# limitations upstream. Transfer part of its actual skill gain into execution
	# dimensions read by competition, with diminishing returns below perfection.
	# Actual supervised practice continues after a difficulty's familiarity
	# reaches its cap. Otherwise early-learned doubles permanently freeze air,
	# landing and official consistency and can never qualify for triples.
	var learned := maxf(0.0,gain)
	for group in ["air","landing"]:
		var metrics: Dictionary = profile.get(group)
		for key in metrics:
			var previous := float(metrics[key])
			metrics[key] = minf(95.0,previous + learned * (1.0 - previous / 100.0)) if previous < 95.0 else previous
	for key in profile.consistency:
		var previous := float(profile.consistency[key])
		var transfer := 1.0 if key == "training" else (0.7 if key == "internal" else 0.45)
		profile.consistency[key] = minf(95.0,previous + learned * transfer * (1.0 - previous / 100.0)) if previous < 95.0 else previous
	if record_legacy_progress:
		profile.attempts += attempts
		if rotations > profile.unlocked_rotations and profile.proficiency[rotation_key] >= 1.0:
			profile.unlocked_rotations = rotations
	outcomes.append(OutcomeRecord.new(
		"jump_training",
		"%s.%s.proficiency" % [jump_id, rotation_key],
		float(profile.proficiency[rotation_key]) - previous_proficiency,
		causes,
		"jump_proficiency_change",
	))
	return outcomes
