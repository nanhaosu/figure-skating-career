class_name JumpMaturation
extends RefCounted

# Shared training-readiness curve, not an eligibility rule. A young athlete can
# still succeed exceptionally; ordinary doubles retain their existing model.
# Axel's extra half-turn and each further revolution require more maturation.
static func factor(career, jump_id: String, rotations: int) -> float:
	if rotations < 3: return 1.0
	var extra_turns := float(rotations-3) + (0.5 if jump_id == "axel" else 0.0)
	var body: Dictionary = career.athlete.body
	var foundation: Dictionary = career.athlete.jump_foundation.to_dict()
	var preparation := float(body.strength_readiness)*0.35 + float(body.joint_readiness)*0.35
	preparation += (float(foundation.air_axis)+float(foundation.rotation_completion)+float(foundation.landing_control))/3.0*0.30
	var physical := 0.30+0.70*clampf((preparation-15.0-extra_turns*35.0)/40.0,0.0,1.0)
	return age_factor(career,jump_id,rotations)*physical

static func age_factor(career, jump_id: String, rotations: int) -> float:
	if rotations < 3: return 1.0
	var extra_turns := float(rotations-3) + (0.5 if jump_id == "axel" else 0.0)
	var age: float = career.clock.age_on(career.athlete.birth_year)-extra_turns*4.0
	var maturity := 0.001
	if age >= 12.0: maturity = 1.0
	elif age >= 11.0: maturity = 0.80
	elif age >= 10.0: maturity = 0.35
	elif age >= 9.0: maturity = 0.08
	return maturity
