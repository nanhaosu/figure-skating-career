class_name ProgramPerformanceSimulator
extends RefCounted

const CompetitionRecoveryDecisionService = preload("res://src/simulation/competition_recovery_decision_service.gd")

const ROTATION_KEYS := {1: "single", 2: "double", 3: "triple", 4: "quad"}
const JUMP_CODES := {"toe_loop": "T", "salchow": "S", "loop": "Lo", "flip": "F", "lutz": "Lz", "axel": "A"}
const BASE_VALUES_2014 := {
	"1T": 0.40, "2T": 1.30, "3T": 4.10, "4T": 10.30,
	"1S": 0.40, "2S": 1.30, "3S": 4.20, "4S": 10.50,
	"1Lo": 0.50, "2Lo": 1.80, "3Lo": 5.10, "4Lo": 12.00,
	"1F": 0.50, "2F": 1.90, "3F": 5.30, "4F": 12.30,
	"1Lz": 0.60, "2Lz": 2.10, "3Lz": 6.00, "4Lz": 13.60,
	"1A": 1.10, "2A": 3.30, "3A": 8.50, "4A": 15.00,
}

static func simulate(athlete, program, strategy: Dictionary, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var result := {"program_id":program.program_id,"segment":program.segment,"segment_rules":Dictionary(context.get("segment_rules",{})).duplicate(true),"elements":[],"falls":0,"fatigue_end":0.0,"decision_events":[],"recovery_state":{}}
	var running_fatigue := float(context.get("starting_fatigue", athlete.body.get("acute_fatigue", 0.0)))
	# Simulation only adds top-level overrides. Nested rules and catalogues are read-only.
	var simulation_context := context.duplicate()
	running_fatigue += float(context.get("execution_penalty", 0.0))
	running_fatigue += float(context.get("program_load", {}).get("execution_penalty", 0.0))
	simulation_context.late_bonus_element_ids = _late_bonus_element_ids(program, context)
	var recovery_state := CompetitionRecoveryDecisionService.new_state(program)
	for index in program.elements.size():
		var element = program.elements[index]
		var record: Dictionary
		if element.kind == "jump":
			var action_context := simulation_context.duplicate()
			action_context.merge({"index":index,"starting_fatigue":running_fatigue,"strategy":strategy,"recovery_state":recovery_state},true)
			var action := {"kind":"jump","parts":[{"jump_id":element.jump_id,"rotations":element.rotations}],"element":element.to_dict()}
			action.parts.append_array(element.combination_parts)
			record = execute_jump_action(athlete,program,action,action_context,rng)
		else:
			record = _simulate_non_jump(athlete, program, element, index, running_fatigue, rng)
		if record.has("recovery_state"):
			recovery_state = Dictionary(record.recovery_state).duplicate(true)
			record.erase("recovery_state")
		result.elements.append(record)
		if record.actual.get("fall", false): result.falls += 1
		running_fatigue += float(record.fatigue_cost)
	result.fatigue_end = snappedf(running_fatigue, 0.01)
	result.decision_events = Array(recovery_state.get("decision_events",[])).duplicate(true)
	result.recovery_state = recovery_state
	return result

# Both programme execution and specialist practice use the same landing,
# continuation and second-jump mechanics. No second combo-success dice model.
static func execute_jump_action(athlete, program, action: Dictionary, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var element
	if action.get("element") is Dictionary:
		element = preload("res://src/domain/program_element.gd").from_dict(action.element)
	else:
		var first: Dictionary = action.parts[0]
		element = preload("res://src/domain/program_element.gd").create("specialist","jump",first.jump_id,int(first.rotations)).element
		element.set_combination_parts(action.parts.slice(1))
	var recovery: Dictionary = context.get("recovery_state",CompetitionRecoveryDecisionService.new_state(program))
	return _simulate_jump(athlete,program,element,int(context.get("index",0)),float(context.get("starting_fatigue",athlete.body.acute_fatigue)),context.get("strategy",{}),context,recovery,rng)

static func _simulate_jump(athlete, program, element, index: int, fatigue: float, strategy: Dictionary, context: Dictionary, recovery_state: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var planned_parts: Array[Dictionary] = [{"jump_id": element.jump_id, "rotations": element.rotations}]
	for part in element.combination_parts: planned_parts.append(Dictionary(part).duplicate(true))
	var parts: Array[Dictionary] = []
	var running_fatigue := fatigue
	var connection_modifier := 0.0
	var first_record := _simulate_jump_part(athlete,program,element.element_id,planned_parts[0],index,0,running_fatigue,connection_modifier,strategy,context,rng)
	parts.append(first_record)
	running_fatigue += float(first_record.fatigue_cost)
	var decision: Dictionary = {}
	var selected_parts: Array = []
	if planned_parts.size() > 1:
		decision = CompetitionRecoveryDecisionService.decide_immediate_continuation(athlete,program,element,_decision_part(first_record),planned_parts.slice(1),recovery_state,context,rng)
		selected_parts = Array(decision.selected_parts).duplicate(true); recovery_state = Dictionary(decision.state).duplicate(true)
	elif not Array(recovery_state.get("owed_parts",[])).is_empty():
		decision = CompetitionRecoveryDecisionService.decide_deferred_recovery(athlete,program,element,_decision_part(first_record),recovery_state,context,rng)
		selected_parts = Array(decision.selected_parts).duplicate(true); recovery_state = Dictionary(decision.state).duplicate(true)
	for selected_index in selected_parts.size():
		if bool(parts.back().actual.get("fall",false)): break
		connection_modifier = _connection_modifier(parts.back(),athlete,selected_parts[selected_index])
		var part_record := _simulate_jump_part(athlete,program,element.element_id,selected_parts[selected_index],index,selected_index+1,running_fatigue,connection_modifier,strategy,context,rng)
		parts.append(part_record)
		running_fatigue += float(part_record.fatigue_cost)
	var interrupted := planned_parts.size() > 1 and parts.size() < planned_parts.size()
	var actual_parts: Array = parts.map(func(part): return {
		"jump_id": str(part.get("jump_id", "")),
		"called_rotations": int(part.get("called_rotations", 0)),
		"abbreviation": str(part.get("abbreviation", "")),
	})
	recovery_state = CompetitionRecoveryDecisionService.record_completed_slot(recovery_state,element,actual_parts)
	var abbreviations: Array[String] = []
	var planned_abbreviations: Array[String] = []
	var base_value := 0.0
	var live_goe := 0.0
	var fatigue_cost := 0.0
	var review_reasons: Array[String] = []
	var has_error := interrupted
	var has_review := false
	var success_probability := 0.96
	var fall := false
	var error_type := ""
	for part in parts:
		abbreviations.append(str(part.abbreviation))
		base_value += float(part.base_value)
		live_goe += float(part.live_goe)
		fatigue_cost += float(part.fatigue_cost)
		success_probability = minf(success_probability, float(part.success_probability))
		fall = fall or bool(part.actual.get("fall", false))
		if error_type.is_empty() and not str(part.actual.get("error_type", "")).is_empty(): error_type = str(part.actual.error_type)
		if part.status == "error": has_error = true
		if part.status == "review": has_review = true
		for reason in part.review_reasons:
			if not review_reasons.has(reason): review_reasons.append(reason)
	for planned in planned_parts: planned_abbreviations.append("%d%s" % [int(planned.rotations), JUMP_CODES[str(planned.jump_id)]])
	var segment_rules: Dictionary = context.get("segment_rules", {})
	var sequences_allowed: bool = segment_rules.get("segment") == "free" and segment_rules.get("axel_sequence_allowed", false)
	var planned_sequence: bool = sequences_allowed and planned_parts.slice(1).any(func(part): return part.jump_id == "axel")
	var actual_sequence: bool = sequences_allowed and parts.slice(1).any(func(part): return part.jump_id == "axel")
	var decision_evidence := decision.duplicate(true)
	decision_evidence.erase("state")
	return {
		"element_id": element.element_id, "kind": "jump", "index": index,
		"planned_abbreviation": "+".join(planned_abbreviations) + ("+SEQ" if planned_sequence else ""),
		"abbreviation": "+".join(abbreviations) + ("+SEQ" if actual_sequence else ""),
		"base_value": snappedf(base_value, 0.01), "live_goe": snappedf(live_goe, 0.01),
		"status": "review" if has_review else ("error" if has_error else "success"),
		"review_reasons": review_reasons, "success_probability": success_probability,
		"fatigue_before": fatigue, "fatigue_cost": snappedf(fatigue_cost, 0.01),
		"parts": parts, "combination_interrupted": interrupted,
		"actual": {"success": not has_error and not has_review, "fall": fall, "error_type": error_type, "takeoff_edge_quality": float(parts[0].actual.get("takeoff_edge_quality", 50.0))},
		"recovery_decision": decision_evidence, "recovery_state":recovery_state,
	}

static func _decision_part(part: Dictionary) -> Dictionary:
	return {"jump_id":str(part.get("jump_id","")),"planned_rotations":int(part.get("facts",{}).get("planned_rotations",part.get("called_rotations",1))),"called_rotations":int(part.get("called_rotations",1)),"error_type":str(part.get("actual",{}).get("error_type","")),"connection_held":bool(part.get("facts",{}).get("connection_held",true)),"fall":bool(part.get("actual",{}).get("fall",false))}

static func _simulate_jump_part(athlete, program, group_id: String, planned: Dictionary, index: int, part_index: int, fatigue: float, connection_modifier: float, strategy: Dictionary, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var jump_id := str(planned.jump_id)
	var rotations := int(planned.rotations)
	var profile = athlete.jumps[jump_id]
	var rotation_key: String = ROTATION_KEYS[rotations]
	var familiarity := (float(program.whole_run_familiarity) + float(program.slot_familiarity.get(group_id, 0.0))) * 0.5
	# Programme memory matters, but it must not outweigh the underlying jump the
	# athlete has trained for years. Low familiarity adds volatility instead of
	# erasing technical ability.
	var probability := _part_success_probability(athlete,program,group_id,planned,fatigue,connection_modifier,strategy,context)
	var untrained_overreach := rotations > int(profile.unlocked_rotations) and int(Dictionary(profile.attempt_evidence.get(rotation_key, {})).get("attempts", 0)) <= 0
	var success := false if untrained_overreach else rng.randf() < probability
	var fall := false
	var error_type := ""
	if untrained_overreach:
		# An athlete cannot conjure an unattempted extra rotation in competition.
		# The take-off still produces the nearest established jump, which then
		# participates in repetition rules exactly like any other actual call.
		error_type = "pop"
	elif not success:
		var roll := rng.randf()
		error_type = "fall" if roll < 0.34 else ("underrotated" if roll < 0.68 else ("two_foot" if roll < 0.84 else "pop"))
		fall = error_type == "fall"
	var edge_review := ["lutz", "flip"].has(jump_id) and float(profile.takeoff.edge_quality) >= 30.0 and float(profile.takeoff.edge_quality) <= 55.0
	var rotation_review := ["underrotated", "pop"].has(error_type)
	var review_reasons: Array[String] = []
	if edge_review: review_reasons.append("takeoff_edge")
	if rotation_review: review_reasons.append("rotation_completion")
	var status := "error" if not success and not rotation_review else ("review" if not review_reasons.is_empty() else "success")
	var called_rotations := maxi(1, rotations - 1) if error_type == "pop" else rotations
	if untrained_overreach: called_rotations = clampi(int(profile.unlocked_rotations), 1, maxi(1, rotations - 1))
	var abbreviation := "%d%s" % [called_rotations, JUMP_CODES[jump_id]]
	var scoring_catalog = context.get("scoring_catalog", {})
	var base_values: Dictionary = Dictionary(scoring_catalog.get("jump_base_values", {})) if scoring_catalog is Dictionary else {}
	var base_value := float(base_values.get(abbreviation, BASE_VALUES_2014.get(abbreviation, 0.0)))
	var quality := (float(profile.landing.control) + float(profile.air.axis) + familiarity) / 3.0
	var goe_factor := clampf((quality - 50.0) / 50.0, -1.0, 1.0)
	if not success: goe_factor = -0.55 if rotation_review else -0.85
	var live_goe := snappedf(base_value * goe_factor * 0.42, 0.01)
	var completed_rotation_ratio := 1.0
	if error_type == "underrotated": completed_rotation_ratio = 0.84
	elif error_type == "pop": completed_rotation_ratio = maxf(0.25, float(called_rotations) / float(rotations) - 0.04)
	var facts := {
		"planned_rotations": rotations,
		"completed_rotation_ratio": completed_rotation_ratio,
		"rotation_ratio": completed_rotation_ratio,
		"takeoff_edge_quality": float(profile.takeoff.edge_quality),
		"edge_quality": float(profile.takeoff.edge_quality),
		"landing_quality": snappedf((float(profile.landing.control) + float(profile.landing.flow)) * 0.5, 0.01),
		"fall": fall,
		"two_foot": error_type == "two_foot",
		"connection_held": part_index == 0 or connection_modifier > -12.0,
		"invalid": false,
		"late_bonus": Array(context.get("late_bonus_element_ids", [])).has(group_id),
	}
	if scoring_catalog is Dictionary and scoring_catalog.get("rotation_call_standard","") == "isu_2334":
		# A representative underrotation is0.35 of ONE turn, not16% of
		# whichever jump was planned. Keep the legacy generator unchanged.
		facts.missing_rotation_turns = 0.35 if error_type == "underrotated" else 0.0
		if error_type == "underrotated":
			facts.rotation_ratio = 1.0-0.35/float(rotations)
			facts.completed_rotation_ratio = facts.rotation_ratio
		if error_type == "pop":
			facts.executed_rotation_ratio = 0.96
			facts.executed_missing_rotation_turns = float(called_rotations)*0.04
	return {
		"element_id": "%s:%d" % [group_id, part_index], "kind": "jump", "jump_id": jump_id, "index": index, "part_index": part_index,
		"abbreviation": abbreviation, "called_rotations": called_rotations, "base_value": base_value, "live_goe": live_goe,
		"status": status, "review_reasons": review_reasons,
		"success_probability": probability, "fatigue_before": fatigue,
		"fatigue_cost": 1.2 + rotations * 0.8,
		"actual": {"success": success, "fall": fall, "error_type": error_type, "takeoff_edge_quality": float(profile.takeoff.edge_quality)},
		"facts": facts,
	}

static func estimate_combination_success_probability(athlete, program, element, context: Dictionary = {}) -> float:
	var planned_parts: Array[Dictionary] = [{"jump_id":element.jump_id,"rotations":element.rotations}]
	for part in element.combination_parts: planned_parts.append(Dictionary(part).duplicate(true))
	if planned_parts.size() <= 1: return 0.0
	var running_fatigue := float(context.get("starting_fatigue",athlete.body.get("acute_fatigue",0.0)))
	var connection_modifier := 0.0
	var combined_probability := 1.0
	var estimate_context := context.duplicate()
	if not estimate_context.has("pressure"): estimate_context.pressure = 35.0
	for part_index in planned_parts.size():
		var planned: Dictionary = planned_parts[part_index]
		combined_probability *= _part_success_probability(athlete,program,str(element.element_id),planned,running_fatigue,connection_modifier,{"risk":"balanced"},estimate_context)
		running_fatigue += 1.2 + int(planned.rotations) * 0.8
		if part_index + 1 < planned_parts.size():
			connection_modifier = _connection_modifier({"jump_id":planned.jump_id,"status":"success","actual":{"fall":false}},athlete,planned_parts[part_index+1])
	return clampf(combined_probability,0.01,0.96)

static func _part_success_probability(athlete, program, group_id: String, planned: Dictionary, fatigue: float, connection_modifier: float, strategy: Dictionary, context: Dictionary) -> float:
	var jump_id := str(planned.jump_id)
	var rotations := int(planned.rotations)
	var profile = athlete.jumps[jump_id]
	var rotation_key: String = ROTATION_KEYS[rotations]
	var familiarity := (float(program.whole_run_familiarity)+float(program.slot_familiarity.get(group_id,0.0)))*0.5
	var readiness := float(profile.proficiency.get(rotation_key,0.0))*0.48+float(profile.air.axis)*0.16+float(profile.landing.completion)*0.14+float(profile.landing.control)*0.12+familiarity*0.10
	var pressure := float(context.get("pressure",35.0))
	var consistency_key := "internal" if context.get("event_scope","formal") == "internal" else "official"
	var consistency: float = clampf(float(profile.consistency.get(consistency_key,50.0)),0.0,100.0)
	readiness += (consistency-50.0)*0.12*clampf(0.5+pressure/70.0,0.5,1.5)
	readiness += _attempt_evidence_bonus(profile,rotation_key)
	var risk_adjust := 5.0 if strategy.get("risk") == "conservative" else (-5.0 if strategy.get("risk") == "aggressive" else 0.0)
	var entry_pressure := float(context.get("entry_pressure_by_element",{}).get(group_id,0.0))
	var raw_probability := (readiness-float(rotations-1)*8.0-fatigue*0.28-pressure*0.08-entry_pressure+risk_adjust+connection_modifier)/100.0
	# The underlying score is deliberately demanding, but interpreting it as a
	# literal percentage made an established 65--75 level junior triple behave
	# like a newly attempted jump. Calibrate the score to competition outcomes
	# while retaining a hard non-zero failure chance at the top end.
	var function_factor: float = preload("res://src/simulation/athlete_function_service.gd").execution_factor(context.get("function_limits",{}),{"kind":"jump","parts":[planned]})
	return clampf(0.08 + raw_probability * 1.22,0.03,0.96)*function_factor

static func _attempt_evidence_bonus(profile, rotation_key: String) -> float:
	var evidence = profile.attempt_evidence.get(rotation_key, {})
	if not evidence is Dictionary:
		return 0.0
	var attempts := maxi(0, int(evidence.get("attempts", 0)))
	var successes := clampi(int(evidence.get("successes", 0)), 0, attempts)
	# A few lucky landings are not enough. Repeated landings across a meaningful
	# practice volume can add confidence, but never make the jump automatic.
	var volume_factor := clampf(float(attempts) / 120.0, 0.0, 1.0)
	var repeated_success_factor := clampf(float(successes) / 40.0, 0.0, 1.0)
	return 14.0 * volume_factor * repeated_success_factor

static func _connection_modifier(previous: Dictionary, athlete, next_planned: Dictionary) -> float:
	if bool(previous.actual.get("fall", false)): return -100.0
	var jump_id := str(previous.get("jump_id", ""))
	var landing_control := 50.0
	var combination_ability := 50.0
	if athlete.jumps.has(jump_id):
		landing_control = float(athlete.jumps[jump_id].landing.control)
		combination_ability = float(athlete.jumps[jump_id].landing.combination)
	# A loop must take off from the landing edge itself; a toe loop has the toe
	# assist available. This is a technique cost, not a separate grindable stat.
	var follower_penalty := -6.0 if str(next_planned.get("jump_id","")) == "loop" else 0.0
	return clampf(
		(landing_control - 50.0) * 0.08
		+ (combination_ability - 50.0) * 0.16
		+ follower_penalty
		- (14.0 if previous.status != "success" else 0.0),
		-28.0, 10.0,
	)

static func _simulate_non_jump(athlete, program, element, index: int, fatigue: float, rng: RandomNumberGenerator) -> Dictionary:
	var familiarity := float(program.slot_familiarity.get(element.element_id, 0.0))
	var technique := float(athlete.technique.get("rotation", 30.0)) if element.kind == "spin" else float(athlete.skating.get("deep_edge", 30.0))
	# Competition facts cross JSON save boundaries. Quantize the generated
	# quality before it becomes a committed record so parser ULP differences
	# cannot make an otherwise identical checkpoint compare unequal.
	var quality := snappedf(clampf(technique * 0.75 + familiarity * 0.25 - fatigue * 0.18 + rng.randf_range(-8.0, 8.0), 0.0, 100.0), 0.001)
	var abbreviation := str(element.spin_code) if element.kind == "spin" else ("StSq" if element.kind == "step_sequence" else "ChSq")
	var base_value := 2.50 if element.kind == "spin" else 2.60
	var level_review := quality >= 38.0 and quality <= 52.0
	var credited_features := clampi(int(floor(quality / 20.0)), 0, element.target_level)
	var feature_evidence: Array[Dictionary] = []
	if element.kind == "spin":
		var spin_id: String = {"CCoSp":"combination", "FCSp":"flying", "FSSp":"flying", "LSp":"layback", "CSp":"camel", "SSp":"sit", "USp":"upright"}.get(abbreviation, "combination")
		var proficiency := maxf(float(athlete.spins.get(spin_id, {}).get("proficiency", 0.0)), technique * 0.65)
		var foundation: Dictionary = athlete.spin_foundation
		var scores := {
			"position_control":proficiency * 0.5 + float(foundation.position_control) * 0.5,
			"centering":technique * 0.4 + float(foundation.centering) * 0.6,
			"difficult_variation":proficiency * 0.6 + float(foundation.flexibility) * 0.4,
			"entry_exit":proficiency * 0.5 + float(foundation.entry_exit) * 0.5,
		}
		credited_features = 0
		for feature in scores:
			var execution := snappedf(float(scores[feature]) - fatigue * 0.12 - (100.0 - familiarity) * 0.04 + rng.randf_range(-7.0, 7.0), 0.001)
			var credited := execution >= 48.0
			feature_evidence.append({"feature":feature, "execution":execution, "credited":credited})
			if credited: credited_features += 1
		credited_features = mini(credited_features, element.target_level)
		quality = snappedf(clampf(technique * 0.4 + proficiency * 0.5 + familiarity * 0.1 - fatigue * 0.18 + rng.randf_range(-6.0, 6.0), 0.0, 100.0), 0.001)
	if element.kind == "step_sequence":
		var skating: Dictionary = athlete.skating
		var scores := {
			"turns":float(skating.turns),
			"deep_edges":float(skating.deep_edge),
			"one_foot_control":float(skating.one_foot_stability),
			"continuous_flow":float(skating.flow)*0.6 + float(skating.knee_action)*0.4,
		}
		credited_features = 0
		for feature in scores:
			var execution := snappedf(float(scores[feature]) - fatigue*0.12 - (100.0-familiarity)*0.04 + rng.randf_range(-7.0,7.0), 0.001)
			var credited := execution >= 48.0
			feature_evidence.append({"feature":feature, "execution":execution, "credited":credited})
			if credited: credited_features += 1
		credited_features = mini(credited_features, element.target_level)
		quality = snappedf(clampf((float(skating.deep_edge)+float(skating.turns)+float(skating.flow))/3.0*0.9 + familiarity*0.1 - fatigue*0.18 + rng.randf_range(-6.0,6.0),0.0,100.0),0.001)
	level_review = quality >= 38.0 and quality <= 52.0
	var facts := {
		"element_code": abbreviation,
		"execution_quality": quality,
		"attempted_features": element.target_level,
		"credited_features": credited_features,
		"feature_evidence": feature_evidence,
		"rotations": snappedf(float(athlete.technique.get("rotation", 30.0)) / 8.0, 0.1) if element.kind == "spin" else 0.0,
		"speed": float(athlete.skating.get("speed", 30.0)),
		"centering": float(athlete.skating.get("one_foot_stability", 30.0)),
		"edge_turn_accuracy": float(athlete.skating.get("turns", 30.0)),
		"coverage": float(athlete.skating.get("ice_efficiency", 30.0)),
	}
	return {
		"element_id": element.element_id, "kind": element.kind, "index": index,
		"abbreviation": abbreviation, "base_value": base_value,
		"live_goe": snappedf(base_value * clampf((quality - 50.0) / 120.0, -0.4, 0.4), 0.01),
		"status": "review" if level_review else ("error" if quality < 28.0 else "success"),
		"review_reasons": ["level"] if level_review else [], "success_probability": 0.0,
		"fatigue_before": fatigue, "fatigue_cost": 0.8,
		"actual": {"quality": quality, "fall": false}, "facts": facts,
	}

static func _late_bonus_element_ids(program, context: Dictionary) -> Array[String]:
	var rules = context.get("segment_rules", {})
	if not rules is Dictionary: return []
	var window = rules.get("bonus_window", {})
	if not window is Dictionary or str(window.get("kind", "")) != "last_jump_elements": return []
	var jump_ids: Array[String] = []
	for element in program.elements:
		if element.kind == "jump": jump_ids.append(element.element_id)
	var count := clampi(int(window.get("count", 0)), 0, jump_ids.size())
	return jump_ids.slice(jump_ids.size() - count) if count > 0 else []
