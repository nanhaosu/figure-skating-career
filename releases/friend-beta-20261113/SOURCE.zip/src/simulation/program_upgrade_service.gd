class_name ProgramUpgradeService
extends RefCounted

const Program = preload("res://src/domain/skating_program.gd")
const Repertoire = preload("res://src/domain/technical_repertoire.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Validator = preload("res://src/simulation/program_validator.gd")

static func rules_for_career(career, segment: String) -> Dictionary:
	var bundle := preload("res://src/content/season_bundle_repository.gd").for_career(career)
	var level := "senior" if preload("res://src/simulation/competitive_level_service.gd").current(career) == "senior" else "junior"
	var target_id := str(career.season_state.get("target_event_id",""))
	if not target_id.is_empty() and bundle.errors.is_empty():
		var targets: Array = bundle.calendar.events.filter(func(event):return event.event_id == target_id and not event.get("reference_only",false) and event.get("status") != "cancelled")
		if targets.size() == 1:
			var resolved := preload("res://src/content/season_bundle_repository.gd").competition_for_career(career,targets[0])
			if not resolved.errors.is_empty() or str(resolved.event.competition_level) != level: return {}
			return resolved.rules.get(segment,{}).get("segment_rules",{}).duplicate(true)
	return preload("res://src/content/internal_event_rules.gd").for_season(preload("res://src/content/season_bundle_repository.gd").season_year(career),level,segment)

static func propose(career, segment: String, rules: Dictionary, include_declined: bool = false) -> Dictionary:
	var result := {"id":"","changed":false,"programs":{},"evidence_refs":[],"familiarity_cost":0.0,"base_program_hash":"","segment":segment,"errors":[]}
	if not segment in ["short","free"]: result.errors.append("节目阶段无效"); return result
	if not career.competition_state.is_empty() or career.clock.year < 2018: return result
	var original = Program.from_dict(career.active_programs.get(segment,{}))
	if original == null: return result
	result.base_program_hash = JSON.stringify(original.to_dict()).sha256_text()
	for target in _candidate_targets(career, segment, original):
		var action: Dictionary = target.get("action",{})
		var id := Repertoire.action_id(action)
		var item: Dictionary = career.technical_repertoire.entries.get(id,{})
		if id.is_empty() or item.get("state") != "available": continue
		if not preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,action).allowed: continue
		var contexts: Array = item.get("learned_history",{}).get("first_success_contexts",{}).keys()
		contexts.sort()
		var version := JSON.stringify({"base":result.base_program_hash,"action":id,"contexts":contexts,"season":career.season_program_plan.get("season_id",""),"direction_revision":career.training_direction.get("revision",0)}).sha256_text()
		var previous := _previous(career,version)
		if not previous.is_empty() and (previous.decision == "accepted" or not include_declined): continue
		for index in original.elements.size():
			var edited = Program.from_dict(original.to_dict())
			var element = edited.elements[index]
			if element.kind != "jump": continue
			var explicit := str(target.get("element_id",""))
			if not explicit.is_empty() and edited.elements.any(func(row): return row.element_id == explicit):
				if element.element_id != explicit: continue
			elif element.jump_id != str(action.parts[0].jump_id): continue
			var before: Dictionary = element.to_dict()
			element.jump_id = str(action.parts[0].jump_id)
			element.rotations = int(action.parts[0].rotations)
			var errors: Array[String] = element.set_combination_parts(action.parts.slice(1))
			if not errors.is_empty() or element.to_dict() == before: continue
			if not Validator.validate(edited,career.athlete,rules).is_empty():
				continue
			var revision := Draft.save_draft(original,edited)
			if not revision.errors.is_empty(): continue
			result.id = version
			result.changed = true
			result.programs[segment] = edited.to_dict()
			result.familiarity_cost = maxf(0,float(original.whole_run_familiarity)-float(revision.program.whole_run_familiarity))
			result.evidence_refs = ["technical:"+id]
			return result
	return result

static func _candidate_targets(career, segment: String, original) -> Array:
	var targets: Array = Array(career.season_program_plan.get("targets",{}).get(segment,[])).duplicate(true)
	# A learned jump must be discoverable through the existing advice flow even
	# when the player has not authored a separate seasonal target. No programme
	# is changed here, and propose() still checks evidence, health and legality.
	for element in original.elements:
		if element.kind != "jump" or element.jump_id == "axel" or element.rotations >= 3: continue
		var parts: Array = [{"jump_id":element.jump_id,"rotations":3}]
		parts.append_array(element.combination_parts)
		targets.append({"element_id":element.element_id,"action":{"kind":"jump","parts":parts}})
	if segment == "free":
		var counts := {}
		for element in original.elements:
			if element.kind == "jump": counts[element.jump_id] = int(counts.get(element.jump_id,0))+1
		for family in ["toe_loop","salchow","loop","flip","lutz"]:
			if original.elements.any(func(row): return row.kind == "jump" and row.jump_id == family and row.rotations >= 3): continue
			var action := {"kind":"jump","parts":[{"jump_id":family,"rotations":3}]}
			if career.technical_repertoire.entries.get(Repertoire.action_id(action),{}).get("state") != "available": continue
			for element in original.elements:
				if element.kind != "jump" or element.jump_id == family or int(counts.get(element.jump_id,0)) <= 1: continue
				targets.append({"element_id":element.element_id,"action":action})
	return targets

static func apply(career, proposal: Dictionary, receipt_id: String) -> Dictionary:
	return _decide(career,proposal,receipt_id,"accepted")

static func decline(career, proposal: Dictionary, receipt_id: String) -> Dictionary:
	return _decide(career,proposal,receipt_id,"declined")

static func _decide(career, proposal: Dictionary, receipt_id: String, decision: String) -> Dictionary:
	if receipt_id.is_empty(): return {"ok":false,"error":"缺少建议确认凭据"}
	var id := str(proposal.get("id",""))
	for record in career.event_ledger:
		if record.get("kind") == "program_upgrade_decision" and record.get("receipt_id") == receipt_id:
			var same: bool = record.get("suggestion_id") == id and record.get("decision") == decision
			return {"ok":same,"events":[],"error":"" if same else "确认凭据已经用于另一项决定"}
	var previous: Dictionary = _previous(career,id)
	if not previous.is_empty() and (previous.decision == "accepted" or decision == "declined"): return {"ok":false,"error":"这份建议已经处理"}
	if not career.competition_state.is_empty(): return {"ok":false,"error":"比赛进行中不能通过培养建议修改节目"}
	var segment := str(proposal.get("segment",""))
	var rules: Dictionary = rules_for_career(career,segment)
	var fresh := propose(career,segment,rules,true)
	if not fresh.changed or fresh.id != id or fresh.base_program_hash != proposal.get("base_program_hash") or fresh.programs != proposal.get("programs"): return {"ok":false,"error":"节目或储备已经变化，请重新查看建议"}
	if decision == "accepted":
		var revision := Draft.save_draft(Program.from_dict(career.active_programs[segment]),Program.from_dict(fresh.programs[segment]))
		if not revision.errors.is_empty(): return {"ok":false,"error":"；".join(revision.errors)}
		career.active_programs[segment] = revision.program.to_dict()
		if revision.archived != null: career.program_archive.append(revision.archived.to_dict())
	var record := {"decision":decision,"receipt_id":receipt_id,"base_program_hash":fresh.base_program_hash,"suggestion_id":id,"kind":"program_upgrade_decision","clock":career.clock.to_dict()}
	career.experience_state.suggestion_receipts[id] = record
	while career.experience_state.suggestion_receipts.size() > 128: career.experience_state.suggestion_receipts.erase(career.experience_state.suggestion_receipts.keys()[0])
	career.event_ledger.append(record.duplicate(true))
	return {"ok":true,"events":[record],"error":""}

static func _previous(career, suggestion_id: String) -> Dictionary:
	var cached: Dictionary = career.experience_state.suggestion_receipts.get(suggestion_id,{})
	if not cached.is_empty(): return cached
	for index in range(career.event_ledger.size()-1,-1,-1):
		var record: Dictionary = career.event_ledger[index]
		if record.get("kind") == "program_upgrade_decision" and record.get("suggestion_id") == suggestion_id: return record
	return {}
