class_name CompetitionRouteExecutor
extends RefCounted

static func execute(plan: Dictionary, performance: Dictionary, _athlete, context: Dictionary) -> Dictionary:
	var overload := float(plan.get("complexity_assessment", {}).get("overload", 0.0))
	var fatigue := maxf(float(context.get("starting_fatigue", 0.0)), float(performance.get("fatigue_end", 0.0)))
	var familiarity := clampf(float(context.get("familiarity", 60.0)), 0.0, 100.0)
	var shrink_events: Array[Dictionary] = []
	if overload > 10.0: shrink_events.append({"kind": "complexity_overload", "severity": snappedf(overload, 0.01)})
	if fatigue > 50.0: shrink_events.append({"kind": "fatigue_contraction", "severity": snappedf(fatigue - 50.0, 0.01)})
	if familiarity < 25.0: shrink_events.append({"kind": "route_uncertainty", "severity": snappedf(25.0 - familiarity, 0.01)})
	var error_count := 0
	for element in performance.get("elements", []):
		if str(element.get("status", "success")) == "error" or bool(element.get("actual", {}).get("fall", false)): error_count += 1
	if error_count > 0: shrink_events.append({"kind": "error_disruption", "severity": float(error_count)})
	var shrink := clampf(overload * 0.004 + maxf(0.0, fatigue - 35.0) * 0.003 + maxf(0.0, 35.0 - familiarity) * 0.0015 + error_count * 0.025, 0.0, 0.42)
	var points: Array[Dictionary] = []
	for raw_point in plan.get("points", []):
		var point: Dictionary = Dictionary(raw_point)
		points.append({
			"x": snappedf(0.5 + (float(point.x) - 0.5) * (1.0 - shrink), 0.0001),
			"y": snappedf(0.5 + (float(point.y) - 0.5) * (1.0 - shrink), 0.0001),
			"progress": float(point.progress),
		})
	var planned: Dictionary = Dictionary(plan.get("planned_metrics", {}))
	var duration := float(context.get("duration_seconds", 160.0))
	var anchors: Array = Array(plan.get("action_anchors", [])).duplicate(true)
	var source_anchors := anchors.duplicate(true)
	var action_phases := _build_action_phases(anchors, Array(performance.get("elements", [])))
	for phase in action_phases:
		phase.start_seconds = phase.start * duration
		phase.end_seconds = phase.end * duration
	points = _hold_points(_retime_points(points,source_anchors,anchors), action_phases, anchors)
	var segments: Array[Dictionary] = []
	for index in points.size()-1: segments.append({"from":index,"to":index+1})
	for anchor in anchors:
		var position := _position(points, float(anchor.progress))
		anchor.x = position.x; anchor.y = position.y
		anchor.entry_edge = str(anchor.get("entry_edge", "standard"))
	return {
		"points": points, "segments": segments,
		"action_anchors": anchors, "duration_seconds":duration,
		"action_phases": action_phases,
		"shrink_events": shrink_events,
		"actual_metrics": {
			"coverage": snappedf(float(planned.get("coverage", 0.0)) * (1.0 - shrink), 0.01),
			"balance": snappedf(maxf(0.0, float(planned.get("balance", 0.0)) - shrink * 32.0), 0.01),
			"repetition": snappedf(minf(100.0, float(planned.get("repetition", 0.0)) + shrink * 45.0), 0.01),
			"direction_changes": maxi(0, int(planned.get("direction_changes", 0)) - int(round(shrink * 8.0))),
			"execution_ratio": snappedf(1.0 - shrink, 0.001),
		},
	}

static func _build_action_phases(anchors: Array, elements: Array) -> Array[Dictionary]:
	var records := {}
	for raw in elements: records[str(raw.get("element_id", ""))] = raw
	var phases: Array[Dictionary] = []
	var previous_end := 0.0
	for raw_anchor in anchors:
		var anchor: Dictionary = Dictionary(raw_anchor)
		var element_id := str(anchor.get("element_id", ""))
		var element: Dictionary = Dictionary(records.get(element_id, {}))
		var center := float(anchor.get("progress", 0.5))
		var abbreviation := str(element.get("abbreviation", ""))
		var kind := str(element.get("kind", ""))
		var first_phase := phases.size()
		if kind.is_empty():
			kind = "spin" if abbreviation.contains("Sp") else ("step" if abbreviation.contains("StSq") else "jump")
		if kind == "spin":
			phases.append(_phase("approach", element_id, center - 0.025, center))
			phases.append(_phase("spin_hold", element_id, center, center + 0.055))
		elif kind in ["step", "step_sequence", "choreographic_sequence"]:
			phases.append(_phase("step_run", element_id, center - 0.035, center + 0.035))
		else:
			phases.append(_phase("approach", element_id, center - 0.008, center - 0.004))
			phases.append(_phase("takeoff", element_id, center - 0.004, center))
			phases.append(_phase("airborne", element_id, center, center + 0.007))
			phases.append(_phase("landing_hold", element_id, center + 0.007, center + 0.018))
			if bool(element.get("actual", {}).get("fall", false)):
				phases.append(_phase("recovery", element_id, center + 0.018, center + 0.021))
		# Reserve the entire part in program order. A following step/spin cannot
		# intrude into a combination, and no phase loses its duration to clipping.
		var shift := maxf(0.0,previous_end-float(phases[first_phase].start))
		anchor.progress = center + shift
		for index in range(first_phase,phases.size()):
			var phase: Dictionary = phases[index]
			phase.start += shift; phase.end += shift
			phase.part_index = int(anchor.get("part_index", 0))
			phase.entry_edge = str(anchor.get("entry_edge", "standard"))
		previous_end = phases.back().end
	# Extremely dense layouts use a common time scale, preserving positive
	# phase durations and action order while keeping the resolved program end.
	var scale := maxf(1.0,previous_end)
	for phase in phases:
		phase.start /= scale; phase.end /= scale
	for anchor in anchors: anchor.progress /= scale
	return phases

static func _retime_points(points: Array[Dictionary], source: Array, anchors: Array) -> Array[Dictionary]:
	var knots: Array[Dictionary] = [{"source":0.0,"time":0.0}]
	for index in anchors.size(): knots.append({"source":float(source[index].progress),"time":float(anchors[index].progress)})
	knots.append({"source":1.0,"time":1.0})
	for point in points:
		var progress := float(point.progress)
		for index in range(1,knots.size()):
			var a: Dictionary = knots[index-1]; var b: Dictionary = knots[index]
			if progress <= b.source:
				var weight := inverse_lerp(a.source,b.source,progress) if b.source > a.source else 1.0
				point.progress = lerpf(a.time,b.time,weight)
				break
	return points

static func _hold_points(points: Array[Dictionary], phases: Array[Dictionary], anchors: Array) -> Array[Dictionary]:
	# Piecewise monotone time mapping; a hold repeats the same route coordinate.
	var knots: Array[Dictionary] = [{"time":0.0,"route":0.0}]
	for phase in phases:
		if phase.kind in ["landing_hold", "spin_hold"]:
			knots.append({"time":phase.start,"route":phase.start})
			knots.append({"time":phase.end,"route":phase.start})
	knots.append({"time":1.0,"route":1.0})
	for anchor in anchors:
		var progress := float(anchor.progress)
		var inside_hold := false
		for phase in phases:
			if phase.kind in ["landing_hold","spin_hold"] and progress >= phase.start and progress <= phase.end: inside_hold = true
		if not inside_hold: knots.append({"time":progress,"route":progress})
	knots.sort_custom(func(a,b): return a.time < b.time)
	var progress_index := PackedFloat64Array()
	for point in points:
		var progress := float(point.progress)
		if not is_finite(progress) or (not progress_index.is_empty() and progress < progress_index[-1]):
			progress_index.clear()
			break
		progress_index.append(progress)
	var result: Array[Dictionary] = []
	for i in range(1, knots.size()):
		var a: Dictionary = knots[i-1]; var b: Dictionary = knots[i]
		var samples := maxi(1, int(ceil((b.time-a.time)*240)))
		for j in samples:
			var weight := float(j)/samples
			var position := _position(points, lerpf(a.route,b.route,weight), progress_index)
			result.append({"x":position.x,"y":position.y,"progress":lerpf(a.time,b.time,weight)})
	var last := _position(points,1.0,progress_index)
	result.append({"x":last.x,"y":last.y,"progress":1.0})
	return result

static func _position(points: Array, progress: float, progress_index := PackedFloat64Array()) -> Vector2:
	if points.is_empty(): return Vector2(0.5,0.5)
	if not progress_index.is_empty() and is_finite(progress):
		var index := maxi(1, progress_index.bsearch(progress))
		if index < points.size(): return _interpolate(points[index-1],points[index],progress)
	else:
		for index in range(1,points.size()):
			if progress <= float(points[index].progress): return _interpolate(points[index-1],points[index],progress)
	return Vector2(points.back().x,points.back().y)

static func _interpolate(a: Dictionary, b: Dictionary, progress: float) -> Vector2:
	var weight := inverse_lerp(float(a.progress),float(b.progress),progress) if b.progress > a.progress else 1.0
	return Vector2(a.x,a.y).lerp(Vector2(b.x,b.y),clampf(weight,0.0,1.0))

static func _phase(kind: String, element_id: String, start: float, end: float) -> Dictionary:
	return {"kind": kind, "element_id": element_id, "start": start, "end": end}
