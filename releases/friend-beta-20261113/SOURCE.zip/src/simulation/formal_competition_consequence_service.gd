class_name FormalCompetitionConsequenceService
extends RefCounted

const PersonalRecordService = preload("res://src/simulation/personal_record_service.gd")
const Ranking = preload("res://src/simulation/competition_ranking_service.gd")
const POINTS := [100,85,70,60,50,45,40,36,32,29,26,23,20,18,16,14,12,10,8,6,5,4,3,2,1]

static func apply_world(career, archive: Dictionary) -> Dictionary:
	if not career.ranking_state.get("isu_world") is Dictionary or not career.ranking_state.get("season_world") is Dictionary:
		Ranking.begin_season(career.ranking_state,int(archive.get("event",{}).get("ruleset_season_start_year",2018)))
	if archive.get("event",{}).get("event_family") == "jgp_stage":
		var points := preload("res://src/simulation/junior_grand_prix_service.gd").update_points(career,archive)
		if not points.errors.is_empty(): return points
	for row in archive.get("final_standings",[]):
		var id := str(row.get("athlete_id",""))
		if not career.world_athletes.has(id): continue
		career.world_athletes[id].ranking_state = Ranking.preview(career.world_athletes[id].get("ranking_state",{}),archive,row)
	Ranking.refresh_ranks(career.ranking_state,career.world_athletes)
	return {"errors":[]}

static func apply(career, archive: Dictionary) -> Dictionary:
	var receipt := "%s:%s" % [archive.get("season_id",""),archive.get("event_id","")]
	if career.ranking_state.get("applied_events",{}).has(receipt):
		return {"career_changes":{"record_book":career.record_book.duplicate(true),"ranking_state":career.ranking_state.duplicate(true),"selection_state":career.selection_state.duplicate(true),"world_athletes":career.world_athletes.duplicate(true),"experience_state":career.experience_state.duplicate(true),"archive":archive.duplicate(true)},"summary":archive.get("consequence_summary",{}),"errors":[]}
	if bool(archive.get("consequences_applied", false)) and archive.get("consequence_snapshot", {}) is Dictionary:
		var stored: Dictionary = Dictionary(archive.consequence_snapshot).duplicate(true)
		if not stored.has("experience_state"): stored.experience_state = career.experience_state.duplicate(true)
		stored.archive = archive.duplicate(true)
		return {"career_changes": stored, "summary": archive.get("consequence_summary", {}), "errors": []}
	var player: Dictionary = Dictionary(archive.get("player_result", {}))
	if player.is_empty(): return {"career_changes": {}, "summary": {}, "errors": ["比赛档案缺少玩家成绩"]}
	var record_result := PersonalRecordService.preview(career.record_book, archive)
	var ranking := Ranking.preview(career.ranking_state,archive,player)
	var rank := int(player.get("final_rank", player.get("short_rank", 99)))
	var awarded := int(ranking.domestic_points) - int(career.ranking_state.get("domestic_points",0))
	var evidence := _evidence(career, player, rank)
	ranking.selection_evidence = evidence
	var marked := archive.duplicate(true)
	marked.consequences_applied = true
	var world: Dictionary = career.world_athletes.duplicate(true)
	for row in archive.get("final_standings",[]):
		var id := str(row.get("athlete_id",""))
		if id == "player" or not world.has(id): continue
		world[id].ranking_state = Ranking.preview(world[id].get("ranking_state",{}),archive,row)
	Ranking.refresh_ranks(ranking,world)
	# Persist the same numeric/string-key representation that JSON reloads.
	ranking = load("res://src/domain/career_state.gd")._restore_ranking_state(JSON.parse_string(JSON.stringify(ranking)))
	var changes := {"record_book": record_result.next_record_book, "ranking_state": ranking, "world_athletes":world,"archive": {}}
	var milestone := preload("res://src/simulation/career_milestone_service.gd").preview(career.experience_state,archive)
	changes.experience_state = milestone.next_state
	marked.milestone_receipt = {"new_ids":milestone.new_ids.duplicate(),"event_id":str(archive.get("event_id",""))}
	if archive.get("event",{}).get("event_family") == "jgp_stage":
		var working = load("res://src/domain/career_state.gd").from_dict(career.to_dict())
		var points: Dictionary = preload("res://src/simulation/junior_grand_prix_service.gd").update_points(working,archive)
		if not points.errors.is_empty(): return {"career_changes":{},"summary":{},"errors":points.errors}
		changes.selection_state = working.selection_state.duplicate(true)
	marked.consequence_summary = {"domestic_points_awarded": awarded, "candidate_band": evidence.candidate_band, "record_changes": record_result.changes}
	marked.consequence_snapshot = {"record_book": record_result.next_record_book.duplicate(true), "ranking_state": ranking.duplicate(true)}
	marked.consequence_snapshot.experience_state = changes.experience_state.duplicate(true)
	if changes.has("selection_state"): marked.consequence_snapshot.selection_state = changes.selection_state.duplicate(true)
	changes.archive = marked
	return {"career_changes": changes, "summary": marked.consequence_summary, "errors": []}

static func _evidence(career, player: Dictionary, rank: int) -> Dictionary:
	var triple_count := 0
	for jump in career.athlete.jumps.values():
		if int(jump.unlocked_rotations) >= 3: triple_count += 1
	var health := clampf(100.0 - float(career.athlete.body.get("cumulative_fatigue", 0.0)) - float(career.athlete.body.get("impact_load", 0.0)) * 0.25, 0.0, 100.0)
	var stability := clampf(85.0 - float(player.get("falls", 0)) * 14.0, 0.0, 100.0)
	var coach_support := float(career.relationships.get("coach").professional_trust) if career.relationships.has("coach") else 40.0
	var club_support := clampf(float(career.athlete.resources.get("ice_access", 0.0)) + 20.0, 0.0, 100.0)
	var age: int = career.clock.year - career.athlete.birth_year
	var eligibility := 100.0 if age >= 13 and age <= 18 else 0.0
	var rank_score := clampf(105.0 - rank * 5.0, 0.0, 100.0)
	var technical := clampf(triple_count * 15.0, 0.0, 100.0)
	var weighted := rank_score * 0.32 + technical * 0.20 + stability * 0.14 + health * 0.10 + eligibility * 0.08 + coach_support * 0.08 + club_support * 0.08
	var band := "leading" if weighted >= 82.0 else ("strong" if weighted >= 68.0 else ("borderline" if weighted >= 54.0 else ("watch" if weighted >= 38.0 else "not_considered")))
	return {"recent_rank":rank,"direct_rivals":rank_score,"technical_ceiling":technical,"stability":stability,"health":health,"age_eligibility":eligibility,"coach_support":coach_support,"club_support":club_support,"candidate_score":snappedf(weighted,0.01),"candidate_band":band}
