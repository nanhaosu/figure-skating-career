class_name EventEligibilityEvaluator
extends RefCounted

const Identity = preload("res://src/domain/athlete_identity.gd")

const QUALIFICATION_LABELS := {
	"national_technical_minimum":"尚无符合本赛事要求的技术等级记录",
	"program_legal":"短节目或自由滑不符合当季青年组规则",
	"cfsa_registered":"尚未完成协会参赛注册",
	"club_nomination":"尚未获得俱乐部报名",
	"club_final_top_six":"分站积分尚未达到总决赛资格",
}

static func evaluate(athlete, event: Dictionary, season_start_year: int, requested_levels: Array[String], qualification_state: Dictionary, rule_context: Dictionary) -> Dictionary:
	var hard_gate_codes: Array[String] = []
	var explanations: Array[String] = []
	var warnings: Array[String] = []
	var missing: Array[String] = []
	var allowed_levels: Array[String] = []
	for level in event.get("level_options", []): allowed_levels.append(str(level))
	for qualification_id in event.get("qualification_ids", []):
		if not bool(qualification_state.get(qualification_id, false)):
			missing.append(str(qualification_id))
	if not missing.is_empty():
		hard_gate_codes.append("missing_qualification")
		for qualification_id in missing:
			explanations.append(str(QUALIFICATION_LABELS.get(qualification_id, "尚未满足报名资质：%s" % qualification_id)))
	var recommended_level := "senior" if allowed_levels == ["senior"] else "junior"
	for level in requested_levels:
		if not allowed_levels.has(level):
			hard_gate_codes.append("level_not_offered")
			explanations.append("赛事不设%s组" % level)
	if requested_levels.has("senior") and recommended_level != "senior" and not bool(event.get("move_up_allowed", false)):
		hard_gate_codes.append("move_up_not_allowed")
		explanations.append("本赛事规则不允许越级参加成年组")
	if requested_levels.size() > 1:
		if not bool(event.get("multi_group_allowed", false)):
			hard_gate_codes.append("multi_group_not_allowed")
			explanations.append("本赛事不允许兼报多个组别")
		else:
			warnings.append("兼报将增加赛期疲劳与节目准备负担")
	var birth_date = athlete.birth_date
	# Legacy callers may supply an explicit date as meta, but it cannot
	# override a persisted identity or silently repair an invalid one.
	if birth_date.is_empty(): birth_date = athlete.get_meta("birth_date", {})
	var exact_birth_date: bool = birth_date is Dictionary and not birth_date.is_empty() and Identity.validate_birth_date(birth_date,int(athlete.birth_year)).is_empty()
	if not exact_birth_date: warnings.append("仅有出生年份时按年龄范围判断；跨国际年龄门槛需补充生日")
	var international_level := "senior" if requested_levels.has("senior") else "junior"
	var minimum_age := senior_min_age(season_start_year) if international_level == "senior" else int(rule_context.get("junior_min_age", 13))
	if international_level == "senior" and season_start_year < 2023: minimum_age = int(rule_context.get("senior_min_age",minimum_age))
	var maximum_age := 1000 if international_level == "senior" else int(rule_context.get("junior_max_age",18))
	var age: Dictionary = Identity.age_gate(int(athlete.birth_year),birth_date,season_start_year,minimum_age,maximum_age) if birth_date is Dictionary else {"status":"unknown","reason_codes":["invalid_birth_date"]}
	var next_eligible := int(athlete.birth_year) + minimum_age
	if exact_birth_date and (int(birth_date.month) > 7 or (int(birth_date.month) == 7 and int(birth_date.day) >= 1)):
		next_eligible += 1
	if str(event.get("scope", "domestic")) == "international":
		if age.status == "unknown":
			hard_gate_codes.append("international_age_unknown")
			explanations.append("国际%s年龄资格尚不能确定，请在赛季资料中补充准确生日；国内训练和符合条件的国内赛不受影响" % ("成年组" if international_level == "senior" else "青年组"))
		elif age.status == "ineligible":
			hard_gate_codes.append("international_age_ineligible")
			explanations.append("不符合该赛季国际%s年龄范围" % ("成年组" if international_level == "senior" else "青年组"))
	var status := "eligible" if hard_gate_codes.is_empty() else "ineligible"
	if hard_gate_codes == ["international_age_unknown"]: status = "unknown"
	return {
		"status": status,
		"age": age,
		"eligible": hard_gate_codes.is_empty(),
		"recommended_level": recommended_level,
		"allowed_levels": allowed_levels,
		"hard_gate_codes": hard_gate_codes,
		"explanations": explanations,
		"missing_qualification_ids": missing,
		"warnings": warnings,
		"next_eligible_season_start_year": next_eligible,
		"birth_date_precision": "day" if exact_birth_date else "year",
	}

static func senior_min_age(season_start_year: int) -> int:
	return 17 if season_start_year >= 2024 else (16 if season_start_year == 2023 else 15)

