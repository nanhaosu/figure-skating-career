class_name EntryApplicationService
extends RefCounted

const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Eligibility = preload("res://src/simulation/event_eligibility_evaluator.gd")
const Assignment = preload("res://src/simulation/international_assignment_service.gd")
const FINALIZED_REASON := "本场已确认报名决定，不能重复收费或改写历史"

static func domestic_schedule_options(career, bundle: Dictionary) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	for event in preload("res://src/content/season_calendar_repository.gd").playable_events(bundle.get("calendar",{})):
		if str(event.get("scope", "")) != "domestic": continue
		if event.get("event_family") == "beijing_trial" and event.event_id != "cn_beijing_trial_1_2021": continue
		var entry: Dictionary = career.season_state.get("entry_plan", {}).get("entries", {}).get(event.event_id, {})
		var route: Dictionary = options(career, event, bundle)[0]
		rows.append({"event_id":event.event_id, "name":event.name, "date":event.start_date, "available":route.available, "selected":entry.get("status") == "confirmed", "reasons":route.reasons.duplicate()})
		if event.get("event_family") == "beijing_trial": rows[-1].name = "北京冬奥女单选拔系列（五场，一次报名）"
	return rows

static func apply_domestic_schedule(career, event_ids) -> Dictionary:
	if not event_ids is Array: return {"ok":false, "error":"国内赛选择必须是赛事列表"}
	var bundle := Bundle.for_career(career)
	if not bundle.errors.is_empty(): return {"ok":false, "error":"赛历不可用"}
	var offered := {}
	for row in domestic_schedule_options(career,bundle): offered[row.event_id] = bool(row.available)
	var domestic: Dictionary = {}
	for event in preload("res://src/content/season_calendar_repository.gd").playable_events(bundle.calendar):
		if str(event.get("scope", "")) == "domestic": domestic[event.event_id] = event
	for id in event_ids:
		if not id is String or not domestic.has(id): return {"ok":false, "error":"国内赛选择包含未知或国际赛事"}
	var events: Array = []
	if offered.get("cn_beijing_trial_1_2021",false) and not event_ids.has("cn_beijing_trial_1_2021") and career.beijing_trial_series.player_choice != "enrolled":
		var declined: Dictionary = load("res://src/simulation/beijing_trial_service.gd").decline(career,"domestic-schedule-beijing-decline")
		if not declined.ok: return declined
		events.append_array(declined.events)
	for id in event_ids:
		if career.season_state.get("entry_plan", {}).get("entries", {}).get(id, {}).get("status") == "confirmed": continue
		var result := apply(career, {"event_id":id, "route_id":"enter"})
		if not result.ok: return result
		events.append_array(result.events)
	var planner = load("res://src/simulation/season_calendar_planner.gd")
	var proposal: Dictionary = planner.refresh_eligibility(career, bundle.calendar, bundle.rules, career.season_state.entry_plan) if not career.season_state.entry_plan.is_empty() else planner.propose(career, bundle.calendar, bundle.rules)
	if not proposal.errors.is_empty(): return {"ok":false, "error":str(proposal.errors)}
	for id in domestic:
		var entry: Dictionary = proposal.plan.entries[id]
		if event_ids.has(id) or str(entry.status) == "confirmed": continue
		# Disabled rows were never offered as a choice. Preserve their unresolved
		# state so fixing a programme/qualification can still reopen registration.
		if not bool(offered.get(id,false)): continue
		entry.status = "declined"
		entry.player_override = "skip"
		if not entry.available_adjustment_ids.has("skip"): entry.available_adjustment_ids.append("skip")
		career.season_state.event_statuses[id] = "declined"
	career.season_state.entry_plan = proposal.plan.to_dict()
	career.season_state["domestic_schedule_selected"] = true
	return {"ok":true, "events":events}

static func withdraw(career,event_id: String) -> Dictionary:
	if not career.competition_state.is_empty() or career.competition_archive.any(func(a): return a.get("event_id") == event_id): return {"ok":false,"error":"已经开始或结束的比赛不能更改报名"}
	var receipt := "%s:withdraw" % event_id
	if career.selection_state.applications.has(receipt): return {"ok":true,"events":[]}
	var entry: Dictionary = career.season_state.entry_plan.get("entries",{}).get(event_id,{})
	if entry.get("status") != "confirmed": return {"ok":false,"error":"只有已报名赛事可以退出"}
	entry.status = "declined"; entry.player_override = "skip"
	career.season_state.event_statuses[event_id] = "declined"
	var record := {"event_id":event_id,"route_id":"withdraw","clock":career.clock.to_dict(),"reason_codes":["explicit_withdrawal_no_refund"]}
	career.selection_state.applications[receipt] = record
	career.event_ledger.append({"kind":"entry_withdrawn","event_id":event_id,"clock":career.clock.to_dict(),"reason":"主动退出本场；报名费用不退，比赛将作为世界赛事继续"})
	var jgp_replacement := Assignment.replace_with_frozen_alternate(career,event_id,"player")
	if not jgp_replacement.is_empty(): record["jgp_replacement"] = jgp_replacement
	var gp_replacement := preload("res://src/simulation/senior_grand_prix_service.gd").withdraw_player(career,event_id)
	if not gp_replacement.is_empty(): record["gp_replacement"] = gp_replacement
	if preload("res://src/simulation/beijing_trial_service.gd").event_ids().has(event_id):
		if not career.beijing_trial_series.withdrawals.has("player"): career.beijing_trial_series.withdrawals.player = []
		if not career.beijing_trial_series.withdrawals.player.has(event_id): career.beijing_trial_series.withdrawals.player.append(event_id)
	if event_id == "isu_owg2022":
		var replacement: Dictionary = preload("res://src/simulation/beijing_trial_service.gd").withdraw_player_dispatch(career)
		if not replacement.ok: return replacement
	return {"ok":true,"events":[record]}

static func current_eligibility(career, event: Dictionary, bundle: Dictionary, check_in: bool = false) -> Dictionary:
	if event.get("reference_only", false):
		return {"eligible":false,"status":"ineligible","hard_gate_codes":["historical_reference_only"],"missing_qualification_ids":[],"explanations":["该历史赛事的正式参赛规则仍待核对。"],"warnings":[],"requested_levels":[],"age_at_cutoff":0,"birth_date_precision":"unknown"}
	if not preload("res://src/simulation/dated_training_service.gd").has_exact_event_dates(event):
		return {"eligible":false,"status":"ineligible","hard_gate_codes":["event_dates_unknown"],"missing_qualification_ids":[],"explanations":["史料仅有月份或缺少完整比赛日，暂不能报名或补造日期；该赛事仍保留在赛历。"],"warnings":[],"requested_levels":[],"age_at_cutoff":0,"birth_date_precision":"unknown"}
	if preload("res://src/content/season_calendar_repository.gd").event_status(event)=="cancelled":
		return {"eligible":false,"hard_gate_codes":["event_cancelled"],"missing_qualification_ids":[],"explanations":["赛事已取消，不生成报名、正式成绩或积分；空档继续训练。"],"warnings":[],"requested_levels":[],"age_at_cutoff":0,"birth_date_precision":"unknown"}
	var planner = load("res://src/simulation/season_calendar_planner.gd")
	var qualifications: Dictionary = planner.qualification_state_for(career)
	var assigned: Array = career.selection_state.assignments.get("player",[])
	qualifications.isu_junior_age = true # Exact age is evaluated below.
	qualifications.isu_senior_age = true # Same precise age gate, not a generic missing flag.
	qualifications.federation_assignment = assigned.has(event.get("event_id"))
	qualifications.federation_championship_assignment = assigned.has(event.get("event_id"))
	qualifications.federation_world_junior_selection = assigned.has(event.get("event_id"))
	qualifications.jgp_final_qualified = career.selection_state.get("jgp",{}).get("qualified_ids",[]).has("player")
	if event.has("nomination_deadline") or event.get("association_funded_game_policy", false):
		# The named-entry deadline precedes music delivery and event check-in.
		qualifications.program_legal = true
	var pandemic_gp := {}
	if preload("res://src/simulation/pandemic_grand_prix_service.gd").supports(event):
		pandemic_gp = preload("res://src/simulation/pandemic_grand_prix_service.gd").preview(career,event)
		qualifications.pandemic_gp_invitation = pandemic_gp.eligible
	var senior_gp := {}
	var gp_final := {}
	if preload("res://src/simulation/senior_grand_prix_service.gd").supports(event):
		senior_gp = preload("res://src/simulation/senior_grand_prix_service.gd").preview(career,event)
		qualifications.gp_invitation = senior_gp.invited and senior_gp.errors.is_empty()
		# The approved game invitation has no invented historical TES minimum.
		# Exact senior age remains independently enforced by Eligibility below.
		qualifications.individual_entry_requirements = true
	if preload("res://src/simulation/senior_grand_prix_service.gd").supports_final(event):
		gp_final = preload("res://src/simulation/senior_grand_prix_service.gd").final_preview(career,event)
		qualifications.gp_final_qualified = gp_final.qualified_ids.has("player")
	var personal_service = preload("res://src/simulation/international_personal_eligibility.gd")
	var championship := {}
	if preload("res://src/simulation/senior_championship_service.gd").supports(event):
		championship = preload("res://src/simulation/senior_championship_service.gd").preview(career,event)
		var selected: bool = championship.errors.is_empty() and championship.selected.any(func(row):return row.athlete_id == "player")
		qualifications.federation_championship_assignment = selected
		qualifications.federation_assignment = selected
		qualifications.olympic_qualifier_assignment = selected
	var personal_policy: Dictionary = personal_service.policy_for(event)
	var personal := {}
	if not personal_policy.is_empty():
		personal = personal_service.evaluate(career,event,personal_policy)
		qualifications.individual_entry_requirements = personal.eligible
	if check_in:
		var resolved := Bundle.competition_for_career(career,event)
		qualifications.program_legal = resolved.errors.is_empty()
		if resolved.errors.is_empty():
			var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(career,resolved.event)
			for segment in ["short","free"]:
				var program = load("res://src/domain/skating_program.gd").from_dict(event_programs.get(segment,{}))
				if program == null or not load("res://src/simulation/program_validator.gd").validate(program,career.athlete,resolved.rules[segment].segment_rules).is_empty(): qualifications.program_legal = false
	var level_service = preload("res://src/simulation/competitive_level_service.gd")
	var levels: Array[String] = [level_service.event_level(career,event)]
	var gate := Eligibility.evaluate(career.athlete,event,int(event.get("ruleset_season_start_year",2018)),levels,qualifications,bundle.get("rules",{}))
	if not pandemic_gp.is_empty(): gate.warnings.append(pandemic_gp.label)
	if not championship.is_empty() and championship.errors.is_empty():
		gate.senior_championship = championship
		gate.warnings.append(championship.label)
		gate.warnings.append(championship.audit.public_formula)
	if not senior_gp.is_empty():
		gate.senior_gp_invitation = senior_gp
		gate.warnings.append(senior_gp.label)
	if not gp_final.is_empty():
		gate.gp_final_standings = gp_final
		if not gp_final.complete: gate.warnings.append("六站赛果齐备后公布总决赛名单。")
		else:
			var rows: Array = gp_final.audit.candidate_rows
			var rank := rows.find_custom(func(row): return row.athlete_id == "player")
			if rank >= 0: gate.warnings.append("成年大奖赛积分 %d，系列排名第 %d。" % [rows[rank].points,rank+1])
	if not personal.is_empty():
		gate.personal_eligibility = personal
		gate.warnings.append_array(personal.warnings)
		if event.get("qualification_ids",[]).has("individual_entry_requirements") and not personal.eligible:
			gate.explanations.append_array(personal_service.explanations(personal,personal_policy))
	if not level_service.permits(career,event):
		gate.hard_gate_codes.append("season_level_mismatch")
		gate.explanations.append("本季组别选择不包含该赛事，请在赛季规划中确认升组或过渡安排")
		gate.eligible = false
	if event.get("event_family") == "beijing_trial":
		var trial_admission: Dictionary = load("res://src/simulation/beijing_trial_service.gd").admission(career)
		if not trial_admission.eligible:
			gate.hard_gate_codes.append("beijing_trial_admission")
			gate.explanations.append_array(trial_admission.reasons)
			gate.eligible = false
		if check_in and career.beijing_trial_series.player_choice != "enrolled":
			gate.hard_gate_codes.append("beijing_trial_not_enrolled")
			gate.explanations.append("尚未报名北京选拔系列")
			gate.eligible = false
		gate.status = "eligible" if gate.eligible else "ineligible"
	if event.get("event_family") == "world_junior":
		var minimum: Dictionary = load("res://src/simulation/world_junior_eligibility_service.gd").evaluate_career(career,event)
		gate.world_junior_minimum = minimum
		var existing: Dictionary = career.season_state.get("entry_plan",{}).get("entries",{}).get(event.get("event_id"),{})
		var legacy_confirmed: bool = existing.get("status") == "confirmed" and not existing.get("eligibility_snapshot",{}).has("world_junior_minimum")
		if not minimum.eligible:
			if legacy_confirmed:
				gate.warnings.append("旧存档已确认的世青报名予以保留；没有补造最低技术分记录")
			else:
				gate.hard_gate_codes.append("world_junior_minimum_missing")
				gate.explanations.append_array(minimum.reasons)
				gate.eligible = false
	return gate

static func _medical_injuries(career) -> Array[String]:
	var ids: Array[String] = []
	var minimum_jump := {"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":1}]}
	if preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,minimum_jump).allowed: return ids
	for injury in career.condition_state.injuries:
		if injury.get("status") != "active" or str(injury.get("id","")).is_empty(): continue
		var limits: Dictionary = injury.get("function_limits",{})
		var prohibits := limits.is_empty() and float(injury.get("severity",0.0)) >= 0.7
		for field in ["takeoff","coordination","landing"]:
			var limit: Dictionary = limits.get(field,{})
			prohibits = prohibits or bool(limit.get("blocked",false)) or int(limit.get("maximum_rotations",4)) < 1
		if prohibits: ids.append(str(injury.id))
	return ids

static func medical_pause_applies(career,event_id: String) -> bool:
	if not preload("res://src/domain/beijing_trial_series.gd").event_ids().has(event_id): return false
	var pause: Dictionary = career.beijing_trial_series.get("medical_pause",{})
	if pause.is_empty(): return false
	return _medical_injuries(career).any(func(id):return pause.injury_ids.has(id))

static func _medical_skip(career,event_id: String) -> Dictionary:
	if not medical_pause_applies(career,event_id): return {"ok":false,"error":"本场没有适用且仍生效的医疗暂停选择"}
	var receipt := event_id+":medical_pause"
	if career.selection_state.applications.has(receipt): return {"ok":true,"events":[]}
	if not career.competition_state.is_empty() or career.competition_archive.any(func(a):return a.get("event_id") == event_id): return {"ok":false,"error":"已开始或结束的比赛不能因医疗暂停改写"}
	var entry: Dictionary = career.season_state.entry_plan.get("entries",{}).get(event_id,{})
	if entry.get("status") != "confirmed": return {"ok":false,"error":"只有尚未开始的已报名选拔可以医疗退赛"}
	entry.status = "declined"; entry.player_override = "skip"
	career.season_state.event_statuses[event_id] = "declined"
	var record := {"event_id":event_id,"route_id":"medical_pause","clock":career.clock.to_dict(),"reason_codes":["medical_unavailable_after_accepted_pause"]}
	career.selection_state.applications[receipt] = record
	career.event_ledger.append({"kind":"entry_medically_unavailable","event_id":event_id,"clock":career.clock.to_dict(),"reason":"按已确认康复安排，本场因同一伤情暂停参赛；后续场次仍保留，身体允许后恢复。","medical_pause_receipt":career.beijing_trial_series.medical_pause.receipt_id})
	if not career.beijing_trial_series.withdrawals.has("player"): career.beijing_trial_series.withdrawals.player = []
	if not career.beijing_trial_series.withdrawals.player.has(event_id): career.beijing_trial_series.withdrawals.player.append(event_id)
	return {"ok":true,"events":[record]}

static func _pause_for_recovery(career,event_id: String) -> Dictionary:
	var receipt := event_id+":medical_pause:choice"
	if career.selection_state.applications.has(receipt): return {"ok":true,"events":[]}
	var ids := _medical_injuries(career)
	if ids.is_empty() or career.beijing_trial_series.player_choice != "enrolled": return {"ok":false,"error":"当前没有需要暂停选拔的跳跃禁令与在疗伤情"}
	if career.beijing_trial_series.status != "collecting" or career.season_state.entry_plan.get("entries",{}).get(event_id,{}).get("status") != "confirmed": return {"ok":false,"error":"本场不能新建选拔医疗暂停"}
	var now := str(career.competition_timeline.date) if career.competition_timeline.mode == "dated" else "%04d-%02d-01" % [career.clock.year,(career.clock.quarter-1)*3+1]
	var index := preload("res://src/domain/beijing_trial_series.gd").event_ids().find(event_id)
	if index < 0 or now > preload("res://src/domain/beijing_trial_series.gd").DATES[index]: return {"ok":false,"error":"本场选拔已结束，不能补记医疗暂停；后续尚未开始的场次可单独处理"}
	career.beijing_trial_series.medical_pause = {"receipt_id":receipt,"event_id":event_id,"injury_ids":ids,"selected_on":now}
	var skipped := _medical_skip(career,event_id)
	if not skipped.ok: return skipped
	career.selection_state.applications[receipt] = {"event_id":event_id,"route_id":"medical_pause","clock":career.clock.to_dict(),"reason_codes":["accepted_medical_pause_until_fit"]}
	return skipped

static func options(career, event: Dictionary, bundle: Dictionary, precomputed_gate: Dictionary = {}) -> Array[Dictionary]:
	if event.get("reference_only", false):
		return []
	if event.get("event_family") == "beijing_trial":
		var trials = load("res://src/simulation/beijing_trial_service.gd")
		var admission: Dictionary = trials.admission(career)
		var now := str(career.competition_timeline.date) if career.competition_timeline.mode == "dated" else "%04d-%02d-01" % [career.clock.year,(career.clock.quarter-1)*3+1]
		var reasons: Array = admission.reasons.duplicate()
		if now >= "2021-12-18": reasons.append("首场选拔已开始，不能补报整个系列")
		var gate := {"eligible":reasons.is_empty(),"explanations":reasons,"hard_gate_codes":[],"warnings":[admission.label],"missing_qualification_ids":[]}
		var choices: Array[Dictionary] = [{"id":"enter","label":"报名五场选拔系列（一次确认）","available":reasons.is_empty(),"eligibility":gate,"deadline":"2021-12-18","costs":_costs(false,false,true),"reasons":reasons,"reason_codes":[]},{"id":"skip","label":"本季不报名选拔系列","available":career.beijing_trial_series.player_choice != "enrolled","deadline":"2021-12-18","costs":_costs(false,false,true),"reasons":[],"reason_codes":[]}]
		if career.season_state.get("entry_plan",{}).get("entries",{}).get(event.event_id,{}).get("status") == "confirmed": choices.append({"id":"withdraw","label":"仅退出本场选拔，保留其他场次","available":true,"deadline":event.start_date,"costs":_costs(false,false,true),"reasons":[],"reason_codes":[]})
		if now <= str(event.start_date) and career.season_state.get("entry_plan",{}).get("entries",{}).get(event.event_id,{}).get("status") == "confirmed" and not _medical_injuries(career).is_empty(): choices.append({"id":"medical_pause","label":"康复期间暂停选拔，身体允许后恢复（不再逐场确认）","available":true,"deadline":event.start_date,"costs":_costs(false,false,true),"reasons":[],"reason_codes":["medical_pause_until_fit"]})
		return choices
	var gate := current_eligibility(career,event,bundle) if precomputed_gate.is_empty() else precomputed_gate
	var policy: Dictionary = preload("res://src/simulation/international_personal_eligibility.gd").policy_for(event)
	var window: Dictionary = event.get("application_window", {})
	var deadline := str(window.get("closes", policy.get("cutoff",event.get("application_deadline",event.get("end_date","")))))
	var substitution := preload("res://src/simulation/jgp_second_start_service.gd").substitution_deadline(career,event)
	if not substitution.is_empty(): deadline = substitution
	var now := "%04d-%02d-01" % [career.clock.year,(career.clock.quarter-1)*3+1]
	if career.competition_timeline.get("mode") == "dated": now = str(career.competition_timeline.date)
	var reasons: Array = gate.explanations.duplicate()
	if window.has("opens") and now < str(window.opens): reasons.append("报名窗口尚未开放")
	if deadline.length() == 10 and now > deadline: reasons.append("报名截止日期已过")
	var route := str(event.get("entry_route","club_nomination"))
	var self_fund := route == "open_self_funded"
	var cost := _costs(self_fund, str(event.get("scope","domestic")) == "international")
	var association_funded: bool = event.get("association_funded_game_policy",false)
	var funding_source := str(event.get("association_funding_source_event",""))
	if association_funded and not funding_source.is_empty():
		association_funded = career.competition_archive.any(func(archive):return archive.get("event_id") == funding_source and archive.get("status") == "complete" and not archive.get("world_only",false) and archive.get("free_results",{}).has("player") and preload("res://src/persistence/competition_archive_codec.gd").validate(archive).is_empty())
	if association_funded:
		cost.money = 0.0
	if float(career.athlete.resources.money) < float(cost.money): reasons.append("资金不足")
	var choices: Array[Dictionary] = []
	choices.append({"id":"self_fund_enter" if self_fund else "enter","label":"自费国际参赛（协会申报）" if self_fund else ("使用协会派遣报名" if event.get("scope") == "international" else "俱乐部/协会单位报名"),"available":reasons.is_empty(),"eligibility":gate,"deadline":deadline,"costs":cost,"reasons":reasons,"reason_codes":gate.hard_gate_codes.duplicate()})
	if not substitution.is_empty(): choices[0].label += " · 预报名姓名名单内改派；国内确认截止为游戏政策（原普通报名截止不变）"
	if event.get("application_deadline_game_policy", false):
		choices[0].label += " · 截止日为游戏政策"
	if association_funded:
		choices[0].label += " · 协会承担个人报名支出（游戏政策）"
	if event.has("nomination_deadline"):
		choices[0].label += " · 主办方报名费 €%d（游戏结算 %.0f）" % [int(event.official_entry_fee.amount), float(cost.money)]
		choices[0].official_entry_fee = Dictionary(event.official_entry_fee).duplicate(true)
		var nomination_reasons: Array[String] = []
		var nomination_deadline := str(event.nomination_deadline)
		if now > nomination_deadline: nomination_reasons.append("协会预报名期限已过")
		if career.selection_state.assignments.get("player", []).has(event.event_id): nomination_reasons.append("已有本场提名")
		var level_service = preload("res://src/simulation/competitive_level_service.gd")
		if not level_service.permits(career,event): nomination_reasons.append("赛季规划须包含该比赛组别")
		var identity_gate := Eligibility.evaluate(career.athlete,event,int(event.ruleset_season_start_year),[level_service.event_level(career,event)],{"cfsa_registered":true,"federation_assignment":true,"program_legal":true},bundle.rules)
		nomination_reasons.append_array(identity_gate.explanations)
		if not career.competition_archive.any(func(archive): return archive.get("status") == "complete" and not archive.get("world_only",false) and archive.get("free_results",{}).has("player")):
			nomination_reasons.append("游戏协会提名要求已有完整正式赛成绩")
		choices.append({"id":"request_nomination","label":"申请协会提名（游戏评估）","available":nomination_reasons.is_empty(),"deadline":nomination_deadline,"costs":_costs(false,false,true),"reasons":nomination_reasons,"reason_codes":[]})
	if event.get("event_family") in ["jgp_stage","world_junior"]:
		var kind := "jgp" if event.event_family == "jgp_stage" else "world_junior"
		var resolved: bool = career.selection_state.get("decisions",{}).has(kind)
		var candidates: Array = Assignment.candidates_from_archives(career,kind,false)
		var evidence: Array = candidates[0].results if not candidates.is_empty() else []
		var annual_policy := preload("res://src/simulation/annual_selection_policy_service.gd").target(career,kind,int(event.get("ruleset_season_start_year",2018)))
		var selection_reasons: Array[String] = []
		var selection_codes: Array[String] = []
		if not annual_policy.errors.is_empty(): selection_reasons.append("年度政策损坏："+"；".join(annual_policy.errors))
		elif annual_policy.target.is_empty(): selection_reasons.append("本赛季目标选拔制度未覆盖")
		if kind == "jgp" and jgp_start_ids(career).size() >= int(annual_policy.target.get("max_starts",2)):
			selection_reasons.append("本季JGP站数上限已安排或使用，无需逐站确认不参加")
			selection_codes.append("jgp_two_start_limit")
		if resolved: selection_reasons.append("本轮已决议，完整候选审计见下方")
		if kind == "jgp":
			if not window.is_empty():
				if now < str(window.opens): selection_reasons.append("报名窗口尚未开放")
				if now > deadline: selection_reasons.append("报名截止日期已过")
			elif deadline.length() >= 7 and now.substr(0,7) > deadline.substr(0,7):
				selection_reasons.append("选拔申请截止季度已过")
		if kind == "world_junior":
			selection_reasons.append_array(Assignment.world_selection_window_errors(career,int(event.get("ruleset_season_start_year",2018))))
			for required in Assignment.designated_events("world_junior",Bundle.season_year(career),career):
				if not evidence.any(func(row): return row.event_id == required): selection_reasons.append("缺少必需指定赛事完整成绩：%s" % required)
		elif evidence.is_empty():
			var designated: Array = Assignment.designated_events(kind,int(event.get("ruleset_season_start_year",2018)),career)
			var participated: bool = career.competition_archive.any(func(a): return a.get("status") == "complete" and not a.get("world_only",false) and designated.has(a.get("event_id")) and a.get("final_standings",[]).any(func(r): return r.get("athlete_id") == "player"))
			if not participated: selection_reasons.append("须先完成公开指定赛事")
		choices.append({"id":"request_assignment","label":"提交公开选拔申请（可申请不代表达到派遣标准）","available":selection_reasons.is_empty(),"deadline":deadline,"costs":_costs(false,false,true),"reasons":selection_reasons,"reason_codes":selection_codes})
		choices.append({"id":"no_assignment","label":"暂无派遣：可选国内赛或自费国际赛","available":false,"deadline":deadline,"costs":{},"reasons":["本赛不能自费购买派遣名额"],"reason_codes":["assignment_required"]})
	choices.append({"id":"skip","label":"本次不参加","available":true,"deadline":deadline,"costs":_costs(false,false,true),"reasons":[],"reason_codes":["voluntary_decline"]})
	for application in career.selection_state.applications.values():
		if application.get("event_id") != event.get("event_id") or not application.get("route_id") in ["enter","self_fund_enter","skip"]: continue
		for choice in choices:
			if choice.id == application.route_id: continue
			choice.available = false
			choice.reasons.append(FINALIZED_REASON)
	if career.season_state.get("entry_plan",{}).get("entries",{}).get(event.get("event_id"),{}).get("status") == "confirmed" and career.competition_state.is_empty() and not career.competition_archive.any(func(a): return a.get("event_id") == event.get("event_id")):
		choices.append({"id":"withdraw","label":"主动退赛（报名费用不退）","available":true,"deadline":deadline,"costs":_costs(false,false,true),"reasons":[],"reason_codes":["explicit_withdrawal_no_refund"]})
	return choices

static func jgp_start_ids(career) -> Array:
	var ids: Array = []
	var suffix := "_%d" % Bundle.season_year(career)
	for event_id in career.selection_state.assignments.get("player",[]):
		if str(event_id).begins_with("isu_jgp_") and str(event_id).ends_with(suffix) and not str(event_id).contains("final") and not ids.has(event_id): ids.append(event_id)
	for event_id in career.selection_state.get("jgp",{}).get("events",{}):
		if not str(event_id).begins_with("isu_jgp_") or not str(event_id).ends_with(suffix) or str(event_id).contains("final"): continue
		if career.selection_state.jgp.events[event_id].any(func(row): return row.get("athlete_id") == "player") and not ids.has(event_id): ids.append(event_id)
	for archive in career.competition_archive:
		var event_id := str(archive.get("event_id",""))
		if not event_id.begins_with("isu_jgp_") or not event_id.ends_with(suffix) or event_id.contains("final") or bool(archive.get("world_only",false)): continue
		if archive.get("status") == "complete" and archive.get("final_standings",[]).any(func(row): return row.get("athlete_id") == "player") and not ids.has(event_id): ids.append(event_id)
	return ids

static func has_entry_choice(choices: Array) -> bool:
	return choices.any(func(option): return option.get("id") in ["enter","self_fund_enter","request_assignment","withdraw"] and bool(option.get("available",false)))

static func _costs(self_fund: bool, international: bool, skip: bool = false) -> Dictionary:
	if skip: return {"money":0.0,"fatigue":0.0,"training_familiarity":0.0,"guardian_closeness":0.0,"coach_trust":0.0,"reputation":0.0}
	return {"money":30.0 if self_fund else (8.0 if international else 3.0),"fatigue":12.0 if self_fund else (8.0 if international else 3.0),"training_familiarity":3.0 if self_fund else 1.0,"guardian_closeness":-3.0 if self_fund else 0.0,"coach_trust":-2.0 if self_fund else 1.0,"reputation":1.0 if self_fund else 0.5}

static func apply(career, command: Dictionary) -> Dictionary:
	if not command.get("event_id") is String or not command.get("route_id") is String: return {"ok":false,"error":"报名命令无效"}
	var bundle := Bundle.for_career(career)
	if not bundle.errors.is_empty(): return {"ok":false,"error":"赛历不可用"}
	var event := {}
	for candidate in bundle.calendar.events:
		if candidate.event_id == command.event_id: event = candidate; break
	if event.is_empty(): return {"ok":false,"error":"未知赛事"}
	if event.get("event_family") == "beijing_trial":
		var trials = load("res://src/simulation/beijing_trial_service.gd")
		if command.route_id == "enter": return trials.enroll(career,"beijing2022_women_trials","entry-beijing-series")
		if command.route_id == "skip": return trials.decline(career,"entry-beijing-series-decline")
		if command.route_id == "withdraw": return withdraw(career,str(event.event_id))
		if command.route_id == "medical_pause": return _pause_for_recovery(career,str(event.event_id))
		return {"ok":false,"error":"北京选拔报名路径无效"}
	var receipt := "%s:%s" % [command.event_id,command.route_id]
	if career.selection_state.applications.has(receipt): return {"ok":true,"events":[]}
	for application in career.selection_state.applications.values():
		if application.get("event_id") == event.event_id and application.get("route_id") in ["enter","self_fund_enter","skip"]:
			return {"ok":false,"error":FINALIZED_REASON}
	var routes := options(career,event,bundle); var choice := {}
	for route in routes:
		if route.id == command.route_id: choice = route
	if choice.is_empty() or not choice.available: return {"ok":false,"error":"当前不允许此报名路径：%s" % ",".join(choice.get("reasons",[]))}
	if command.route_id == "enter" and preload("res://src/simulation/senior_championship_service.gd").supports(event):
		var championship := preload("res://src/simulation/senior_championship_service.gd").preview(career,event)
		if not championship.errors.is_empty() or not championship.selected.any(func(row):return row.athlete_id == "player"): return {"ok":false,"error":"未获得本届世锦赛派遣"}
		preload("res://src/simulation/senior_championship_service.gd").commit(career,championship)
	if command.route_id == "enter" and preload("res://src/simulation/pandemic_grand_prix_service.gd").supports(event):
		if not career.selection_state.assignments.has("player"): career.selection_state.assignments.player = []
		if not career.selection_state.assignments.player.has(event.event_id): career.selection_state.assignments.player.append(event.event_id)
	if command.route_id == "enter" and preload("res://src/simulation/senior_grand_prix_service.gd").supports(event):
		var invitation := preload("res://src/simulation/senior_grand_prix_service.gd").commit(career,event)
		if not invitation.errors.is_empty() or not invitation.invited: return {"ok":false,"error":"尚未获得该站成年大奖赛邀请"}
	if command.route_id == "enter" and preload("res://src/simulation/senior_grand_prix_service.gd").supports_final(event):
		preload("res://src/simulation/senior_grand_prix_service.gd").commit_final(career,event)
	if command.route_id == "request_nomination":
		var assignments: Dictionary = career.selection_state.assignments
		if not assignments.has("player"): assignments.player = []
		assignments.player.append(event.event_id)
	elif command.route_id == "request_assignment":
		var kind := "jgp" if event.event_family == "jgp_stage" else "world_junior"
		var candidates := Assignment.candidates_from_archives(career,kind)
		var decision := Assignment.resolve(career,candidates,4 if kind == "jgp" else 1,{"kind":kind,"bundle":bundle},career.seed)
		if not decision.errors.is_empty(): return {"ok":false,"error":str(decision.errors)}
		if not career.selection_state.has("decisions"): career.selection_state.decisions = {}
		career.selection_state.decisions[kind] = {"inputs":candidates.duplicate(true),"decision":decision.duplicate(true),"clock":career.clock.to_dict()}
		if kind == "jgp": preload("res://src/simulation/jgp_second_start_service.gd").initialize(career,decision,bundle.calendar)
		for id in decision.assignments:
			if not career.selection_state.assignments.has(id): career.selection_state.assignments[id] = []
			for event_id in decision.assignments[id]:
				if not career.selection_state.assignments[id].has(event_id): career.selection_state.assignments[id].append(event_id)
	else:
		var planner = load("res://src/simulation/season_calendar_planner.gd")
		var proposal: Dictionary
		# Refresh already constructs one fresh proposal. Do not perform a
		# second full-season international field qualification first.
		if not career.season_state.entry_plan.is_empty():
			proposal = planner.refresh_entry_eligibility(career,bundle.calendar,bundle.rules,career.season_state.entry_plan,str(event.event_id))
		else:
			# Initial individual entry has the same scope as subsequent entries.
			# Full-season previews remain available through the overview, but a
			# single decision must not eagerly qualify every future foreign field.
			var scoped_calendar: Dictionary = bundle.calendar.duplicate(false)
			scoped_calendar.events = [event]
			proposal = planner.propose(career,scoped_calendar,bundle.rules)
		if not proposal.errors.is_empty(): return {"ok":false,"error":str(proposal.errors)}
		var entry: Dictionary = proposal.plan.entries[event.event_id]
		entry.status = "declined" if command.route_id == "skip" else "confirmed"
		entry.player_override = command.route_id
		if not entry.available_adjustment_ids.has(command.route_id): entry.available_adjustment_ids.append(command.route_id)
		entry.eligibility_snapshot = choice.get("eligibility",entry.eligibility_snapshot)
		career.season_state.season_id = bundle.calendar.season_id
		career.season_state.entry_plan = proposal.plan.to_dict()
		career.season_state.event_statuses[event.event_id] = entry.status
		if event.get("event_family") == "club_league_final":
			career.season_state["club_league_standings"] = planner.club_league_standings(career)
		var costs: Dictionary = choice.costs
		career.athlete.resources.money -= float(costs.money)
		career.athlete.body.acute_fatigue = clampf(career.athlete.body.acute_fatigue + float(costs.fatigue),0,100)
		for segment in career.active_programs:
			if career.active_programs[segment].is_empty(): continue
			career.active_programs[segment].whole_run_familiarity = maxf(0,career.active_programs[segment].get("whole_run_familiarity",0) - float(costs.training_familiarity))
		if career.relationships.has("guardian"): career.relationships.guardian.closeness = clampf(career.relationships.guardian.closeness + float(costs.guardian_closeness),0,100)
		if career.relationships.has("coach"): career.relationships.coach.professional_trust = clampf(career.relationships.coach.professional_trust + float(costs.coach_trust),0,100)
		career.social_state["competition_reputation"] = float(career.social_state.get("competition_reputation",0)) + float(costs.reputation)
	var record := {"event_id":event.event_id,"route_id":command.route_id,"option_snapshot":choice.duplicate(true),"clock":career.clock.to_dict(),"reason_codes":choice.reason_codes.duplicate()}
	if command.route_id == "skip" and event.get("event_family") == "jgp_stage" and career.selection_state.get("jgp_second_start",{}).get("season_id") == bundle.calendar.season_id:
		var replacement := Assignment.replace_with_frozen_alternate(career,str(event.event_id),"player")
		if not replacement.is_empty():
			replacement["reason_code"] = "declined_assignment_offer"
			record["jgp_replacement"] = replacement
	career.selection_state.applications[receipt] = record
	career.event_ledger.append({"kind":"entry_application","application_id":receipt,"clock":career.clock.to_dict()})
	return {"ok":true,"events":[record]}
