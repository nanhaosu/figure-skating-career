class_name TechniqueCoherenceService
extends RefCounted

const AthleteState = preload("res://src/domain/athlete_state.gd")
const JUMP_IDS := ["toe_loop", "salchow", "loop", "flip", "lutz", "axel"]

static func minimum_floors(athlete: AthleteState) -> Dictionary:
	var jump_rotations := {}
	var highest_non_axel := 0
	for jump_id in JUMP_IDS:
		jump_rotations[jump_id] = 0
		if jump_id != "axel":
			highest_non_axel = maxi(highest_non_axel, int(athlete.jumps[jump_id].unlocked_rotations))
	if highest_non_axel >= 3:
		for jump_id in JUMP_IDS: jump_rotations[jump_id] = 2
		jump_rotations.toe_loop = 3
	elif highest_non_axel >= 2:
		for jump_id in JUMP_IDS: jump_rotations[jump_id] = 1
		jump_rotations.toe_loop = 2
		jump_rotations.salchow = 2
	for jump_id in JUMP_IDS:
		jump_rotations[jump_id] = maxi(int(jump_rotations[jump_id]), int(athlete.jumps[jump_id].unlocked_rotations))

	var advanced_spin := false
	for profile in athlete.spins.values():
		advanced_spin = advanced_spin or float(profile.proficiency) >= 60.0 or int(profile.level_features) >= 4
	var spin_foundation := {}
	var spin_proficiency := {}
	if advanced_spin:
		for key in ["rotation", "centering", "balance", "position_control"]: spin_foundation[key] = 30.0
		spin_foundation.flexibility = 18.0
		spin_foundation.entry_exit = 20.0
		for spin_id in ["upright", "sit", "camel"]: spin_proficiency[spin_id] = 18.0
	return {
		"jump_rotations": jump_rotations,
		"spin_foundation": spin_foundation,
		"spin_proficiency": spin_proficiency,
	}

static func apply(athlete: AthleteState) -> Array[Dictionary]:
	var corrections: Array[Dictionary] = []
	var floors := minimum_floors(athlete)
	for jump_id in floors.jump_rotations:
		var jump = athlete.jumps[jump_id]
		var target := int(floors.jump_rotations[jump_id])
		for rotations in range(1, target + 1):
			var key: String = str(["", "single", "double", "triple", "quad"][rotations])
			if int(jump.attempt_evidence[key].attempts) == 0:
				jump.attempt_evidence[key].attempts = 8
				jump.attempt_evidence[key].successes = 3
				jump.attempt_evidence[key].clean_successes = 1
				jump.proficiency[key] = maxf(float(jump.proficiency[key]), 22.0)
				corrections.append({"kind": "jump_prerequisite", "jump_id": jump_id, "rotations": rotations, "evidence_scope": "training_only"})
		jump.unlocked_rotations = maxi(int(jump.unlocked_rotations), target)
		jump.attempts = _total_attempts(jump)
	for key in floors.spin_foundation:
		var before := float(athlete.spin_foundation[key])
		athlete.spin_foundation[key] = maxf(before, float(floors.spin_foundation[key]))
		if float(athlete.spin_foundation[key]) > before:
			corrections.append({"kind": "spin_shared_foundation", "field": key, "from": before, "to": athlete.spin_foundation[key]})
	for spin_id in floors.spin_proficiency:
		var before := float(athlete.spins[spin_id].proficiency)
		athlete.spins[spin_id].proficiency = maxf(before, float(floors.spin_proficiency[spin_id]))
		if float(athlete.spins[spin_id].proficiency) > before:
			corrections.append({"kind": "spin_prerequisite", "spin_id": spin_id, "from": before, "to": athlete.spins[spin_id].proficiency})
	return corrections

static func _total_attempts(jump) -> int:
	var total := 0
	for evidence in jump.attempt_evidence.values(): total += int(evidence.attempts)
	return total
