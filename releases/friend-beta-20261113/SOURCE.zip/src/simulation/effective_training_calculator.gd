class_name EffectiveTrainingCalculator
extends RefCounted

const TrainingPlan = preload("res://src/domain/training_plan.gd")
const ATTEMPTS_PER_FIVE_PERCENT := 28.0

static func apply_efficiency(volume: Dictionary, efficiency: float) -> void:
	var factor := clampf(efficiency, 0.0, 1.0)
	for key in volume.category_volumes: volume.category_volumes[key] *= factor
	var budget := 0
	for key in volume.jump_attempts:
		volume.jump_attempts[key] = int(floor(float(volume.jump_attempts[key]) * factor))
		budget += int(volume.jump_attempts[key])
	for specialist in volume.get("specialist_attempts", []):
		specialist.attempts = int(floor(float(specialist.attempts) * factor))
		if specialist.has("quality"): specialist.quality *= factor
		budget += int(specialist.attempts) * specialist.action.parts.size()
	volume.jump_attempt_budget = budget
	volume.quality *= factor
	for jump_id in volume.get("jump_qualities",{}):
		volume.jump_qualities[jump_id] *= factor

static func calculate(career, plan: TrainingPlan) -> Dictionary:
	var shares: Dictionary = plan.shares
	var constraints: Array[String] = []
	if career == null or career.athlete == null or shares.is_empty():
		return {"category_volumes": {}, "jump_attempts": {}, "quality": 0.0, "constraints": ["invalid_training_context"], "total_hours_band": "未知"}
	var athlete = career.athlete
	var age: int = career.clock.age_on(athlete.birth_year) if career.clock != null else 10
	var age_factor := 0.85 if age <= 8 else (0.95 if age <= 10 else (1.05 if age <= 12 else 1.0))
	var ice_access := float(athlete.resources.get("ice_access", 0.0))
	var money := float(athlete.resources.get("money", 0.0))
	var ice_factor := clampf(0.45 + ice_access * 0.015, 0.35, 1.30)
	var money_factor := clampf(0.80 + money * 0.004, 0.65, 1.15)
	var coach_trust := 35.0
	if career.relationships.has("coach"):
		coach_trust = float(career.relationships.coach.professional_trust)
	var supervision_factor := clampf(0.80 + coach_trust * 0.004, 0.75, 1.15)
	var acute := float(athlete.body.get("acute_fatigue", 0.0))
	var cumulative := float(athlete.body.get("cumulative_fatigue", 0.0))
	var fatigue_factor := clampf(1.0 - acute * 0.004 - cumulative * 0.006, 0.30, 1.0)
	if ice_access < 20.0: constraints.append("limited_ice_access")
	if money < 20.0: constraints.append("limited_training_funds")
	if fatigue_factor < 0.75: constraints.append("fatigue_limits_training_volume")
	if _has_medical_restriction(career):
		fatigue_factor *= 0.55
		constraints.append("medical_restriction_limits_training")
	var volume_factor := age_factor * ice_factor * money_factor * supervision_factor * fatigue_factor
	var quality := clampf((money_factor + supervision_factor + fatigue_factor) / 3.0, 0.40, 1.15)
	var category_volumes := {}
	var jump_qualities := {}
	var jump_attempts := {}
	for category_id in TrainingPlan.CATEGORY_IDS:
		category_volumes[category_id] = snappedf(float(shares.get(category_id, 0)) * volume_factor, 0.01)
		if category_id.begins_with("jump_"):
			var jump_id := category_id.trim_prefix("jump_")
			jump_qualities[jump_id] = quality*float(plan.lesson_quality.get(category_id,1.0))
			var blocks := float(shares.get(category_id, 0)) / float(TrainingPlan.SHARE_STEP)
			jump_attempts[jump_id] = maxi(0, int(round(blocks * ATTEMPTS_PER_FIVE_PERCENT * volume_factor)))
	var active_share := 100 - int(shares.get("rest", 0))
	var total_budget := 0
	for count in jump_attempts.values(): total_budget += int(count)
	var specialist_attempts: Array = []
	var reserved := {}
	var original_attempts := jump_attempts.duplicate()
	for target in plan.specialist_targets:
		if target.action.parts.size() < 2: continue
		if not preload("res://src/simulation/athlete_function_service.gd").action_constraints(career,target.action).allowed: continue
		var required := {}
		for part in target.action.parts: required[part.jump_id] = int(required.get(part.jump_id,0))+1
		var combinations: int = int(target.allocated_attempt_budget)/int(target.action.parts.size())
		for jump_id in required:
			var available := maxi(0,int(original_attempts.get(jump_id,0))/2-int(reserved.get(jump_id,0)))
			combinations = mini(combinations,available/int(required[jump_id]))
		if combinations <= 0: continue
		for jump_id in required:
			var cost: int = combinations*int(required[jump_id])
			jump_attempts[jump_id] -= cost
			reserved[jump_id] = int(reserved.get(jump_id,0))+cost
		var specialist_quality := 0.0
		for part in target.action.parts: specialist_quality += float(jump_qualities.get(part.jump_id,quality))
		specialist_quality /= float(target.action.parts.size())
		specialist_attempts.append({"action":target.action.duplicate(true),"attempts":combinations,"quality":specialist_quality})
	var estimated_hours := float(active_share) * volume_factor
	var hours_band := "较少" if estimated_hours < 45.0 else ("正常" if estimated_hours < 80.0 else "充足")
	return {"category_volumes": category_volumes, "jump_attempts": jump_attempts, "jump_qualities":jump_qualities,"specialist_attempts":specialist_attempts,"jump_attempt_budget":total_budget,"quality": quality, "constraints": constraints, "total_hours_band": hours_band}

static func _has_medical_restriction(career) -> bool:
	return preload("res://src/simulation/athlete_condition_service.gd").has_medical_restriction(career)
