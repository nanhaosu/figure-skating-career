class_name OlympicQuotaService
extends RefCounted

const POLICY := "beijing2022_20210309_D1_D2"
const SOURCE := "https://sok.se/download/18.7b3b606f17b7e71c60970691/1630594886056/Beijing%202022%20-%20Qualification%20System%20-%20Figure%20Skating.pdf"
const MILANO_POLICY := "milano2026_D1_D2"
const MILANO_SOURCE := "https://isu-d8g8b4b7ece7aphs.a03.azurefd.net/isudamcontainer/CMS/Corporate-Site/Governance/Transparency/ISU-Communications/2741-OWG-Figure-Skating-Qualification-Competition-and-Judges-Draw-Beijing-1758706754-2014.pdf"
const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Evidence = preload("res://src/simulation/international_personal_eligibility.gd")
const SOURCE_YEARS := {"isu_wc2021":2020,"isu_olympic_qualifier_nebelhorn_2021":2021,"isu_wc2025":2024,"isu_olympic_qualifier_beijing_2025":2025}

static func from_worlds(archive: Dictionary) -> Dictionary:
	var milano: bool = archive.get("event_id") == "isu_wc2025"
	var event_id := "isu_wc2025" if milano else "isu_wc2021"
	var read := _archive_rows(archive,event_id,2024 if milano else 2020)
	if not read.errors.is_empty(): return _failure(read.errors)
	var result := allocate_worlds(read.rows,MILANO_POLICY if milano else POLICY)
	if result.errors.is_empty():
		result.source_event_id = event_id
		result.source_date = read.date
		result.fingerprint = read.fingerprint
	return result

static func from_qualifier(quota: Dictionary,archive: Dictionary) -> Dictionary:
	var milano: bool = quota.get("policy_id") == MILANO_POLICY
	var event_id := "isu_olympic_qualifier_beijing_2025" if milano else "isu_olympic_qualifier_nebelhorn_2021"
	var read := _archive_rows(archive,event_id,2025 if milano else 2021)
	if not read.errors.is_empty(): return _failure(read.errors)
	var result := allocate_qualifier(quota,read.rows)
	if result.errors.is_empty():
		result.source_event_id = event_id
		result.source_date = read.date
		result.fingerprint = read.fingerprint
	return result

static func settle(career,archive: Dictionary) -> Dictionary:
	var id := str(archive.get("event_id",""))
	if not SOURCE_YEARS.has(id): return {"errors":[],"changed":false}
	var milano: bool = int(SOURCE_YEARS[id]) >= 2024
	var worlds: bool = id in ["isu_wc2021","isu_wc2025"]
	var read := _archive_rows(archive,id,int(SOURCE_YEARS[id]))
	if not read.errors.is_empty(): return _failure(read.errors)
	var latest := "%04d-%02d-%02d" % [career.clock.year,career.clock.quarter*3,[31,30,30,31][career.clock.quarter-1]]
	if read.date > latest: return _failure(["不能结算未来国家席位赛果"])
	var state: Dictionary = (career.milano_olympic_quota_state if milano else career.olympic_quota_state).duplicate(true)
	var receipt: Dictionary = state.receipts.get(id,{})
	if not receipt.is_empty():
		if receipt.fingerprint != read.fingerprint: return _failure(["国家席位来源已改变，须显式更正，不能覆盖原赛果"])
		return {"errors":[],"changed":false}
	var result := from_worlds(archive) if worlds else from_qualifier(state.get("worlds",{}),archive)
	if not result.errors.is_empty(): return result
	state["worlds" if worlds else "qualifier"] = result.duplicate(true)
	state.current = result.duplicate(true)
	state.status = result.status
	state.receipts[id] = {"fingerprint":read.fingerprint,"applied_on":read.date}
	var error := preload("res://src/domain/olympic_quota_state.gd").validate(state)
	if not error.is_empty(): return _failure([error])
	if milano: career.milano_olympic_quota_state = state
	else: career.olympic_quota_state = state
	return {"errors":[],"changed":true,"countries":result.countries.duplicate(true)}

static func _archive_rows(raw: Dictionary,event_id: String,year: int) -> Dictionary:
	if raw.get("status") != "complete" or raw.get("event_id") != event_id or not Codec.validate(raw).is_empty(): return {"errors":["国家席位需要完整且可校验的正式比赛档案"]}
	var archive := Codec.expand(raw)
	if archive.is_empty(): return {"errors":["正式比赛归档无法完整解码"]}
	var resolved := Bundle.competition_event({"event_id":event_id,"ruleset_season_start_year":year,"competition_level":"senior"})
	if not resolved.errors.is_empty() or not Evidence._matches_event(archive.get("event",{}),resolved.event,"senior") or archive.get("season_id") != resolved.get("season_id"): return {"errors":["国家席位赛事与规范赛历不一致"]}
	if not archive.get("roster") is Array or archive.roster.is_empty() or not archive.get("final_standings") is Array or archive.final_standings.size() != archive.roster.size() or not archive.get("qualifiers") is Array or not archive.get("short_results") is Dictionary or not archive.get("free_results") is Dictionary: return {"errors":["国家席位档案缺少完整名单及两段成绩"]}
	if event_id == "isu_wc2025" and archive.qualifiers.size() != mini(24,archive.roster.size()): return {"errors":["波士顿世锦赛档案的自由滑晋级人数无效"]}
	if event_id == "isu_olympic_qualifier_beijing_2025" and archive.qualifiers.size() != archive.roster.size(): return {"errors":["北京资格赛档案缺少自由滑成绩"]}
	var identities := {}; var rows: Array = []
	for entrant in archive.roster:
		if not entrant is Dictionary or not entrant.get("athlete_id") is String or identities.has(entrant.athlete_id): return {"errors":["参赛身份无效或重复"]}
		identities[entrant.athlete_id] = str(entrant.get("federation",""))
	if identities.size() != archive.short_results.size() or archive.qualifiers.size() != archive.free_results.size(): return {"errors":["名单与分项成绩数量不一致"]}
	for standing in archive.final_standings:
		if not standing is Dictionary: return {"errors":["最终名次行无效"]}
		var id := str(standing.get("athlete_id",""))
		if not identities.has(id) or identities[id] != standing.get("federation"): return {"errors":["最终名次与原参赛协会不一致"]}
		var short_record: Dictionary = archive.short_results.get(id,{})
		var free_record: Dictionary = archive.free_results.get(id,{})
		var qualified: bool = archive.qualifiers.has(id)
		if short_record.is_empty() or qualified != not free_record.is_empty() or (standing.has("qualified") and standing.qualified != qualified): return {"errors":["自由滑晋级记录不一致"]}
		var points := {"short":0.0,"free":0.0}; var tes := {"short":0.0,"free":0.0}
		for segment in ["short","free"]:
			var record: Dictionary = short_record if segment == "short" else free_record
			if segment == "free" and not qualified: continue
			var score = record.get("score",{})
			if not score is Dictionary or not Evidence._tes_number(score.get("total")) or not Evidence._tes_number(score.get("tes")) or not Evidence._final_record(record): return {"errors":["分项成绩或最终技术认定无效"]}
			if record.get("protocol") is Dictionary:
				for field in ["total","tes"]:
					if record.protocol.has(field) and record.protocol[field] != score[field]: return {"errors":["小分表与分项成绩不一致"]}
			points[segment] = float(score.total)
			tes[segment] = float(score.tes)
			if not Evidence._tes_number(standing.get(segment+"_score")) or absf(float(standing[segment+"_score"])-points[segment]) > 0.011: return {"errors":["最终名次所列分项分数不一致"]}
		if qualified and (not Evidence._tes_number(standing.get("total_score")) or absf(float(standing.total_score)-points.short-points.free) > 0.011): return {"errors":["最终总分不等于实际两段成绩"]}
		rows.append({"athlete_id":id,"federation":identities[id],"rank":standing.get("rank"),"qualified":qualified,"short_score":points.short,"free_score":points.free,"short_tes":tes.short,"free_tes":tes.free})
	var errors := _row_errors(rows,event_id in ["isu_wc2021","isu_wc2025"])
	if not errors.is_empty(): return {"errors":errors}
	rows.sort_custom(func(a,b):return int(a.rank) < int(b.rank))
	return {"errors":[],"rows":rows,"date":str(resolved.event.end_date),"fingerprint":JSON.stringify(rows).sha256_text()}

# Allocation is to countries. No athlete-selection field is produced here.
static func allocate_worlds(rows: Array,policy_id: String = POLICY) -> Dictionary:
	if policy_id not in [POLICY,MILANO_POLICY]: return _failure(["未知奥运世锦赛席位规则"])
	var errors := _row_errors(rows,true)
	if not errors.is_empty(): return _failure(errors)
	var ranked := rows.duplicate(true)
	ranked.sort_custom(func(a,b):return int(a.rank) < int(b.rank))
	var grouped := {}; var details := {}; var countries := {}; var fs_ids: Array = []
	for row in ranked:
		if not grouped.has(row.federation): grouped[row.federation] = []
		grouped[row.federation].append(row)
		if row.qualified: fs_ids.append(row.athlete_id)
	var used := 0
	for federation in grouped:
		var entrants: Array = grouped[federation]
		var points := 0; var free_count := 0
		for index in entrants.size():
			var row: Dictionary = entrants[index]
			if index < 2: points += mini(16,int(row.rank)) if row.qualified else 18
			if row.qualified: free_count += 1
		var potential := 1
		if entrants.size() == 1:
			potential = 3 if int(entrants[0].rank) <= 2 else (2 if int(entrants[0].rank) <= 10 else 1)
		else: potential = 3 if points <= 13 else (2 if points <= 28 else 1)
		var multiple := mini(potential,free_count)
		var earned := multiple if multiple >= 2 else 0
		countries[federation] = earned
		used += earned
		details[federation] = {"best_rank":int(entrants[0].rank),"points":points,"potential":potential,"free_qualifiers":free_count,"worlds_places":earned,"additional_eligible":false}
	if used > 24: return _failure(["世锦赛多席分配超过项目上限，需核对完整名次"])
	# D.1 next-highest-country singles are not limited to FS qualifiers.
	for row in ranked:
		if used >= 24: break
		if int(countries[row.federation]) > 0: continue
		countries[row.federation] = 1
		used += 1
	for federation in details:
		details[federation].worlds_places = int(countries[federation])
		details[federation].additional_eligible = int(countries[federation]) > 0 and int(details[federation].potential) > int(countries[federation])
	return {"errors":[],"status":"worlds_complete","policy_id":policy_id,"source":MILANO_SOURCE if policy_id == MILANO_POLICY else SOURCE,"countries":countries,"details":details,"ordinary_places":used,"worlds_free_ids":fs_ids,"qualifier_awards":{},"standby":[],"host_additional":{},"reallocation_receipts":{}}

static func qualifier_candidates(quota: Dictionary,athletes: Array) -> Dictionary:
	var eligible_ids: Array = []; var reasons := {}
	for row in athletes:
		var id := str(row.get("athlete_id","")); var federation := str(row.get("federation",""))
		var places := int(quota.get("countries",{}).get(federation,0))
		if quota.get("status") != "worlds_complete": reasons[id] = "国家席位资料尚未齐备"
		elif places > 0 and not quota.get("details",{}).get(federation,{}).get("additional_eligible",false): reasons[id] = "已有世锦赛席位且不具额外席位资格"
		elif places > 0 and quota.get("worlds_free_ids",[]).has(id): reasons[id] = "争额外席位者不得是该届世锦赛自由滑参赛者"
		else: eligible_ids.append(id)
	return {"eligible_ids":eligible_ids,"reasons":reasons}

static func allocate_qualifier(quota: Dictionary,rows: Array) -> Dictionary:
	var policy_id := str(quota.get("policy_id",""))
	if quota.get("status") != "worlds_complete" or policy_id not in [POLICY,MILANO_POLICY] or not quota.get("countries") is Dictionary:
		return _failure(["缺少有效世锦赛国家席位记录"])
	var errors := _row_errors(rows,false)
	if not errors.is_empty(): return _failure(errors)
	var next := quota.duplicate(true)
	var ranked := rows.duplicate(true)
	ranked.sort_custom(func(a,b):return int(a.rank) < int(b.rank))
	var eligible := qualifier_candidates(quota,ranked)
	var milano := policy_id == MILANO_POLICY
	var offered := {}; var remaining := 5 if milano else 30-int(quota.ordinary_places)
	if milano: next.neutral_awards = {}
	for row in ranked:
		var federation := str(row.federation)
		if milano and federation == "AIN":
			if remaining > 0 and eligible.eligible_ids.has(row.athlete_id):
				next.neutral_awards[row.athlete_id] = {"athlete_id":row.athlete_id,"rank":int(row.rank),"places":1}
				next.ordinary_places += 1
				remaining -= 1
			continue
		if not eligible.eligible_ids.has(row.athlete_id) or offered.has(federation): continue
		offered[federation] = true
		if remaining > 0:
			next.countries[federation] = int(next.countries.get(federation,0))+1
			next.qualifier_awards[federation] = {"athlete_id":row.athlete_id,"rank":int(row.rank),"places":1}
			next.ordinary_places += 1
			remaining -= 1
		elif milano or int(next.countries.get(federation,0)) == 0:
			next.standby.append({"federation":federation,"athlete_id":row.athlete_id,"rank":int(row.rank)})
	var host := "ITA" if milano else "CHN"
	var host_attempted: bool = not milano or ranked.any(func(row):return row.federation == host)
	if host_attempted and int(next.countries.get(host,0)) == 0:
		next.host_additional[host] = {"places":1,"personal_eligibility_required":true,"source":"milano2026_host_country_additional_quota" if milano else "20210309_host_country_additional_quota","ordinary_quota":false}
	next.status = "qualifier_complete"
	next.qualifier_exclusions = eligible.reasons
	return next

static func reallocate(quota: Dictionary,released: Dictionary,date: String) -> Dictionary:
	if quota.get("policy_id") == MILANO_POLICY: return _failure(["米兰周期的席位递补尚未接入"])
	if quota.get("status") not in ["qualifier_complete","reallocated"] or date < "2021-10-31" or date > "2021-12-21": return _failure(["不在已核实的席位递补窗口内"])
	var receipt := (date+JSON.stringify(released)).sha256_text()
	if quota.get("reallocation_receipts",{}).has(receipt): return quota.duplicate(true)
	var next := quota.duplicate(true)
	var vacancies := 0
	for federation in released:
		var count = released[federation]
		if not _whole(count) or int(count) <= 0 or int(count) > int(next.countries.get(federation,0)): return _failure(["交回名额无效"])
		vacancies += int(count)
		next.countries[federation] -= int(count)
		next.ordinary_places -= int(count)
	var new_standby: Array = []; var awards: Array = []
	for row in next.standby:
		if vacancies > 0 and int(next.countries.get(row.federation,0)) == 0 and not released.has(row.federation):
			next.countries[row.federation] = 1
			next.ordinary_places += 1
			vacancies -= 1
			awards.append(row.duplicate(true))
		else: new_standby.append(row)
	next.standby = new_standby
	next.reallocation_receipts[receipt] = {"date":date,"released":released.duplicate(true),"awards":awards,"unfilled":vacancies}
	next.status = "reallocated"
	return next

static func _row_errors(rows: Array,national_limit: bool) -> Array[String]:
	var errors: Array[String] = []
	if rows.is_empty(): return ["缺少完整名次表"]
	var identities := {}; var ranks := {}; var countries := {}
	for row in rows:
		if not row is Dictionary or not row.get("athlete_id") is String or str(row.get("athlete_id","")).is_empty() or not row.get("federation") is String or str(row.get("federation","")).length() != 3 or not row.get("qualified") is bool or not _whole(row.get("rank")) or int(row.get("rank",0)) < 1:
			errors.append("名次、身份、协会或自由滑记录无效")
			continue
		if identities.has(row.athlete_id) or ranks.has(int(row.rank)): errors.append("比赛名次或身份重复")
		identities[row.athlete_id] = true
		ranks[int(row.rank)] = true
		countries[row.federation] = int(countries.get(row.federation,0))+1
		if national_limit and int(countries[row.federation]) > 3: errors.append("世锦赛同协会超过三位参赛者")
	for rank in range(1,rows.size()+1):
		if not ranks.has(rank): errors.append("名次表不完整")
	return errors

static func _whole(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floor(float(value))

static func _failure(errors: Array) -> Dictionary:
	return {"errors":errors,"status":"unknown","countries":{},"details":{},"ordinary_places":0}
