class_name SeniorChampionshipService
extends RefCounted

const Personal = preload("res://src/simulation/international_personal_eligibility.gd")
const Calendar = preload("res://src/content/season_calendar_repository.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const QUOTAS := "res://data/qualification/worlds_2021_initial_game_quotas.json"
const KEY := "worlds_2021"
# Finite associations represented by the current game world, not a complete
# historical ISU membership census. European associations stay on their path.
const FOUR_CONTINENTS_SUPPORTED := ["CHN","JPN","USA","KOR","CAN","KAZ","HKG","TPE","AUS","MEX"]
const FORMULA := "游戏公开派遣：先满足本届个人条件，再按已有完整国内赛最好两场总分之和、这两场自由滑之和、固定身份顺序排名；不要求参加全部赛事、不读取俱乐部偏好。疫情游戏补充：国内成绩从2019赛季起，仅计入本场赛前有效窗口；全体本国候选均无国内成绩时统一改用已有认可国际完赛成绩，绝不补造停赛期间成绩。外国协会使用已有国际完赛成绩。世锦赛国家初始名额采用已公示游戏表；落选赛每国最多1人。"

const FOUR_CONTINENTS_FORMULA := "游戏公开派遣：具备本届个人资格后，比较已有完整比赛最好两场总分、这两场自由滑分及固定身份顺序；中国使用有效国内成绩，全体缺少国内记录时才统一使用国际成绩。无全勤要求，不读取俱乐部偏好。"

const NEXT_WORLDS_FORMULA := "游戏公开派遣：先满足本届个人资格，比较已有完整国内赛最好两场总分、相同两场自由滑及固定身份顺序；全体缺少国内记录时统一比较认可国际成绩。无全勤要求，不读取俱乐部偏好。"
const MILANO_TRIAL := "cn_milano_qualifier_trials_2025"
const MILANO_QUALIFIER := "isu_olympic_qualifier_beijing_2025"
const MILANO_GAMES := "isu_owg2026"
const CUP_OF_CHINA_2025 := "isu_gpchn2025"
const MILANO_TRIAL_FORMULA := "游戏派遣按完整国内选拔赛总分、自由滑分排序。实际选拔还综合国际赛表现、竞技状态、心理和伤病，游戏只建模成绩部分。"
const MILANO_FINAL_FORMULA := "中国队选拔按中国杯和全国锦标赛两项总分之和，同分比其中一场的最高总分，并核验国家席位和个人国际 TES。两场均须有正式完赛记录。"

static func public_standard(event: Dictionary) -> String:
	match str(event.get("event_id","")):
		"isu_fc2022": return FOUR_CONTINENTS_FORMULA
		"isu_wc2022": return NEXT_WORLDS_FORMULA
		"isu_wc2024", "isu_wc2025": return NEXT_WORLDS_FORMULA
		MILANO_QUALIFIER, CUP_OF_CHINA_2025: return MILANO_TRIAL_FORMULA
		MILANO_GAMES: return MILANO_FINAL_FORMULA
		"isu_wc2021", "isu_olympic_qualifier_nebelhorn_2021": return FORMULA
	return ""

static func supports(event: Dictionary) -> bool:
	return event.get("event_id") in ["isu_wc2021","isu_olympic_qualifier_nebelhorn_2021","isu_fc2022","isu_wc2022","isu_wc2024","isu_wc2025",MILANO_TRIAL,MILANO_QUALIFIER,CUP_OF_CHINA_2025,MILANO_GAMES]

static func _key(event: Dictionary) -> String:
	if event.get("event_id") == "isu_fc2022": return "four_continents_2022"
	if event.get("event_id") == "isu_wc2022": return "worlds_2022"
	if event.get("event_id") in ["isu_wc2024","isu_wc2025",MILANO_TRIAL,MILANO_QUALIFIER,CUP_OF_CHINA_2025,MILANO_GAMES]: return str(event.event_id)
	return KEY if event.get("event_id") == "isu_wc2021" else "nebelhorn_2021"

static func allocate(rows: Array) -> Dictionary:
	var policy = JSON.parse_string(FileAccess.get_file_as_string(QUOTAS))
	if not policy is Dictionary or not policy.get("user_approved",false) or policy.get("event_id") != "isu_wc2021" or policy.get("default_places") != 1 or not Personal._same_value(policy.get("overrides"),{"JPN":3,"RUS":3,"KAZ":3,"CAN":2,"KOR":2,"USA":2}):
		return {"errors":["2021世锦赛游戏初始名额表不可核对"],"selected":[],"audit":{}}
	return _allocate_with_policy(rows,policy)

static func allocate_qualifier(rows: Array,quota: Dictionary,event_id: String = "isu_olympic_qualifier_nebelhorn_2021") -> Dictionary:
	if quota.is_empty() or quota.get("status") == "unknown":
		return {"errors":["落选赛须先核对本生涯世锦赛国家席位；未知不等于零席"],"reason_code":"country_quota_unknown","selected":[],"audit":{}}
	var quota_service = preload("res://src/simulation/olympic_quota_service.gd")
	var expected_policy: String = quota_service.MILANO_POLICY if event_id == MILANO_QUALIFIER else quota_service.POLICY
	if quota.get("status") != "worlds_complete" or quota.get("policy_id") != expected_policy:
		return {"errors":["已知国家席位记录的规则依据无效，不能按未知旧档跳过"],"reason_code":"country_quota_invalid","selected":[],"audit":{}}
	var candidates: Array = rows.duplicate(true)
	var permitted := preload("res://src/simulation/olympic_quota_service.gd").qualifier_candidates(quota,candidates)
	for row in candidates:
		row.eligible = row.get("eligible",false) and permitted.eligible_ids.has(row.athlete_id)
		row.quota_reason = permitted.reasons.get(row.athlete_id,"")
	if event_id != MILANO_QUALIFIER:
		return _allocate_with_policy(candidates,{"event_id":event_id,"default_places":1,"overrides":{},"policy_id":"nebelhorn2021_one_per_eligible_country","label":"奥运落选赛：每国最多1人；已有名额但不能争额外席位的协会不参加此资格分类。争额外席位者不得参加过2021世锦赛自由滑。按游戏公开成绩派遣，争取的是国家席位，不是个人自动入选。"})
	return _allocate_with_policy(candidates,{"event_id":event_id,"default_places":1,"overrides":{"AIN":2},"policy_id":expected_policy+"_qualifier_entries","public_formula":MILANO_TRIAL_FORMULA,"label":"每个符合资格的协会可派一人。争额外席位者须未参加本周期世锦赛自由滑。选手争取的是国家席位。"})

static func allocate_for_event(career,event: Dictionary,rows: Array) -> Dictionary:
	var event_id := str(event.get("event_id",""))
	if event_id == "isu_wc2024":
		return _allocate_with_policy(rows,{"event_id":event_id,"default_places":1,"overrides":{"JPN":3,"KOR":3,"USA":2,"BEL":2,"CAN":2,"EST":2,"GER":2,"SUI":2},"policy_id":"worlds2024_initial_reference_caps","label":"蒙特利尔为本段生涯首场世锦赛，采用赛前公开国家参赛上限；参赛仍按本档个人资格和选拔。","public_formula":NEXT_WORLDS_FORMULA})
	if event_id == "isu_wc2025":
		var policy := _next_worlds_policy(career,"isu_wc2024",2023,event_id)
		if not policy.get("errors",[]).is_empty(): return {"errors":policy.errors,"reason_code":policy.reason_code,"selected":[],"audit":{}}
		return _allocate_with_policy(rows,policy)
	if event_id == MILANO_TRIAL:
		return _allocate_with_policy(rows,{"event_id":event_id,"default_places":0,"overrides":{"CHN":5},"policy_id":"milano_qualifier_trials_2025","label":"已收录的选拔资格来源为上一届全国锦标赛成年适龄前五；十四冬和过往冬奥成绩路径尚未接入。","public_formula":"符合当季成年年龄并在上届全锦赛适龄选手中进入前五。"})
	if event_id == MILANO_QUALIFIER:
		return allocate_qualifier(rows,career.milano_olympic_quota_state.worlds,event_id)
	if event_id == CUP_OF_CHINA_2025:
		return _allocate_with_policy(rows,{"event_id":event_id,"default_places":0,"overrides":{"CHN":2,"USA":3,"JPN":3,"KOR":2,"ITA":1,"GEO":1},"policy_id":"milano_cup_china_domestic_trial","label":"中国杯东道主两席按国内选拔赛成绩派遣。外国选手采用有限名单的游戏分站模型。","public_formula":MILANO_TRIAL_FORMULA})
	if event_id == MILANO_GAMES:
		var quota: Dictionary = career.milano_olympic_quota_state.current
		if quota.get("status") != "qualifier_complete": return {"errors":["米兰冬奥会须核对本生涯两阶段国家席位"],"reason_code":"country_quota_unknown","selected":[],"audit":{}}
		var caps: Dictionary = quota.countries.duplicate(true)
		for country in quota.host_additional: caps[country] = int(caps.get(country,0)) + int(quota.host_additional[country].places)
		caps.AIN = quota.get("neutral_awards",{}).size()
		return _allocate_with_policy(rows,{"event_id":event_id,"default_places":0,"overrides":caps,"policy_id":"milano2026_dispatch","label":"米兰冬奥派遣以本档国家席位、适龄与个人国际 TES 为前提。","public_formula":MILANO_FINAL_FORMULA,"source_fingerprint":quota.get("fingerprint",""),"source_date":quota.get("source_date","")})
	if event.get("event_id") == "isu_wc2022":
		var policy := _next_worlds_policy(career)
		if not policy.get("errors",[]).is_empty(): return {"errors":policy.errors,"reason_code":policy.reason_code,"selected":[],"audit":{}}
		var candidates: Array = rows.duplicate(true)
		for row in candidates:
			if not preload("res://src/content/international_participation_policy.gd").permitted({"scope":"international","start_date":"2022-03-23"},str(row.get("federation",""))):
				row.eligible = false
				row.quota_reason = "association_participation_suspended_20220301"
		return _allocate_with_policy(candidates,policy)
	if event.get("event_id") == "isu_fc2022":
		var candidates: Array = rows.duplicate(true)
		for row in candidates:
			if not FOUR_CONTINENTS_SUPPORTED.has(str(row.get("federation",""))):
				row.eligible = false
				row.quota_reason = "outside_modeled_four_continents_associations"
		return _allocate_with_policy(candidates,{"event_id":"isu_fc2022","default_places":3,"overrides":{},"policy_id":"four_continents2022_three_per_association","label":"四大洲：每协会最多3人，须独立满足个人资格；仅当前已建模非欧洲协会参加，塔林承办不改变参赛协会范围。采用2395资格版本，最终修订未核实。国内派遣采用游戏公开成绩公式。","public_formula":FOUR_CONTINENTS_FORMULA})
	return allocate(rows) if event.get("event_id") == "isu_wc2021" else allocate_qualifier(rows,career.olympic_quota_state.get("worlds",{}))

static func _next_worlds_policy(career,source_id: String = "isu_wc2021",source_year: int = 2020,target_id: String = "isu_wc2022") -> Dictionary:
	var source := {}
	var latest := "%04d-%02d-%02d" % [career.clock.year,career.clock.quarter*3,[31,30,30,31][career.clock.quarter-1]]
	if career.competition_timeline.mode == "dated": latest = str(career.competition_timeline.date)
	for archive in career.competition_archive:
		if not archive is Dictionary or archive.get("event_id") != source_id: continue
		# Reuse canonical full-protocol extraction, not Olympic allocation: its
		# FS-count and 24-place constraints do not govern next year's Worlds.
		var read: Dictionary = preload("res://src/simulation/olympic_quota_service.gd")._archive_rows(archive,source_id,source_year)
		if not read.errors.is_empty() or str(read.get("date","")) > latest:
			return {"errors":["前届世锦赛完整赛果尚不能核对"],"reason_code":"country_quota_invalid"}
		if not source.is_empty() and source.fingerprint != read.fingerprint:
			return {"errors":["前届世锦赛来源存在冲突，不能覆盖国家名额"],"reason_code":"country_quota_invalid"}
		source = read
	if source.is_empty(): return {"errors":["本生涯缺少前届世锦赛赛果；国家名额未知，不套用历史默认表"],"reason_code":"country_quota_unknown"}
	var grouped := {}
	for row in source.rows:
		if not grouped.has(row.federation): grouped[row.federation] = []
		grouped[row.federation].append(row)
	var caps := {}
	for country in grouped:
		var entrants: Array = grouped[country]
		entrants.sort_custom(func(a,b):return int(a.rank)<int(b.rank))
		if entrants.size() == 1:
			caps[country] = 3 if int(entrants[0].rank)<=2 else 2 if int(entrants[0].rank)<=10 else 1
		else:
			var points := 0
			for row in entrants.slice(0,2): points += mini(16,int(row.rank)) if row.qualified else 18
			caps[country] = 3 if points<=13 else 2 if points<=28 else 1
	var policy_id := "worlds2022_actual_worlds2021_places" if target_id == "isu_wc2022" else target_id+"_from_"+source_id
	return {"event_id":target_id,"default_places":1,"overrides":caps,"policy_id":policy_id,"label":"世锦赛国家名额按本生涯前届世锦赛完整成绩计算；单人前2/前10、多人成绩积分13/28分别对应3/2席，否则1席。每名选手仍须独立满足个人资格及派遣。","source_fingerprint":source.fingerprint,"source_date":source.date,"public_formula":NEXT_WORLDS_FORMULA}

static func _allocate_with_policy(rows: Array,policy: Dictionary) -> Dictionary:
	var ranked: Array = []; var identities := {}
	for raw in rows:
		if not raw is Dictionary or str(raw.get("athlete_id","")).is_empty() or identities.has(raw.athlete_id) or str(raw.get("federation","")).is_empty():
			return {"errors":["世锦赛候选身份缺失或重复"],"selected":[],"audit":{}}
		identities[raw.athlete_id] = true
		var row: Dictionary = raw.duplicate(true)
		var observed := {}; var results: Array = []
		for result in row.get("results",[]):
			if not result is Dictionary or str(result.get("event_id","")).is_empty() or not Personal._tes_number(result.get("total")) or not Personal._tes_number(result.get("free")):
				return {"errors":["派遣成绩必须可核对且为有限非负分数"],"selected":[],"audit":{}}
			if observed.has(result.event_id):
				if observed[result.event_id] != result: return {"errors":["同场派遣成绩发生冲突"],"selected":[],"audit":{}}
				continue
			observed[result.event_id] = result
			results.append(result.duplicate(true))
		results.sort_custom(func(a,b):
			if float(a.total) != float(b.total): return float(a.total) > float(b.total)
			if float(a.free) != float(b.free): return float(a.free) > float(b.free)
			return str(a.event_id) < str(b.event_id))
		row.counted = results.slice(0,2); row.score = 0.0; row.free_score = 0.0
		for result in row.counted:
			row.score += float(result.total); row.free_score += float(result.free)
		ranked.append(row)
	var milano_final: bool = policy.event_id == MILANO_GAMES
	ranked.sort_custom(func(a,b):
		if a.get("eligible",false) != b.get("eligible",false): return a.get("eligible",false)
		if milano_final:
			var a_total := snappedf(float(a.score),0.01)
			var b_total := snappedf(float(b.score),0.01)
			if a_total != b_total: return a_total > b_total
			if a.federation != b.federation: return str(a.federation) < str(b.federation)
			if a.federation == "CHN":
				var a_best := 0.0 if a.counted.is_empty() else float(a.counted[0].total)
				var b_best := 0.0 if b.counted.is_empty() else float(b.counted[0].total)
				if a_best != b_best: return a_best > b_best
				return str(a.athlete_id) < str(b.athlete_id)
		elif a.score != b.score: return a.score > b.score
		if a.free_score != b.free_score: return a.free_score > b.free_score
		return str(a.athlete_id) < str(b.athlete_id))
	var selected: Array = []; var used := {}
	for row in ranked:
		if not row.get("eligible",false): continue
		var cap := int(policy.overrides.get(row.federation,policy.default_places))
		if int(used.get(row.federation,0)) >= cap: continue
		selected.append(row.duplicate(true)); used[row.federation] = int(used.get(row.federation,0))+1
	return {"errors":[],"event_id":policy.event_id,"selected":selected,"policy_id":policy.policy_id,"label":policy.label,"audit":{"hidden_replacement":false,"candidate_rows":ranked,"public_formula":policy.get("public_formula",FORMULA),"national_places":{"default_places":policy.default_places,"overrides":policy.overrides.duplicate(true),"source_fingerprint":policy.get("source_fingerprint",""),"source_date":policy.get("source_date","")}}}

static func preview(career,event: Dictionary,pool: Array = []) -> Dictionary:
	var calendars := {}
	var event_id := str(event.get("event_id",""))
	var year := int(event.get("ruleset_season_start_year",0))
	var policy := Personal.policy_for(event)
	var requires_tes := not policy.is_empty()
	var canonical := Personal._canonical_event(event_id,year,"senior",calendars)
	if event_id == MILANO_TRIAL:
		canonical = preload("res://src/content/season_bundle_repository.gd").competition_event({"event_id":event_id,"ruleset_season_start_year":2025,"competition_level":"senior"}).event
	if not supports(event) or not Personal._matches_event(event,canonical,"senior"):
		return {"errors":["世锦赛规范赛事不匹配"],"selected":[],"audit":{}}
	var saved: Dictionary = career.selection_state.get("decisions",{}).get(_key(event),{}).get("decision",{})
	if not saved.is_empty(): return saved.duplicate(true)
	var cutoff := str(policy.cutoff) if requires_tes else str(canonical.get("application_deadline",canonical.start_date))
	var rows: Array = []
	var min_age := preload("res://src/simulation/event_eligibility_evaluator.gd").senior_min_age(year)
	if pool.is_empty():
		var countries: Array[String] = []
		for record in career.world_athletes.values():
			if not countries.has(str(record.get("federation",""))): countries.append(str(record.get("federation","")))
		pool = load("res://src/simulation/formal_roster_generator.gd")._eligible_persistent_pool(career.world_athletes,countries,year,"senior")
	var qualified_batch: Dictionary = Personal.evaluate_many(career,event,policy,pool.map(func(record):return str(record.athlete_id))+["player"]) if requires_tes else {}
	var results_table := _result_table(career,cutoff)
	for record in pool:
		var id := str(record.athlete_id)
		var qualified: Dictionary = qualified_batch[id] if requires_tes else {"eligible":true,"basis":"senior_age_and_legal_programmes_in_persistent_pool"}
		rows.append({"athlete_id":id,"federation":record.federation,"eligible":qualified.eligible,"personal":qualified,"results":_subject_results(results_table,id,str(record.federation))})
	var age := preload("res://src/domain/athlete_identity.gd").age_gate(career.athlete.birth_year,career.athlete.birth_date,year,min_age,1000)
	var personal: Dictionary = qualified_batch.player if requires_tes else {"eligible":age.status == "eligible","age":age}
	var permitted: bool = preload("res://src/simulation/competitive_level_service.gd").permits(career,event)
	rows.append({"athlete_id":"player","federation":str(career.story_context.home_federation),"eligible":personal.eligible and permitted,"personal":personal,"results":_subject_results(results_table,"player",str(career.story_context.home_federation))})
	# Apply the same evidence mode to all home candidates. Comparing one
	# athlete's domestic results with another's international results would
	# reward missing domestic records rather than their actual performance.
	var home := str(career.story_context.home_federation)
	if not rows.any(func(row):return row.federation == home and not row.results.is_empty()):
		for row in rows:
			if row.federation == home: row.results = _subject_results(results_table,str(row.athlete_id),"")
	if year >= 2023:
		for row in rows:
			row.eligible = row.eligible and preload("res://src/content/international_participation_policy.gd").permitted(event,str(row.federation))
	if event_id in [MILANO_TRIAL,MILANO_QUALIFIER,CUP_OF_CHINA_2025,MILANO_GAMES]:
		_apply_milano_selection(career,event_id,rows,results_table)
	return allocate_for_event(career,event,rows)

static func _apply_milano_selection(career,event_id: String,rows: Array,results_table: Dictionary) -> void:
	var allowed_at_trials := {}
	if event_id == MILANO_TRIAL:
		var age_eligible := {}
		for row in rows:
			if row.federation == "CHN" and row.eligible: age_eligible[row.athlete_id] = true
		for archive in career.competition_archive:
			if archive.get("event_id") != "cn_nationals_2024" or archive.get("status") != "complete": continue
			var read: Dictionary = preload("res://src/simulation/olympic_quota_service.gd")._archive_rows(archive,"cn_nationals_2024",2024)
			if not read.errors.is_empty(): continue
			for placement in read.rows:
				if placement.qualified and age_eligible.has(placement.athlete_id): allowed_at_trials[placement.athlete_id] = true
				if allowed_at_trials.size() == 5: break
			break
	for row in rows:
		if row.federation != "CHN":
			if row.federation == "AIN" and event_id == MILANO_GAMES:
				row.eligible = row.eligible and career.milano_olympic_quota_state.current.get("neutral_awards",{}).has(row.athlete_id)
			continue
		if event_id == MILANO_TRIAL:
			row.eligible = row.eligible and allowed_at_trials.has(row.athlete_id)
		elif event_id in [MILANO_QUALIFIER,CUP_OF_CHINA_2025]:
			row.results = _subject_results(results_table,row.athlete_id,"CHN").filter(func(result):return result.event_id == MILANO_TRIAL)
			row.eligible = row.eligible and row.results.size() == 1
		elif event_id == MILANO_GAMES:
			var domestic: Array = _subject_results(results_table,row.athlete_id,"CHN").filter(func(result):return result.event_id == "cn_nationals_2025")
			var international: Array = _subject_results(results_table,row.athlete_id,"").filter(func(result):return result.event_id == CUP_OF_CHINA_2025)
			row.results = domestic + international
			row.eligible = row.eligible and domestic.size() == 1 and international.size() == 1

static func commit(career,plan: Dictionary) -> void:
	if not plan.get("errors",[]).is_empty() or plan.get("audit",{}).is_empty(): return
	if not career.selection_state.has("decisions"): career.selection_state.decisions = {}
	var event_id := str(plan.get("event_id","isu_wc2021"))
	var key := _key({"event_id":event_id})
	if career.selection_state.decisions.has(key): return
	career.selection_state.decisions[key] = {"inputs":plan.audit.candidate_rows.duplicate(true),"decision":plan.duplicate(true),"clock":career.clock.to_dict()}
	record_milano_dispatch(career,plan)
	for row in plan.selected:
		if not career.selection_state.assignments.has(row.athlete_id): career.selection_state.assignments[row.athlete_id] = []
		if not career.selection_state.assignments[row.athlete_id].has(event_id): career.selection_state.assignments[row.athlete_id].append(event_id)

static func record_milano_dispatch(career,plan: Dictionary) -> void:
	if plan.get("event_id") != MILANO_GAMES: return
	career.milano_olympic_quota_state.dispatch = {"event_id":MILANO_GAMES,"policy_id":plan.policy_id,"selected_ids":plan.selected.filter(func(row):return row.federation == "CHN").map(func(row):return row.athlete_id),"quota_fingerprint":plan.audit.national_places.source_fingerprint}

static func _results(career,id: String,federation: String,cutoff: String = "2021-03-01") -> Array:
	return _subject_results(_result_table(career,cutoff),id,federation)

static func _subject_results(table: Dictionary,id: String,federation: String) -> Array:
	return table["domestic" if federation == "CHN" else "international"].get(id,[]).duplicate(true)

static func _result_table(career,cutoff: String) -> Dictionary:
	# One authentic scan for the whole candidate field. Keep only score rows,
	# not hundreds of decoded athlete/programme/performance snapshots.
	var table := {"domestic":{},"international":{}}
	var calendars := {}
	var latest := "%04d-%02d-%02d" % [career.clock.year,career.clock.quarter*3,[31,30,30,31][career.clock.quarter-1]]
	if career.competition_timeline.mode == "dated": latest = str(career.competition_timeline.date)
	for raw in career.competition_archive:
		if not raw is Dictionary or raw.get("status") != "complete" or not Codec.validate(raw).is_empty(): continue
		# validate() authenticates the public index against the immutable body.
		# Resolve applicability from that index before inflating old protocols.
		var e: Dictionary = raw.get("event",{})
		if str(e.get("end_date","")) > cutoff or str(e.get("end_date","")) > latest: continue
		var canonical := {}
		if e.get("scope") == "domestic":
			for year in range(2019,int(e.get("ruleset_season_start_year",2021))+1):
				var key := str(year)
				if not calendars.has(key): calendars[key] = Calendar.load_calendar(year,"CHN","women_singles")
				for candidate in calendars[key].get("calendar",{}).get("events",[]):
					if candidate.event_id == raw.get("event_id") and int(candidate.get("ruleset_season_start_year",0)) == int(e.get("ruleset_season_start_year",0)) and candidate.get("level_options",[]).has("senior") and Calendar.event_status(candidate) != "cancelled": canonical = candidate
		else:
			canonical = Personal._canonical_event(str(raw.get("event_id","")),int(e.get("ruleset_season_start_year",0)),str(e.get("competition_level","junior")),calendars)
		if canonical.is_empty() or not Personal._matches_event(e,canonical,str(e.get("competition_level","senior"))): continue
		var category := "domestic" if e.get("scope") == "domestic" else "international"
		if category == "international" and int(e.get("ruleset_season_start_year",0)) < 2018: continue
		var archive := Codec.expand(raw)
		for id in archive.get("short_results",{}):
			if id == "player" and raw.get("world_only",false): continue
			var short_row: Dictionary = archive.short_results[id]
			var free_row: Dictionary = archive.get("free_results",{}).get(id,{})
			if short_row.is_empty() or free_row.is_empty() or not Personal._final_record(short_row) or not Personal._final_record(free_row): continue
			var s = short_row.get("score",{}).get("total"); var f = free_row.get("score",{}).get("total")
			if not Personal._tes_number(s) or not Personal._tes_number(f): continue
			if not table[category].has(id): table[category][id] = []
			table[category][id].append({"event_id":canonical.event_id,"total":float(s)+float(f),"free":float(f)})
	return table
