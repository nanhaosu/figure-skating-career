class_name FormalCompetitionSimulator
extends RefCounted

const AthleteState = preload("res://src/domain/athlete_state.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const FormalRosterGenerator = preload("res://src/simulation/formal_roster_generator.gd")
const FormalPracticeService = preload("res://src/simulation/formal_practice_service.gd")
const FormalSegmentSimulator = preload("res://src/simulation/formal_segment_simulator.gd")
const BetweenSegmentAdjuster = preload("res://src/simulation/between_segment_adjuster.gd")
const SeasonBundleRepository = preload("res://src/content/season_bundle_repository.gd")
const JudgingProfileRepository = preload("res://src/content/judging_profile_repository.gd")
const FormalCompetitionConsequenceService = preload("res://src/simulation/formal_competition_consequence_service.gd")
const PersonalRecordService = preload("res://src/simulation/personal_record_service.gd")
const AthleteConditionService = preload("res://src/simulation/athlete_condition_service.gd")

const BETWEEN_SEGMENT_EXERTION_RETENTION := 0.25

static func _player_programs(session: Dictionary) -> Dictionary:
	for row in session.get("roster",[]):
		if row.get("is_player",false):
			return {"short":row.get("short_program",{}),"free":row.get("free_program",{})}
	return {}

static func create_session(career, event: Dictionary, programs: Dictionary, strategy_id: String, seed: int, roster_size: int = 34, world_only: bool = false) -> Dictionary:
	var archived := _committed(career,str(event.get("event_id","")))
	if not archived.is_empty(): return _reopen(archived)
	if not world_only and not AthleteConditionService.can_compete(career,programs): return {"kind":"formal", "status":"error", "errors":["伤病尚未恢复，暂不能参赛"]}
	var resolved := SeasonBundleRepository.competition_event(event) if world_only else SeasonBundleRepository.competition_for_career(career,event)
	if not resolved.errors.is_empty(): return {"kind":"formal","status":"error","errors":resolved.errors}
	event = resolved.event
	if not world_only and event.get("entry_route") in ["federation_assignment","federation_selection"] and not Array(career.selection_state.assignments.get("player",[])).has(event.event_id):
		return {"kind":"formal","status":"error","errors":["尚未获得该赛事派遣"]}
	var generated := FormalRosterGenerator.build(career, event, seed ^ 0x134F, mini(roster_size, int(event.get("field_size_limit", roster_size))),not world_only)
	if not generated.errors.is_empty():
		var failure := {"kind":"formal","status":"error","errors":generated.errors}
		if generated.has("reason_code"): failure.reason_code = generated.reason_code
		if world_only and generated.get("world_unavailable",false):
			failure.world_unavailable = true
			failure.reason_code = generated.get("reason_code","")
		return failure
	for athlete_id in generated.created_athletes:
		career.world_athletes[athlete_id] = generated.created_athletes[athlete_id].duplicate(true)
	var roster: Array = generated.roster.duplicate(true)
	for row in roster:
		if row.is_player:
			row.short_program = Dictionary(programs.get("short", {})).duplicate(true)
			row.free_program = Dictionary(programs.get("free", {})).duplicate(true)
	var practice := FormalPracticeService.observe(career.athlete, programs, {
		"pain": float(career.athlete.body.get("acute_fatigue", 0.0)),
		"equipment_risk": 0.0,
	}, _subseed(seed, "player", "practice",str(event.event_id)))
	return {
		"kind": "formal", "record_version": 1, "status": "practice_ready", "errors": [], "world_only":world_only,
		"event": event.duplicate(true), "event_id": str(event.event_id), "season_id": resolved.season_id,
		"resolved_rules":resolved.rules,"roster_policy":event.competition_policy.roster_policy,
		"seed": seed, "strategy_id": strategy_id, "strategy_overrides": {},
		"roster": roster, "created_athletes": generated.created_athletes,
		"judge_profiles": JudgingProfileRepository.panel(event,seed), "practice": practice, "practice_response": {},
		"short_results": {}, "short_standings": [], "qualifiers": [], "player_qualified": false,
		"free_results": {}, "free_standings": [], "final_standings": [], "archive": {},
	}

# The same roster, segment, judging and consequence services run absent-player
# events. No substitute scores or player outcomes are manufactured.
static func simulate_world_event(career,event: Dictionary,seed: int) -> Dictionary:
	var session := create_session(career,event,career.active_programs,"balanced",seed,34,true)
	if not session.get("errors",[]).is_empty(): return session
	if session.get("status") == "complete": return session
	session.status = "short_ready"
	return lock_short(career,session)

static func complete_practice(session: Dictionary, response_id: String) -> Dictionary:
	var next := session.duplicate(true)
	if str(next.get("status", "")) != "practice_ready": return next
	var observation: Dictionary = Dictionary(next.get("practice", {}))
	if bool(observation.get("meaningful", false)):
		var response := FormalPracticeService.apply_response(observation, response_id)
		if not response.errors.is_empty():
			next.errors = response.errors
			return next
		next.practice_response = response
		next.strategy_overrides = response.strategy_overrides
	elif response_id != "accept":
		next.errors = ["本次公开训练没有需要处理的异常"]
		return next
	next.status = "short_ready"
	next.errors = []
	return next

static func lock_short(career, session: Dictionary) -> Dictionary:
	var archived := _committed(career,str(session.get("event_id","")))
	if not archived.is_empty(): return session.duplicate(true) if session.get("archive",{}) == archived else _reopen(archived)
	var next := session.duplicate(true)
	if not Dictionary(next.get("short_results", {})).is_empty(): return next
	if not next.get("world_only",false) and not AthleteConditionService.can_compete(career,_player_programs(next)):
		next.errors = ["伤病尚未恢复，暂不能参赛"]
		return next
	if str(next.get("status", "")) != "short_ready":
		next.errors = ["当前状态不能锁定短节目"]
		return next
	var rules: Dictionary = next.resolved_rules.short
	var results := {}
	for row in next.roster:
		var athlete = AthleteState.from_dict(row.athlete)
		var program = SkatingProgram.from_dict(row.short_program)
		var context := _judging_context(career,next,row)
		if row.is_player: context.merge(AthleteConditionService.competition_context(career), true)
		if row.is_player: context.condition = career.condition_state.duplicate(true)
		var strategy := _strategy(next) if row.is_player else _opponent_strategy(row)
		var record := FormalSegmentSimulator.simulate(athlete, program, strategy, context, rules, _subseed(int(next.seed), str(row.athlete_id), "short",str(next.event_id)))
		if not record.errors.is_empty():
			next.errors = ["%s的短节目无法模拟：%s" % [row.name, record.errors[0]]]
			return next
		results[str(row.athlete_id)] = record
	var standings := _short_standings(next.roster, results)
	var qualifiers: Array[String] = []
	var cut := int(next.event.competition_policy.free_cut)
	if cut <= 0: cut = standings.size()
	for index in standings.size():
		standings[index].rank = index + 1
		standings[index].qualified = index < cut
		if index < cut: qualifiers.append(str(standings[index].athlete_id))
	next.short_results = results
	next.short_standings = standings
	next.qualifiers = qualifiers
	next.player_qualified = qualifiers.has("player")
	next.status = "free_adjustment" if next.player_qualified else "free_ready"
	next.errors = []
	if not next.player_qualified:
		return lock_free(career, next, "watch")
	return next

static func free_segment_context(career, session: Dictionary, row: Dictionary) -> Dictionary:
	var context := _judging_context(career,session,row)
	var short_performance: Dictionary = session.short_results[str(row.athlete_id)].performance
	var short_finish := float(short_performance.fatigue_end)
	var short_start := short_finish
	if not Array(short_performance.get("elements",[])).is_empty():
		short_start = float(short_performance.elements[0].get("fatigue_before",short_finish))
	# Formal short and free programmes are separated by recovery time. Persistent
	# body fatigue remains, while only a fraction of the short programme's
	# temporary on-ice exertion carries into the free skate.
	context.starting_fatigue = snappedf(short_start + maxf(0.0,short_finish-short_start) * BETWEEN_SEGMENT_EXERTION_RETENTION,0.01)
	if row.is_player:
		context.merge(AthleteConditionService.competition_context(career), true)
		context.condition = career.condition_state.duplicate(true)
	return context

static func lock_free(career, session: Dictionary, adjustment_id: String, confirmed_program: Dictionary = {}) -> Dictionary:
	var archived := _committed(career,str(session.get("event_id","")))
	if not archived.is_empty(): return session.duplicate(true) if session.get("archive",{}) == archived else _reopen(archived)
	var next := session.duplicate(true)
	if str(next.get("status", "")) == "complete": return next
	if bool(next.get("player_qualified", false)) and not AthleteConditionService.can_compete(career,_player_programs(next)):
		next.errors = ["伤病尚未恢复，暂不能参赛"]
		return next
	if Dictionary(next.get("short_results", {})).is_empty():
		next.errors = ["短节目尚未完成"]
		return next
	if not bool(next.get("player_qualified", false)) and adjustment_id != "watch":
		next.errors = ["未晋级自由滑，不能调整或执行玩家自由滑"]
		return next
	if bool(next.player_qualified) and not ["keep", "protect", "chase"].has(adjustment_id):
		next.errors = ["无效的自由滑调整：%s" % adjustment_id]
		return next
	var results := {}
	var rules: Dictionary = next.resolved_rules.free
	for row in next.roster:
		var athlete_id := str(row.athlete_id)
		if not next.qualifiers.has(athlete_id): continue
		var athlete = AthleteState.from_dict(row.athlete)
		var program = SkatingProgram.from_dict(row.free_program)
		var strategy := _strategy(next) if row.is_player else _opponent_strategy(row)
		if row.is_player:
			var short_record: Dictionary = next.short_results.player.performance.duplicate(true)
			short_record.provisional_rank = _rank_of(next.short_standings, "player")
			var adjustment := BetweenSegmentAdjuster.propose(program, adjustment_id)
			var edited = SkatingProgram.from_dict(confirmed_program) if not confirmed_program.is_empty() else adjustment.program
			var revision := BetweenSegmentAdjuster.revise(program, edited, athlete, rules.segment_rules)
			if not revision.errors.is_empty():
				next.errors = revision.errors
				return next
			program = revision.program
			# Confirming the between-segment editor publishes a competition
			# version. Preserve revision/familiarity costs, but not draft workflow.
			var publication := preload("res://src/simulation/program_draft_service.gd").lock_for_competition(program,athlete,rules.segment_rules)
			if not publication.errors.is_empty():
				next.errors = publication.errors
				return next
			program = publication.program
			next.free_revision = {"program":program.to_dict(), "familiarity_cost":revision.familiarity_cost}
			for key in adjustment.strategy_overrides: strategy[key] = adjustment.strategy_overrides[key]
		var context := free_segment_context(career, next, row)
		var record := FormalSegmentSimulator.simulate(athlete, program, strategy, context, rules, _subseed(int(next.seed), athlete_id, "free",str(next.event_id)))
		if not record.errors.is_empty():
			next.errors = ["%s的自由滑无法模拟：%s" % [row.name, record.errors[0]]]
			return next
		results[athlete_id] = record
	var free_standings := _free_standings(next.roster, next.short_results, results, next.qualifiers)
	for index in free_standings.size(): free_standings[index].rank = index + 1
	next.free_results = results
	next.free_standings = free_standings
	next.final_standings = _complete_final_standings(free_standings, next.short_standings)
	next.status = "complete"
	next.archive = {
		"record_version": 1, "event": next.event.duplicate(true), "event_id": next.event_id,
		"season_id": next.season_id, "seed": next.seed, "status": "complete",
		"judge_profiles":next.judge_profiles.duplicate(true),"roster":next.roster.duplicate(true),
		"roster_policy":next.roster_policy,"resolved_rules":next.resolved_rules.duplicate(true),"qualifiers":next.qualifiers.duplicate(),
		"short_results": next.short_results.duplicate(true), "short_standings": next.short_standings.duplicate(true),
		"free_results": results.duplicate(true), "free_standings": free_standings.duplicate(true),
		"final_standings": next.final_standings.duplicate(true), "player_qualified": next.player_qualified,
		"scoring_era_id": rules.scoring_catalog.scoring_era_id, "record_eligibility": str(next.event.get("record_eligibility", "domestic_only")),
		"consequences_applied": false,
	}
	if next.get("world_only",false):
		next.archive.world_only = true
		var world_result := FormalCompetitionConsequenceService.apply_world(career,next.archive)
		if not world_result.errors.is_empty():
			next.errors = world_result.errors
			return next
		var npc_errors := _update_npc_records(career,next.archive)
		if not npc_errors.is_empty(): next.errors = npc_errors; return next
		next.archive.consequences_applied = true
		next.archive = load("res://src/domain/career_state.gd")._restore_competition_state(JSON.parse_string(JSON.stringify(next.archive)))
		var quota_result := preload("res://src/simulation/olympic_quota_service.gd").settle(career,next.archive)
		if not quota_result.errors.is_empty():
			next.errors = quota_result.errors
			return next
		career.competition_archive.append(load("res://src/persistence/competition_archive_codec.gd").compact(next.archive))
		next.errors = []
		return next
	var player_result := _player_result(next)
	next.player_result = player_result.duplicate(true)
	next.archive.player_result = player_result
	var consequence := FormalCompetitionConsequenceService.apply(career, next.archive)
	if not consequence.errors.is_empty():
		next.errors = consequence.errors
		return next
	career.record_book = consequence.career_changes.record_book
	career.ranking_state = consequence.career_changes.ranking_state
	if consequence.career_changes.has("experience_state"): career.experience_state = consequence.career_changes.experience_state.duplicate(true)
	if consequence.career_changes.has("selection_state"): career.selection_state = consequence.career_changes.selection_state.duplicate(true)
	if consequence.career_changes.has("world_athletes"): career.world_athletes = consequence.career_changes.world_athletes.duplicate(true)
	next.archive = consequence.career_changes.archive
	var npc_errors := _update_npc_records(career, next.archive)
	if not npc_errors.is_empty(): next.errors = npc_errors; return next
	for segment in ["short","free"]:
		var player_segment: Dictionary = next.get(segment+"_results",{}).get("player",{})
		if not player_segment.is_empty():
			preload("res://src/simulation/repertoire_evidence_service.gd").record_competition(career,player_segment.get("performance",{}),"competition:%s:%s" % [next.event_id,segment])
	# Freeze a save-stable value snapshot: JSON reload must never alter an archive.
	preload("res://src/simulation/coach_lesson_service.gd").observe_archive(career,next.archive)
	next.archive = load("res://src/domain/career_state.gd")._restore_competition_state(JSON.parse_string(JSON.stringify(next.archive)))
	var quota_result := preload("res://src/simulation/olympic_quota_service.gd").settle(career,next.archive)
	if not quota_result.errors.is_empty():
		next.errors = quota_result.errors
		return next
	career.competition_archive.append(load("res://src/persistence/competition_archive_codec.gd").compact(next.archive))
	next.errors = []
	return next

static func _short_standings(roster: Array, results: Dictionary) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	for entrant in roster:
		var record: Dictionary = results[str(entrant.athlete_id)]
		rows.append({"athlete_id": entrant.athlete_id, "name": entrant.name, "federation": entrant.federation, "club_id": entrant.club_id, "is_player": entrant.is_player, "short_score": record.score.total, "tes": record.score.tes})
	rows.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if not is_equal_approx(float(a.short_score), float(b.short_score)): return float(a.short_score) > float(b.short_score)
		if not is_equal_approx(float(a.tes), float(b.tes)): return float(a.tes) > float(b.tes)
		return str(a.athlete_id) < str(b.athlete_id)
	)
	return rows

static func _free_standings(roster: Array, short_results: Dictionary, free_results: Dictionary, qualifiers: Array) -> Array[Dictionary]:
	var by_id := {}
	for entrant in roster: by_id[str(entrant.athlete_id)] = entrant
	var rows: Array[Dictionary] = []
	for athlete_id in qualifiers:
		var entrant: Dictionary = by_id[athlete_id]
		var short_score := float(short_results[athlete_id].score.total)
		var free_score := float(free_results[athlete_id].score.total)
		rows.append({"athlete_id": athlete_id, "name": entrant.name, "federation": entrant.federation, "club_id": entrant.club_id, "is_player": entrant.is_player, "short_score": short_score, "free_score": free_score, "total_score": snappedf(short_score + free_score, 0.01), "free_tes": free_results[athlete_id].score.tes})
	rows.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if not is_equal_approx(float(a.total_score), float(b.total_score)): return float(a.total_score) > float(b.total_score)
		if not is_equal_approx(float(a.free_score), float(b.free_score)): return float(a.free_score) > float(b.free_score)
		return str(a.athlete_id) < str(b.athlete_id)
	)
	return rows

static func _complete_final_standings(free_rows: Array, short_rows: Array) -> Array[Dictionary]:
	var rows: Array[Dictionary] = free_rows.duplicate(true)
	var included := {}
	for row in rows: included[str(row.athlete_id)] = true
	for short_row in short_rows:
		if included.has(str(short_row.athlete_id)): continue
		var cut_row: Dictionary = Dictionary(short_row).duplicate(true)
		cut_row.rank = rows.size() + 1
		cut_row.qualified = false
		rows.append(cut_row)
	return rows

static func _strategy(session: Dictionary) -> Dictionary:
	var result := {"risk": str(session.get("strategy_id", "balanced"))}
	result.risk = {"safe":"conservative","attack":"aggressive"}.get(result.risk,result.risk)
	if not ["conservative", "balanced", "aggressive"].has(result.risk): result.risk = "balanced"
	for key in session.get("strategy_overrides", {}): result[key] = session.strategy_overrides[key]
	return result

static func _protection(row: Dictionary) -> float:
	return {"leader": 58.0, "middle": 25.0, "development": 5.0, "player": 0.0}.get(str(row.tier), 0.0)

static func _judging_context(career, session: Dictionary, row: Dictionary) -> Dictionary:
	var reputation := float(career.social_state.get("competition_reputation",0.0)) if row.is_player else _protection(row)
	return {"judge_profiles":JudgingProfileRepository.for_entrant(session.judge_profiles,row,session.event,reputation),"reputation":{},"pcs_recognition":FormalSegmentSimulator.recognition_from_archives(career.competition_archive,str(row.get("athlete_id", "player"))),"panel_context":{"reputation_protection":clampf(reputation,0,60)}}

static func _committed(career, event_id: String) -> Dictionary:
	for archive in career.competition_archive:
		if archive.get("event_id") == event_id and archive.get("status") == "complete": return archive.duplicate(true)
	return {}

static func _reopen(archive: Dictionary) -> Dictionary:
	archive = load("res://src/persistence/competition_archive_codec.gd").expand(archive)
	var session := archive.duplicate(true)
	session.kind = "formal"; session.errors = []; session.archive = archive.duplicate(true)
	return session

static func _rank_of(standings: Array, athlete_id: String) -> int:
	for row in standings:
		if str(row.athlete_id) == athlete_id: return int(row.rank)
	return standings.size()

static func _player_result(session: Dictionary) -> Dictionary:
	var short_rank := _rank_of(session.short_standings, "player")
	var short_record: Dictionary = session.short_results.player
	var result := {"short_score":float(short_record.score.total),"short_rank":short_rank,"short_domestic_bonus":float(short_record.score.domestic_bonus),"qualified":bool(session.player_qualified),"falls":int(short_record.performance.falls)}
	if session.player_qualified:
		var final_rank := _rank_of(session.free_standings, "player")
		var free_record: Dictionary = session.free_results.player
		result.free_score = float(free_record.score.total)
		result.free_domestic_bonus = float(free_record.score.domestic_bonus)
		result.total_score = snappedf(float(result.short_score) + float(result.free_score), 0.01)
		result.final_rank = final_rank
		result.falls += int(free_record.performance.falls)
	return result

static func _subseed(root_seed: int, athlete_id: String, segment: String, event_id: String) -> int:
	var hash_value: int = 2166136261
	for byte in ("%d:%s:%s:%s" % [root_seed, event_id, athlete_id, segment]).to_utf8_buffer():
		hash_value = ((hash_value ^ int(byte)) * 16777619) & 0xFFFFFFFF
	return hash_value

static func _update_npc_records(career, archive: Dictionary) -> Array[String]:
	var updates := {}
	for short_row in archive.short_standings:
		var athlete_id := str(short_row.athlete_id)
		if athlete_id == "player" or not career.world_athletes.has(athlete_id): continue
		var saved: Dictionary = career.world_athletes[athlete_id].duplicate(true)
		if Array(saved.get("competition_history",[])).any(func(entry): return entry.get("event_id") == archive.event_id and entry.get("season_id") == archive.season_id): continue
		var economic: Dictionary = preload("res://src/simulation/opponent_season_schedule_service.gd").settle_actual_participation(saved,archive)
		if not economic.errors.is_empty(): return economic.errors
		var qualified: bool = archive.free_results.has(athlete_id)
		var result: Dictionary = {"short_score":float(archive.short_results[athlete_id].score.total),"short_domestic_bonus":float(archive.short_results[athlete_id].score.domestic_bonus),"short_rank":int(short_row.rank),"qualified":qualified}
		if qualified:
			result.free_score = float(archive.free_results[athlete_id].score.total)
			result.free_domestic_bonus = float(archive.free_results[athlete_id].score.domestic_bonus)
			result.total_score = snappedf(float(result.short_score) + float(result.free_score), 0.01)
			result.final_rank = _rank_of(archive.free_standings, athlete_id)
		# Record preview is read-only; only this per-athlete top-level result differs.
		var view: Dictionary = archive.duplicate(false)
		view.player_result = result
		var records: Dictionary = saved.get("record_book", {"international":{},"all_formal":{}})
		saved.record_book = PersonalRecordService.preview(records, view).next_record_book
		if not saved.has("competition_history"): saved.competition_history = []
		saved.competition_history.append({"event_id":archive.event_id,"season_id":archive.season_id,"short_rank":int(short_row.rank),"final_rank":int(result.get("final_rank",0)),"qualified":qualified})
		updates[athlete_id] = saved
	for id in updates: career.world_athletes[id] = updates[id]
	return []

static func _opponent_strategy(row: Dictionary) -> Dictionary:
	var risk := str(row.get("opponent_risk","balanced"))
	return {"risk":risk if risk in ["conservative","balanced","aggressive"] else "balanced"}
