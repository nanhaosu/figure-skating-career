class_name TechnicalPanelSimulator
extends RefCounted

const JumpRuleLedger = preload("res://src/simulation/jump_rule_ledger.gd")

static func resolve_performance(performance: Dictionary, reputation: Dictionary, influence: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var result := {"segment": str(performance.get("segment", "")), "calls": [], "final_elements": [], "controversy_cost": 0.0, "rule_events": [], "actual_jump_counts": {}}
	for element in performance.get("elements", []):
		var called := resolve_call(element, reputation, influence, rng)
		result.calls.append(called)
		var final_element: Dictionary = Dictionary(called.final_values).duplicate(true)
		final_element.element_id = str(element.get("element_id", ""))
		result.final_elements.append(final_element)
		result.controversy_cost += float(called.controversy_cost)
	result.controversy_cost = snappedf(float(result.controversy_cost), 0.01)
	var ledger := JumpRuleLedger.apply(result.final_elements, Dictionary(performance.get("segment_rules", {})))
	result.final_elements = ledger.elements
	result.rule_events = ledger.rule_events
	result.actual_jump_counts = ledger.actual_jump_counts
	return result

static func resolve_call(performance_element: Dictionary, reputation: Dictionary, influence: Dictionary, _rng: RandomNumberGenerator) -> Dictionary:
	if performance_element.get("parts", []) is Array and not performance_element.get("parts", []).is_empty():
		return _resolve_combination_call(performance_element, reputation, influence, _rng)
	var actual: Dictionary = Dictionary(performance_element.get("actual", {})).duplicate(true)
	var final_values := {
		"abbreviation": str(performance_element.get("abbreviation", "?")),
		"kind": str(performance_element.get("kind", "")),
		"parts": Array(performance_element.get("parts", [])).duplicate(true),
		"base_value": float(performance_element.get("base_value", 0.0)),
		"live_goe": float(performance_element.get("live_goe", 0.0)),
		"status": str(performance_element.get("status", "success")),
	}
	var result := {
		"element_id": str(performance_element.get("element_id", "")),
		"evidence_confidence": "clear",
		"final_values": final_values,
		"calls": [],
		"intervention_sources": [],
		"controversy_cost": 0.0,
	}
	if bool(actual.get("fall", false)):
		final_values.status = "error"
		final_values.live_goe = minf(float(final_values.live_goe), -maxf(0.10, float(final_values.base_value) * 0.50))
		result.calls.append("fall")
		return result

	var reasons: Array = performance_element.get("review_reasons", [])
	if reasons.has("takeoff_edge"):
		_resolve_edge(performance_element, reputation, influence, result)
	if reasons.has("rotation_completion"):
		_resolve_rotation(performance_element, influence, result)
	if reasons.has("level") or (final_values.kind in ["spin", "step_sequence"] and performance_element.get("facts", {}).has("credited_features")):
		_resolve_level(performance_element, result)
	if reasons.is_empty() and final_values.status == "error":
		result.calls.append(str(actual.get("error_type", "execution_error")))
	return result

static func _resolve_combination_call(performance_element: Dictionary, reputation: Dictionary, influence: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var abbreviations: Array[String] = []
	var base_value := 0.0
	var part_goe := 0.0
	var status := "success"
	var calls: Array[String] = []
	var interventions: Array[String] = []
	var controversy := 0.0
	var confidence := "clear"
	for part in performance_element.parts:
		var called := resolve_call(part, reputation, influence, rng)
		abbreviations.append(str(called.final_values.abbreviation))
		base_value += float(called.final_values.base_value)
		part_goe += float(called.final_values.live_goe)
		if called.final_values.status == "error": status = "error"
		if called.evidence_confidence == "ambiguous": confidence = "ambiguous"
		for call_id in called.calls: calls.append("part_%d:%s" % [int(part.get("part_index", 0)) + 1, str(call_id)])
		for source in called.intervention_sources:
			if not interventions.has(source): interventions.append(source)
		controversy += float(called.controversy_cost)
	return {
		"element_id": str(performance_element.get("element_id", "")), "evidence_confidence": confidence,
		"final_values": {
			"abbreviation": "+".join(abbreviations), "base_value": snappedf(base_value, 0.01),
			"live_goe": snappedf(minf(float(performance_element.get("live_goe", 0.0)), part_goe) if status == "error" else part_goe, 0.01),
			"status": status, "kind": "jump", "parts": Array(performance_element.get("parts", [])).duplicate(true),
		},
		"calls": calls, "intervention_sources": interventions, "controversy_cost": snappedf(controversy, 0.01),
	}

static func _resolve_edge(performance_element: Dictionary, reputation: Dictionary, influence: Dictionary, result: Dictionary) -> void:
	var edge_quality := float(performance_element.get("actual", {}).get("takeoff_edge_quality", 50.0))
	var clear_wrong_edge := edge_quality < 30.0
	var stereotype := float(reputation.get("edge_symbol_count", 0)) * 3.0
	var protection := float(influence.get("priority", 0.0)) * 0.5 + float(influence.get("coach_voice", 0.0)) * 0.2
	var call_pressure := (55.0 - edge_quality) + stereotype - protection
	var symbol := ""
	if clear_wrong_edge or call_pressure >= 22.0:
		symbol = "e"
	elif call_pressure >= 10.0:
		symbol = "!"
	result.evidence_confidence = "clear" if clear_wrong_edge else "ambiguous"
	for source in ["priority", "coach_voice"]:
		if float(influence.get(source, 0.0)) > 0.0: result.intervention_sources.append(source)
	if clear_wrong_edge and protection > 0.0:
		result.controversy_cost = snappedf(protection * 0.08, 0.01)
	if not symbol.is_empty():
		result.final_values.abbreviation += symbol
		result.final_values.live_goe = snappedf(minf(float(result.final_values.live_goe), -float(result.final_values.base_value) * (0.25 if symbol == "!" else 0.45)), 0.01)
		result.final_values.status = "error"
		result.calls.append("edge_%s" % symbol)
	else:
		result.final_values.status = "success"
		result.calls.append("edge_clean")

static func _resolve_rotation(performance_element: Dictionary, influence: Dictionary, result: Dictionary) -> void:
	var severe := str(performance_element.get("actual", {}).get("error_type", "")) == "pop"
	if severe:
		# Performance already supplies the lower actual jump and its base value.
		# Do not downgrade that jump a second time against the original plan.
		result.evidence_confidence = "clear"
		result.final_values.status = "error"
		result.calls.append("jump_popped")
		return
	var symbol := "<<" if severe else "<"
	result.evidence_confidence = "clear" if severe else "ambiguous"
	if not severe and float(influence.get("priority", 0.0)) >= 70.0:
		result.final_values.status = "success"
		result.calls.append("rotation_clean")
		result.intervention_sources.append("priority")
		return
	result.final_values.abbreviation += symbol
	result.final_values.base_value = snappedf(float(result.final_values.base_value) * (0.50 if severe else 0.70), 0.01)
	result.final_values.live_goe = snappedf(minf(float(result.final_values.live_goe), -float(result.final_values.base_value) * 0.50), 0.01)
	result.final_values.status = "error"
	result.calls.append("rotation_%s" % symbol)

static func _resolve_level(performance_element: Dictionary, result: Dictionary) -> void:
	var quality := float(performance_element.get("actual", {}).get("quality", 50.0))
	var facts: Dictionary = performance_element.get("facts", {})
	var level := clampi(int(facts.get("credited_features", round(quality / 20.0))), 0, 4)
	result.evidence_confidence = "clear" if facts.has("credited_features") else "ambiguous"
	result.final_values.abbreviation += str(level)
	# Difficulty credit and quality of execution are independent decisions.
	result.final_values.status = "error" if quality < 28.0 else "success"
	result.calls.append("level_%d" % level)
