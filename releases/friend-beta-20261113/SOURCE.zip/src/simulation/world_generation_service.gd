class_name WorldGenerationService
extends RefCounted

const AthleteState = preload("res://src/domain/athlete_state.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const HistoricalProfiles = preload("res://src/content/historical_athlete_profile_repository.gd")

const NAME_POOLS := {
	"CHN": [["林", "陈", "周", "许", "沈", "顾", "唐", "陆", "夏", "苏", "叶", "温", "江", "宋", "梁", "何"], ["心宁", "若岚", "清禾", "静仪", "雨桐", "知夏", "映雪", "嘉澄", "思遥", "念安", "芷晴", "星妍", "舒然", "令月", "可昕", "语冰"]],
	"JPN": [["青井", "森川", "早川", "星野", "藤原", "水野", "木村", "白石"], ["澪", "葵", "結衣", "遥", "花音", "凛", "真央", "美月"]],
	"RUS": [["Volkova", "Morozova", "Orlova", "Petrova", "Sokolova", "Belova", "Smirnova", "Vetrova"], ["Alina", "Elena", "Sofia", "Daria", "Nina", "Vera", "Mila", "Irina"]],
	"USA": [["Reed", "Hayes", "Brooks", "Morgan", "Parker", "Bennett", "Stone", "Lane"], ["Avery", "Maya", "Chloe", "Lily", "Nora", "Lucy", "Grace", "Zoe"]],
	"KOR": [["Kim", "Park", "Lee", "Choi", "Jung", "Han", "Yoon", "Kang"], ["Haeun", "Seoyeon", "Yuna", "Jiwon", "Minseo", "Sumin", "Nari", "Daeun"]],
	"BEL": [["De Smet", "Peeters", "Janssens", "Dubois", "Maes", "Jacobs", "Laurent", "Vermeulen"], ["Emma", "Louise", "Elise", "Noor", "Lotte", "Julie", "Clara", "Mila"]],
}

static func ensure_season(career, bundle: Dictionary, seed: int, historical_catalog: Dictionary = {}) -> Dictionary:
	var errors := _bundle_errors(bundle)
	if career == null or seed < 0: errors.append("世界生成需要生涯和非负种子")
	if not errors.is_empty(): return {"created_ids":[], "errors":errors}
	var season_id := str(bundle.calendar.season_id)
	var generated: Array = career.world_state.get("generated_seasons", [])
	var cohorts: Array = career.world_state.get("junior_cohort_seasons", [])
	var missing_federation: bool = bundle.federation_profiles.keys().any(func(federation):return not career.world_athletes.values().any(func(record):return record.get("federation") == federation))
	if generated.has(season_id) and cohorts.has(season_id) and not missing_federation:
		# V14 saves may already have generated this season with an older legal
		# programme template. Reapply data-driven menu rules idempotently before
		# returning so persisted NPCs cannot later block formal simulation.
		var existing_short_rules: Dictionary = load("res://src/content/historical_rule_repository.gd").rules_for(bundle.rules,"junior","short")
		for record in career.world_athletes.values(): _apply_short_rules(record,existing_short_rules)
		var schedules: Dictionary = preload("res://src/simulation/opponent_season_schedule_service.gd").ensure_plans(career,bundle)
		if not schedules.errors.is_empty(): return {"created_ids":[],"errors":schedules.errors}
		return {"created_ids":[], "errors":[]}
	var world_seed := int(career.world_state.get("world_seed", seed))
	# The explicit seed establishes the world once; later seasons retain it.
	if generated.is_empty(): world_seed = seed
	var epoch := {"year":int(bundle.calendar.calendar_year), "quarter":3}
	if career.clock.year == int(epoch.year) and career.clock.quarter < 3: epoch.quarter = career.clock.quarter
	var profiles: Dictionary = bundle.federation_profiles
	var federations: Array = profiles.keys()
	federations.sort()
	var created: Array[String] = []
	var staged_records: Dictionary = career.world_athletes.duplicate()
	var catalog := HistoricalProfiles.load_catalog() if historical_catalog.is_empty() else historical_catalog
	for federation in federations:
		var cohort_size := maxi(1,int(ceil(float(profiles[federation].pool_size) / 6.0)))
		var existing_count := 0
		for record in career.world_athletes.values():
			if str(record.get("federation", "")) == federation: existing_count += 1
		for index in range(existing_count, int(profiles[federation].pool_size)):
			var record := generate_record(staged_records, str(federation), profiles[federation], world_seed, index, epoch, season_id, 13 + index % 6 if existing_count == 0 else 0, true, catalog)
			if record.has("errors"): return {"created_ids":[], "errors":record.errors}
			staged_records[record.athlete_id] = record
			created.append(record.athlete_id)
		# Stable annual cohort IDs depend only on world, federation and season.
		# Legacy saves can acquire the missing cohort without touching incumbents.
		if existing_count > 0 and not cohorts.has(season_id):
			for offset in cohort_size:
				var index := int(epoch.year) * 1000 + offset
				var id := "world-%d-%s-%04d" % [world_seed,federation,index]
				if career.world_athletes.has(id): continue
				var record := generate_record(staged_records,str(federation),profiles[federation],world_seed,index,epoch,season_id,13,true,catalog)
				if record.has("errors"): return {"created_ids":[], "errors":record.errors}
				staged_records[id] = record
				created.append(id)
	career.world_athletes = staged_records
	for record in career.world_athletes.values():
		var age := int(epoch.year) - int(record.athlete.birth_year) - (1 if str(record.birth_date).substr(5) >= "07-01" else 0)
		record["junior_status"] = "eligible" if age >= 13 and age < 19 else "aged_out"
	var short_rules: Dictionary = load("res://src/content/historical_rule_repository.gd").rules_for(bundle.rules,"junior","short")
	for record in career.world_athletes.values(): _apply_short_rules(record,short_rules)
	if not generated.has(season_id): generated.append(season_id)
	if not cohorts.has(season_id): cohorts.append(season_id)
	career.world_state["junior_cohort_seasons"] = cohorts
	career.world_state["world_seed"] = world_seed
	career.world_state["generated_seasons"] = generated
	career.world_state["season_id"] = season_id
	career.world_state["generated_federations"] = federations
	career.world_state["athlete_ids"] = career.world_athletes.keys()
	career.world_state.athlete_ids.sort()
	if Dictionary(career.world_state.last_advanced_clock).is_empty():
		career.world_state.last_advanced_clock = epoch.duplicate()
	var schedules: Dictionary = preload("res://src/simulation/opponent_season_schedule_service.gd").ensure_plans(career,bundle)
	if not schedules.errors.is_empty(): return {"created_ids":[],"errors":schedules.errors}
	return {"created_ids":created, "errors":[]}

static func generate_record(existing: Dictionary, federation: String, profile: Dictionary, seed: int, index: int, epoch: Dictionary, season_id: String, cohort_age: int = 0, apply_historical: bool = true, historical_catalog: Dictionary = {}) -> Dictionary:
	var seasonal_technique:bool = apply_historical and federation != "CHN" and int(epoch.year) in [2020,2021] and profile.has("technical_generation")
	if seasonal_technique:
		var technical_errors := _seasonal_technique_errors(profile.technical_generation)
		if not technical_errors.is_empty():return {"errors":technical_errors}
	var athlete_id := "world-%d-%s-%04d" % [seed, federation, index]
	while existing.has(athlete_id):
		index += 1
		athlete_id = "world-%d-%s-%04d" % [seed, federation, index]
	var rng := RandomNumberGenerator.new()
	var career_seed := stable_seed(athlete_id)
	rng.seed = career_seed
	var name := _name(federation, rng, existing)
	var strength := clampf(rng.randfn(float(profile.mean_strength), float(profile.strength_deviation)), 15.0, 94.0)
	var tier := "leader" if strength >= 78.0 else ("middle" if strength >= 67.0 else "development")
	var birth_year := int(epoch.year) - rng.randi_range(14, 17)
	var birth_date := "%04d-%02d-%02d" % [birth_year, rng.randi_range(1, 12), rng.randi_range(1, 28)]
	if cohort_age > 0:
		birth_year = int(epoch.year) - cohort_age - (1 if birth_date.substr(5) >= "07-01" else 0)
		birth_date = "%04d-%s" % [birth_year,birth_date.substr(5)]
	var athlete := _athlete(name, birth_year, strength, rng)
	var historical: Dictionary = {}
	var archetype := ""
	if apply_historical and federation == "CHN" and int(epoch.year) >= 2018 and int(epoch.year) <= 2021:
		historical = HistoricalProfiles.profile_for(int(epoch.year), federation, HistoricalProfiles.age_on_july_first(birth_date, int(epoch.year)), "domestic_junior", historical_catalog)
		if not historical.get("errors", []).is_empty(): return {"errors":historical.errors}
		# A stable 28-athlete cohort contains three rare top packages. Refill IDs
		# use the same strata; the player's ability never enters this selection.
		var stratum := posmod(index, 28)
		archetype = "top" if stratum < 3 else ("middle" if stratum < 14 else "development")
		_sample_historical_technique(athlete, historical, archetype, rng, false, int(epoch.year))
		tier = "leader" if archetype == "top" else archetype
	elif seasonal_technique:
		_sample_seasonal_technique(athlete,profile.technical_generation,rng,int(epoch.year))
		archetype = "top" if tier == "leader" else tier
	athlete.resources.money = float(profile.resource_level)
	athlete.resources.ice_access = float(profile.resource_level)
	var record := {
		"world_record_version":1, "athlete_id":athlete_id, "name":name,
		"federation":federation, "nationality":federation, "name_origin":federation,
		"birth_date":birth_date, "status":"active", "tier":tier,
		"club_id":"%s-club-%02d" % [federation.to_lower(), rng.randi_range(1, 6)],
		"coach_id":"%s-coach-%02d" % [federation.to_lower(), rng.randi_range(1, 12)],
		"career_seed":career_seed, "athlete":athlete.to_dict(),
		"physical_trajectory":{
			"elapsed_quarters":0, "age":int(epoch.year) - birth_year,
			"height_cm":rng.randf_range(148.0, 167.0),
			"mature_height_cm":rng.randf_range(160.0, 174.0),
			"late_bloomer":rng.randf() < float(profile.late_bloomer_rate),
			"volatility":float(profile.volatility), "resource_level":float(profile.resource_level),
			"development_rate":rng.randf_range(0.15, 0.65),
		},
		"personality":{"discipline":rng.randf_range(35.0, 95.0), "ambition":rng.randf_range(35.0, 95.0)},
		"short_program":_program(athlete_id + "-short", "short", tier).to_dict(),
		"free_program":_program(athlete_id + "-free", "free", tier).to_dict(),
		"competition_history":[], "record_book":{"international":{}, "all_formal":{}},
		"ranking_points":{"domestic":0, "isu_world":0, "season_world":0},
		"last_advanced_clock":epoch.duplicate(), "last_advanced_season":season_id,
	}
	record.physical_trajectory.mature_height_cm = maxf(record.physical_trajectory.height_cm, record.physical_trajectory.mature_height_cm)
	if not historical.is_empty() or seasonal_technique:
		record["generation_profile_id"] = historical.id if not historical.is_empty() else "international-%s-%s-v1" % [season_id,federation]
		record["archetype"] = archetype
		for segment in ["short", "free"]:
			var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(int(epoch.year), "junior", segment)
			var proposed: Dictionary = load("res://src/simulation/program_draft_service.gd").propose_for_npc(athlete, segment, rules, career_seed, archetype)
			if proposed.program == null: return {"errors":proposed.errors}
			var program = proposed.program
			program.program_id = athlete_id + "-" + segment
			var bounds: Array = historical.familiarity_ranges[archetype] if not historical.is_empty() else [70.0,90.0]
			program.whole_run_familiarity = rng.randf_range(bounds[0], bounds[1])
			bounds = historical.pcs_ranges[archetype] if not historical.is_empty() else [maxf(35.0,strength-12.0),minf(92.0,strength+4.0)]
			program.choreography_quality = rng.randf_range(bounds[0], bounds[1])
			for slot in program.slot_familiarity: program.slot_familiarity[slot] = program.whole_run_familiarity
			record[segment + "_program"] = program.to_dict()
	_apply_short_rules(record,load("res://src/content/internal_event_rules.gd").for_season(int(season_id.left(4)),"junior","short"))
	return _quantized(record)

static func _seasonal_technique_errors(value) -> Array[String]:
	if not value is Dictionary:return ["赛季技术采样必须为对象"]
	var errors:Array[String]=[]
	if value.get("model_version") != 1:errors.append("未知赛季技术采样版本")
	for field in ["axel_triple_probability","quad_probability"]:
		var p=value.get(field)
		if not (p is int or p is float) or float(p)<0.0 or float(p)>1.0:errors.append("赛季技术概率无效："+field)
	if not value.get("triple_probabilities") is Dictionary:return ["赛季三周分布必须为对象"]
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		var p=value.triple_probabilities.get(id)
		if not (p is int or p is float) or float(p)<0.0 or float(p)>1.0:errors.append("赛季三周概率无效："+id)
	if not value.get("quad_families") is Array or value.quad_families.is_empty():errors.append("缺少四周采样动作范围")
	else:
		for id in value.quad_families:
			if id not in ["toe_loop","salchow","loop","flip","lutz"]:errors.append("无效四周采样动作")
	return errors

static func _sample_seasonal_technique(athlete,model:Dictionary,rng:RandomNumberGenerator,year:int) -> void:
	# These are established formal entrants, not blank child AthleteState
	# defaults. Reserve sampling alone must not leave their spins untrained.
	var strength:float = float(athlete.technique.rotation)
	# Expressive ability is a separate, variable skill. Lower jump packages
	# may still be expressive; a quad does not buy PCS or a fixed placing.
	athlete.mind.expression=clampf(40.0+strength*0.5+rng.randfn(0.0,12.0),35.0,95.0)
	for key in athlete.spin_foundation:athlete.spin_foundation[key]=clampf(strength+rng.randf_range(-9,7),35.0,95.0)
	for spin in athlete.spins.values():
		spin.proficiency=clampf(strength+rng.randf_range(-8,8),35.0,95.0)
		spin.training_consistency=clampf(strength+rng.randf_range(-10,6),35.0,95.0)
		spin.level_features=clampi(int(floor(float(spin.proficiency)/20.0)),1,4)
	var advanced:bool = rng.randf()<float(model.quad_probability)
	var quad_id:String = str(model.quad_families[rng.randi_range(0,model.quad_families.size()-1)])
	for id in athlete.jumps:
		var jump=athlete.jumps[id]
		var probability:float = float(model.axel_triple_probability) if id=="axel" else float(model.triple_probabilities[id])
		jump.unlocked_rotations = 3 if rng.randf()<probability else 2
		if advanced and id==quad_id:jump.unlocked_rotations=4
		jump.attempts=0
		for rotation in range(1,5):
			var key:String=["","single","double","triple","quad"][rotation]
			var learned:bool=rotation<=int(jump.unlocked_rotations)
			jump.proficiency[key] = clampf(float(jump.proficiency.triple)+rng.randf_range(-4,7),45.0,94.0) if learned else 0.0
			jump.attempt_evidence[key]={"attempts":120 if learned else 0,"successes":80 if learned else 0,"clean_successes":60 if learned else 0,"falls":0,"pops":0,"two_foot":0,"hand_down":0,"underrotated":0,"downgraded":0,"first_success_clock":{"year":year,"quarter":1} if learned else {}}
			jump.attempts+=int(jump.attempt_evidence[key].attempts)

static func generate_child_record(existing: Dictionary, athlete_id: String, seed: int, index: int, year: int, age: int, club_id: String) -> Dictionary:
	var profile := {"mean_strength":38.0, "strength_deviation":8.0, "resource_level":42.0, "late_bloomer_rate":0.35, "volatility":0.18}
	var generated := generate_record(existing, "CHN", profile, seed + 101, 9000 + index, {"year":year,"quarter":1}, "early-%d" % year, age, false)
	var rng := RandomNumberGenerator.new()
	rng.seed = stable_seed(athlete_id)
	var ability := snappedf(rng.randf_range(24.0, 58.0), 0.001)
	var athlete = AthleteState.from_dict(generated.athlete)
	# Teaching age is the actual age on July 1, unlike international entry
	# which requires attaining the age before July 1. Keep this new child's
	# identity consistent with the requested teaching band at that boundary.
	athlete.birth_year = year - age - (1 if str(generated.birth_date).substr(5) > "07-01" else 0)
	for key in athlete.technique: athlete.technique[key] = clampf(ability + rng.randf_range(-5.0, 5.0), 10.0, 70.0)
	for key in athlete.skating: athlete.skating[key] = clampf(ability + rng.randf_range(-6.0, 6.0), 10.0, 70.0)
	for jump_id in athlete.jumps:
		var jump = athlete.jumps[jump_id]
		jump.unlocked_rotations = 2 if ability >= 46.0 and ["toe_loop","salchow","loop"].has(jump_id) else 1
		jump.proficiency.single = clampf(ability + rng.randf_range(-4.0, 7.0), 10.0, 78.0)
		jump.proficiency.double = clampf(ability - 24.0 + rng.randf_range(-5.0, 5.0), 0.0, 45.0) if jump.unlocked_rotations >= 2 else 0.0
		jump.proficiency.triple = 0.0
		jump.proficiency.quad = 0.0
	var historical: Dictionary = {}
	var archetype := ""
	if year >= 2014 and year <= 2017 and age >= 6 and age <= 10:
		historical = HistoricalProfiles.profile_for(year, "CHN", age, "teaching")
		if not historical.errors.is_empty(): return {"errors":historical.errors}
		archetype = "top" if rng.randf() < 0.1 else ("middle" if rng.randf() < 0.4 else "development")
		_sample_historical_technique(athlete, historical, archetype, rng, true, year)
	var short_result: Dictionary = load("res://src/simulation/program_draft_service.gd").propose(athlete,"short",load("res://src/content/internal_event_rules.gd").for_teaching_group("short"),{},int(rng.randi()))
	var free_result: Dictionary = load("res://src/simulation/program_draft_service.gd").propose(athlete,"free",load("res://src/content/internal_event_rules.gd").for_teaching_group("free"),{},int(rng.randi()))
	var short: SkatingProgram = short_result.program
	var free: SkatingProgram = free_result.program
	generated.athlete_id = athlete_id
	generated.name = athlete.display_name
	generated.birth_date = "%04d-%s" % [athlete.birth_year, str(generated.birth_date).substr(5)]
	generated.club_id = club_id
	generated.tier = "early_development"
	if not historical.is_empty():
		generated["generation_profile_id"] = historical.id
		generated["archetype"] = archetype
	else:
		generated.erase("generation_profile_id")
		generated.erase("archetype")
	generated.athlete = athlete.to_dict()
	generated.short_program = short.to_dict()
	generated.free_program = free.to_dict()
	generated.age = age
	generated.ability = ability
	generated.development_state = {"phase":"foundation", "training_quarters":0, "trend":rng.randf_range(-0.1,0.5)}
	generated.physical_trajectory.age = age
	return _quantized(generated)

static func _sample_historical_technique(athlete, profile: Dictionary, archetype: String, rng: RandomNumberGenerator, teaching: bool, year: int) -> void:
	var bounds: Array = profile.pcs_ranges[archetype]
	for key in athlete.skating: athlete.skating[key] = rng.randf_range(bounds[0], bounds[1])
	bounds = profile.spin_step_ranges[archetype]
	for key in athlete.spin_foundation: athlete.spin_foundation[key] = rng.randf_range(bounds[0], bounds[1])
	for spin in athlete.spins.values():
		for key in spin:
			if spin[key] is float or spin[key] is int: spin[key] = rng.randf_range(bounds[0], bounds[1])
	for id in athlete.jumps:
		var jump = athlete.jumps[id]
		var ceiling := int(profile.maximum_axel) if id == "axel" else int(profile.maximum_non_axel)
		var chance := float(profile.jump_distributions[archetype][id])
		if teaching: chance *= clampf(float(year - athlete.birth_year - 5) / 5.0, 0.2, 1.0)
		jump.unlocked_rotations = ceiling if rng.randf() < chance else maxi(1, ceiling - 1)
		# Junior rules permit a double prescribed solo. All formal entrants here
		# have 2A; advanced triples are personal, independently sampled reserves.
		if not teaching and id == "axel": jump.unlocked_rotations = 2
		jump.attempts = 0
		for rotations in range(1, 5):
			var key: String = ["", "single", "double", "triple", "quad"][rotations]
			var learned: bool = rotations <= jump.unlocked_rotations
			jump.proficiency[key] = rng.randf_range(52, 88) if learned else 0.0
			jump.attempt_evidence[key] = {"attempts":120 if learned else 0,"successes":80 if learned else 0,"clean_successes":60 if learned else 0,"falls":0,"pops":0,"two_foot":0,"hand_down":0,"underrotated":0,"downgraded":0,"first_success_clock":{"year":year,"quarter":1} if learned else {}}
			jump.attempts += int(jump.attempt_evidence[key].attempts)
		for key in jump.consistency: jump.consistency[key] = rng.randf_range(45, 80)
		jump.landing.combination = rng.randf_range(45, 75)

static func _apply_short_rules(record: Dictionary, short_rules: Dictionary) -> void:
	if not record.get("short_program") is Dictionary: return
	var elements: Array = record.short_program.get("elements",[])
	var edits := {}
	var spin_index := 0
	for index in elements.size():
		var element: Dictionary = elements[index]
		if element.get("kind") == "jump" and Array(element.get("combination_parts",[])).is_empty() and element.get("jump_id") != "axel" and short_rules.has("required_solo_jump"):
			var required_id := str(short_rules.required_solo_jump)
			var mastered := int(record.get("athlete",{}).get("jumps",{}).get(required_id,{}).get("unlocked_rotations",0))
			if mastered >= 2:
				var rotations := mini(int(element.get("rotations",2)),mini(mastered,3))
				# Keep the prescribed solo from repeating a triple in the combination.
				if rotations == 3:
					for other in elements:
						var parts: Array = other.get("combination_parts",[])
						if parts.is_empty(): continue
						if other.get("jump_id") == required_id and int(other.get("rotations",0)) == 3: rotations = 2
						for part in parts:
							if part.get("jump_id") == required_id and int(part.get("rotations",0)) == 3: rotations = 2
				if element.get("jump_id") != required_id or not is_same(element.get("rotations"), rotations):
					edits[index] = {"jump_id":required_id,"rotations":rotations}
		if element.get("kind") == "spin":
			if short_rules.has("required_spin_codes") and spin_index < short_rules.required_spin_codes.size():
				var code = short_rules.required_spin_codes[spin_index]
				if element.get("spin_code") != code: edits[index] = {"spin_code":code}
			spin_index += 1
	# Cheaply detect stale no-repeat violations as well as season-menu changes.
	# The short-program restriction includes doubles, not just triples.
	if edits.is_empty() and not _short_jump_collision(elements): return
	var athlete = AthleteState.from_dict(record.get("athlete",{}))
	var program = SkatingProgram.from_dict(record.short_program)
	if athlete == null or program == null: return
	var validator = load("res://src/simulation/program_validator.gd")
	if validator.validate(program,athlete,short_rules).is_empty(): return
	var staged: Dictionary = record.short_program.duplicate(true)
	for index in edits:
		staged.elements[index].merge(edits[index],true)
	var candidate = SkatingProgram.from_dict(staged)
	if candidate != null and validator.validate(candidate,athlete,short_rules).is_empty():
		record.short_program = staged
		return
	# Changing the prescribed solo can collide with an existing combination.
	# Reuse the deterministic legal-draft search, but retain the saved slots and
	# every non-layout attribute; this must never strengthen the opponent.
	var proposal: Dictionary = load("res://src/simulation/program_draft_service.gd").propose_for_npc(athlete,"short",short_rules,int(record.get("career_seed",0)),str(record.get("archetype","middle")))
	if proposal.program == null or not proposal.errors.is_empty(): return
	for element in staged.elements:
		if element.get("kind") != "jump": continue
		var role := _short_jump_role(element)
		for replacement in proposal.program.elements:
			var replacement_data: Dictionary = replacement.to_dict()
			if replacement_data.get("kind") != "jump" or _short_jump_role(replacement_data) != role: continue
			for key in ["jump_id","rotations","combination_parts"]:
				element[key] = replacement_data[key]
			break
	candidate = SkatingProgram.from_dict(staged)
	if candidate != null and validator.validate(candidate,athlete,short_rules).is_empty(): record.short_program = staged

static func _short_jump_role(element: Dictionary) -> String:
	if not Array(element.get("combination_parts",[])).is_empty(): return "combination"
	return "axel" if element.get("jump_id") == "axel" else "solo"

static func _short_jump_collision(elements: Array) -> bool:
	var seen := {}
	for element in elements:
		if element.get("kind") != "jump": continue
		var codes := {"%s:%s" % [element.get("rotations"),element.get("jump_id")]:true}
		for part in element.get("combination_parts",[]): codes["%s:%s" % [part.get("rotations"),part.get("jump_id")]] = true
		for code in codes:
			if seen.has(code): return true
			seen[code] = true
	return false

static func stable_seed(text: String) -> int:
	var value: int = 2166136261
	for byte in text.to_utf8_buffer(): value = ((value ^ int(byte)) * 16777619) & 0xFFFFFFFF
	return value

static func choose_federation(profiles: Dictionary, allowed: Array[String], rng: RandomNumberGenerator) -> String:
	var total := 0.0
	for federation in allowed: total += float(profiles[federation].nationality_frequency)
	var choice := rng.randf() * total
	for federation in allowed:
		choice -= float(profiles[federation].nationality_frequency)
		if choice < 0.0: return federation
	return allowed[0]

static func _name(federation: String, rng: RandomNumberGenerator, existing: Dictionary) -> String:
	var pools: Array = NAME_POOLS.get(federation, NAME_POOLS.CHN)
	var used := {}
	for record in existing.values(): used[str(record.get("name", ""))] = true
	var offset := rng.randi_range(0, pools[0].size() * pools[1].size() - 1)
	for step in pools[0].size() * pools[1].size():
		var index: int = (offset + step) % (pools[0].size() * pools[1].size())
		var name := "%s%s%s" % [pools[0][index / pools[1].size()], "" if ["CHN", "JPN", "HKG", "TPE", "MAC"].has(federation) else " ", pools[1][index % pools[1].size()]]
		if not used.has(name): return name
	return "%s 选手%04d" % [federation, existing.size()]

static func _bundle_errors(bundle: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	for error in bundle.get("errors", []): errors.append(str(error))
	if not bundle.get("calendar") is Dictionary or str(bundle.get("calendar", {}).get("season_id", "")).is_empty():
		errors.append("世界生成需要明确赛季")
	if not bundle.get("federation_profiles") is Dictionary or bundle.get("federation_profiles", {}).is_empty():
		errors.append("世界生成需要联邦参数")
	return errors

static func _quantized(value):
	if value is float: return snappedf(value, 0.001)
	if value is Dictionary:
		for key in value: value[key] = _quantized(value[key])
	elif value is Array:
		for index in value.size(): value[index] = _quantized(value[index])
	return value

static func _athlete(name: String, birth_year: int, strength: float, rng: RandomNumberGenerator) -> AthleteState:
	var athlete := AthleteState.new(name, birth_year, "formal_generated", "generated_family")
	for key in athlete.technique: athlete.technique[key] = clampf(strength + rng.randf_range(-4.0, 4.0), 5.0, 95.0)
	for key in athlete.skating: athlete.skating[key] = clampf(strength + rng.randf_range(-6.0, 6.0), 5.0, 95.0)
	for key in athlete.jump_foundation.to_dict(): athlete.jump_foundation.set(key, clampf(strength + rng.randf_range(-5.0, 5.0), 5.0, 95.0))
	for jump in athlete.jumps.values():
		jump.unlocked_rotations = 3
		jump.proficiency.single = 90.0
		jump.proficiency.double = clampf(strength + 12.0, 35.0, 96.0)
		jump.proficiency.triple = clampf(strength + rng.randf_range(-8.0, 5.0), 20.0, 94.0)
		jump.consistency.official = clampf(strength + rng.randf_range(-10.0, 4.0), 15.0, 92.0)
		for key in jump.takeoff: jump.takeoff[key] = clampf(strength + rng.randf_range(-7.0, 7.0), 10.0, 95.0)
		for key in jump.air: jump.air[key] = clampf(strength + rng.randf_range(-7.0, 7.0), 10.0, 95.0)
		for key in jump.landing: jump.landing[key] = clampf(strength + rng.randf_range(-7.0, 7.0), 10.0, 95.0)
	athlete.body.acute_fatigue = rng.randf_range(4.0, 22.0)
	athlete.body.cumulative_fatigue = rng.randf_range(3.0, 25.0)
	athlete.mind.motivation = rng.randf_range(45.0, 88.0)
	return athlete

static func _program(program_id: String, segment: String, tier: String) -> SkatingProgram:
	var elements: Array = []
	var jump_specs := [["axel", 2], ["lutz", 3], ["flip", 3]] if segment == "short" else [["lutz", 3], ["flip", 3], ["axel", 2], ["loop", 3], ["salchow", 3], ["lutz", 3], ["axel", 2]]
	for index in jump_specs.size():
		var spec: Array = jump_specs[index]
		var jump = ProgramElement.create("%s-j%d" % [program_id, index + 1], "jump", spec[0], spec[1]).element
		if index == 1:
			if segment == "short":
				jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 3 if tier == "leader" else 2}])
			else:
				jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 3}] if tier == "leader" else [{"jump_id": "loop", "rotations": 2}])
		elif segment == "free" and index == 4:
			jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 2}])
		elif segment == "free" and index == 5:
			jump.set_combination_parts([{"jump_id": "toe_loop", "rotations": 2}, {"jump_id": "loop", "rotations": 2}])
		elements.append(jump)
	for index in 3:
		var spin = ProgramElement.create("%s-spin%d" % [program_id, index + 1], "spin").element
		spin.spin_code = ["CCoSp", "FSSp" if tier == "development" else "FCSp", "LSp"][index]
		elements.append(spin)
	elements.append(ProgramElement.create("%s-step" % program_id, "step_sequence").element)
	var program = SkatingProgram.create(program_id, segment, elements).program
	program.whole_run_familiarity = {"leader": 82.0, "middle": 68.0, "development": 54.0}.get(tier, 60.0)
	program.choreography_quality = {"leader": 80.0, "middle": 64.0, "development": 48.0}.get(tier, 55.0)
	for element_id in program.slot_familiarity: program.slot_familiarity[element_id] = program.whole_run_familiarity
	return program
