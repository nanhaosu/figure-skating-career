class_name PersonalRecordService
extends RefCounted

static func preview(record_book: Dictionary, archive: Dictionary) -> Dictionary:
	var next := record_book.duplicate(true)
	if not next.has("international"): next.international = {}
	if not next.has("all_formal"): next.all_formal = {}
	var changes: Array[Dictionary] = []
	if not str(archive.get("record_eligibility","domestic_only")) in ["domestic_only","isu_recognized"]: return {"changes":changes,"next_record_book":next}
	var player: Dictionary = Dictionary(archive.get("player_result", {}))
	if player.is_empty(): return {"changes": changes, "next_record_book": next}
	var era := str(archive.get("scoring_era_id", "unknown"))
	var scopes: Array[String] = ["all_formal"]
	if str(archive.get("record_eligibility", "domestic_only")) == "isu_recognized": scopes.append("international")
	for scope in scopes:
		if not next[scope].has(era): next[scope][era] = {}
		var score_adjustment := 0.0 if scope == "all_formal" else float(player.get("short_domestic_bonus", 0.0))
		_update(next[scope][era], "short", float(player.get("short_score", 0.0)) - score_adjustment, archive, changes, scope)
		if bool(player.get("qualified", false)) and player.has("free_score"):
			score_adjustment = 0.0 if scope == "all_formal" else float(player.get("free_domestic_bonus", 0.0))
			_update(next[scope][era], "free", float(player.free_score) - score_adjustment, archive, changes, scope)
			var total_adjustment := 0.0 if scope == "all_formal" else float(player.get("short_domestic_bonus", 0.0)) + float(player.get("free_domestic_bonus", 0.0))
			_update(next[scope][era], "total", float(player.get("total_score", 0.0)) - total_adjustment, archive, changes, scope)
	return {"changes": changes, "next_record_book": next}

static func _update(era_book: Dictionary, segment: String, score: float, archive: Dictionary, changes: Array[Dictionary], scope: String) -> void:
	if score <= 0.0: return
	if not era_book.has(segment): era_book[segment] = {"pb": 0.0, "pb_meta": {}, "sb": {}}
	var entry: Dictionary = era_book[segment]
	var season_id := str(archive.get("season_id", ""))
	var event: Dictionary = archive.get("event",{})
	var metadata := {"score": snappedf(score, 0.01), "event_id": str(archive.get("event_id", "")), "date": str(event.get("segment_dates",{}).get(segment,event.get("actual_dates", {}).get("start", event.get("start_date",""))))}
	if float(entry.get("pb", 0.0)) <= 0.0 or score > float(entry.pb):
		metadata.first_valid_score = float(entry.get("pb", 0.0)) <= 0.0
		entry.pb = snappedf(score, 0.01)
		entry.pb_meta = metadata.duplicate(true)
		changes.append({"scope":scope,"segment":segment,"kind":"pb","score":entry.pb,"first_valid_score":metadata.first_valid_score})
	if not entry.sb.has(season_id) or score > float(entry.sb[season_id].score):
		metadata.first_valid_score = not entry.sb.has(season_id)
		entry.sb[season_id] = metadata.duplicate(true)
		changes.append({"scope":scope,"segment":segment,"kind":"sb","score":metadata.score,"first_valid_score":metadata.first_valid_score})
