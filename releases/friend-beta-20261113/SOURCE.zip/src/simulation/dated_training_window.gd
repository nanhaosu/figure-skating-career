class_name DatedTrainingWindow
extends RefCounted

const Identity = preload("res://src/domain/athlete_identity.gd")
const DAY := 86400

# The cursor denotes an already settled day. Never infer an exact cursor
# from an old quarterly save; the caller must first finish that old period.
# Planning is pure: the command commits the returned days together with all
# actual training effects, or commits neither on a failed durable write.
static func plan(cursor: String, target: String) -> Dictionary:
	var bounds := _bounds(cursor, target)
	if bounds.has("error"): return _failure(bounds.error)
	var from_time: int = bounds.start
	var to_time: int = bounds.finish
	var days: Array[Dictionary] = []
	for timestamp in range(from_time+DAY,to_time+1,DAY):
		var date := Time.get_date_dict_from_unix_time(timestamp)
		var quarter := (int(date.month)-1)/3+1
		var first_month := (quarter-1)*3+1
		var end_year := int(date.year)+(1 if quarter == 4 else 0)
		var next_month := 1 if quarter == 4 else first_month+3
		var next_time := _time({"year":end_year,"month":next_month,"day":1})
		var first_time := _time({"year":date.year,"month":first_month,"day":1})
		days.append({"date":"%04d-%02d-%02d" % [date.year,date.month,date.day],"year":int(date.year),"quarter":quarter,"period_days":(next_time-first_time)/DAY,"quarter_end":timestamp+DAY == next_time})
	return {"errors":[],"days":days,"cursor":target}

static func valid_range(cursor: String, target: String) -> bool:
	return not _bounds(cursor, target).has("error")

static func _bounds(cursor: String, target: String) -> Dictionary:
	var start := _date(cursor)
	var finish := _date(target)
	if start.is_empty() or finish.is_empty(): return {"error":"训练日期必须是有效的YYYY-MM-DD日历日期"}
	var from_time := _time(start)
	var to_time := _time(finish)
	if to_time < from_time: return {"error":"训练日期不能倒退"}
	if to_time-from_time > 366*DAY: return {"error":"单次日期训练不能跨越一年以上"}
	return {"start":from_time,"finish":to_time}

static func _date(value: String) -> Dictionary:
	if value.length() != 10 or value.substr(4,1) != "-" or value.substr(7,1) != "-": return {}
	var digits := value.substr(0,4)+value.substr(5,2)+value.substr(8,2)
	for character in digits:
		if character < "0" or character > "9": return {}
	var result := {"year":int(value.substr(0,4)),"month":int(value.substr(5,2)),"day":int(value.substr(8,2))}
	return result if Identity.validate_birth_date(result,int(result.year)).is_empty() else {}

static func _time(date: Dictionary) -> int:
	return int(Time.get_unix_time_from_datetime_dict({"year":date.year,"month":date.month,"day":date.day,"hour":0,"minute":0,"second":0}))

static func _failure(message: String) -> Dictionary:
	return {"errors":[message],"days":[]}
