class_name JumpConnectionRules
extends RefCounted

const DIRECT_FOLLOWERS: Array[String] = ["toe_loop", "loop"]
const KNOWN_JUMPS: Array[String] = ["toe_loop", "salchow", "loop", "flip", "lutz", "axel"]

static func can_connect(first_jump_id: String, second_jump_id: String, rules: Dictionary = {}) -> Dictionary:
	if not KNOWN_JUMPS.has(first_jump_id) or not KNOWN_JUMPS.has(second_jump_id):
		return {"allowed":false,"reason":"连跳包含未知跳跃"}
	if second_jump_id == "axel" and rules.get("segment") == "free" and rules.get("axel_sequence_allowed", false):
		return {"allowed":true,"reason":""}
	var allowed_followers: Array = rules.get("combination_followup_jump_types", DIRECT_FOLLOWERS)
	if not allowed_followers.has(second_jump_id):
		return {"allowed":false,"reason":"直接连跳的后续跳只能是后外点冰跳或后外结环跳"}
	return {"allowed":true,"reason":""}
