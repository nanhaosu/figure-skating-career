class_name RepertoireEvidenceService
extends RefCounted

const Model = preload("res://src/domain/technical_repertoire.gd")
const Rules = preload("res://src/content/repertoire_health_rules.gd")

static func action_id(action: Dictionary) -> String:
	return Model.action_id(action)

static func already_recorded(career, id: String, batch_id: String, context: String, source_id: String = "") -> bool:
	for previous in career.technical_repertoire.entries.get(id,{}).get("evidence",[]):
		if previous.batch_id != batch_id or previous.context != context: continue
		if source_id.is_empty() or previous.get("source_ids",[]).has(source_id): return true
	return false

static func record_competition(career, performance: Dictionary, batch_id: String) -> void:
	var records := {}
	for element in performance.get("elements",[]):
		if element.get("kind") != "jump": continue
		var parts: Array = element.get("parts",[])
		var executed_parts: Array = []
		var completed := true
		var clean := true
		for part in parts:
			var called := {"jump_id":str(part.jump_id),"rotations":int(part.called_rotations)}
			var action := {"kind":"jump","parts":[called]}
			var success := bool(part.get("actual",{}).get("success",false))
			var clean_part := success and str(part.get("status","")) == "success"
			_collect_competition(records,action,success,clean_part,str(part.get("actual",{}).get("error_type","")))
			executed_parts.append(called)
			completed = completed and success
			clean = clean and clean_part
		if executed_parts.size() > 1:
			_collect_competition(records,{"kind":"jump","parts":executed_parts},completed,clean,"execution" if not completed else "")
	for row in records.values():
		row.batch_id = batch_id
		row.clock = career.clock.to_dict()
		row.context = "competition"
		row.assessment_eligible = false
		record(career,row)
	for id in records:
		preload("res://src/simulation/repertoire_evaluator.gd").evaluate(career,id)

static func _collect_competition(records: Dictionary, action: Dictionary, success: bool, clean: bool, failure: String) -> void:
	var id := action_id(action)
	if id.is_empty(): return
	if not records.has(id): records[id] = {"action":action,"action_id":id,"attempts":0,"successes":0,"clean_successes":0,"failure_counts":{}}
	var row: Dictionary = records[id]
	row.attempts += 1
	row.successes += int(success)
	row.clean_successes += int(clean)
	if not failure.is_empty(): row.failure_counts[failure] = int(row.failure_counts.get(failure,0))+1

static func record(career, evidence: Dictionary) -> Dictionary:
	var action = evidence.get("action",{})
	if not action is Dictionary: return {"ok":false,"recorded":false,"error":"缺少技术动作"}
	var id := action_id(action)
	var error := Model.validate_evidence(evidence,id)
	if id.is_empty() or not error.is_empty(): return {"ok":false,"recorded":false,"error":error if not error.is_empty() else "技术动作无效"}
	var entries: Dictionary = career.technical_repertoire.entries
	var item: Dictionary = entries.get(id,Model.entry(action))
	var source_id := str(evidence.get("source_id",""))
	if already_recorded(career,id,str(evidence.batch_id),str(evidence.context),source_id):
		return {"ok":true,"recorded":false,"error":""}
	if int(evidence.attempts) == 0: return {"ok":true,"recorded":false,"error":""}
	# Copy caller data: later UI or simulation changes cannot rewrite past evidence.
	var saved := evidence.duplicate(true)
	if not source_id.is_empty():
		saved.erase("source_id")
		saved.source_ids = [source_id]
	var functions = preload("res://src/simulation/athlete_function_service.gd")
	saved.assessment_eligible = bool(saved.assessment_eligible) and float(functions.snapshot(career).acute_fatigue) < 30.0 and bool(functions.action_constraints(career,action).allowed)
	item.learned_history.record_count = int(item.learned_history.get("record_count",0))+1
	saved.sequence = int(item.learned_history.record_count)
	if not item.learned_history.has("first_success_contexts"): item.learned_history.first_success_contexts = {}
	var milestone_context: String = Model.first_context_type(str(saved.context))
	if int(saved.successes) > 0 and not milestone_context.is_empty() and not item.learned_history.first_success_contexts.has(milestone_context):
		item.learned_history.first_success_contexts[milestone_context] = {"batch_id":str(saved.batch_id),"clock":saved.clock.duplicate(true),"source_sequence":int(saved.sequence)}
	for field in ["attempts","successes","clean_successes"]: saved[field] = int(saved[field])
	var aggregate := {}
	if not source_id.is_empty():
		for previous in item.evidence:
			# Never merge a fresh revalidation day with success from before a
			# withdrawal; sequence marks the last actual source in each row.
			if previous.batch_id == saved.batch_id and previous.context == saved.context and previous.assessment_eligible == saved.assessment_eligible and previous.has("source_ids") and int(previous.get("sequence",0)) > int(item.get("revalidation_after_sequence",0)):
				aggregate = previous
				break
	if aggregate.is_empty(): item.evidence.append(saved)
	else:
		aggregate.source_ids.append(source_id)
		aggregate.sequence = saved.sequence
		for field in ["attempts","successes","clean_successes"]: aggregate[field] += int(saved[field])
		for key in saved.failure_counts: aggregate.failure_counts[key] = int(aggregate.failure_counts.get(key,0))+int(saved.failure_counts[key])
	var limit := int(Rules.load_rules().evidence_limit)
	while item.evidence.size() > limit: item.evidence.pop_front()
	item.learned_history.total_attempts = int(item.learned_history.get("total_attempts",0))+int(saved.attempts)
	item.learned_history.total_successes = int(item.learned_history.get("total_successes",0))+int(saved.successes)
	entries[id] = item
	return {"ok":true,"recorded":true,"error":""}
