class_name DatedBodyLoad
extends RefCounted

const Legacy = preload("res://src/simulation/career_simulator.gd")
const Plan = preload("res://src/domain/training_plan.gd")
const Effective = preload("res://src/simulation/effective_training_calculator.gd")
const Condition = preload("res://src/simulation/athlete_condition_service.gd")

# Consume one actual elapsed day, with ONLY actually executed nonjump dose
# and actual jump contacts. Impact from jump execution is already paid by
# JumpTrainingSimulator; this service applies its rest recovery, not a second
# impact charge. Daily command/cursor owns once-only execution and persistence.
static func apply(career,plan,executed_volume: Dictionary,period_days: Variant,jump_contacts: Variant) -> Dictionary:
	if career == null or plan == null or not _integer(period_days) or int(period_days) not in [90,91,92] or not _integer(jump_contacts) or int(jump_contacts) < 0 or int(jump_contacts) > 1000000 or not executed_volume.get("category_volumes") is Dictionary: return _failure("实际日负荷或日历无效")
	for category in executed_volume.category_volumes:
		var amount = executed_volume.category_volumes[category]
		if not Plan.CATEGORY_IDS.has(category) or not (amount is int or amount is float) or not is_finite(float(amount)) or float(amount) < 0 or float(amount) > 1000000: return _failure("实际日训练剂量无效")
	var nonjump_units := 0.0
	for category in ["skating_foundation","rotation","conditioning","program_short","program_free"]:
		nonjump_units += float(executed_volume.category_volumes.get(category,0.0))/float(Plan.SHARE_STEP)
	# One five-percent jump lesson was28 actual practice blocks in the existing
	# volume model. Use actual executed contacts, including interrupted combos,
	# rather than charging unperformed planned jump shares after medical stops.
	var jump_units := float(jump_contacts)/Effective.ATTEMPTS_PER_FIVE_PERCENT
	var active_units := nonjump_units+jump_units
	# Rest is elapsed scheduled time, not a purchasable resource-volume bonus.
	var rest_units := float(plan.shares.get("rest",0))/float(Plan.SHARE_STEP)/float(period_days)
	var recovery := float(Condition.modifiers(career).recovery_efficiency)
	var changes := {
		"acute_fatigue":active_units*Legacy.ACTIVE_ACUTE_FATIGUE-rest_units*Legacy.REST_ACUTE_RECOVERY*recovery,
		"cumulative_fatigue":active_units*Legacy.ACTIVE_CUMULATIVE_FATIGUE-rest_units*Legacy.REST_CUMULATIVE_RECOVERY*recovery,
		"ankle_load":jump_units*Legacy.JUMP_ANKLE_LOAD+nonjump_units*Legacy.OTHER_ACTIVE_ANKLE_LOAD-rest_units*Legacy.REST_ANKLE_RECOVERY,
		"impact_load":-rest_units*Legacy.PERCENTAGE_MODE_REST_IMPACT_RECOVERY,
	}
	var outcomes: Array[Dictionary] = []
	for metric in changes:
		var before := float(career.athlete.body[metric])
		career.athlete.body[metric] = clampf(before+float(changes[metric]),0.0,100.0)
		outcomes.append({"category":"body","target":metric,"delta":float(career.athlete.body[metric])-before,"cause_codes":["actual_dated_load","elapsed_rest"],"summary_key":"fatigue_change"})
	return {"errors":[],"outcomes":outcomes}

static func _integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floorf(float(value))

static func _failure(message: String) -> Dictionary:
	return {"errors":[message],"outcomes":[]}
