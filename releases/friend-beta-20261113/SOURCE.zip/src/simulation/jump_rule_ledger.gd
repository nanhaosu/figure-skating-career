class_name JumpRuleLedger
extends RefCounted

static func apply(final_elements: Array, rules: Dictionary) -> Dictionary:
	var elements: Array = final_elements.duplicate(true)
	var events: Array[Dictionary] = []
	var counts: Dictionary = {}
	var occurrences: Array[Dictionary] = []
	for element_index in elements.size():
		var element = elements[element_index]
		if not element is Dictionary or str(element.get("kind", "")) != "jump": continue
		var parts: Array = _parts_for(element)
		element.parts = parts.duplicate(true)
		var in_combination := parts.size() > 1 or bool(element.get("is_combination", false))
		for part_index in parts.size():
			var code := _actual_code(parts[part_index])
			if code.is_empty(): continue
			counts[code] = int(counts.get(code, 0)) + 1
			occurrences.append({"element_index":element_index,"part_index":part_index,"code":code,"rotations":int(code.left(1)),"in_combination":in_combination})
	var limits: Dictionary = Dictionary(rules.get("repeat_limits", {}))
	if not limits.has("max_repeated_triples_or_quads"):
		return {"elements":elements,"rule_events":events,"actual_jump_counts":counts}
	var invalid: Dictionary = {}
	if str(rules.get("segment","")) == "short" and int(limits.max_repeated_triples_or_quads) == 0:
		# Short-program repetition is between jump elements. Both parts of
		# 3T+3T belong to the same element; a later solo3T still has no value.
		# Use the actual called rotation, including popped/downgraded jumps.
		var first_element := {}
		for occurrence in occurrences:
			if not first_element.has(occurrence.code): first_element[occurrence.code] = occurrence.element_index
			elif int(first_element[occurrence.code]) != int(occurrence.element_index): invalid[_key(occurrence)] = true
		return _finish(elements,occurrences,invalid,counts,events)
	var by_code: Dictionary = {}
	for occurrence in occurrences:
		if not by_code.has(occurrence.code): by_code[occurrence.code] = []
		by_code[occurrence.code].append(occurrence)
	var maximum_repeated_types := int(limits.max_repeated_triples_or_quads)
	for code in by_code:
		var code_occurrences: Array = by_code[code]
		var rotations := int(str(code).left(1))
		var per_code_limit := 2 if rotations == 2 or maximum_repeated_types > 0 else 1
		for index in range(per_code_limit, code_occurrences.size()): invalid[_key(code_occurrences[index])] = true
	var repeated_types: Array[String] = []
	var seen_high: Dictionary = {}
	for occurrence in occurrences:
		if int(occurrence.rotations) < 3 or invalid.has(_key(occurrence)): continue
		var code := str(occurrence.code)
		seen_high[code] = int(seen_high.get(code, 0)) + 1
		if int(seen_high[code]) == 2:
			if repeated_types.size() >= maximum_repeated_types: invalid[_key(occurrence)] = true
			else: repeated_types.append(code)
	for code in by_code:
		if int(str(code).left(1)) < 3: continue
		var valid: Array = Array(by_code[code]).filter(func(item): return not invalid.has(_key(item)))
		if valid.size() == 2 and not valid.any(func(item): return bool(item.in_combination)): invalid[_key(valid[1])] = true
	return _finish(elements,occurrences,invalid,counts,events)

static func _finish(elements: Array, occurrences: Array[Dictionary], invalid: Dictionary, counts: Dictionary, events: Array[Dictionary]) -> Dictionary:
	var invalid_by_element: Dictionary = {}
	for occurrence in occurrences:
		if not invalid.has(_key(occurrence)): continue
		if not invalid_by_element.has(occurrence.element_index): invalid_by_element[occurrence.element_index] = []
		invalid_by_element[occurrence.element_index].append(occurrence)
	for element_index in invalid_by_element: _invalidate(elements[int(element_index)],invalid_by_element[element_index],events)
	return {"elements":elements,"rule_events":events,"actual_jump_counts":counts}

static func _invalidate(element: Dictionary, invalid_parts: Array, events: Array[Dictionary]) -> void:
	var indexes: Array[int] = []
	var codes: Array[String] = []
	for occurrence in invalid_parts:
		indexes.append(int(occurrence.part_index)); if not codes.has(str(occurrence.code)): codes.append(str(occurrence.code))
	var parts: Array = element.get("parts", [])
	var remaining_base := 0.0
	var remaining_goe_base := 0.0
	for index in parts.size():
		if indexes.has(index):
			parts[index].invalid_reason = "REP"; parts[index].base_value = 0.0; parts[index].goe_base_value = 0.0
		else:
			remaining_base += float(parts[index].get("base_value",0.0)); remaining_goe_base = maxf(remaining_goe_base,float(parts[index].get("goe_base_value",parts[index].get("base_value",0.0))))
	var original_base := float(element.get("base_value",0.0))
	element.base_value = snappedf(remaining_base if indexes.size() < parts.size() else 0.0,0.01)
	element.goe_base_value = snappedf(remaining_goe_base if float(element.base_value) > 0.0 else 0.0,0.01)
	element.live_goe = snappedf(float(element.get("live_goe",0.0))*float(element.base_value)/original_base,0.01) if original_base > 0.0 else 0.0
	element.element_score = snappedf(float(element.base_value)+float(element.live_goe),0.01)
	element.invalid_reason = "REP"; element.status = "error"
	var info: Array = Array(element.get("info",[])); if not info.has("REP"): info.append("REP"); element.info = info
	events.append({"element_id":str(element.get("element_id","")),"code":"actual_jump_repetition","jump_codes":codes,"outcome":"invalid"})

static func _parts_for(element: Dictionary) -> Array:
	var parts = element.get("parts",[])
	if parts is Array and not parts.is_empty(): return Array(parts)
	var code := str(element.get("abbreviation","")).split("+")[0]
	for symbol in ["<<","<","!","e","x","*","REP"]: code = code.replace(symbol,"")
	return [{"called_rotations":int(code.left(1)),"abbreviation":code,"base_value":float(element.get("base_value",0.0)),"goe_base_value":float(element.get("goe_base_value",element.get("base_value",0.0)))}] if code.length() >= 2 else []

static func _actual_code(part: Dictionary) -> String:
	var abbreviation := str(part.get("abbreviation",""))
	for symbol in ["<<","<","!","e","x","*","REP"]: abbreviation = abbreviation.replace(symbol,"")
	if abbreviation.length() >= 2 and int(abbreviation.left(1)) > 0: return abbreviation
	var suffix: String = {"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz","axel":"A"}.get(str(part.get("jump_id","")),"")
	return "%d%s" % [int(part.get("called_rotations",part.get("rotations",0))),suffix] if not suffix.is_empty() else ""

static func _key(occurrence: Dictionary) -> String:
	return "%d:%d" % [int(occurrence.element_index),int(occurrence.part_index)]
