class_name AthleteConditionService
extends RefCounted

const KeyNodes = preload("res://src/simulation/key_node_service.gd")

# Quarterly gameplay hazards, not clinical probabilities. Named streams isolate
# condition events from training, authority and competition replay.
static func advance_quarter(career, executed_plan, seed: int, assess_injury: bool = true) -> Dictionary:
	var state: Dictionary = career.condition_state
	var result := {"signals":[], "injuries":[], "modifiers":{}, "events":[]}
	var rng: RandomNumberGenerator = career.random_streams.take_rng("condition_injury")
	rng.seed = int(rng.seed) + seed * 104729
	var shares: Dictionary = executed_plan.shares if not executed_plan.shares.is_empty() else executed_plan.allocations
	var scale := 1.0 if not executed_plan.shares.is_empty() else 100.0 / 12.0
	var jump_load := 0.0
	for key in shares:
		if str(key).begins_with("jump_"):
			var rotations := int(executed_plan.jump_rotations.get(str(key).trim_prefix("jump_"), 1))
			jump_load += float(shares[key]) * scale * (1.0 + maxf(0.0, rotations - 1) * 0.2)
	var rest := float(shares.get("rest", 0)) * scale
	var body: Dictionary = career.athlete.body
	var stress := float(state.psychology.get("stress", career.athlete.mind.get("training_fear", 0.0)))
	for injury in state.injuries:
		if str(injury.get("status", "")) != "active": continue
		if bool(injury.get("rehabilitation_managed", false)): continue
		if injury.has("dated_recovery_fraction"): continue
		if rest >= 15.0 and jump_load < 50.0:
			injury.remaining_quarters = maxi(0, int(injury.remaining_quarters) - 1)
			if int(injury.remaining_quarters) == 0:
				injury.status = "recovered"
				result.events.append({"kind":"injury_recovered", "injury_id":injury.id})
	_advance_growth(career, result)
	var impact := jump_load + float(body.impact_load) * 0.15
	var active_injuries := 0
	for injury in state.injuries:
		if str(injury.get("status","")) == "active": active_injuries += 1
	var risk := clampf(maxf(0.0, impact - 55.0) * 0.006 + float(body.acute_fatigue) * 0.0003 + float(body.cumulative_fatigue) * 0.001 + (0.025 if state.growth_phase == "rapid" else 0.0) + active_injuries * 0.006 - float(career.athlete.technique.landing) * 0.0003 - rest * 0.003 - float(body.recovery_capacity) * 0.0003, 0.0, 0.72)
	if assess_injury and jump_load > 0.0 and rng.randf() < risk:
		var severity := rng.randf_range(0.15, 0.5) if jump_load < 75.0 else rng.randf_range(0.35, 0.95)
		var injury := {"id":"injury:%d:%d:%d" % [career.clock.year, career.clock.quarter, state.injuries.size()], "site":"ankle", "severity":severity, "remaining_quarters":2 if severity >= 0.7 else 1, "status":"active"}
		state.injuries.append(injury)
		if severity >= 0.7:
			injury.rehabilitation_managed = true
			state.pending_decision = {"kind":"rehabilitation_initial","injury_id":injury.id}
		result.injuries.append(injury.duplicate(true))
		var label := "需要停跳康复，暂缓参赛" if severity >= 0.7 else "踝部不适，训练效率下降"
		state.medical_opinions.append({"injury_id":injury.id, "label":label, "clock":career.clock.to_dict()})
		KeyNodes.add(career, injury.id, "injury_review", label)
		result.events.append({"kind":"injury", "injury_id":injury.id, "label":label})
	stress = clampf(stress + maxf(0.0, float(body.acute_fatigue) - 60.0) * 0.04 - rest * 0.08, 0.0, 100.0)
	state.psychology = {"stress":stress, "label":"压力偏高" if stress >= 60.0 else ("有些紧绷" if stress >= 30.0 else "心态平稳")}
	result.modifiers = modifiers(career)
	for event in result.events:
		event.clock = career.clock.to_dict()
		career.event_ledger.append(event.duplicate(true))
	return result

# Once per actually executed three-week stage. This stream is independent of
# execution outcomes and is never sampled by a preview or a rest-only stage.
static func assess_training_stage(career, actual_attempts: int, plan, overrides: Dictionary = {}) -> Dictionary:
	return _assess_training_exposure(career,actual_attempts,float(actual_attempts),plan,overrides,1.0)

# One actual calendar day, not another full three-week stage. Express the
# observed contact rate in original stage units, then scale survival exposure
# so90/91/92 daily checks do not multiply the quarter's four-stage hazard.
static func assess_training_day(career,actual_attempts: Variant,plan,period_days: Variant,overrides: Dictionary = {}) -> Dictionary:
	if not _exposure_integer(actual_attempts) or float(actual_attempts) < 0 or float(actual_attempts) > 1000000 or not _exposure_integer(period_days) or int(period_days) not in [90,91,92]: return {"errors":["伤病评估的实际日负荷或日历无效"]}
	var event := _assess_training_exposure(career,int(actual_attempts),float(actual_attempts)*float(period_days)/4.0,plan,overrides,4.0/float(period_days))
	if not event.is_empty():
		for injury in career.condition_state.injuries:
			if injury.id == event.get("injury_id") and not bool(injury.get("rehabilitation_managed",false)): injury.dated_recovery_fraction = {"n":0,"d":1}
	return event

# Called before today's training, so an injury created during that training
# cannot receive a full recovery day, much less a whole quarter, immediately.
static func advance_injury_day(career,plan,period_days: Variant) -> Dictionary:
	var periods = preload("res://src/simulation/dated_training_dose.gd")
	if plan == null or plan.shares.is_empty() or not periods.accrue_period({},0,period_days).errors.is_empty(): return {"errors":["轻伤恢复日历或计划无效"],"events":[]}
	for injury in career.condition_state.injuries:
		var fraction = injury.get("dated_recovery_fraction",{})
		if not fraction is Dictionary or not periods.accrue_period(fraction,0,period_days).errors.is_empty(): return {"errors":["轻伤恢复时长余量无效"],"events":[]}
	var jump_load := 0.0
	for key in plan.shares:
		if str(key).begins_with("jump_"):
			var rotations := int(plan.jump_rotations.get(str(key).trim_prefix("jump_"),1))
			jump_load += float(plan.shares[key])*(1.0+maxf(0.0,rotations-1)*0.2)
	var result := {"errors":[],"events":[]}
	if float(plan.shares.get("rest",0)) < 15.0 or jump_load >= 50.0: return result
	for injury in career.condition_state.injuries:
		if str(injury.get("status","")) != "active" or bool(injury.get("rehabilitation_managed",false)): continue
		var duration: Dictionary = periods.accrue_period(injury.get("dated_recovery_fraction",{}),1,period_days)
		injury.dated_recovery_fraction = duration.fraction
		if int(duration.completed_periods) == 0: continue
		injury.remaining_quarters = maxi(0,int(injury.remaining_quarters)-1)
		if int(injury.remaining_quarters) == 0:
			injury.status = "recovered"
			result.events.append({"kind":"injury_recovered","injury_id":str(injury.id)})
	return result

static func _exposure_integer(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floorf(float(value))

static func _assess_training_exposure(career,actual_attempts: int,stage_equivalent_attempts: float,plan,overrides: Dictionary,exposure: float) -> Dictionary:
	if actual_attempts <= 0 or not career.condition_state.get("pending_decision",{}).is_empty(): return {}
	var rules: Dictionary = preload("res://src/content/repertoire_health_rules.gd").load_rules()
	var base := float(overrides.get("base_risk",rules.get("stage_base_risk",0.0015)))
	var major_fraction := float(overrides.get("major_fraction",rules.get("stage_major_fraction",0.12)))
	var body: Dictionary = career.athlete.body
	var rest := float(plan.shares.get("rest",0))
	var overload := maxf(0.0,stage_equivalent_attempts-18.0) + maxf(0.0,float(body.acute_fatigue)-40.0)*0.3 + maxf(0.0,float(body.cumulative_fatigue)-20.0)*0.5
	var risk := clampf(base + overload*float(rules.get("stage_overload_risk",0.0004))*(1.0-rest/150.0),0.0,1.0)
	if exposure != 1.0: risk = 1.0-pow(1.0-risk,exposure)
	var rng: RandomNumberGenerator = career.random_streams.take_rng("condition_training_stage")
	if rng.randf() >= risk: return {}
	var major := rng.randf() < clampf(major_fraction+overload*0.001,0.0,1.0)
	var severity := rng.randf_range(0.72,0.90) if major else rng.randf_range(0.15,0.40)
	var injury := {"id":"injury:%d:%d:%d" % [career.clock.year,career.clock.quarter,career.condition_state.injuries.size()],"site":"ankle","severity":severity,"remaining_quarters":2 if major else 1,"status":"active"}
	career.condition_state.injuries.append(injury)
	var label := "训练中落冰受伤，暂停剩余跳跃，等待治疗决定" if major else "踝部出现轻微不适，教练将降低后续负荷"
	if major:
		injury.rehabilitation_managed = true
		injury.function_limits = {"landing":{"blocked":true,"factor":0.4,"review_condition":"确认治疗路线并通过身体复评"}}
		career.condition_state.pending_decision = {"kind":"rehabilitation_initial","injury_id":injury.id}
		KeyNodes.add(career,injury.id,"injury_review",label)
	career.condition_state.medical_opinions.append({"injury_id":injury.id,"label":label,"clock":career.clock.to_dict()})
	var event := {"kind":"injury","injury_id":injury.id,"label":label,"clock":career.clock.to_dict(),"actual_stage_attempts":actual_attempts}
	career.event_ledger.append(event)
	return event

static func _advance_growth(career, result: Dictionary) -> void:
	var state: Dictionary = career.condition_state
	if str(state.growth_phase) == "rapid":
		state.growth_quarters = int(state.get("growth_quarters", 0)) + 1
		if int(state.growth_quarters) >= 4:
			state.growth_phase = "adapted"
		return
	if str(state.growth_phase) != "stable": return
	for node in state.get("key_nodes", []):
		if str(node.kind) == "growth_warning":
			if bool(node.resolved):
				state.growth_phase = "rapid"
				state.growth_quarters = 0
				career.athlete.body.growth_trend = 65.0
				career.athlete.body.joint_readiness = maxf(0.0, float(career.athlete.body.joint_readiness) - 4.0)
				result.events.append({"kind":"growth_change", "label":"正在适应身体变化"})
			return
	if career.clock.age_on(career.athlete.birth_year) >= 11:
		var observation := {"id":"growth:rapid", "label":"近期生长速度偏快", "clock":career.clock.to_dict()}
		state.growth_signals.append(observation)
		result.signals.append(observation.duplicate(true))
		KeyNodes.add(career, "growth:rapid", "growth_warning", observation.label)
		result.events.append({"kind":"growth_warning", "label":observation.label})
	elif career.clock.quarter == 4:
		# Neutral childhood observations share this sole growth-state owner; they
		# never overwrite a warned, rapid or adapted trajectory.
		career.athlete.body.growth_trend = career.random_streams.take_rng("condition_growth").randf_range(0.0, 20.0)

static func modifiers(career) -> Dictionary:
	var state: Dictionary = career.condition_state
	var injury_severity := 0.0
	for injury in state.injuries:
		if str(injury.get("status", "")) == "active": injury_severity = maxf(injury_severity, float(injury.get("severity", 0.0)))
	var stress := float(state.psychology.get("stress", career.athlete.mind.get("training_fear", 0.0)))
	var body: Dictionary = career.athlete.body
	return {"training_efficiency":clampf(1.0 - injury_severity * 0.5 - stress * 0.002, 0.25, 1.0), "fatigue_efficiency":clampf(1.0 - float(body.acute_fatigue) * 0.004 - float(body.cumulative_fatigue) * 0.006, 0.2, 1.0), "execution_penalty":injury_severity * 20.0 + float(body.cumulative_fatigue) * 0.15, "pressure_delta":stress * 0.5, "recovery_efficiency":1.0 - stress * 0.004}

static func can_compete(career, programs: Variant = null) -> bool:
	var functions = preload("res://src/simulation/athlete_function_service.gd")
	var has_program := false
	var selected: Dictionary = career.active_programs if programs == null else programs
	for program in selected.values():
		if program.is_empty(): continue
		has_program = true
		if not _program_allowed(career,program): return false
	if not has_program:
		return functions.action_constraints(career,{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":1}]}).allowed
	return true

static func _program_allowed(career, program: Dictionary) -> bool:
	var functions = preload("res://src/simulation/athlete_function_service.gd")
	for element in program.get("elements",[]):
		var action: Dictionary = element.duplicate(true)
		if action.get("kind") == "jump":
			action.parts = [{"jump_id":action.jump_id,"rotations":action.rotations}]
			action.parts.append_array(action.get("combination_parts",[]))
		if not functions.action_constraints(career,action).allowed: return false
	return true

static func has_medical_restriction(career) -> bool:
	for memory in career.memories:
		if str(memory.get("signature", "")) != "medical_restriction" or float(memory.get("strength", 0.0)) <= 0.0: continue
		var created: Dictionary = memory.get("created_clock", {})
		var elapsed: int = (career.clock.year - int(created.get("year", career.clock.year))) * 4 + career.clock.quarter - int(created.get("quarter", career.clock.quarter))
		if elapsed <= 0: return true
		# The memory remains part of the story, but restriction follows current
		# symptoms and injuries rather than the lifetime of that memory.
		for injury in career.condition_state.injuries:
			if str(injury.get("status", "")) == "active": return true
		if float(career.athlete.body.impact_load) >= 15.0 or float(career.athlete.body.ankle_load) >= 20.0: return true
	return false

static func can_train(career, plan) -> bool:
	if not career.condition_state.get("pending_decision",{}).is_empty(): return false
	var functions = preload("res://src/simulation/athlete_function_service.gd")
	var values: Dictionary = plan.shares if not plan.shares.is_empty() else plan.allocations
	for key in values:
		if int(values[key]) <= 0: continue
		if str(key).begins_with("jump_"):
			var id := str(key).trim_prefix("jump_")
			var action := {"kind":"jump","parts":[{"jump_id":id,"rotations":int(plan.jump_rotations.get(id,1))}]}
			if not functions.action_constraints(career,action).allowed: return false
		elif str(key).begins_with("program_"):
			if not _program_allowed(career,career.active_programs.get(str(key).trim_prefix("program_"),{})): return false
		elif str(key) in ["rotation","skating_foundation"]:
			var action := {"kind":"spin" if str(key) == "rotation" else "step_sequence"}
			if not functions.action_constraints(career,action).allowed: return false
	return true

static func competition_context(career) -> Dictionary:
	var effects := modifiers(career)
	return {"pressure":35.0 + float(effects.pressure_delta), "execution_penalty":float(career.athlete.body.cumulative_fatigue)*0.15,"function_limits":preload("res://src/simulation/athlete_function_service.gd").snapshot(career).limits}

static func labels(career) -> Array[String]:
	var result: Array[String] = []
	for injury in career.condition_state.injuries:
		if str(injury.get("status", "")) == "active": result.append("需要停跳康复，暂缓参赛" if float(injury.severity) >= 0.7 else "踝部不适，训练效率下降")
	if float(career.athlete.body.cumulative_fatigue) >= 30.0: result.append("恢复明显变慢")
	if not career.condition_state.psychology.is_empty(): result.append(str(career.condition_state.psychology.get("label", "心态平稳")))
	return result
