class_name AuthorityResolver
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const PlanProposal = preload("res://src/domain/plan_proposal.gd")
const AuthorityConstraint = preload("res://src/domain/authority_constraint.gd")

const CHILDHOOD_MIN_AGE := 6
const DEPENDENT_MAX_AGE := 17
const GUARDIAN_CONTROL_THRESHOLD := 35.0
const HEALTH_PRIORITY_THRESHOLD := 70.0
const COACH_TRUST_THRESHOLD := 35.0
const SECRET_ATTEMPTS_PER_BLOCK := 4

static func preview(career: CareerState, desired: TrainingPlan):
	var proposal = PlanProposal.create(desired)
	var rng := RandomNumberGenerator.new()
	rng.seed = career.seed + career.rng_step
	var legacy := resolve(career, desired, rng)
	for index in legacy.decisions.size():
		var decision: Dictionary = legacy.decisions[index]
		var conflict = AuthorityConstraint.new()
		conflict.id = "%s:%s:%d" % [decision.actor_id, decision.reason_code, index]
		conflict.actor_id = decision.actor_id
		conflict.reason_code = decision.reason_code
		conflict.proposed_allocations = decision.after.duplicate(true)
		conflict.proposed_shares = Dictionary(decision.get("after_shares", {})).duplicate(true)
		conflict.proposed_jump_rotations = Dictionary(decision.get("after_jump_rotations", {})).duplicate(true)
		conflict.responses = _available_responses(career)
		if conflict.reason_code == "extreme_child_load":
			conflict.responses.assign([{"id":"accept", "label":"接受安排"}, {"id":"negotiate", "label":"商量具体分配"}, {"id":"insist", "label":"公开坚持加练"}, {"id":"pretend_comply", "label":"表面服从、私下尝试"}])
		proposal.conflicts.append(conflict)
	proposal.status = "needs_response" if not proposal.conflicts.is_empty() else "resolved"
	return proposal

static func respond(career: CareerState, proposal, conflict_id: String, response_id: String, rng: RandomNumberGenerator):
	var conflict = null
	for candidate in proposal.conflicts:
		if candidate.id == conflict_id:
			conflict = candidate
			break
	if conflict == null:
		return proposal
	var available: Array = conflict.responses.map(func(item): return item.id)
	if not available.has(response_id):
		return proposal
	if conflict.reason_code == "extreme_child_load":
		return _respond_extreme(career, proposal, conflict, response_id)
	var accepted := response_id == "accept"
	if response_id == "persuade":
		var chance := clampf((float(career.athlete.mind.autonomy) + float(career.athlete.mind.expression)) / 200.0, 0.05, 0.75)
		accepted = not (rng.randf() < chance)
	if response_id == "ask_reason":
		proposal.decisions.append({"actor_id": conflict.actor_id, "response_id": response_id, "reason_code": conflict.reason_code})
		return proposal
	if accepted or response_id == "pretend_comply":
		proposal.approved = TrainingPlan.create(conflict.proposed_shares, conflict.proposed_jump_rotations).plan if not conflict.proposed_shares.is_empty() else TrainingPlan.create(conflict.proposed_allocations).plan
		_preserve_specialists(career, proposal.desired, proposal.approved)
	if response_id == "pretend_comply":
		proposal.secret_practice_intent = _percentage_secret_intent(career, proposal.desired, proposal.approved) if not proposal.desired.shares.is_empty() else _secret_intent(career, proposal.desired.allocations, conflict.proposed_allocations)
	proposal.executed = proposal.approved
	proposal.decisions.append({"actor_id": conflict.actor_id, "response_id": response_id, "reason_code": conflict.reason_code, "adult_change_accepted": accepted})
	proposal.conflicts.erase(conflict)
	proposal.status = "resolved" if proposal.conflicts.is_empty() else "needs_response"
	return proposal

static func _secret_intent(career: CareerState, desired: Dictionary, approved: Dictionary) -> Dictionary:
	var chosen_category := ""
	var refused_units := 0
	for category_id in TrainingPlan.CATEGORY_IDS:
		if not category_id.begins_with("jump_"):
			continue
		var difference := int(desired.get(category_id, 0)) - int(approved.get(category_id, 0))
		if difference > refused_units:
			chosen_category = category_id
			refused_units = difference
	if chosen_category.is_empty():
		return {}
	return {
		"jump_id": chosen_category.trim_prefix("jump_"), "rotations": 1,
		"attempts": refused_units * 8, "units": refused_units, "familiarity": 0.0,
		"money_cost": refused_units * 2.0,
		"free_ice_access": float(career.athlete.resources.ice_access) > 0.0,
		"transport_available": float(career.athlete.resources.money) >= 10.0,
		"unmonitored_window": float(career.athlete.mind.autonomy) >= 25.0,
	}

static func _available_responses(career: CareerState) -> Array[Dictionary]:
	var autonomy := float(career.athlete.mind.get("autonomy", 0.0))
	var responses: Array[Dictionary] = [
		{"id": "accept", "label": "接受安排"},
		{"id": "ask_reason", "label": "询问原因"},
	]
	if autonomy >= 15.0:
		responses.append({"id": "persuade", "label": "尝试说服"})
	if autonomy >= 25.0:
		responses.append({"id": "pretend_comply", "label": "表面服从"})
	if autonomy >= 45.0:
		responses.append({"id": "insist", "label": "坚持原计划"})
	return responses

static func resolve(career: CareerState, requested: TrainingPlan, rng: RandomNumberGenerator) -> Dictionary:
	if not requested.shares.is_empty():
		return _resolve_percentage(career, requested)
	var allocations: Dictionary = requested.allocations.duplicate()
	var decisions: Array[Dictionary] = []
	if not _is_dependent_age(career):
		return {"approved_plan": requested, "decisions": decisions}

	_apply_guardian_decision(career, allocations, decisions)
	_apply_coach_decision(career, allocations, decisions, not decisions.is_empty())

	if decisions.is_empty():
		return {"approved_plan": requested, "decisions": decisions}
	var approved: TrainingPlan = TrainingPlan.create(allocations).plan
	return {"approved_plan": approved, "decisions": decisions}

static func _resolve_percentage(career: CareerState, requested: TrainingPlan) -> Dictionary:
	# Preview must never mutate the plan the player submitted. Apart from making
	# the UI lie about the desired choice, mutation could turn an already-safe
	# recovery plan into a no-op conflict that reappeared after every response.
	var shares: Dictionary = requested.shares.duplicate(true)
	var rotations: Dictionary = requested.jump_rotations.duplicate(true)
	var decisions: Array[Dictionary] = []
	if not _is_dependent_age(career):
		return {"approved_plan": requested, "decisions": decisions}
	if _jump_units(shares) >= 75:
		var actor_id := "guardian" if career.relationships.has("guardian") and float(career.relationships.guardian.health_priority) >= 40.0 else "coach"
		if not career.relationships.has(actor_id): actor_id = "guardian" if career.relationships.has("guardian") else ""
		if not actor_id.is_empty():
			var before := shares.duplicate(true)
			var cap := 35 if float(career.relationships[actor_id].health_priority) >= 70.0 else 45
			while _jump_units(shares) > cap:
				_move_share(shares, _largest_jump_category(shares), "rest")
			_record_percentage_decision(decisions, actor_id, "extreme_child_load", before, shares, rotations, rotations)
			var reduced = TrainingPlan.create(shares, rotations).plan
			_preserve_specialists(career, requested, reduced)
			return {"approved_plan":reduced, "decisions":decisions}
	var guardian = career.relationships.get("guardian")
	if guardian != null and (_needs_forced_recovery(career) or _has_active_memory(career, "medical_restriction")) and int(shares.rest) < 20:
		var before := shares.duplicate(true)
		while int(shares.rest) < 20:
			_move_share(shares, _largest_non_rest_category(shares), "rest")
		_record_percentage_decision(decisions, "guardian", "fatigue_recovery_required", before, shares, rotations, rotations)
	elif guardian != null and float(guardian.health_priority) >= 40.0 and requested.requires_load_review():
		var before := shares.duplicate(true)
		_move_share(shares, _largest_jump_category(shares), "rest")
		_record_percentage_decision(decisions, "guardian", "guardian_health_protection", before, shares, rotations, rotations)
	if decisions.is_empty() and career.relationships.has("coach"):
		var risky_jumps := _rotation_risks(career, shares, rotations)
		if not risky_jumps.is_empty():
			var adjusted_rotations := rotations.duplicate(true)
			for risky_jump in risky_jumps:
				adjusted_rotations[risky_jump] = maxi(1, int(career.athlete.jumps[risky_jump].unlocked_rotations))
			_record_percentage_decision(decisions, "coach", "coach_rotation_risk", shares, shares, rotations, adjusted_rotations)
			rotations = adjusted_rotations
		elif requested.requires_load_review():
			var before := shares.duplicate(true)
			_move_share(shares, _largest_jump_category(shares), "rest")
			_record_percentage_decision(decisions, "coach", "coach_jump_load_safety", before, shares, rotations, rotations)
	if decisions.is_empty():
		return {"approved_plan": requested, "decisions": decisions}
	var adjusted = TrainingPlan.create(shares, rotations).plan
	_preserve_specialists(career, requested, adjusted)
	return {"approved_plan": adjusted, "decisions": decisions}

static func _preserve_specialists(career: CareerState, source: TrainingPlan, destination: TrainingPlan) -> void:
	destination.expression_share = mini(source.expression_share,maxi(0,int(destination.shares.get("skating_foundation",0))-5))
	destination.lesson_quality = source.lesson_quality.duplicate(true)
	destination.focus_lessons = source.focus_lessons.duplicate(true)
	preload("res://src/simulation/coach_lesson_service.gd").project_decision(source,destination)
	# Rebuild allocations without losing programme intentions. Actual attempt
	# budgets are recalculated downstream from the approved family shares.
	for target in source.specialist_targets:
		var action: Dictionary = target.get("action", {})
		if not preload("res://src/simulation/athlete_function_service.gd").action_constraints(career, action).allowed:
			continue
		var allowed := true
		for part in action.get("parts", []):
			var jump_id := str(part.jump_id)
			if int(destination.shares.get("jump_%s" % jump_id, 0)) <= 0 or int(part.rotations) > int(destination.jump_rotations.get(jump_id, 1)):
				allowed = false
		if allowed: destination.specialist_targets.append(target.duplicate(true))

static func _respond_extreme(career, proposal, conflict, response_id: String):
	if response_id == "ask_reason": return proposal
	var shares: Dictionary = conflict.proposed_shares.duplicate(true)
	var extra := 0
	var closeness_delta := 2.0
	var trust_delta := 2.0
	var efficiency := 1.0
	match response_id:
		"negotiate", "persuade":
			extra = 10
			closeness_delta = 1.0
			trust_delta = 3.0
			efficiency = 0.95
		"insist":
			extra = 20
			closeness_delta = -4.0
			trust_delta = -5.0
			efficiency = 0.75
		"pretend_comply":
			extra = 5
			closeness_delta = 0.0
			trust_delta = 1.0
			efficiency = 0.85
	proposal.approved = TrainingPlan.create(shares, conflict.proposed_jump_rotations).plan
	_preserve_specialists(career, proposal.desired, proposal.approved)
	var jump_id := _largest_jump_category(proposal.desired.shares)
	shares[jump_id] = int(shares[jump_id]) + extra
	shares.rest = int(shares.rest) - extra
	proposal.executed = TrainingPlan.create(shares, conflict.proposed_jump_rotations).plan
	_preserve_specialists(career, proposal.desired, proposal.executed)
	proposal.training_efficiency = efficiency
	if response_id == "pretend_comply":
		proposal.secret_practice_intent = _percentage_secret_intent(career, proposal.desired, proposal.approved)
	var adult = career.relationships[conflict.actor_id]
	adult.closeness = clampf(adult.closeness + closeness_delta, 0.0, 100.0)
	adult.professional_trust = clampf(adult.professional_trust + trust_delta, 0.0, 100.0)
	var event := {"category":"relationship_delta", "actor_id":conflict.actor_id, "closeness_delta":closeness_delta, "trust_delta":trust_delta, "response_id":response_id, "clock":career.clock.to_dict()}
	career.event_ledger.append(event)
	proposal.decisions.append(event.duplicate(true))
	proposal.conflicts.erase(conflict)
	proposal.status = "resolved" if proposal.conflicts.is_empty() else "needs_response"
	return proposal

static func _rotation_risks(career: CareerState, shares: Dictionary, rotations: Dictionary) -> Array[String]:
	var readiness := (float(career.athlete.body.strength_readiness) + float(career.athlete.body.joint_readiness)) / 2.0
	var risks: Array[String] = []
	for jump_id in TrainingPlan.JUMP_LABELS:
		if int(shares.get("jump_%s" % jump_id, 0)) <= 0:
			continue
		var target := int(rotations.get(jump_id, 1))
		# Learning the next rotation needs a baseline of whole-body readiness,
		# but must not require competition-level strength before practice can
		# begin. Higher rotations still raise the threshold progressively.
		var readiness_floor := 25.0 + float(target) * 5.0
		var learned := maxi(1,int(career.athlete.jumps[jump_id].unlocked_rotations))
		# This review concerns NEW rotation readiness. Replacing an already
		# learned target by that identical target is not an actionable conflict.
		# Current injury/function limits remain enforced by medical review.
		if target > learned+1 or (target > learned and readiness < readiness_floor):
			risks.append(str(jump_id))
	return risks

static func _move_share(shares: Dictionary, from_category: String, to_category: String) -> void:
	shares[from_category] = int(shares[from_category]) - TrainingPlan.SHARE_STEP
	shares[to_category] = int(shares[to_category]) + TrainingPlan.SHARE_STEP

static func _record_percentage_decision(decisions: Array[Dictionary], actor_id: String, reason_code: String, before_shares: Dictionary, after_shares: Dictionary, before_rotations: Dictionary, after_rotations: Dictionary) -> void:
	decisions.append({"actor_id": actor_id, "action": "adjust_training_plan", "reason_code": reason_code, "before_shares": before_shares.duplicate(true), "after_shares": after_shares.duplicate(true), "before_jump_rotations": before_rotations.duplicate(true), "after_jump_rotations": after_rotations.duplicate(true), "before": before_shares.duplicate(true), "after": after_shares.duplicate(true)})

static func _percentage_secret_intent(career: CareerState, desired: TrainingPlan, approved: TrainingPlan) -> Dictionary:
	for jump_id in TrainingPlan.JUMP_LABELS:
		var desired_rotation := int(desired.jump_rotations.get(jump_id, 1))
		var approved_rotation := int(approved.jump_rotations.get(jump_id, 1))
		var refused_share := int(desired.shares.get("jump_%s" % jump_id, 0)) - int(approved.shares.get("jump_%s" % jump_id, 0))
		if desired_rotation > approved_rotation or refused_share > 0:
			var blocks := maxi(1, refused_share / TrainingPlan.SHARE_STEP)
			return {"jump_id": jump_id, "rotations": desired_rotation, "attempts": blocks * SECRET_ATTEMPTS_PER_BLOCK, "units": blocks, "familiarity": 0.0, "money_cost": blocks * 2.0, "free_ice_access": float(career.athlete.resources.ice_access) > 0.0, "transport_available": float(career.athlete.resources.money) >= 10.0, "unmonitored_window": float(career.athlete.mind.autonomy) >= 25.0}
	return {}

static func _is_dependent_age(career: CareerState) -> bool:
	if career.clock == null or career.athlete == null:
		return false
	var age := career.clock.age_on(career.athlete.birth_year)
	return age >= CHILDHOOD_MIN_AGE and age <= DEPENDENT_MAX_AGE

static func _apply_guardian_decision(career: CareerState, allocations: Dictionary, decisions: Array[Dictionary]) -> void:
	if not career.relationships.has("guardian"):
		return
	var guardian = career.relationships["guardian"]
	if _has_active_memory(career, "medical_restriction") and _jump_units(allocations) > 0:
		_record_move(decisions, allocations, "guardian", _largest_jump_category(allocations), "rest", "medical_recovery_required")
		return
	if _needs_forced_recovery(career) and _active_units(allocations) > 0:
		_record_move(decisions, allocations, "guardian", _largest_non_rest_category(allocations), "rest", "fatigue_recovery_required")
		return
	if guardian.health_priority >= 40.0 and _jump_units(allocations) >= 5:
		_record_move(decisions, allocations, "guardian", _largest_jump_category(allocations), "rest", "guardian_health_protection")
	elif 100.0 - guardian.health_priority >= HEALTH_PRIORITY_THRESHOLD and int(allocations["rest"]) > 2:
		_record_move(decisions, allocations, "guardian", "rest", "jump_toe_loop", "guardian_achievement_pressure")

static func _apply_coach_decision(career: CareerState, allocations: Dictionary, decisions: Array[Dictionary], guardian_already_intervened: bool) -> void:
	if not career.relationships.has("coach"):
		return
	var coach = career.relationships["coach"]
	if not guardian_already_intervened and _has_active_memory(career, "medical_restriction") and _jump_units(allocations) > 0:
		_record_move(decisions, allocations, "coach", _largest_jump_category(allocations), "rest", "medical_recovery_required")
		return
	if not guardian_already_intervened and _needs_forced_recovery(career) and _active_units(allocations) > 0:
		_record_move(decisions, allocations, "coach", _largest_non_rest_category(allocations), "rest", "fatigue_recovery_required")
		return
	if not guardian_already_intervened and _jump_units(allocations) >= 5:
		_record_move(decisions, allocations, "coach", _largest_jump_category(allocations), "rest", "coach_jump_load_safety")
		return
	if int(allocations.skating_foundation) >= 4 and _jump_units(allocations) < 4:
		_record_move(decisions, allocations, "coach", "skating_foundation", "jump_toe_loop", "coach_jump_priority")
		return
	if coach.professional_trust >= COACH_TRUST_THRESHOLD:
		return
	var source_category := _largest_non_rest_category(allocations)
	if source_category == "skating_foundation":
		return
	_record_move(decisions, allocations, "coach", source_category, "skating_foundation", "coach_foundation_priority")

static func _has_active_memory(career: CareerState, signature: String) -> bool:
	if signature == "medical_restriction":
		return preload("res://src/simulation/athlete_condition_service.gd").has_medical_restriction(career)
	for memory in career.memories:
		if memory.get("signature") == signature and float(memory.get("strength", 0.0)) > 0.0:
			return true
	return false

static func _needs_forced_recovery(career: CareerState) -> bool:
	var body: Dictionary = career.athlete.body
	return (
		float(body.get("acute_fatigue", 0.0)) >= 70.0
		or float(body.get("cumulative_fatigue", 0.0)) >= 30.0
		or float(body.get("ankle_load", 0.0)) >= 80.0
		or float(body.get("impact_load", 0.0)) >= 80.0
	)

static func _active_units(allocations: Dictionary) -> int:
	var total := 0
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id != "rest":
			total += int(allocations.get(category_id, 0))
	return total

static func _largest_non_rest_category(allocations: Dictionary) -> String:
	var largest_category := "skating_foundation"
	var largest_value := int(allocations[largest_category])
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id == "rest" or category_id.begins_with("jump_"):
			continue
		var value := int(allocations[category_id])
		if value > largest_value:
			largest_category = category_id
			largest_value = value
	if _jump_units(allocations) > largest_value:
		return _largest_jump_category(allocations)
	return largest_category

static func _jump_units(allocations: Dictionary) -> int:
	var total := 0
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id.begins_with("jump_"):
			total += int(allocations[category_id])
	return total

static func _largest_jump_category(allocations: Dictionary) -> String:
	var result := "jump_toe_loop"
	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id.begins_with("jump_") and int(allocations[category_id]) > int(allocations[result]):
			result = category_id
	return result

static func _record_move(decisions: Array[Dictionary], allocations: Dictionary, actor_id: String, from_category: String, to_category: String, reason_code: String) -> void:
	var before := allocations.duplicate()
	allocations[from_category] = int(allocations[from_category]) - 1
	allocations[to_category] = int(allocations[to_category]) + 1
	decisions.append({
		"actor_id": actor_id,
		"action": "adjust_training_plan",
		"reason_code": reason_code,
		"before": before,
		"after": allocations.duplicate(),
	})
