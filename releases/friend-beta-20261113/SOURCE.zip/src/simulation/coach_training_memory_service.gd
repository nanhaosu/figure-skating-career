class_name CoachTrainingMemoryService
extends RefCounted

static func record_stage(career, plan, batches: Array) -> void:
	if plan.coach_decision.is_empty() or batches.is_empty(): return
	var key := "%d:%d" % [career.clock.year,career.clock.quarter]
	var state: Dictionary = career.coach_training_state
	var actual: Dictionary = plan.coach_decision.duplicate(true)
	actual.period_key = key
	actual.allocated_gap_ids = []
	var previous: Dictionary = state.get("last_decision",{})
	if previous.get("period_key") == key:
		actual.allocated_gap_ids = Array(previous.get("allocated_gap_ids",[])).duplicate()
	var performed := {}
	for batch in batches:
		if int(batch.get("attempts",0)) > 0: performed[str(batch.get("jump_id",""))] = true
	for id in plan.coach_decision.get("allocated_gap_ids",[]):
		if performed.has(id) and not actual.allocated_gap_ids.has(id): actual.allocated_gap_ids.append(id)
	state.last_decision = actual

static func complete_period(career) -> void:
	var state: Dictionary = career.coach_training_state
	var key := "%d:%d" % [career.clock.year,career.clock.quarter]
	var actual: Dictionary = state.get("last_decision",{})
	if actual.get("period_key") != key or state.last_completed_period == key: return
	state.completed_periods += 1
	state.last_completed_period = key
	for id in actual.get("allocated_gap_ids",[]): state.last_practiced[id] = int(state.completed_periods)
	career.history.append({"category":"coach_training","clock":career.clock.to_dict(),"decision":actual.duplicate(true)})
