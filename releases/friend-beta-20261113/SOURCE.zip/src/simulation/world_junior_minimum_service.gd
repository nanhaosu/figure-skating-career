class_name WorldJuniorMinimumService
extends RefCounted

# Women only. Historical separate-segment minima, not modern combined TES.
# ISU Communication 2205 §13 and 2262 §7. Cutoff supplied by the verified
# event adapter; never infer the first official practice from a quarter.
static func evaluate(season_start_year: int, cutoff: String, records: Array) -> Dictionary:
	var result := {"eligible":false,"version":1,"cutoff":cutoff,"segments":{},"reasons":[]}
	if season_start_year not in [2018,2019] or not _valid_date(cutoff):
		result.reasons.append("该赛季世青最低技术分或截止日期尚未核实")
		return result
	for segment in ["short","free"]:
		var evidence := {}
		for value in records:
			if not value is Dictionary: continue
			var record: Dictionary = value
			if record.get("segment") != segment: continue
			if record.get("scope") != "international" or record.get("level") != "junior": continue
			if record.get("discipline") != "women_singles" or record.get("record_eligibility") != "isu_recognized": continue
			if str(record.get("event_id","")).is_empty(): continue
			var earned = record.get("season_start_year")
			if not (earned is int or earned is float): continue
			if not is_finite(float(earned)) or float(earned) != int(earned): continue
			if int(earned) not in [season_start_year-1,season_start_year]: continue
			var date := str(record.get("performed_on",""))
			if not _valid_date(date) or date > cutoff: continue
			# An asserted season must also match the competition date.
			if date < "%04d-07-01" % int(earned) or date >= "%04d-07-01" % (int(earned)+1): continue
			var tes = record.get("tes")
			if not (tes is int or tes is float): continue
			if not is_finite(float(tes)): continue
			var threshold := 23.0 if segment == "short" else 38.0
			if season_start_year == 2018 and int(earned) == 2017:
				threshold = 21.0 if segment == "short" else 36.0
			if float(tes) < threshold: continue
			if evidence.is_empty() or float(tes) > float(evidence.tes):
				evidence = record.duplicate(true)
				evidence.threshold = threshold
		if evidence.is_empty():
			var target := "23" if segment == "short" else "38"
			if season_start_year == 2018:
				target = "2018—19成绩至少%s；2017—18成绩至少%s" % [target,"21" if segment == "short" else "36"]
			else:
				target = "2018—19或2019—20成绩至少%s" % target
			result.reasons.append("%sTES未达标：%s。须在%s及以前的认可青年国际赛取得，国内赛总分不代替TES" % ["短节目" if segment == "short" else "自由滑",target,cutoff])
		else:
			result.segments[segment] = evidence
	result.eligible = result.segments.size() == 2
	return result

static func _valid_date(value: String) -> bool:
	if value.length() != 10 or value[4] != "-" or value[7] != "-": return false
	for part in [value.substr(0,4),value.substr(5,2),value.substr(8,2)]:
		for character in part:
			if character < "0" or character > "9": return false
	var year := int(value.substr(0,4))
	var month := int(value.substr(5,2))
	var day := int(value.substr(8,2))
	if year < 1 or month < 1 or month > 12: return false
	var days := [31,28,31,30,31,30,31,31,30,31,30,31]
	if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0): days[1] = 29
	return day >= 1 and day <= days[month-1]
