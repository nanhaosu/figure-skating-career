class_name CompetitionRankingService
extends RefCounted

const Scoring = preload("res://src/content/formal_scoring_repository.gd")
const JGP = preload("res://src/simulation/junior_grand_prix_service.gd")

# Receipt and earned history persist separately from the current ranked totals.
static func preview(previous: Dictionary, archive: Dictionary, result: Dictionary) -> Dictionary:
	var next := previous.duplicate(true)
	var receipt := "%s:%s" % [archive.get("season_id",""),archive.get("event_id","")]
	if next.get("applied_events",{}).has(receipt): return next
	var event: Dictionary = archive.get("event",{})
	var year := int(event.get("ruleset_season_start_year",str(archive.get("season_id","2018-19")).left(4).to_int()))
	var loaded := Scoring.load_catalog(year,"women_singles")
	var tables: Dictionary = loaded.get("catalog",{}).get("ranking_tables",{})
	var system := str(event.get("ranking_points_system","domestic"))
	var family := str(event.get("event_family",""))
	var rank := int(result.get("final_rank",result.get("rank",result.get("short_rank",999))))
	var domestic := _at(tables.get("domestic",[]),rank) if system in ["domestic","domestic_club"] else 0
	var world := 0; var category := ""
	if family in ["jgp_stage","jgp_final"] and system in ["isu_jgp_standings","isu_jgp_final"]:
		world = _at(tables.get(family,[]),rank); category = "jgp"
	elif family == "world_junior" and system == "isu_world_standings" and result.has("free_score"):
		world = _at(tables.get(family,[]),rank); category = "championship"
	elif year in [2020,2021] and system == "isu_world_standings" and str(archive.get("status","")) == "complete" and str(event.get("status","scheduled")) in ["scheduled","held"]:
		# 1629: senior GP has its own best-two allowance, separate from JGP.
		# Championships share one best result and require finishing the free.
		if family in ["gp_stage","gp_final"]:
			world = _at(tables.get(family,[]),rank); category = "gp"
		elif family in ["world_championships","four_continents","olympic_games"] and result.has("free_score"):
			world = _at(tables.get(family,[]),rank); category = "championship"
	var entry := {"event_id":str(archive.get("event_id","")),"season_id":str(archive.get("season_id","")),"date":str(event.get("start_date",event.get("actual_dates",{}).get("start",""))),"rank":rank,"system":system,"category":category,"world_points":world,"domestic_points":domestic,"jgp_points":JGP.placement_points(rank) if family == "jgp_stage" else 0}
	if not next.has("history"): next.history = []
	next.history.append(entry)
	if not next.has("applied_events"): next.applied_events = {}
	next.applied_events[receipt] = entry.duplicate(true)
	next.domestic_points = int(next.get("domestic_points",0)) + domestic
	if not next.has("domestic_seasons"): next.domestic_seasons = {}
	next.domestic_seasons[entry.season_id] = int(next.domestic_seasons.get(entry.season_id,0)) + domestic
	if not next.has("jgp_seasons"): next.jgp_seasons = {}
	next.jgp_seasons[entry.season_id] = int(next.jgp_seasons.get(entry.season_id,0)) + int(entry.jgp_points)
	var current_year := year
	for item in next.history: current_year = maxi(current_year,str(item.season_id).left(4).to_int())
	next.isu_world = {"points":_total(next.history,current_year,false),"rank":0,"season_id":"%d-%02d" % [current_year,(current_year+1)%100]}
	next.season_world = {"points":_total(next.history,current_year,true),"rank":0,"season_id":next.isu_world.season_id}
	return next

static func _at(table: Array, rank: int) -> int:
	return int(table[rank-1]) if rank >= 1 and rank <= table.size() else 0

static func begin_season(ranking: Dictionary, year: int) -> void:
	var season_id := "%d-%02d" % [year,(year+1)%100]
	ranking.domestic_points = int(ranking.get("domestic_seasons",{}).get(season_id,0))
	ranking.isu_world = {"points":_total(ranking.get("history",[]),year,false),"rank":0,"season_id":season_id}
	ranking.season_world = {"points":_total(ranking.get("history",[]),year,true),"rank":0,"season_id":season_id}

static func _total(history: Array, year: int, current_only: bool) -> int:
	var by_category := {}
	for item in history:
		var age := year - str(item.season_id).left(4).to_int()
		if age < 0 or age > (0 if current_only else 2) or int(item.world_points) <= 0: continue
		var category := str(item.category)
		if not by_category.has(category): by_category[category] = {}
		if not by_category[category].has(age): by_category[category][age] = []
		by_category[category][age].append(int(round(float(item.world_points)*(0.7 if age == 2 else 1.0))))
	var total := 0
	for category in by_category:
		var selected: Array = []
		var per_season := 1 if category == "championship" else 2
		for values in by_category[category].values():
			values.sort(); values.reverse(); selected.append_array(values.slice(0,per_season))
		selected.sort(); selected.reverse()
		for points in selected.slice(0,per_season if current_only else per_season*2): total += int(points)
	return total

static func refresh_ranks(player_ranking: Dictionary, world: Dictionary) -> void:
	for system in ["isu_world","season_world"]:
		var rows: Array = [{"id":"player","ranking":player_ranking}]
		for id in world:
			if world[id].get("ranking_state",{}).get(system) is Dictionary: rows.append({"id":id,"ranking":world[id].ranking_state})
		rows.sort_custom(func(a,b): return a.ranking.get(system,{}).get("points",0) > b.ranking.get(system,{}).get("points",0))
		var previous := -1; var rank := 0
		for i in rows.size():
			var ranking: Dictionary = rows[i].ranking
			var points := int(ranking.get(system,{}).get("points",0))
			if points != previous: rank = i+1
			if ranking.get(system) is Dictionary: ranking[system].rank = rank if points > 0 else 0
			previous = points
	for record in world.values():
		if not record.get("ranking_state",{}).get("isu_world") is Dictionary: continue
		record.ranking_points = {"domestic":record.ranking_state.get("domestic_points",0),"isu_world":record.ranking_state.isu_world.points,"season_world":record.ranking_state.season_world.points}
