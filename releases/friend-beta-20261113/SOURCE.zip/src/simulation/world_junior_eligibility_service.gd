class_name WorldJuniorEligibilityService
extends RefCounted

const Calendar = preload("res://src/content/season_calendar_repository.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const Minimum = preload("res://src/simulation/world_junior_minimum_service.gd")
# 2019 announcement §3.2 / schedule; 2020 official ISU music rotation.
# These are TES cutoffs (first official practice minus 21 days).
const CUTOFFS := {"isu_world_junior_2019":"2019-02-11", "isu_world_junior_2020":"2020-02-10"}

static func evaluate_career(career, event: Dictionary) -> Dictionary:
	if event.get("event_id") == "isu_world_junior_2022":
		var service = preload("res://src/simulation/international_personal_eligibility.gd")
		var policy: Dictionary = service.policy_for(event)
		var personal: Dictionary = service.evaluate(career,event,policy)
		return {"eligible":personal.tes.eligible,"version":2,"cutoff":str(policy.get("cutoff","")),"segments":personal.tes.segments.duplicate(true),"reasons":service.explanations(personal,policy),"warnings":personal.warnings.duplicate(),"personal_eligibility":personal}
	var records: Array = []
	var calendars := {}
	for archive in career.competition_archive:
		if archive.get("status") != "complete" or archive.get("world_only",false): continue
		if not Codec.validate(archive).is_empty(): continue
		var archived_event: Dictionary = archive.get("event",{})
		var year := int(archived_event.get("ruleset_season_start_year",0))
		if year not in [2018,2019]: continue
		if not calendars.has(year): calendars[year] = Calendar.load_international_calendar(year,"women_singles","junior")
		var loaded: Dictionary = calendars[year]
		if not loaded.errors.is_empty(): continue
		var canonical := {}
		for candidate in loaded.calendar.events:
			if candidate.event_id == archive.get("event_id"):
				canonical = candidate
				break
		if canonical.is_empty() or archived_event.get("event_id") != canonical.event_id: continue
		if canonical.get("record_eligibility") != "isu_recognized" or canonical.get("scope") != "international": continue
		if not canonical.get("level_options",[]).has("junior"): continue
		for segment in ["short","free"]:
			var performance: Dictionary = archive.get(segment+"_results",{}).get("player",{})
			var score: Dictionary = performance.get("score",performance.get("protocol",{}))
			if not score.has("tes"): continue
			# Canonical end date is conservative when exact segment dates aren't
			# catalogued. Never trust a user-provided quarter or guessed date.
			var performed := str(canonical.get("segment_dates",{}).get(segment,canonical.end_date))
			records.append({"event_id":canonical.event_id,"segment":segment,"tes":score.tes,"season_start_year":year,"performed_on":performed,"scope":"international","level":"junior","discipline":"women_singles","record_eligibility":"isu_recognized"})
	return Minimum.evaluate(int(event.get("ruleset_season_start_year",0)),str(CUTOFFS.get(event.get("event_id"),"")),records)
