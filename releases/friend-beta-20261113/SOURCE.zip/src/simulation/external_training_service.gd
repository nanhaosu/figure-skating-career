class_name ExternalTrainingService
extends RefCounted

const Repository = preload("res://src/content/external_training_repository.gd")

static func offers(career) -> Array:
	var result: Array = []
	for course in Repository.courses():
		for focus in career.training_direction.focuses:
			if not course.kinds.has(focus.kind): continue
			if course.id == "jump_axis" and focus.target.get("kind") != "jump": continue
			result.append({"course":course,"focus":focus})
	return result

static func book(career, offer_id: String, focus_id: String, receipt_id: String) -> Dictionary:
	if receipt_id.is_empty() or receipt_id.length() > 160: return {"ok":false,"error":"外训确认编号无效"}
	for booking in career.training_direction.external_schedule:
		if booking.id == receipt_id: return {"ok":true,"events":[]}
	var course := Repository.course(offer_id)
	if course.is_empty(): return {"ok":false,"error":"外训课程不存在"}
	var focus := {}
	for option in offers(career):
		if option.course.id == offer_id and option.focus.id == focus_id: focus = option.focus
	if focus.is_empty(): return {"ok":false,"error":"请先设置与该外训匹配的培养重点"}
	if not career.condition_state.get("pending_decision",{}).is_empty(): return {"ok":false,"error":"请先处理重大伤病，再申请外训"}
	if float(career.athlete.resources.money) < float(course.cost): return {"ok":false,"error":"训练资金不足"}
	var year: int = career.clock.year
	var quarter: int = career.clock.quarter
	if int(career.training_period_state.get("weeks_elapsed",0)) > 0:
		quarter += 1
		if quarter > 4: year += 1; quarter = 1
	for booking in career.training_direction.external_schedule:
		if booking.status == "booked" and int(booking.year) == year and int(booking.quarter) == quarter: return {"ok":false,"error":"这一训练期已有外训安排，不能叠加"}
	if _competition_conflict(career,year,quarter): return {"ok":false,"error":"本期已有确认比赛，请改在没有比赛的训练期申请外训"}
	if career.training_direction.external_schedule.size() >= 64: return {"ok":false,"error":"外训记录已满，请先完成当前安排"}
	var booking := {"id":receipt_id,"offer_id":offer_id,"focus_id":focus_id,"focus":focus.duplicate(true),"year":year,"quarter":quarter,"cost":int(course.cost),"executed_stages":0,"refund":0,"status":"booked"}
	career.athlete.resources.money -= float(course.cost)
	career.training_direction.external_schedule.append(booking)
	career.training_direction.revision += 1
	_refresh_plan(career)
	var event := {"kind":"external_training_booked","booking_id":receipt_id,"clock":career.clock.to_dict(),"cost":int(course.cost)}
	career.event_ledger.append(event)
	return {"ok":true,"events":[event]}

static func cancel(career, booking_id: String, receipt_id: String, refresh_plan: bool = true) -> Dictionary:
	if receipt_id.is_empty(): return {"ok":false,"error":"取消确认编号无效"}
	for event in career.event_ledger:
		if event.get("kind") == "external_training_cancelled" and event.get("receipt_id") == receipt_id: return {"ok":true,"events":[]}
	for booking in career.training_direction.external_schedule:
		if booking.id != booking_id: continue
		if booking.status != "booked": return {"ok":true,"events":[]}
		_refund(career,booking)
		career.training_direction.revision += 1
		if refresh_plan: _refresh_plan(career)
		var event := {"kind":"external_training_cancelled","receipt_id":receipt_id,"booking_id":booking_id,"refund":booking.refund,"clock":career.clock.to_dict()}
		career.event_ledger.append(event)
		return {"ok":true,"events":[event]}
	return {"ok":false,"error":"找不到这项外训预约"}

static func quality_for(career, focus: Dictionary) -> float:
	for booking in career.training_direction.external_schedule:
		if booking.status != "booked" or int(booking.year) != career.clock.year or int(booking.quarter) != career.clock.quarter: continue
		if booking.focus.kind == focus.kind and booking.focus.target == focus.target:
			return float(Repository.course(booking.offer_id).get("quality",1.0))
	return 1.0

static func settle_stage(career) -> void:
	for booking in career.training_direction.external_schedule:
		if booking.status != "booked": continue
		var current: int = career.clock.year*4+career.clock.quarter
		var scheduled: int = int(booking.year)*4+int(booking.quarter)
		if scheduled > current: continue
		if scheduled < current: _refund(career,booking); continue
		# A dated executor owns these lessons. A legacy quarter callback must
		# not spend another quarter of a course after a few calendar days.
		if booking.has("executed_days"): continue
		booking.executed_stages = mini(4,int(booking.executed_stages)+1)
		if not career.condition_state.get("pending_decision",{}).is_empty(): _refund(career,booking)
		elif int(booking.executed_stages) == 4: booking.status = "completed"

static func settle_day(career, date: String) -> Dictionary:
	var dates = preload("res://src/simulation/dated_training_window.gd")
	var checked: Dictionary = dates.plan(date,date)
	if not checked.errors.is_empty(): return {"errors":checked.errors}
	var year := int(date.substr(0,4))
	var quarter := (int(date.substr(5,2))-1)/3+1
	if year != career.clock.year or quarter != career.clock.quarter: return {"errors":["外训日期不属于当前训练季度"]}
	var start := "%04d-%02d-01" % [year,(quarter-1)*3+1]
	var first_time := int(Time.get_unix_time_from_datetime_string(start+"T00:00:00"))
	var next_start := "%04d-%02d-01" % [year+(1 if quarter == 4 else 0),1 if quarter == 4 else quarter*3+1]
	var period := (int(Time.get_unix_time_from_datetime_string(next_start+"T00:00:00"))-first_time)/86400
	var pending: Array[Dictionary] = []
	# Validate every booking before changing any paid state.
	for booking in career.training_direction.external_schedule:
		if booking.status != "booked": continue
		var scheduled := int(booking.year)*4+int(booking.quarter)
		var current := year*4+quarter
		if scheduled > current: continue
		if scheduled < current:
			pending.append({"booking":booking,"refund":true})
			continue
		if not booking.has("executed_days"):
			if int(booking.executed_stages) != 0 or date != start: return {"errors":["旧外训阶段须先结算；按日外训必须从已知课程起点连续执行"]}
		else:
			var last := str(booking.get("last_executed_date",""))
			if last == date: continue
			var gap: Dictionary = dates.plan(last,date)
			if not gap.errors.is_empty() or gap.days.size() != 1 or int(booking.get("period_days",0)) != period: return {"errors":["外训日期必须连续，不能倒退、跳日或更改疗程日数"]}
		pending.append({"booking":booking,"refund":false})
	for action in pending:
		var booking: Dictionary = action.booking
		if action.refund:
			_refund(career,booking)
			continue
		booking.executed_days = int(booking.get("executed_days",0))+1
		booking.period_days = period
		booking.last_executed_date = date
		booking.executed_stages = mini(4,int(booking.executed_days)*4/period)
		if not career.condition_state.get("pending_decision",{}).is_empty(): _refund(career,booking)
		elif int(booking.executed_days) == period: booking.status = "completed"
	return {"errors":[]}

static func _refund(career, booking: Dictionary) -> void:
	# First three lessons use integer division; the final lesson owns remainder.
	var spent: int = (int(booking.cost)/4)*int(booking.executed_stages)
	if booking.has("executed_days"): spent = int(booking.cost)*int(booking.executed_days)/int(booking.period_days)
	if int(booking.executed_stages) == 4: spent = int(booking.cost)
	booking.refund = int(booking.cost)-spent
	booking.status = "cancelled"
	career.athlete.resources.money = minf(100.0,float(career.athlete.resources.money)+float(booking.refund))

static func _refresh_plan(career) -> void:
	var intent = preload("res://src/domain/training_intent.gd").from_dict(career.training_period_state.get("intent",{"mode":"accept","element_id":""}))
	var built: Dictionary = load("res://src/simulation/coach_training_plan_service.gd").build(career,intent)
	if not built.errors.is_empty(): return
	career.last_generated_plan = built.plan.to_dict()
	if not career.training_period_state.is_empty(): career.training_period_state.plan = built.plan.to_dict()

static func _competition_conflict(career, year: int, quarter: int) -> bool:
	if not career.competition_state.is_empty(): return true
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	for event in bundle.get("calendar",{}).get("events",[]):
		var id: String = event.get("event_id","")
		if career.season_state.get("entry_plan",{}).get("entries",{}).get(id,{}).get("status") != "confirmed": continue
		var date: String = event.get("start_date",event.get("date",""))
		if date.length() >= 7 and int(date.substr(0,4)) == year and (int(date.substr(5,2))-1)/3+1 == quarter: return true
	return false
