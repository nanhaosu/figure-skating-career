class_name SeniorGrandPrixService
extends RefCounted

const Calendar = preload("res://src/content/season_calendar_repository.gd")
const Identity = preload("res://src/domain/athlete_identity.gd")
const Codec = preload("res://src/persistence/competition_archive_codec.gd")
const Evidence = preload("res://src/simulation/international_personal_eligibility.gd")
const LABEL := "游戏派遣规则：每站最多12人、每国最多3人、每人最多2站；以赛前已有认可国际赛最好总分排序，同分比较有效世界积分，再同分按固定身份排序；按顺位分散至各站。历史邀请细则未核实。"
const LABEL_2022 := "成年大奖赛：女单最低总分 141.65。按世锦赛前六、世锦赛第七至十二、世青奖牌与赛季最好成绩或世界积分安排邀请。游戏政策：世青奖牌优先两站，普通排名首轮一站；公开成绩候补可获第二站或补充未开赛空位，原邀请不撤回。站位、同档排序及赛季最好成绩前75的补充候补池也按游戏政策。"
const MINIMUM_2022 := 141.65
const RELEASE_2022 := "2022-07-22"
const FINAL_ID := "isu_gp_final_torino_2022"
const POINTS := [15,13,11,9,7,5,4,3]

# Explicit game policy: offers for vacant future seats use only the published,
# evidenced reserve order. Existing offers and completed fields remain intact.
static func supplement_vacancies(original: Dictionary, events: Array, date: String, availability: Dictionary = {}) -> Dictionary:
	var plan: Dictionary = original.duplicate(true)
	if plan.get("policy_id") != "senior_gp2022_game_invitation": return plan
	var rows: Array = plan.get("audit",{}).get("candidate_rows",[])
	var added := {}
	for event in events:
		var event_id: String = event.event_id
		if date >= str(event.start_date) or not plan.fields.has(event_id): continue
		var field: Array = plan.fields[event_id]
		for row in rows:
			if field.size() >= 12: break
			var id: String = row.athlete_id
			if not availability.is_empty() and not availability.get(id,false): continue
			if plan.audit.get("withdrawn",{}).get(event_id,[]).has(id): continue
			if field.has(id) or plan.assignments.get(id,[]).size() >= 2: continue
			if field.filter(func(other):return rows.any(func(candidate):return candidate.athlete_id == other and candidate.federation == row.federation)).size() >= 3: continue
			field.append(id)
			if not plan.assignments.has(id): plan.assignments[id] = []
			plan.assignments[id].append(event_id)
			if not added.has(event_id): added[event_id] = []
			added[event_id].append(id)
	if not added.is_empty():
		if not plan.audit.has("initial_fields"): plan.audit.initial_fields = original.fields.duplicate(true)
		if not plan.audit.has("supplemental_offers"): plan.audit.supplemental_offers = []
		plan.audit.supplemental_offers.append({"date":date,"source_kind":"game_setting","reason":"已核对成绩的公开候补补充未开赛空位；原邀请不撤回","added":added})
	return plan

static func _active_candidates(career, plan: Dictionary) -> Dictionary:
	var available := {}
	for row in plan.get("audit",{}).get("candidate_rows",[]):
		var id: String = row.athlete_id
		available[id] = id == "player" or career.world_athletes.get(id,{}).get("status","missing") == "active"
	return available

static func supports(event: Dictionary) -> bool:
	return event.get("event_family") == "gp_stage" and int(event.get("ruleset_season_start_year",0)) in [2021,2022]

static func supports_final(event: Dictionary) -> bool:
	return event.get("event_id") == FINAL_ID and event.get("event_family") == "gp_final"

# Pure allocation. Inputs are already evidenced, age-eligible candidates.
# No player strength, domestic results or random winner preference is read.
static func allocate(rows: Array, events: Array, year: int = 2021, fixed_fields: Dictionary = {}, player_not_before: String = "") -> Dictionary:
	var ranked: Array = rows.duplicate(true)
	ranked.sort_custom(func(a,b):
		if int(a.get("tier",0)) != int(b.get("tier",0)): return int(a.get("tier",0)) < int(b.get("tier",0))
		if float(a.best_total) != float(b.best_total): return float(a.best_total) > float(b.best_total)
		if int(a.world_points) != int(b.world_points): return int(a.world_points) > int(b.world_points)
		return str(a.athlete_id) < str(b.athlete_id))
	var fields := {}; var assignments := {}; var countries := {}
	for event in events:
		fields[event.event_id] = Array(fixed_fields.get(event.event_id,[])).duplicate()
		countries[event.event_id] = {}
		for id in fields[event.event_id]:
			var matches := ranked.filter(func(row): return row.athlete_id == id)
			if not matches.is_empty():
				var federation: String = matches[0].federation
				countries[event.event_id][federation] = int(countries[event.event_id].get(federation,0))+1
			if not assignments.has(id): assignments[id] = []
			assignments[id].append(event.event_id)
	for index in ranked.size():
		if ranked[index].get("reserve_only",false): continue
		var starts := 1 if year == 2022 and int(ranked[index].get("tier",3)) >= 3 else 2
		for round_index in starts:
			var row: Dictionary = ranked[index]
			var id := str(row.athlete_id); var federation := str(row.federation)
			if not assignments.has(id): assignments[id] = []
			if assignments[id].size() >= starts: break
			if events.is_empty(): continue
			var preferred := posmod(index+round_index*maxi(1,events.size()/2),events.size())
			for offset in events.size():
				var stage: Dictionary = events[(preferred+offset)%events.size()]
				var event_id: String = stage.event_id
				if id == "player" and str(stage.get("application_deadline",stage.start_date)) < player_not_before: continue
				if fixed_fields.has(event_id) or fields[event_id].size() >= 12 or int(countries[event_id].get(federation,0)) >= 3 or assignments[id].has(event_id): continue
				fields[event_id].append(id)
				assignments[id].append(event_id)
				countries[event_id][federation] = int(countries[event_id].get(federation,0))+1
				break
	var alternates := {}
	if year == 2022:
		for event in events:
			var id: String = event.event_id
			alternates[id] = ranked.filter(func(row): return not fields[id].has(row.athlete_id)).map(func(row): return row.athlete_id)
	return {"errors":[],"policy_id":"senior_gp%d_game_invitation" % year,"fields":fields,"assignments":assignments,"audit":{"hidden_replacement":false,"candidate_rows":ranked,"station_alternates":alternates,"public_formula":LABEL if year == 2021 else LABEL_2022}}

static func preview(career, event: Dictionary) -> Dictionary:
	var year := int(event.get("ruleset_season_start_year",0))
	var label := LABEL if year == 2021 else LABEL_2022
	var events := _events(year) if supports(event) else []
	if not supports(event) or not events.any(func(e):return e.event_id == event.get("event_id") and Evidence._matches_event(event,e,"senior")):
		return {"errors":["成年大奖赛规范赛事不匹配"],"invited":false,"plan":{},"label":label}
	var saved: Dictionary = career.selection_state.get("decisions",{}).get("senior_gp_%d" % year,{})
	var plan: Dictionary = saved.get("decision",{}).duplicate(true)
	if plan.is_empty() or (year == 2022 and plan.fields.size() < events.size()):
		var cutoff := RELEASE_2022 if year == 2022 else str(events[0].start_date)
		var fixed: Dictionary = plan.get("fields",{})
		var candidates := _candidates(career,cutoff,year,events[0])
		if not fixed.is_empty():
			var frozen: Array = saved.inputs
			var ids := frozen.map(func(row): return row.athlete_id)
			candidates = frozen + candidates.filter(func(row): return not ids.has(row.athlete_id))
		var not_before := ""
		if not fixed.is_empty():
			not_before = str(career.competition_timeline.get("date",""))
			for archive in career.competition_archive:
				if not fixed.has(archive.get("event_id","")) or archive.get("status") != "complete": continue
				var completed_event: Dictionary = archive.get("event",{})
				var finish := str(completed_event.get("actual_dates",{}).get("end",completed_event.get("end_date","")))
				if finish > not_before: not_before = finish
		plan = allocate(candidates,events,year,fixed,not_before)
	if year == 2022:
		plan = supplement_vacancies(plan,events,str(career.competition_timeline.get("date",RELEASE_2022)),_active_candidates(career,plan))
	return {"errors":plan.get("errors",[]),"invited":plan.get("fields",{}).get(event.event_id,[]).has("player"),"plan":plan,"label":label}

static func commit(career,event: Dictionary) -> Dictionary:
	var result := preview(career,event)
	if not result.errors.is_empty(): return result
	var key := "senior_gp_%d" % int(event.ruleset_season_start_year)
	var previous: Dictionary = career.selection_state.get("decisions",{}).get(key,{})
	if JSON.stringify(previous.get("decision",{})) == JSON.stringify(result.plan): return result
	if not career.selection_state.has("decisions"): career.selection_state.decisions = {}
	career.selection_state.decisions[key] = {"inputs":result.plan.audit.candidate_rows.duplicate(true),"decision":result.plan.duplicate(true),"clock":previous.get("clock",career.clock.to_dict())}
	for id in result.plan.assignments:
		if not career.selection_state.assignments.has(id): career.selection_state.assignments[id] = []
		for event_id in result.plan.assignments[id]:
			if not career.selection_state.assignments[id].has(event_id): career.selection_state.assignments[id].append(event_id)
	return result

static func _events(year: int) -> Array:
	var loaded := Calendar.load_international_calendar(year,"women_singles","senior")
	if not loaded.errors.is_empty(): return []
	var result: Array = Calendar.playable_events(loaded.calendar).filter(func(e):return supports(e))
	result.sort_custom(func(a,b):return a.start_date < b.start_date)
	return result

static func circuit_needs_publication(career, bundle: Dictionary) -> Dictionary:
	if int(bundle.calendar.calendar_year) != 2022 or career.competition_timeline.get("mode") != "dated" or str(career.competition_timeline.date) < RELEASE_2022:
		return {}
	if career.season_program_plan.get("season_id") != "2022-23" or career.season_program_plan.get("status") != "confirmed":
		return {}
	var stages: Array = bundle.calendar.events.filter(func(event): return supports(event))
	if stages.is_empty(): return {}
	var decision: Dictionary = career.selection_state.get("decisions",{}).get("senior_gp_2022",{}).get("decision",{})
	if decision.get("fields",{}).size() < stages.size(): return stages[0]
	var supplemented := supplement_vacancies(decision,stages,str(career.competition_timeline.date),_active_candidates(career,decision))
	return stages[0] if JSON.stringify(supplemented) != JSON.stringify(decision) else {}

static func final_preview(career, event: Dictionary) -> Dictionary:
	var saved: Dictionary = career.selection_state.get("decisions",{}).get(FINAL_ID,{}).get("decision",{})
	if not saved.is_empty(): return saved.duplicate(true)
	var stages := _events(2022)
	var seen := {}
	var table := {}
	for archive in career.competition_archive:
		var id: String = archive.get("event_id","")
		if seen.has(id) or archive.get("status") != "complete" or not stages.any(func(stage): return stage.event_id == id): continue
		seen[id] = true
		var field_size: int = archive.get("free_results",{}).size()
		for placing in archive.get("final_standings",[]):
			var athlete: String = placing.athlete_id
			if not archive.get("free_results",{}).has(athlete): continue
			if not table.has(athlete): table[athlete] = {"athlete_id":athlete,"federation":placing.federation,"starts":[]}
			var rank := int(placing.rank)
			table[athlete].starts.append({"event_id":id,"rank":rank,"points":POINTS[rank-1] if rank >= 1 and rank <= POINTS.size() else 0,"total":placing.total_score,"free":placing.free_score,"short":placing.short_score,"field_size":field_size})
	var rows: Array = table.values()
	for row in rows:
		row.starts.sort_custom(func(a,b): return a.rank < b.rank if a.rank != b.rank else a.total > b.total)
		row.starts = row.starts.slice(0,2)
		var key := [0,-int(row.starts[0].rank),0,row.starts.size(),0,0,0,0]
		for start in row.starts:
			key[0] += int(start.points)
			key[2] += roundi(float(start.total)*100)
			key[4] += roundi(float(start.free)*100)
			key[5] = maxi(key[5],roundi(float(start.free)*100))
			key[6] += roundi(float(start.short)*100)
			key[7] += int(start.field_size)
		row.points = key[0]
		row.tie_key = key
	rows.sort_custom(func(a,b):
		for index in a.tie_key.size():
			if a.tie_key[index] != b.tie_key[index]: return a.tie_key[index] > b.tie_key[index]
		return a.athlete_id < b.athlete_id)
	var qualified: Array = []
	var alternates: Array = []
	var complete := supports_final(event) and stages.size() == 6 and seen.size() == stages.size()
	if complete:
		for index in rows.size():
			if index < 6 or rows[index].tie_key == rows[5].tie_key: qualified.append(rows[index].athlete_id)
			elif alternates.size() < 3: alternates.append(rows[index].athlete_id)
	return {"qualified_ids":qualified,"alternates":alternates,"complete":complete,"audit":{"hidden_replacement":false,"candidate_rows":rows,"public_formula":"成年大奖赛六站结束后按积分、最好名次、指定站总分和同分细则决定总决赛席位。"}}

static func commit_final(career,event: Dictionary) -> Dictionary:
	var result := final_preview(career,event)
	if result.complete and not career.selection_state.get("decisions",{}).has(FINAL_ID):
		if not career.selection_state.has("decisions"): career.selection_state.decisions = {}
		career.selection_state.decisions[FINAL_ID] = {"inputs":result.audit.candidate_rows.duplicate(true),"decision":result.duplicate(true),"clock":career.clock.to_dict()}
	return result

static func withdraw_player(career,event_id: String) -> Dictionary:
	var key := FINAL_ID if event_id == FINAL_ID else "senior_gp_2022"
	var decision: Dictionary = career.selection_state.get("decisions",{}).get(key,{}).get("decision",{})
	var field: Array = decision.get("qualified_ids",[]) if key == FINAL_ID else decision.get("fields",{}).get(event_id,[])
	if not field.has("player"): return {}
	var alternates: Array = decision.get("alternates",[]) if key == FINAL_ID else decision.audit.get("station_alternates",{}).get(event_id,[])
	var loaded := Calendar.load_international_calendar(2022,"women_singles","senior")
	var events: Array = loaded.calendar.get("events",[]).filter(func(event): return event.event_id == event_id)
	if events.size() != 1: return {}
	var now := str(career.competition_timeline.get("date",""))
	var event: Dictionary = events[0]
	field.erase("player")
	if key != FINAL_ID:
		if not decision.audit.has("withdrawn"): decision.audit.withdrawn = {}
		if not decision.audit.withdrawn.has(event_id): decision.audit.withdrawn[event_id] = []
		if not decision.audit.withdrawn[event_id].has("player"): decision.audit.withdrawn[event_id].append("player")
	var assignment: Dictionary = career.selection_state.assignments
	if assignment.has("player"): assignment.player.erase(event_id)
	if key != FINAL_ID and decision.assignments.has("player"): decision.assignments.player.erase(event_id)
	var replacement := ""
	for id in alternates:
		if now >= str(event.start_date): break
		var athlete: Dictionary = career.world_athletes.get(id,{})
		if field.has(id) or athlete.get("status","missing") != "active": continue
		if key != FINAL_ID:
			if assignment.get(id,[]).filter(func(stage):return decision.fields.has(stage)).size() >= 2: continue
			if field.filter(func(other):return career.world_athletes.get(other,{}).get("federation") == athlete.federation).size() >= 3: continue
		replacement = id
		field.append(id)
		if key != FINAL_ID:
			if not assignment.has(id): assignment[id] = []
			assignment[id].append(event_id)
			if not decision.assignments.has(id): decision.assignments[id] = []
			decision.assignments[id].append(event_id)
		break
	return {"event_id":event_id,"removed_id":"player","promoted_id":replacement,"source_kind":"game_setting"}

static func _candidates(career,cutoff: String,season_year: int,first_event: Dictionary) -> Array:
	var rows := {}; var calendars := {}
	var latest := "%04d-%02d-%02d" % [career.clock.year,career.clock.quarter*3,[31,30,30,31][career.clock.quarter-1]]
	if career.competition_timeline.mode == "dated": latest = str(career.competition_timeline.date)
	for raw in career.competition_archive:
		if not raw is Dictionary or raw.get("status") != "complete": continue
		# Reject unrelated events before validating the much larger score bodies.
		# Only a matching, validated archive can supply invitation evidence.
		var event: Dictionary = raw.get("event",{})
		var year := int(event.get("ruleset_season_start_year",0))
		if year < 2019 or year > 2021 or (season_year == 2022 and year != 2021): continue
		var level := str(event.get("competition_level","junior"))
		var canonical := Evidence._canonical_event(str(raw.get("event_id","")),year,level,calendars)
		if canonical.is_empty() or not Evidence._matches_event(event,canonical,level) or str(canonical.end_date) >= cutoff or str(canonical.end_date) > latest: continue
		if season_year == 2022 and (canonical.get("record_eligibility") != "isu_recognized" or canonical.event_family not in ["world_championships","world_junior","four_continents","europeans","gp_stage","gp_final","jgp_stage","jgp_final","challenger"]): continue
		if not Codec.validate(raw).is_empty(): continue
		var archive := Codec.expand(raw)
		var places := {}
		if season_year == 2022 and canonical.event_id in ["isu_wc2022","isu_world_junior_2022"]:
			for placing in archive.final_standings: places[placing.athlete_id] = int(placing.rank)
		for id in archive.get("short_results",{}):
			if id == "player" and archive.get("world_only",false): continue
			var short_record: Dictionary = archive.short_results[id]
			var free_record: Dictionary = archive.get("free_results",{}).get(id,{})
			if not Evidence._final_record(short_record) or free_record.is_empty() or not Evidence._final_record(free_record): continue
			var short_total = short_record.get("score",{}).get("total")
			var free_total = free_record.get("score",{}).get("total")
			if not Evidence._tes_number(short_total) or not Evidence._tes_number(free_total): continue
			var identity := _identity(career,str(id),season_year)
			if identity.is_empty(): continue
			if id == "player" and not preload("res://src/simulation/competitive_level_service.gd").permits(career,first_event): continue
			var total := float(short_total)+float(free_total)
			if not rows.has(id): rows[id] = {"athlete_id":str(id),"federation":identity.federation,"best_total":total,"world_points":0,"evidence":[]}
			rows[id].best_total = maxf(float(rows[id].best_total),total)
			rows[id].evidence.append({"event_id":canonical.event_id,"date":canonical.end_date,"total":total,"level":level})
			if season_year == 2022:
				var place := int(places.get(id,999))
				var tier := 3
				if canonical.event_id == "isu_wc2022": tier = 0 if place <= 6 else (1 if place <= 12 else 3)
				elif canonical.event_id == "isu_world_junior_2022" and place <= 3: tier = 2
				rows[id].tier = mini(int(rows[id].get("tier",3)),tier)
	# Recompute ranking from existing dated receipts only; stale totals, future
	# awards or an invented rank cannot become an invitation credential.
	for id in rows:
		var ranking: Dictionary = career.ranking_state if id == "player" else career.world_athletes[id].get("ranking_state",{})
		var history: Array = ranking.get("history",[]).filter(func(r):return str(r.get("date","")) >= "2019-07-01" and str(r.get("date","")) < cutoff and str(r.get("date","")) <= latest and Evidence._valid_date(str(r.get("date",""))))
		rows[id].world_points = preload("res://src/simulation/competition_ranking_service.gd")._total(history,season_year,false)
	if season_year == 2022:
		var roster = load("res://src/simulation/formal_roster_generator.gd")
		var bundle := preload("res://src/content/season_bundle_repository.gd").load_bundle(season_year,"women_singles","senior")
		if not bundle.errors.is_empty(): return []
		var admitted: Array[String] = roster._admitted_federations(first_event,bundle.federation_profiles)
		var rules: Dictionary = roster._programme_rules(season_year,"senior")
		for segment in ["short","free"]:
			var resolved := preload("res://src/content/season_bundle_repository.gd").rules_for_event_level(first_event,segment,"women_singles","senior")
			if not resolved.errors.is_empty(): return []
			rules.segments[segment] = resolved.rules
		var by_score: Array = rows.values()
		by_score.sort_custom(func(a,b): return a.best_total > b.best_total if a.best_total != b.best_total else a.athlete_id < b.athlete_id)
		var by_points := by_score.filter(func(row): return row.world_points > 0)
		by_points.sort_custom(func(a,b): return a.world_points > b.world_points if a.world_points != b.world_points else a.athlete_id < b.athlete_id)
		var top24 := {}
		for row in by_score.slice(0,24) + by_points.slice(0,24): top24[row.athlete_id] = true
		var top75 := {}
		for row in by_score.slice(0,75): top75[row.athlete_id] = true
		return by_score.filter(func(row):
			if row.best_total < MINIMUM_2022: return false
			row.reserve_only = row.tier >= 3 and not top24.has(row.athlete_id)
			if row.reserve_only and not top75.has(row.athlete_id): return false
			if not admitted.has(row.federation): return false
			return row.athlete_id == "player" or not roster._project_programs(career.world_athletes[row.athlete_id],"senior",season_year,rules,true).is_empty())
	return rows.values()

static func _identity(career,id: String,season_year: int) -> Dictionary:
	var athlete: Dictionary = career.athlete.to_dict() if id == "player" else career.world_athletes.get(id,{}).get("athlete",{})
	if athlete.is_empty(): return {}
	var birthday: Dictionary = athlete.get("birth_date",{})
	var record: Dictionary = career.world_athletes.get(id,{})
	if id != "player":
		if record.get("status","active") != "active": return {}
		var date := str(record.get("birth_date",""))
		if not date.is_empty():
			if not Evidence._valid_date(date): return {}
			birthday = {"year":int(date.left(4)),"month":int(date.substr(5,2)),"day":int(date.right(2))}
	if Identity.age_gate(int(athlete.get("birth_year",0)),birthday,season_year,15,1000).status != "eligible": return {}
	return {"federation":str(career.story_context.home_federation) if id == "player" else str(record.get("federation",""))}
