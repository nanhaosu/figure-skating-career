class_name CareerFactory
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const GameClock = preload("res://src/domain/game_clock.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const SaveSchema = preload("res://src/persistence/save_schema.gd")
const StoryContext = preload("res://src/domain/story_context.gd")
const RandomStreamState = preload("res://src/domain/random_stream_state.gd")
const PreCareerHistoryGenerator = preload("res://src/simulation/pre_career_history_generator.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const ClubCoachRepository = preload("res://src/content/club_coach_repository.gd")
const CoachAssignment = preload("res://src/domain/coach_assignment.gd")

const START_YEAR := 2014
const MIN_BIRTH_YEAR := 2006
const MAX_BIRTH_YEAR := 2008
const MIN_NAME_LENGTH := 1
const MAX_NAME_LENGTH := 20

static func create(display_name: String, birth_year: int, entry_path_id: String, family_profile_id: String, seed: int, catalog: Dictionary, skating_start_age: int = 4) -> Dictionary:
	var repository := ClubCoachRepository.new()
	var clubs := repository.clubs()
	var default_club_id := str(clubs[0].id) if not clubs.is_empty() else ""
	var coaches := repository.coaches_for_club(default_club_id)
	var default_coach_id := str(coaches[0].id) if not coaches.is_empty() else ""
	return _create(display_name, birth_year, entry_path_id, family_profile_id, seed, catalog, skating_start_age, default_club_id, default_coach_id, repository)

static func create_from_profile(profile: Dictionary, seed: int) -> Dictionary:
	var repository := ClubCoachRepository.new()
	var errors: Array[String] = repository.errors()
	var club_id := str(profile.get("club_id", ""))
	var coach_id := str(profile.get("coach_id", ""))
	if club_id.is_empty() or repository.club_profile(club_id).is_empty(): errors.append("请选择俱乐部")
	var coach := repository.coach_profile(coach_id)
	if coach_id.is_empty() or coach.is_empty() or str(coach.get("club_id", "")) != club_id: errors.append("请选择教练")
	if profile.has("birth_date"):
		if not profile.birth_date is Dictionary:
			errors.append("生日必须是年、月、日组成的对象")
		else:
			errors.append_array(preload("res://src/domain/athlete_identity.gd").validate_birth_date(profile.birth_date,int(profile.get("birth_year",0))))
	if not errors.is_empty(): return {"career": null, "errors": errors}
	var catalog: Dictionary = profile.get("catalog", CatalogRepository.load_catalog())
	var result := _create(
		str(profile.get("display_name", "")), int(profile.get("birth_year", 0)),
		str(profile.get("entry_path_id", "")), str(profile.get("family_profile_id", "")),
		seed, catalog, int(profile.get("skating_start_age", 4)), club_id, coach_id, repository,
	)
	if result.career != null:
		result.career.athlete.birth_date = preload("res://src/domain/athlete_identity.gd").canonical_birth_date(Dictionary(profile.get("birth_date",{})),result.career.athlete.birth_year)
	return result

static func _create(display_name: String, birth_year: int, entry_path_id: String, family_profile_id: String, seed: int, catalog: Dictionary, skating_start_age: int, club_id: String, coach_id: String, repository: ClubCoachRepository) -> Dictionary:
	var catalog_errors: Array = catalog.get("errors", [])
	if not catalog_errors.is_empty():
		return {"career": null, "errors": catalog_errors.duplicate()}
	var trimmed_name := display_name.strip_edges()
	var backgrounds: Dictionary = catalog.get("backgrounds", {})
	var entry_paths: Dictionary = backgrounds.get("entry_paths", {})
	var family_profiles: Dictionary = backgrounds.get("family_profiles", {})
	var errors: Array[String] = []
	if trimmed_name.length() < MIN_NAME_LENGTH or trimmed_name.length() > MAX_NAME_LENGTH:
		errors.append("姓名长度必须为1至20个字符")
	if birth_year < MIN_BIRTH_YEAR or birth_year > MAX_BIRTH_YEAR:
		errors.append("2014年时年龄必须为6至8岁")
	if not entry_paths.has(entry_path_id):
		errors.append("请选择有效的入门路径")
	if not family_profiles.has(family_profile_id):
		errors.append("请选择有效的家庭背景")
	if seed < 0:
		errors.append("随机种子必须为非负整数")
	if skating_start_age < 3 or skating_start_age > 6:
		errors.append("开始学滑年龄必须为3至6岁")
	if not errors.is_empty():
		return {"career": null, "errors": errors}

	var entry_path: Dictionary = entry_paths[entry_path_id]
	var family_profile: Dictionary = family_profiles[family_profile_id]
	var career := CareerState.new()
	career.schema_version = SaveSchema.CURRENT_VERSION
	career.seed = seed
	career.world_state["world_seed"] = seed
	career.story_context = StoryContext.women_singles_2014("CHN")
	career.random_streams = RandomStreamState.new(seed)
	career.clock = GameClock.new(START_YEAR, 1)
	career.athlete = AthleteState.new(trimmed_name, birth_year, entry_path_id, family_profile_id)
	career.athlete.skating.deep_edge = clampf(career.athlete.skating.deep_edge + float(entry_path.technique_delta), 0.0, 100.0)
	career.athlete.resources.money = clampf(float(family_profile.economic_capacity), 0.0, 100.0)
	career.athlete.resources.ice_access = clampf(career.athlete.resources.ice_access + float(entry_path.resource_delta), 0.0, 100.0)
	var coach_profile := repository.coach_profile(coach_id)
	var coach_defaults: Dictionary = coach_profile.get("relationship_defaults", {})
	var coach_relationship := RelationshipState.from_dict(coach_defaults)
	career.relationships = {
		"guardian": RelationshipState.new(
			float(family_profile.emotional_support),
			float(family_profile.industry_knowledge),
			float(family_profile.control),
			float(family_profile.health_priority),
		),
		"coach": coach_relationship,
	}
	career.coach_assignment = CoachAssignment.new(
		club_id, coach_id, coach_relationship,
		Array(coach_profile.get("known_strengths", [])),
		Array(coach_profile.get("known_concerns", [])),
		Dictionary(coach_profile.get("technical_tendencies", {})),
	)
	career.social_state["club_id"] = club_id
	var generated := PreCareerHistoryGenerator.generate(
		career.athlete,
		career.relationships,
		career.condition_state,
		birth_year,
		skating_start_age,
		entry_path_id,
		family_profile_id,
		seed,
		entry_path,
		family_profile,
		career.coach_assignment.technical_tendencies,
	)
	if not generated.errors.is_empty():
		return {"career": null, "errors": generated.errors.duplicate()}
	career.athlete = generated.athlete
	career.relationships = generated.relationships
	career.coach_assignment.relationship = career.relationships.coach
	career.condition_state = generated.condition_state
	career.pre_career_history = generated.history
	return {"career": career, "errors": errors}
