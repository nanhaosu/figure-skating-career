class_name BeijingTrialService
extends RefCounted

const DATES = preload("res://src/domain/beijing_trial_series.gd").DATES
const SERIES_ID := "beijing2022_women_trials"
const RULE_LABEL := "游戏补充规则：五场至少完成四场，取最好四场总分。同分比较这四场TES，再比较这四场自由滑，仍同分使用存档固定抽签；舍弃场总分相同时，优先计入TES、自由滑较高的一场。五个日期为游戏结算日。"

static func event_ids() -> Array[String]:
	return preload("res://src/domain/beijing_trial_series.gd").event_ids()

static func admission(career) -> Dictionary:
	var reasons: Array[String] = []
	if str(career.story_context.home_federation) != "CHN": reasons.append("北京中国女单选拔仅向中国选手开放")
	var age: Dictionary = preload("res://src/domain/athlete_identity.gd").age_gate(career.athlete.birth_year,career.athlete.birth_date,2021,15,999)
	if age.status != "eligible": reasons.append("须满足2021赛季成年年龄；边界生日未知时先补充资料")
	if int(career.certification_state.get("national_technical_grade",0)) < 7: reasons.append("游戏报名要求国内技术等级7级")
	var event := {"event_id":event_ids()[0],"ruleset_season_start_year":2021,"competition_level":"senior"}
	var resolved: Dictionary = preload("res://src/content/season_bundle_repository.gd").competition_event(event)
	if not resolved.errors.is_empty(): reasons.append_array(resolved.errors)
	else:
		var programs: Dictionary = preload("res://src/simulation/season_program_service.gd").programs_for_event(career,resolved.event)
		for segment in ["short","free"]:
			var program = preload("res://src/domain/skating_program.gd").from_dict(programs.get(segment,{}))
			if program == null or not preload("res://src/simulation/program_validator.gd").validate(program,career.athlete,resolved.rules[segment].segment_rules).is_empty(): reasons.append("须有合法的成年组"+("短节目" if segment == "short" else "自由滑"))
	return {"eligible":reasons.is_empty(),"reasons":reasons,"label":"游戏开放报名：年龄、国内7级及成年节目合格即可；不要求国内全勤、既往名次或奥运国际TES。奥运资格与派遣另行判定。"}

static func enroll(career,series_id: String,receipt_id: String) -> Dictionary:
	if series_id != SERIES_ID or receipt_id.is_empty() or receipt_id.length() > 160: return {"ok":false,"error":"选拔系列或确认编号无效"}
	var state: Dictionary = career.beijing_trial_series
	if state.enrollment_receipts.has(receipt_id): return {"ok":state.enrollment_receipts[receipt_id].get("choice") == "enrolled","events":[]}
	if state.player_choice == "enrolled": return {"ok":true,"events":[]}
	if state.status == "finalized": return {"ok":false,"error":"本系列已结算，不能重新报名"}
	var today := str(career.competition_timeline.date) if career.competition_timeline.mode == "dated" else "%04d-%02d-01" % [career.clock.year,(career.clock.quarter-1)*3+1]
	if today < "2021-07-01" or today >= "2021-12-18": return {"ok":false,"error":"请在2021赛季首场选拔开始前报名；不会补办错过的场次"}
	var gate := admission(career)
	if not gate.eligible: return {"ok":false,"error":"；".join(gate.reasons)}
	var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(career)
	if not bundle.errors.is_empty(): return {"ok":false,"error":str(bundle.errors)}
	var planner = load("res://src/simulation/season_calendar_planner.gd")
	var proposed: Dictionary = planner.propose(career,bundle.calendar,bundle.rules) if career.season_state.entry_plan.is_empty() else planner.refresh_eligibility(career,bundle.calendar,bundle.rules,career.season_state.entry_plan)
	if not proposed.errors.is_empty(): return {"ok":false,"error":str(proposed.errors)}
	var entries: Dictionary = proposed.plan.to_dict()
	for id in event_ids():
		if not entries.entries.has(id): return {"ok":false,"error":"选拔五场赛历不完整"}
		entries.entries[id].status = "confirmed"
		entries.entries[id].requested_levels = ["senior"]
		entries.entries[id].player_override = "enter"
	var prepared := prepare(career,bundle)
	if not prepared.ok: return prepared
	career.season_state.entry_plan = entries
	career.season_state.season_id = str(bundle.calendar.season_id)
	career.season_state.qualification_state = planner.qualification_state_for(career)
	for id in event_ids(): career.season_state.event_statuses[id] = "confirmed"
	state.status = "collecting"; state.player_choice = "enrolled"
	if not state.entrant_ids.has("player"): state.entrant_ids.append("player")
	state.lottery_seed = preload("res://src/simulation/world_generation_service.gd").stable_seed("beijing-trials:"+str(career.seed))
	state.enrollment_receipts[receipt_id] = {"choice":"enrolled","date":today,"admission":gate}
	var event := {"kind":"beijing_trial_enrolled","series_id":SERIES_ID,"date":today,"clock":career.clock.to_dict(),"rule_label":gate.label}
	career.event_ledger.append(event)
	return {"ok":true,"events":[event]}

static func prepare(career,bundle: Dictionary) -> Dictionary:
	var state: Dictionary = career.beijing_trial_series
	if state.status != "unexamined": return {"ok":true,"events":[]}
	var world: Dictionary = preload("res://src/simulation/world_generation_service.gd").ensure_season(career,bundle,int(career.world_state.get("world_seed",career.seed)))
	if not world.errors.is_empty(): return {"ok":false,"error":str(world.errors)}
	var roster_api = load("res://src/simulation/formal_roster_generator.gd")
	var federations: Array[String] = ["CHN"]
	var pool: Array = roster_api._eligible_persistent_pool(career.world_athletes,federations,2021,"senior")
	for record in pool:
		# NPCs sit the same game-readiness review automatically; absence of an
		# old NPC grade is never silently rewritten as a historical certificate.
		var proxy = preload("res://src/domain/career_state.gd").new()
		proxy.clock = preload("res://src/domain/game_clock.gd").new(2021,4)
		proxy.athlete = preload("res://src/domain/athlete_state.gd").from_dict(record.athlete)
		var saved: Dictionary = career.world_athletes[record.athlete_id]
		proxy.active_programs = {"short":saved.short_program.duplicate(true),"free":saved.free_program.duplicate(true)}
		var assessment: Dictionary = preload("res://src/persistence/numeric_state.gd").canonical_copy(preload("res://src/simulation/certification_service.gd").assess(proxy))
		if assessment.status != "ready": continue
		state.entrant_ids.append(record.athlete_id)
		state.enrollment_receipts["npc-review:"+str(record.athlete_id)] = {"choice":"enrolled","athlete_id":record.athlete_id,"domestic_grade":7,"basis":"game_readiness_review","assessment":assessment}
	state.entrant_ids.sort()
	state.status = "collecting"
	state.lottery_seed = preload("res://src/simulation/world_generation_service.gd").stable_seed("beijing-trials:"+str(career.seed))
	return {"ok":true,"events":[]}

static func decline(career,receipt_id: String) -> Dictionary:
	if receipt_id.is_empty() or receipt_id.length() > 160: return {"ok":false,"error":"选拔确认编号无效"}
	var state: Dictionary = career.beijing_trial_series
	if state.enrollment_receipts.has(receipt_id): return {"ok":state.enrollment_receipts[receipt_id].get("choice") == "declined","events":[]}
	if state.player_choice == "enrolled": return {"ok":false,"error":"已报名后请按场次明确退赛，不改写整个系列"}
	if state.player_choice == "declined": return {"ok":true,"events":[]}
	var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(career)
	if not bundle.errors.is_empty() or bundle.calendar.season_id != "2021-22": return {"ok":false,"error":"当前不在北京选拔赛季"}
	var planner = load("res://src/simulation/season_calendar_planner.gd")
	var proposal: Dictionary = planner.propose(career,bundle.calendar,bundle.rules) if career.season_state.entry_plan.is_empty() else planner.refresh_eligibility(career,bundle.calendar,bundle.rules,career.season_state.entry_plan)
	if not proposal.errors.is_empty(): return {"ok":false,"error":str(proposal.errors)}
	var prepared := prepare(career,bundle)
	if not prepared.ok: return prepared
	var entries: Dictionary = proposal.plan.to_dict()
	for id in event_ids():
		entries.entries[id].status = "declined"
		entries.entries[id].player_override = "skip"
		career.season_state.event_statuses[id] = "declined"
	career.season_state.entry_plan = entries
	state.player_choice = "declined"
	state.enrollment_receipts[receipt_id] = {"choice":"declined","clock":career.clock.to_dict()}
	var event := {"kind":"beijing_trial_declined","series_id":SERIES_ID,"clock":career.clock.to_dict(),"reason":"本季不报名选拔系列，其他选手照常比赛；空档继续训练"}
	career.event_ledger.append(event)
	return {"ok":true,"events":[event]}

static func settle_sources(career,date: String) -> Dictionary:
	var table := standings(career,date)
	if not table.errors.is_empty(): return {"ok":false,"error":"；".join(table.errors)}
	var receipts: Dictionary = career.beijing_trial_series.event_receipts.duplicate(true)
	for id in table.sources:
		if receipts.has(id) and receipts[id].fingerprint != table.sources[id].fingerprint: return {"ok":false,"error":"选拔正式成绩来源已改变，须明确更正，不能静默覆盖"}
		receipts[id] = table.sources[id].duplicate(true)
	career.beijing_trial_series.event_receipts = receipts
	return {"ok":true,"events":[]}

static func standings(career,as_of_date: String) -> Dictionary:
	var dates = preload("res://src/simulation/dated_training_window.gd")
	if not dates.plan(as_of_date,as_of_date).errors.is_empty(): return {"errors":["选拔查询日期无效"],"rows":[]}
	var latest := str(career.competition_timeline.date) if career.competition_timeline.mode == "dated" else "%04d-%02d-%02d" % [career.clock.year,career.clock.quarter*3,[31,30,30,31][career.clock.quarter-1]]
	if as_of_date > latest: return {"errors":["不能读取未来选拔成绩"],"rows":[]}
	var rows: Array = []; var seen := {}; var sources := {}
	var ids := event_ids()
	for archive in career.competition_archive:
		var id := str(archive.get("event_id",""))
		if not ids.has(id) or archive.get("status") != "complete": continue
		var index := ids.find(id)
		if DATES[index] > as_of_date: continue
		if archive.get("season_id") != "2021-22" or archive.get("event",{}).get("event_family") != "beijing_trial": return {"errors":["选拔档案赛季或赛事身份不符"],"rows":[]}
		var error := preload("res://src/persistence/competition_archive_codec.gd").validate(archive,true)
		if not error.is_empty(): return {"errors":[error],"rows":[]}
		var canonical: Dictionary = preload("res://src/content/season_bundle_repository.gd").competition_event(archive.event)
		if not canonical.errors.is_empty() or canonical.event.start_date != DATES[index]: return {"errors":["选拔档案不能与规范赛期核对"],"rows":[]}
		# Use the same canonical lossless payload before and after the normal
		# persistence compaction; presentation aliases must not change provenance.
		var codec = preload("res://src/persistence/competition_archive_codec.gd")
		var source: Dictionary = codec.compact(codec.canonical_copy(archive))
		var fingerprint := str(source.get("packed_archive",{}).get("sha256",JSON.stringify(source).sha256_text()))
		if seen.has(id):
			if seen[id] != fingerprint: return {"errors":["同场选拔档案存在冲突，须明确更正"],"rows":[]}
			continue
		seen[id] = fingerprint; sources[id] = {"fingerprint":fingerprint,"revision":1}
		for row in archive.get("final_standings",[]):
			var athlete_id := str(row.get("athlete_id",""))
			if not career.beijing_trial_series.entrant_ids.has(athlete_id): return {"errors":["选拔成绩包含未报名选手"],"rows":[]}
			var short: Dictionary = archive.get("short_results",{}).get(athlete_id,{})
			var free: Dictionary = archive.get("free_results",{}).get(athlete_id,{})
			if short.is_empty() or free.is_empty(): continue # DNS/SP-only is not a completed start.
			var sp: Dictionary = short.get("score",short.get("protocol",{}))
			var fs: Dictionary = free.get("score",free.get("protocol",{}))
			for value in [sp.get("total"),sp.get("tes"),fs.get("total"),fs.get("tes"),row.get("total_score")]:
				if not _score(value): return {"errors":["选拔两段正式分数无效"],"rows":[]}
			var total := snappedf(float(sp.total)+float(fs.total),0.01)
			if int(round(total*100)) != int(round(float(row.total_score)*100)): return {"errors":["选拔总分与实际两段不一致"],"rows":[]}
			rows.append({"athlete_id":athlete_id,"event_id":id,"complete":true,"total_score":total,"tes":snappedf(float(sp.tes)+float(fs.tes),0.01),"free_score":float(fs.total)})
	var result := aggregate(rows,int(career.beijing_trial_series.lottery_seed))
	result.sources = sources; result.as_of_date = as_of_date
	return result

# Integer hundredths avoid floating-point ties changing after JSON reload.
static func aggregate(performances: Array,lottery_seed: int) -> Dictionary:
	var grouped := {}; var receipts := {}; var allowed := event_ids()
	for performance in performances:
		if not performance is Dictionary or not performance.get("athlete_id") is String or str(performance.get("athlete_id","")).is_empty() or not allowed.has(performance.get("event_id")) or performance.get("complete") != true:
			return {"errors":["选拔汇总只能使用本系列完整比赛"],"rows":[]}
		for field in ["total_score","tes","free_score"]:
			if not _score(performance.get(field)): return {"errors":["选拔成绩必须为合法的两位小数分数"],"rows":[]}
		var row := {"athlete_id":str(performance.athlete_id),"event_id":str(performance.event_id),"total_cents":int(round(float(performance.total_score)*100)),"tes_cents":int(round(float(performance.tes)*100)),"free_cents":int(round(float(performance.free_score)*100))}
		var receipt: String = str(row.athlete_id)+":"+str(row.event_id)
		if receipts.has(receipt):
			if receipts[receipt] != row: return {"errors":["同场成绩来源已改变，需显式更正后重新结算"],"rows":[]}
			continue
		receipts[receipt] = row.duplicate(true)
		if not grouped.has(row.athlete_id): grouped[row.athlete_id] = []
		grouped[row.athlete_id].append(row)
	var standings: Array = []
	for id in grouped:
		var starts: Array = grouped[id]
		starts.sort_custom(func(a,b):
			if a.total_cents != b.total_cents: return a.total_cents > b.total_cents
			if a.tes_cents != b.tes_cents: return a.tes_cents > b.tes_cents
			if a.free_cents != b.free_cents: return a.free_cents > b.free_cents
			return a.event_id < b.event_id)
		var counted: Array = []; var discarded: Array = []
		var total := 0; var tes := 0; var free := 0
		for index in starts.size():
			if index >= 4:
				discarded.append(starts[index].event_id)
				continue
			counted.append(starts[index].event_id)
			total += int(starts[index].total_cents)
			tes += int(starts[index].tes_cents)
			free += int(starts[index].free_cents)
		standings.append({"athlete_id":str(id),"completed":starts.size(),"eligible":starts.size()>=4,"counted_event_ids":counted,"discarded_event_ids":discarded,"total":total/100.0,"tes":tes/100.0,"free_score":free/100.0,"lottery_key":preload("res://src/simulation/world_generation_service.gd").stable_seed("%d:beijing2022:%s"%[lottery_seed,id])})
	standings.sort_custom(func(a,b):
		if a.total != b.total: return a.total > b.total
		if a.tes != b.tes: return a.tes > b.tes
		if a.free_score != b.free_score: return a.free_score > b.free_score
		if a.lottery_key != b.lottery_key: return a.lottery_key < b.lottery_key
		return a.athlete_id < b.athlete_id)
	for index in standings.size(): standings[index].rank = index+1
	return {"errors":[],"series_id":SERIES_ID,"rows":standings,"provisional":true,"lottery_seed":lottery_seed,"rule_label":RULE_LABEL}

static func _score(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0.0 and absf(float(value)*100-round(float(value)*100)) < 0.00001

static func preview_dispatch(career,date: String) -> Dictionary:
	var table := standings(career,date)
	if not table.errors.is_empty(): return {"ok":false,"error":"；".join(table.errors),"status":"pending","selected_ids":[]}
	var pending := {"ok":true,"status":"pending","selected_ids":[],"alternate_ids":[],"reason_codes":[],"table":table}
	if date < "2022-01-15" or table.sources.size() != 5:
		pending.reason_codes = ["five_trial_sources_not_complete"];return pending
	# Keep the already adopted international TES deadline available after the
	# last trial; do not reject a skater before the final evidence window closes.
	if date < "2022-01-24": pending.reason_codes = ["personal_evidence_window_open"];return pending
	var quota: Dictionary = career.olympic_quota_state
	var error := preload("res://src/domain/olympic_quota_state.gd").validate(quota)
	if not error.is_empty(): return {"ok":false,"status":"pending","selected_ids":[],"error":error}
	if quota.status == "unknown": pending.reason_codes = ["country_quota_unknown"];return pending
	var current: Dictionary = quota.current
	if quota.status == "worlds_complete" and bool(current.get("details",{}).get("CHN",{}).get("additional_eligible",true)):
		pending.reason_codes = ["country_qualifier_not_settled"];return pending
	var places := int(current.get("countries",{}).get("CHN",0))
	if places == 0: places = int(current.get("host_additional",{}).get("CHN",{}).get("places",0))
	var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").load_bundle(2021,"women_singles","senior")
	if not bundle.errors.is_empty(): return {"ok":false,"status":"pending","selected_ids":[],"error":str(bundle.errors)}
	var event: Dictionary = bundle.calendar.events.filter(func(e):return e.event_id == "isu_owg2022")[0]
	var personal_service = preload("res://src/simulation/international_personal_eligibility.gd")
	var policy: Dictionary = personal_service.policy_for(event)
	var rows: Array = []
	var qualified_batch: Dictionary = personal_service.evaluate_many(career,event,policy,table.rows.map(func(row):return str(row.athlete_id)))
	for standing in table.rows:
		var row: Dictionary = standing.duplicate(true)
		var id := str(row.athlete_id)
		var personal: Dictionary = qualified_batch[id]
		row.personal_status = str(personal.status)
		row.personal_evidence = personal
		row.reason_codes = personal.reason_codes.duplicate()
		row.medically_available = true
		if id == "player":
			row.medically_available = career.condition_state.pending_decision.is_empty() and preload("res://src/simulation/athlete_condition_service.gd").can_compete(career)
			if not preload("res://src/simulation/competitive_level_service.gd").permits(career,event):
				row.personal_status = "ineligible";row.reason_codes.append("senior_path_not_chosen")
			if career.selection_state.applications.has("isu_owg2022:skip") or career.season_state.get("entry_plan",{}).get("entries",{}).get("isu_owg2022",{}).get("status") == "declined":
				row.personal_status = "ineligible";row.reason_codes.append("explicit_olympic_decline")
		else: row.medically_available = career.world_athletes.get(id,{}).get("status","active") == "active"
		rows.append(row)
	var decision := allocate_dispatch(rows,places)
	if not decision.errors.is_empty(): return {"ok":false,"status":"pending","selected_ids":[],"error":"；".join(decision.errors)}
	decision.ok = true;decision.places = places;decision.decided_on = date
	decision.sources = table.sources.duplicate(true)
	decision.country_source = {"status":quota.status,"receipts":quota.receipts.duplicate(true),"host_additional":current.get("host_additional",{}).duplicate(true)}
	decision.rule_label = RULE_LABEL+" 派遣另核对成年国际TES23/40、年龄和身体；国际TES采用2395、最终修订未核实。"
	return decision

static func withdraw_player_dispatch(career) -> Dictionary:
	var original: Dictionary = career.beijing_trial_series.finalization
	var current: Dictionary = career.olympic_quota_state.dispatch.duplicate(true)
	if career.beijing_trial_series.status != "finalized" or current.get("status") != "confirmed" or not current.get("selected_ids",[]).has("player"): return {"ok":true,"events":[]}
	current.selected_ids.erase("player")
	var date := str(career.competition_timeline.date) if career.competition_timeline.mode == "dated" else "%04d-%02d-01" % [career.clock.year,(career.clock.quarter-1)*3+1]
	var event: Dictionary = preload("res://src/content/season_bundle_repository.gd").competition_event({"event_id":"isu_owg2022","ruleset_season_start_year":2021,"competition_level":"senior"}).event
	var personal = preload("res://src/simulation/international_personal_eligibility.gd")
	var promoted := "";var rejected: Array = []
	# Public game substitution: only before the event, in the published
	# alternate order, with the original TES deadline still strictly applied.
	if date < str(event.start_date):
		for id in current.get("alternate_ids",[]):
			var qualified: Dictionary = personal.evaluate(career,event,personal.policy_for(event),str(id))
			if career.world_athletes.get(id,{}).get("status","active") != "active" or not qualified.eligible:
				rejected.append({"athlete_id":id,"reason_codes":qualified.reason_codes.duplicate()});continue
			promoted = str(id);break
	if not promoted.is_empty():
		current.selected_ids.append(promoted)
		current.alternate_ids.erase(promoted)
		if not career.selection_state.assignments.has(promoted): career.selection_state.assignments[promoted] = []
		if not career.selection_state.assignments[promoted].has("isu_owg2022"): career.selection_state.assignments[promoted].append("isu_owg2022")
	if career.selection_state.assignments.has("player"): career.selection_state.assignments.player.erase("isu_owg2022")
	var receipt := {"kind":"beijing_dispatch_replacement","date":date,"removed_id":"player","promoted_id":promoted,"original_decided_on":original.get("decided_on",""),"rejected_alternates":rejected,"rule_label":"游戏公开递补：赛前明确退赛后，按已公布候补顺序重新核对原截止日前个人资格；不改写五场成绩和原始派遣，无合格候补则保留空缺。"}
	if not current.has("replacement_receipts"): current.replacement_receipts = []
	current.replacement_receipts.append(receipt.duplicate(true))
	career.olympic_quota_state.dispatch = current
	career.event_ledger.append(receipt)
	return {"ok":true,"events":[receipt]}

static func finalize(career,date: String) -> Dictionary:
	if career.beijing_trial_series.status == "finalized":
		return career.beijing_trial_series.finalization.duplicate(true).merged({"ok":true})
	var decision := preview_dispatch(career,date)
	if not decision.ok or decision.status != "confirmed": return decision
	for id in decision.sources:
		var prior: Dictionary = career.beijing_trial_series.event_receipts.get(id,{})
		if not prior.is_empty() and prior.fingerprint != decision.sources[id].fingerprint: return {"ok":false,"status":"pending","selected_ids":[],"error":"选拔档案已改变，须明确更正后重新结算"}
	var state: Dictionary = career.beijing_trial_series.duplicate(true)
	state.event_receipts = decision.sources.duplicate(true)
	state.finalization = decision.duplicate(true)
	state.status = "finalized"
	# Freeze auditable numeric containers at the same JSON boundary as disk.
	state = preload("res://src/domain/beijing_trial_series.gd").normalize(JSON.parse_string(JSON.stringify(preload("res://src/persistence/numeric_state.gd").canonical_copy(state))))
	var invalid := preload("res://src/domain/beijing_trial_series.gd").validate(state)
	if not invalid.is_empty(): return {"ok":false,"status":"pending","selected_ids":[],"error":invalid}
	var candidate = career.transaction_copy()
	candidate.beijing_trial_series = state
	candidate.olympic_quota_state.dispatch = state.finalization.duplicate(true)
	for id in decision.selected_ids:
		if not candidate.selection_state.assignments.has(id): candidate.selection_state.assignments[id] = []
		if not candidate.selection_state.assignments[id].has("isu_owg2022"): candidate.selection_state.assignments[id].append("isu_owg2022")
	if decision.selected_ids.has("player"):
		var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(candidate)
		if not bundle.errors.is_empty(): return {"ok":false,"status":"pending","selected_ids":[],"error":str(bundle.errors)}
		var entry_model = preload("res://src/domain/season_entry_plan.gd")
		var previous = entry_model.from_dict(candidate.season_state.entry_plan)
		if previous == null or previous.season_id != "2021-22" or not previous.entries.has("isu_owg2022"): return {"ok":false,"status":"pending","selected_ids":[],"error":"已派遣选手的奥运报名赛历不可核对"}
		var olympic: Array = bundle.calendar.events.filter(func(e):return e.event_id == "isu_owg2022")
		if olympic.size() != 1: return {"ok":false,"status":"pending","selected_ids":[],"error":"奥运规范赛期缺失"}
		var gate: Dictionary = load("res://src/simulation/entry_application_service.gd").current_eligibility(candidate,olympic[0],bundle)
		if not gate.eligible: return {"ok":false,"status":"pending","selected_ids":[],"error":"奥运报名核验未通过："+"；".join(gate.explanations)}
		# Dispatch authorizes this one event, not a full-season invitation and
		# selection recomputation. Preserve every unrelated accepted snapshot.
		var entries: Dictionary = previous.entries.duplicate(true)
		var entry: Dictionary = entries.isu_owg2022
		entry.status = "confirmed";entry.requested_levels = ["senior"]
		entry.eligibility_snapshot = gate
		entry.reason_codes = ["automatic_beijing_trial_dispatch"]
		entry.player_override = "enter"
		if not entry.available_adjustment_ids.has("enter"): entry.available_adjustment_ids.append("enter")
		var proposal: Dictionary = entry_model.create(previous.season_id,entries,previous.proposal_version+1)
		if not proposal.errors.is_empty(): return {"ok":false,"status":"pending","selected_ids":[],"error":"；".join(proposal.errors)}
		candidate.season_state.entry_plan = proposal.plan.to_dict()
		candidate.season_state.event_statuses.isu_owg2022 = "confirmed"
		candidate.selection_state.applications["isu_owg2022:enter"] = {"event_id":"isu_owg2022","route_id":"enter","clock":candidate.clock.to_dict(),"option_snapshot":{"id":"enter","available":true,"costs":{"money":0.0,"fatigue":0.0}},"reason_codes":["automatic_beijing_trial_dispatch"]}
	career.beijing_trial_series = candidate.beijing_trial_series
	career.olympic_quota_state = candidate.olympic_quota_state
	career.selection_state = candidate.selection_state
	career.season_state = candidate.season_state
	career.event_ledger.append({"kind":"beijing_trial_dispatch","date":date,"clock":career.clock.to_dict(),"selected_ids":decision.selected_ids.duplicate(),"alternate_ids":decision.alternate_ids.duplicate(),"places":decision.places})
	return state.finalization.duplicate(true).merged({"ok":true})

# Pure allocation after archive-backed rank, individual eligibility and actual
# country places have been independently established by the caller below.
static func allocate_dispatch(rows: Array,places: int) -> Dictionary:
	var result := {"errors":[],"status":"confirmed","selected_ids":[],"alternate_ids":[],"pending_ids":[],"audit":[]}
	if places < 0 or places > 3: result.errors.append("国家名额须为0至3席");return result
	var ids := {}; var ranks := {}; var ordered: Array = rows.duplicate(true)
	for row in ordered:
		if not row is Dictionary or not row.get("athlete_id") is String or str(row.athlete_id).is_empty() or ids.has(row.athlete_id) or not row.get("rank") is int or row.rank < 1 or ranks.has(row.rank) or not row.get("completed") is int or row.completed < 0 or row.completed > 5 or row.get("personal_status") not in ["eligible","ineligible","unknown"] or not row.get("medically_available") is bool or not row.get("reason_codes") is Array:
			result.errors.append("派遣输入缺少可核对的排名、完赛、个人资格或身体状态");return result
		ids[row.athlete_id] = true;ranks[row.rank] = true
	ordered.sort_custom(func(a,b):return a.rank < b.rank)
	for row in ordered:
		if row.completed < 4: row.reason_codes.append("fewer_than_four_complete_trials")
		if not row.medically_available: row.reason_codes.append("medical_unavailable")
		if row.personal_status == "ineligible": row.reason_codes.append("personal_requirements_not_met")
		if row.completed >= 4 and row.medically_available and row.personal_status == "unknown": result.pending_ids.append(row.athlete_id)
		row.dispatch_eligible = row.completed >= 4 and row.medically_available and row.personal_status == "eligible"
		result.audit.append(row)
	if not result.pending_ids.is_empty(): result.status = "pending";return result
	for row in result.audit:
		if not row.dispatch_eligible: continue
		if result.selected_ids.size() < places: result.selected_ids.append(row.athlete_id)
		else: result.alternate_ids.append(row.athlete_id)
	return result
