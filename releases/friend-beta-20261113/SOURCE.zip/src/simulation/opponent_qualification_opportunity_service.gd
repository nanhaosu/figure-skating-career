class_name OpponentQualificationOpportunityService
extends RefCounted

const Personal = preload("res://src/simulation/international_personal_eligibility.gd")
const Seeds = preload("res://src/simulation/world_generation_service.gd")

# Forward game policy, not historical entry reconstruction. The caller already
# checked age, legal programmes and persisted identity. Ordinary opportunities
# favour each association's prepared aspirants, with a bounded qualification
# deficit bonus. This grants a start, never a TES, invitation or championship seat.
static func supports(event: Dictionary) -> bool:
	return int(event.get("ruleset_season_start_year",0)) >= 2023 and event.get("scope") == "international" and event.get("event_family") in ["international_open","challenger"] and event.get("record_eligibility") == "isu_recognized" and event.get("level_options",[]).has("senior")

static func order(career, event: Dictionary, candidates: Array[Dictionary]) -> Array[Dictionary]:
	if not supports(event): return candidates
	var year := int(event.ruleset_season_start_year)
	var target_id := "isu_wc2024" if year == 2023 else "isu_wc2025"
	var loaded := preload("res://src/content/season_calendar_repository.gd").load_international_calendar(year,"women_singles","senior")
	var target: Dictionary = {}
	for candidate in loaded.get("calendar",{}).get("events",[]):
		if candidate.get("event_id") == target_id: target = candidate
	var policy := Personal.policy_for(target)
	# Later seasons without an implemented Worlds policy use readiness alone.
	if year > 2024: policy = {}
	var personal := {} if policy.is_empty() else Personal.evaluate_many(career,target,policy,candidates.map(func(r):return r.athlete_id))
	return rank(candidates,personal,int(career.world_state.get("world_seed",career.seed)),str(event.event_id))

static func rank(candidates: Array[Dictionary], personal: Dictionary, world_seed: int, event_id: String) -> Array[Dictionary]:
	var result: Array[Dictionary] = candidates.duplicate()
	var priorities := {}; var ties := {}
	for record in result:
		var id := str(record.athlete_id)
		var body: Dictionary = record.get("athlete",{}).get("body",{})
		var fatigue := maxf(float(body.get("acute_fatigue",0)),float(body.get("cumulative_fatigue",0)))
		var readiness := _mean(record.get("athlete",{}).get("technique",{}))
		var triples := 0.0; var count := 0
		for jump in record.get("athlete",{}).get("jumps",{}).values():
			triples += float(jump.get("proficiency",{}).get("triple",0)) if int(jump.get("unlocked_rotations",0)) >= 3 else 0.0
			count += 1
		if count > 0: readiness = (readiness + triples/count)/2.0
		var familiarity := (float(record.get("short_program",{}).get("whole_run_familiarity",0)) + float(record.get("free_program",{}).get("whole_run_familiarity",0)))/2.0
		readiness += familiarity*0.1
		var qualification: Dictionary = personal.get(id,{})
		var deficit := 5.0 if not qualification.is_empty() and not qualification.get("eligible",false) else 0.0
		var observed := float(qualification.get("tes",{}).get("combined",0))
		# Actual valid TES is supporting evidence of readiness, never a substitute
		# for the next simulated performance. Recovery outranks score hunting.
		priorities[id] = readiness + minf(10.0,observed/10.0) + deficit - fatigue*0.35
		ties[id] = Seeds.stable_seed("%d:%s:%s" % [world_seed,event_id,id])
	result.sort_custom(func(a,b):
		var aid := str(a.athlete_id); var bid := str(b.athlete_id)
		if priorities[aid] != priorities[bid]: return priorities[aid] > priorities[bid]
		return ties[aid] < ties[bid] if ties[aid] != ties[bid] else aid < bid)
	return result

static func _mean(values: Dictionary) -> float:
	var total := 0.0
	for value in values.values(): total += float(value)
	return total/maxi(1,values.size())
