class_name MilestoneAdvanceService
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const AuthorityResolver = preload("res://src/simulation/authority_resolver.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const EventEngine = preload("res://src/simulation/event_engine.gd")
const InternalInvitationService = preload("res://src/simulation/internal_invitation_service.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")
const KeyNodeService = preload("res://src/simulation/key_node_service.gd")

static func advance(career, current_plan, catalog: Dictionary, persist: Callable, max_quarters: int = 16) -> Dictionary:
	var quarters: Array[Dictionary] = []
	if career == null or current_plan == null or not persist.is_valid(): return _result(quarters, "invalid_request")
	for index in clampi(max_quarters, 1, 16):
		if not preload("res://src/simulation/athlete_condition_service.gd").can_train(career, current_plan): return _result(quarters, "medical_restriction")
		if not KeyNodeService.pending(career).is_empty(): return _result(quarters, "key_node")
		if career.clock.year >= 2018: return _result(quarters, "2018_transition")
		if not career.competition_state.is_empty(): return _result(quarters, "competition_in_progress")
		# Readiness evaluation creates the deterministic early peer pool and offer
		# schedule. Probe a copy so a mere gate check cannot mutate the live career
		# before a quarter is successfully persisted.
		if InternalInvitationService.status(CareerState.from_dict(career.to_dict())).ready: return _result(quarters, "competition_invitation")
		var preview_career = CareerState.from_dict(career.to_dict())
		var proposal = AuthorityResolver.preview(preview_career, TrainingPlan.from_dict(current_plan.to_dict()))
		if proposal.status != "resolved": return _result(quarters, "authority_conflict")
		var event_rng := RandomNumberGenerator.new()
		event_rng.seed = preview_career.seed + preview_career.rng_step * CareerSimulator.RNG_STEP_OFFSET + 17
		if not EventEngine.generate(preview_career, proposal, event_rng).is_empty(): return _result(quarters, "quarter_event")
		var before_clock: Dictionary = career.clock.to_dict()
		var before_history_size: int = preview_career.history.size()
		CareerSimulator.advance_proposal(preview_career, proposal, catalog)
		if preview_career.clock.to_dict() == before_clock: return _result(quarters, "advance_rejected")
		for entry in preview_career.history.slice(before_history_size):
			if str(entry.get("category", "")) == "roadmap_progress" and not Array(entry.get("key_events", [])).is_empty():
				return _result(quarters, "choice_due")
			if str(entry.get("category", "")) == "jump_milestone" and bool(entry.get("interrupt", false)):
				return _result(quarters, "choice_due")
		var live_proposal = AuthorityResolver.preview(career, TrainingPlan.from_dict(current_plan.to_dict()))
		var history_size: int = career.history.size()
		var outcomes: Array = CareerSimulator.advance_proposal(career, live_proposal, catalog)
		if career.clock.to_dict() == before_clock: return _result(quarters, "advance_rejected")
		quarters.append({"clock":before_clock, "outcomes":OutcomeRecord.list_to_dict(outcomes), "history":career.history.slice(history_size)})
		if not bool(persist.call(career)): return _result(quarters, "save_failed")
		if not KeyNodeService.pending(career).is_empty(): return _result(quarters, "key_node")
		if career.clock.year >= 2018: return _result(quarters, "2018_transition")
		if InternalInvitationService.status(CareerState.from_dict(career.to_dict())).ready: return _result(quarters, "competition_invitation")
		if career.history.slice(history_size).any(func(entry): return str(entry.get("category", "")) == "technical_grade_review"):
			return _result(quarters, "certification_review")
		if float(career.athlete.body.acute_fatigue) >= 75.0 or float(career.athlete.body.ankle_load) >= 75.0:
			return _result(quarters, "health_alert")
	return _result(quarters, "max_quarters")

static func _result(quarters: Array[Dictionary], reason: String) -> Dictionary:
	return {"quarters":quarters, "stop_reason":reason, "outcomes":quarters.back().outcomes if not quarters.is_empty() else []}
