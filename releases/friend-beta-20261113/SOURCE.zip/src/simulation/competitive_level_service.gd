class_name CompetitiveLevelService
extends RefCounted

const LABELS := {"junior":"青年组", "transition":"青年 / 成年过渡", "senior":"成年组"}

static func current(career) -> String:
	return str(career.season_program_plan.get("competitive_level","junior"))

static func validate_choice(career, season_id: String, level: String) -> String:
	if not LABELS.has(level): return "参赛组别无效"
	var year_text := season_id.get_slice("-",0)
	if not year_text.is_valid_int(): return "升组赛季无效"
	if level == "junior": return ""
	var event := {"scope":"international","level_options":["senior"],"qualification_ids":[]}
	var gate: Dictionary = preload("res://src/simulation/event_eligibility_evaluator.gd").evaluate(career.athlete,event,int(year_text),["senior"],{}, {})
	return "；".join(gate.explanations) if not gate.eligible else ""

static func event_level(career, event: Dictionary) -> String:
	var offered: Array = event.get("level_options",[])
	if current(career) == "senior" and offered.has("senior"): return "senior"
	return "junior" if offered.has("junior") else "senior"

static func permits(career, event: Dictionary) -> bool:
	# Domestic admission is governed by the event's own offered divisions and
	# certification. An international junior pathway does not exclude nationals.
	if event.get("scope","domestic") == "domestic": return true
	var offered: Array = event.get("level_options",[])
	var level := current(career)
	return level == "transition" or offered.has(level)
