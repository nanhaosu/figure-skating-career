class_name PreCareerHistoryGenerator
extends RefCounted

const AthleteState = preload("res://src/domain/athlete_state.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const TechniqueCoherenceService = preload("res://src/simulation/technique_coherence_service.gd")

const START_YEAR := 2014
const HISTORY_SALT := 0x45D9F3B
const JUMP_ORDER := ["toe_loop", "salchow", "loop", "flip", "lutz", "axel"]
const ROTATION_KEYS := ["single", "double", "triple", "quad"]
const PATH_MODIFIERS := {
	"entry_interest_class": {"teaching": 0.0, "skating": 0.0, "jump_practice": 0.0, "expression": 0.0, "fault_chance": 0.24, "load": 1.0},
	"entry_school_program": {"teaching": 2.0, "skating": 1.0, "jump_practice": 0.25, "expression": 1.0, "fault_chance": 0.14, "load": 1.2},
	"entry_club_trial": {"teaching": 4.0, "skating": 1.8, "jump_practice": 0.90, "expression": 0.0, "fault_chance": 0.12, "load": 5.5},
	"entry_public_rink": {"teaching": -3.0, "skating": 0.5, "jump_practice": -0.55, "expression": 0.0, "fault_chance": 0.52, "load": 1.6},
	"entry_transfer_sport": {"teaching": 1.0, "skating": 1.5, "jump_practice": -0.15, "expression": 12.0, "fault_chance": 0.22, "load": 1.0},
}

static func generate(
	base_athlete: AthleteState,
	base_relationships: Dictionary,
	base_condition: Dictionary,
	birth_year: int,
	skating_start_age: int,
	entry_path_id: String,
	family_profile_id: String,
	seed: int,
	entry_path: Dictionary,
	family_profile: Dictionary,
	coach_tendencies: Dictionary = {},
) -> Dictionary:
	var errors: Array[String] = []
	var handoff_age := START_YEAR - birth_year
	if skating_start_age < 3 or skating_start_age > 6:
		errors.append("开始学滑年龄必须为3至6岁")
	if handoff_age < skating_start_age:
		errors.append("开始学滑年龄不能晚于生涯开始年龄")
	if seed < 0:
		errors.append("随机种子必须为非负整数")
	if not errors.is_empty():
		return {"athlete": null, "relationships": {}, "condition_state": {}, "history": {}, "errors": errors}

	var athlete := AthleteState.from_dict(base_athlete.to_dict())
	var relationships := _copy_relationships(base_relationships)
	var condition_state := base_condition.duplicate(true)
	var rng := _rng(seed, birth_year, skating_start_age, entry_path_id)
	var training_quarters := maxi(0, (handoff_age - skating_start_age) * 4)
	var path_modifiers: Dictionary = PATH_MODIFIERS.get(entry_path_id, PATH_MODIFIERS.entry_interest_class)

	_apply_foundations(athlete, rng, training_quarters, entry_path, family_profile, path_modifiers, coach_tendencies)
	_apply_jump_history(athlete, rng, birth_year, skating_start_age, handoff_age, training_quarters, path_modifiers, coach_tendencies)
	_apply_spin_history(athlete, rng, training_quarters, path_modifiers, coach_tendencies)
	var known_observations := _apply_technical_faults(athlete, rng, entry_path, family_profile, path_modifiers, training_quarters, coach_tendencies)
	var childhood_injury := _apply_load_and_injury(athlete, condition_state, rng, training_quarters, family_profile, path_modifiers, coach_tendencies)
	var episodes := _build_episodes(rng, skating_start_age, handoff_age, training_quarters, entry_path_id, family_profile_id)
	var coherence_corrections := TechniqueCoherenceService.apply(athlete)
	if not childhood_injury.is_empty():
		var health_index := maxi(0, episodes.size() - 2)
		episodes[health_index] = {
			"id": "history-health-%d" % rng.randi_range(1000, 9999),
			"age": maxi(skating_start_age, handoff_age - 1),
			"kind": "health",
			"fact": "连续跳跃训练后出现轻微踝部不适，训练曾短暂降量并加强恢复。",
			"text": "连续跳跃训练后出现轻微踝部不适，训练曾短暂降量并加强恢复。",
			"consequence_codes": ["temporary_load_reduction", "recovery_emphasis"],
			"evidence_refs": ["condition_state.injuries.pre-career-ankle"],
		}
	var history := {
		"version": 1,
		"skating_start_age": skating_start_age,
		"training_quarters": training_quarters,
		"episodes": episodes,
		"coach_assessment": _coach_assessment(athlete, training_quarters),
		"known_observations": known_observations,
		"coherence_corrections": coherence_corrections,
		"source": "generated",
	}
	return {
		"athlete": athlete,
		"relationships": relationships,
		"condition_state": condition_state,
		"history": history,
		"errors": errors,
	}

static func _rng(seed: int, birth_year: int, start_age: int, path_id: String) -> RandomNumberGenerator:
	var path_hash := 2166136261
	for byte in path_id.to_utf8_buffer():
		path_hash = int((path_hash ^ int(byte)) * 16777619) & 0x7fffffff
	var rng := RandomNumberGenerator.new()
	rng.seed = (seed ^ HISTORY_SALT ^ (birth_year * 131) ^ (start_age * 8191) ^ path_hash) & 0x7fffffffffffffff
	return rng

static func _copy_relationships(source: Dictionary) -> Dictionary:
	var result := {}
	for key in source:
		var value = source[key]
		if value is RelationshipState:
			result[key] = RelationshipState.from_dict(value.to_dict())
		elif value is Dictionary:
			result[key] = RelationshipState.from_dict(value)
	return result

static func _apply_foundations(athlete: AthleteState, rng: RandomNumberGenerator, training_quarters: int, entry_path: Dictionary, family_profile: Dictionary, path_modifiers: Dictionary, coach_tendencies: Dictionary) -> void:
	var years := float(training_quarters) / 4.0
	var aptitude := rng.randf_range(-2.5, 2.5)
	var teaching := float(entry_path.get("technique_delta", 0.0)) * 0.22 + float(path_modifiers.teaching) + float(coach_tendencies.get("edge_foundation", 0.0)) * 4.0
	var investment := float(entry_path.get("resource_delta", 0.0)) * 0.10 + float(family_profile.get("economic_capacity", 50.0)) * 0.018
	var skating_gain := years * (4.0 + teaching * 0.18) + aptitude + float(path_modifiers.skating)
	for key in athlete.skating:
		athlete.skating[key] = clampf(float(athlete.skating[key]) + skating_gain + rng.randf_range(-1.5, 1.5), 0.0, 100.0)
	athlete.technique.rotation = clampf(float(athlete.technique.rotation) + years * 3.2 + aptitude, 0.0, 100.0)
	athlete.technique.landing = clampf(float(athlete.technique.landing) + years * 2.8 + teaching, 0.0, 100.0)
	athlete.technique.single_jumps = clampf(float(athlete.technique.single_jumps) + years * 5.0 + teaching, 0.0, 100.0)
	for key in athlete.jump_foundation.DEFAULTS:
		var gain := years * rng.randf_range(2.2, 3.8) + teaching * 0.35
		athlete.jump_foundation.set(key, clampf(float(athlete.jump_foundation.get(key)) + gain, 0.0, 100.0))
	athlete.body.strength_readiness = clampf(float(athlete.body.strength_readiness) + years * 2.0, 0.0, 100.0)
	athlete.body.joint_readiness = clampf(float(athlete.body.joint_readiness) + years * 1.4, 0.0, 100.0)
	athlete.body.recovery_capacity = clampf(float(athlete.body.recovery_capacity) + years * 1.8 + investment, 0.0, 100.0)
	athlete.mind.motivation = clampf(float(athlete.mind.motivation) + rng.randf_range(-3.0, 5.0), 0.0, 100.0)
	athlete.mind.motivation = clampf(float(athlete.mind.motivation) + float(coach_tendencies.get("psychological_attunement", 0.0)) * 3.0, 0.0, 100.0)
	athlete.mind.training_fear = clampf(float(athlete.mind.training_fear) - float(coach_tendencies.get("psychological_attunement", 0.0)) * 2.0, 0.0, 100.0)
	athlete.mind.expression = clampf(float(athlete.mind.expression) + float(path_modifiers.expression) + years * 0.6, 0.0, 100.0)
	athlete.resources.ice_access = clampf(float(athlete.resources.ice_access) + investment, 0.0, 100.0)

static func _apply_jump_history(athlete: AthleteState, rng: RandomNumberGenerator, birth_year: int, start_age: int, handoff_age: int, training_quarters: int, path_modifiers: Dictionary, coach_tendencies: Dictionary) -> void:
	if training_quarters <= 0:
		return
	var years := float(training_quarters) / 4.0
	var learned_singles := JUMP_ORDER.size() if years >= 4.5 else clampi(int(round(years * 1.65 + float(path_modifiers.jump_practice) + rng.randf_range(-0.35, 1.0))), 1, JUMP_ORDER.size())
	var double_count := 0
	if years >= 4.0:
		double_count = clampi(int(floor((years - 3.0) * 1.2)), 1, JUMP_ORDER.size())
		if float(path_modifiers.jump_practice) >= 0.75: double_count += 1
		if float(path_modifiers.jump_practice) >= 0.75 and rng.randf() < 0.35: double_count += 1
		double_count = clampi(double_count, 1, JUMP_ORDER.size())
	for index in JUMP_ORDER.size():
		var jump = athlete.jumps[JUMP_ORDER[index]]
		if index < learned_singles:
			_populate_rotation(jump, "single", rng, birth_year, start_age, handoff_age, years, index)
		if index < double_count:
			_populate_rotation(jump, "double", rng, birth_year, start_age, handoff_age, years, index)
		if JUMP_ORDER[index] == "toe_loop":
			var toe_bonus := float(coach_tendencies.get("toe_jump_mechanics", 0.0)) * 12.0
			jump.takeoff.toe_assist = clampf(float(jump.takeoff.toe_assist) + toe_bonus, 0.0, 100.0)
			jump.proficiency.single = clampf(float(jump.proficiency.single) + toe_bonus * 0.35, 0.0, 100.0)
			jump.proficiency.double = clampf(float(jump.proficiency.double) + toe_bonus * 0.25, 0.0, 100.0)
		jump.attempts = 0
		for rotation_key in ROTATION_KEYS:
			jump.attempts += int(jump.attempt_evidence[rotation_key].attempts)

static func _apply_spin_history(athlete: AthleteState, rng: RandomNumberGenerator, training_quarters: int, path_modifiers: Dictionary, coach_tendencies: Dictionary) -> void:
	if training_quarters <= 0: return
	var years := float(training_quarters) / 4.0
	var shared_gain := years * (4.2 + float(path_modifiers.skating) * 0.12)
	for key in athlete.spin_foundation:
		var modifier := 0.75 if key == "flexibility" else 1.0
		athlete.spin_foundation[key] = clampf(float(athlete.spin_foundation[key]) + shared_gain * modifier + rng.randf_range(-1.5, 1.5), 0.0, 100.0)
	var focus_order := ["upright", "sit", "camel", "combination", "layback", "flying"]
	var expression_bonus := float(coach_tendencies.get("component_development", 0.0)) * 8.0
	for index in focus_order.size():
		var spin_id: String = focus_order[index]
		var exposure := maxf(0.0, years * 8.0 - float(index) * 4.5)
		var specialty := rng.randf_range(-2.0, 4.0) + (expression_bonus if spin_id in ["layback", "combination"] else 0.0)
		athlete.spins[spin_id].proficiency = clampf(exposure + specialty, 0.0, 100.0)
		athlete.spins[spin_id].training_consistency = clampf(exposure * 0.72 + specialty, 0.0, 100.0)
		athlete.spins[spin_id].level_features = clampi(int(floor(float(athlete.spins[spin_id].proficiency) / 18.0)), 0, 4)

static func _populate_rotation(jump, rotation_key: String, rng: RandomNumberGenerator, birth_year: int, start_age: int, handoff_age: int, years: float, order_index: int) -> void:
	var rotations := ROTATION_KEYS.find(rotation_key) + 1
	var attempts := maxi(6, int(round(years * rng.randf_range(12.0, 22.0) - order_index * 3.0)))
	var success_rate := clampf(0.36 + years * 0.08 - order_index * 0.025 - float(rotations - 1) * 0.22 + rng.randf_range(-0.06, 0.08), 0.12, 0.88)
	var successes := clampi(int(round(float(attempts) * success_rate)), 1, attempts)
	var clean_successes := clampi(int(round(float(successes) * rng.randf_range(0.42, 0.76))), 0, successes)
	var failures := attempts - successes
	var evidence: Dictionary = jump.attempt_evidence[rotation_key]
	evidence.attempts = attempts
	evidence.successes = successes
	evidence.clean_successes = clean_successes
	var remaining_failures := failures
	evidence.falls = mini(remaining_failures, int(round(float(failures) * 0.34)))
	remaining_failures -= int(evidence.falls)
	evidence.pops = mini(remaining_failures, int(round(float(failures) * 0.25)))
	remaining_failures -= int(evidence.pops)
	evidence.two_foot = mini(remaining_failures, int(round(float(failures) * 0.16)))
	remaining_failures -= int(evidence.two_foot)
	evidence.hand_down = mini(remaining_failures, int(round(float(failures) * 0.10)))
	remaining_failures -= int(evidence.hand_down)
	evidence.underrotated = mini(remaining_failures, int(round(float(failures) * 0.10)))
	remaining_failures -= int(evidence.underrotated)
	evidence.downgraded = remaining_failures
	var learned_age := clampi(start_age + 1 + order_index / 2 + rotations - 1, start_age, handoff_age)
	var learned_year := birth_year + learned_age
	var learned_quarter := 1 + (order_index % 4)
	if learned_year >= START_YEAR:
		learned_year = START_YEAR - 1
		learned_quarter = 4
	evidence.first_success_clock = {"year": learned_year, "quarter": learned_quarter}
	jump.unlocked_rotations = maxi(int(jump.unlocked_rotations), rotations)
	jump.proficiency[rotation_key] = clampf(15.0 + success_rate * 55.0 + years * 2.0, 0.0, 100.0)
	jump.consistency.training = maxf(float(jump.consistency.training), clampf(float(clean_successes) / float(attempts) * 100.0, 0.0, 100.0))
	jump.consistency.internal = maxf(float(jump.consistency.internal), jump.consistency.training * 0.25)
	jump.consistency.official = 0.0
	jump.consistency.high_pressure = 0.0
	jump.air.height = clampf(float(jump.air.height) + years * 2.0, 0.0, 100.0)
	jump.air.rotation_speed = clampf(float(jump.air.rotation_speed) + years * 2.2, 0.0, 100.0)
	jump.landing.completion = clampf(float(jump.landing.completion) + years * 2.4, 0.0, 100.0)
	jump.landing.control = clampf(float(jump.landing.control) + years * 2.0, 0.0, 100.0)

static func _apply_technical_faults(athlete: AthleteState, rng: RandomNumberGenerator, entry_path: Dictionary, family_profile: Dictionary, path_modifiers: Dictionary, training_quarters: int, coach_tendencies: Dictionary) -> Array[String]:
	var known_observations: Array[String] = []
	if training_quarters <= 0:
		return known_observations
	var teaching := float(path_modifiers.teaching)
	for jump_id in ["flip", "lutz"]:
		var jump = athlete.jumps[jump_id]
		var lutz_guidance := float(coach_tendencies.get("lutz_edge_guidance", 0.0)) if jump_id == "lutz" else 0.0
		jump.takeoff.edge_quality = clampf(50.0 + teaching * 1.7 + lutz_guidance * 18.0 + rng.randf_range(-5.0, 5.0), 0.0, 100.0)
		var fault_chance := clampf(float(path_modifiers.fault_chance) - lutz_guidance * 0.22, 0.04, 0.75)
		if rng.randf() >= fault_chance:
			continue
		jump.takeoff.edge_quality = rng.randf_range(22.0, 38.0)
		jump.takeoff.edge_stability = rng.randf_range(28.0, 46.0)
		if rng.randf() < 0.45:
			jump.takeoff.prerotation = rng.randf_range(21.0, 38.0)
		if rng.randf() < 0.30:
			jump.air.axis = rng.randf_range(30.0, 39.0)
		jump.habits.rigidity = rng.randf_range(18.0, 48.0)
		jump.habits.relapse_risk = rng.randf_range(20.0, 55.0)
		var observation_probability := clampf(
			0.18 + float(entry_path.get("technique_delta", 0.0)) * 0.012 + float(family_profile.get("industry_knowledge", 0.0)) * 0.004 + maxf(0.0, teaching) * 0.02,
			0.15,
			0.85
		)
		if rng.randf() < observation_probability:
			var jump_name := "勾手跳" if jump_id == "lutz" else "后内点冰跳"
			var text := "%s的起跳刃还不稳定，教练建议继续观察。" % jump_name
			known_observations.append(text)
			jump.observations.append({"id": "%s-edge" % jump_id, "kind": "edge", "text": text, "known": true})
	return known_observations

static func _apply_load_and_injury(athlete: AthleteState, condition_state: Dictionary, rng: RandomNumberGenerator, training_quarters: int, family_profile: Dictionary, path_modifiers: Dictionary, coach_tendencies: Dictionary) -> Dictionary:
	if not condition_state.get("injuries") is Array:
		condition_state.injuries = []
	if training_quarters <= 0:
		return {}
	var years := float(training_quarters) / 4.0
	var control := float(family_profile.get("control", 50.0))
	var health_priority := float(family_profile.get("health_priority", 60.0))
	var aggression := float(path_modifiers.load) + control * 0.07 - health_priority * 0.045 + float(coach_tendencies.get("load_aggression", 0.0)) * 4.0 + rng.randf_range(-1.5, 1.5)
	var impact_load := clampf(years * maxf(0.0, aggression) * 0.9, 0.0, 100.0)
	athlete.body.impact_load = impact_load
	athlete.body.ankle_load = clampf(impact_load * rng.randf_range(0.45, 0.70), 0.0, 100.0)
	athlete.body.cumulative_fatigue = clampf(impact_load * rng.randf_range(0.18, 0.32), 0.0, 100.0)
	var poor_recovery := clampf((70.0 - float(athlete.body.recovery_capacity)) / 70.0, 0.0, 1.0)
	var injury_probability := clampf(maxf(0.0, impact_load - 12.0) * 0.0018 + poor_recovery * 0.018, 0.0, 0.105)
	if rng.randf() >= injury_probability:
		return {}
	var injury := {
		"id": "pre-career-ankle",
		"site": "ankle",
		"severity": rng.randf_range(0.08, 0.25),
		"remaining_quarters": 1,
		"status": "active",
	}
	condition_state.injuries.append(injury)
	return injury

static func _build_episodes(rng: RandomNumberGenerator, start_age: int, handoff_age: int, training_quarters: int, entry_path_id: String, family_profile_id: String) -> Array[Dictionary]:
	var entry_text := _entry_episode_text(entry_path_id)
	if training_quarters == 0:
		return [
			_episode("first-contact", handoff_age, "entry", "%d岁%s，今天才开始认识花样滑冰。" % [handoff_age, entry_text], ["career_started_as_beginner"], ["profile.entry_path"]),
			_episode("first-lesson", handoff_age, "training", "第一次课程从站稳和安全摔倒开始。", ["basic_safety_started"], ["history.training_quarters"]),
			_episode("first-plan", handoff_age, "family", "家人与教练开始商量最初的学滑安排。", ["initial_plan_created"], ["relationships.guardian", "relationships.coach"]),
		]
	var count := clampi(4 + int(floor(float(training_quarters) / 12.0)), 4, 6)
	var templates := [
		["entry", "%s，先学会安全摔倒、起身和独立蹬冰。" % entry_text, ["safety_foundation"], ["profile.entry_path"]],
		["skating", "固定上冰后，前后滑、单脚平衡和基础用刃逐渐稳定。", ["skating_foundation_gained"], ["athlete.skating"]],
		["jump", "单周跳按动作次序进入日常训练，并开始尝试较早掌握的两周跳。", ["jump_curriculum_progressed"], ["athlete.jumps", "athlete.jump_foundation"]],
		["spin", "直立、蹲踞和燕式旋转共同打底，同时慢慢显出更擅长的姿势。", ["spin_foundation_gained", "spin_specialization_emerged"], ["athlete.spin_foundation", "athlete.spins"]],
		["routine", "训练成为每周生活的一部分；疲惫时会降量，状态好时再推进新动作。", ["training_routine_formed"], ["athlete.body", "relationships.coach"]],
		["handoff", "教练把已经练过、尚不稳定和需要长期观察的内容写进交接评估。", ["handoff_assessment_created"], ["history.coach_assessment", "history.known_observations"]],
	]
	var episodes: Array[Dictionary] = []
	for index in count:
		var ratio := 0.0 if count == 1 else float(index) / float(count - 1)
		var age := clampi(int(round(lerpf(float(start_age), float(handoff_age), ratio))), start_age, handoff_age)
		episodes.append(_episode("history-%d-%d" % [index + 1, rng.randi_range(1000, 9999)], age, templates[index][0], templates[index][1], templates[index][2], templates[index][3]))
	return episodes

static func _episode(id: String, age: int, kind: String, fact: String, consequence_codes: Array, evidence_refs: Array) -> Dictionary:
	return {"id": id, "age": age, "kind": kind, "fact": fact, "text": fact, "consequence_codes": consequence_codes.duplicate(), "evidence_refs": evidence_refs.duplicate()}

static func _entry_episode_text(entry_path_id: String) -> String:
	return {
		"entry_interest_class": "第一次参加兴趣班",
		"entry_school_program": "通过学校冰雪项目来到冰场",
		"entry_club_trial": "参加俱乐部试训后进入启蒙组",
		"entry_public_rink": "第一次在公共冰场反复尝试滑行",
		"entry_transfer_sport": "从其他运动跨项接触花样滑冰",
	}.get(entry_path_id, "第一次来到冰场")

static func _coach_assessment(athlete: AthleteState, training_quarters: int) -> String:
	if training_quarters == 0:
		return "刚刚接触花样滑冰，需要从安全、平衡和基本滑行开始观察。"
	var learned := 0
	for jump in athlete.jumps.values():
		if int(jump.unlocked_rotations) >= 1: learned += 1
	return "已有%d种单周跳留下成功记录，滑行与跳跃基础仍需在后续训练中持续验证。" % learned
