class_name ProgramDraftService
extends RefCounted

const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const ProgramRevisionService = preload("res://src/simulation/program_revision_service.gd")

static func save_draft(existing_program, edited_program) -> Dictionary:
	if edited_program == null:
		return {"program":null, "archived":null, "errors":["节目草案不存在"]}
	var saved
	var archived = null
	if existing_program == null:
		saved = SkatingProgram.from_dict(edited_program.to_dict())
	else:
		var editable_existing = SkatingProgram.from_dict(existing_program.to_dict())
		# Saving a draft explicitly returns this segment to editing. Other callers
		# still go through the revision service, which protects competition locks.
		editable_existing.draft_status = "draft"
		editable_existing.locked_segments.erase(editable_existing.segment)
		var editable = SkatingProgram.from_dict(edited_program.to_dict())
		editable.program_id = editable_existing.program_id
		var revision := ProgramRevisionService.revise(editable_existing, editable)
		if not revision.errors.is_empty(): return revision
		saved = revision.program
		archived = revision.archived
	saved.draft_status = "draft"
	saved.locked_segments.erase(saved.segment)
	return {"program":saved, "archived":archived, "changed":archived != null, "errors":[]}

static func lock_for_competition(program, athlete, rules: Dictionary) -> Dictionary:
	if program == null:
		return {"program":null, "errors":["节目不存在"]}
	var errors := ProgramValidator.validate(program, athlete, rules)
	if not errors.is_empty():
		return {"program":null, "errors":errors}
	var locked = SkatingProgram.from_dict(program.to_dict())
	locked.draft_status = "locked"
	if not locked.locked_segments.has(locked.segment): locked.locked_segments.append(locked.segment)
	return {"program":locked, "errors":[]}

const ProgramElement = preload("res://src/domain/program_element.gd")
const JumpConnectionRules = preload("res://src/simulation/jump_connection_rules.gd")
const JUMP_ORDER: Array[String] = ["lutz", "flip", "loop", "salchow", "toe_loop", "axel"]

static func propose(athlete, segment: String, rules: Dictionary, music: Dictionary, seed: int) -> Dictionary:
	if athlete == null or rules.is_empty() or str(rules.get("segment", "")) != segment:
		return {"program":null, "missing":[], "errors":["节目目标规则无效"]}
	var elements: Array = _short_jumps(athlete, rules, seed) if segment == "short" else _free_jumps(athlete, rules, seed)
	for index in int(rules.get("spin_min", 0)):
		var spin = ProgramElement.create("%s-spin-%d" % [segment, index + 1], "spin").element
		if index < rules.get("required_spin_codes", []).size(): spin.spin_code = rules.required_spin_codes[index]
		elif index < rules.get("draft_spin_codes", []).size(): spin.spin_code = rules.draft_spin_codes[index]
		elements.append(spin)
	for index in int(rules.get("step_min", 0)):
		elements.append(ProgramElement.create("%s-step-%d" % [segment, index + 1], "step_sequence").element)
	for index in int(rules.get("choreographic_min", 0)):
		elements.append(ProgramElement.create("%s-choreo-%d" % [segment, index + 1], "choreographic_sequence").element)
	var created := SkatingProgram.create("coach-%s-%d" % [segment, seed], segment, elements)
	if not created.errors.is_empty(): return {"program":null, "missing":[], "errors":created.errors}
	created.program.music = music.duplicate(true)
	created.program.route_complexity = "simple"
	return {"program":created.program, "missing":ProgramValidator.validate(created.program, athlete, rules), "errors":[]}

static func legal_draft(athlete, segment: String, rules: Dictionary, music: Dictionary, seed: int) -> Dictionary:
	var proposal := propose(athlete, segment, rules, music, seed)
	if proposal.program == null or not proposal.errors.is_empty(): return proposal
	if not proposal.missing.is_empty():
		return {"program":null, "missing":proposal.missing, "errors":["当前已掌握动作不足以生成合规节目"]}
	return proposal

static func propose_for_npc(athlete, segment: String, rules: Dictionary, seed: int, archetype: String) -> Dictionary:
	var constrained := rules.duplicate(true)
	constrained["maximum_followup_rotations"] = 3 if archetype == "top" else 2
	constrained["minimum_followup_rotations"] = 2
	return legal_draft(athlete, segment, constrained, {"title":"赛季节目"}, seed)

static func _short_jumps(athlete, rules: Dictionary, seed: int) -> Array:
	if rules.has("required_solo_rotations"):
		return _generic_formal_short_jumps(athlete,rules,seed)
	if rules.has("required_axel_rotations") or rules.has("required_solo_jump"):
		return _prescribed_short_jumps(athlete, rules, seed)
	if Array(rules.get("required_jump_types", [])).has("axel"):
		return _generic_formal_short_jumps(athlete, rules, seed)
	var result: Array = []
	var candidates := _rotated_candidates(athlete, seed, 1)
	if candidates.is_empty(): return result
	var combo: Variant = _combination_from_candidates(athlete, candidates, rules, 1, [])
	if combo != null: result.append(combo)
	for candidate in candidates:
		if result.size() >= int(rules.get("jump_min", 0)): break
		if result.any(func(element): return element.jump_id == candidate.jump_id): continue
		result.append(_jump("short-jump-%d" % [result.size() + 1], candidate))
	for candidate in candidates:
		if result.size() >= int(rules.get("jump_min", 0)): break
		result.append(_jump("short-jump-%d" % [result.size() + 1], candidate))
	return result

static func _generic_formal_short_jumps(athlete, rules: Dictionary, seed: int) -> Array:
	var result: Array = []
	var axel_rotation := _highest_required_rotation(athlete,"axel",Array(rules.required_axel_rotations)) if rules.has("required_axel_rotations") else _highest_unlocked(athlete, "axel", 3, 1)
	if axel_rotation > 0: result.append(_jump("short-axel", {"jump_id":"axel", "rotations":axel_rotation}))
	var candidates := _rotated_candidates(athlete, seed, 2,int(rules.get("maximum_combination_rotations",4))).filter(func(candidate): return candidate.jump_id != "axel")
	var solos: Array = candidates.duplicate(true)
	for rotations in [3,2]:
		for candidate in candidates:
			if rotations >= int(candidate.rotations): continue
			if _highest_unlocked(athlete,str(candidate.jump_id),rotations,rotations) == rotations:
				solos.append({"jump_id":str(candidate.jump_id),"rotations":rotations})
	# Reserve the actual solo code before choosing the combination. Consuming
	# every family in the first greedy pair can hide a perfectly legal layout;
	# a different rotation of a family remains a different jump code.
	for solo in solos:
		if rules.has("required_solo_rotations") and not Array(rules.required_solo_rotations).any(func(rotation):return float(rotation) == float(solo.rotations)): continue
		var combo: Variant = _combination_from_candidates(athlete,candidates,rules,2,["axel"],[_key(solo)])
		if combo == null: continue
		combo.element_id = "short-combination"
		result.append(combo)
		result.append(_jump("short-solo",solo))
		return result
	return result

static func _prescribed_short_jumps(athlete, rules: Dictionary, seed: int) -> Array:
	var result: Array = []
	var reserved: Array[String] = []
	var axel_rotations := _highest_required_rotation(athlete, "axel", Array(rules.get("required_axel_rotations", [])))
	if axel_rotations > 0:
		result.append(_jump("short-axel", {"jump_id":"axel", "rotations":axel_rotations}))
		reserved.append("axel")
	var solo_id := str(rules.get("required_solo_jump", ""))
	var candidates := _rotated_candidates(athlete, seed, int(rules.get("minimum_combination_rotations", 2)),int(rules.get("maximum_combination_rotations",4)))
	if not solo_id.is_empty():
		var solo_rotation := _highest_unlocked(athlete, solo_id, int(rules.get("maximum_combination_rotations", 3)), int(rules.get("minimum_combination_rotations", 2)))
		for rotation in range(mini(3,solo_rotation),1,-1):
			if _highest_unlocked(athlete,solo_id,rotation,rotation) != rotation: continue
			var solo := {"jump_id":solo_id,"rotations":rotation}
			var compatible: Variant = _combination_from_candidates(athlete,candidates,rules,int(rules.get("minimum_combination_rotations",2)),reserved,[_key(solo)])
			if compatible == null: continue
			result.append(_jump("short-prescribed-solo",solo))
			compatible.element_id = "short-combination"
			result.append(compatible)
			return result
		if solo_rotation > 0:
			result.append(_jump("short-prescribed-solo", {"jump_id":solo_id, "rotations":solo_rotation}))
		return result
	var combo: Variant = _combination_from_candidates(athlete, candidates, rules, int(rules.get("minimum_combination_rotations", 2)), reserved)
	if combo != null:
		combo.element_id = "short-combination"
		result.append(combo)
	return result

static func _free_jumps(athlete, rules: Dictionary, seed: int) -> Array:
	var target := int(rules.get("jump_min", 0))
	var candidates := _rotated_candidates(athlete, seed, 1)
	var result: Array = []
	if candidates.is_empty(): return result
	var counts := {}
	for candidate in candidates:
		if result.size() >= target: break
		result.append(_jump("free-jump-%d" % [result.size() + 1], candidate))
		_increment(counts, candidate)
	var repeat_candidates: Array = candidates.duplicate(true)
	for candidate in repeat_candidates:
		if result.size() >= target: break
		if int(counts.get(_key(candidate), 0)) >= 2: continue
		if int(candidate.rotations) >= 3:
			var repeated := 0
			for code in counts:
				if int(str(code).get_slice(":",0)) >= 3 and int(counts[code]) >= 2: repeated += 1
			if repeated >= int(Dictionary(rules.get("repeat_limits",{})).get("max_repeated_triples_or_quads",2)): continue
		result.append(_jump("free-jump-%d" % [result.size() + 1], candidate))
		_increment(counts, candidate)
	# A limited set of learned families can still fill a legal programme with
	# their separately evidenced lower rotations. Keep the highest-family pass
	# first so adding this fallback cannot replace an established five-triple set.
	for rotations in [3,2,1]:
		for candidate in candidates:
			if result.size() >= target: break
			if rotations >= int(candidate.rotations): continue
			if _highest_unlocked(athlete,str(candidate.jump_id),rotations,rotations) != rotations: continue
			var lower := {"jump_id":str(candidate.jump_id),"rotations":rotations}
			if int(counts.get(_key(lower),0)) > 0: continue
			result.append(_jump("free-jump-%d" % [result.size()+1],lower))
			_increment(counts,lower)
	var combination_target := mini(mini(int(rules.get("jump_combination_max", 0)), 3), result.size())
	var three_jump_target := mini(int(rules.get("jump_combination_three_jump_max", 0)), 1)
	var combination_indexes: Array[int] = []
	var reserved_codes: Array[String] = []
	# Repeated high jumps need one combination before an optional third jump
	# consumes the scarce followers. Count only parts actually put in the plan.
	for index in result.size():
		if combination_indexes.size() >= combination_target: break
		var code := _key({"jump_id":result[index].jump_id,"rotations":result[index].rotations})
		if result[index].rotations >= 3 and int(counts.get(code,0)) >= 2 and not reserved_codes.has(code):
			combination_indexes.append(index)
			reserved_codes.append(code)
	for index in result.size():
		if combination_indexes.size() >= combination_target: break
		if not combination_indexes.has(index): combination_indexes.append(index)
	for index in combination_indexes:
		var follower := _best_follower(athlete,rules,counts,str(result[index].jump_id),1)
		if follower.is_empty(): continue
		result[index].set_combination_parts([follower])
		_increment(counts,follower)
	if three_jump_target > 0:
		for index in combination_indexes:
			var parts: Array = result[index].combination_parts.duplicate(true)
			if parts.size() != 1: continue
			var follower := _best_follower(athlete,rules,counts,str(parts[0].jump_id),1)
			if follower.is_empty(): continue
			parts.append(follower)
			result[index].set_combination_parts(parts)
			_increment(counts,follower)
			break
	return result

static func _combination_from_candidates(athlete, candidates: Array, rules: Dictionary, minimum_rotation: int, excluded: Array[String], excluded_codes: Array[String] = []):
	for base in candidates:
		if excluded.has(str(base.jump_id)) or excluded_codes.has(_key(base)): continue
		var follower_minimum := minimum_rotation
		var highest_required := int(rules.get("minimum_combination_highest_rotation",0))
		if int(base.rotations) < highest_required: follower_minimum = maxi(follower_minimum,highest_required)
		var follower := _best_follower(athlete, rules, {}, str(base.jump_id), follower_minimum, excluded,excluded_codes)
		if follower.is_empty(): continue
		var element = _jump("short-jump-1", base)
		element.set_combination_parts([follower])
		return element
	return null

static func _best_follower(athlete, rules: Dictionary, counts: Dictionary, previous_id: String, minimum_rotation: int, excluded: Array[String] = [], excluded_codes: Array[String] = []) -> Dictionary:
	minimum_rotation = maxi(minimum_rotation,int(rules.get("minimum_followup_rotations",minimum_rotation)))
	var allowed: Array = rules.get("combination_followup_jump_types", JumpConnectionRules.DIRECT_FOLLOWERS)
	var rotation_order: Array = range(4, minimum_rotation - 1, -1)
	for rotations in rotation_order:
		if rotations > mini(int(rules.get("maximum_followup_rotations",4)),int(rules.get("maximum_combination_rotations",4))): continue
		for jump_id in allowed:
			if excluded.has(str(jump_id)): continue
			if not JumpConnectionRules.can_connect(previous_id, str(jump_id), rules).allowed: continue
			if _highest_unlocked(athlete, str(jump_id), rotations, rotations) != rotations: continue
			if rotations >= 3 and not _strong_followup(athlete.jumps[jump_id],rotations): continue
			var candidate := {"jump_id":str(jump_id), "rotations":rotations}
			if excluded_codes.has(_key(candidate)): continue
			if int(counts.get(_key(candidate), 0)) >= 2: continue
			if rotations >= 3 and int(counts.get(_key(candidate),0)) == 1:
				var repeated := 0
				for code in counts:
					if int(str(code).get_slice(":",0)) >= 3 and int(counts[code]) >= 2: repeated += 1
				if repeated >= int(Dictionary(rules.get("repeat_limits",{})).get("max_repeated_triples_or_quads",2)): continue
			return candidate
	return {}

static func _rotated_candidates(athlete, seed: int, minimum_rotation: int, maximum_rotation: int = 4) -> Array:
	var candidates: Array = []
	for jump_id in JUMP_ORDER:
		var rotations := _highest_unlocked(athlete, jump_id, maximum_rotation, minimum_rotation)
		if rotations > 0: candidates.append({"jump_id":jump_id, "rotations":rotations})
	if not candidates.is_empty():
		var offset := posmod(seed, candidates.size())
		candidates = candidates.slice(offset) + candidates.slice(0, offset)
	return candidates

static func _highest_required_rotation(athlete, jump_id: String, allowed: Array) -> int:
	var sorted: Array = allowed.duplicate()
	sorted.sort()
	sorted.reverse()
	for rotations in sorted:
		if _highest_unlocked(athlete,jump_id,int(rotations),int(rotations)) == int(rotations): return int(rotations)
	return 0

static func _highest_unlocked(athlete, jump_id: String, maximum: int, minimum: int) -> int:
	if not athlete.jumps.has(jump_id): return 0
	var unlocked := mini(int(athlete.jumps[jump_id].unlocked_rotations), maximum)
	for rotations in range(unlocked,minimum-1,-1):
		if _rotation_ready(athlete.jumps[jump_id],rotations): return rotations
	return 0

# Recommendation only: does not revoke unlocks or restrict manual editing.
static func _rotation_ready(jump, rotations: int) -> bool:
	if rotations == 1: return true
	var key: String = ["","single","double","triple","quad"][rotations]
	var evidence: Dictionary = jump.attempt_evidence[key]
	var proficiency := float(jump.proficiency[key])
	if int(evidence.attempts) == 0:
		# Older saves may predate per-rotation counters. Preserve demonstrable
		# skill rather than either deleting their repertoire or inventing it.
		var consistency := maxf(float(jump.consistency.training),float(jump.consistency.official))
		for legacy_rotation in range(rotations,int(jump.unlocked_rotations)+1):
			var legacy_key: String = ["","single","double","triple","quad"][legacy_rotation]
			if int(jump.attempt_evidence[legacy_key].attempts) == 0 and float(jump.proficiency[legacy_key]) >= 35.0 and consistency >= 35.0: return true
		return false
	return proficiency >= 20.0 and int(evidence.successes) >= 5 and int(evidence.clean_successes) >= 1

static func _strong_followup(jump, rotations: int) -> bool:
	var key: String = ["","single","double","triple","quad"][rotations]
	var evidence: Dictionary = jump.attempt_evidence[key]
	return float(jump.proficiency[key]) >= 70.0 and float(jump.consistency.training) >= 65.0 and float(jump.landing.combination) >= 60.0 and int(evidence.successes) >= 10 and int(evidence.clean_successes) >= 3

static func _jump(element_id: String, candidate: Dictionary):
	return ProgramElement.create(element_id, "jump", str(candidate.jump_id), int(candidate.rotations)).element

static func _key(candidate: Dictionary) -> String:
	return "%d:%s" % [int(candidate.rotations), str(candidate.jump_id)]

static func _increment(counts: Dictionary, candidate: Dictionary) -> void:
	var key := _key(candidate)
	counts[key] = int(counts.get(key, 0)) + 1
