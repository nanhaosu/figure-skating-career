class_name InternationalAssignmentService
extends RefCounted

const World = preload("res://src/simulation/world_generation_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Policy = preload("res://src/simulation/annual_selection_policy_service.gd")

static func world_selection_window_errors(career, season_start_year: int = 2018) -> Array[String]:
	var selected := Policy.target(career,"world_junior",season_start_year)
	if not selected.errors.is_empty(): return ["年度政策损坏："+"；".join(selected.errors)]
	if selected.target.is_empty(): return ["本赛季世青政策未覆盖"]
	var current: int = career.clock.year * 4 + career.clock.quarter
	var year := int(selected.target.window.year)
	var quarter := int(selected.target.window.quarter)
	var window := year * 4 + quarter
	if current < window: return ["公开世青选拔于%d年第%d季度开始" % [year,quarter]]
	if current > window: return ["选拔申请截止季度已过"]
	return []

static func resolve(career, candidates: Array, available_slots: int, context: Dictionary, seed: int) -> Dictionary:
	var kind := str(context.get("kind","jgp"))
	if not kind in ["jgp","world_junior"] or available_slots < 0 or seed < 0:
		return {"assignments":{},"audit":{},"errors":["选拔参数无效"]}
	var year := int(context.get("bundle",{}).get("calendar",{}).get("calendar_year",context.get("season_start_year",2018)))
	var selected := Policy.target(career,kind,year)
	if not selected.errors.is_empty(): return {"assignments":{},"audit":{},"errors":selected.errors}
	if selected.target.is_empty(): return {"assignments":{},"audit":{},"errors":["本赛季目标选拔制度未覆盖"]}
	var model: Dictionary = selected.target
	available_slots = mini(available_slots,int(model.places))
	if kind == "world_junior":
		var window_errors := world_selection_window_errors(career,year)
		if not window_errors.is_empty(): return {"assignments":{},"audit":{},"errors":window_errors}
	var designated: Array = model.designated_event_ids
	var rows: Array = []; var adjustments: Array = []; var seen := {}
	for candidate in candidates:
		if not candidate is Dictionary or str(candidate.get("athlete_id", "")).is_empty() or seen.has(candidate.athlete_id):
			return {"assignments":{},"audit":{},"errors":["候选名单无效或重复"]}
		seen[candidate.athlete_id] = true
		var evidence := {}; var score := 0.0; var free_score := 0.0
		for result in candidate.get("results",[]):
			if not result is Dictionary or not designated.has(str(result.get("event_id",""))): continue
			if not preload("res://src/content/annual_selection_policy_repository.gd").number(result.get("total_score",0),0,10000) or not preload("res://src/content/annual_selection_policy_repository.gd").number(result.get("free_score",0),0,10000): return {"assignments":{},"audit":{},"errors":["成绩无效"]}
			# Only an actually complete SP+FS score can satisfy the published
			# best/weighted total rule. A cut may apply, but earns no full score.
			if result.has("complete_result") and not result.complete_result is bool: return {"assignments":{},"audit":{},"errors":["完整成绩事实无效"]}
			if not bool(result.get("complete_result",float(result.get("free_score",0)) > 0.0 and float(result.get("total_score",0)) > float(result.get("free_score",0)))): continue
			var prior: Dictionary = evidence.get(result.event_id,{})
			if prior.is_empty() or float(result.total_score) > float(prior.total_score) or (float(result.total_score) == float(prior.total_score) and float(result.free_score) > float(prior.free_score)):
				evidence[result.event_id] = result.duplicate(true)
		if kind == "world_junior":
			for id in designated:
				var weight := float(model.weights[id])
				score += float(evidence.get(id,{}).get("total_score",0)) * weight
				free_score += float(evidence.get(id,{}).get("free_score",0)) * weight
		else:
			for result in evidence.values():
				if float(result.get("total_score",0)) > score or (float(result.get("total_score",0)) == score and float(result.get("free_score",0)) > free_score):
					score = float(result.total_score); free_score = float(result.get("free_score",0))
		var eligible := bool(candidate.get("eligible",false)) and str(candidate.get("federation","")) == str(selected.policy.federation) and score >= float(model.minimum_score)
		eligible = eligible and preload("res://src/content/annual_selection_policy_repository.gd").integer(candidate.get("age"),int(model.minimum_age),int(model.maximum_age))
		if kind == "world_junior":
			for required in designated:
				if not evidence.has(required): eligible = false
		rows.append({"athlete_id":candidate.athlete_id,"name":candidate.get("name",candidate.athlete_id),"score":snappedf(score,0.01),"free_score":snappedf(free_score,0.01),"eligible":eligible,"evidence":evidence,"club_access":float(candidate.get("club_access",0)),"lottery_key":World.stable_seed("%d:selection:%s" % [seed,candidate.athlete_id]),"reason_codes":["not_selected" if eligible else "insufficient_designated_evidence_or_ineligible"]})
		var age := int(candidate.get("age",0))
		var earliest := 0.0
		# Only complete SP+FS evidence counts; explicit dates survive archive order.
		var complete: Array = evidence.values().filter(func(r): return bool(r.get("complete_result",float(r.get("free_score",0)) > 0.0 and float(r.get("total_score",0)) > float(r.get("free_score",0)))))
		complete.sort_custom(func(a,b): return str(a.get("event_start_date",a.event_id)) < str(b.get("event_start_date",b.event_id)))
		if not complete.is_empty(): earliest = float(complete[0].total_score)
		var growth := maxf(0.0,(score-earliest)/maxf(1.0,earliest))
		var development: Dictionary = model.get("development",{})
		var development_score := 0.0
		if not development.is_empty(): development_score = minf(growth,float(development.growth_cap))*float(development.growth_factor)+clampf(float(int(development.age_origin)-age)*float(development.age_factor),0.0,float(development.age_cap))+minf(clampf(float(candidate.get("club_access",0)),0.0,100.0)*float(development.access_factor),float(development.access_cap))
		rows[-1]["development"] = {"eligible":eligible and not development.is_empty() and age >= int(development.get("minimum_age",0)) and age <= int(development.get("maximum_age",0)) and complete.size() >= int(development.get("minimum_complete_events",0)),"age":age,"complete_events":complete.size(),"earliest_total":earliest,"growth_fraction":growth,"score":snappedf(development_score,0.01)}
		var choice: Dictionary = model.get("station_choice",{})
		adjustments.append({"athlete_id":candidate.athlete_id,"score_adjustment":0.0,"station_choices":int(choice.get("high_choices",1)) if float(candidate.get("club_access",0)) >= float(choice.get("access_threshold",101)) else int(choice.get("base_choices",1)),"reason_code":"visible_club_advocacy"})
	rows.sort_custom(func(a,b):
		if a.eligible != b.eligible: return a.eligible
		if a.score != b.score: return a.score > b.score
		if a.free_score != b.free_score: return a.free_score > b.free_score
		return a.lottery_key < b.lottery_key if a.lottery_key != b.lottery_key else str(a.athlete_id) < str(b.athlete_id))
	var assignments := {}; var choices := {}; var stations: Array = []; var capacities := {}
	var calendar: Dictionary = context.get("bundle",{}).get("calendar",{})
	var quota: Dictionary = career.selection_state.get("jgp_base_quota_history",{}).get(str(calendar.get("season_id","")), {})
	var dynamic_slots := {}
	if kind == "jgp":
		if not quota.is_empty():
			dynamic_slots = preload("res://src/simulation/junior_grand_prix_quota_service.gd").station_slots(quota,str(selected.policy.federation),calendar.get("events",[]))
		for event in calendar.get("events",[]):
			if event.get("event_family") == "jgp_stage" and event.get("status") != "cancelled" and not event.get("reference_only",false):
				var current_month := "%04d-%02d" % [career.clock.year,(career.clock.quarter-1)*3+1]
				if str(event.end_date).substr(0,7) < current_month: continue
				if not quota.is_empty() and career.competition_timeline.get("mode") == "dated":
					if str(career.competition_timeline.date) > str(event.get("application_deadline", event.start_date)): continue
				stations.append(event)
				capacities[event.event_id] = mini(int(model.station_places),int(context.get("station_slots",{}).get(event.event_id,int(model.station_places))))
				if not quota.is_empty(): capacities[event.event_id] = int(dynamic_slots.get(event.event_id,0))
	var fields: Dictionary = context.get("station_fields",{})
	var staged: bool = kind == "jgp" and selected.status == "frozen" and model.get("second_start",{}).get("mode") == "after_first"
	var reserved_station_ids: Array = []
	if staged:
		stations = stations.filter(func(e):return int(capacities.get(e.event_id,0)) > 0)
		stations.sort_custom(func(a,b):return a.start_date < b.start_date)
		reserved_station_ids = stations.slice(maxi(1,stations.size()/2)).map(func(e):return e.event_id)
		stations = stations.slice(0,maxi(1,stations.size()/2))
	var fields_status := "provided" if not fields.is_empty() else "not_required"
	var prior_starts := {}
	if kind == "jgp":
		for id in career.selection_state.assignments:
			prior_starts[id] = []
			for event_id in career.selection_state.assignments[id]:
				if str(event_id).begins_with("isu_jgp_") and not str(event_id).contains("final"):
					prior_starts[id].append(event_id)
					if capacities.has(event_id): capacities[event_id] = maxi(0,capacities[event_id]-1)
		for event_id in career.selection_state.get("jgp",{}).get("events",{}):
			for result in career.selection_state.jgp.events[event_id]:
				var id: String = result.athlete_id
				if not prior_starts.has(id): prior_starts[id] = []
				if not prior_starts[id].has(event_id): prior_starts[id].append(event_id)
	# Field strength only participates in an actual station choice. Keep policy,
	# evidence validation, ranking and prior-start audit even when no seat is usable.
	if kind == "jgp" and fields.is_empty() and available_slots > 0:
		var dispatchable := false
		for row in rows:
			var previous: Array = prior_starts.get(row.athlete_id,[])
			if not row.eligible or previous.size() >= int(model.max_starts): continue
			if stations.any(func(e): return int(capacities[e.event_id]) > 0 and not previous.has(e.event_id)):
				dispatchable = true
				break
		if dispatchable:
			fields = station_fields(career,stations)
			fields_status = "computed"
	var selection_order := rows.duplicate()
	var development_id := ""
	var merit_places := int(model.get("development",{}).get("merit_places",0))
	if kind == "jgp" and available_slots > merit_places:
		var merit: Array = rows.filter(func(r): return r.eligible).slice(0,merit_places)
		var development: Array = rows.filter(func(r): return r.development.eligible and not merit.has(r))
		development.sort_custom(func(a,b): return a.development.score > b.development.score if a.development.score != b.development.score else rows.find(a) < rows.find(b))
		if not development.is_empty():
			development_id = development[0].athlete_id
			selection_order.erase(development[0])
			selection_order.insert(mini(merit_places,selection_order.size()),development[0])
	for row in selection_order:
		var previous: Array = prior_starts.get(row.athlete_id,[])
		if kind == "jgp" and previous.size() >= int(model.max_starts):
			row.reason_codes = ["jgp_two_start_limit"]
			continue
		if not row.eligible or assignments.size() >= available_slots: continue
		if kind == "world_junior":
			assignments[row.athlete_id] = ["isu_world_junior_%d" % (year+1)]
		else:
			var options: Array = stations.filter(func(e): return int(capacities[e.event_id]) > 0 and not previous.has(e.event_id))
			options.sort_custom(func(a,b): return World.stable_seed("%d:%s:%s" % [seed,row.athlete_id,a.event_id]) < World.stable_seed("%d:%s:%s" % [seed,row.athlete_id,b.event_id]))
			if options.is_empty(): continue
			var choice: Dictionary = model.station_choice
			var accessible := options.slice(0,int(choice.high_choices) if row.club_access >= float(choice.access_threshold) else int(choice.base_choices))
			accessible.sort_custom(func(a,b): return float(fields.get(a.event_id,0)) < float(fields.get(b.event_id,0)))
			var first: Dictionary = accessible[0]
			var assigned: Array = [first.event_id]; capacities[first.event_id] -= 1
			choices[row.athlete_id] = {"event_id":first.event_id,"field_strength":fields.get(first.event_id,0),"considered_ids":accessible.map(func(e): return e.event_id)}
			# A second start is earned by the same ranking, with remaining slots.
			for event in options:
				if staged: break
				if assigned.size() + previous.size() >= int(model.max_starts): break
				if event.event_id != first.event_id and capacities[event.event_id] > 0:
					assigned.append(event.event_id); capacities[event.event_id] -= 1; break
			assignments[row.athlete_id] = assigned
		row.reason_codes = ["selected_by_development_observation" if row.athlete_id == development_id else "selected_by_published_rank"]
	var alternates := {}
	var station_starts := {}
	if kind == "jgp" and not quota.is_empty():
		for event in stations:
			var station_id: String = event.event_id
			if int(dynamic_slots[station_id]) <= 0: continue
			station_starts[station_id] = event.start_date
			alternates[station_id] = selection_order.filter(func(row):
				return row.eligible and not assignments.get(row.athlete_id,[]).has(station_id)).map(func(row): return row.athlete_id)
	return {"assignments":assignments,"audit":{"public_formula":Policy.public_formula(selected.policy,kind),"policy":{"policy_id":selected.policy.policy_id,"season_id":selected.policy.season_id,"content_sha256":selected.content_sha256,"status":selected.status},"designated_event_ids":designated.duplicate(),"candidate_rows":rows,"association_adjustments":adjustments,"station_choices":choices,"station_fields":fields,"station_fields_status":fields_status,"remaining_station_slots":capacities,"reserved_station_ids":reserved_station_ids,"hidden_replacement":false,"seed":seed,"available_slots":available_slots,"station_alternates":alternates,"station_starts":station_starts,"station_slot_policy":"非官方游戏政策：按当季实际举行分站的日期分配基础配额" if not quota.is_empty() else ""},"errors":[]}

static func replace_with_frozen_alternate(career, event_id: String, removed_id: String) -> Dictionary:
	var state: Dictionary = career.selection_state
	var decision: Dictionary = state.get("decisions",{}).get("jgp",{}).get("decision",{})
	var lists: Dictionary = decision.get("audit",{}).get("station_alternates",{})
	if not lists.has(event_id) or not state.assignments.get(removed_id,[]).has(event_id): return {}
	state.assignments[removed_id].erase(event_id)
	var start := str(decision.audit.get("station_starts",{}).get(event_id,""))
	var expired: bool = not start.is_empty() and career.competition_timeline.get("mode") == "dated" and str(career.competition_timeline.date) >= start
	var substitution_cutoff := str(state.get("jgp_second_start",{}).get("substitution_deadlines",{}).get(event_id,""))
	if not substitution_cutoff.is_empty() and career.competition_timeline.get("mode") == "dated": expired = str(career.competition_timeline.date) > substitution_cutoff
	var excluded: Array = [removed_id]
	for receipt in state.get("jgp_replacements",[]):
		if receipt.event_id == event_id: excluded.append(receipt.removed_id)
	var replacement := ""
	for id in ([] if expired else lists[event_id]):
		if excluded.has(id) or state.assignments.get(id,[]).has(event_id): continue
		if id != "player" and career.world_athletes.get(id,{}).get("status","missing") != "active": continue
		var starts: Array = state.assignments.get(id,[]).filter(func(station):
			return lists.has(station) or (str(station).begins_with("isu_jgp_") and not str(station).contains("final")))
		for prior_event in state.get("jgp",{}).get("events",{}):
			if not starts.has(prior_event) and state.jgp.events[prior_event].any(func(row): return row.get("athlete_id") == id):
				starts.append(prior_event)
		if starts.size() >= 2: continue
		if not state.assignments.has(id): state.assignments[id] = []
		state.assignments[id].append(event_id)
		replacement = str(id)
		break
	var receipt := {"event_id":event_id,"removed_id":removed_id,"promoted_id":replacement,"clock":career.clock.to_dict(),"source_kind":"game_setting"}
	if not state.has("jgp_replacements"): state.jgp_replacements = []
	state.jgp_replacements.append(receipt)
	return receipt

static func station_fields(career, stations: Array) -> Dictionary:
	var result := {}
	var clone = load("res://src/domain/career_state.gd").from_dict(career.to_dict())
	for event in stations:
		var roster: Dictionary = load("res://src/simulation/formal_roster_generator.gd").build(clone,event,0)
		var total := 0.0; var count := 0
		for row in roster.get("roster",[]):
			if row.is_player: continue
			total += float(row.athlete.technique.rotation); count += 1
		result[event.event_id] = snappedf(total / maxf(1,count),0.001)
	return result

static func candidates_from_archives(career, kind: String, include_opponents: bool = true) -> Array:
	var year := Bundle.season_year(career)
	var selected := Policy.target(career,kind,year)
	if not selected.errors.is_empty() or selected.target.is_empty(): return []
	var model: Dictionary = selected.target
	var age: int = year-career.athlete.birth_year
	var candidates := {"player":{"athlete_id":"player","name":career.athlete.display_name,"age":age,"federation":"CHN","eligible":age >= int(model.minimum_age) and age <= int(model.maximum_age),"club_access":career.athlete.resources.ice_access,"results":[]}}
	if include_opponents:
		var rules_batch: Dictionary = load("res://src/simulation/formal_roster_generator.gd")._programme_rules(year,"junior")
		for id in career.world_athletes:
			var npc: Dictionary = career.world_athletes[id]
			if npc.get("federation") != "CHN": continue
			var npc_age := year - int(npc.athlete.birth_year) - (1 if str(npc.get("birth_date", "")).substr(5) > "07-01" else 0)
			var program_ready: bool = load("res://src/simulation/formal_roster_generator.gd")._competition_ready(npc,year,"junior",rules_batch)
			candidates[id] = {"athlete_id":id,"name":npc.get("name",id),"age":npc_age,"federation":"CHN","eligible":npc_age >= int(model.minimum_age) and npc_age <= int(model.maximum_age) and npc.get("status","active") == "active" and program_ready,"club_access":npc.athlete.resources.ice_access,"results":[]}
	var designated: Array = model.designated_event_ids
	for archive in career.competition_archive:
		if archive.get("status") != "complete" or not designated.has(archive.get("event_id")): continue
		for row in archive.get("final_standings",[]):
			if candidates.has(row.athlete_id) and row.has("total_score"):
				var result: Dictionary = row.duplicate(true); result.event_id = archive.event_id
				result["event_start_date"] = str(archive.get("event",{}).get("start_date",archive.event_id))
				if archive.get("short_results") is Dictionary and archive.get("free_results") is Dictionary:
					result.complete_result = archive.short_results.has(row.athlete_id) and archive.free_results.has(row.athlete_id)
					result.completeness_source = "actual_segment_records"
				else: result.completeness_source = "legacy_score_summary_unverified"
				candidates[row.athlete_id].results.append(result)
	return candidates.values()

static func designated_events(kind: String,year: int,career = null) -> Array:
	var selected := Policy.target(career,kind,year)
	return selected.target.get("designated_event_ids",[]).duplicate()
