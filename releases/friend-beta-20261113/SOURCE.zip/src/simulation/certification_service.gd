class_name CertificationService
extends RefCounted

const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")

# Game-side readiness heuristic, not a claim about an official grading rubric.
const APPLICATION_THRESHOLD := 45.0
const PASS_THRESHOLD := 58.0

static func assess(career) -> Dictionary:
	var athlete = career.athlete
	var jump_scores: Array[float] = []
	for jump_id in athlete.jumps:
		var jump = athlete.jumps[jump_id]
		var evidence: Dictionary = Dictionary(jump.attempt_evidence.get("double", {}))
		var attempts := int(evidence.get("attempts", 0))
		var clean_rate := float(evidence.get("clean_successes", 0)) / maxf(1.0, float(attempts))
		var jump_readiness := 0.0
		if int(jump.unlocked_rotations) >= 2:
			jump_readiness = 28.0 + float(jump.proficiency.get("double", 0.0)) * 0.32 + clean_rate * 25.0 + float(jump.consistency.get("training", 0.0)) * 0.15
		jump_scores.append(clampf(jump_readiness, 0.0, 100.0))
	jump_scores.sort()
	jump_scores.reverse()
	var jumps := 0.0
	for index in mini(3, jump_scores.size()): jumps += jump_scores[index] / 3.0
	var skating := (float(athlete.skating.speed) + float(athlete.skating.one_foot_stability) + float(athlete.skating.deep_edge)) / 3.0
	var program := 0.0
	var legal_count := 0
	for segment in ["short", "free"]:
		var saved: Dictionary = Dictionary(career.active_programs.get(segment, {}))
		var loaded = SkatingProgram.from_dict(saved) if not saved.is_empty() else null
		if loaded != null:
			program += 0.35 * clampf(float(loaded.whole_run_familiarity), 0.0, 100.0)
			var legal_teaching := ProgramValidator.validate(loaded, athlete, InternalEventRules.for_teaching_group(segment)).is_empty()
			var legal_formal := ProgramValidator.validate(loaded, athlete, InternalEventRules.for_season(maxi(2018,career.clock.season_start_year()),"junior",segment)).is_empty()
			if legal_teaching or legal_formal:
				legal_count += 1
				program += 15.0
	var health := clampf(100.0 - float(athlete.body.acute_fatigue) * 0.5 - float(athlete.body.cumulative_fatigue) * 0.3 - float(athlete.body.ankle_load) * 0.2, 0.0, 100.0)
	var readiness := jumps * 0.48 + skating * 0.15 + program * 0.27 + health * 0.10
	var missing: Array[String] = []
	if legal_count < 2: missing.append("短节目和自由滑尚未达到内部教学组要求")
	if jumps < 45.0: missing.append("两周跳训练证据尚不充分")
	if program < 38.0: missing.append("节目整套熟悉度不足")
	var status := "ready" if readiness >= PASS_THRESHOLD and missing.is_empty() else "developing"
	if float(athlete.body.acute_fatigue) >= 75.0 or float(athlete.body.ankle_load) >= 75.0:
		status = "health_deferred"
		missing.append("当前疲劳或关节负荷过高，暂缓等级考核")
	return {"status":status, "readiness":readiness, "evidence":{"jumps":jumps, "skating":skating, "program":program, "health":health, "legal_programs":legal_count}, "missing":missing}

static func process_quarter(career) -> Dictionary:
	var assessment := assess(career)
	if int(career.certification_state.get("national_technical_grade", 0)) >= 7: return assessment
	if career.clock.year - career.athlete.birth_year < 10: return assessment
	var clock: Dictionary = career.clock.to_dict()
	var history: Array = career.certification_state.get("history", [])
	if history.any(func(entry): return Dictionary(entry.get("clock", {})) == clock): return assessment
	if assessment.status == "developing" and float(assessment.readiness) < APPLICATION_THRESHOLD: return assessment
	var outcome := "passed" if assessment.status == "ready" else ("health_deferred" if assessment.status == "health_deferred" else "not_passed")
	var record := {"clock":clock, "outcome":outcome, "readiness":float(assessment.readiness), "evidence":Dictionary(assessment.evidence).duplicate(true), "missing":Array(assessment.missing).duplicate(true)}
	history.append(record)
	career.certification_state.history = history
	career.certification_state.last_assessment = record.duplicate(true)
	career.history.append({
		"category":"technical_grade_review", "target":"national_technical_grade",
		"delta":7.0 if outcome == "passed" else 0.0, "clock":clock, "outcome":outcome,
		"summary_key":"技术等级考核：%s" % outcome, "cause_codes":["game_readiness_review"],
	})
	if outcome == "passed": career.certification_state.national_technical_grade = 7
	return assessment
