class_name FormalSegmentSimulator
extends RefCounted

const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const ProgramPerformanceSimulator = preload("res://src/simulation/program_performance_simulator.gd")
const FormalTechnicalPanel = preload("res://src/simulation/formal_technical_panel.gd")
const FormalJudgingPanel = preload("res://src/simulation/formal_judging_panel.gd")
const CompetitionRoutePlanner = preload("res://src/simulation/competition_route_planner.gd")
const CompetitionRouteExecutor = preload("res://src/simulation/competition_route_executor.gd")
const ProgramLoadEstimator = preload("res://src/simulation/program_load_estimator.gd")

static func simulate(athlete, program, strategy: Dictionary, context: Dictionary, rules: Dictionary, seed: int) -> Dictionary:
	var segment_rules: Dictionary = Dictionary(rules.get("segment_rules", {}))
	var scoring_catalog: Dictionary = Dictionary(rules.get("scoring_catalog", {}))
	var validation_errors := ProgramValidator.validate(program, athlete, segment_rules)
	if not validation_errors.is_empty(): return _error(seed, validation_errors)
	var route_config := {
		"complexity": program.route_complexity,
		"choreography_quality": program.choreography_quality,
		"starting_fatigue":float(context.get("starting_fatigue",0.0)),
	}
	var route_plan := CompetitionRoutePlanner.plan(athlete, program, route_config, seed ^ 0x31A5)
	var performance_context := context.duplicate(true)
	performance_context.event_scope = "formal"
	performance_context.scoring_catalog = scoring_catalog
	performance_context.segment_rules = segment_rules
	performance_context.entry_pressure_by_element = route_plan.entry_pressure_by_element
	performance_context.program_load = ProgramLoadEstimator.estimate_segment(program, athlete, context)
	var performance_rng := RandomNumberGenerator.new()
	performance_rng.seed = seed
	var performance := ProgramPerformanceSimulator.simulate(athlete, program, strategy, performance_context, performance_rng)
	var technical_context: Dictionary = Dictionary(context.get("panel_context", {})).duplicate(true)
	technical_context.segment_rules = segment_rules
	var technical_review := FormalTechnicalPanel.resolve(
		performance, scoring_catalog, Dictionary(context.get("reputation", {})),
		technical_context, seed ^ 0x4D2B,
	)
	var duration_seconds := float(segment_rules.get("duration_seconds",160.0 if program.segment == "short" else 210.0))
	var route_execution := CompetitionRouteExecutor.execute(route_plan, performance, athlete, {
		"starting_fatigue": float(performance_context.get("starting_fatigue", 0.0)),
		"familiarity": program.whole_run_familiarity,
		"duration_seconds":duration_seconds,
	})
	var presentation := _presentation(athlete, program, performance, route_execution, context)
	var judges: Array = context.get("judge_profiles", _neutral_judges())
	var protocol := FormalJudgingPanel.score(performance, technical_review, presentation, scoring_catalog, judges, seed ^ 0x7721)
	if not protocol.get("errors",[]).is_empty(): return _error(seed,protocol.errors)
	_annotate_protocol(protocol,program,performance,technical_review)
	return {
		"record_version": 1, "seed": seed,
		"snapshot": {"athlete": athlete.to_dict(), "program": program.to_dict(), "strategy": strategy.duplicate(true), "context": context.duplicate(true)},
		"performance": performance, "technical_review": technical_review,
		"score": protocol.duplicate(true), "route_execution": route_execution,
		"route_source": {"version":1,"duration_seconds":duration_seconds},
		"protocol": protocol, "errors": [],
		"program_load": performance_context.program_load,
	}

static func _annotate_protocol(protocol: Dictionary, program, performance: Dictionary, technical_review: Dictionary) -> void:
	var planned_by_id := {}; var actual_by_id := {}; var final_by_id := {}
	for element in program.elements: planned_by_id[element.element_id] = element.to_dict()
	for element in performance.get("elements",[]): actual_by_id[str(element.get("element_id",""))] = element
	for element in technical_review.get("final_elements",[]): final_by_id[str(element.get("element_id",""))] = element
	for score in protocol.get("element_scores",[]):
		var element_id := str(score.get("element_id",""))
		var actual: Dictionary = actual_by_id.get(element_id,{})
		var final_call: Dictionary = final_by_id.get(element_id,{})
		score.planned_element = Dictionary(planned_by_id.get(element_id,{})).duplicate(true)
		score.actual_execution = {"abbreviation":str(actual.get("abbreviation","")),"parts":Array(actual.get("parts",[])).duplicate(true),"fall":bool(actual.get("actual",{}).get("fall",false))}
		score.recovery_decision = Dictionary(actual.get("recovery_decision",{})).duplicate(true)
		score.final_call = {"abbreviation":str(final_call.get("abbreviation","")),"info":Array(final_call.get("info",[])).duplicate(),"invalid_reason":str(final_call.get("invalid_reason",""))}

static func _presentation(athlete, program, performance: Dictionary, route: Dictionary, context: Dictionary = {}) -> Dictionary:
	# These are game-model estimates, not a replacement for an ISU judge's marks.
	# Technical difficulty belongs in TES; it must not gate artistic ability.
	var disruption := float(performance.get("falls", 0))
	var observed_falls := 0
	for element in performance.get("elements", []):
		if bool(element.get("actual", {}).get("fall", false)):
			observed_falls += 1
		elif str(element.get("status", "")) == "error":
			disruption += 0.25
	disruption = maxf(disruption, float(observed_falls))
	var metrics: Dictionary = route.get("actual_metrics", {})
	var balance := float(metrics.get("balance", 50.0))
	var coverage := float(metrics.get("coverage", 50.0))
	var recognition := clampf(float(context.get("pcs_recognition", 0.0)), 0.0, 0.4)
	var skating: Dictionary = athlete.skating
	var expression := float(athlete.mind.expression)
	var choreography := float(program.choreography_quality)
	var familiarity := float(program.whole_run_familiarity)
	return {
		"skating_skills": clampf((float(skating.deep_edge)*0.3 + float(skating.flow)*0.2 + float(skating.speed)*0.15 + float(skating.one_foot_stability)*0.15 + float(skating.knee_action)*0.1 + float(skating.ice_efficiency)*0.1)/10.0 + recognition - disruption*0.12, 0.25, 10.0),
		"transitions": clampf((float(skating.turns)*0.65 + float(skating.one_foot_stability)*0.2 + float(skating.flow)*0.15)/10.0 + recognition - disruption*0.25, 0.25, 10.0),
		"performance": clampf((expression*0.65 + float(athlete.mind.competition_composure)*0.15 + float(athlete.mind.motivation)*0.1 + familiarity*0.1)/10.0 + recognition - disruption*0.7, 0.25, 10.0),
		"composition": clampf((choreography*0.65 + balance*0.2 + coverage*0.15)/10.0 + recognition - disruption*0.2, 0.25, 10.0),
		"interpretation": clampf((expression*0.65 + choreography*0.25 + familiarity*0.1)/10.0 + recognition - disruption*0.45, 0.25, 10.0),
		"presentation": clampf((expression*0.6 + float(athlete.mind.competition_composure)*0.15 + choreography*0.15 + familiarity*0.1)/10.0 + recognition - disruption*0.55, 0.25, 10.0),
	}

static func recognition_from_archives(archives: Array, athlete_id: String) -> float:
	var marks: Array[float] = []
	var counted_events := 0
	for index in range(archives.size()-1,-1,-1):
		var archive: Dictionary = archives[index]
		if str(archive.get("status", "")) != "complete": continue
		var prior_marks := marks.size()
		for segment in ["short", "free"]:
			var record: Dictionary = archive.get(segment+"_results", {}).get(athlete_id, {})
			var score: Dictionary = record.get("score", {})
			if not score.has("pcs"): continue
			var factor := 4.0 if segment == "short" else 8.0
			marks.append(float(score.pcs)/factor - float(score.get("deductions", 0.0))*0.25)
		if marks.size() == prior_marks: continue
		counted_events += 1
		if counted_events >= 6: break
	if marks.size() < 4: return 0.0
	var mean := 0.0
	for mark in marks: mean += mark/float(marks.size())
	var variation := 0.0
	for mark in marks: variation += absf(mark-mean)/float(marks.size())
	return snappedf(clampf((mean-5.5)*0.12 - variation*0.08, 0.0, 0.4), 0.001)

static func _neutral_judges() -> Array[Dictionary]:
	var judges: Array[Dictionary] = []
	for index in 9: judges.append({"judge_id": "J%d" % [index + 1], "technical_bias": 0.0, "pcs_bias": 0.0, "affinity": 0.0})
	return judges

static func _error(seed: int, errors: Array) -> Dictionary:
	return {"record_version": 1, "seed": seed, "snapshot": {}, "performance": {}, "technical_review": {}, "score": {}, "route_execution": {}, "protocol": {}, "errors": errors.duplicate()}
