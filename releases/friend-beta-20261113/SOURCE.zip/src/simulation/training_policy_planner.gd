class_name TrainingPolicyPlanner
extends RefCounted

const TrainingPlan = preload("res://src/domain/training_plan.gd")
const PlanProposal = preload("res://src/domain/plan_proposal.gd")
const ConflictScanner = preload("res://src/simulation/conflict_scanner.gd")
const EffectiveTrainingCalculator = preload("res://src/simulation/effective_training_calculator.gd")

static func build(career, policy, _catalog: Dictionary) -> Dictionary:
	var mode := "more_aggressive" if policy.risk_attitude == "aggressive" else ("safer" if policy.risk_attitude == "cautious" or policy.policy_id == "recovery" else "accept")
	var intent = load("res://src/domain/training_intent.gd").create(mode).intent
	var built: Dictionary = load("res://src/simulation/coach_training_plan_service.gd").build(career,intent,policy.to_dict())
	if built.plan == null: return {"plan":null,"reasons":built.errors,"forecast":{},"conflicts":[]}
	var plan = built.plan
	var volume := EffectiveTrainingCalculator.calculate(career, plan)
	var conflicts: Array = ConflictScanner.scan(career, PlanProposal.create(plan))
	var jump_attempt_total := 0
	for attempts in volume.jump_attempts.values(): jump_attempt_total += int(attempts)
	var load_band := "高" if policy.risk_attitude == "aggressive" or plan.jump_units() >= 6 else ("低" if plan.shares.rest >= 30 else "中")
	var reasons: Array[String] = [_policy_reason(policy.policy_id)]
	reasons.append_array(built.reasons)
	if not policy.focus_jumps.is_empty(): reasons.append("重点照顾%s" % _focus_names(policy.focus_jumps))
	career.last_training_policy = policy.to_dict()
	career.last_generated_plan = plan.to_dict()
	return {
		"plan": plan,
		"reasons": reasons,
		"forecast": {
			"progress_focus": policy.focus_jumps.duplicate(), "load_band": load_band,
			"expected_attempt_band": [maxi(0, jump_attempt_total - 10), jump_attempt_total + 10],
			"adult_objection": not conflicts.is_empty(),
		},
		"conflicts": conflicts,
	}

static func _template(policy_id: String, focus_jumps: Array[String]) -> Dictionary:
	var shares := {"skating_foundation": 30, "jump_toe_loop": 10, "jump_salchow": 5, "jump_loop": 0, "jump_flip": 0, "jump_lutz": 0, "jump_axel": 5, "rotation": 15, "conditioning": 15, "rest": 20}
	if policy_id == "balanced_foundation" and not focus_jumps.is_empty():
		for jump_id in TrainingPlan.JUMP_LABELS: shares["jump_%s" % jump_id] = 0
		var focus_share := 15 if focus_jumps.size() == 1 else 10
		for jump_id in focus_jumps: shares["jump_%s" % jump_id] = focus_share
		var remainder := 20 - focus_share * focus_jumps.size()
		var support_jump := "axel" if not focus_jumps.has("axel") else "toe_loop"
		shares["jump_%s" % support_jump] += remainder
	if policy_id == "technique_rebuild":
		shares = {"skating_foundation": 35, "jump_toe_loop": 5, "jump_salchow": 5, "jump_loop": 5, "jump_flip": 5, "jump_lutz": 5, "jump_axel": 5, "rotation": 10, "conditioning": 10, "rest": 15}
	elif policy_id == "competition_stability":
		shares = {"skating_foundation": 20, "jump_toe_loop": 5, "jump_salchow": 5, "jump_loop": 5, "jump_flip": 5, "jump_lutz": 5, "jump_axel": 5, "rotation": 10, "conditioning": 15, "rest": 25}
	elif policy_id == "recovery":
		shares = {"skating_foundation": 25, "jump_toe_loop": 5, "jump_salchow": 5, "jump_loop": 0, "jump_flip": 0, "jump_lutz": 0, "jump_axel": 0, "rotation": 5, "conditioning": 20, "rest": 40}
	elif policy_id == "rotation_push":
		shares = {"skating_foundation": 20, "jump_toe_loop": 0, "jump_salchow": 0, "jump_loop": 0, "jump_flip": 0, "jump_lutz": 0, "jump_axel": 0, "rotation": 20, "conditioning": 15, "rest": 15}
		var selected: Array = focus_jumps if not focus_jumps.is_empty() else ["toe_loop", "salchow"]
		var each := 30 if selected.size() == 1 else 15
		for jump_id in selected: shares["jump_%s" % jump_id] = each
	return shares

static func _apply_risk(shares: Dictionary, policy) -> void:
	if policy.focus_jumps.is_empty() or policy.policy_id == "recovery": return
	var focus_key := "jump_%s" % policy.focus_jumps[0]
	if policy.risk_attitude == "aggressive" and int(shares.rest) >= 10:
		shares.rest -= 5; shares[focus_key] += 5
	elif policy.risk_attitude == "cautious" and int(shares.get(focus_key, 0)) >= 5:
		shares[focus_key] -= 5; shares.rest += 5

static func _targets_for(shares: Dictionary, policy) -> Dictionary:
	var targets := {}
	for jump_id in TrainingPlan.JUMP_LABELS:
		if int(shares.get("jump_%s" % jump_id, 0)) > 0:
			targets[jump_id] = int(policy.target_rotations.get(jump_id, 1))
	return targets

static func _policy_reason(policy_id: String) -> String:
	return {"balanced_foundation": "兼顾基本功、跳跃与恢复", "rotation_push": "集中资源推进目标周数", "technique_rebuild": "优先修整技术结构", "competition_stability": "增加完整动作的稳定训练", "recovery": "降低冲击并恢复身体状态"}.get(policy_id, "按当前方针安排训练")

static func _focus_names(focus_jumps: Array[String]) -> String:
	var names: Array[String] = []
	for jump_id in focus_jumps: names.append(TrainingPlan.JUMP_LABELS[jump_id])
	return "、".join(names)
