class_name TrainingFocusCompiler
extends RefCounted

const Plan = preload("res://src/domain/training_plan.gd")
const Direction = preload("res://src/domain/training_direction.gd")

static func compile(career, base_plan, direction: Dictionary, foundation_floors: Dictionary = {}) -> Dictionary:
	var error := Direction.validate(direction)
	if not error.is_empty(): return {"plan":null,"errors":[error],"reasons":[],"focus_states":[],"conflicts":[]}
	var plan = Plan.from_dict(base_plan.to_dict())
	var reasons: Array = []
	var states: Array = []
	var focused := {}
	var jump_focus_count := 0
	var expression_reserve := 0
	var protected_shares := foundation_floors.duplicate(true)
	var bonus_donors: Array = []
	# Automatic planning may reuse a nonselected jump's bonus, never its 5%
	# maintenance. Direct/manual callers retain their existing allocation rules.
	if not foundation_floors.is_empty():
		var selected := {}
		for focus in direction.focuses:
			for part in focus.get("target",{}).get("parts",[]): selected["jump_"+str(part.jump_id)] = true
		for id in Plan.JUMP_LABELS:
			if not selected.has("jump_"+str(id)): bonus_donors.append("jump_"+str(id))
	for focus in direction.focuses:
		if focus.kind in ["new_difficulty","recovery"] or (focus.kind == "execution" and focus.target.get("kind") == "jump"): jump_focus_count += 1
		if focus.kind == "musical_expression": expression_reserve = mini(5,maxi(0,int(plan.shares.skating_foundation)-5))
		if focus.kind == "spin": protected_shares.rotation = int(base_plan.shares.rotation)
		if focus.kind in ["skating_edges","steps"]: protected_shares.skating_foundation = int(base_plan.shares.skating_foundation)
	var conflicts: Array = []
	if jump_focus_count > 1:
		conflicts.append({"resource":"jump_specialist_lessons","priority":direction.priority})
		reasons.append("两个跳跃重点共用专项课时；均衡时分别推进，优先某项时将本期专项课集中给它，另一项仍保留基础维护")
	var remaining_blocks := 2
	var existing_actions := {}
	for specialist in plan.specialist_targets:
		existing_actions[preload("res://src/domain/technical_repertoire.gd").action_id(specialist.action)] = true
	var focus_order: Array = range(direction.focuses.size())
	if direction.priority == "second": focus_order.reverse()
	elif direction.priority == "balanced" and (career.clock.year*4+career.clock.quarter-1)%2 == 1:
		focus_order.reverse()
	if direction.priority == "balanced" and direction.focuses.size() == 2:
		reasons.append("均衡模式在课时不足时按训练期轮换先安排的重点；另一项保留基础维护，不额外加量")
	for focus_index in focus_order:
		var focus: Dictionary = direction.focuses[focus_index]
		var external_quality: float = preload("res://src/simulation/external_training_service.gd").quality_for(career,focus)
		if external_quality > 1.0:
			var categories: Array = []
			if focus.target.get("kind") == "jump":
				for part in focus.target.parts: categories.append("jump_"+str(part.jump_id))
			elif focus.kind == "musical_expression": categories.append("expression")
			elif focus.kind == "spin": categories.append("rotation")
			elif focus.kind in ["skating_edges","steps"]: categories.append("skating_foundation")
			elif focus.target.has("segment"): categories.append("program_"+str(focus.target.segment))
			for category in categories: plan.lesson_quality[category] = maxf(float(plan.lesson_quality.get(category,1.0)),external_quality)
			reasons.append("%s采用已预约的外训专项指导；替代原课程，不增加尝试预算、不保证突破" % focus.id)
		if focus.kind == "recovery":
			var history_id: String = preload("res://src/domain/technical_repertoire.gd").action_id(focus.target)
			var entry: Dictionary = career.technical_repertoire.entries.get(history_id,{})
			if not bool(entry.get("learned_history",{}).get("ever_learned",false)):
				return {"plan":null,"errors":["只能恢复曾经掌握、有历史记录的动作"],"reasons":reasons,"focus_states":states,"conflicts":conflicts}
			# An explicit single-jump recovery lesson is about that old action,
			# not the harder automatic target. Medical review still runs later.
			if focus.target.get("parts",[]).size() == 1:
				var recovered_part: Dictionary = focus.target.parts[0]
				if int(recovered_part.rotations) <= int(career.athlete.jumps[recovered_part.jump_id].unlocked_rotations):
					plan._jump_rotations[recovered_part.jump_id] = int(recovered_part.rotations)
		if focus.kind in ["execution","program_connections"] and focus.target.get("kind") != "jump":
			var segment := str(focus.target.get("segment",""))
			if not segment in ["short","free"] or career.active_programs.get(segment,{}).is_empty():
				return {"plan":null,"errors":["请先选择已有的短节目或自由滑"],"reasons":reasons,"focus_states":states,"conflicts":conflicts}
			var allocated := false
			if remaining_blocks > 0:
				for donor in ["conditioning","skating_foundation","rotation"]+bonus_donors:
					var minimum := maxi(int(protected_shares.get(donor,5)),5+expression_reserve if donor == "skating_foundation" else 5)
					if int(plan._shares.get(donor,0)) >= minimum+5:
						plan._shares[donor] -= 5
						plan._shares["program_"+segment] += 5
						remaining_blocks -= 1
						allocated = true
						break
			states.append({"id":focus.id,"stage":"practice" if allocated else "maintenance"})
			if allocated and focus.kind == "program_connections": plan.focus_lessons["connections_"+segment] = 5.0
			reasons.append("%s：%s，不自动改节目" % [focus.id,"增加整套专项练习，使用现有课时" if allocated else "本期专项额度不足，维持原有节目练习"])
			continue
		if focus.kind in ["spin","skating_edges","steps"]:
			var destination := "rotation" if focus.kind == "spin" else "skating_foundation"
			var allocated := false
			if remaining_blocks > 0:
				for donor in ["conditioning","skating_foundation","rotation"]+bonus_donors:
					if donor == destination: continue
					var minimum := maxi(int(protected_shares.get(donor,5)),5+expression_reserve if donor == "skating_foundation" else 5)
					if int(plan._shares.get(donor,0)) >= minimum+5:
						plan._shares[donor] -= 5
						plan._shares[destination] += 5
						protected_shares[destination] = int(plan._shares[destination])
						remaining_blocks -= 1
						allocated = true
						break
			states.append({"id":focus.id,"stage":"practice" if allocated else "maintenance"})
			if allocated and focus.kind == "steps": plan.focus_lessons.steps = 5.0
			reasons.append("%s：%s，恢复与六类跳跃维护不变" % [focus.id,"调整一份现有课程用于专项" if allocated else "本期可调整额度不足，保留原有练习"])
			continue
		if focus.kind == "musical_expression":
			# Five existing skating percentage points become expressive movement
			# lessons, not five new points on top of the curriculum.
			plan.expression_share = mini(5,maxi(0,int(plan.shares.skating_foundation)-5))
			states.append({"id":focus.id,"stage":"practice"})
			reasons.append("音乐表达使用滑行课程中的专项课时，不依赖已编排节目，也不额外增加训练量")
			continue
		if not focus.kind in ["new_difficulty","recovery","execution"]: continue
		var action_id: String = preload("res://src/domain/technical_repertoire.gd").action_id(focus.target)
		if existing_actions.has(action_id):
			reasons.append("%s沿用已有专项尝试额度；培养重点仍会调整现有课程，不另建尝试池" % focus.id)
		var requested_blocks := 1
		if jump_focus_count > 1 and direction.priority != "balanced":
			var preferred := 0 if direction.priority == "first" else 1
			requested_blocks = 2 if focus_index == preferred else 0
		var preparing := false
		var combination_ready: bool = focus.target.parts.size() > 1
		for part in focus.target.parts:
			var id: String = part.jump_id
			# The existing coach readiness sets the safe working rotation. A distant
			# goal changes emphasis, never bypasses foundation or medical checks.
			preparing = preparing or int(part.rotations) > int(plan.jump_rotations.get(id,1))
			combination_ready = combination_ready and int(part.rotations) <= int(career.athlete.jumps[id].unlocked_rotations) and int(part.rotations) <= int(plan.jump_rotations.get(id,1))
			if requested_blocks == 0 or focused.has(id): continue
			focused[id] = true
			for block in mini(requested_blocks,remaining_blocks):
				var allocated := false
				for donor in ["skating_foundation","conditioning","rotation"]+bonus_donors:
					var minimum := maxi(int(protected_shares.get(donor,5)),5+expression_reserve if donor == "skating_foundation" else 5)
					if int(plan._shares.get(donor,0)) >= minimum+5:
						plan._shares[donor] -= 5
						plan._shares["jump_"+id] += 5
						remaining_blocks -= 1
						allocated = true
						break
				if not allocated: reasons.append("可调整课时不足，本期保留基础维护，不额外增加负荷")
		if combination_ready and requested_blocks > 0:
			if not existing_actions.has(action_id): plan.specialist_targets.append({"action":focus.target.duplicate(true),"allocated_attempt_budget":16,"priority":100})
			existing_actions[action_id] = true
		elif focus.target.parts.size() > 1:
			preparing = true
		states.append({"id":focus.id,"stage":"preparation" if preparing else "practice"})
		reasons.append("%s专项使用原有课时；%s" % [focus.id,"先练当前基础，不记录尚未开始的目标动作尝试" if preparing else "保持教练核定的实际练习周数"])
	return {"plan":plan,"errors":[],"reasons":reasons,"focus_states":states,"conflicts":conflicts}
