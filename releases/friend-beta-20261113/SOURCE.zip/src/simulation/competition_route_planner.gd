class_name CompetitionRoutePlanner
extends RefCounted

const COMPLEXITY_TARGETS := {"simple": 30.0, "standard": 48.0, "rich": 68.0, "extreme": 86.0}

static func plan(athlete, program, route_config: Dictionary, seed: int) -> Dictionary:
	var complexity := str(route_config.get("complexity", "standard"))
	if not COMPLEXITY_TARGETS.has(complexity): complexity = "standard"
	var target := float(COMPLEXITY_TARGETS[complexity])
	var capacity := snappedf(
		float(athlete.skating.get("turns", 0.0)) * 0.30
		+ float(athlete.skating.get("one_foot_stability", 0.0)) * 0.25
		+ float(athlete.skating.get("deep_edge", 0.0)) * 0.20
		+ float(athlete.skating.get("flow", 0.0)) * 0.15
		+ float(athlete.skating.get("ice_efficiency", 0.0)) * 0.10,
		0.01,
	)
	var overload := maxf(0.0, target - capacity)
	var choreography_quality := clampf(float(route_config.get("choreography_quality", program.choreography_quality)), 0.0, 100.0)
	var transitions := 0.0
	for element in program.elements: transitions += element.entry_difficulty * 100.0
	transitions /= maxi(1, program.elements.size())
	var effective := clampf(target * 0.35 + capacity * 0.25 + choreography_quality * 0.15 + program.whole_run_familiarity * 0.15 + transitions * 0.10 - float(route_config.get("starting_fatigue", 0.0)) * 0.25, 12.0, 90.0)
	var rng := RandomNumberGenerator.new(); rng.seed = seed
	var phase_x := rng.randf_range(0.0, TAU)
	var phase_y := rng.randf_range(0.0, TAU)
	var point_count := maxi(18, program.elements.size() * 7 + int(effective / 6.0))
	var points: Array[Dictionary] = []
	for index in point_count:
		var progress := float(index) / float(point_count - 1)
		var x := 0.5 + sin(progress * TAU * (2.0 + effective / 32.0) + phase_x) * 0.40
		var y := 0.5 + sin(progress * TAU * (1.0 + effective / 58.0) + phase_y) * 0.40
		points.append({"x": snappedf(clampf(x, 0.06, 0.94), 0.0001), "y": snappedf(clampf(y, 0.06, 0.94), 0.0001), "progress": snappedf(progress, 0.0001)})
	var segments: Array[Dictionary] = []
	for index in points.size() - 1: segments.append({"from": index, "to": index + 1})
	var anchors: Array[Dictionary] = []
	var element_count := maxi(1, program.elements.size())
	for index in program.elements.size():
		var element = program.elements[index]
		var progress := float(index + 1) / float(element_count + 1)
		anchors.append(_anchor(element.element_id, 0, progress, points.size()))
		var primary: Dictionary = anchors.back()
		primary.entry_edge = element.planned_entry
		primary.kind = element.kind
		if not element.ice_anchor.is_empty():
			var point: Dictionary = points[primary.point_index]
			point.x = float(element.ice_anchor.x); point.y = float(element.ice_anchor.y)
			point.progress = progress
		primary.x = float(points[primary.point_index].x)
		primary.y = float(points[primary.point_index].y)
		for part_index in element.combination_parts.size():
			var part := _anchor(element.element_id, part_index + 1, minf(0.98, progress + 0.030 * float(part_index + 1)), points.size())
			part.entry_edge = "connected"; part.kind = "jump"
			# A combination shares a local corridor, never a distant route lobe.
			part.x = clampf(primary.x + 0.025 * (part_index + 1), 0.06, 0.94)
			part.y = clampf(primary.y - 0.012 * (part_index + 1), 0.06, 0.94)
			anchors.append(part)
	# Explicit action positions are route knots, so the marker reaches them exactly.
	for anchor in anchors:
		points.append({"x":anchor.x,"y":anchor.y,"progress":anchor.progress})
	for index in anchors.size():
		var start: Dictionary = anchors[index]
		if int(start.part_index) != 0: continue
		var last := start
		for candidate in anchors:
			if candidate.element_id == start.element_id: last = candidate
		if last == start: continue
		for point in points:
			if point.progress >= start.progress and point.progress <= last.progress:
				var weight := inverse_lerp(start.progress,last.progress,point.progress)
				point.x = lerpf(start.x,last.x,weight)
				point.y = lerpf(start.y,last.y,weight)
	points.sort_custom(func(a,b): return a.progress < b.progress)
	segments.clear()
	for index in points.size() - 1: segments.append({"from":index,"to":index + 1})
	var speed := float(athlete.skating.get("speed", 20.0))
	var coverage := clampf(42.0 + speed * 0.28 + choreography_quality * 0.18 + target * 0.12, 20.0, 96.0)
	var pressure: Dictionary = {}
	for element in program.elements:
		pressure[element.element_id] = snappedf(overload * 0.34 + maxf(0.0, float(program.elements.size() - 5)) * 0.7, 0.01)
	return {
		"points": points, "segments": segments, "action_anchors": anchors,
		"planned_metrics": {
			"coverage": snappedf(coverage, 0.01), "balance": snappedf(clampf(72.0 + choreography_quality * 0.16 - overload * 0.12, 20.0, 96.0), 0.01),
			"repetition": snappedf(clampf(30.0 - target * 0.22, 4.0, 28.0), 0.01), "direction_changes": maxi(4, int(target / 6.0)),
		},
		"entry_pressure_by_element": pressure,
		"complexity_assessment": {"level": complexity, "target": target, "capacity": capacity, "effective": effective, "overload": snappedf(overload, 0.01)},
	}

static func _anchor(element_id: String, part_index: int, progress: float, point_count: int) -> Dictionary:
	return {"element_id": element_id, "part_index": part_index, "progress": snappedf(progress, 0.0001), "point_index": clampi(int(round(progress * float(point_count - 1))), 0, point_count - 1)}
