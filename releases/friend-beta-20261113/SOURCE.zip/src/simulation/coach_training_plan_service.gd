class_name CoachTrainingPlanService
extends RefCounted

const TrainingPlan = preload("res://src/domain/training_plan.gd")
const TrainingIntent = preload("res://src/domain/training_intent.gd")
const FOUNDATION_FLOORS := {"rotation":10,"skating_foundation":10,"conditioning":5}

const BASE_SHARES := {
	"skating_foundation":25,
	"jump_toe_loop":5, "jump_salchow":5, "jump_loop":5,
	"jump_flip":5, "jump_lutz":5, "jump_axel":5,
	"rotation":15, "conditioning":10, "rest":20,
	"program_short":0, "program_free":0,
}

static func build(career, intent: TrainingIntent, policy_context: Dictionary = {}) -> Dictionary:
	if career == null or career.athlete == null or intent == null:
		return {"plan":null, "errors":["无法为当前生涯生成训练计划"], "reasons":[]}
	# All automatic entry points use this builder. Resolve saved route goals
	# here as well as for callers that explicitly supply a policy context.
	if policy_context.is_empty() and not career.development_roadmap.is_empty():
		var roadmap = preload("res://src/domain/development_roadmap.gd").from_dict(career.development_roadmap)
		if roadmap != null:
			var evaluation := preload("res://src/simulation/development_roadmap_evaluator.gd").evaluate(career,roadmap)
			var adapted := preload("res://src/simulation/roadmap_training_adapter.gd").build_policy(career,roadmap,evaluation)
			if adapted.policy != null: policy_context = adapted.policy.to_dict()
	var shares: Dictionary = BASE_SHARES.duplicate(true)
	var reasons: Array[String] = ["教练保留滑行、六类跳跃、旋转、体能与恢复的完整课程"]
	var targets := _maintenance_targets(career,policy_context.get("target_rotations",{}))
	match intent.mode:
		"safer":
			shares.skating_foundation = 30; shares.rotation = 10; shares.conditioning = 5; shares.rest = 25
			reasons.append("你要求更稳妥，教练增加恢复与滑行基础，仍不放弃任何跳跃类别")
		"more_aggressive":
			shares.skating_foundation = 20; shares.rotation = 20; shares.conditioning = 15; shares.rest = 15
			reasons.append("你要求加快节奏，教练增加转体和体能，但保留最低恢复量")
		"requested_element":
			var parsed := _parse_element(intent.element_id)
			if not parsed.ok: return {"plan":null, "errors":[parsed.error], "reasons":reasons}
			var eligibility := _eligible(career, parsed.jump_id, parsed.rotations)
			if not eligibility.ok: return {"plan":null, "errors":[eligibility.error], "reasons":reasons}
			shares.skating_foundation -= 5; shares["jump_%s" % parsed.jump_id] += 5
			targets[parsed.jump_id] = parsed.rotations
			reasons.append("你提出把%s加入重点，教练同意用少量滑行额度换取专项尝试，同时保留原有恢复量" % TrainingPlan.JUMP_LABELS[parsed.jump_id])
		"accept": reasons.append("你接受了教练提出的均衡方案")
		_: return {"plan":null, "errors":["未知训练回应：%s" % intent.mode], "reasons":reasons}
	# Existing programmes reserve their real rehearsal before optional extras.
	for segment in ["short", "free"]:
		if not Dictionary(career.active_programs.get(segment, {})).is_empty():
			_move_block(shares,"program_"+segment)
	_apply_route(career,shares,targets,reasons,policy_context)
	if intent.mode == "requested_element":
		var explicit := _parse_element(intent.element_id)
		targets[explicit.jump_id] = explicit.rotations
	_apply_coach_emphasis(career, shares, reasons)
	# Once programmes exist, rehearsal is part of ordinary coaching, not an
	# undisclosed requirement that the player discover another allocation screen.
	if int(shares.program_short)+int(shares.program_free) > 0:
		reasons.append("已有节目纳入日常合乐，逐步培养衔接、熟练度和表现；不占用六类跳跃及恢复课程")
	# Preserve the selected emphasis and every jump family, but make recovery
	# part of coaching rather than requiring repeated player micromanagement.
	var recovering := protect_recovery(career,shares,intent.mode == "more_aggressive")
	if recovering:
		reasons.append("近期疲劳偏高，教练自动增加恢复，保留六类跳跃的练习；身体缓过来后再恢复原节奏")
	var created := TrainingPlan.create(shares, targets)
	if created.plan == null: return {"plan":null,"errors":created.errors,"reasons":reasons,"intent":intent.to_dict()}
	created.plan.coach_decision = _apply_gap(career,created.plan,reasons,recovering or str(policy_context.get("policy_id","")) == "recovery" or intent.mode == "safer")
	shares = created.plan._shares
	if not recovering and str(career.development_roadmap.get("route_id","")) == "fast" and str(policy_context.get("policy_id","")) != "recovery" and intent.mode != "safer":
		var total_jump := 0
		for id in TrainingPlan.JUMP_LABELS: total_jump += int(shares.get("jump_"+id,0))
		var priorities: Array = _route_priorities(career,policy_context)
		if total_jump <= 45 and not priorities.is_empty():
			var chosen := str(priorities[int(career.coach_training_state.completed_periods)%priorities.size()])
			if TrainingPlan.JUMP_LABELS.has(chosen) and _move_block(shares,"jump_"+chosen):
				reasons.append("快速路线把一份可调基础课转为优先跳跃练习；恢复不减，六类基础仍保留，身体需要恢复时暂停这份加速课。")
	var gap_plan = created.plan
	var taught: Dictionary = preload("res://src/simulation/coach_lesson_service.gd").decorate(career,created.plan)
	created.plan = taught.plan
	reasons.append_array(taught.reasons)
	_attach_specialists(career,created.plan,reasons)
	var before_focus: Dictionary = created.plan.shares
	var focused: Dictionary = preload("res://src/simulation/training_focus_compiler.gd").compile(career,created.plan,career.training_direction,FOUNDATION_FLOORS)
	if not focused.errors.is_empty(): return {"plan":null,"errors":focused.errors,"reasons":reasons}
	reasons.append_array(focused.reasons)
	if not recovering and intent.mode != "safer":
		_protect_route_preparation(career,focused.plan,policy_context,reasons)
	_protect_minor_recovery(career,focused.plan,reasons)
	var review := review_load(career,focused.plan)
	preload("res://src/simulation/coach_lesson_service.gd").project_decision(gap_plan,review.adjusted_plan)
	if review.adjusted_plan.coach_decision.get("reason_codes",[]).has("consolidation_preparation") and int(review.adjusted_plan.shares.conditioning) < 15:
		review.adjusted_plan.coach_decision.reason_codes.erase("consolidation_preparation")
		review.adjusted_plan.coach_decision.reason_codes.append("gap_lesson_reduced")
		reasons = reasons.filter(func(reason): return not str(reason).begins_with("已学三周仍有身体准备缺口"))
	if not review.accepted:
		reasons.assign(review.reasons)
	if review.adjusted_plan.coach_decision.get("reason_codes",[]).has("gap_lesson_reduced"):
		reasons = reasons.filter(func(reason): return not ("本期增加" in str(reason) or "纳入专项" in str(reason)))
		reasons.append("部分补短板课程已按实际恢复或重点要求调整；以最终课程为准，不视为已完成进阶补练。")
	# Focus and body review may replace earlier optional allocations. Never
	# present a preliminary route/teacher transfer as an executed final lesson.
	var reallocated := false
	for category in before_focus:
		if int(review.adjusted_plan.shares.get(category,0)) < int(before_focus[category]): reallocated = true
	if reallocated:
		var allocation_prefixes := ["成长路线优先","教练发现","教练擅长","教练倾向","教练重视","教练偏重","快速路线把","你提出把"]
		reasons = reasons.filter(func(reason): return not allocation_prefixes.any(func(prefix): return str(reason).begins_with(prefix)))
		reasons.push_front("本期已按自主重点或身体限制重新分配课时；路线与教练的额外安排以最终课程为准。")
	return {"plan":review.adjusted_plan, "decision":review.adjusted_plan.coach_decision.duplicate(true), "errors":created.errors, "reasons":reasons, "intent":intent.to_dict(),"focus_states":focused.focus_states,"conflicts":focused.conflicts}

static func _protect_minor_recovery(career, plan, reasons: Array) -> void:
	var needs_recovery := false
	for injury in career.condition_state.injuries:
		if injury.get("status") == "active" and not bool(injury.get("rehabilitation_managed",false)) and float(injury.get("severity",1.0)) < 0.7: needs_recovery = true
	if not needs_recovery: return
	var changed := false
	for id in TrainingPlan.JUMP_LABELS:
		var key := "jump_"+str(id)
		var surplus := maxi(0,int(plan._shares[key])-5)
		if surplus == 0: continue
		plan._shares[key] -= surplus
		plan._shares.rest += surplus
		changed = true
	if changed: reasons.append("踝部轻伤恢复期，跳跃暂只保留各类维护，额外课时转为恢复；避免一边减效训练、一边始终达不到恢复条件。")

static func _protect_route_preparation(career, plan, context: Dictionary, reasons: Array) -> void:
	if career.development_roadmap.get("route_id","") != "fast" or context.get("policy_id","") == "recovery": return
	var has_triple_goal := false
	for goal in career.development_roadmap.get("milestones",[]):
		if int(goal.get("rotations",0)) == 3: has_triple_goal = true
	if not has_triple_goal: return
	var preparing := false
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		if id == career.development_roadmap.get("deferred_jump",""): continue
		if int(plan.jump_rotations.get(id,1)) < 3 and _triple_preparation(career,career.athlete.jumps[id]) < 54.0: preparing = true
		elif int(career.athlete.jumps[id].unlocked_rotations) >= 3:
			var readiness: Dictionary = preload("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,id,3)
			if readiness.gaps.has("physical_readiness_low"): preparing = true
	# Five ordinary triples are a foundation, not a ceiling. A selected 3A or
	# quad still needs its own preparation instead of endless capped doubles.
	for focus in career.training_direction.focuses:
		if focus.get("kind") != "new_difficulty": continue
		for part in focus.get("target",{}).get("parts",[]):
			var id: String = str(part.get("jump_id",""))
			var requested: int = int(part.get("rotations",0))
			if requested < 3 or not career.athlete.jumps.has(id) or int(plan.jump_rotations.get(id,1)) >= requested: continue
			var required := float(requested)*18.0+(9.0 if id == "axel" else 0.0)
			if _triple_preparation(career,career.athlete.jumps[id]) < required: preparing = true
	if not preparing: return
	var shares: Dictionary = plan._shares
	var donors: Array = ["skating_foundation","rotation"]
	for id in TrainingPlan.JUMP_LABELS: donors.append("jump_"+str(id))
	var changed := false
	for donor in donors:
		var floor_share := int(FOUNDATION_FLOORS.get(donor,5))
		while int(shares.conditioning) < 15 and int(shares.get(donor,0)) >= floor_share+5:
			shares[donor] -= 5
			shares.conditioning += 5
			changed = true
	if changed: reasons.append("三周准备尚不足，本期保留15%体能准备课，用可调基础课和额外跳跃课替换；恢复和各类基础练习保留。")

static func _triple_preparation(career, jump) -> float:
	var body: Dictionary = career.athlete.body
	var foundation: Dictionary = career.athlete.jump_foundation.to_dict()
	var physical := (float(body.strength_readiness)+float(body.joint_readiness))/2.0
	var technical := (float(foundation.air_axis)+float(foundation.rotation_completion)+float(foundation.landing_control))/3.0
	var execution := (float(jump.air.axis)+float(jump.landing.control))/2.0
	return physical*0.40+technical*0.30+execution*0.30

static func _move_block(shares: Dictionary, destination: String, protected: Dictionary = {}) -> bool:
	for donor in ["conditioning","rotation","skating_foundation"]:
		if donor == destination: continue
		if int(shares.get(donor,0)) >= maxi(int(FOUNDATION_FLOORS.get(donor,5)),int(protected.get(donor,5)))+5:
			shares[donor] -= 5
			shares[destination] += 5
			return true
	return false

static func _route_priorities(career, context: Dictionary) -> Array:
	var priorities: Array = Array(context.get("focus_jumps",career.development_roadmap.get("priority_jumps",[]))).duplicate()
	if not priorities.is_empty(): return priorities
	# Unspecified delegates to the coach. Respect an explicit postponement,
	# and never mutate the player's still-unspecified saved preference array.
	var deferred := str(career.development_roadmap.get("deferred_jump",""))
	for id in TrainingPlan.JUMP_LABELS:
		if str(id) == deferred: continue
		priorities.append(id)
		if priorities.size() == 2: break
	return priorities

static func _apply_route(career, shares: Dictionary, targets: Dictionary, reasons: Array, context: Dictionary) -> void:
	var route: Dictionary = career.development_roadmap
	var priorities: Array = _route_priorities(career,context)
	var policy := str(context.get("policy_id",""))
	if policy == "recovery":
		while int(shares.rest) < 40 and _move_block(shares,"rest"): pass
		# Explicit recovery is an exception to the normal automatic floor;
		# keep allowed maintenance and programme rehearsal, not optional volume.
		for donor in ["skating_foundation","rotation","conditioning"]:
			while int(shares.rest) < 40 and int(shares.get(donor,0)) >= 10:
				shares[donor] -= 5
				shares.rest += 5
		reasons.append("恢复方针保留允许的基础课，恢复至少占本期四成")
		return
	if route.is_empty() and context.is_empty(): return
	var target_requests: Dictionary = context.get("target_rotations",{})
	for id in priorities.slice(0,2):
		if not TrainingPlan.JUMP_LABELS.has(id): continue
		var blocks := 3 if policy == "rotation_push" and priorities.size() == 1 else 1
		for block in blocks:
			if _move_block(shares,"jump_"+str(id)):
				reasons.append("成长路线优先%s，增加现有专项课时，其余跳跃保留" % TrainingPlan.JUMP_LABELS[id])
		if target_requests.has(id):
			# A policy's distant goal changes emphasis, never skips readiness.
			targets[id] = mini(int(targets[id]),maxi(1,int(target_requests[id])))
	if str(route.get("route_id","")) == "steady" or policy == "competition_stability":
		_move_block(shares,"rest")
	if str(route.get("route_id","")) == "steady":
		_consolidate_declared_breadth(career,targets,priorities,reasons)

static func _consolidate_declared_breadth(career, targets: Dictionary, priorities: Array, reasons: Array) -> void:
	var breadth := 0
	for goal in career.development_roadmap.get("milestones",[]):
		if int(goal.get("rotations",0)) == 3: breadth = maxi(breadth,int(goal.get("count",0)))
	var selected: Array = []
	# Already learned difficulty is never removed. Then keep a consistent
	# subset approaching this route's declared breadth, rather than rotating
	# all five into new difficulty while pretending to consolidate three.
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		if int(career.athlete.jumps[id].unlocked_rotations) >= 3: selected.append(id)
	var ranked: Array = ["toe_loop","salchow","loop","flip","lutz"]
	ranked.sort_custom(func(a,b):
		var a_progress := float(career.athlete.jumps[a].proficiency.triple)
		var b_progress := float(career.athlete.jumps[b].proficiency.triple)
		if not is_equal_approx(a_progress,b_progress): return a_progress > b_progress
		if priorities.has(a) != priorities.has(b): return priorities.has(a)
		return ranked_order(a) < ranked_order(b))
	for id in ranked:
		if selected.size() >= breadth: break
		if not selected.has(id): selected.append(id)
	for id in ranked:
		if not selected.has(id): targets[id] = mini(2,int(targets[id]))
	reasons.append("稳健路线先巩固约定的动作广度，其余类别保留基础练习；主动指定难度仍可另行争取。")

static func ranked_order(id: String) -> int:
	return ["toe_loop","salchow","loop","flip","lutz"].find(id)

static func _apply_gap(career, plan, reasons: Array, recovering: bool = false) -> Dictionary:
	var diagnosis: Dictionary = preload("res://src/simulation/training_gap_diagnoser.gd").inspect(career)
	var decision := {"period_key":"%d:%d" % [career.clock.year,career.clock.quarter],"coach_id":career.coach_assignment.coach_id,"gap_ids":[],"allocated_gap_ids":[],"reason_codes":[]}
	for row in diagnosis.candidates: decision.gap_ids.append(row.jump_id)
	if diagnosis.candidates.is_empty(): return decision
	var candidate: Dictionary = diagnosis.candidates[0]
	if int(plan.jump_rotations.get(candidate.jump_id,1)) < int(candidate.rotations):
		candidate = candidate.duplicate(true)
		candidate.stage = "preparation"
	var protected := {}
	for focus in career.training_direction.focuses:
		if focus.kind == "spin": protected.rotation = int(plan._shares.rotation)
		if focus.kind in ["skating_edges","steps","musical_expression"]: protected.skating_foundation = int(plan._shares.skating_foundation)
	var consolidation: bool = candidate.reason_codes.has("consolidation_gap")
	if consolidation and candidate.reason_codes.has("physical_readiness_low"):
		if not recovering:
			while int(plan._shares.conditioning) < 15 and _move_block(plan._shares,"conditioning",protected): pass
		if not recovering and int(plan._shares.conditioning) >= 15:
			decision.reason_codes.append("consolidation_preparation")
			reasons.append("已学三周仍有身体准备缺口，本期保留15%体能课；这不是已经完成三周巩固练习，也不授予技术进阶。")
		else:
			decision.reason_codes.append("gap_budget_unavailable")
		return decision
	var already_covered := int(plan._shares.get("jump_"+str(candidate.jump_id),0)) >= 10
	if already_covered or _move_block(plan._shares,"jump_"+str(candidate.jump_id),protected):
		decision.allocated_gap_ids.append(candidate.jump_id)
		decision.reason_codes.append("consolidation_gap" if consolidation and candidate.stage == "practice" else ("foundation_gap" if candidate.stage == "practice" else "foundation_preparation"))
		reasons.append("教练发现%s当前仍需巩固，%s%s课；不额外加量、不直接解锁" % [TrainingPlan.JUMP_LABELS[candidate.jump_id],"沿用现有专项安排" if already_covered else "本期增加","进阶练习" if candidate.stage == "practice" else "前置准备"])
	else:
		decision.reason_codes.append("gap_budget_unavailable")
		reasons.append("本期恢复和已选重点占满可调课时，短板暂保留基础维护")
	return decision

static func _apply_coach_emphasis(career, shares: Dictionary, reasons: Array) -> void:
	var profile: Dictionary = career.coach_assignment.technical_tendencies
	# Redistribute existing lessons, never grant technique or extra attempts for free.
	if float(profile.get("toe_jump_mechanics", 0.0)) > 0.1:
		if _move_block(shares,"jump_toe_loop"):
			reasons.append("教练擅长点冰技术，本期调整一份可用课程加强后外点冰；其他五类跳跃照常练习")
		if float(profile.get("load_aggression", 0.0)) > 0.2:
			if _move_block(shares,"jump_flip"):
				reasons.append("教练倾向技术推进，调整一份可用课程加强后内点冰；总训练量不增加")
	if float(profile.get("edge_foundation", 0.0)) > 0.1:
		if _move_block(shares,"skating_foundation"):
			reasons.append("教练重视用刃，调整一份可用课程加强滑行基础；不挤占最低旋转课")
		if float(profile.get("component_development", 0.0)) > 0.1 and _move_block(shares,"skating_foundation"):
			reasons.append("教练重视滑表，调整可用课程加强衔接与表达；基础旋转仍完整保留")
	if float(profile.get("load_aggression", 0.0)) <= -0.25:
		if _move_block(shares,"rest"):
			reasons.append("教练偏重长期培养，将一份可调课程转为恢复；不停止任何基础类别")

static func _attach_specialists(career, plan, reasons: Array) -> void:
	var candidates: Array = []
	for targets in career.season_program_plan.get("targets",{}).values():
		# Programme intentions mirror the selected focuses, not a competing
		# curriculum. The focus compiler owns their prerequisites and allocation.
		if not career.training_direction.focuses.is_empty(): continue
		if targets is Array:
			for target in targets:
				if target is Dictionary and target.get("action") is Dictionary:
					candidates.append({"action":target.action,"priority":100})
	for program in career.active_programs.values():
		for element in program.get("elements",[]):
			if element.get("kind") != "jump" or Array(element.get("combination_parts",[])).is_empty(): continue
			var parts: Array = [{"jump_id":element.jump_id,"rotations":element.rotations}]
			parts.append_array(element.combination_parts)
			candidates.append({"action":{"kind":"jump","parts":parts},"priority":50})
	var seen := {}
	var focused := {}
	var focus_blocks := 2 if career.training_direction.focuses.is_empty() else 0
	for candidate in candidates:
		var id: String = preload("res://src/domain/technical_repertoire.gd").action_id(candidate.action)
		if id.is_empty() or seen.has(id): continue
		seen[id] = true
		var ready := true
		for part in candidate.action.parts:
			var eligibility := _eligible(career,str(part.jump_id),int(part.rotations))
			if not eligibility.ok:
				ready = false
				reasons.append("%s暂不能成为专项：%s" % [id,eligibility.error])
				break
			if int(candidate.priority) >= 100:
				# A future combo first changes its constituent single curriculum.
				# It must not sit as a label until the unfocused default happens to
				# learn every prerequisite. The global budget/rest stays unchanged.
				plan._jump_rotations[part.jump_id] = maxi(int(plan.jump_rotations.get(part.jump_id,1)),int(part.rotations))
				if not focused.has(part.jump_id) and focus_blocks > 0:
					if _move_block(plan._shares,"jump_"+str(part.jump_id)):
						focused[part.jump_id] = true
						focus_blocks -= 1
			if candidate.action.parts.size() > 1 and int(career.athlete.jumps[part.jump_id].unlocked_rotations) < int(part.rotations):
				ready = false
				reasons.append("%s先补足其中单跳，再进入连跳专项" % id)
		if not ready: continue
		plan.specialist_targets.append({"action":candidate.action.duplicate(true),"allocated_attempt_budget":16,"priority":candidate.priority})
		if candidate.action.parts.size() == 1:
			var part: Dictionary = candidate.action.parts[0]
			plan._jump_rotations[part.jump_id] = int(part.rotations)
		reasons.append("%s纳入专项，使用现有跳跃训练额度，不额外增加总负荷" % id)

static func review_load(career, plan) -> Dictionary:
	var functions = preload("res://src/simulation/athlete_function_service.gd")
	var shares: Dictionary = plan.shares
	var targets: Dictionary = plan.jump_rotations
	var reasons: Array = []
	for jump_id in TrainingPlan.JUMP_LABELS:
		var rotation := int(targets.get(jump_id,1))
		while rotation >= 1 and not functions.action_constraints(career,{"kind":"jump","parts":[{"jump_id":jump_id,"rotations":rotation}]}).allowed:
			rotation -= 1
		if rotation < 1:
			shares.rest += int(shares["jump_"+jump_id])
			shares["jump_"+jump_id] = 0
			targets.erase(jump_id)
		else: targets[jump_id] = rotation
	for segment in ["short","free"]:
		if not preload("res://src/simulation/athlete_condition_service.gd")._program_allowed(career,career.active_programs.get(segment,{})):
			shares.rest += int(shares["program_"+segment])
			shares["program_"+segment] = 0
	for category in ["skating_foundation","rotation"]:
		var kind := "step_sequence" if category == "skating_foundation" else "spin"
		if not functions.action_constraints(career,{"kind":kind}).allowed:
			shares.rest += int(shares[category]); shares[category] = 0
	var adjusted = TrainingPlan.create(shares,targets).plan
	adjusted.expression_share = mini(plan.expression_share,maxi(0,int(shares.skating_foundation)-5))
	adjusted.lesson_quality = plan.lesson_quality.duplicate(true)
	adjusted.focus_lessons = plan.focus_lessons.duplicate(true)
	preload("res://src/simulation/coach_lesson_service.gd").project_decision(plan,adjusted)
	for target in plan.specialist_targets:
		if functions.action_constraints(career,target.action).allowed: adjusted.specialist_targets.append(target.duplicate(true))
	if adjusted.to_dict() != plan.to_dict(): reasons.append("身体限制已落实到课程：保留允许的基础练习，禁用动作改为恢复；相关功能复评后再恢复专项")
	return {"accepted":adjusted.to_dict() == plan.to_dict(),"adjusted_plan":adjusted,"reasons":reasons,"review_conditions":["复评受限功能并更新实际训练表现"] if not reasons.is_empty() else []}

static func protect_recovery(career, shares: Dictionary, aggressive: bool = false) -> bool:
	var body: Dictionary = career.athlete.body
	var stress := float(career.condition_state.psychology.get("stress",0.0))
	var recovery_efficiency := 1.0 - stress * 0.004
	var active_units := float(100 - int(shares.rest)) / 5.0
	var rest_units := float(shares.rest) / 5.0
	var next_acute := float(body.acute_fatigue) + active_units * 1.4 - rest_units * 4.0 * recovery_efficiency
	var next_cumulative := float(body.cumulative_fatigue) + active_units * 0.35 - rest_units * 1.5 * recovery_efficiency
	# React at the warning boundary, not well after the event system has begun
	# interrupting the athlete. Recovery must change the actual allocation.
	if float(body.ankle_load) >= 20.0 or float(body.impact_load) >= 15.0 or float(body.acute_fatigue) >= 18.0 or float(body.cumulative_fatigue) >= 12.0 or (not aggressive and (next_acute >= 18.0 or next_cumulative >= 12.0)):
		var recovery_share := 40 if stress >= 40.0 else 30
		var needed := maxi(0,recovery_share-int(shares.rest))
		for category in ["skating_foundation","rotation","conditioning"]:
			var moved := mini(needed,maxi(0,int(shares[category])-5))
			shares[category] -= moved
			shares.rest += moved
			needed -= moved
			if needed == 0: break
		return true
	return false

static func _maintenance_targets(career, explicit_targets: Dictionary = {}) -> Dictionary:
	var targets := {}
	for jump_id in TrainingPlan.JUMP_LABELS:
		var jump = career.athlete.jumps[jump_id]
		var learned := clampi(int(jump.unlocked_rotations),1,4)
		targets[jump_id] = learned
		# Revalidate foundations through real practice after medical withdrawal.
		# Never infer a recovered double from successful triples alone.
		var recovery_rotation := 0
		for item in career.technical_repertoire.entries.values():
			if item.get("state") != "unavailable" or not bool(item.get("learned_history",{}).get("ever_learned",false)): continue
			var parts: Array = item.action.parts
			if parts.size() != 1 or str(parts[0].jump_id) != str(jump_id): continue
			var rotations := int(parts[0].rotations)
			if rotations <= learned and (recovery_rotation == 0 or rotations < recovery_rotation): recovery_rotation = rotations
		if recovery_rotation > 0:
			targets[jump_id] = recovery_rotation
			continue
		if learned >= 4: continue
		var key: String = ["","single","double","triple"][learned]
		var evidence: Dictionary = jump.attempt_evidence[key]
		# Propose practice, not a free unlock. Each family keeps its own evidence;
		# actual attempts and maturation still determine whether it succeeds.
		if int(evidence.successes) < 5 or int(evidence.clean_successes) < 1 or float(jump.proficiency[key]) < 7.0: continue
		var next := learned+1
		if str(career.development_roadmap.get("deferred_jump","")) == str(jump_id) and not _explicit_difficulty(career,jump_id,next,explicit_targets): continue
		if next >= 4 or (jump_id == "axel" and next >= 3):
			if not _explicit_difficulty(career,jump_id,next,explicit_targets): continue
		var body: Dictionary = career.athlete.body
		var preparation := (float(body.strength_readiness)+float(body.joint_readiness))/2.0
		if next >= 3:
			var foundation: Dictionary = career.athlete.jump_foundation.to_dict()
			var technical := (float(foundation.air_axis)+float(foundation.rotation_completion)+float(foundation.landing_control))/3.0
			var execution := (float(jump.air.axis)+float(jump.landing.control))/2.0
			preparation = preparation*0.40 + technical*0.30 + execution*0.30
		var required := float(next)*18.0
		# Axel adds half a turn: keep it above ordinary triples without making
		# a chosen 3A wait for almost the same preparation as a four-turn jump.
		if jump_id == "axel" and next >= 3: required += 9.0
		if preparation < required: continue
		if next >= 3 and load("res://src/simulation/jump_maturation.gd").age_factor(career,jump_id,next) < 0.35: continue
		targets[jump_id] = next
	return targets

static func _explicit_difficulty(career, jump_id: String, rotations: int, requested: Dictionary) -> bool:
	if int(requested.get(jump_id,0)) >= rotations: return true
	for focus in career.training_direction.focuses:
		if focus.get("kind") != "new_difficulty" or focus.get("target",{}).get("kind") != "jump": continue
		for part in focus.target.get("parts",[]):
			if part.get("jump_id") == jump_id and int(part.get("rotations",0)) >= rotations: return true
	for targets in career.season_program_plan.get("targets",{}).values():
		if not targets is Array: continue
		for target in targets:
			for part in target.get("action",{}).get("parts",[]):
				if part.get("jump_id") == jump_id and int(part.get("rotations",0)) >= rotations: return true
	return false

static func _parse_element(element_id: String) -> Dictionary:
	var parts := element_id.split(":")
	if parts.size() != 3 or parts[0] != "jump" or not TrainingPlan.JUMP_LABELS.has(parts[1]) or not str(parts[2]).is_valid_int():
		return {"ok":false, "error":"动作编号无效，请选择明确的跳跃与周数"}
	var rotations := int(parts[2])
	if rotations < 1 or rotations > 4: return {"ok":false, "error":"目标周数必须为1至4周"}
	return {"ok":true, "jump_id":str(parts[1]), "rotations":rotations}

static func _eligible(career, jump_id: String, rotations: int) -> Dictionary:
	var jump = career.athlete.jumps[jump_id]
	# Existing learned rotations do not become ineligible because an old save
	# lacks lower-rotation evidence. Prerequisites gate NEW difficulty only.
	if rotations <= int(jump.unlocked_rotations): return {"ok":true}
	if rotations > int(jump.unlocked_rotations) + 1:
		return {"ok":false, "error":"%s还缺少前置周数的训练证据，不能直接加入本期计划" % TrainingPlan.JUMP_LABELS[jump_id]}
	if rotations > 1:
		var lower_key: String = ["", "single", "double", "triple"][rotations - 1]
		if int(jump.attempt_evidence[lower_key].successes) <= 0:
			return {"ok":false, "error":"%s还没有前置动作的成功训练证据" % TrainingPlan.JUMP_LABELS[jump_id]}
	return {"ok":true}
