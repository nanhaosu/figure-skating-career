class_name FocusSkaterService
extends RefCounted

static func select(session: Dictionary, career = null) -> Array[String]:
	var roster: Array = session.get("roster", [])
	var standings: Array = session.get("final_standings", session.get("short_standings", []))
	var player_rank := 0
	var federation := "CHN"
	for row in roster:
		if bool(row.get("is_player",false)): federation = str(row.get("federation","CHN"))
	for row in standings:
		if bool(row.get("is_player",false)): player_rank = int(row.get("rank",0))
	var social: Dictionary = career.social_state if career != null else {}
	var scored: Array[Dictionary] = []
	for row in roster:
		var id := str(row.get("athlete_id",""))
		if id.is_empty() or bool(row.get("is_player",false)) or id == "player": continue
		var priority := 0.0
		if Array(social.get("rival_ids",[])).has(id): priority += 100.0
		if career != null and career.relationships.has(id): priority += 60.0
		if str(row.get("federation","")) == federation: priority += 12.0
		for standing in standings:
			if str(standing.get("athlete_id","")) != id: continue
			var rank := int(standing.get("rank",99))
			if player_rank > 0: priority += maxf(0.0, 35.0 - absf(rank-player_rank)*5.0)
			if rank <= 3: priority += 24.0
			var cut := int(session.get("event",{}).get("competition_policy",{}).get("free_cut",24))
			if cut > 0 and absi(rank-cut) <= 1: priority += 20.0
		if bool(row.get("record_threat",false)) or bool(row.get("pb_candidate",false)): priority += 30.0
		if career != null:
			var player_pb := best_total(career.record_book)
			var rival_pb := best_total(career.world_athletes.get(id,{}).get("record_book",{}))
			if rival_pb > 0 and rival_pb >= player_pb: priority += 30.0
		scored.append({"id":id,"priority":priority})
	scored.sort_custom(func(a,b): return a.priority > b.priority if a.priority != b.priority else a.id < b.id)
	var ids: Array[String] = []
	for i in mini(5,scored.size()): ids.append(scored[i].id)
	return ids

static func best_total(book: Dictionary) -> float:
	var best := 0.0
	for era in book.get("international",{}).values(): best = maxf(best,float(era.get("total",{}).get("pb",0.0)))
	return best
