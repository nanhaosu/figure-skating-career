class_name InternalInvitationService
extends RefCounted

const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const TeachingCompetitionService = preload("res://src/simulation/teaching_competition_service.gd")

static func status(career) -> Dictionary:
	var missing: Array[String] = []
	var details: Dictionary = {}
	if career == null: return {"ready":false, "missing":["没有可参赛的生涯"], "details":{}, "invitation":"not_ready"}
	if str(career.internal_invitation_state.get("status", "")) == "completed" or _has_completed_match(career):
		return {"ready":false, "missing":["首次内部赛已完成"], "details":{}, "invitation":"completed"}
	for segment in ["short", "free"]:
		var stored: Dictionary = Dictionary(career.active_programs.get(segment, {}))
		var program = SkatingProgram.from_dict(stored) if not stored.is_empty() else null
		var errors := ProgramValidator.validate(program, career.athlete, InternalEventRules.for_teaching_group(segment))
		if not errors.is_empty():
			missing.append("%s未达到内部教学组要求" % ("短节目" if segment == "short" else "自由滑"))
			details[segment] = errors
		elif program.draft_status != "locked" or not program.locked_segments.has(segment):
			missing.append("%s仍是草稿，尚未锁定参赛" % ("短节目" if segment == "short" else "自由滑"))
			details[segment] = ["节目内容已合规，但还没有确认参赛版本"]
	if not career.competition_state.is_empty(): missing.append("已有进行中的比赛")
	var schedule := TeachingCompetitionService.evaluate(career)
	return {"ready":missing.is_empty() and bool(schedule.available), "missing":missing, "details":details, "invitation":str(career.internal_invitation_state.get("status", "not_ready")), "schedule":schedule}

static func ensure_offer(career) -> Dictionary:
	if _has_completed_match(career):
		career.internal_invitation_state.status = "completed"
		return status(career)
	var schedule := TeachingCompetitionService.evaluate(career)
	var current: String = str(career.internal_invitation_state.get("status", "not_ready"))
	if current == "deferred":
		var current_week := TeachingCompetitionService.elapsed_week(career)
		var offered_week := int(career.internal_invitation_state.get("offered_week",-1))
		var last_deferred_week := int(career.internal_invitation_state.get("last_deferred_week",offered_week))
		var deferred_until := int(career.internal_invitation_state.get("deferred_until_week",offered_week + 1))
		# Reopening the same screen must not immediately undo the player's defer.
		# A later training week may offer the event again until it is completed.
		if current_week <= last_deferred_week or current_week < deferred_until:
			return status(career)
	if bool(schedule.available) and ["not_ready", "deferred"].has(current):
		career.internal_invitation_state.status = "pending"
	return status(career)

static func defer(career) -> Dictionary:
	ensure_offer(career)
	if str(career.internal_invitation_state.status) == "pending":
		career.internal_invitation_state.status = "deferred"
		var current_week := TeachingCompetitionService.elapsed_week(career)
		career.internal_invitation_state["last_deferred_week"] = current_week
		career.internal_invitation_state["deferred_until_week"] = mini(TeachingCompetitionService.LATEST_WEEK, current_week + 6)
	return status(career)

static func accept(career) -> Dictionary:
	ensure_offer(career)
	if status(career).ready and ["pending", "deferred"].has(str(career.internal_invitation_state.status)):
		career.internal_invitation_state.status = "accepted"
	return status(career)

static func complete(career) -> void:
	career.internal_invitation_state.status = "completed"

static func _has_completed_match(career) -> bool:
	return career.history.any(func(entry): return str(entry.get("category", "")) == "internal_competition")
