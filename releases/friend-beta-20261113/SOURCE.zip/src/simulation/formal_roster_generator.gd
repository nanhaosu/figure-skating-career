class_name FormalRosterGenerator
extends RefCounted

const WorldGenerationService = preload("res://src/simulation/world_generation_service.gd")
const SeasonBundleRepository = preload("res://src/content/season_bundle_repository.gd")
const AthleteState = preload("res://src/domain/athlete_state.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const InternalEventRules = preload("res://src/content/internal_event_rules.gd")
const Identity = preload("res://src/domain/athlete_identity.gd")

static func build(career, event: Dictionary, seed: int, target_size: int = 34, include_player: bool = true) -> Dictionary:
	var gp_final := preload("res://src/simulation/senior_grand_prix_service.gd").supports_final(event)
	var final_event: bool = gp_final or event.get("event_family", "") in ["jgp_final","club_league_final"]
	var senior_gp: bool = preload("res://src/simulation/senior_grand_prix_service.gd").supports(event)
	var pandemic_gp: bool = preload("res://src/simulation/pandemic_grand_prix_service.gd").supports(event)
	var senior_worlds: bool = preload("res://src/simulation/senior_championship_service.gd").supports(event)
	var beijing_trial: bool = event.get("event_family") == "beijing_trial"
	var beijing_olympic: bool = event.get("event_id") == "isu_owg2022"
	if not final_event and not senior_gp and not pandemic_gp and not senior_worlds and not beijing_trial and not beijing_olympic and (target_size < 30 or target_size > 38):
		return {"roster": [], "created_athletes": {}, "errors": ["正式青年女单阵容必须为30至38人"]}
	if career == null or career.athlete == null:
		return {"roster": [], "created_athletes": {}, "errors": ["缺少玩家生涯数据"]}
	if str(event.get("event_id", "")).is_empty():
		return {"roster": [], "created_athletes": {}, "errors": ["缺少正式比赛资料"]}
	var season_year := int(event.get("ruleset_season_start_year", 2018))
	var level := str(event.get("competition_level",preload("res://src/simulation/competitive_level_service.gd").event_level(career,event)))
	var bundle := SeasonBundleRepository.load_bundle(season_year, "women_singles", level if season_year >= 2020 else "junior")
	if not bundle.errors.is_empty(): return {"roster":[], "created_athletes":{}, "errors":bundle.errors}
	var existing_ids: Array = career.world_athletes.keys()
	var ensured := WorldGenerationService.ensure_season(career, bundle, int(career.world_state.get("world_seed", career.seed)))
	if not ensured.errors.is_empty(): return {"roster":[], "created_athletes":{}, "errors":ensured.errors}
	var profiles: Dictionary = bundle.federation_profiles.duplicate(true)
	var quota_jgp: bool = season_year == 2022 and event.get("event_family") == "jgp_stage"
	if season_year == 2022 and event.get("event_family") in ["jgp_stage","jgp_final"]:
		var previous := SeasonBundleRepository.load_bundle(2021,"women_singles","senior")
		if not previous.errors.is_empty(): return {"roster":[],"created_athletes":{},"errors":previous.errors}
		for federation in previous.federation_profiles:
			if not profiles.has(federation): profiles[federation] = previous.federation_profiles[federation].duplicate(true)
	# The domestic catalog admits MAC, whose small pool shares the HKG
	# aggregate model until a separate historical profile is available.
	profiles["MAC"] = profiles.HKG.duplicate(true)
	var allowed := _admitted_federations(event, profiles)
	var rules_batch := _programme_rules(season_year,level)
	if event.has("scoring_rule"):
		for segment in ["short","free"]:
			var resolved := SeasonBundleRepository.rules_for_event_level(event,segment,"women_singles",level)
			if not resolved.errors.is_empty(): return {"roster":[],"created_athletes":{},"errors":resolved.errors}
			rules_batch.segments[segment] = resolved.rules
	var stage_filter := Callable()
	if event.get("event_family") == "jgp_stage" and not (beijing_olympic or beijing_trial or senior_worlds or pandemic_gp or senior_gp):
		stage_filter = func(record):
			var assigned: Array = career.selection_state.assignments.get(record.athlete_id, [])
			return (record.federation != career.story_context.home_federation or assigned.has(event.event_id)) and _stage_available(career,record,event)
	var persistent := _eligible_persistent_pool(career.world_athletes, allowed, season_year,level,rules_batch,stage_filter)
	if beijing_olympic: return _olympic_field(career,event,persistent,existing_ids,seed,include_player)
	if beijing_trial:
		var trials = load("res://src/simulation/beijing_trial_service.gd")
		var prepared: Dictionary = trials.prepare(career,bundle)
		if not prepared.ok: return {"roster":[],"created_athletes":{},"errors":[prepared.error]}
		var state: Dictionary = career.beijing_trial_series
		if include_player and state.player_choice != "enrolled": return {"roster":[],"created_athletes":{},"errors":["尚未报名北京选拔系列"]}
		var withdrawn: Array = state.withdrawals.get("player",[])
		if include_player and withdrawn.has(event.event_id): return {"roster":[],"created_athletes":{},"errors":["本场已主动退赛"]}
		var selected_trials: Array[Dictionary] = []
		for record in persistent:
			if state.entrant_ids.has(record.athlete_id) and not state.withdrawals.get(record.athlete_id,[]).has(event.event_id): selected_trials.append(record)
		if selected_trials.is_empty() and not include_player: return {"roster":[],"created_athletes":{},"errors":["没有符合条件的选拔参赛者"],"world_unavailable":true,"reason_code":"no_trial_entrants"}
		return _assemble(career,selected_trials,existing_ids,seed,include_player)
	if senior_worlds:
		var championship = preload("res://src/simulation/senior_championship_service.gd")
		var decision: Dictionary = championship.preview(career,event,persistent)
		if not decision.errors.is_empty(): return {"roster":[],"created_athletes":{},"errors":decision.errors,"world_unavailable":not include_player and decision.get("reason_code") == "country_quota_unknown","reason_code":decision.get("reason_code","")}
		if include_player and not decision.selected.any(func(row):return row.athlete_id == "player"):
			return {"roster":[],"created_athletes":{},"errors":["未同时满足世锦赛个人资格与国内派遣条件"]}
		# A withdrawn player leaves a place for the next qualified compatriot;
		# this does not overwrite the original published selection decision.
		var field: Dictionary = decision if include_player else championship.allocate_for_event(career,event,decision.audit.candidate_rows.filter(func(row):return row.athlete_id != "player"))
		var selected_worlds: Array[Dictionary] = []
		for row in field.selected:
			if row.athlete_id == "player": continue
			var found: Array = persistent.filter(func(record):return record.athlete_id == row.athlete_id)
			if found.size() != 1: return {"roster":[],"created_athletes":{},"errors":["已派遣选手不在有效持久名单中"]}
			selected_worlds.append(found[0])
		if selected_worlds.is_empty() and not include_player: return {"roster":[],"created_athletes":{},"errors":["没有具备可核对个人资格的锦标赛参赛者"],"world_unavailable":true,"reason_code":"no_evidenced_championship_field"}
		championship.commit(career,decision)
		championship.record_milano_dispatch(career,field)
		return _assemble(career,selected_worlds,existing_ids,seed,include_player)
	if pandemic_gp:
		var local := preload("res://src/simulation/pandemic_grand_prix_service.gd").preview(career,event)
		if not local.errors.is_empty() or (include_player and not local.eligible): return {"roster":[],"created_athletes":{},"errors":["不符合该站疫情本地邀请条件"]}
		persistent = persistent.filter(func(record):return preload("res://src/simulation/pandemic_grand_prix_service.gd").local_record(record,local.host))
		persistent.sort_custom(func(a,b):return str(a.athlete_id) < str(b.athlete_id))
		var local_rows: Array[Dictionary] = []
		local_rows.assign(persistent.slice(0,maxi(0,target_size-(1 if include_player else 0))))
		if local_rows.is_empty() and not include_player: return {"roster":[],"created_athletes":{},"errors":["没有可核对的本地参赛选手"]}
		return _assemble(career,local_rows,existing_ids,seed,include_player)
	if senior_gp:
		var invitation := preload("res://src/simulation/senior_grand_prix_service.gd").preview(career,event)
		if not invitation.errors.is_empty() or (include_player and not invitation.invited): return {"roster":[],"created_athletes":{},"errors":["尚未获得该站成年大奖赛邀请"]}
		var selected_gp: Array[Dictionary] = []
		for id in invitation.plan.fields.get(event.event_id,[]):
			if id == "player": continue
			var found: Array = persistent.filter(func(record):return record.athlete_id == id)
			if found.size() != 1: return {"roster":[],"created_athletes":{},"errors":["大奖赛邀请选手不在本场可用名单中"]}
			selected_gp.append(found[0])
		invitation = preload("res://src/simulation/senior_grand_prix_service.gd").commit(career,event)
		if not invitation.errors.is_empty(): return {"roster":[],"created_athletes":{},"errors":invitation.errors}
		if int(event.ruleset_season_start_year) == 2022 and not include_player and selected_gp.size() < 2:
			return {"roster":[],"created_athletes":{},"errors":["本站有效邀请选手不足"],"world_unavailable":not include_player}
		return _assemble(career,selected_gp,existing_ids,seed,include_player)
	if gp_final:
		var final := preload("res://src/simulation/senior_grand_prix_service.gd").commit_final(career,event)
		var ids: Array = final.qualified_ids
		if not final.complete or (include_player and not ids.has("player")):
			return {"roster":[],"created_athletes":{},"errors":["成年大奖赛总决赛缺少完整分站积分或参赛资格"],"world_unavailable":not include_player}
		var selected: Array[Dictionary] = []
		for record in persistent:
			if ids.has(record.athlete_id): selected.append(record)
		if selected.size() + (1 if include_player else 0) < 2:
			return {"roster":[],"created_athletes":{},"errors":["总决赛可参赛选手不足"],"world_unavailable":not include_player}
		return _assemble(career,selected,existing_ids,seed,include_player)
	# Home international delegations are closed lists. The foreign world pool
	# fills remaining places, subject to published stage assignments/start limits.
	# Finals instead use their exact qualification identities below.
	if event.get("event_family") == "world_junior":
		persistent = persistent.filter(func(record): return record.federation != career.story_context.home_federation or career.selection_state.assignments.get(record.athlete_id,[]).has(event.event_id))
	if final_event:
		var ids: Array = career.selection_state.get("jgp",{}).get("qualified_ids",[]) if event.event_family == "jgp_final" else load("res://src/simulation/season_calendar_planner.gd").club_league_standings(career).qualified_ids
		if ids.size() < 6:
			if not include_player: return {"roster":[],"created_athletes":{},"errors":["总决赛须使用完整已晋级名单"],"world_unavailable":true,"reason_code":"no_evidenced_final_field"}
			return {"roster":[],"created_athletes":{},"errors":["总决赛须使用完整已晋级名单"]}
		if include_player and not ids.has("player"): return {"roster":[],"created_athletes":{},"errors":["总决赛须使用完整已晋级名单"]}
		var final_rows: Array[Dictionary] = []
		for id in ids:
			if id == "player": continue
			var found: Array = persistent.filter(func(record): return record.athlete_id == id)
			if found.size() != 1: return {"roster":[],"created_athletes":{},"errors":["晋级运动员不在有效世界名单中"]}
			final_rows.append(found[0])
		return _assemble(career,final_rows,existing_ids,seed,include_player)
	var autonomous_field := preload("res://src/simulation/opponent_season_schedule_service.gd").field_covered(career,event)
	if autonomous_field:
		var requesting: Array[Dictionary] = []
		for record in persistent:
			var participation: Dictionary = preload("res://src/simulation/opponent_season_schedule_service.gd").participates(career,record,event)
			if not participation.get("errors",[]).is_empty(): return {"roster":[],"created_athletes":{},"errors":participation.errors}
			if participation.allowed: requesting.append(record)
		persistent = requesting
	var rng := RandomNumberGenerator.new()
	rng.seed = WorldGenerationService.stable_seed("%d:%s" % [int(career.world_state.world_seed), str(event.event_id)])
	var epoch := {"year":int(event.ruleset_season_start_year), "quarter":3}
	var staged_world: Dictionary = career.world_athletes.duplicate()
	# Preserve explicit small-federation exemptions in domestic fields.
	for federation in allowed:
		if not autonomous_field and event.get("scope") != "international" and not persistent.any(func(record): return record.federation == federation):
			var errors := _add_candidate(staged_world,int(career.world_state.world_seed),persistent, federation, profiles[federation], epoch, bundle.calendar.season_id,level,rules_batch)
			if not errors.is_empty(): return {"roster":[],"created_athletes":{},"errors":errors}
	var limited_international: bool = event.get("scope") == "international" and (quota_jgp or event.has("federation_entry_limit"))
	for refill_slot in maxi(0,target_size - 1 - persistent.size()) if not autonomous_field and not limited_international else 0:
		if event.get("scope") == "international": return {"roster":[],"created_athletes":{},"errors":["有效持久选手池不足，不能临时重生国际阵容"]}
		var federation := WorldGenerationService.choose_federation(profiles, allowed, rng)
		var errors := _add_candidate(staged_world,int(career.world_state.world_seed),persistent, federation, profiles[federation], epoch, bundle.calendar.season_id,level,rules_batch)
		if not errors.is_empty(): return {"roster":[],"created_athletes":{},"errors":errors}
	# Rank identities independently for each event without consuming the
	# federation-selection stream or consulting athlete/player ability.
	var selection_keys := {}
	for record in persistent:
		selection_keys[record.athlete_id] = WorldGenerationService.stable_seed("%d:%s:%s" % [int(career.world_state.world_seed), str(event.event_id), str(record.athlete_id)])
	persistent.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var a_key: int = selection_keys[a.athlete_id]
		var b_key: int = selection_keys[b.athlete_id]
		return a_key < b_key if a_key != b_key else str(a.athlete_id) < str(b.athlete_id)
	)
	if level == "senior":
		persistent = preload("res://src/simulation/opponent_qualification_opportunity_service.gd").order(career,event,persistent)
	var selected: Array[Dictionary] = []
	var federation_limit := int(event.get("federation_entry_limit", target_size))
	var station_limits := {}
	if quota_jgp:
		for federation in allowed:
			station_limits[federation] = preload("res://src/simulation/junior_grand_prix_quota_service.gd").limit_for_event(career,event,bundle.calendar,federation)
		if include_player and int(station_limits.get(career.story_context.home_federation,0)) < 1:
			return {"roster":[],"created_athletes":{},"errors":["协会没有本站参赛名额"]}
	var federation_counts := {}
	if include_player: federation_counts[career.story_context.home_federation] = 1
	var has_place := func(federation):
		if quota_jgp: return int(federation_counts.get(federation,0)) < int(station_limits.get(federation,0))
		return (event.get("host_entry_limit_exempt", false) and federation == event.get("host_federation")) or int(federation_counts.get(federation, 0)) < federation_limit
	# Published assignments reserve identities before filling the foreign field.
	if event.get("scope") == "international":
		for id in career.selection_state.assignments:
			if id == "player" or not career.selection_state.assignments[id].has(event.event_id): continue
			if autonomous_field and career.world_athletes.has(id):
				var participation: Dictionary = preload("res://src/simulation/opponent_season_schedule_service.gd").participates(career,career.world_athletes[id],event)
				if participation.get("covered",false) and not participation.allowed: continue
			var found: Array = persistent.filter(func(record): return record.athlete_id == id)
			if found.size() != 1: return {"roster":[],"created_athletes":{},"errors":["派遣运动员不在有效世界名单中"]}
			var federation: String = found[0].federation
			if not has_place.call(federation):
				return {"roster":[],"created_athletes":{},"errors":["协会派遣超过本站名额"]}
			selected.append(found[0])
			federation_counts[federation] = int(federation_counts.get(federation, 0)) + 1
		if selected.size() >= target_size: return {"roster":[],"created_athletes":{},"errors":["阵容容量不足以容纳已派遣名单"]}
	# Selection reads only persisted identity/federation; never player ability.
	for federation in allowed:
		for record in persistent:
			if record.federation == federation and not selected.has(record) and selected.size() < target_size - 1 and has_place.call(federation):
				selected.append(record)
				federation_counts[federation] = int(federation_counts.get(federation, 0)) + 1
				break
	var remaining: Array[Dictionary] = persistent.filter(func(record): return not selected.has(record))
	while selected.size() < target_size - 1:
		var available: Array[String] = []
		for federation in allowed:
			if has_place.call(federation) and remaining.any(func(record): return record.federation == federation): available.append(federation)
		if available.is_empty(): break
		var federation := WorldGenerationService.choose_federation(profiles, available, rng)
		for index in remaining.size():
			if remaining[index].federation == federation:
				selected.append(remaining[index])
				federation_counts[federation] = int(federation_counts.get(federation, 0)) + 1
				remaining.remove_at(index)
				break
	selected.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return str(a.athlete_id) < str(b.athlete_id))
	if (autonomous_field or limited_international) and selected.size()+(1 if include_player else 0) < 2:
		return {"roster":[],"created_athletes":{},"errors":["本场实际有效报名不足两人，不能临时补造对手；请调整或退出报名"],"reason_code":"no_confirmed_entrant_field","world_unavailable":not include_player}
	career.world_athletes = staged_world
	return _assemble(career,selected,existing_ids,seed,include_player)

# No generic padding: an Olympic place belongs to a country, while the
# actual starter must independently have personal qualification and dispatch.
static func _olympic_field(career,event: Dictionary,pool: Array[Dictionary],existing_ids: Array,seed: int,include_player: bool) -> Dictionary:
	var quota: Dictionary = career.olympic_quota_state
	var invalid := preload("res://src/domain/olympic_quota_state.gd").validate(quota)
	if not invalid.is_empty() or quota.status == "unknown": return {"roster":[],"created_athletes":{},"errors":[invalid if not invalid.is_empty() else "奥运国家席位尚无可核对赛果"],"world_unavailable":not include_player,"reason_code":"country_quota_unknown"}
	var decision: Dictionary = quota.dispatch
	if career.beijing_trial_series.status != "finalized" or decision.get("status") != "confirmed": return {"roster":[],"created_athletes":{},"errors":["中国奥运派遣尚未最终确认"],"world_unavailable":not include_player,"reason_code":"dispatch_not_finalized"}
	var personal = preload("res://src/simulation/international_personal_eligibility.gd")
	var policy: Dictionary = personal.policy_for(event)
	var qualified_batch: Dictionary = personal.evaluate_many(career,event,policy,pool.map(func(record):return str(record.athlete_id))+["player"])
	if include_player and (not decision.get("selected_ids",[]).has("player") or not qualified_batch.player.eligible): return {"roster":[],"created_athletes":{},"errors":["玩家未同时满足最终奥运派遣与个人资格"]}
	var caps: Dictionary = quota.current.countries.duplicate()
	for country in quota.current.host_additional:
		if int(caps.get(country,0)) == 0: caps[country] = int(quota.current.host_additional[country].places)
	var selected: Array[Dictionary] = [];var used := {"CHN":1 if include_player else 0}
	var foreign: Array = []
	var championship = preload("res://src/simulation/senior_championship_service.gd")
	var result_table: Dictionary = championship._result_table(career,"2022-01-24")
	for record in pool:
		var country := str(record.federation);var id := str(record.athlete_id)
		if int(caps.get(country,0)) == 0: continue
		if country == "CHN":
			if decision.get("selected_ids",[]).has(id) and qualified_batch[id].eligible and int(used.CHN) < int(caps.CHN):
				selected.append(record);used.CHN = int(used.CHN)+1
			continue
		var results: Array = championship._subject_results(result_table,id,"")
		if results.is_empty() or not qualified_batch[id].eligible: continue
		results.sort_custom(func(a,b):return float(a.total)>float(b.total) if a.total != b.total else str(a.event_id)<str(b.event_id))
		var value := 0.0
		for result in results.slice(0,2): value += float(result.total)
		foreign.append({"record":record,"score":value})
	foreign.sort_custom(func(a,b):return float(a.score)>float(b.score) if a.score != b.score else str(a.record.athlete_id)<str(b.record.athlete_id))
	for row in foreign:
		var country := str(row.record.federation)
		if int(used.get(country,0)) >= int(caps.get(country,0)): continue
		selected.append(row.record);used[country] = int(used.get(country,0))+1
	if selected.is_empty() and not include_player: return {"roster":[],"created_athletes":{},"errors":["没有具备可核对资格及派遣的奥运参赛者"],"world_unavailable":true,"reason_code":"no_evidenced_olympic_field"}
	return _assemble(career,selected,existing_ids,seed,include_player)

static func _assemble(career, selected: Array[Dictionary], existing_ids: Array, seed: int, include_player: bool = true) -> Dictionary:
	var roster: Array[Dictionary] = []
	for record in selected: roster.append(_row_from_record(record))
	var player_row := {
		"athlete_id": "player", "name": career.athlete.display_name,
		"federation": str(career.story_context.home_federation), "club_id": str(career.social_state.get("club_id","player_club")),
		"tier": "player", "is_player": true, "athlete": career.athlete.to_dict(),
		"style_bloc": _style_bloc(career.social_state.get("personality",{}), career.athlete.to_dict()),
		"short_program": Dictionary(career.active_programs.get("short", {})).duplicate(true),
		"free_program": Dictionary(career.active_programs.get("free", {})).duplicate(true),
	}
	if include_player: roster.insert(posmod(seed, roster.size() + 1), player_row)
	career.world_state.athlete_ids = career.world_athletes.keys()
	career.world_state.athlete_ids.sort()
	var created := {}
	for id in career.world_athletes:
		if not existing_ids.has(id): created[id] = career.world_athletes[id].duplicate(true)
	return {"roster": roster, "created_athletes": created, "errors": []}

static func _add_candidate(world: Dictionary, world_seed: int, pool: Array[Dictionary], federation: String, profile: Dictionary, epoch: Dictionary, season_id: String, level: String = "junior", rules_batch: Dictionary = {}) -> Array:
	# Rejected prospective entrants never enter the persistent world or roster.
	# One bounded stratum cycle allows genuinely capable legacy replacements.
	var year := int(epoch.get("year",2018))
	rules_batch = _programme_rules(year,level,rules_batch)
	for attempt in 28:
		var record := WorldGenerationService.generate_record(world, federation, profile, world_seed, world.size()+attempt, epoch, season_id,16 if level == "senior" else 0)
		if record.has("errors"): return record.errors
		var projected := _project_programs(record,level,year,rules_batch,true)
		if projected.is_empty(): continue
		world[record.athlete_id] = record
		pool.append(projected)
		return []
	return ["候选选手已有能力不足以编排本组别合规节目；已达28次有界筛选上限，未补加技能或无效参赛者"]

static func _stage_available(career, record: Dictionary, event: Dictionary) -> bool:
	var assigned: Array = career.selection_state.assignments.get(record.athlete_id,[])
	var designated: Array = assigned.filter(func(id): return str(id).begins_with("isu_jgp_") and not str(id).contains("final"))
	if not designated.is_empty() and not designated.has(event.event_id): return false
	var starts := {}
	var year := int(event.ruleset_season_start_year)
	var season_id := "%d-%02d" % [year,(year+1)%100]
	for id in designated: starts[id] = true
	for archive in career.competition_archive:
		if archive.get("season_id") != season_id or archive.get("event",{}).get("event_family") != "jgp_stage": continue
		if archive.get("final_standings",[]).any(func(row): return row.get("athlete_id") == record.athlete_id): starts[archive.event_id] = true
	return starts.has(event.event_id) or starts.size() < 2

static func _eligible_persistent_pool(world_athletes: Dictionary, allowed_federations: Array[String], season_year: int, level: String = "junior", rules_batch: Dictionary = {}, stage_filter: Callable = Callable()) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	rules_batch = _programme_rules(season_year,level,rules_batch)
	for athlete_id in world_athletes:
		var saved = world_athletes[athlete_id]
		if not saved is Dictionary or not allowed_federations.has(str(saved.get("federation", ""))): continue
		if str(saved.get("status", "active")) != "active": continue
		# Eligibility only reads nested fields; programme projection detaches them.
		var record: Dictionary = saved.duplicate()
		record.athlete_id = str(record.get("athlete_id", athlete_id))
		if not _is_complete_record(record): continue
		var birth_year := int(record.athlete.get("birth_year", 0))
		var birthday: Dictionary = {}
		var text := str(record.get("birth_date",""))
		if not text.is_empty():
			if text.length() != 10 or text[4] != "-" or text[7] != "-": continue
			var parts := text.split("-")
			if not Array(parts).all(func(part): return str(part).is_valid_int()): continue
			birthday = {"year":int(parts[0]),"month":int(parts[1]),"day":int(parts[2])}
		elif record.athlete.get("birth_date") is Dictionary: birthday = record.athlete.birth_date
		var senior_age := preload("res://src/simulation/event_eligibility_evaluator.gd").senior_min_age(season_year)
		var age := Identity.age_gate(birth_year,birthday,season_year,senior_age if level == "senior" else 13,999 if level == "senior" else 18)
		if age.status != "eligible": continue
		if stage_filter.is_valid() and not stage_filter.call(record): continue
		record = _project_programs(record,level,season_year,rules_batch,true)
		if not record.is_empty(): result.append(record)
	return result

static func _programme_rules(season_year: int, level: String, batch: Dictionary = {}) -> Dictionary:
	# Lifetime is one build/candidate batch, never a cross-career cache.
	if batch.get("year") == season_year and batch.get("level") == level and batch.get("segments",{}).has_all(["short","free"]): return batch
	return {"year":season_year,"level":level,"segments":{"short":InternalEventRules.for_season(season_year,level,"short"),"free":InternalEventRules.for_season(season_year,level,"free")}}

static func _project_programs(record: Dictionary, level: String, season_year: int = 2018, rules_batch: Dictionary = {}, require_ready: bool = false) -> Dictionary:
	# Detached pre-entry proposal only: frozen session rows and source programmes
	# are never rewritten. Existing ability remains the sole drafting constraint.
	var projected := record.duplicate(true)
	var athlete = AthleteState.from_dict(projected.get("athlete",{}))
	if athlete == null: return {} if require_ready else projected
	rules_batch = _programme_rules(season_year,level,rules_batch)
	for segment in ["short","free"]:
		var key := "%s_program" % segment
		var original = SkatingProgram.from_dict(projected.get(key,{}))
		if original == null:
			if require_ready: return {}
			continue
		var rules: Dictionary = rules_batch.segments[segment]
		if ProgramValidator.validate(original,athlete,rules).is_empty(): continue
		var draft := preload("res://src/simulation/program_draft_service.gd").legal_draft(athlete,segment,rules,original.music,int(record.get("career_seed",0)))
		if draft.program == null:
			if require_ready: return {}
			continue
		# This is a new prospective programme, not an edit to a locked race.
		# A locked source cannot be silently unlocked by candidate projection.
		if original.draft_status == "locked" and original.locked_segments.has(segment):
			if require_ready: return {}
			continue
		draft.program.program_id = original.program_id
		draft.program.route_complexity = original.route_complexity
		draft.program.choreography_quality = original.choreography_quality
		var revision := preload("res://src/simulation/program_revision_service.gd").revise(original,draft.program)
		if revision.errors.is_empty():
			projected[key] = revision.program.to_dict()
		if require_ready:
			var revised = SkatingProgram.from_dict(projected[key])
			if revised == null or not ProgramValidator.validate(revised,athlete,rules).is_empty(): return {}
	return projected

static func _competition_ready(record: Dictionary, season_year: int, level: String = "junior", rules_batch: Dictionary = {}) -> bool:
	var athlete = AthleteState.from_dict(record.get("athlete",{}))
	if athlete == null: return false
	rules_batch = _programme_rules(season_year,level,rules_batch)
	for segment in ["short","free"]:
		var program = SkatingProgram.from_dict(record.get("%s_program" % segment,{}))
		if program == null or not ProgramValidator.validate(program,athlete,rules_batch.segments[segment]).is_empty():
			return false
	return true

static func _admitted_federations(event: Dictionary, profiles: Dictionary) -> Array[String]:
	var result: Array[String] = []
	if str(event.get("scope", "")) == "international":
		result.assign(profiles.keys())
		if int(event.get("ruleset_season_start_year",0)) == 2022 and event.get("event_family") in ["gp_stage","gp_final"]:
			var previous := SeasonBundleRepository.load_bundle(2021,"women_singles","senior")
			for federation in previous.federation_profiles:
				if not result.has(federation): result.append(federation)
		result.erase("MAC")
		for federation in result.duplicate():
			if not preload("res://src/content/international_participation_policy.gd").permitted(event,federation): result.erase(federation)
		result.sort()
		return result
	result.append("CHN")
	var policy = event.get("admission_policy", {})
	if policy is Dictionary:
		for federation in policy.get("explicit_exemptions", []):
			if profiles.has(str(federation)) and not result.has(str(federation)): result.append(str(federation))
		var routes = policy.get("review_routes", {})
		if routes is Dictionary:
			for federation in routes:
				if profiles.has(str(federation)) and routes[federation] is Array and not routes[federation].is_empty() and not result.has(str(federation)):
					result.append(str(federation))
	return result

static func _row_from_record(record: Dictionary) -> Dictionary:
	return {
		"athlete_id": str(record.athlete_id),
		"name": str(record.name),
		"federation": str(record.federation),
		"club_id": str(record.club_id),
		"tier": str(record.tier),
		"is_player": false,
		"opponent_risk": preload("res://src/simulation/opponent_decision_service.gd").frozen_risk(record),
		"style_bloc": _style_bloc(record.get("personality",{}), record.athlete),
		"athlete": Dictionary(record.athlete).duplicate(true),
		"short_program": Dictionary(record.short_program).duplicate(true),
		"free_program": Dictionary(record.free_program).duplicate(true),
	}

static func _is_complete_record(record: Dictionary) -> bool:
	for key in ["athlete_id", "name", "federation", "club_id", "tier", "athlete", "short_program", "free_program"]:
		if not record.has(key): return false
	return record.athlete is Dictionary and record.short_program is Dictionary and record.free_program is Dictionary

static func _style_bloc(personality: Dictionary, athlete: Dictionary) -> String:
	var declared := str(personality.get("skating_style", ""))
	if declared in ["lyrical", "athletic"]: return declared
	# A game-model style classification from persisted skating attributes;
	# no player strength, event RNG or judge profile changes the athlete.
	var skating: Dictionary = athlete.get("skating", {})
	return "lyrical" if float(skating.get("deep_edge",50.0)) >= float(skating.get("speed",50.0)) else "athletic"

