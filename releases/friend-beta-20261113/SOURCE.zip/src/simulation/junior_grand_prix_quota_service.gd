class_name JuniorGrandPrixQuotaService
extends RefCounted

const SOURCE := "https://jgpostrava.cz/wp-content/uploads/2022/08/JGP2022-23_Announcement_Final.pdf"
const Codec = preload("res://src/persistence/competition_archive_codec.gd")

# Model the unpublished mapping to actual stations explicitly as game policy.
static func station_slots(quota: Dictionary, federation: String, events: Array) -> Dictionary:
	var allowance: Dictionary = quota.countries.get(federation, quota.non_participant)
	var stages: Array = events.filter(func(event):
		return event.get("event_family") == "jgp_stage" and event.get("status") != "cancelled" and not event.get("reference_only",false))
	stages.sort_custom(func(a,b):
		return str(a.start_date) < str(b.start_date) if a.start_date != b.start_date else str(a.event_id) < str(b.event_id))
	var slots := {}
	for index in stages.size():
		slots[stages[index].event_id] = int(allowance.per_station) if index < int(allowance.stations) else 0
	return slots

# The 2022–23 singles base entitlement precedes station assignments, host
# entries, withdrawals and inter-federation reallocations.
static func from_world_junior(raw: Dictionary) -> Dictionary:
	if raw.get("event_id") != "isu_world_junior_2022" or raw.get("season_id") != "2021-22" or raw.get("status") != "complete":
		return {"errors":["需要 2022 世青赛完整正式归档"]}
	if not Codec.validate(raw).is_empty():
		return {"errors":["世青赛档案校验失败"]}
	var archive := Codec.expand(raw)
	var event: Dictionary = archive.get("event", {})
	if event.get("event_id") != raw.event_id or event.get("event_family") != "world_junior" or event.get("scope") != "international" or event.get("competition_level") != "junior":
		return {"errors":["世青赛归档的赛事或组别不符"]}
	var identities := {}
	for row in archive.get("roster", []):
		if identities.has(row.athlete_id) or str(row.get("federation","")).is_empty():
			return {"errors":["世青赛参赛身份无效"]}
		identities[row.athlete_id] = row.federation
	var standings: Array = archive.get("final_standings", []).duplicate()
	var short_ranks := {}
	for row in archive.get("short_standings", []):
		short_ranks[row.athlete_id] = int(row.rank)
	if standings.is_empty() or standings.size() != identities.size() or short_ranks.size() != identities.size():
		return {"errors":["世青赛归档缺少完整名次"]}
	standings.sort_custom(func(a,b): return int(a.rank) < int(b.rank))
	var countries := {}
	var seen := {}
	var member_rank := 0
	for row in standings:
		var id := str(row.athlete_id)
		var federation := str(row.federation)
		if seen.has(id) or identities.get(id) != federation or int(short_ranks.get(id,0)) < 1:
			return {"errors":["世青赛名次与报名身份不一致"]}
		seen[id] = true
		if countries.has(federation): continue
		var qualified: bool = archive.get("free_results", {}).has(id)
		if qualified: member_rank += 1
		var station_count := 4 if int(short_ranks[id]) <= 30 else 3
		var per_station := 1
		if qualified:
			station_count = 7 if member_rank <= 6 else (6 if member_rank <= 10 else 5)
			per_station = 2 if member_rank <= 3 else 1
		countries[federation] = {"stations":station_count,"per_station":per_station,"athlete_id":id,"member_rank":member_rank if qualified else 0}
	return {"errors":[],"season_id":"2022-23","source":SOURCE,"source_event_id":archive.event_id,
		"source_fingerprint":JSON.stringify({"standings":standings,"short_ranks":short_ranks,"finalists":archive.get("qualifiers",[])}).sha256_text(),
		"countries":countries,"non_participant":{"stations":2,"per_station":1}}

# Foreign association station allocation is explicit game policy. The source
# receipt and identities fix the spread; input order and mutable RNG do not.
# CHN retains its already published chronological allocation unchanged.
static func world_station_slots(quota: Dictionary, federation: String, events: Array) -> Dictionary:
	if federation == "CHN": return station_slots(quota,federation,events)
	var allowance: Dictionary = quota.get("countries",{}).get(federation,quota.get("non_participant",{}))
	var stages: Array = events.filter(func(event):return event.get("event_family") == "jgp_stage" and event.get("status") != "cancelled" and not event.get("reference_only",false))
	var fingerprint := str(quota.get("source_fingerprint",""))
	stages.sort_custom(func(a,b):
		var left := (fingerprint+":"+federation+":"+str(a.event_id)).sha256_text()
		var right := (fingerprint+":"+federation+":"+str(b.event_id)).sha256_text()
		return left < right if left != right else str(a.event_id) < str(b.event_id))
	var slots := {}
	for index in stages.size():
		slots[str(stages[index].event_id)] = int(allowance.get("per_station",0)) if index < int(allowance.get("stations",0)) else 0
	return slots

# No field generation or assignment changes occur here. Home invitations keep
# their frozen rights after a player declines; reserved capacity is already the
# whole station allowance and must not be added to its selected identities.
static func limit_for_event(career, event: Dictionary, calendar: Dictionary, federation: String = "") -> int:
	if event.get("event_family") != "jgp_stage" or event.get("status") == "cancelled" or event.get("reference_only",false): return 0
	var home := str(career.story_context.home_federation)
	if federation.is_empty(): federation = home
	if federation == str(event.get("host_federation","")): return 3
	var season := str(calendar.get("season_id",""))
	var quota: Dictionary = career.selection_state.get("jgp_base_quota_history",{}).get(season,{})
	if quota.is_empty(): return 0
	var id := str(event.get("event_id",""))
	if federation == home:
		var staged: Dictionary = career.selection_state.get("jgp_second_start",{})
		if str(staged.get("season_id","")) == season and staged.get("reserved_capacities",{}).has(id): return int(staged.reserved_capacities[id])
		var decision: Dictionary = career.selection_state.get("decisions",{}).get("jgp",{}).get("decision",{})
		var remaining: Dictionary = decision.get("audit",{}).get("remaining_station_slots",{})
		if remaining.has(id):
			var initial := 0
			var current := 0
			for ids in decision.get("assignments",{}).values():
				if ids.has(id): initial += 1
			for ids in career.selection_state.get("assignments",{}).values():
				if ids.has(id): current += 1
			return int(remaining[id])+maxi(initial,current)
		return int(station_slots(quota,federation,calendar.get("events",[])).get(id,0))
	return int(world_station_slots(quota,federation,calendar.get("events",[])).get(id,0))
