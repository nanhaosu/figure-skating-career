class_name FocusTrainingRunService
extends RefCounted

static func advance(career, intent, persist: Callable, should_stop: Callable, max_quarters: int = 2) -> Dictionary:
	var saved = career.transaction_copy()
	var before: Dictionary = career.to_dict()
	var quarters := 0
	var weeks := 0
	if not persist.is_valid() or max_quarters < 1 or max_quarters > 2: return _result(saved,before,"invalid_request",{},["连续训练请求无效"],0,0)
	for stage in 8:
		await Engine.get_main_loop().process_frame
		if should_stop.is_valid() and bool(should_stop.call()): return _result(saved,before,"user_pause",{},[],quarters,weeks)
		var prepared = saved.transaction_copy()
		var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(prepared)
		var gate: Dictionary = load("res://src/simulation/season_progression_service.gd").quarter_gate(prepared,bundle)
		if not gate.is_empty(): return _result(saved,before,"pending_action",gate,[],quarters,weeks)
		var pending: Dictionary = load("res://src/simulation/meaningful_advance_service.gd")._pending_action(prepared)
		if not pending.is_empty(): return _result(saved,before,"pending_action",pending,[],quarters,weeks)
		var built: Dictionary = load("res://src/simulation/coach_training_plan_service.gd").build(prepared,intent)
		if not built.errors.is_empty(): return _result(saved,before,"invalid_intent",{},built.errors,quarters,weeks)
		if not prepared.training_period_state.is_empty():
			var agreed = load("res://src/domain/training_plan.gd").from_dict(prepared.training_period_state.get("plan",{}))
			if agreed == null: return _result(saved,before,"invalid_intent",{},["当前训练期的已确认计划无法读取"],quarters,weeks)
			if load("res://src/simulation/athlete_condition_service.gd").can_train(prepared,agreed): built.plan = agreed
		prepared.last_generated_plan = built.plan.to_dict()
		if prepared.training_period_state.is_empty():
			prepared.training_period_state = {"weeks_elapsed":0,"intent":intent.to_dict(),"plan":built.plan.to_dict(),"started_clock":prepared.clock.to_dict()}
		elif not prepared.training_period_state.has("stage_checkpoint") and int(prepared.training_period_state.get("weeks_elapsed",0)) > 0:
			return _result(saved,before,"pending_action",{"kind":"training_checkpoint","message":"请先按原安排完成当前入门训练期，再使用连续推进。"},[],quarters,weeks)
		else: prepared.training_period_state.plan = built.plan.to_dict()
		var previous_stage := int(prepared.training_period_state.get("stage_checkpoint",{}).get("next_stage",0))
		var result: Dictionary = load("res://src/simulation/career_command_service.gd").apply(prepared,{"type":"advance_quarter","stage_limit":1,"expected_stage":previous_stage,"expected_clock":prepared.clock.to_dict(),"bundle":bundle})
		if not result.ok: return _result(saved,before,"pending_action",result.get("stop_node",{}),[] if result.has("stop_node") else [result.error],quarters,weeks)
		var candidate = result.career
		var finished: bool = candidate.clock.to_dict() != saved.clock.to_dict()
		var executed := (4 if finished else int(candidate.training_period_state.get("stage_checkpoint",{}).get("next_stage",previous_stage)))-previous_stage
		if finished: candidate.training_period_state = {}
		var durable = await persist.call(candidate)
		var committed: bool = bool(durable.get("ok",false)) if durable is Dictionary else bool(durable)
		if not committed: return _result(saved,before,"save_failed",{},["保存失败，保留最后一次成功保存的阶段"],quarters,weeks)
		saved = candidate
		weeks += executed*3
		if finished: quarters += 1
		if quarters >= max_quarters: return _result(saved,before,"quarter_complete",{},[],quarters,weeks)
	return _result(saved,before,"quarter_complete",{},[],quarters,weeks)

static func _result(career, before: Dictionary, reason: String, pending: Dictionary, errors: Array, quarters: int, weeks: int) -> Dictionary:
	return {"career":career,"stop_reason":reason,"pending_action":pending,"errors":errors,"completed_quarters":quarters,"elapsed_weeks":weeks,"facts":preload("res://src/presentation/training_focus_review_presenter.gd").build(before,career).facts}
