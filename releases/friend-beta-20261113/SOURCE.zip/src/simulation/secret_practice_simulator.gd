class_name SecretPracticeSimulator
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const JumpTrainingSimulator = preload("res://src/simulation/jump_training_simulator.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")

static func resolve(career, intent: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var blocked_reasons := _blocked_reasons(career, intent)
	var result := {
		"executed_units": 0,
		"efficiency": 0.0,
		"discovered": false,
		"reaction": "none",
		"outcomes": [],
		"memories": [],
		"blocked_reasons": blocked_reasons,
	}
	if not blocked_reasons.is_empty():
		return result

	var jump_id := str(intent.get("jump_id", ""))
	var rotations := int(intent.get("rotations", 1))
	var attempts := int(intent.get("attempts", 0))
	var familiarity := clampf(float(intent.get("familiarity", 0.0)), 0.0, 1.0)
	var efficiency := 0.20 + familiarity * 0.20
	var prior_unlocked := int(career.athlete.jumps[jump_id].unlocked_rotations)
	var outcomes: Array = JumpTrainingSimulator.apply(career, jump_id, rotations, attempts, efficiency, rng)
	if rotations > maxi(1, prior_unlocked):
		_apply_unknown_difficulty_cost(career, jump_id, rotations, prior_unlocked, attempts, outcomes)
	var previous_fatigue := float(career.athlete.body.acute_fatigue)
	career.athlete.body.acute_fatigue = clampf(previous_fatigue + attempts * 0.15, 0.0, 100.0)
	outcomes.append(OutcomeRecord.new(
		"body", "acute_fatigue", float(career.athlete.body.acute_fatigue) - previous_fatigue,
		["secret_practice", "unsupervised_full_load"], "fatigue_change",
	))
	career.athlete.resources.money = maxf(0.0, float(career.athlete.resources.money) - float(intent.get("money_cost", 0.0)))
	result.executed_units = maxi(1, int(intent.get("units", 1)))
	result.efficiency = efficiency
	result.outcomes = outcomes

	var observer_id := _observer(career)
	var control := float(career.relationships[observer_id].control) if not observer_id.is_empty() else 0.0
	result.discovered = rng.randf() < control / 100.0
	if result.discovered:
		result.reaction = _reaction(career, observer_id, _technique_gain(outcomes))
		career.relationships[observer_id].professional_trust = maxf(0.0, career.relationships[observer_id].professional_trust - 8.0)
		career.relationships[observer_id].control = minf(100.0, career.relationships[observer_id].control + 10.0)
		career.condition_state.secret_practice_blocked = true
		career.event_ledger.append({"kind":"secret_practice_discovered", "reaction":result.reaction, "actor_id":observer_id, "clock":career.clock.to_dict()})
		result.memories.append({
			"id": "secret:%d:%d" % [career.clock.year, career.clock.quarter],
			"kind": "secret_practice_discovered", "actors": [observer_id],
			"cause_ids": ["secret_practice"], "reaction": result.reaction,
		})
	return result

static func _apply_unknown_difficulty_cost(career, jump_id: String, rotations: int, prior_unlocked: int, attempts: int, outcomes: Array) -> void:
	var risk_load := (rotations - maxi(1, prior_unlocked)) * attempts * 0.03
	var profile = career.athlete.jumps[jump_id]
	var previous_rigidity := float(profile.habits.rigidity)
	profile.habits.rigidity = clampf(previous_rigidity + risk_load, 0.0, 100.0)
	outcomes.append(OutcomeRecord.new("jump_habit", "%s.rigidity" % jump_id, float(profile.habits.rigidity) - previous_rigidity, ["secret_practice", "unknown_high_difficulty"], "habit_rigidity_change"))
	var previous_fear := float(career.athlete.mind.training_fear)
	career.athlete.mind.training_fear = clampf(previous_fear + risk_load * 0.5, 0.0, 100.0)
	outcomes.append(OutcomeRecord.new("mind", "training_fear", float(career.athlete.mind.training_fear) - previous_fear, ["secret_practice", "unknown_high_difficulty"], "training_fear_change"))

static func _blocked_reasons(career, intent: Dictionary) -> Array[String]:
	var reasons: Array[String] = []
	if bool(career.condition_state.get("secret_practice_blocked", false)): reasons.append("adult_supervision")
	if not preload("res://src/simulation/athlete_condition_service.gd").can_compete(career): reasons.append("medical_restriction")
	if not bool(intent.get("free_ice_access", false)) or float(career.athlete.resources.ice_access) <= 0.0:
		reasons.append("free_ice_access")
	if not bool(intent.get("transport_available", false)):
		reasons.append("transport_available")
	if not bool(intent.get("unmonitored_window", false)):
		reasons.append("unmonitored_window")
	if float(career.athlete.resources.money) < float(intent.get("money_cost", 0.0)):
		reasons.append("insufficient_money")
	if not JumpCatalog.JUMP_IDS.has(str(intent.get("jump_id", ""))) or int(intent.get("attempts", 0)) <= 0:
		reasons.append("invalid_practice")
	return reasons

static func _observer(career) -> String:
	var guardian_control := float(career.relationships.guardian.control) if career.relationships.has("guardian") else 0.0
	var coach_control := float(career.relationships.coach.control) if career.relationships.has("coach") else 0.0
	if coach_control > guardian_control:
		return "coach"
	return "guardian" if career.relationships.has("guardian") else ""

static func _reaction(career, observer_id: String, technique_gain: float) -> String:
	var adult = career.relationships[observer_id]
	if adult.health_priority >= 70.0:
		return "stop"
	if observer_id == "coach" and adult.professional_trust >= 70.0 and technique_gain > 0.0:
		return "supervised_extra"
	if adult.health_priority >= 30.0 and technique_gain > 0.0:
		return "reconsider"
	return "monitor"

static func _technique_gain(outcomes: Array) -> float:
	var gain := 0.0
	for outcome in outcomes:
		if outcome.category == "jump_training":
			gain += maxf(0.0, outcome.delta)
	return gain
