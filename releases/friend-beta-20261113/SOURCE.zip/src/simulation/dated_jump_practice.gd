class_name DatedJumpPractice
extends RefCounted

const Dates = preload("res://src/simulation/dated_training_window.gd")
const Plan = preload("res://src/domain/training_plan.gd")
const Model = preload("res://src/domain/technical_repertoire.gd")
const Batch = preload("res://src/simulation/jump_attempt_batch_simulator.gd")
const Learning = preload("res://src/simulation/jump_training_simulator.gd")
const Transfer = preload("res://src/simulation/jump_transfer_simulator.gd")
const Evidence = preload("res://src/simulation/repertoire_evidence_service.gd")
const Coaching = preload("res://src/simulation/coach_lesson_service.gd")

# Executes only actual allocated jump contacts and their teaching effects.
# The owning dated command must guard its durable cursor BEFORE calling this;
# this primitive neither advances time nor awards a quarter's health/rehab.
static func execute(career, plan, volume: Dictionary, date: String, rng: RandomNumberGenerator) -> Dictionary:
	var result := {"errors":[],"outcomes":[],"aggregate_batches":[],"milestones":[],"actual_jump_attempts":0}
	var checked: Dictionary = Dates.plan(date,date)
	if not checked.errors.is_empty(): return _failure("跳跃练习日期无效")
	var year := int(date.substr(0,4)); var quarter := (int(date.substr(5,2))-1)/3+1
	if career == null or plan == null or rng == null or year != career.clock.year or quarter != career.clock.quarter: return _failure("跳跃练习日期与当前训练期不一致")
	if not volume.get("jump_attempts") is Dictionary or not volume.get("jump_qualities",{}) is Dictionary or not volume.get("specialist_attempts",[]) is Array: return _failure("跳跃练习剂量无效")
	for id in volume.jump_attempts:
		var rotations = plan.jump_rotations.get(id,1)
		if not Plan.JUMP_LABELS.has(id) or not _count(volume.jump_attempts[id]) or not _quality(volume.get("jump_qualities",{}).get(id,volume.get("quality",1.0))) or not _count(rotations) or not int(rotations) in [1,2,3,4]: return _failure("单跳练习剂量无效")
		if int(volume.jump_attempts[id]) > 0 and int(plan.shares.get("jump_"+str(id),0)) <= 0: return _failure("单跳练习剂量不属于已执行训练计划")
	for specialist in volume.get("specialist_attempts",[]):
		if not specialist is Dictionary or not specialist.get("action") is Dictionary or Model.action_id(specialist.action).is_empty() or specialist.action.get("parts",[]).size() < 2 or not _count(specialist.get("attempts")) or not _quality(specialist.get("quality",volume.get("quality",1.0))): return _failure("连跳练习剂量无效")
		if int(specialist.attempts) > 0:
			var allocated := false
			for target in plan.specialist_targets:
				if Model.action_id(target.get("action",{})) == Model.action_id(specialist.action) and int(target.get("allocated_attempt_budget",0)) >= int(specialist.attempts)*specialist.action.parts.size(): allocated = true
			if not allocated: return _failure("连跳练习剂量不属于已执行专项计划")
	if not career.condition_state.get("pending_decision",{}).is_empty(): return result
	var first := "%04d-%02d-01T00:00:00" % [year,(quarter-1)*3+1]
	var next := "%04d-%02d-01T00:00:00" % [year+(1 if quarter == 4 else 0),1 if quarter == 4 else quarter*3+1]
	var period_days := (int(Time.get_unix_time_from_datetime_string(next))-int(Time.get_unix_time_from_datetime_string(first)))/86400
	var batch_id := Model.dated_assessment_id(date)
	var lessons: Array = []
	for id in Plan.JUMP_LABELS:
		var count := int(volume.jump_attempts.get(id,0))
		if count == 0: continue
		var rotations := int(plan.jump_rotations.get(id,1))
		var action_id := "%d%s" % [rotations,Model.CODES[id]]
		if Evidence.already_recorded(career,action_id,batch_id,"practice",date): continue
		var quality := float(volume.get("jump_qualities",{}).get(id,volume.get("quality",1.0)))
		var batch: Dictionary = Batch.simulate(career,id,rotations,count,quality,rng)
		if batch.outcomes.is_empty(): continue
		result.actual_jump_attempts += count
		result.aggregate_batches.append_array(batch.outcomes)
		lessons.append_array(batch.outcomes)
		result.milestones.append_array(batch.milestones)
		result.outcomes.append_array(Learning.apply(career,id,rotations,count,quality,rng,false))
		result.outcomes.append_array(Transfer.apply(career,id,rotations,count,quality,rng))
		Evidence.record(career,{"action":{"kind":"jump","parts":[{"jump_id":id,"rotations":rotations}]},"action_id":action_id,"batch_id":batch_id,"source_id":date,"clock":career.clock.to_dict(),"context":"practice","attempts":count,"successes":batch.successes,"clean_successes":batch.clean_successes,"failure_counts":{"falls":batch.falls,"pops":batch.pops},"assessment_eligible":true})
	for specialist in volume.get("specialist_attempts",[]):
		if int(specialist.attempts) == 0: continue
		var combo: Dictionary = preload("res://src/simulation/combination_training_service.gd").simulate(career,specialist.action,int(specialist.attempts),batch_id,{"quality":float(specialist.get("quality",volume.get("quality",1.0))),"evidence_context":"specialist","source_id":date},rng)
		result.outcomes.append_array(combo.outcomes)
		result.actual_jump_attempts += int(combo.actual_load.jump_attempts)
		if not combo.evidence.is_empty(): result.aggregate_batches.append(combo.evidence.duplicate(true))
		# Teach the parts actually attempted, never the planned second jump
		# after a first-jump fall/interruption. Combo evidence is not a single
		# jump batch and cannot by itself tell the coach which family worked.
		for execution in combo.executions:
			for actual in execution.get("parts",[]):
				lessons.append({"jump_id":str(actual.get("jump_id","")),"attempts":1})
	result.outcomes.append_array(Coaching.settle(career,plan,1.0/float(period_days),lessons))
	result.lesson_batches = lessons
	return result

static func _count(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) == floorf(float(value)) and float(value) >= 0 and float(value) <= 1000000

static func _quality(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= 0 and float(value) <= 1.15

static func _failure(message: String) -> Dictionary:
	return {"errors":[message],"outcomes":[],"aggregate_batches":[],"milestones":[],"actual_jump_attempts":0}
