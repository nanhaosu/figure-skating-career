class_name FormalTechnicalPanel
extends RefCounted

const FormalScoringRepository = preload("res://src/content/formal_scoring_repository.gd")
const JumpRuleLedger = preload("res://src/simulation/jump_rule_ledger.gd")

static func resolve(performance: Dictionary, rules: Dictionary, reputation: Dictionary, panel_context: Dictionary, seed: int) -> Dictionary:
	var result := {"calls": [], "final_elements": [], "review_events": [], "rule_events": [], "actual_jump_counts": {}, "seed": seed}
	for raw_element in performance.get("elements", []):
		if not raw_element is Dictionary: continue
		var element: Dictionary = raw_element
		var resolved := _resolve_element(element, rules, reputation, panel_context)
		result.final_elements.append(resolved.element)
		result.calls.append(resolved.call)
		for review in resolved.reviews: result.review_events.append(review)
	var ledger := JumpRuleLedger.apply(result.final_elements, Dictionary(panel_context.get("segment_rules", {})))
	result.final_elements = ledger.elements
	result.rule_events = ledger.rule_events
	result.actual_jump_counts = ledger.actual_jump_counts
	return result

static func _resolve_element(element: Dictionary, rules: Dictionary, reputation: Dictionary, panel_context: Dictionary) -> Dictionary:
	if str(element.get("kind", "")) != "jump":
		return _resolve_level_element(element, rules)
	var parts = element.get("parts", [])
	if parts is Array and not parts.is_empty():
		return _resolve_combination(element, rules, reputation, panel_context)
	return _resolve_jump(element, rules, reputation, panel_context)

static func _resolve_combination(element: Dictionary, rules: Dictionary, reputation: Dictionary, panel_context: Dictionary) -> Dictionary:
	var abbreviations: Array[String] = []
	var base_value := 0.0
	var info: Array[String] = []
	var facts: Array[Dictionary] = []
	var final_parts: Array[Dictionary] = []
	var reviews: Array[Dictionary] = []
	var confidence := "clear"
	var goe_base_value := 0.0
	for part in element.parts:
		var resolved := _resolve_jump(part, rules, reputation, panel_context)
		abbreviations.append(str(resolved.element.abbreviation))
		base_value += float(resolved.element.base_value)
		goe_base_value = maxf(goe_base_value, float(resolved.element.get("goe_base_value", resolved.element.base_value)))
		facts.append(Dictionary(resolved.element.facts).duplicate(true))
		var final_part: Dictionary = resolved.element.duplicate(true)
		final_part.jump_id = str(part.get("jump_id", ""))
		final_part.called_rotations = int(str(final_part.abbreviation).left(1))
		final_parts.append(final_part)
		for symbol in resolved.element.info:
			if not info.has(symbol): info.append(symbol)
		for review in resolved.reviews: reviews.append(review)
		if resolved.element.call_confidence == "ambiguous": confidence = "ambiguous"
	var interrupted := bool(element.get("combination_interrupted", false))
	var segment_rules: Dictionary = panel_context.get("segment_rules", {})
	var is_sequence: bool = segment_rules.get("segment") == "free" and segment_rules.get("axel_sequence_allowed", false) and final_parts.slice(1).any(func(part): return part.jump_id == "axel")
	# Losing the follow-up jump does not invalidate the first completed jump.
	# Falls/landing errors and actual invalid parts are judged independently.
	return _result({
		"element_id": str(element.get("element_id", "")), "abbreviation": "+".join(abbreviations) + ("+SEQ" if is_sequence else ""),
		"info": info, "base_value": snappedf(base_value, 0.01), "status": "error" if interrupted or _has_error_symbol(info) else "success",
		"goe_base_value": snappedf(goe_base_value, 0.01), "late_bonus": info.has("x"), "facts": {"parts": facts, "connection_held": not interrupted}, "parts":final_parts,"kind":"jump","call_confidence": confidence,
	}, reviews)

static func _resolve_jump(element: Dictionary, rules: Dictionary, reputation: Dictionary, panel_context: Dictionary) -> Dictionary:
	var facts: Dictionary = Dictionary(element.get("facts", {})).duplicate(true)
	if facts.is_empty(): facts = _legacy_facts(element)
	var planned_code := str(element.get("planned_abbreviation", element.get("abbreviation", ""))).split("+")[0]
	var planned_rotations := int(facts.get("planned_rotations", int(planned_code.left(1))))
	var jump_code := planned_code.substr(1)
	var credited_code := planned_code
	var info: Array[String] = []
	var reviews: Array[Dictionary] = []
	var confidence := "clear"
	var ratio := float(facts.get("rotation_ratio", facts.get("completed_rotation_ratio", 1.0)))
	# A pop changes the jump actually attempted; it is not a downgrade of the
	# originally scheduled jump. Keep the plan in the facts, judge actual turns.
	if str(element.get("actual", {}).get("error_type", "")) == "pop":
		credited_code = str(element.get("abbreviation", planned_code))
		ratio = float(facts.get("executed_rotation_ratio", 0.96))
		planned_rotations = int(credited_code.left(1))
	var quarter_standard := str(rules.get("rotation_call_standard","")) == "isu_2334"
	if quarter_standard:
		# Absolute missing turns, not the same percentage for 2/3/4 rotations.
		# A pop must use the actual attempted jump's landing evidence.
		var missing := float(facts.get("missing_rotation_turns",maxf(0.0,(1.0-ratio)*planned_rotations)))
		if str(element.get("actual",{}).get("error_type","")) == "pop":
			missing = float(facts.get("executed_missing_rotation_turns",maxf(0.0,(1.0-ratio)*planned_rotations)))
		if missing >= 0.5 - 0.00000001:
			info.append("<<")
			credited_code = "%d%s" % [maxi(1,planned_rotations-1),jump_code]
		elif missing > 0.25 + 0.00000001:
			info.append("<")
		elif absf(missing-0.25) <= 0.00000001:
			info.append("q")
	elif ratio < 0.75:
		info.append("<<")
		credited_code = "%d%s" % [maxi(1, planned_rotations - 1), jump_code]
	elif ratio < 0.90:
		info.append("<")
		if ratio >= 0.86:
			confidence = "ambiguous"
			reviews.append(_review(element, "rotation", ratio))
	var edge_quality := float(facts.get("edge_quality", facts.get("takeoff_edge_quality", 100.0)))
	if jump_code in ["Lz", "F"]:
		if edge_quality < 30.0:
			info.append("e")
		elif edge_quality < 56.0:
			confidence = "ambiguous"
			reviews.append(_review(element, "edge", edge_quality))
			var pressure := (56.0 - edge_quality) + clampf(float(reputation.get("edge_symbol_count", 0)),0,3) * 3.0 - clampf(float(panel_context.get("reputation_protection", 0.0)),0,60) * 0.2
			if pressure >= 20.0: info.append("e")
			elif pressure >= 7.0: info.append("!")
	if bool(facts.get("invalid", false)) or not bool(facts.get("connection_held", true)):
		info.append("*")
	var base_value := FormalScoringRepository.element_value(rules, credited_code)
	if info.has("<") and info.has("e"): base_value *= 0.60
	elif info.has("<"): base_value *= 0.80 if quarter_standard else 0.75
	elif info.has("e"): base_value *= 0.80 if quarter_standard else 0.75
	base_value = snappedf(base_value+0.00000001,0.01)
	if info.has("*"): base_value = 0.0
	var goe_base_value := base_value
	var late_bonus := bool(facts.get("late_bonus", false)) and not info.has("*")
	if late_bonus:
		info.append("x")
		base_value *= 1.10
	var final_element := {
		"element_id": str(element.get("element_id", "")), "abbreviation": credited_code,
		"info": info, "base_value": snappedf(base_value, 0.01), "goe_base_value": goe_base_value,
		"status": "error" if _has_error_symbol(info) or bool(facts.get("fall", false)) or bool(facts.get("two_foot", false)) else "success",
		"late_bonus": late_bonus, "facts": facts, "kind":"jump", "parts":[{"jump_id":str(element.get("jump_id","")),"called_rotations":int(credited_code.left(1)),"abbreviation":credited_code,"base_value":snappedf(base_value,0.01),"goe_base_value":goe_base_value}], "call_confidence": confidence,
	}
	facts.planned_abbreviation = planned_code
	facts.credited_abbreviation = credited_code
	return _result(final_element, reviews)

static func _resolve_level_element(element: Dictionary, rules: Dictionary) -> Dictionary:
	var facts: Dictionary = Dictionary(element.get("facts", {})).duplicate(true)
	var code := str(facts.get("element_code", element.get("abbreviation", "")))
	var level := clampi(int(facts.get("credited_features", 0)), 0, 4)
	if code == "ChSq": level = 1
	var abbreviation := code if code == "ChSq" else "%s%s" % [code, "B" if level == 0 else str(level)]
	var base_value := 3.0 if code == "ChSq" else FormalScoringRepository.level_value(rules, code, level)
	var final_element := {
		"element_id": str(element.get("element_id", "")), "abbreviation": abbreviation,
		"kind": str(element.get("kind", "")),
		"final_level":level,
		"info": [], "base_value": snappedf(base_value, 0.01), "status": "error" if str(element.get("status", "success")) == "error" else "success",
		"goe_base_value": snappedf(base_value, 0.01), "late_bonus": false, "facts": facts, "call_confidence": "clear",
	}
	return _result(final_element, [])

static func _legacy_facts(element: Dictionary) -> Dictionary:
	var actual: Dictionary = Dictionary(element.get("actual", {}))
	return {
		"planned_rotations": int(str(element.get("planned_abbreviation", element.get("abbreviation", "1T"))).left(1)),
		"rotation_ratio": 0.62 if str(actual.get("error_type", "")) == "pop" else (0.84 if str(actual.get("error_type", "")) == "underrotated" else 1.0),
		"edge_quality": float(actual.get("takeoff_edge_quality", 100.0)),
		"landing_quality": float(actual.get("quality", 50.0)), "fall": bool(actual.get("fall", false)),
		"two_foot": str(actual.get("error_type", "")) == "two_foot", "connection_held": true, "invalid": false, "late_bonus": false,
	}

static func _review(element: Dictionary, kind: String, evidence: float) -> Dictionary:
	return {"element_id": str(element.get("element_id", "")), "kind": kind, "evidence": evidence, "status": "resolved","states":["yellow","finalized"]}

static func _has_error_symbol(info: Array[String]) -> bool:
	for symbol in ["<<", "<", "q", "!", "e", "*"]:
		if info.has(symbol): return true
	return false

static func _result(element: Dictionary, reviews: Array) -> Dictionary:
	return {"element": element, "call": {"element_id": element.element_id, "info": element.info, "confidence": element.call_confidence}, "reviews": reviews}
