class_name SeasonProgressionService
extends RefCounted

const Career = preload("res://src/domain/career_state.gd")
const Command = preload("res://src/simulation/career_command_service.gd")
const KeyNodes = preload("res://src/simulation/key_node_service.gd")
const Entry = preload("res://src/simulation/entry_application_service.gd")
const World = preload("res://src/simulation/world_season_simulator.gd")
const Ranking = preload("res://src/simulation/competition_ranking_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")

static func background_unexamined(career, event: Dictionary) -> bool:
	if event.get("background_no_retroactive",false): return true
	if not event.get("no_retroactive_background",false): return false
	var finish := str(event.get("actual_dates",{}).get("end",event.get("end_date","")))
	if career.competition_timeline.get("mode") == "dated": return not finish.is_empty() and str(career.competition_timeline.date) > finish
	return not finish.is_empty() and _ordinal(_date_clock(finish)) < _ordinal(career.clock.to_dict())

# Reuse the synchronous deterministic stepper, stopping at each proposed commit.
# UI callers await the durable boundary; native batch simulations keep their API.
static func advance_to_next_node_durable(career, bundle: Dictionary, persist: Callable) -> Dictionary:
	var saved = career
	for step in 256:
		var proposed := []
		var result := advance_to_next_node(saved,bundle,func(candidate): proposed.append(candidate); return false)
		if proposed.is_empty(): return result
		if not bool(await persist.call(proposed[0])): return result
		saved = proposed[0]
	return _result(saved,{},["advance_limit"])

# Dates order decisions within a quarter; the simulation clock remains quarterly.
# Missing historical application dates use the first event date, explicitly labelled.
static func advance_to_next_node(career, bundle: Dictionary, persist: Callable) -> Dictionary:
	if career == null or not persist.is_valid() or not bundle.get("errors",[]).is_empty() or bundle.get("calendar",{}).is_empty():
		return _result(career,{},["invalid_request"])
	var saved = career
	var season_id := str(bundle.calendar.season_id)
	if _receipt(saved,"season_closed",season_id): return _result(saved,_closed_node(saved,season_id))
	for step in 256:
		var pending := _pending(saved)
		if not pending.is_empty(): return _result(saved,pending)
		# A legacy staged period owns its remaining dose until normal quarter
		# completion. December check-ins still work without inventing a precise
		# old date; switch at the following proven boundary, not past the races.
		if preload("res://src/simulation/dated_training_service.gd").can_auto_activate(saved):
			var activation: Dictionary = Command.apply(saved,{"type":"begin_dated_training"})
			if not activation.ok: return _result(saved,_node(saved,"training_plan",str(activation.error)),[str(activation.error)])
			var activated = activation.career.transaction_copy(true)
			if not bool(persist.call(activated)): return _result(saved,{},["save_failed"])
			saved = activated
			continue
		if saved.competition_timeline.mode == "dated":
			var second = preload("res://src/simulation/jgp_second_start_service.gd")
			var second_round: Dictionary = second.preview(saved,bundle.calendar)
			if not second_round.is_empty():
				var dispatched = saved.transaction_copy(true)
				second.commit(dispatched,second_round)
				if not bool(persist.call(dispatched)): return _result(saved,{},["save_failed"])
				saved = dispatched
				continue
			var gp = preload("res://src/simulation/senior_grand_prix_service.gd")
			var gp_publication: Dictionary = gp.circuit_needs_publication(saved,bundle)
			if not gp_publication.is_empty():
				var invited = saved.transaction_copy(true)
				var publication: Dictionary = gp.commit(invited,gp_publication)
				if not publication.errors.is_empty(): return _result(saved,{},publication.errors)
				if not bool(persist.call(invited)): return _result(saved,{},["save_failed"])
				saved = invited
				continue
			var unresolved := _unresolved_dated_event(saved,bundle)
			if not unresolved.is_empty():
				if _entry_status(saved,str(unresolved.event_id)) == "confirmed": return _result(saved,_unknown_dates_node(saved,unresolved))
				var unexamined = saved.transaction_copy(true)
				unexamined.event_ledger.append({"kind":"season_event","season_id":season_id,"event_id":str(unresolved.event_id),"date":str(unresolved.get("start_date","")),"date_precision":str(unresolved.get("date_precision","unknown")),"clock":saved.clock.to_dict(),"outcome":"unexamined","reason_code":"missing_precise_dates","reason":"史料未提供可核对的完整比赛日；保留赛事展示，不补造日期、比赛成绩或训练占用。"})
				if not bool(persist.call(unexamined)): return _result(saved,{},["save_failed"])
				saved = unexamined
				continue
		var next := _due_confirmed_event(saved,bundle)
		var planning := preload("res://src/simulation/season_program_service.gd").planning_node(saved,bundle)
		if next.is_empty() and not planning.is_empty(): return _result(saved,planning)
		if next.is_empty():
			var world_bundle := _background_bundle(saved,bundle)
			if not world_bundle.errors.is_empty(): return _result(saved,{},world_bundle.errors)
			next = _next_event(saved,world_bundle)
		var close_clock := {"year":int(bundle.calendar.calendar_year)+1,"quarter":3}
		var target: Dictionary = next.get("clock",close_clock)
		var working
		var dated: bool = saved.competition_timeline.mode == "dated"
		var target_date := _dated_training_target(saved,next,bundle) if dated else ""
		if (dated and target_date > str(saved.competition_timeline.date)) or (not dated and _ordinal(saved.clock.to_dict()) < _ordinal(target)):
			var advance_command := {"type":"advance_quarter","bundle":bundle}
			if dated: advance_command = {"type":"advance_dated_training","target_date":target_date}
			var source = saved
			var advanced := Command.apply(source,advance_command)
			if not advanced.ok:
				return _result(saved,advanced.get("stop_node",_node(saved,"training_plan",advanced.error)),[] if advanced.has("stop_node") else [advanced.error])
			working = advanced.career
			if working.clock.to_dict() != saved.clock.to_dict(): working.training_period_state = {}
		elif not next.is_empty():
			var event: Dictionary = next.event
			if next.kind == "beijing_dispatch":
				working = saved.transaction_copy()
				var decision: Dictionary = load("res://src/simulation/beijing_trial_service.gd").finalize(working,str(next.date))
				if not decision.ok: return _result(saved,{},[str(decision.get("error","选拔派遣核验失败"))])
				working.event_ledger.append({"kind":"beijing_dispatch_checked","season_id":season_id,"event_id":"beijing2022_women_trials","date":next.date,"clock":working.clock.to_dict(),"status":decision.status,"reason_codes":decision.get("reason_codes",[]).duplicate()})
				var world_check: Dictionary = World.advance_to(working,working.clock.to_dict(),bundle)
				if not world_check.errors.is_empty(): return _result(saved,{},world_check.errors)
				working = working.transaction_copy(true)
				if not bool(persist.call(working)): return _result(saved,{},["save_failed"])
				saved = working
				continue
			if next.kind == "registration":
				var options := Entry.options(saved,event,bundle)
				var kind := "selection" if options.any(func(o): return o.id in ["request_assignment","request_nomination"] and o.available) else "registration"
				var node := _node(saved,kind,"请确认%s的报名路径；未获派遣也可明确选择不参加" % event.name,event.event_id,options)
				node.date = next.date; node.deadline_basis = next.deadline_basis
				return _result(saved,node)
			var archive := _archive(saved,str(event.event_id))
			if dated and not archive.is_empty():
				var occupied_end := str(event.get("actual_dates",{}).get("end",event.get("end_date",event.start_date)))
				if str(saved.competition_timeline.date) < occupied_end:
					var consumed: Dictionary = Command.apply(saved,{"type":"consume_completed_competition_dates","event_id":str(event.event_id)})
					if not consumed.ok: return _result(saved,{},[consumed.error])
					working = consumed.career
			if archive.is_empty() and _entry_status(saved,str(event.event_id)) == "confirmed":
				var resolved := Bundle.competition_for_career(saved,event)
				if not resolved.errors.is_empty(): return _result(saved,{},resolved.errors)
				# A blanket physical prohibition cannot be cured by programme
				# editing. Keep difficulty-specific restrictions on the normal
				# fallback path when a safe lower jump is still physically allowed.
				var minimum_jump := {"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":1}]}
				if not preload("res://src/simulation/athlete_function_service.gd").action_constraints(saved,minimum_jump).allowed:
					if Entry.medical_pause_applies(saved,str(event.event_id)):
						if working == null: working = saved.transaction_copy()
						var medically_skipped := Entry._medical_skip(working,str(event.event_id))
						if not medically_skipped.ok: return _result(saved,{},[str(medically_skipped.error)])
						if not bool(persist.call(working)): return _result(saved,{},["save_failed"])
						saved = working
						continue
					return _result(saved,_node(saved,"medical_restriction","当前医疗限制不允许跳跃，请先处理康复或退赛安排",event.event_id,[{"id":"review_medical"}]))
				var event_programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(saved,resolved.event)
				for segment in ["short","free"]:
					var program = load("res://src/domain/skating_program.gd").from_dict(event_programs.get(segment,{}))
					if program == null or not load("res://src/simulation/program_validator.gd").validate(program,saved.athlete,resolved.rules[segment].segment_rules).is_empty():
						var node := _node(saved,"program_adjustment","%s需要符合本场组别规则的%s" % [event.name,"短节目" if segment == "short" else "自由滑"],event.event_id,[{"id":"edit_program","segment":segment}])
						node.segment = segment; node.rules = resolved.rules[segment].segment_rules
						return _result(saved,node)
				var fallback_rules := {"short":resolved.rules.short.segment_rules,"free":resolved.rules.free.segment_rules}
				var replacement := preload("res://src/simulation/program_fallback_service.gd").propose(saved,event_programs,fallback_rules,resolved.event)
				if replacement.changed:
					var node := _node(saved,"program_replacement","节目中有暂不可用动作，请确认合法替代或退赛",event.event_id)
					node.proposal = replacement
					return _result(saved,node)
				if not load("res://src/simulation/athlete_condition_service.gd").can_compete(saved,event_programs):
					return _result(saved,_node(saved,"medical_restriction","已报名赛事需要处理伤病或退出决定",event.event_id,[{"id":"review_medical"}]))
				var gate := Entry.current_eligibility(saved,event,bundle,true)
				if not gate.eligible:
					return _result(saved,_node(saved,"entry_revalidation","已报名赛事当前资格需处理：%s" % ",".join(gate.explanations),event.event_id,[{"id":"withdraw","label":"主动退赛（报名费用不退）","available":true}]))
				return _result(saved,_node(saved,"competition_check_in","请进入%s签到并查看出场名单" % event.name,event.event_id,[{"id":"check_in"}]))
			if working == null: working = saved.transaction_copy()
			var unexamined_reason := ""
			var unexamined_code := ""
			if archive.is_empty() and background_unexamined(saved,event):
				unexamined_reason = "此新增世界赛事早于旧档当前进度且没有可核对归档；保留未知，不倒补比赛，训练继续。"
				unexamined_code = "historical_background_unexamined"
			if archive.is_empty() and unexamined_reason.is_empty():
				var simulated: Dictionary = load("res://src/simulation/formal_competition_simulator.gd").simulate_world_event(working,event,working.seed+12001)
				if not simulated.errors.is_empty():
					if not simulated.get("world_unavailable",false): return _result(saved,{},simulated.errors)
					unexamined_reason = "世界赛事未模拟：%s；保留资格未知，不补造旧成绩，生涯训练继续。" % ",".join(simulated.errors)
					unexamined_code = str(simulated.get("reason_code",""))
			var event_receipt := {"kind":"season_event","season_id":season_id,"event_id":event.event_id,"date":next.date,"clock":working.clock.to_dict(),"outcome":"unexamined" if not unexamined_reason.is_empty() else ("completed" if not archive.is_empty() else "declined"),"reason":unexamined_reason if not unexamined_reason.is_empty() else ("已完成并归档" if not archive.is_empty() else "本场未参赛；世界比赛已归档（不代表玩家主动弃赛）")}
			if event.get("event_family") == "beijing_trial":
				var settled: Dictionary = load("res://src/simulation/beijing_trial_service.gd").settle_sources(working,str(next.date))
				if not settled.ok: return _result(saved,{},[str(settled.error)])
			if not unexamined_code.is_empty(): event_receipt.reason_code = unexamined_code
			working.event_ledger.append(event_receipt)
		else:
			working = saved.transaction_copy()
			_close(working,bundle)
		var synchronized := World.advance_to(working,working.clock.to_dict(),bundle)
		if not synchronized.errors.is_empty(): return _result(saved,{},synchronized.errors)
		for i in working.competition_archive.size():
			working.competition_archive[i] = load("res://src/persistence/competition_archive_codec.gd").compact(working.competition_archive[i])
		# Normalize at every commit, so in-memory and disk-resumed transactions
		# start with exactly the same JSON number representation.
		working = working.transaction_copy(true)
		if not bool(persist.call(working)): return _result(saved,{},["save_failed"])
		saved = working
		if _receipt(saved,"season_closed",season_id): return _result(saved,_closed_node(saved,season_id))
	return _result(saved,{},["advance_limit"])

static func training_entry_gate(career, bundle: Dictionary) -> Dictionary:
	var gate := quarter_gate(career,bundle)
	# Entering the screen does not activate or pay days. The real saved coach
	# action handles the provable formal-era boundary before it trains.
	if gate.get("kind","") in ["registration","competition_check_in"] and preload("res://src/simulation/dated_training_service.gd").can_auto_activate(career) and _pending(career).is_empty(): return {}
	return gate

static func quarter_gate(career, bundle: Dictionary) -> Dictionary:
	var pending := _pending(career)
	if not pending.is_empty(): return pending
	if career.competition_timeline.mode == "dated":
		var unresolved := _unresolved_dated_event(career,bundle,true)
		if not unresolved.is_empty(): return _unknown_dates_node(career,unresolved)
	# Completed player archives still need coordinator receipts, but are no
	# longer check-in actions. Keep this filtering local to read-only training
	# inspection so advancing can settle chronology and world results normally.
	var unplayed_bundle := bundle.duplicate(true)
	unplayed_bundle.calendar.events = bundle.get("calendar",{}).get("events",[]).filter(func(event):return _archive(career,str(event.event_id)).is_empty())
	var confirmed := _due_confirmed_event(career,unplayed_bundle)
	if not confirmed.is_empty():
		if confirmed.kind == "beijing_dispatch": return _node(career,"season_transition","先核对选拔派遣，再继续训练。",confirmed.event.event_id)
		return _node(career,"competition_check_in","已报名比赛到期，请先处理赛事",confirmed.event.event_id,[{"id":"check_in"}])
	var season_id := str(bundle.get("calendar",{}).get("season_id",""))
	var close_clock := {"year":int(bundle.get("calendar",{}).get("calendar_year",career.clock.year))+1,"quarter":3}
	if not season_id.is_empty() and not _receipt(career,"season_closed",season_id) and _ordinal(career.clock.to_dict()) >= _ordinal(close_clock):
		return _node(career,"season_transition","本季已到结算时间，先处理剩余赛事并归档，再安排下季训练。")
	var planning := preload("res://src/simulation/season_program_service.gd").planning_node(career,bundle)
	if not planning.is_empty(): return planning
	# Continuous training must give the coordinator a chance to settle a
	# mandatory live world event while still in its quarter. Otherwise the
	# next training quarter makes a fresh career indistinguishable from an
	# imported save with missing history. Past legacy events remain unknown.
	var background := _background_bundle(career,bundle)
	if background.get("errors",[]).is_empty():
		for event in background.get("calendar",{}).get("events",[]):
			if not event.get("background_only",false) or event.get("background_no_retroactive",false): continue
			if _receipt(career,"season_event",season_id,str(event.event_id)): continue
			var end_clock := _date_clock(str(event.get("end_date",event.start_date)))
			if _ordinal(end_clock) == _ordinal(career.clock.to_dict()) and _date_due(career,str(event.get("actual_dates",{}).get("end",event.get("end_date",event.start_date)))):
				return _node(career,"season_transition","先同步本季度世界资格赛，再继续训练；不新增参赛确认。",str(event.event_id))
	# Background-only events must not mask the player's later due entry.
	var actionable_bundle := unplayed_bundle.duplicate(true)
	actionable_bundle.calendar.events = []
	for event in unplayed_bundle.get("calendar", {}).get("events", []):
		var status := _entry_status(career,str(event.event_id))
		var registration: bool = not event.get("background_only",false) and not status in ["confirmed","declined"] and _archive(career,str(event.event_id)).is_empty()
		if registration and _registration_expired(career,event,bundle): registration = false
		if preload("res://src/simulation/jgp_second_start_service.gd").pending(career,event): registration = false
		if not registration and status != "confirmed": continue
		var possible_date := _registration_date(career, event) if registration else str(event.get("actual_dates",{}).get("start",event.start_date))
		if registration:
			var personal: Dictionary = preload("res://src/simulation/international_personal_eligibility.gd").policy_for(event)
			if not personal.is_empty(): possible_date = str(personal.cutoff)
		if _ordinal(_date_clock(possible_date)) > _ordinal(career.clock.to_dict()): continue
		actionable_bundle.calendar.events.append(event)
	# Use the same lazy chronological selection as the coordinator. A rejected
	# foreign entry is background only, so remove it and look for a later due
	# player action instead of qualifying every unrelated future event first.
	while not actionable_bundle.calendar.events.is_empty():
		var due := _next_event(career,actionable_bundle)
		if due.is_empty() or _ordinal(due.clock) > _ordinal(career.clock.to_dict()): return {}
		if career.competition_timeline.mode == "dated" and not _date_due(career,_dated_training_target(career,due,bundle)): return {}
		var registration: bool = due.kind == "registration"
		if registration or _entry_status(career,str(due.event.event_id)) == "confirmed":
			return _node(career,"registration" if registration else "competition_check_in","本季度赛事尚未处理",due.event.event_id,Entry.options(career,due.event,bundle) if registration else [{"id":"check_in"}])
		actionable_bundle.calendar.events = actionable_bundle.calendar.events.filter(func(event):return event.event_id != due.event.event_id)
	return {}

static func _due_confirmed_event(career, bundle: Dictionary) -> Dictionary:
	var selected := bundle.duplicate(true)
	selected.calendar.events = bundle.get("calendar",{}).get("events",[]).filter(func(event): return _entry_status(career,str(event.event_id)) == "confirmed")
	var due := _next_event(career,selected)
	if due.is_empty() or _ordinal(due.clock) > _ordinal(career.clock.to_dict()): return {}
	if career.competition_timeline.mode == "dated" and not _date_due(career,_dated_training_target(career,due,bundle)): return {}
	return due

static func _date_due(career,date: String) -> bool:
	return career.competition_timeline.mode != "dated" or date <= str(career.competition_timeline.date)

static func _unresolved_dated_event(career,bundle: Dictionary,confirmed_only: bool = false) -> Dictionary:
	for event in preload("res://src/content/season_calendar_repository.gd").playable_events(bundle.get("calendar",{})):
		if preload("res://src/simulation/dated_training_service.gd").has_exact_event_dates(event): continue
		# A legacy completed player race remains real history even if its date
		# precision is low. It cannot be withdrawn or relabelled as unplayed.
		if not _archive(career,str(event.event_id)).is_empty(): continue
		if _receipt(career,"season_event",str(bundle.calendar.season_id),str(event.event_id)): continue
		if confirmed_only and _entry_status(career,str(event.event_id)) != "confirmed": continue
		return event
	return {}

static func _unknown_dates_node(career,event: Dictionary) -> Dictionary:
	return _node(career,"entry_revalidation","旧档已报名赛事的史料只有月份，无法核对实际比赛日；请明确退赛后继续训练，不虚构日期或成绩。",str(event.event_id),[{"id":"withdraw","label":"退出日期无法核对的旧报名（报名费不退）","available":true}])

static func _dated_training_target(career,next: Dictionary,bundle: Dictionary) -> String:
	if next.is_empty(): return _previous_date("%04d-07-01" % (int(bundle.calendar.calendar_year)+1))
	if next.kind == "registration":
		var race_eve := _previous_date(str(next.event.get("actual_dates",{}).get("start",next.event.start_date)))
		return str(next.date) if str(next.date) < race_eve else race_eve
	if _entry_status(career,str(next.event.event_id)) == "confirmed":
		return _previous_date(str(next.event.get("actual_dates",{}).get("start",next.event.start_date)))
	return str(next.date)

static func _previous_date(date: String) -> String:
	return Time.get_date_string_from_unix_time(int(Time.get_unix_time_from_datetime_string(date+"T00:00:00"))-86400)

static func _pending(career) -> Dictionary:
	var decision: Dictionary = career.condition_state.get("pending_decision",{})
	if not decision.is_empty():
		var offered: Dictionary = load("res://src/simulation/rehabilitation_service.gd").options(career,str(decision.get("injury_id","")))
		var treatment := _node(career,"rehabilitation_decision","请先与医疗团队确认康复路线","",offered.routes)
		treatment.injury_id = decision.get("injury_id","")
		treatment.treatment = offered
		return treatment
	var pending := KeyNodes.pending(career)
	if not pending.is_empty():
		var node := _node(career,str(pending[0].kind),str(pending[0].label),"",[{"id":"acknowledge","label":"确认并讨论安排"}])
		node.id = pending[0].id
		return node
	if not career.competition_state.is_empty():
		var kinds := {"practice_ready":"competition_practice","short_ready":"competition_short","free_adjustment":"between_segments","free_ready":"competition_free","complete":"result_acknowledgement"}
		var kind := str(kinds.get(career.competition_state.get("status",""),"competition_check_in"))
		return _node(career,kind,"当前比赛尚有需要处理的环节",str(career.competition_state.get("event_id","")),[{"id":"resume_competition"}])
	if not career.condition_state.get("pending_training_events",[]).is_empty():
		return _node(career,"training_decision","训练中出现需要讨论的变化","",career.condition_state.pending_training_events[0].choices)
	if career.internal_invitation_state.get("status") != "deferred" and load("res://src/simulation/internal_invitation_service.gd").status(career).ready:
		return _node(career,"internal_invitation","俱乐部邀请你参加内部赛","",[{"id":"enter"},{"id":"defer"}])
	return {}

static func _background_bundle(career,bundle: Dictionary) -> Dictionary:
	var year := int(bundle.get("calendar",{}).get("calendar_year",0))
	var required := str({2020:"isu_wc2021",2021:"isu_olympic_qualifier_nebelhorn_2021",2023:"isu_wc2024",2024:"isu_wc2025",2025:"isu_olympic_qualifier_beijing_2025"}.get(year,""))
	if required.is_empty() or bundle.calendar.events.any(func(event):return event.get("event_id") == required): return bundle
	var loaded := preload("res://src/content/season_calendar_repository.gd").load_international_calendar(year,"women_singles","senior")
	var result: Dictionary = bundle.duplicate(true)
	if not loaded.errors.is_empty():
		result.errors.append_array(loaded.errors)
		return result
	for raw in loaded.calendar.events:
		if raw.get("event_id") != required: continue
		var event: Dictionary = raw.duplicate(true)
		event.background_only = true
		event.background_no_retroactive = _ordinal(career.clock.to_dict()) > _ordinal(_date_clock(str(event.end_date)))
		result.calendar.events.append(event)
		return result
	result.errors.append("缺少本周期国家资格世界赛事："+required)
	return result

static func _next_event(career,bundle: Dictionary) -> Dictionary:
	var candidates: Array = []
	if career.beijing_trial_series.status == "collecting" and not _receipt(career,"beijing_dispatch_checked",str(bundle.calendar.season_id),"beijing2022_women_trials"):
		var olympic: Array = bundle.calendar.get("events",[]).filter(func(event):return event.get("event_id") == "isu_owg2022")
		# Domestic senior trials are independent of the athlete's primary
		# international group. Their deadline must also settle on junior routes.
		if olympic.is_empty() and str(bundle.calendar.season_id) == "2021-22" and str(career.beijing_trial_series.season_id) == "2021-22":
			var senior: Dictionary = preload("res://src/content/season_calendar_repository.gd").load_international_calendar(2021,"women_singles","senior")
			if senior.errors.is_empty(): olympic = senior.calendar.events.filter(func(event):return event.get("event_id") == "isu_owg2022")
		if olympic.size() == 1: candidates.append({"kind":"beijing_dispatch","event":olympic[0],"date":"2022-01-24","clock":{"year":2022,"quarter":1},"deadline_basis":"adopted_personal_TES_cutoff"})
	for event in preload("res://src/content/season_calendar_repository.gd").playable_events(bundle.calendar):
		if _receipt(career,"season_event",str(bundle.calendar.season_id),str(event.event_id)): continue
		if career.competition_timeline.mode == "dated" and not preload("res://src/simulation/dated_training_service.gd").has_exact_event_dates(event): continue
		var status := _entry_status(career,str(event.event_id))
		var registration: bool = not event.get("background_only",false) and not status in ["confirmed","declined"] and _archive(career,str(event.event_id)).is_empty()
		if registration and _registration_expired(career,event,bundle):
			registration = false
			# A migrated legacy cursor cannot supply present-day abilities for
			# an unrecorded race that finished before that cursor.
			var finish := str(event.get("actual_dates",{}).get("end",event.get("end_date",event.start_date)))
			var past: bool = str(career.competition_timeline.date) > finish if career.competition_timeline.mode == "dated" else _ordinal(_date_clock(finish)) < _ordinal(career.clock.to_dict())
			if past:
				event = event.duplicate(true)
				event.background_no_retroactive = true
		# A participant needs the first actual competition day for check-in;
		if preload("res://src/simulation/jgp_second_start_service.gd").pending(career,event): registration = false
		# absent-player results become known only after the actual final day.
		var event_date := str(event.get("actual_dates",{}).get("start",event.start_date)) if status == "confirmed" else str(event.get("actual_dates",{}).get("end",event.get("end_date",event.start_date)))
		var date := _registration_date(career, event) if registration else event_date
		var personal_policy: Dictionary = preload("res://src/simulation/international_personal_eligibility.gd").policy_for(event)
		if registration and not personal_policy.is_empty(): date = str(personal_policy.cutoff)
		var deadline_basis := "adopted_qualification_policy" if registration and not personal_policy.is_empty() else "published" if event.has("application_deadline") else "event_start_fallback"
		if registration and not preload("res://src/simulation/jgp_second_start_service.gd").substitution_deadline(career,event).is_empty(): deadline_basis = "game_policy"
		if registration and personal_policy.is_empty() and event.get("application_deadline_game_policy",false):
			deadline_basis = "game_policy"
		candidates.append({"kind":"registration" if registration else "event","event":event,"date":date,"clock":_date_clock(date),"deadline_basis":deadline_basis})
	# Evaluate only a registration that could actually be next. Unrelated
	# future international previews repeatedly scan the same archive history.
	# A rejected registration becomes its normal background event and must be
	# re-sorted: another deadline may now precede that event's final day.
	while not candidates.is_empty():
		candidates.sort_custom(func(a,b):
			if a.date != b.date: return a.date < b.date
			if a.kind != b.kind: return a.kind == "registration"
			return int(a.event.sequence) < int(b.event.sequence))
		var next: Dictionary = candidates.pop_front()
		if next.kind == "registration" and str(next.event.get("scope","")) == "international":
			var actionable := Entry.options(career,next.event,bundle).any(func(option):return option.id in ["enter","self_fund_enter","request_assignment","request_nomination"] and bool(option.available))
			if not actionable:
				next.kind = "event"
				next.date = str(next.event.get("actual_dates",{}).get("end",next.event.get("end_date",next.event.start_date)))
				next.clock = _date_clock(next.date)
				next.deadline_basis = "published" if next.event.has("application_deadline") else "event_start_fallback"
				candidates.append(next)
				continue
		return next
	return {}

static func _close(career,bundle: Dictionary) -> void:
	var season_id := str(bundle.calendar.season_id)
	var next_year := int(bundle.calendar.calendar_year)+1
	var next_id := "%d-%02d" % [next_year,(next_year+1)%100]
	var old: Dictionary = career.season_state.duplicate(true)
	var history: Dictionary = old.get("season_history",{}).duplicate(true)
	old.erase("season_history")
	history[season_id] = {"season":old,"record_book":career.record_book.duplicate(true),"ranking_state":career.ranking_state.duplicate(true),"clock":career.clock.to_dict()}
	var selections: Dictionary = career.selection_state.duplicate(true)
	var selection_history: Dictionary = selections.get("season_history",{}).duplicate(true)
	selections.erase("season_history"); selection_history[season_id] = selections
	career.selection_state = {"applications":{},"assignments":{},"appeals":[],"season_history":selection_history}
	career.season_state = {"season_id":next_id,"entry_plan":{},"qualification_state":{},"event_statuses":{},"season_history":history,"coach_feedback":"本季成绩与身体记录已保存，请讨论下一赛季目标与训练安排。"}
	Ranking.begin_season(career.ranking_state,next_year)
	for record in career.world_athletes.values():
		if not record.has("ranking_state"): record.ranking_state = {}
		Ranking.begin_season(record.ranking_state,next_year)
	Ranking.refresh_ranks(career.ranking_state,career.world_athletes)
	career.world_state.season_id = next_id
	career.event_ledger.append({"kind":"season_closed","season_id":season_id,"next_season_id":next_id,"clock":career.clock.to_dict(),"reason":"赛季排名与SB已归档；PB及比赛档案保留"})

static func _registration_date(career, event: Dictionary) -> String:
	var substitution := preload("res://src/simulation/jgp_second_start_service.gd").substitution_deadline(career,event)
	if not substitution.is_empty(): return substitution
	if event.has("nomination_deadline") and not career.selection_state.assignments.get("player", []).has(event.event_id):
		return str(event.nomination_deadline)
	return str(event.get("application_deadline", event.start_date))

static func _registration_expired(career, event: Dictionary, bundle: Dictionary) -> bool:
	var deadline := _registration_date(career,event)
	if deadline.is_empty(): return false
	if career.competition_timeline.mode == "dated":
		if str(career.competition_timeline.date) <= deadline: return false
	elif _ordinal(_date_clock(deadline)) >= _ordinal(career.clock.to_dict()): return false
	# Keep explicit exceptions (including a pre-entered JGP name-list change).
	return not Entry.options(career,event,bundle).any(func(option):return option.id in ["enter","self_fund_enter","request_assignment","request_nomination"] and bool(option.available))

static func _entry_status(career,event_id: String) -> String:
	return str(career.season_state.get("entry_plan",{}).get("entries",{}).get(event_id,{}).get("status",""))

static func _archive(career,event_id: String) -> Dictionary:
	for archive in career.competition_archive:
		if archive.get("event_id") == event_id and archive.get("status") == "complete" and not archive.get("world_only",false): return archive
	return {}

static func _receipt(career,kind: String,season_id: String,event_id: String = "") -> bool:
	return career.event_ledger.any(func(e): return e.get("kind") == kind and e.get("season_id") == season_id and (event_id.is_empty() or e.get("event_id") == event_id))

static func _date_clock(date: String) -> Dictionary:
	return {"year":date.left(4).to_int(),"quarter":(date.substr(5,2).to_int()-1)/3+1}

static func _ordinal(clock: Dictionary) -> int:
	return int(clock.year)*4+int(clock.quarter)

static func _node(career,kind: String,reason: String,event_id: String = "",choices: Array = []) -> Dictionary:
	return {"kind":kind,"clock":career.clock.to_dict(),"event_id":event_id,"choices":choices,"reason":reason}

static func _closed_node(career, season_id: String) -> Dictionary:
	var node := _node(career,"season_complete","赛季已经归档，可以回顾这一路，再安排下一赛季。")
	node.closed_season_id = season_id
	return node

static func _result(career,node: Dictionary,errors: Array = []) -> Dictionary:
	return {"career":career,"advanced_clock":career.clock.to_dict() if career != null else {},"stop_node":node,"ledger":career.event_ledger.duplicate(true) if career != null else [],"errors":errors}
