class_name JumpTransferSimulator
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const JumpFamilyCatalog = preload("res://src/domain/jump_family_catalog.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")

const ROTATION_KEYS := {1: "single", 2: "double", 3: "triple", 4: "quad"}
const FOUNDATION_WEIGHTS := {
	"takeoff_power": 0.70, "speed_conversion": 0.45, "timing": 0.40,
	"air_axis": 0.65, "air_tightness": 0.80, "spatial_awareness": 0.45,
	"rotation_completion": 0.55, "landing_control": 0.60, "landing_flow": 0.35,
}

static func apply(
	career,
	jump_id: String,
	rotations: int,
	effective_attempts: int,
	training_quality: float,
	rng: RandomNumberGenerator,
) -> Array[OutcomeRecord]:
	var outcomes: Array[OutcomeRecord] = []
	if not JumpCatalog.JUMP_IDS.has(jump_id) or not ROTATION_KEYS.has(rotations) or effective_attempts <= 0:
		return outcomes
	var quality := clampf(training_quality, 0.0, 1.0)
	if quality <= 0.0:
		return outcomes
	var foundation = career.athlete.jump_foundation
	var base_gain := effective_attempts * 0.012 * quality * rng.randf_range(0.95, 1.05)
	for field_name in FOUNDATION_WEIGHTS:
		var previous := float(foundation.get(field_name))
		var delta := base_gain * float(FOUNDATION_WEIGHTS[field_name]) * (1.0 - previous / 100.0)
		foundation.set(field_name, clampf(previous + delta, 0.0, 100.0))
		outcomes.append(OutcomeRecord.new(
			"jump_foundation", field_name, float(foundation.get(field_name)) - previous,
			["%s_practice" % jump_id, "shared_foundation_transfer"], "jump_foundation_change",
		))

	var source = career.athlete.jumps[jump_id]
	var rotation_key: String = ROTATION_KEYS[rotations]
	var related_jumps := JumpFamilyCatalog.related(jump_id)
	for related_id in related_jumps:
		var family_weight := float(related_jumps[related_id])
		var target = career.athlete.jumps[related_id]
		var previous_proficiency := float(target.proficiency[rotation_key])
		var specialty_gain := effective_attempts * 0.006 * quality * family_weight
		specialty_gain *= 1.0 - previous_proficiency / 100.0
		target.proficiency[rotation_key] = clampf(previous_proficiency + specialty_gain, 0.0, 100.0)
		if specialty_gain > 0.0:
			outcomes.append(OutcomeRecord.new(
				"jump_transfer", "%s.%s.proficiency" % [related_id, rotation_key], specialty_gain,
				["%s_practice" % jump_id, "jump_family_transfer"], "jump_family_skill_change",
			))

		var source_rigidity := float(source.habits.rigidity)
		if source_rigidity > 0.0:
			var previous_rigidity := float(target.habits.rigidity)
			var edge_factor := 1.35 if float(source.takeoff.edge_quality) < 35.0 else 1.0
			var rigidity_gain := effective_attempts * 0.002 * quality * family_weight * (source_rigidity / 100.0) * edge_factor
			target.habits.rigidity = clampf(previous_rigidity + rigidity_gain, 0.0, 100.0)
			if rigidity_gain > 0.0:
				outcomes.append(OutcomeRecord.new(
					"jump_habit", "%s.rigidity" % related_id, float(target.habits.rigidity) - previous_rigidity,
					["%s_practice" % jump_id, "latent_family_habit_transfer"], "latent_jump_habit_change",
				))
	return outcomes
