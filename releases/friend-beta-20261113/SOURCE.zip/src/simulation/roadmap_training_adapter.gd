class_name RoadmapTrainingAdapter
extends RefCounted

const TrainingPolicy = preload("res://src/domain/training_policy.gd")

static func build_policy(career, roadmap, evaluation: Dictionary) -> Dictionary:
	var focus: Array[String] = []
	for jump_id in evaluation.get("near_term_focus", roadmap.priority_jumps):
		var normalized := str(jump_id)
		if normalized == roadmap.deferred_jump or focus.has(normalized) or focus.size() >= 2: continue
		focus.append(normalized)
	var risks: Array = evaluation.get("risk_codes", [])
	var policy_id := _base_policy(roadmap.route_id)
	var temporary := false
	var reason_codes: Array[String] = ["roadmap_%s" % roadmap.route_id]
	if risks.has("high_body_load") or risks.has("growth_acceleration"):
		policy_id = "recovery"; focus.clear(); temporary = true; reason_codes.append("roadmap_body_safety_override")
	elif risks.has("observed_technique_risk"):
		policy_id = "technique_rebuild"; temporary = true; reason_codes.append("roadmap_technique_rebuild")
	elif ["slightly_behind", "far_behind"].has(str(evaluation.get("status", "on_track"))):
		policy_id = "rotation_push"; reason_codes.append("roadmap_milestone_pressure")
	var target_rotations := {}
	var next_rotations := _next_rotations(roadmap, evaluation)
	for jump_id in focus: target_rotations[jump_id] = next_rotations
	var risk := _risk_for(roadmap)
	if policy_id == "recovery": risk = "cautious"
	var policy_result := TrainingPolicy.create(policy_id, focus, target_rotations, risk)
	return {"policy": policy_result.policy, "reason_codes": reason_codes, "temporary_override": temporary, "errors": policy_result.errors}

static func _base_policy(route_id: String) -> String:
	if route_id == "fast": return "rotation_push"
	return "balanced_foundation"

static func _risk_for(roadmap) -> String:
	if roadmap.route_id == "steady": return "cautious"
	if roadmap.route_id == "fast": return "aggressive"
	return roadmap.risk_attitude

static func _next_rotations(roadmap, evaluation: Dictionary = {}) -> int:
	for forecast in evaluation.get("milestone_forecasts", []):
		if int(forecast.get("current_count", 0)) < int(forecast.get("count", 0)):
			return clampi(int(forecast.get("rotations", 1)), 1, 4)
	if roadmap.milestones.is_empty(): return 1
	return clampi(int(roadmap.milestones[-1].rotations), 1, 4)
