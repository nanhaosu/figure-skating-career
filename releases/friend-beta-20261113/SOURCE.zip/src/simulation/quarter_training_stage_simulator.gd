class_name QuarterTrainingStageSimulator
extends RefCounted

const TrainingPlan = preload("res://src/domain/training_plan.gd")
const JumpAttemptBatchSimulator = preload("res://src/simulation/jump_attempt_batch_simulator.gd")
const JumpTrainingSimulator = preload("res://src/simulation/jump_training_simulator.gd")
const JumpTransferSimulator = preload("res://src/simulation/jump_transfer_simulator.gd")

const MIN_STAGES := 3
const MAX_STAGES := 6
const DEFAULT_STAGES := 4
const ATTEMPT_FATIGUE := 0.12

static func simulate(career, plan, volume: Dictionary, rng: RandomNumberGenerator, assessment_rules: Dictionary = {}) -> Dictionary:
	var result := {
		"stage_count": 0, "outcomes": [], "aggregate_batches": [],
		"key_events": [], "milestones": [], "strategy_changes": [],"actual_jump_attempts":0,
		"checkpoint":{},"completed":false,"errors":[],
	}
	if career == null or plan == null or plan.shares.is_empty():
		return result
	var total_attempts := 0
	for attempts in volume.get("jump_attempts", {}).values():
		total_attempts += int(attempts)
	for specialist in volume.get("specialist_attempts",[]):
		total_attempts += int(specialist.attempts)*specialist.action.parts.size()
	if total_attempts <= 0 and not volume.has("stage_checkpoint"):
		return result
	var stage_count := clampi(DEFAULT_STAGES, MIN_STAGES, MAX_STAGES)
	result.stage_count = stage_count
	var original_acute := float(career.athlete.body.acute_fatigue)
	if not volume.get("stage_checkpoint",{}) is Dictionary:
		result.errors.append("训练阶段检查点必须为对象")
		return result
	var checkpoint: Dictionary = volume.get("stage_checkpoint",{})
	for number in [checkpoint.get("next_stage",0),volume.get("stage_limit",stage_count)]:
		if not (number is int or number is float) or not is_finite(float(number)) or float(number) != floorf(float(number)):
			result.errors.append("训练阶段编号必须为整数")
			return result
	var start_stage := int(checkpoint.get("next_stage",0))
	var limit := int(volume.get("stage_limit",stage_count))
	var identity := "%d:%d:%d" % [career.clock.year,career.clock.quarter,career.rng_step]
	if start_stage < 0 or start_stage > stage_count or limit < 1:
		result.errors.append("训练阶段检查点无效")
		return result
	if not checkpoint.is_empty():
		var saved_rng := str(checkpoint.get("rng_state",""))
		var offset = checkpoint.get("acute_offset")
		if not (offset is int or offset is float) or not is_finite(float(offset)) or float(offset) < 0.0 or float(offset) > 100.0:
			result.errors.append("训练阶段疲劳记录无效")
			return result
		if str(checkpoint.get("identity","")) != identity or not saved_rng.is_valid_int() or str(int(saved_rng)) != saved_rng:
			result.errors.append("训练阶段检查点不属于当前训练期")
			return result
		rng.state = int(checkpoint.rng_state)
		career.athlete.body.acute_fatigue = clampf(original_acute+float(checkpoint.get("acute_offset",0.0)),0.0,100.0)
	var end_stage := mini(stage_count,start_stage+limit)
	var executed_end := start_stage
	for stage_index in range(start_stage,end_stage):
		var stage_attempt_total := 0
		var lesson_batches: Array = []
		var batch_id := "%d:%d:%d:stage:%d" % [career.clock.year,career.clock.quarter,career.rng_step,stage_index]
		for jump_id in TrainingPlan.JUMP_LABELS:
			var attempts := _stage_share(int(volume.jump_attempts.get(jump_id, 0)), stage_count, stage_index)
			if attempts <= 0:
				continue
			stage_attempt_total += attempts
			var rotations := int(plan.jump_rotations.get(jump_id, 1))
			var quality := float(volume.get("jump_qualities",{}).get(jump_id,volume.get("quality",1.0)))
			var batch: Dictionary = JumpAttemptBatchSimulator.simulate(career, jump_id, rotations, attempts, quality, rng)
			if batch.outcomes.is_empty():
				stage_attempt_total -= attempts
				continue
			var batch_record: Dictionary = batch.outcomes[0].duplicate(true)
			batch_record.stage = stage_index + 1
			result.aggregate_batches.append(batch_record)
			lesson_batches.append(batch_record)
			result.milestones.append_array(batch.milestones)
			for milestone in batch.milestones:
				if _should_interrupt(career, milestone):
					result.key_events.append(milestone.duplicate(true))
			result.outcomes.append_array(JumpTrainingSimulator.apply(career, jump_id, rotations, attempts, quality, rng, false))
			result.outcomes.append_array(JumpTransferSimulator.apply(career, jump_id, rotations, attempts, quality, rng))
			preload("res://src/simulation/repertoire_evidence_service.gd").record(career,{"action":{"kind":"jump","parts":[{"jump_id":jump_id,"rotations":rotations}]},"action_id":"%d%s" % [rotations,preload("res://src/domain/technical_repertoire.gd").CODES[jump_id]],"batch_id":batch_id,"clock":career.clock.to_dict(),"context":"practice","attempts":attempts,"successes":batch.successes,"clean_successes":batch.clean_successes,"failure_counts":{"falls":batch.falls,"pops":batch.pops},"assessment_eligible":true})
		for specialist in volume.get("specialist_attempts",[]):
			var count := _stage_share(int(specialist.attempts),stage_count,stage_index)
			if count <= 0: continue
			var context := {"quality":float(specialist.get("quality",volume.get("quality",1.0))),"evidence_context":"specialist"}
			if stage_index >= 2:
				context.merge(_rehearsal_context(career,plan,specialist.action),true)
			var combo: Dictionary = preload("res://src/simulation/combination_training_service.gd").simulate(career,specialist.action,count,batch_id,context,rng)
			result.outcomes.append_array(combo.outcomes)
			stage_attempt_total += int(combo.actual_load.jump_attempts)
			if not combo.evidence.is_empty():
				result.aggregate_batches.append({"category":"combination_training","target":combo.evidence.action_id,"delta":float(combo.evidence.successes),"cause_codes":["specialist_practice"],"summary_key":"combination_practice","attempts":combo.evidence.attempts,"successes":combo.evidence.successes,"stage":stage_index+1})
		result.actual_jump_attempts += stage_attempt_total
		career.athlete.body.acute_fatigue = clampf(
			float(career.athlete.body.acute_fatigue) + stage_attempt_total * ATTEMPT_FATIGUE,
			0.0, 100.0,
		)
		executed_end = stage_index+1
		result.outcomes.append_array(preload("res://src/simulation/coach_lesson_service.gd").settle(career,plan,1.0/float(stage_count),lesson_batches))
		preload("res://src/simulation/coach_training_memory_service.gd").record_stage(career,plan,lesson_batches)
		preload("res://src/simulation/athlete_condition_service.gd").assess_training_stage(career,stage_attempt_total,plan,assessment_rules)
		preload("res://src/simulation/external_training_service.gd").settle_stage(career)
		for action_id in career.technical_repertoire.entries:
			preload("res://src/simulation/repertoire_evaluator.gd").evaluate(career,str(action_id))
		if not career.condition_state.get("pending_decision",{}).is_empty(): break
	# Stage fatigue influences later attempts; the quarter-level fatigue outcome remains authoritative.
	result.checkpoint = {"identity":identity,"next_stage":executed_end,"rng_state":str(rng.state),"acute_offset":float(career.athlete.body.acute_fatigue)-original_acute}
	result.completed = executed_end == stage_count
	career.athlete.body.acute_fatigue = original_acute
	return result

static func _stage_share(total: int, stage_count: int, stage_index: int) -> int:
	return total / stage_count + (1 if stage_index < total % stage_count else 0)

static func _rehearsal_context(career, plan, action: Dictionary) -> Dictionary:
	var id := preload("res://src/domain/technical_repertoire.gd").action_id(action)
	for segment in ["short","free"]:
		if int(plan.shares.get("program_"+segment,0)) <= 0: continue
		var data: Dictionary = career.active_programs.get(segment,{})
		var elements: Array = data.get("elements",[])
		var prefix_load := 0.0
		for index in elements.size():
			var element: Dictionary = elements[index]
			if element.kind == "jump":
				var parts: Array = [{"jump_id":element.jump_id,"rotations":element.rotations}]
				parts.append_array(element.get("combination_parts",[]))
				if preload("res://src/domain/technical_repertoire.gd").action_id({"kind":"jump","parts":parts}) == id:
					return {"evidence_context":"program_late" if index >= elements.size()/2 else "program_early","program_data":data,"element":element,"index":index,"starting_fatigue":float(career.athlete.body.acute_fatigue)+prefix_load,"familiarity":float(data.get("whole_run_familiarity",0.0))}
			prefix_load += 3.0 if element.kind == "jump" else 2.0
	return {}

static func _should_interrupt(career, milestone: Dictionary) -> bool:
	if not str(milestone.get("signature", "")).begins_with("first_jump_success"):
		return false
	return str(career.training_preferences.get("breakthrough_policy", "summary")) == "ask"
