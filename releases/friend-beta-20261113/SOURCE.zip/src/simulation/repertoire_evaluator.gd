class_name RepertoireEvaluator
extends RefCounted

const Rules = preload("res://src/content/repertoire_health_rules.gd")
const Functions = preload("res://src/simulation/athlete_function_service.gd")
const Element = preload("res://src/domain/program_element.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Execution = preload("res://src/simulation/program_performance_simulator.gd")

static func evaluate(career, id: String, rules: Dictionary = {}) -> Dictionary:
	var config := Rules.load_rules()
	config.merge(rules,true)
	var invalid := Rules.validate(config)
	if not invalid.is_empty(): return {"state":"training","reason_codes":["invalid_rules"],"review_conditions":[],"evidence_summary":{},"context_warnings":[],"error":invalid}
	var entries: Dictionary = career.technical_repertoire.entries
	if not entries.has(id): return {"state":"training","reason_codes":["no_evidence"],"review_conditions":[],"evidence_summary":{},"context_warnings":[]}
	var item: Dictionary = entries[id]
	var constraints := Functions.action_constraints(career,item.action)
	var positive := _window(item.evidence,int(config.evidence_window),false)
	var negatives: Array = []
	var late: Array = []
	for evidence in item.evidence:
		if evidence.context == "program_late": late.append(evidence)
		elif bool(evidence.assessment_eligible) and evidence.context != "competition": negatives.append(evidence)
	var warning := _window(negatives,int(config.warning_batches),true)
	var withdrawal := _window(negatives,int(config.withdraw_batches),true)
	var result := {"state":str(item.state),"reason_codes":[],"review_conditions":[],"evidence_summary":positive,"context_warnings":[]}
	var late_window := _window(late,3,false)
	if int(late_window.attempts) >= 12 and float(late_window.rate) < float(config.warning_rate):
		result.context_warnings.append("late_program_unreliable")
	if not constraints.allowed:
		result.state = "unavailable"
		result.reason_codes.append("medical_restriction")
		result.review_conditions = constraints.review_conditions.duplicate()
	else:
		var enough_entry := int(positive.batches) >= int(config.entry_batches) and int(positive.attempts) >= int(config.entry_attempts) and int(positive.successes) >= int(config.entry_successes) and float(positive.rate) >= float(config.entry_rate)
		# Entering after a prior loss requires new evidence, not replaying the
		# same successful training that predated the restriction.
		if item.state == "unavailable":
			var fresh: Array = []
			for row in item.evidence:
				if int(row.get("sequence",0)) > int(item.get("revalidation_after_sequence",0)): fresh.append(row)
			var restored := _window(fresh,int(config.evidence_window),false)
			enough_entry = int(restored.batches) >= int(config.entry_batches) and int(restored.attempts) >= int(config.entry_attempts) and int(restored.successes) >= int(config.entry_successes) and float(restored.rate) >= float(config.entry_rate)
		if enough_entry:
			result.state = "available"
			item.legacy_unverified = false
			item.learned_history.ever_learned = true
		elif item.state != "available": result.reason_codes.append("needs_validation")
		if int(warning.batches) >= int(config.warning_batches) and int(warning.attempts) >= int(config.warning_attempts) and float(warning.rate) < float(config.warning_rate):
			result.reason_codes.append("persistent_decline")
		var durable := float(Functions.snapshot(career).acute_fatigue) < 30.0
		if item.state == "available" and durable and int(withdrawal.batches) >= int(config.withdraw_batches) and int(withdrawal.attempts) >= int(config.withdraw_attempts) and float(withdrawal.rate) < float(config.withdraw_rate) and _current_estimate(career,item.action) < float(config.withdraw_rate):
			result.state = "unavailable"
			result.reason_codes.append("insufficient_current_capacity")
		if result.state == "available" and int(positive.batches) >= int(config.stable_batches) and int(positive.attempts) >= int(config.stable_attempts) and float(positive.rate) >= float(config.stable_rate):
			result.reason_codes.append("repeatedly_validated")
		if item.legacy_unverified: result.reason_codes.append("legacy_unverified")
	if result.state == "unavailable" and item.state != "unavailable":
		item.revalidation_after_sequence = int(item.learned_history.get("record_count",0))
	item.state = result.state
	item.reason_codes = result.reason_codes.duplicate()
	item.context_warnings = result.context_warnings.duplicate()
	return result

# Aggregate true batch IDs, never treating individual attempts as separate days.
static func _window(evidence: Array, batch_limit: int, eligible_only: bool) -> Dictionary:
	var ids: Array = []
	for index in range(evidence.size()-1,-1,-1):
		var row: Dictionary = evidence[index]
		if eligible_only and not bool(row.assessment_eligible): continue
		if not ids.has(row.batch_id):
			if ids.size() == batch_limit: break
			ids.append(row.batch_id)
	var result := {"batches":ids.size(),"attempts":0,"successes":0,"clean_successes":0,"rate":0.0}
	for row in evidence:
		if not ids.has(row.batch_id) or (eligible_only and not bool(row.assessment_eligible)): continue
		result.attempts += int(row.attempts)
		result.successes += int(row.successes)
		result.clean_successes += int(row.clean_successes)
	if int(result.attempts) > 0: result.rate = float(result.successes)/float(result.attempts)
	return result

static func _current_estimate(career, action: Dictionary) -> float:
	var first: Dictionary = action.parts[0]
	var element = Element.create("reserve_probe","jump",first.jump_id,int(first.rotations)).element
	element.set_combination_parts(action.parts.slice(1))
	var program = Program.create("reserve_probe","free",[element]).program
	# Neutral familiar context: a new programme or a bad competition day must
	# not masquerade as permanently lost technical capacity.
	program.whole_run_familiarity = 100.0
	program.slot_familiarity[element.element_id] = 100.0
	var context := {"pressure":0.0,"starting_fatigue":0.0,"event_scope":"internal"}
	if action.parts.size() > 1:
		return Execution.estimate_combination_success_probability(career.athlete,program,element,context)
	return Execution._part_success_probability(career.athlete,program,element.element_id,first,0.0,0.0,{},context)
