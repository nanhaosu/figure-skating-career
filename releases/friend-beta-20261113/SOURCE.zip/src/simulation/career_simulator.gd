class_name CareerSimulator
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const AuthorityResolver = preload("res://src/simulation/authority_resolver.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")
const JumpTrainingSimulator = preload("res://src/simulation/jump_training_simulator.gd")
const JumpTransferSimulator = preload("res://src/simulation/jump_transfer_simulator.gd")
const JumpAttemptBatchSimulator = preload("res://src/simulation/jump_attempt_batch_simulator.gd")
const EffectiveTrainingCalculator = preload("res://src/simulation/effective_training_calculator.gd")
const QuarterTrainingStageSimulator = preload("res://src/simulation/quarter_training_stage_simulator.gd")
const SecretPracticeSimulator = preload("res://src/simulation/secret_practice_simulator.gd")
const EventEngine = preload("res://src/simulation/event_engine.gd")
const DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
const DevelopmentRoadmapEvaluator = preload("res://src/simulation/development_roadmap_evaluator.gd")
const RoadmapProgressUpdater = preload("res://src/simulation/roadmap_progress_updater.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const ProgramTrainingSimulator = preload("res://src/simulation/program_training_simulator.gd")
const CertificationService = preload("res://src/simulation/certification_service.gd")
const RandomStreamState = preload("res://src/domain/random_stream_state.gd")
const AthleteConditionService = preload("res://src/simulation/athlete_condition_service.gd")

# Compatibility for event and authority previews that have not moved to named streams yet.
const RNG_STEP_OFFSET := RandomStreamState.STEP_OFFSET
const BASE_TECHNIQUE_GROWTH := 1.2
const ACTIVE_ACUTE_FATIGUE := 1.4
const ACTIVE_CUMULATIVE_FATIGUE := 0.35
const REST_ACUTE_RECOVERY := 4.0
const REST_CUMULATIVE_RECOVERY := 1.5
const JUMP_ANKLE_LOAD := 1.0
const OTHER_ACTIVE_ANKLE_LOAD := 0.25
const REST_ANKLE_RECOVERY := 2.5
const REST_IMPACT_RECOVERY := 2.0
# A percentage plan spans months of interleaved work and recovery. Its attempt
# batches are much larger than legacy lesson units; recovery uses that same scale.
const PERCENTAGE_MODE_REST_IMPACT_RECOVERY := 8.0

static func advance_quarter(career: CareerState, requested_plan: TrainingPlan, catalog: Dictionary) -> Array[OutcomeRecord]:
	if career.competition_timeline.mode == "dated": return []
	if not AthleteConditionService.can_train(career, requested_plan): return []
	var rng := _take_training_rng(career)
	var resolution := AuthorityResolver.resolve(career, requested_plan, rng)
	return _advance_with_plan(career, resolution.approved_plan, resolution.decisions, catalog, rng)

static func advance_proposal(career: CareerState, proposal, catalog: Dictionary) -> Array[OutcomeRecord]:
	if career.competition_timeline.mode == "dated": return []
	assert(proposal.status == "resolved")
	if not AthleteConditionService.can_train(career, proposal.executed): return []
	var rng := _take_training_rng(career)
	var secret_result := {"executed_units": 0, "efficiency": 0.0, "discovered": false, "reaction": "none", "outcomes": [], "memories": [], "blocked_reasons": []}
	if not proposal.secret_practice_intent.is_empty() and not career.training_period_state.has("stage_checkpoint"):
		secret_result = SecretPracticeSimulator.resolve(career, proposal.secret_practice_intent, rng)
	var plan_record := {
		"category": "quarter_plan",
		"training_efficiency": proposal.training_efficiency,
		"desired": proposal.desired.allocations.duplicate(true),
		"approved": proposal.approved.allocations.duplicate(true),
		"executed": proposal.executed.allocations.duplicate(true),
		"decisions": proposal.decisions.duplicate(true),
		"secret_practice": _secret_result_to_dict(secret_result),
		"cause_codes": ["secret_practice"] if int(secret_result.executed_units) > 0 else [],
	}
	if not proposal.executed.shares.is_empty():
		plan_record["desired_shares"] = proposal.desired.shares
		plan_record["approved_shares"] = proposal.approved.shares
		plan_record["executed_shares"] = proposal.executed.shares
		plan_record["desired_jump_rotations"] = proposal.desired.jump_rotations
		plan_record["approved_jump_rotations"] = proposal.approved.jump_rotations
		plan_record["executed_jump_rotations"] = proposal.executed.jump_rotations
	return _advance_with_plan(career, proposal.executed, proposal.decisions, catalog, rng, secret_result.outcomes, plan_record)

static func _advance_with_plan(career: CareerState, approved_plan: TrainingPlan, decisions: Array, catalog: Dictionary, rng: RandomNumberGenerator, initial_outcomes: Array = [], plan_record: Dictionary = {}) -> Array[OutcomeRecord]:
	var previous_roadmap_evaluation: Dictionary = career.development_roadmap.get("last_evaluation", {}).duplicate(true) if not career.development_roadmap.is_empty() else {}
	var percentage_mode := not approved_plan.shares.is_empty()
	var allocations: Dictionary = (approved_plan.shares if percentage_mode else approved_plan.allocations).duplicate(true)
	var resume_checkpoint: Dictionary = career.training_period_state.get("stage_checkpoint",{})
	var executed_expression_share := float(approved_plan.expression_share)
	var executed_expression_quality := float(approved_plan.lesson_quality.get("expression",1.0))
	var executed_lesson_quality: Dictionary = approved_plan.lesson_quality.duplicate(true)
	var executed_focus_lessons: Dictionary = approved_plan.focus_lessons.duplicate(true)
	var quality_weights := {}
	for category in allocations: quality_weights[category] = float(allocations[category])*float(approved_plan.lesson_quality.get(category,1.0))
	var effective_volume: Dictionary = EffectiveTrainingCalculator.calculate(career, approved_plan) if percentage_mode else {}
	var condition := AthleteConditionService.modifiers(career)
	var condition_efficiency := float(condition.training_efficiency) * float(plan_record.get("training_efficiency", 1.0))
	if percentage_mode:
		EffectiveTrainingCalculator.apply_efficiency(effective_volume, condition_efficiency)
		if not resume_checkpoint.is_empty():
			var same_plan: bool = JSON.parse_string(JSON.stringify(resume_checkpoint.get("plan",{}))) == JSON.parse_string(JSON.stringify(approved_plan.to_dict()))
			if same_plan: effective_volume = Dictionary(resume_checkpoint.volume).duplicate(true)
			effective_volume.stage_checkpoint = resume_checkpoint.duplicate(true)
		if career.training_period_state.has("stage_limit"): effective_volume.stage_limit = career.training_period_state.stage_limit
	var authority_causes := _authority_causes(decisions)
	var outcomes: Array[OutcomeRecord] = []
	var attempt_records: Array[Dictionary] = []
	for initial_outcome in initial_outcomes:
		outcomes.append(initial_outcome)
	var rest_units: float = float(allocations.rest) / TrainingPlan.SHARE_STEP if percentage_mode else float(allocations.rest)
	var jump_units := 0.0
	for jump_id in TrainingPlan.JUMP_LABELS:
		jump_units += int(allocations.get("jump_%s" % jump_id, 0)) / TrainingPlan.SHARE_STEP if percentage_mode else int(allocations.get("jump_%s" % jump_id, 0))
	var total_units := TrainingPlan.TOTAL_SHARE / TrainingPlan.SHARE_STEP if percentage_mode else TrainingPlan.UNITS_PER_QUARTER
	var active_units := total_units - rest_units
	var fatigue_multiplier := float(condition.fatigue_efficiency) * condition_efficiency
	var motivation_multiplier := 0.8 if float(career.athlete.mind.motivation) < 35.0 else 1.0
	var categories: Dictionary = catalog.get("training", {}).get("categories", {})
	var staged_training: Dictionary = {}
	if percentage_mode:
		staged_training = QuarterTrainingStageSimulator.simulate(career, approved_plan, effective_volume, rng)
		for staged_outcome in staged_training.outcomes:
			staged_outcome.cause_codes.append_array(authority_causes)
		outcomes.append_array(staged_training.outcomes)
		attempt_records.append_array(staged_training.aggregate_batches)
		for milestone in staged_training.milestones:
			var milestone_record: Dictionary = milestone.duplicate(true)
			milestone_record.interrupt = staged_training.key_events.any(
				func(key_event): return key_event.signature == milestone_record.signature
			)
			attempt_records.append(milestone_record)
		if int(staged_training.stage_count) > 0 and not bool(staged_training.completed):
			var checkpoint: Dictionary = staged_training.checkpoint.duplicate(true)
			var saved_volume: Dictionary = effective_volume.duplicate(true)
			saved_volume.erase("stage_checkpoint")
			saved_volume.erase("stage_limit")
			checkpoint.volume = saved_volume
			checkpoint.plan = approved_plan.to_dict()
			var completed_fraction := float(int(checkpoint.next_stage)-int(resume_checkpoint.get("next_stage",0)))/4.0
			checkpoint.shares_acc = _weighted_totals(resume_checkpoint.get("shares_acc",{}),allocations,completed_fraction)
			checkpoint.expression_share_acc = float(resume_checkpoint.get("expression_share_acc",0.0))+float(approved_plan.expression_share)*completed_fraction
			checkpoint.expression_quality_acc = float(resume_checkpoint.get("expression_quality_acc",resume_checkpoint.get("expression_share_acc",0.0)))+float(approved_plan.expression_share)*executed_expression_quality*completed_fraction
			checkpoint.lesson_quality_acc = _weighted_totals(resume_checkpoint.get("lesson_quality_acc",resume_checkpoint.get("shares_acc",{})),quality_weights,completed_fraction)
			checkpoint.focus_lessons_acc = _weighted_totals(resume_checkpoint.get("focus_lessons_acc",{}),approved_plan.focus_lessons,completed_fraction)
			checkpoint.category_volumes_acc = _weighted_totals(resume_checkpoint.get("category_volumes_acc",{}),effective_volume.category_volumes,completed_fraction)
			# Manual/policy execution can also stop for injury. Persist a complete
			# continuation contract rather than a checkpoint with missing intent.
			if not career.training_period_state.has("intent"):
				career.training_period_state.intent = {"mode":"accept","element_id":""}
			if not career.training_period_state.has("started_clock"):
				career.training_period_state.started_clock = career.clock.to_dict()
			career.training_period_state.plan = approved_plan.to_dict()
			career.training_period_state.stage_checkpoint = checkpoint
			career.training_period_state.weeks_elapsed = int(checkpoint.next_stage)*3
			career.history.append_array(OutcomeRecord.list_to_dict(outcomes))
			career.history.append_array(attempt_records)
			return outcomes
		if career.training_period_state.has("stage_checkpoint"):
			var remaining_fraction := float(4-int(resume_checkpoint.next_stage))/4.0
			executed_focus_lessons = _weighted_totals(resume_checkpoint.get("focus_lessons_acc",{}),approved_plan.focus_lessons,remaining_fraction)
			executed_expression_share = float(resume_checkpoint.get("expression_share_acc",0.0))+float(approved_plan.expression_share)*remaining_fraction
			var expression_quality_total := float(resume_checkpoint.get("expression_quality_acc",resume_checkpoint.get("expression_share_acc",0.0)))+float(approved_plan.expression_share)*executed_expression_quality*remaining_fraction
			executed_expression_quality = expression_quality_total/maxf(0.000001,executed_expression_share)
			var settled_quality_weights := _weighted_totals(resume_checkpoint.get("lesson_quality_acc",resume_checkpoint.get("shares_acc",{})),quality_weights,remaining_fraction)
			allocations = _weighted_totals(resume_checkpoint.get("shares_acc",{}),allocations,remaining_fraction)
			for category in settled_quality_weights:
				executed_lesson_quality[category] = float(settled_quality_weights[category])/maxf(0.000001,float(allocations.get(category,0.0))) if float(allocations.get(category,0.0)) > 0 else 1.0
			effective_volume.category_volumes = _weighted_totals(resume_checkpoint.get("category_volumes_acc",{}),effective_volume.category_volumes,remaining_fraction)
			rest_units = float(allocations.rest)/TrainingPlan.SHARE_STEP
			jump_units = 0.0
			for jump_id in TrainingPlan.JUMP_LABELS: jump_units += float(allocations.get("jump_%s" % jump_id,0))/TrainingPlan.SHARE_STEP
			active_units = total_units-rest_units
			career.training_period_state.erase("stage_checkpoint")
			career.training_period_state.weeks_elapsed = 12

	for category_id in TrainingPlan.CATEGORY_IDS:
		if category_id == "rest":
			continue
		var units: float = float(allocations[category_id]) / TrainingPlan.SHARE_STEP if percentage_mode else float(allocations[category_id])
		if units == 0:
			continue
		if TrainingPlan.PROGRAM_CATEGORY_IDS.has(category_id):
			var segment := category_id.trim_prefix("program_")
			var saved_program: Dictionary = career.active_programs.get(segment, {})
			if saved_program.is_empty():
				attempt_records.append({
					"category": "program_training_unavailable", "segment": segment,
					"requested_share": int(allocations[category_id]),
					"cause_codes": ["no_active_program"],
				})
				continue
			var program = SkatingProgram.from_dict(saved_program)
			if program == null:
				continue
			var effective_share := float(effective_volume.get("category_volumes", {}).get(category_id, allocations[category_id])) if percentage_mode else float(units * TrainingPlan.SHARE_STEP)
			var connections_fraction := clampf(float(executed_focus_lessons.get("connections_"+segment,0.0))/maxf(1.0,float(allocations[category_id])),0.0,1.0)
			attempt_records.append_array(ProgramTrainingSimulator.apply(program, effective_share*float(executed_lesson_quality.get(category_id,1.0)), career.athlete,connections_fraction))
			career.active_programs[segment] = program.to_dict()
			continue
		var target := str(categories.get(category_id, {}).get("target", ""))
		if category_id.begins_with("jump_"):
			if percentage_mode:
				continue
			var jump_id := category_id.trim_prefix("jump_")
			var rotations := int(approved_plan.jump_rotations.get(jump_id, 1)) if percentage_mode else 1
			var attempts: int = int(effective_volume.jump_attempts.get(jump_id, 0)) if percentage_mode else int(units * 8)
			var supervision := float(effective_volume.quality) if percentage_mode else fatigue_multiplier
			if percentage_mode:
				var batch: Dictionary = JumpAttemptBatchSimulator.simulate(career, jump_id, rotations, attempts, supervision, rng)
				attempt_records.append_array(batch.outcomes)
				attempt_records.append_array(batch.milestones)
			var jump_outcomes := JumpTrainingSimulator.apply(career, jump_id, rotations, attempts, supervision, rng, not percentage_mode)
			if percentage_mode:
				jump_outcomes.append_array(JumpTransferSimulator.apply(career, jump_id, rotations, attempts, supervision, rng))
			for outcome in jump_outcomes:
				outcome.cause_codes.append_array(authority_causes)
			outcomes.append_array(jump_outcomes)
			continue
		var growth := 0.0
		for unit in int(ceilf(units)):
			growth += BASE_TECHNIQUE_GROWTH * fatigue_multiplier * motivation_multiplier * rng.randf_range(0.9, 1.1) * minf(1.0,units-float(unit))
		var target_state: Dictionary
		if category_id == "skating_foundation" and executed_expression_share > 0.0:
			var expression_fraction := clampf(executed_expression_share/maxf(1.0,float(allocations.skating_foundation)),0.0,1.0)
			var expression_before := float(career.athlete.mind.expression)
			var expression_gain := growth*expression_fraction*maxf(0.0,1.0-expression_before/120.0)*executed_expression_quality
			career.athlete.mind.expression = minf(100.0,expression_before+expression_gain)
			outcomes.append(OutcomeRecord.new("musical_expression","expression",float(career.athlete.mind.expression)-expression_before,["focused_expression_training"],"training_growth"))
			growth *= 1.0-expression_fraction
		growth *= float(executed_lesson_quality.get(category_id,1.0))
		if category_id == "skating_foundation":
			var steps_fraction := clampf(float(executed_focus_lessons.get("steps",0.0))/maxf(1.0,float(allocations.skating_foundation)-executed_expression_share),0.0,1.0)
			var steps_growth := growth*steps_fraction
			career.athlete.skating.turns = minf(100.0,float(career.athlete.skating.turns)+steps_growth)
			growth -= steps_growth
		if target == "skating":
			target = "deep_edge"
			target_state = career.athlete.skating
		else:
			target_state = career.athlete.body if career.athlete.body.has(target) else career.athlete.technique
		var previous := float(target_state.get(target, 0.0))
		var updated := clampf(previous + growth, 0.0, 100.0)
		target_state[target] = updated
		var causes: Array[String] = ["%s_training" % category_id]
		causes.append_array(authority_causes)
		if motivation_multiplier < 1.0:
			causes.append("low_motivation")
		outcomes.append(OutcomeRecord.new(category_id, target, updated - previous, causes, "training_growth"))
		if category_id == "rotation":
			# A complete spin lesson develops positions and control together;
			# players do not need six separate prerequisite grinds.
			for metric in career.athlete.spin_foundation:
				var before := float(career.athlete.spin_foundation[metric])
				var delta := growth * (1.1 if metric == "flexibility" else 1.6) * maxf(0.0, 1.0 - before / 110.0)
				career.athlete.spin_foundation[metric] = minf(100.0, before + delta)
				outcomes.append(OutcomeRecord.new(category_id, "spin_" + str(metric), float(career.athlete.spin_foundation[metric]) - before, causes, "training_growth"))
			for spin_id in career.athlete.spins:
				var spin: Dictionary = career.athlete.spins[spin_id]
				var before := float(spin.proficiency)
				spin.proficiency = minf(100.0, before + growth * 1.8 * maxf(0.0, 1.0 - before / 110.0))
				spin.training_consistency = minf(100.0, float(spin.training_consistency) + growth * 1.3)
				spin.level_features = clampi(int(float(spin.proficiency) / 16.0), 0, 4)
				outcomes.append(OutcomeRecord.new(category_id, "spin_" + str(spin_id), float(spin.proficiency) - before, causes, "training_growth"))
		# These related dimensions used to remain at creation values forever,
		# even though competition consumes them. Transfer the actual training
		# growth, preserving the primary focus and different adaptation rates.
		var related := {}
		if category_id == "skating_foundation":
			related = {"one_foot_stability":0.85,"knee_action":0.8,"ice_efficiency":0.75,"flow":0.7,"speed":0.6,"turns":0.55}
		elif category_id == "conditioning":
			related = {"strength_readiness":0.75,"joint_readiness":0.45}
		var adaptation := 1.0
		if category_id == "conditioning":
			var age: int = career.clock.age_on(career.athlete.birth_year)
			adaptation = (0.75 if age <= 10 else 1.0) * clampf(1.0-float(career.athlete.body.impact_load)/200.0,0.5,1.0)
			adaptation *= clampf(float(rest_units)/5.0,0.2,1.0)
		for metric in related:
			var before := float(target_state[metric])
			var delta := growth * float(related[metric]) * adaptation * maxf(0.0,1.0-before/100.0)
			target_state[metric] = minf(95.0,before+delta) if before < 95.0 else before
			outcomes.append(OutcomeRecord.new(category_id,metric,float(target_state[metric])-before,causes,"training_growth"))

	var recovery_causes: Array[String] = ["training_load", "rest_recovery"]
	recovery_causes.append_array(authority_causes)
	if rest_units < 2:
		recovery_causes.append("insufficient_recovery")
	var acute_change := active_units * ACTIVE_ACUTE_FATIGUE - rest_units * REST_ACUTE_RECOVERY * float(condition.recovery_efficiency)
	outcomes.append(_apply_body_change(career, "acute_fatigue", acute_change, recovery_causes, "fatigue_change"))
	var cumulative_change := active_units * ACTIVE_CUMULATIVE_FATIGUE - rest_units * REST_CUMULATIVE_RECOVERY * float(condition.recovery_efficiency)
	outcomes.append(_apply_body_change(career, "cumulative_fatigue", cumulative_change, recovery_causes, "fatigue_change"))

	var ankle_causes: Array[String] = ["training_load"]
	ankle_causes.append_array(authority_causes)
	if jump_units > 4:
		ankle_causes.append("jump_repetition_load")
	var ankle_change := jump_units * JUMP_ANKLE_LOAD + (active_units - jump_units) * OTHER_ACTIVE_ANKLE_LOAD - rest_units * REST_ANKLE_RECOVERY
	outcomes.append(_apply_body_change(career, "ankle_load", ankle_change, ankle_causes, "ankle_load_change"))
	if rest_units > 0:
		var impact_recovery := PERCENTAGE_MODE_REST_IMPACT_RECOVERY if percentage_mode else REST_IMPACT_RECOVERY
		outcomes.append(_apply_body_change(career, "impact_load", -rest_units * impact_recovery, ["rest_recovery"], "impact_load_change"))

	var previous_growth := float(career.athlete.body.growth_trend)
	if not career.condition_state.rehabilitation.is_empty():
		var executed_attempts := int(staged_training.get("actual_jump_attempts",0))
		if not percentage_mode:
			for batch in attempt_records: executed_attempts += int(batch.get("attempts",0))
		var rehabilitation: Dictionary = load("res://src/simulation/rehabilitation_service.gd").advance(career,{"completed":true,"jump_attempts":executed_attempts},career.random_streams.take_rng("condition_rehabilitation"))
		for event in rehabilitation.events:
			event.clock = career.clock.to_dict()
			career.event_ledger.append(event)
	AthleteConditionService.advance_quarter(career, approved_plan, career.seed,not percentage_mode)
	for action_id in career.technical_repertoire.entries:
		preload("res://src/simulation/repertoire_evaluator.gd").evaluate(career,str(action_id))
	if career.clock.quarter == 4:
		outcomes.append(OutcomeRecord.new(
			"body",
			"growth_trend",
			float(career.athlete.body.growth_trend) - previous_growth,
			["year_end_growth_observation"],
			"growth_change_observed",
		))

	career.history.append_array(OutcomeRecord.list_to_dict(outcomes))
	career.history.append_array(attempt_records)
	if not plan_record.is_empty():
		career.history.append(plan_record)
	if career.clock.quarter == 4:
		career.history.append(_build_season_summary(career, career.clock.year))
	preload("res://src/simulation/coach_training_memory_service.gd").complete_period(career)
	CertificationService.process_quarter(career)
	career.clock.advance_quarter()
	_update_roadmap_progress(career, previous_roadmap_evaluation)
	EventEngine.decay_memories(career)
	return outcomes

static func _weighted_totals(previous: Dictionary, current: Dictionary, fraction: float) -> Dictionary:
	var totals: Dictionary = previous.duplicate(true)
	for key in current: totals[key] = float(totals.get(key,0.0))+float(current[key])*fraction
	return totals

static func _take_training_rng(career: CareerState) -> RandomNumberGenerator:
	var checkpoint: Dictionary = career.training_period_state.get("stage_checkpoint",{})
	if not checkpoint.is_empty():
		var resumed := RandomNumberGenerator.new()
		resumed.state = int(checkpoint.rng_state)
		return resumed
	var rng: RandomNumberGenerator = career.random_streams.take_rng("training")
	career.rng_step = int(career.random_streams.steps.get("training", 0))
	return rng

static func _update_roadmap_progress(career: CareerState, previous_evaluation: Dictionary) -> void:
	if career.development_roadmap.is_empty():
		return
	var roadmap = DevelopmentRoadmap.from_dict(career.development_roadmap)
	if roadmap == null:
		return
	var current: Dictionary = DevelopmentRoadmapEvaluator.evaluate(career, roadmap)
	var progress: Dictionary = RoadmapProgressUpdater.update(career, previous_evaluation, current)
	current["behind_streak"] = int(progress.behind_streak)
	career.development_roadmap.status = current.status
	career.development_roadmap.last_evaluation = current.duplicate(true)
	var serialized_events: Array[Dictionary] = []
	for event in progress.key_events:
		serialized_events.append(event.to_dict())
	career.history.append({
		"category": "roadmap_progress",
		"clock": career.clock.to_dict(),
		"status_change": progress.status_change.duplicate(true),
		"forecast_change": progress.forecast_change.duplicate(true),
		"key_events": serialized_events,
		"revision_suggestion": progress.revision_suggestion,
	})

static func _secret_result_to_dict(result: Dictionary) -> Dictionary:
	return {
		"executed_units": int(result.executed_units), "efficiency": float(result.efficiency),
		"discovered": bool(result.discovered), "reaction": str(result.reaction),
		"memories": result.memories.duplicate(true), "blocked_reasons": result.blocked_reasons.duplicate(),
	}

static func _build_season_summary(career: CareerState, completed_year: int) -> Dictionary:
	var season_entries := _current_season_entries(career.history)
	var technique_deltas: Dictionary = {}
	var cause_codes: Array[String] = []
	var acute_delta := 0.0
	var cumulative_delta := 0.0
	for entry in season_entries:
		if entry.get("category") == "dated_training":
			for metric in entry.get("technique_deltas",{}): technique_deltas[metric] = float(technique_deltas.get(metric,0.0))+float(entry.technique_deltas[metric])
			acute_delta += float(entry.get("fatigue_deltas",{}).get("acute_fatigue",0.0))
			cumulative_delta += float(entry.get("fatigue_deltas",{}).get("cumulative_fatigue",0.0))
		var target := str(entry.get("target", ""))
		var delta := float(entry.get("delta", 0.0))
		if entry.get("category") != "body" and career.athlete.technique.has(target):
			technique_deltas[target] = float(technique_deltas.get(target, 0.0)) + delta
		if target == "acute_fatigue":
			acute_delta += delta
		elif target == "cumulative_fatigue":
			cumulative_delta += delta
		for cause_code in entry.get("cause_codes", []):
			var normalized_code := str(cause_code)
			if not normalized_code.is_empty() and not cause_codes.has(normalized_code):
				cause_codes.append(normalized_code)

	var acute := float(career.athlete.body.acute_fatigue) - acute_delta
	var cumulative := float(career.athlete.body.cumulative_fatigue) - cumulative_delta
	var peak_fatigue := maxf(acute, cumulative)
	for entry in season_entries:
		if entry.get("category") == "dated_training":
			acute += float(entry.get("fatigue_deltas",{}).get("acute_fatigue",0.0))
			cumulative += float(entry.get("fatigue_deltas",{}).get("cumulative_fatigue",0.0))
			peak_fatigue = maxf(peak_fatigue,float(entry.get("peak_fatigue",0.0)))
		var target := str(entry.get("target", ""))
		if target == "acute_fatigue":
			acute += float(entry.get("delta", 0.0))
		elif target == "cumulative_fatigue":
			cumulative += float(entry.get("delta", 0.0))
		peak_fatigue = maxf(peak_fatigue, maxf(acute, cumulative))

	return {
		"category": "season_summary",
		"year": completed_year,
		"technique_deltas": technique_deltas,
		"peak_fatigue": peak_fatigue,
		"cause_codes": cause_codes,
	}

static func _current_season_entries(history: Array[Dictionary]) -> Array[Dictionary]:
	var start_index := 0
	for index in range(history.size() - 1, -1, -1):
		if history[index].get("category") == "season_summary":
			start_index = index + 1
			break
	var entries: Array[Dictionary] = []
	for index in range(start_index, history.size()):
		entries.append(history[index])
	return entries

static func _apply_body_change(
	career: CareerState,
	target: String,
	requested_delta: float,
	causes: Array[String],
	summary_key: String,
) -> OutcomeRecord:
	var previous := float(career.athlete.body[target])
	var updated := clampf(previous + requested_delta, 0.0, 100.0)
	career.athlete.body[target] = updated
	return OutcomeRecord.new("body", target, updated - previous, causes, summary_key)

static func _authority_causes(decisions: Array) -> Array[String]:
	var causes: Array[String] = []
	for decision in decisions:
		var reason_code := str(decision.get("reason_code", ""))
		if not reason_code.is_empty() and not causes.has(reason_code):
			causes.append(reason_code)
	return causes
