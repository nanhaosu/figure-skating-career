class_name PreparationRouteService
extends RefCounted

const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Direction = preload("res://src/simulation/training_direction_service.gd")
const Dates = preload("res://src/simulation/dated_training_window.gd")
const Repertoire = preload("res://src/domain/technical_repertoire.gd")
const LABELS := {"combination":"三三专项与比赛兑现","axel":"冲击3A，保留现有比赛构成","programme":"完整节目与音乐表达"}

static func options() -> Array:
	return LABELS.keys().map(func(id):return {"id":id,"label":LABELS[id]})

static func preview(career, event: Dictionary, route_id: String) -> Dictionary:
	if not LABELS.has(route_id): return _failure("未知备战路线")
	if not career.competition_state.is_empty(): return _failure("请先完成当前比赛，再调整备战方向")
	if career.season_program_plan.get("status") != "confirmed" or career.season_program_plan.get("season_id") != career.season_state.get("season_id"): return _failure("请先确认本季节目规划")
	if career.active_programs.get("free",{}).is_empty(): return _failure("请先建立自由滑，再选择与节目联动的备战方向")
	var start := str(event.get("start_date",""))
	var now := str(career.competition_timeline.get("date",""))
	if career.competition_timeline.mode != "dated": return _failure("完成当前训练周期、进入日期推进后，可安排目标备战")
	var window := Dates.plan(now,start)
	if event.get("status") == "cancelled" or event.get("reference_only",false) or not window.errors.is_empty() or window.days.is_empty(): return _failure("请选择尚未开始且已接通的目标赛事")
	var direction: Dictionary = career.training_direction.duplicate(true)
	var action := {"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]} if route_id == "axel" else _combination(career)
	if route_id == "programme":
		direction.focuses = [{"id":"musical_expression","kind":"musical_expression","target":{}},{"id":"program_connections:free","kind":"program_connections","target":{"segment":"free"}}]
	else:
		direction.focuses = [{"id":"preparation:"+Repertoire.action_id(action),"kind":"new_difficulty" if route_id == "axel" or not _contains(career,action) else "execution","target":action},{"id":"execution:free","kind":"execution","target":{"segment":"free"}}]
	direction.priority = "balanced"
	var targets: Dictionary = career.season_program_plan.get("targets",{}).duplicate(true)
	for segment in targets: targets[segment] = targets[segment].filter(func(t):return t.get("source") != "preparation_route")
	if route_id != "programme":
		if not targets.has("free"): targets.free = []
		targets.free.append({"element_id":"preparation:"+Repertoire.action_id(action),"action":action.duplicate(true),"source":"preparation_route"})
	var intent = Intent.from_dict(career.training_period_state.get("intent",{"mode":"accept","element_id":""}))
	var baseline := Coach.build(career,intent)
	if not baseline.errors.is_empty(): return _failure("；".join(baseline.errors))
	var saved_plan: Dictionary = career.last_generated_plan
	var baseline_plan = preload("res://src/domain/training_plan.gd").from_dict(saved_plan.get("executed",saved_plan)) if not saved_plan.is_empty() else null
	if baseline_plan == null: baseline_plan = baseline.plan
	var candidate = career.transaction_copy()
	candidate.season_program_plan.targets = targets.duplicate(true)
	var changed := Direction.change(candidate,direction,"preparation-preview")
	if not changed.ok: return _failure(changed.error)
	var built := Coach.build(candidate,intent)
	if not built.errors.is_empty(): return _failure("；".join(built.errors))
	var deltas := {}
	for key in built.plan.shares:
		var delta := int(built.plan.shares[key])-int(baseline_plan.shares[key])
		if delta != 0: deltas[key] = delta
	var readiness: Array[String] = []
	for state in built.get("focus_states",[]):
		var focuses: Array = direction.focuses.filter(func(f):return f.id == state.id)
		var title := str(state.id)
		if not focuses.is_empty():
			var focus: Dictionary = focuses[0]
			title = str({"new_difficulty":"探索难度","execution":"比赛兑现","program_connections":"节目衔接","musical_expression":"音乐表达"}.get(focus.kind,focus.kind))
			title += " · "+Repertoire.action_id(focus.target) if focus.target.get("kind") == "jump" else " · 自由滑" if focus.target.get("segment") == "free" else ""
		readiness.append(title+"："+str({"preparation":"前置准备，尚未安排目标动作尝试","practice":"已安排专项练习","maintenance":"本期仅维护，专项额度不足"}.get(state.stage,state.stage)))
	var programme := "保持已确认自由滑的动作、版本和熟悉度；专项训练不会自动改构成。"
	if route_id == "programme": programme += "重点打磨衔接和音乐表达，原有技术目标仍由教练审核安排。"
	else: programme += "培养目标为"+Repertoire.action_id(action)+"；练成后仍需通过编排检查才能用于比赛。"
	var retained: Array[String] = []
	if intent.mode == "requested_element": retained.append(str(intent.element_id))
	for segment in targets:
		for target in targets[segment]:
			if target.get("source") != "preparation_route": retained.append(Repertoire.action_id(target.get("action",{})))
	var layout: Array[String] = []
	for element in career.active_programs.free.get("elements",[]):
		if element.get("kind") == "jump": layout.append(Repertoire.action_id({"kind":"jump","parts":[{"jump_id":element.jump_id,"rotations":element.rotations}]+element.get("combination_parts",[])}))
	var checks := programme_checks(career,event)
	return {"ok":true,"error":"","route_id":route_id,"label":LABELS[route_id],"direction":direction,"plan":built.plan.to_dict(),"deltas":deltas,"targets":targets,"days":window.days.size(),"readiness":readiness,"programme":programme,"programme_layout":" / ".join(layout),"programme_checks":checks,"retained_goals":retained,"warning":"训练方向不等于报名资格或派遣；不会增加总课时，不绕过身体与恢复审核。"+(" 距比赛不足两周，技术升级应视为长期培养目标。" if window.days.size() < 14 else ""),"reasons":built.reasons}

static func programme_checks(career, event: Dictionary) -> Dictionary:
	var resolved := preload("res://src/content/season_bundle_repository.gd").competition_for_career(career,event)
	var programs := preload("res://src/simulation/season_program_service.gd").programs_for_event(career,event)
	var checks := {}
	for segment in ["short","free"]:
		var errors: Array = resolved.errors.duplicate()
		var data: Dictionary = programs.get(segment,{})
		if errors.is_empty():
			var program = preload("res://src/domain/skating_program.gd").from_dict(data)
			errors = preload("res://src/simulation/program_validator.gd").validate(program,career.athlete,resolved.rules[segment].segment_rules)
		checks[segment] = {"errors":errors,"rules_known":resolved.errors.is_empty(),"program_id":str(data.get("program_id","")),"revision":int(data.get("revision",0))}
	return checks

static func apply(career, event: Dictionary, route_id: String, receipt_id: String, base_revision: int) -> Dictionary:
	if receipt_id.is_empty() or receipt_id.length() > 140: return _failure("备战确认编号无效")
	for receipt in career.event_ledger:
		if receipt.get("kind") == "preparation_route_chosen" and receipt.get("receipt_id") == receipt_id:
			if receipt.get("route_id") != route_id or receipt.get("target_event_id") != event.get("event_id"): return _failure("确认编号已用于另一份备战方案")
			return {"ok":true,"events":[]}
	if base_revision != int(career.training_direction.revision): return _failure("训练方向已更新，请重新查看备战方案")
	var view := preview(career,event,route_id)
	if not view.ok: return view
	career.season_program_plan.targets = view.targets.duplicate(true)
	var changed := Direction.change(career,view.direction,"preparation:"+receipt_id)
	if not changed.ok: return changed
	career.season_state.target_event_id = event.event_id
	career.season_program_plan.targets = view.targets.duplicate(true)
	career.season_program_plan.preparation = {"route_id":route_id,"target_event_id":event.event_id,"chosen_date":career.competition_timeline.date,"direction_revision":career.training_direction.revision}
	var receipt := {"kind":"preparation_route_chosen","receipt_id":receipt_id,"route_id":route_id,"target_event_id":event.event_id,"date":career.competition_timeline.date,"direction_revision":career.training_direction.revision,"training_plan":view.plan.duplicate(true)}
	career.event_ledger.append(receipt)
	return {"ok":true,"events":[receipt]}

static func _combination(career) -> Dictionary:
	for element in career.active_programs.free.get("elements",[]):
		if element.get("kind") != "jump" or int(element.get("rotations",0)) != 3: continue
		var tail: Array = element.get("combination_parts",[])
		if not tail.is_empty() and int(tail[0].get("rotations",0)) == 3:
			return {"kind":"jump","parts":[{"jump_id":element.jump_id,"rotations":3},tail[0].duplicate(true)]}
	return {"kind":"jump","parts":[{"jump_id":"lutz","rotations":3},{"jump_id":"toe_loop","rotations":3}]}

static func _contains(career, action: Dictionary) -> bool:
	for element in career.active_programs.free.get("elements",[]):
		if element.get("kind") != "jump": continue
		var parts: Array = [{"jump_id":element.jump_id,"rotations":element.rotations}]+element.get("combination_parts",[])
		if parts.slice(0,action.parts.size()) == action.parts: return true
	return false

static func _failure(error: String) -> Dictionary:
	return {"ok":false,"error":error}
