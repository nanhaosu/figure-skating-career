class_name ProgramTrainingSimulator
extends RefCounted

static func apply(program, effective_share: float, athlete, connections_fraction: float = 0.0, fractional_dose: bool = false) -> Array[Dictionary]:
	if program == null or athlete == null or effective_share <= 0.0: return []
	# One game quarter compresses several months of on- and off-ice rehearsal.
	# Dense free programmes still take longer, but not at a near-real-time pace.
	var density_factor := clampf(1.0 - maxf(0.0, float(program.elements.size() - 4)) * 0.035, 0.72, 1.0)
	var fatigue_factor := clampf(1.0 - float(athlete.body.get("acute_fatigue", 0.0)) / 160.0, 0.35, 1.0)
	var whole_gain := effective_share * 1.4 * density_factor * fatigue_factor
	var slot_gain := effective_share * 1.6 * density_factor * fatigue_factor
	# Existing quarterly consumers retain their original quantization. A tiny
	# actual daily rehearsal must not disappear merely because UI shows0.01.
	if not fractional_dose:
		whole_gain = snappedf(whole_gain,0.01)
		slot_gain = snappedf(slot_gain,0.01)
	var connections := clampf(connections_fraction,0.0,1.0)
	whole_gain *= 1.0-connections*0.5
	slot_gain *= 1.0-connections*0.5
	# Rehearsal also teaches a young athlete how to project and interpret. Keep
	# this much slower than memory growth so junior programmes retain their
	# characteristic greenness instead of granting instant artistic maturity.
	var expression_gain := effective_share * 0.08 * density_factor * fatigue_factor * (1.0 - float(athlete.mind.expression) / 120.0)
	expression_gain *= 1.0+connections
	athlete.skating.flow = minf(100.0,float(athlete.skating.flow)+effective_share*connections*0.04*fatigue_factor)
	athlete.mind.expression = clampf(float(athlete.mind.expression) + expression_gain,0.0,100.0)
	var old_whole := float(program.whole_run_familiarity)
	program.whole_run_familiarity = clampf(old_whole + whole_gain, 0.0, 100.0)
	for element in program.elements:
		var old_slot := float(program.slot_familiarity.get(element.element_id, 0.0))
		program.slot_familiarity[element.element_id] = clampf(old_slot + slot_gain, 0.0, 100.0)
	return [{
		"category": "program_training", "program_id": program.program_id, "segment": program.segment,
		"whole_run_delta": program.whole_run_familiarity-old_whole if fractional_dose else snappedf(program.whole_run_familiarity - old_whole, 0.01),
		"slot_delta": slot_gain, "target": "%s.whole_run_familiarity" % program.segment,
		"delta": program.whole_run_familiarity-old_whole if fractional_dose else snappedf(program.whole_run_familiarity - old_whole, 0.01),
		"summary_key": "program_familiarity_change", "cause_codes": ["program_practice"],
	}]
