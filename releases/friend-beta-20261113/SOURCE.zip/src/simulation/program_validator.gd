class_name ProgramValidator
extends RefCounted

const JUMP_CODES := {"toe_loop": "T", "salchow": "S", "loop": "Lo", "flip": "F", "lutz": "Lz", "axel": "A"}
const JumpConnectionRules = preload("res://src/simulation/jump_connection_rules.gd")

static func validate(program, athlete, rules: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if program == null: return ["节目不存在"]
	if rules.is_empty(): return ["比赛规则不存在"]
	var label := str(rules.label)
	if program.segment != rules.segment: errors.append("%s不能使用%s节目" % [label, program.segment])
	if program.elements.size() > int(rules.element_max): errors.append("%s最多安排%d个动作" % [label, int(rules.element_max)])
	var jump_count := 0
	var combination_count := 0
	var three_jump_combination_count := 0
	var axel_sequence_count := 0
	var spin_count := 0
	var step_count := 0
	var choreographic_count := 0
	var has_axel := false
	var has_solo_axel := false
	var has_prescribed_axel := false
	var has_prescribed_solo := false
	var has_rotation_solo := false
	var spin_codes: Array[String] = []
	var high_rotation_counts := {}
	var high_rotation_combination_counts := {}
	var high_rotation_jump_element_counts := {}
	var jump_element_counts := {}
	var double_rotation_counts := {}
	var ids: Array[String] = []
	for element in program.elements:
		if element.target_level < 1 or element.target_level > 4: errors.append("目标级别必须为1至4")
		if not is_finite(element.entry_difficulty) or element.entry_difficulty < 0.0 or element.entry_difficulty > 1.0: errors.append("进入难度必须为0至1")
		if not element.ice_anchor.is_empty():
			for axis in ["x", "y"]:
				var coordinate = element.ice_anchor.get(axis)
				if not (coordinate is float or coordinate is int) or not is_finite(float(coordinate)) or float(coordinate) < 0.0 or float(coordinate) > 1.0: errors.append("冰面锚点坐标必须为0至1")
		if element.kind == "spin" and not Array(rules.get("allowed_spin_codes", ["CCoSp", "FCSp", "LSp", "FSSp"])).has(element.spin_code): errors.append("该旋转类型不符合比赛规则")
		if ids.has(element.element_id): errors.append("节目动作编号不能重复：%s" % element.element_id)
		else: ids.append(element.element_id)
		match element.kind:
			"jump":
				var high_rotation_codes_in_element := {}
				var codes_in_element := {"%d%s" % [element.rotations,JUMP_CODES.get(element.jump_id,element.jump_id)]:true}
				jump_count += 1
				if element.combination_parts.is_empty():
					if element.jump_id != "axel" and Array(rules.get("required_solo_rotations",[])).any(func(r):return float(r) == float(element.rotations)): has_rotation_solo = true
					if element.jump_id == "axel": has_solo_axel = true
					if element.jump_id == "axel" and Array(rules.get("required_axel_rotations",[])).any(func(r): return int(r) == element.rotations): has_prescribed_axel = true
					if element.jump_id == str(rules.get("required_solo_jump","")) and element.rotations in [2,3]: has_prescribed_solo = true
				elif rules.has("minimum_combination_rotations") and element.rotations < int(rules.minimum_combination_rotations):
					errors.append("短节目连跳必须由至少两周跳组成")
				if not element.combination_parts.is_empty() and rules.has("minimum_combination_highest_rotation"):
					var highest: int = element.rotations
					for part in element.combination_parts: highest = maxi(highest,int(part.get("rotations",0)))
					if highest < int(rules.minimum_combination_highest_rotation): errors.append("短节目连跳至少包含一个三周跳")
				if element.rotations < 1 or element.rotations > 4: errors.append("跳跃周数必须为1至4")
				if element.combination_parts.size() > 2: errors.append("连跳最多三个跳跃")
				if element.jump_id == "axel": has_axel = true
				_record_high_rotation(high_rotation_counts, element.jump_id, element.rotations)
				_record_high_rotation(high_rotation_codes_in_element, element.jump_id, element.rotations)
				_record_double_rotation(double_rotation_counts, element.jump_id, element.rotations)
				if not element.combination_parts.is_empty():
					_record_high_rotation(high_rotation_combination_counts, element.jump_id, element.rotations)
				var profile = athlete.jumps.get(element.jump_id)
				if profile == null or (profile.unlocked_rotations < element.rotations and not _has_training_attempt(profile, element.rotations)):
					errors.append("%d%s尚未解锁，不能编入节目" % [element.rotations, JUMP_CODES.get(element.jump_id, element.jump_id)])
				if not element.combination_parts.is_empty(): combination_count += 1
				if not element.combination_parts.is_empty() and element.rotations > int(rules.get("maximum_combination_rotations",4)): errors.append("青年短节目连跳不得包含四周跳")
				if element.combination_parts.size() == 2: three_jump_combination_count += 1
				if element.combination_parts.any(func(part): return part.get("jump_id") == "axel"):
					axel_sequence_count += 1
				var previous_jump_id: String = element.jump_id
				for part in element.combination_parts:
					var part_jump_id := str(part.get("jump_id", ""))
					var part_rotations := int(part.get("rotations", 0))
					codes_in_element["%d%s" % [part_rotations,JUMP_CODES.get(part_jump_id,part_jump_id)]] = true
					var connection: Dictionary = JumpConnectionRules.can_connect(previous_jump_id, part_jump_id, rules)
					if not connection.allowed: errors.append(str(connection.reason))
					previous_jump_id = part_jump_id
					if rules.has("minimum_combination_rotations") and part_rotations < int(rules.minimum_combination_rotations): errors.append("短节目连跳必须由至少两周跳组成")
					if part_rotations < 1 or part_rotations > 4: errors.append("连跳周数必须为1至4")
					if part_rotations > int(rules.get("maximum_combination_rotations",4)): errors.append("青年短节目连跳不得包含四周跳")
					if part_jump_id == "axel": has_axel = true
					_record_high_rotation(high_rotation_counts, part_jump_id, part_rotations)
					_record_high_rotation(high_rotation_codes_in_element, part_jump_id, part_rotations)
					_record_high_rotation(high_rotation_combination_counts, part_jump_id, part_rotations)
					_record_double_rotation(double_rotation_counts, part_jump_id, part_rotations)
					var part_profile = athlete.jumps.get(part_jump_id)
					if part_profile == null or (part_profile.unlocked_rotations < part_rotations and not _has_training_attempt(part_profile, part_rotations)):
						errors.append("%d%s尚未解锁，不能编入连跳" % [part_rotations, JUMP_CODES.get(part_jump_id, part_jump_id)])
				for jump_code in high_rotation_codes_in_element:
					high_rotation_jump_element_counts[jump_code] = int(high_rotation_jump_element_counts.get(jump_code, 0)) + 1
				for code in codes_in_element: jump_element_counts[code] = int(jump_element_counts.get(code,0))+1
			"spin":
				spin_count += 1
				spin_codes.append(element.spin_code)
			"step_sequence": step_count += 1
			"choreographic_sequence": choreographic_count += 1
	if jump_count < int(rules.jump_min): errors.append("%s至少安排%d个跳跃动作" % [label, int(rules.jump_min)])
	if jump_count > int(rules.jump_max): errors.append("%s最多安排%d个跳跃动作" % [label, int(rules.jump_max)])
	var combination_min := int(rules.get("jump_combination_min", 0))
	if rules.get("axel_sequence_allowed", false) and axel_sequence_count > 1:
		errors.append("自由滑最多安排一组阿克塞尔跳跃序列")
	var combination_max := int(rules.get("jump_combination_max", 99))
	if combination_count < combination_min: errors.append("%s至少需要%d组连跳" % [label, combination_min])
	if combination_count > combination_max: errors.append("%s最多安排%d组连跳" % [label, combination_max])
	var three_jump_max := int(rules.get("jump_combination_three_jump_max", 99))
	if three_jump_combination_count > three_jump_max:
		errors.append("%s最多安排%d组三连跳" % [label, three_jump_max])
	if Array(rules.get("required_jump_types", [])).has("axel") and not has_axel:
		errors.append("%s必须包含阿克塞尔类跳跃" % label)
	if str(rules.get("segment", "")) == "short" and Array(rules.get("required_jump_types", [])).has("axel") and has_axel and not has_solo_axel:
		errors.append("短节目的阿克塞尔跳必须作为独立单跳")
	if rules.has("required_axel_rotations") and not has_prescribed_axel: errors.append("短节目必须包含规定周数的独立阿克塞尔跳")
	if rules.has("required_solo_jump") and not has_prescribed_solo: errors.append("短节目必须包含规定跳种的两周或三周单跳")
	if rules.has("required_solo_rotations") and not has_rotation_solo: errors.append("短节目独立跳不符合规定周数")
	for code in rules.get("required_spin_codes",[]):
		var alternatives: Array = rules.get("spin_alternatives",{}).get(code,[])
		if not spin_codes.has(code) and not alternatives.any(func(value): return spin_codes.has(value)): errors.append("短节目缺少规定旋转：%s" % code)
	var repeated_high_rotation_types := 0
	if rules.get("distinct_spin_codes",false):
		var seen_spins := {}
		for code in spin_codes:
			if seen_spins.has(code): errors.append("自由滑各旋转须使用不同代码：%s" % code)
			seen_spins[code] = true
	for group in rules.get("required_spin_groups",[]):
		if not Array(group).any(func(code): return spin_codes.has(code)): errors.append("自由滑缺少规定性质旋转：%s" % "/".join(group))
	# The short-program no-repeat rule compares separate jump elements. A
	# 3T+3T (or analogous) combination is one jump element and is legal; a
	# solo 3T plus another 3T in the combination is not.
	var repeated_counts: Dictionary = high_rotation_jump_element_counts if program.segment == "short" else high_rotation_counts
	for jump_id in repeated_counts:
		if int(repeated_counts[jump_id]) > 1: repeated_high_rotation_types += 1
	var repeat_limits = rules.get("repeat_limits", {})
	if repeat_limits is Dictionary and program.segment == "short" and int(repeat_limits.get("max_repeated_triples_or_quads",-1)) == 0:
		for code in jump_element_counts:
			if int(jump_element_counts[code]) > 1: errors.append("短节目不同跳跃动作不能重复：%s" % code)
	if repeat_limits is Dictionary and repeat_limits.has("max_repeated_triples_or_quads"):
		for jump_id in double_rotation_counts:
			if int(double_rotation_counts[jump_id]) > 2:
				errors.append("%s同一种两周跳最多出现2次：2%s" % [label, JUMP_CODES.get(jump_id, jump_id)])
		for jump_code in high_rotation_counts:
			if int(high_rotation_counts[jump_code]) > 2:
				errors.append("%s同一种三周或四周跳最多出现2次：%s" % [label, jump_code])
			elif int(high_rotation_counts[jump_code]) == 2 and int(high_rotation_combination_counts.get(jump_code, 0)) == 0:
				errors.append("%s重复的三周或四周跳至少一次须在连跳中：%s" % [label, jump_code])
	if repeat_limits is Dictionary and repeat_limits.has("max_repeated_triples_or_quads"):
		var maximum := int(repeat_limits.max_repeated_triples_or_quads)
		if repeated_high_rotation_types > maximum:
			errors.append("%s最多重复%d种三周或四周跳" % [label, maximum])
	if spin_count < int(rules.spin_min): errors.append("%s需要%d个旋转" % [label, int(rules.spin_min)])
	if spin_count > int(rules.get("spin_max", 99)): errors.append("%s最多安排%d个旋转" % [label, int(rules.spin_max)])
	if step_count < int(rules.step_min): errors.append("%s需要%d个接续步" % [label, int(rules.step_min)])
	if step_count > int(rules.get("step_max", 99)): errors.append("%s最多安排%d个接续步" % [label, int(rules.step_max)])
	if choreographic_count < int(rules.get("choreographic_min", 0)): errors.append("%s需要%d个编排步法" % [label, int(rules.choreographic_min)])
	if choreographic_count > int(rules.get("choreographic_max", 99)): errors.append("%s最多安排%d个编排步法" % [label, int(rules.choreographic_max)])
	var bonus_window = rules.get("bonus_window", {})
	if bonus_window is Dictionary and str(bonus_window.get("kind", "")) == "last_jump_elements" and int(bonus_window.get("count", 0)) > jump_count:
		errors.append("%s后半程加分窗口不能超过跳跃动作数" % label)
	return errors

static func _record_high_rotation(counts: Dictionary, jump_id: String, rotations: int) -> void:
	if rotations >= 3:
		var jump_code := "%d%s" % [rotations, JUMP_CODES.get(jump_id, jump_id)]
		counts[jump_code] = int(counts.get(jump_code, 0)) + 1

static func _record_double_rotation(counts: Dictionary, jump_id: String, rotations: int) -> void:
	if rotations == 2:
		counts[jump_id] = int(counts.get(jump_id, 0)) + 1

static func _has_training_attempt(profile, rotations: int) -> bool:
	var key: String = str({1:"single", 2:"double", 3:"triple", 4:"quad"}.get(rotations, ""))
	if key.is_empty(): return false
	var evidence: Dictionary = Dictionary(profile.attempt_evidence.get(key, {}))
	return int(evidence.get("attempts", 0)) > 0
