class_name JudgingPanelSimulator
extends RefCounted

const COMPONENT_IDS := ["skating_skills", "transitions", "performance", "composition", "interpretation"]
const MAX_INTERNAL_ADVANTAGE := 3.0

static func score(performance: Dictionary, technical_review: Dictionary, presentation: Dictionary, reputation: Dictionary, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var scope := str(context.get("event_scope", "external"))
	var influence_strength := 0.0
	if scope == "internal":
		influence_strength = clampf(float(context.get("priority", 0.0)) + float(context.get("coach_voice", 0.0)) * 0.7, 0.0, 170.0)
	var confidence_by_id := {}
	for called in technical_review.get("calls", []):
		confidence_by_id[str(called.get("element_id", ""))] = str(called.get("evidence_confidence", "clear"))
	var truth_by_id := {}
	for element in performance.get("elements", []):
		truth_by_id[str(element.get("element_id", ""))] = element

	var element_scores: Array[Dictionary] = []
	var tes := 0.0
	var goe_advantage := 0.0
	for final_element in technical_review.get("final_elements", []):
		var element_id := str(final_element.get("element_id", ""))
		var base_value := float(final_element.get("base_value", 0.0))
		var goe := float(final_element.get("live_goe", 0.0))
		var true_element: Dictionary = truth_by_id.get(element_id, {})
		var clear_fall := bool(true_element.get("actual", {}).get("fall", false))
		if clear_fall:
			goe = minf(goe, -base_value * 0.50)
		elif confidence_by_id.get(element_id, "clear") == "ambiguous" and influence_strength > 0.0:
			var adjustment := minf(base_value * 0.12, influence_strength * base_value / 1000.0)
			goe += adjustment
			goe_advantage += adjustment
		goe = snappedf(goe, 0.01)
		var total := snappedf(base_value + goe, 0.01)
		element_scores.append({
			"element_id": element_id, "abbreviation": str(final_element.get("abbreviation", "?")),
			"base_value": base_value, "goe": goe, "total": total,
			"info":Array(final_element.get("info",[])).duplicate(),
			"parts":Array(final_element.get("parts",[])).duplicate(true),
			"invalid_reason":str(final_element.get("invalid_reason","")),
		})
		tes += total

	var component_scores := {}
	var pcs_unfactored := 0.0
	var route_effects := _route_component_effects(Dictionary(presentation.get("route_metrics", {})))
	for component_id in COMPONENT_IDS:
		var value := clampf((float(presentation.get(component_id, 50.0)) + float(route_effects.get(component_id, 0.0))) / 10.0 + rng.randf_range(-0.08, 0.08), 0.25, 10.0)
		component_scores[component_id] = snappedf(value, 0.01)
		pcs_unfactored += value
	var factor := float(presentation.get("pcs_factor", 0.8))
	var base_pcs := pcs_unfactored * factor
	var pcs_advantage := minf(2.4, influence_strength * 0.02)
	# A prior ranking can move ordinary discretion, but never imports club influence externally.
	if scope == "internal":
		pcs_advantage += minf(0.25, float(reputation.get("ranking_inertia", 0.0)) * 0.01)
	var total_advantage := minf(MAX_INTERNAL_ADVANTAGE, goe_advantage + pcs_advantage)
	pcs_advantage = maxf(0.0, total_advantage - goe_advantage)
	var pcs := snappedf(base_pcs + pcs_advantage, 0.01)
	tes = snappedf(tes, 0.01)
	var deductions := snappedf(float(performance.get("falls", 0)), 0.01)
	return {
		"element_scores": element_scores,
		"tes": tes,
		"component_scores": component_scores,
		"pcs_factor": factor,
		"pcs": pcs,
		"deductions": deductions,
		"total": snappedf(tes + pcs - deductions, 0.01),
		"internal_advantage": snappedf(total_advantage, 0.01),
		"bias_sources": _bias_sources(scope, context, reputation),
		"route_component_effects": {"coverage": float(presentation.get("route_metrics", {}).get("coverage", 0.0)), "balance": float(presentation.get("route_metrics", {}).get("balance", 0.0)), "repetition": float(presentation.get("route_metrics", {}).get("repetition", 0.0)), "components": route_effects},
	}

static func _route_component_effects(metrics: Dictionary) -> Dictionary:
	if metrics.is_empty(): return {}
	var coverage := float(metrics.get("coverage", 60.0))
	var balance := float(metrics.get("balance", 60.0))
	var repetition := float(metrics.get("repetition", 20.0))
	var execution := float(metrics.get("execution_ratio", 0.75)) * 100.0
	return {
		"skating_skills": clampf((coverage - 60.0) * 0.10 + (execution - 70.0) * 0.05, -12.0, 10.0),
		"transitions": clampf((execution - 70.0) * 0.12 - (repetition - 20.0) * 0.08, -14.0, 10.0),
		"composition": clampf((balance - 60.0) * 0.10 + (coverage - 60.0) * 0.06 - (repetition - 20.0) * 0.05, -14.0, 10.0),
	}

static func _bias_sources(scope: String, context: Dictionary, reputation: Dictionary) -> Array[String]:
	var sources: Array[String] = []
	if scope != "internal": return sources
	for source in ["priority", "coach_voice"]:
		if float(context.get(source, 0.0)) > 0.0: sources.append(source)
	if float(reputation.get("ranking_inertia", 0.0)) > 0.0: sources.append("ranking_inertia")
	return sources
