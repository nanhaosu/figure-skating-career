class_name MeaningfulAdvanceService
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingIntent = preload("res://src/domain/training_intent.gd")
const CoachTrainingPlanService = preload("res://src/simulation/coach_training_plan_service.gd")
const CareerCommandService = preload("res://src/simulation/career_command_service.gd")
const SeasonBundleRepository = preload("res://src/content/season_bundle_repository.gd")
const AthleteConditionService = preload("res://src/simulation/athlete_condition_service.gd")
const OutcomeRecord = preload("res://src/domain/outcome_record.gd")
const TeachingCompetitionService = preload("res://src/simulation/teaching_competition_service.gd")

const WEEKS_PER_QUARTER := 12

static func advance(career: CareerState, intent: TrainingIntent, max_weeks: int = WEEKS_PER_QUARTER) -> Dictionary:
	if career == null or intent == null or max_weeks < 1:
		return _result(career, 0, [], "invalid_request", {}, ["推进请求无效"])
	var working := CareerState.from_dict(career.to_dict())
	var pending := _pending_action(working)
	if not pending.is_empty(): return _result(working, 0, [], "pending_action", pending, [])
	var planned := CoachTrainingPlanService.build(working, intent)
	if not planned.errors.is_empty(): return _result(CareerState.from_dict(career.to_dict()), 0, [], "invalid_intent", {}, planned.errors)
	var state: Dictionary = working.training_period_state
	if not state.is_empty() and Dictionary(state.get("intent", {})) != intent.to_dict():
		return _result(working, 0, [], "pending_action", {"kind":"intent_change", "message":"当前训练期尚未结束，请先确认是否改计划"}, [])
	if not state.is_empty():
		var agreed_plan = load("res://src/domain/training_plan.gd").from_dict(state.get("plan", {}))
		if agreed_plan == null: return _result(working, 0, [], "invalid_intent", {}, ["当前训练期的已确认计划无法读取"])
		planned.plan = agreed_plan
		if state.has("stage_checkpoint") and not AthleteConditionService.can_train(working,agreed_plan):
			planned = CoachTrainingPlanService.build(working,intent)
			if not planned.errors.is_empty(): return _result(CareerState.from_dict(career.to_dict()),0,[],"invalid_intent",{},planned.errors)
	if not AthleteConditionService.can_train(working, planned.plan):
		return _result(CareerState.from_dict(career.to_dict()), 0, [], "pending_action", {"kind":"medical_restriction", "message":"身体状态不允许执行当前计划，请先调整为恢复训练"}, [])
	var completed_weeks := int(state.get("weeks_elapsed", 0))
	var weeks := mini(max_weeks, WEEKS_PER_QUARTER - completed_weeks)
	if state.has("stage_checkpoint") and weeks < 3:
		return _result(CareerState.from_dict(career.to_dict()),0,[],"max_weeks",{},[])
	var teaching := TeachingCompetitionService.evaluate(working)
	var current_week := TeachingCompetitionService.elapsed_week(working)
	var due_week := int(working.internal_invitation_state.get("deferred_until_week", teaching.week)) if str(working.internal_invitation_state.get("status", "")) == "deferred" else int(teaching.week)
	var stops_for_teaching := str(working.internal_invitation_state.get("status", "not_ready")) not in ["deferred", "accepted", "completed"] and current_week < due_week and due_week <= current_week + weeks
	if stops_for_teaching:
		if state.has("stage_checkpoint"):
			# A durable stage must execute before its elapsed weeks are reported.
			# Invitations inside a stage are presented at its next safe boundary.
			weeks = mini(weeks, int(ceil(float(due_week - current_week) / 3.0)) * 3)
		else:
			weeks = due_week - current_week
	working.training_period_state = {
		"weeks_elapsed": completed_weeks + weeks,
		"intent": intent.to_dict(),
		"plan": planned.plan.to_dict(),
		"started_clock": Dictionary(state.get("started_clock", working.clock.to_dict())).duplicate(true),
	}
	if state.has("stage_checkpoint"):
		working.training_period_state.stage_checkpoint = Dictionary(state.stage_checkpoint).duplicate(true)
		working.training_period_state.weeks_elapsed = completed_weeks
	var facts: Array[Dictionary] = [{"kind":"period_progress", "text":"本次连续推进%d周，期间没有要求玩家逐周确认。" % weeks, "evidence_refs":["training_period_state.weeks_elapsed"]}]
	if stops_for_teaching and not state.has("stage_checkpoint"):
		var due := TeachingCompetitionService.evaluate(working)
		return _result(working, weeks, facts, "pending_action", _teaching_action(due), [])
	if int(working.training_period_state.weeks_elapsed) < WEEKS_PER_QUARTER and not state.has("stage_checkpoint"):
		return _result(working, weeks, facts, "max_weeks", {}, [])
	var before := CareerState.from_dict(working.to_dict())
	working.last_generated_plan = planned.plan.to_dict()
	var history_start := working.history.size()
	var settle_command := {"type":"advance_quarter", "bundle":SeasonBundleRepository.for_career(working)}
	if state.has("stage_checkpoint"):
		settle_command.stage_limit = mini(4,weeks/3)
		settle_command.expected_stage = int(state.stage_checkpoint.next_stage)
		settle_command.expected_clock = working.clock.to_dict()
	var settlement := CareerCommandService.apply(working, settle_command)
	if not bool(settlement.get("ok", false)):
		var stop_node: Dictionary = settlement.get("stop_node", {})
		if not stop_node.is_empty():
			var paused := CareerState.from_dict(career.to_dict())
			# A new period may stop before any training is committed. Event and
			# authority responses still need a complete, saveable checkpoint.
			# Keep the original elapsed weeks, not the attempted full settlement.
			paused.training_period_state = {
				"weeks_elapsed": completed_weeks,
				"intent": intent.to_dict(),
				"plan": planned.plan.to_dict(),
				"started_clock": Dictionary(state.get("started_clock",career.clock.to_dict())).duplicate(true),
			}
			if state.has("stage_checkpoint"):
				paused.training_period_state.stage_checkpoint = Dictionary(state.stage_checkpoint).duplicate(true)
			return _result(paused, 0, [], "pending_action", stop_node, [])
		return _result(CareerState.from_dict(career.to_dict()), 0, [], "advance_rejected", {}, [str(settlement.get("error", "当前训练计划未能完成"))])
	var settled: CareerState = settlement.career
	if settled.training_period_state.has("stage_checkpoint"):
		var executed_weeks := int(settled.training_period_state.weeks_elapsed)-completed_weeks
		var action: Dictionary = _pending_action(settled)
		if action.is_empty(): action = {"kind":"training_checkpoint","message":"训练阶段已保存，可继续剩余安排"}
		var partial_facts: Array[Dictionary] = [{"kind":"training_stage","weeks_elapsed":int(settled.training_period_state.weeks_elapsed),"evidence_refs":["training_period_state.stage_checkpoint"]}]
		for fact in _facts_from_settlement(before,settled,settled.history.slice(history_start),settlement.get("outcomes",[]),planned):
			if fact.kind not in ["coach_plan","clock_advanced"]: partial_facts.append(fact)
		return _result(settled,executed_weeks,partial_facts,"pending_action",action,[])
	settled.training_period_state = {}
	settled.event_ledger.append({"kind":"coach_curriculum", "clock":settled.clock.to_dict(), "intent":intent.to_dict(), "executed_plan":settled.last_generated_plan.duplicate(true)})
	var outcomes: Array = settlement.get("outcomes", [])
	facts.append_array(_facts_from_settlement(before, settled, settled.history.slice(history_start), outcomes, planned))
	return _result(settled, weeks, facts, "quarter_complete", {}, [])

static func _pending_action(career: CareerState) -> Dictionary:
	if not career.condition_state.get("pending_decision",{}).is_empty():
		return load("res://src/simulation/season_progression_service.gd")._pending(career)
	var events: Array = career.condition_state.get("pending_training_events", [])
	if not events.is_empty():
		var event: Dictionary = events[0]
		return {"kind":"training_event", "id":str(event.get("id", "")), "title":str(event.get("title", "训练事件")), "description":str(event.get("description", "")), "choices":Array(event.get("choices", [])).duplicate(true)}
	var teaching := TeachingCompetitionService.evaluate(career)
	var invitation_status := str(career.internal_invitation_state.get("status", "not_ready"))
	if bool(teaching.available) and invitation_status not in ["deferred", "accepted", "completed"]:
		return _teaching_action(teaching)
	return {}

static func _teaching_action(evaluation: Dictionary) -> Dictionary:
	return {
		"kind":"teaching_competition", "id":str(evaluation.event_id),
		"reason":"教练通知你：第一场教学赛已经排进日程。可以先查看并准备节目，也可以暂缓。",
		"week":int(evaluation.current_week), "reason_codes":Array(evaluation.reason_codes).duplicate(),
		"peer_ids":Array(evaluation.peer_ids).duplicate(),
		"eligible_program_rules":Dictionary(evaluation.eligible_program_rules).duplicate(true),
	}

static func _facts_from_settlement(before: CareerState, after: CareerState, history_entries: Array, outcomes: Array, _planned: Dictionary) -> Array[Dictionary]:
	var facts: Array[Dictionary] = []
	var executed: Dictionary = after.last_generated_plan.duplicate(true)
	facts.append({"kind":"coach_plan", "executed_plan":executed,"text":"本期按已确认并经身体复核的实际课程结算；动作与课时以训练记录为准。" if not executed.is_empty() else "本期训练已结算，未附最终课表；实际动作见训练记录。", "evidence_refs":["last_generated_plan","history.jump_attempt_batch"]})
	for entry in history_entries:
		if not entry is Dictionary: continue
		if entry.get("category") == "coach_training":
			facts.append({"kind":"coach_training","decision":entry.get("decision",{}).duplicate(true),"evidence_refs":["history.coach_training"]})
		if str(entry.get("category","")) in ["jump_milestone","jump_stage"]:
			var fact: Dictionary = entry.duplicate(true)
			fact.kind = str(entry.category)
			fact.evidence_refs = ["history.%s" % str(entry.category)]
			facts.append(fact)
		if str(entry.get("category", "")) == "jump_attempt_batch":
			facts.append({"kind":"jump_attempts", "jump_id":str(entry.get("jump_id", "")), "rotations":int(entry.get("rotations", 1)), "attempts":int(entry.get("attempts", 0)), "successes":int(entry.get("successes", 0)), "text":"%s训练尝试%d次、成功%d次。" % [str(entry.get("jump_id", "跳跃")), int(entry.get("attempts", 0)), int(entry.get("successes", 0))], "evidence_refs":["history.jump_attempt_batch"]})
	for outcome in outcomes:
		var record: Dictionary = outcome.to_dict() if outcome is OutcomeRecord else Dictionary(outcome)
		if is_zero_approx(float(record.get("delta", 0.0))): continue
		facts.append({"kind":"state_change", "category":str(record.get("category","")), "target":str(record.get("target", "")), "delta":float(record.get("delta", 0.0)), "text":"%s变化%+.2f。" % [str(record.get("target", "指标")), float(record.get("delta", 0.0))], "evidence_refs":["outcomes.%s" % str(record.get("target", "unknown"))]})
	facts.append({"kind":"clock_advanced", "text":"训练期结束，生涯从%d年第%d季度进入%d年第%d季度。" % [before.clock.year, before.clock.quarter, after.clock.year, after.clock.quarter], "evidence_refs":["clock"]})
	return facts

static func _result(career, elapsed_weeks: int, facts: Array, stop_reason: String, pending_action: Dictionary, errors: Array) -> Dictionary:
	return {"career":career, "elapsed_weeks":elapsed_weeks, "facts":facts, "stop_reason":stop_reason, "pending_action":pending_action, "errors":errors}
