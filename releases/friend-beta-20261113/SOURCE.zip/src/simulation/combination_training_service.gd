class_name CombinationTrainingService
extends RefCounted

const Model = preload("res://src/domain/technical_repertoire.gd")
const Functions = preload("res://src/simulation/athlete_function_service.gd")
const Execution = preload("res://src/simulation/program_performance_simulator.gd")
const Evidence = preload("res://src/simulation/repertoire_evidence_service.gd")
const Training = preload("res://src/simulation/jump_training_simulator.gd")
const KEYS := {1:"single",2:"double",3:"triple",4:"quad"}

static func simulate(career, action: Dictionary, attempts: int, batch_id: String, context: Dictionary, rng: RandomNumberGenerator) -> Dictionary:
	var result := {"evidence":{},"outcomes":[],"executions":[],"actual_load":{"jump_attempts":0,"impact":0.0},"reasons":[]}
	var id := Model.action_id(action)
	if id.is_empty() or action.parts.size() < 2 or attempts <= 0 or batch_id.is_empty():
		result.reasons.append("连跳练习条件无效")
		return result
	var constraints := Functions.action_constraints(career,action,context)
	if not constraints.allowed:
		result.reasons = constraints.reasons
		return result
	for part in action.parts:
		var profile = career.athlete.jumps[part.jump_id]
		if int(profile.unlocked_rotations) < int(part.rotations) and int(profile.attempt_evidence[KEYS[int(part.rotations)]].get("successes",0)) <= 0:
			result.reasons.append("先建立连跳中各单跳的实际完成基础")
			return result
	var evidence_context := str(context.get("evidence_context","practice"))
	var source_id := str(context.get("source_id",""))
	if Evidence.already_recorded(career,id,batch_id,evidence_context,source_id):
		result.reasons.append("这次训练已结算")
		return result
	var first: Dictionary = action.parts[0]
	var element = preload("res://src/domain/program_element.gd").create("specialist","jump",first.jump_id,int(first.rotations)).element
	element.set_combination_parts(action.parts.slice(1))
	var program = preload("res://src/domain/skating_program.gd").create("specialist","free",[element]).program
	program.whole_run_familiarity = float(context.get("familiarity",70.0))
	program.slot_familiarity[element.element_id] = program.whole_run_familiarity
	if context.get("program_data") is Dictionary:
		var rehearsal = preload("res://src/domain/skating_program.gd").from_dict(context.program_data)
		if rehearsal != null: program = rehearsal
	var execution_action := action.duplicate(true)
	if context.get("element") is Dictionary: execution_action.element = context.element
	var evidence := {"action":action.duplicate(true),"action_id":id,"batch_id":batch_id,"clock":career.clock.to_dict(),"context":evidence_context,"attempts":0,"successes":0,"clean_successes":0,"failure_counts":{},"assessment_eligible":true}
	if context.has("source_id"):
		evidence.source_id = context.source_id
		if not Model.validate_evidence(evidence,id).is_empty():
			result.reasons.append("日期训练来源无效")
			return result
	var single_records := {}
	var impact_before := float(career.athlete.body.impact_load)
	for attempt in attempts:
		var execution_context := context.duplicate(true)
		execution_context.function_limits = Functions.snapshot(career).limits
		execution_context.pressure = float(context.get("pressure",0.0))
		execution_context.event_scope = "internal"
		var execution := Execution.execute_jump_action(career.athlete,program,execution_action,execution_context,rng)
		result.executions.append(execution)
		evidence.attempts += 1
		var completed: bool = execution.parts.size() == action.parts.size()
		var clean: bool = completed
		for index in execution.parts.size():
			var actual: Dictionary = execution.parts[index]
			var physical_success := bool(actual.actual.success)
			completed = completed and physical_success and int(actual.called_rotations) == int(action.parts[index].rotations) and str(actual.jump_id) == str(action.parts[index].jump_id)
			clean = clean and actual.status == "success"
			var part_action := {"kind":"jump","parts":[{"jump_id":actual.jump_id,"rotations":int(actual.facts.planned_rotations)}]}
			var part_id := Model.action_id(part_action)
			if not single_records.has(part_id):
				single_records[part_id] = {"action":part_action,"action_id":part_id,"batch_id":batch_id,"clock":career.clock.to_dict(),"context":evidence_context,"attempts":0,"successes":0,"clean_successes":0,"failure_counts":{},"assessment_eligible":true}
				if context.has("source_id"): single_records[part_id].source_id = context.source_id
			var single: Dictionary = single_records[part_id]
			single.attempts += 1
			if physical_success: single.successes += 1
			if actual.status == "success": single.clean_successes += 1
			var error := str(actual.actual.error_type)
			if not error.is_empty(): single.failure_counts[error] = int(single.failure_counts.get(error,0))+1
			var profile = career.athlete.jumps[actual.jump_id]
			var key: String = KEYS[int(actual.facts.planned_rotations)]
			profile.attempts += 1
			profile.attempt_evidence[key].attempts += 1
			if physical_success: profile.attempt_evidence[key].successes += 1
			if actual.status == "success": profile.attempt_evidence[key].clean_successes += 1
			var failure_key: String = {"fall":"falls","pop":"pops","underrotated":"underrotated","two_foot":"two_foot"}.get(error,"")
			if not failure_key.is_empty(): profile.attempt_evidence[key][failure_key] += 1
			result.outcomes.append_array(Training.apply(career,str(actual.jump_id),int(actual.facts.planned_rotations),1,float(context.get("quality",1.0)),rng,false))
			result.actual_load.jump_attempts += 1
			if index > 0:
				var leader = career.athlete.jumps[execution.parts[index-1].jump_id]
				leader.landing.combination = minf(95.0,float(leader.landing.combination)+0.4)
		if completed: evidence.successes += 1
		if completed and clean: evidence.clean_successes += 1
		if not completed:
			var failure := "interrupted" if execution.combination_interrupted else "execution"
			evidence.failure_counts[failure] = int(evidence.failure_counts.get(failure,0))+1
	for single in single_records.values(): Evidence.record(career,single)
	Evidence.record(career,evidence)
	result.evidence = evidence
	result.actual_load.impact = float(career.athlete.body.impact_load)-impact_before
	return result
