class_name QuarterTrainingSummary
extends RefCounted

const JUMP_LABELS := {"toe_loop": "后外点冰跳", "salchow": "后内结环跳", "loop": "后外结环跳", "flip": "后内点冰跳", "lutz": "勾手跳", "axel": "阿克塞尔跳"}
const ROTATION_LABELS := {1: "单周", 2: "双周", 3: "三周", 4: "四周"}
const STATUS_LABELS := {"ahead": "领先计划", "on_track": "按计划推进", "slightly_behind": "轻微落后", "far_behind": "明显落后", "reassess": "需要重新评估"}
const TARGET_LABELS := {"acute_fatigue": "即时疲劳", "cumulative_fatigue": "累积疲劳", "ankle_load": "踝部负荷", "impact_load": "跳跃冲击负荷", "growth_trend": "身体成长趋势", "recovery_capacity": "恢复能力"}
const GAP_LABELS := {
	"needs_attempts": "还需要实际尝试",
	"needs_first_success": "还没有首次成功证据",
	"needs_recent_successes": "近期成功次数不足",
	"needs_clean_landings": "干净落冰不足",
	"needs_landing_control": "落冰控制不足",
	"needs_physical_readiness": "身体准备尚未跟上",
	"needs_rotation_foundation": "转体基础不足",
	"needs_internal_evidence": "还需要内部赛证据",
	"needs_official_evidence": "还需要正式比赛证据",
}

static func build(_career, completed_entries: Array) -> Dictionary:
	var result := {"breakthroughs": [], "near_breakthroughs": [], "setbacks": [], "costs": [], "roadmap": [], "coach_advice": [], "details": []}
	var batches: Dictionary = {}
	for raw_entry in completed_entries:
		var entry := _as_dictionary(raw_entry)
		if entry.is_empty():
			continue
		var category := str(entry.get("category", ""))
		if category == "jump_attempt_batch":
			_accumulate_batch(batches, entry)
		elif category == "jump_milestone" and str(entry.get("signature", "")).begins_with("first_jump_success"):
			result.breakthroughs.append("首次完成%s·%s" % [_jump_label(entry), _rotation_label(entry)])
		elif category == "jump_stage":
			_add_stage_summary(result, entry)
		elif category == "roadmap_progress":
			_add_roadmap_summary(result, entry)
		elif entry.has("delta") and not is_zero_approx(float(entry.delta)):
			_add_delta_summary(result, entry)
	for key in batches:
		result.details.append(_batch_detail(batches[key]))
	_add_coach_advice(result)
	return result

static func _as_dictionary(entry) -> Dictionary:
	if entry is Dictionary:
		return entry
	if entry != null and entry.has_method("to_dict"):
		return entry.to_dict()
	return {}

static func _accumulate_batch(batches: Dictionary, entry: Dictionary) -> void:
	var key := "%s:%d" % [entry.get("jump_id", ""), int(entry.get("rotations", 1))]
	if not batches.has(key):
		batches[key] = {"jump_id": str(entry.get("jump_id", "")), "rotations": int(entry.get("rotations", 1)), "attempts": 0, "successes": 0, "falls": 0, "pops": 0, "two_foot": 0, "hand_down": 0, "underrotated": 0, "downgraded": 0}
	for field in ["attempts", "successes", "falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]:
		batches[key][field] = int(batches[key][field]) + int(entry.get(field, 0))

static func _batch_detail(batch: Dictionary) -> String:
	var parts: Array[String] = ["尝试%d次" % int(batch.attempts), "成功%d次" % int(batch.successes)]
	for field in ["falls", "pops", "two_foot", "hand_down", "underrotated", "downgraded"]:
		var count := int(batch[field])
		if count > 0:
			parts.append("%s%d次" % [{"falls": "摔倒", "pops": "跳空", "two_foot": "双足", "hand_down": "扶冰", "underrotated": "存周", "downgraded": "降组"}[field], count])
	return "%s·%s：%s" % [JUMP_LABELS.get(batch.jump_id, batch.jump_id), ROTATION_LABELS.get(batch.rotations, str(batch.rotations)), "，".join(parts)]

static func _add_stage_summary(result: Dictionary, entry: Dictionary) -> void:
	var gaps: Array[String] = []
	for gap in entry.get("gaps", []):
		if GAP_LABELS.has(str(gap)):
			gaps.append(GAP_LABELS[str(gap)])
	if not gaps.is_empty():
		result.near_breakthroughs.append("%s·%s接近下一阶段：%s" % [_jump_label(entry), _rotation_label(entry), "、".join(gaps)])

static func _add_delta_summary(result: Dictionary, entry: Dictionary) -> void:
	var delta := float(entry.delta)
	var target := str(entry.get("target", ""))
	var label: String = str(TARGET_LABELS.get(target, target))
	var detail: String = "%s %s%.2f" % [label, "+" if delta > 0.0 else "", delta]
	result.details.append(detail)
	if target in ["acute_fatigue", "cumulative_fatigue", "ankle_load", "impact_load"] and delta > 0.0:
		result.costs.append("%s上升，训练已经产生身体代价" % label)
	elif delta < 0.0 and not target in ["acute_fatigue", "cumulative_fatigue", "ankle_load", "impact_load"]:
		result.setbacks.append("%s出现退步" % label)

static func _add_roadmap_summary(result: Dictionary, entry: Dictionary) -> void:
	var change: Dictionary = entry.get("status_change", {})
	var forecasts: Array = entry.get("forecast_change", [])
	if not change.is_empty():
		var text: String = "成长路线变为%s" % STATUS_LABELS.get(str(change.get("to", "")), str(change.get("to", "")))
		if not forecasts.is_empty():
			text += "，当前节点预计由%d岁调整至%d岁" % [int(forecasts[0].get("from_age", 0)), int(forecasts[0].get("to_age", 0))]
		result.roadmap.append(text)
	elif not forecasts.is_empty():
		result.roadmap.append("当前节点预计调整至%d岁" % int(forecasts[0].get("to_age", 0)))

static func _add_coach_advice(result: Dictionary) -> void:
	if not result.costs.is_empty():
		result.coach_advice.append("下季度应优先控制负荷，不要只追求动作数量。")
	elif not result.near_breakthroughs.is_empty():
		result.coach_advice.append("动作正在接近突破，继续补足最关键的证据。")
	elif not result.roadmap.is_empty():
		result.coach_advice.append("根据最新预测调整季度重点，长期目标不必立即推翻。")
	else:
		result.coach_advice.append("本季度没有必须改变方向的信号，可以继续观察。")

static func _jump_label(entry: Dictionary) -> String:
	var jump_id := str(entry.get("jump_id", ""))
	return JUMP_LABELS.get(jump_id, jump_id)

static func _rotation_label(entry: Dictionary) -> String:
	var rotations := int(entry.get("rotations", 1))
	return ROTATION_LABELS.get(rotations, "%d周" % rotations)
