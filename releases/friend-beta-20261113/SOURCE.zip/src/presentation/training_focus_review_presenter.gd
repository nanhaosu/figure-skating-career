class_name TrainingFocusReviewPresenter
extends RefCounted

static func build(before: Dictionary, career) -> Dictionary:
	var facts: Array = []
	var old: Dictionary = before.get("athlete",{})
	var expression_change := float(career.athlete.mind.expression)-float(old.get("mind",{}).get("expression",career.athlete.mind.expression))
	var progress: Dictionary = preload("res://src/presentation/season_progress_presenter.gd").build(career,career.clock.season_id())
	for focus in career.training_direction.focuses:
		if facts.size() >= 2: break
		if focus.target.get("kind") != "jump":
			var label: String = preload("res://src/presentation/training_focus_presenter.gd").label(focus)
			var delta := 0.0
			var reference := "training_direction"
			match str(focus.kind):
				"musical_expression": delta = expression_change; reference = "athlete.mind.expression"
				"spin": delta = float(career.athlete.spin_foundation.rotation)-float(old.get("spin_foundation",{}).get("rotation",career.athlete.spin_foundation.rotation)); reference = "athlete.spin_foundation.rotation"
				"steps": delta = float(career.athlete.skating.turns)-float(old.get("skating",{}).get("turns",career.athlete.skating.turns)); reference = "athlete.skating.turns"
				"skating_edges": delta = float(career.athlete.skating.deep_edge)-float(old.get("skating",{}).get("deep_edge",career.athlete.skating.deep_edge)); reference = "athlete.skating.deep_edge"
				"execution","program_connections":
					var segment := str(focus.target.get("segment",""))
					delta = float(career.active_programs.get(segment,{}).get("whole_run_familiarity",0))-float(before.get("active_programs",{}).get(segment,{}).get("whole_run_familiarity",0))
					reference = "active_programs."+segment+".whole_run_familiarity"
			var description := "%s：本阶段相关指标变化%+.2f；这是实际训练变化，不是直接增加比赛分数或等级。" % [label,delta] if absf(delta) > 0.001 else "%s：本阶段暂无新的可核实指标变化，可沿用安排或调整重点。" % label
			facts.append({"kind":"focus_review","text":description,"evidence_refs":[reference]})
			continue
		var action_id: String = preload("res://src/domain/technical_repertoire.gd").action_id(focus.target)
		var item: Dictionary = career.technical_repertoire.entries.get(action_id,{})
		var old_item: Dictionary = before.get("technical_repertoire",{}).get("entries",{}).get(action_id,{})
		var attempts := int(item.get("learned_history",{}).get("total_attempts",0))-int(old_item.get("learned_history",{}).get("total_attempts",0))
		var state_rows: Array = progress.focuses.filter(func(row): return row.id == focus.id)
		var status := str(state_rows[0].progress) if not state_rows.is_empty() else "比赛可用性仍以武器库评估为准。"
		facts.append({"kind":"focus_review","text":"%s：%s %s" % [action_id,"本阶段记录了%d次真实目标动作尝试。" % attempts if attempts>0 else "本阶段尚无新的目标动作尝试，继续推进相关基础。",status],"evidence_refs":["technical_repertoire.entries"]})
	if facts.is_empty() and expression_change > 0.001: facts.append({"kind":"focus_review","text":"音乐表达能力提升%+.2f；来自实际课程，并非直接增加比赛P分。" % expression_change,"evidence_refs":["athlete.mind.expression"]})
	if facts.size() < 3:
		var pending: bool = not career.condition_state.get("pending_decision",{}).is_empty()
		facts.append({"kind":"focus_review","text":"先处理医疗团队提出的重大决定，未执行课程不会算作已完成。" if pending else "已有节目继续保留；可根据这次成果调整两个重点，或沿用当前方向。","evidence_refs":["condition_state","active_programs"]})
	return {"facts":facts.slice(0,3)}
