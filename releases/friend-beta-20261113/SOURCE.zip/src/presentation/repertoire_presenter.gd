class_name RepertoirePresenter
extends RefCounted
const Functions = preload("res://src/simulation/athlete_function_service.gd")
const States := {"available":"比赛储备","training":"练习中","unavailable":"暂不可用"}
const Reasons := {"medical_restriction":"身体限制，先完成复评","needs_validation":"需要多个实际训练批次验证","persistent_decline":"近期持续下滑，教练会安排复评","insufficient_current_capacity":"当前能力不足，保留历史并重新练习","legacy_unverified":"旧档储备，待近期训练确认","repeatedly_validated":"近期多批次完成较稳定"}
static func build(career) -> Dictionary:
	var rows: Array = []
	var entries: Dictionary = career.technical_repertoire.entries
	var ids: Array = entries.keys()
	ids.sort()
	for id in ids:
		var item: Dictionary = entries[id]
		var check := Functions.action_constraints(career,item.action)
		var state := str(item.state) if check.allowed else "unavailable"
		var reasons: Array[String] = []
		for reason in item.get("reason_codes",[]): reasons.append(str(Reasons.get(reason,reason)))
		if not check.allowed: reasons = ["身体限制，先完成复评"]
		var attempts := 0
		var successes := 0
		for evidence in item.evidence:
			attempts += int(evidence.attempts)
			successes += int(evidence.successes)
		var history: Dictionary = item.get("learned_history",{})
		var detail := "%s\n近期记录：%d次尝试，%d次完成。%s\n%s\n复评：%s" % [str(States.get(state,state)),attempts,successes,"曾经掌握，学习历史仍保留。" if bool(history.get("ever_learned",false)) else "尚在积累储备。","；".join(reasons),"；".join(check.review_conditions) if not check.review_conditions.is_empty() else "教练会根据实际训练验证，不因一场失误撤下。"]
		if not item.get("context_warnings",[]).is_empty(): detail += "\n合乐后半段稳定性偏弱，单独完成不等于能放进节目后半段。"
		rows.append({"label":"%s · %s" % [id,States.get(state,state)],"detail":detail})
	# Opening practice has real single-jump completion records, but no staged
	# repertoire batches yet. Show that distinction without inventing evidence.
	for jump_id in career.athlete.jumps:
		var profile = career.athlete.jumps[jump_id]
		for rotation in range(1,int(profile.unlocked_rotations)+1):
			var action := {"kind":"jump","parts":[{"jump_id":jump_id,"rotations":rotation}]}
			var id := preload("res://src/domain/technical_repertoire.gd").action_id(action)
			if entries.has(id): continue
			var evidence: Dictionary = profile.attempt_evidence[["","single","double","triple","quad"][rotation]]
			if int(evidence.get("successes",0)) <= 0: continue
			var check := Functions.action_constraints(career,action)
			rows.append({"label":"%s · %s" % [id,"已跳出·待训练验证" if check.allowed else "暂不可用"],"detail":"已有实际完成记录：%d次尝试，%d次完成。\n尚无近期分批验证，不代表比赛稳定；教练会在日常训练中继续确认。\n%s" % [int(evidence.attempts),int(evidence.successes),"当前身体允许练习。" if check.allowed else "身体限制，先完成复评。"]})
	return {"title":"技术武器库","subtitle":"单跳与有序连跳分开记录 · 暂不可用不等于遗忘","rows":rows,"empty":"还没有实际训练记录。跟随教练开始练习后，这里会留下你的动作储备。"}
