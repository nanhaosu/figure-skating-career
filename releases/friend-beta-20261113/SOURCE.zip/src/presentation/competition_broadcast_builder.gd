class_name CompetitionBroadcastBuilder
extends RefCounted

static func build(segment_record: Dictionary, leader_tes: float, target_duration: float, _meaning_context: Dictionary = {}) -> Dictionary:
	var segment := str(segment_record.get("segment","short"))
	var duration := clampf(target_duration,70.0,100.0) if segment == "free" else clampf(target_duration,40.0,60.0)
	var progress_by_id := {}; var point_by_id := {}; var calls := {}; var scores := {}
	for raw in segment_record.get("route_execution",{}).get("action_anchors",[]):
		if int(raw.get("part_index",0)) != 0: continue
		var id := str(raw.get("element_id",""))
		if not progress_by_id.has(id):
			progress_by_id[id] = clampf(float(raw.get("progress",0.0)),0.0,1.0)
			point_by_id[id] = {"x":float(raw.get("x",0.5)),"y":float(raw.get("y",0.5))}
	for raw in segment_record.get("technical_review",{}).get("final_elements",[]): calls[str(raw.get("element_id",""))] = raw
	for raw in segment_record.get("protocol",segment_record.get("score",{})).get("element_scores",[]): scores[str(raw.get("element_id",""))] = raw
	var events: Array[Dictionary] = []; var running_tes := 0.0; var pending := 0
	var elements: Array = segment_record.get("performance",{}).get("elements",[])
	var turning_points := {}
	for turning in preload("res://src/presentation/competition_turning_point_presenter.gd").build(segment_record): turning_points[turning.element_id] = turning
	for index in elements.size():
		var actual: Dictionary = Dictionary(elements[index]).duplicate(true)
		actual.erase("planned_abbreviation")
		var id := str(actual.get("element_id","")); var call: Dictionary = calls.get(id,{})
		var score: Dictionary = scores.get(id,{})
		if turning_points.has(id): actual.turning_point = turning_points[id].duplicate(true)
		if not call.is_empty():
			actual.abbreviation = display_abbreviation(call)
			actual.base_value = float(call.get("base_value",actual.get("base_value",0.0)))
			actual.invalid_reason = str(call.get("invalid_reason", ""))
			var confidence := str(call.get("call_confidence", call.get("evidence_confidence", "")))
			actual.status = "review" if confidence != "clear" else str(call.get("status",actual.get("status","success")))
		actual.goe = float(score.get("goe",actual.get("live_goe",0.0)))
		actual.live_goe = actual.goe
		if actual.live_goe < 0.0 and actual.status != "review": actual.status = "error"
		actual.element_score = float(score.get("total",float(actual.get("base_value",0.0))+float(actual.goe)))
		var attempted_axel := str(elements[index].get("planned_abbreviation",elements[index].get("abbreviation",""))).contains("3A")
		for part in elements[index].get("parts",[]):
			attempted_axel = attempted_axel or str(part.get("planned_abbreviation",part.get("abbreviation",""))) == "3A"
		if attempted_axel:
			actual.meaning_cue = "这次是3A的赛场尝试；落冰与最终周数认定都要核对，不等于训练中跳成。"
			if str(actual.get("status","")) == "review": actual.meaning_cue = "3A尝试已经滑过，仍在等待技术组确认周数；先不宣布突破。"
		running_tes = snappedf(running_tes+float(actual.element_score),0.01)
		if str(actual.get("status","")) == "review": pending += 1
		var progress := float(progress_by_id.get(id,float(index+1)/float(elements.size()+1)))
		events.append({"progress":progress,"timestamp":snappedf(progress*duration,0.001),"route_point":Dictionary(point_by_id.get(id,{})).duplicate(true),"record":actual,"running_tes":running_tes,"pending_review_count":pending})
	return {"events":events,"provisional_tes":running_tes,"leader_tes":snappedf(leader_tes,0.01),"pending_review_count":pending,"target_duration":duration}

static func display_abbreviation(call: Dictionary) -> String:
	var parts: Array = call.get("parts", [])
	if parts.size() > 1:
		var labels: Array[String] = []
		for part in parts: labels.append(_label_with_symbols(part))
		return "+".join(labels)
	return _label_with_symbols(call)

static func _label_with_symbols(call: Dictionary) -> String:
	var label := str(call.get("abbreviation", "?"))
	for symbol in call.get("info", []):
		if str(symbol) in ["*", "<", "<<", "!", "e", "+REP"] and not label.contains(str(symbol)):
			label += str(symbol)
	if str(call.get("invalid_reason", "")) == "REP" and not label.contains("*"): label += "*"
	return label

static func frame_at(timeline: Dictionary, progress: float) -> Dictionary:
	var revealed: Array[Dictionary] = []; var running_tes := 0.0; var pending := 0; var route_point := {}
	var meaning_cue := ""
	for event in timeline.get("events",[]):
		if float(event.get("progress",0.0)) > progress+0.00001: break
		revealed.append(Dictionary(event.get("record",{})).duplicate(true))
		if not str(event.get("record",{}).get("meaning_cue","")).is_empty(): meaning_cue = str(event.record.meaning_cue)
		running_tes = float(event.get("running_tes",running_tes)); pending = int(event.get("pending_review_count",pending)); route_point = Dictionary(event.get("route_point",{})).duplicate(true)
	return {"progress":clampf(progress,0.0,1.0),"revealed_elements":revealed,"running_tes":snappedf(running_tes,0.01),"leader_tes":float(timeline.get("leader_tes",0.0)),"pending_review_count":pending,"route_point":route_point,"meaning_cue":meaning_cue}
