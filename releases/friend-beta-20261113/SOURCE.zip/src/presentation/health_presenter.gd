class_name HealthPresenter
extends RefCounted
static func build(career) -> Dictionary:
	var snapshot := preload("res://src/simulation/athlete_function_service.gd").snapshot(career)
	var rows: Array = [{"label":"当前负荷与恢复","detail":"即时疲劳 %.1f · 累积负荷 %.1f\n短期疲劳会影响当期表现，不会直接删除技术储备。\n教练会自动下调不安全动作的份额，保留允许的滑行、旋转及基础。" % [snapshot.acute_fatigue,snapshot.cumulative_load]}]
	var names := {"takeoff":"起跳","coordination":"协调","landing":"落冰","recovery":"恢复"}
	for key in snapshot.limits:
		var limit: Dictionary = snapshot.limits[key]
		rows.append({"label":"%s功能 · %s" % [names.get(key,key),"暂停相关动作" if bool(limit.get("blocked",false)) else "受限训练"],"detail":"%s\n%s" % ["最多练%d周动作。" % int(limit.maximum_rotations) if limit.has("maximum_rotations") else "按教练评估安排允许的动作。",str(limit.get("review_condition","通过下一阶段身体复评再恢复难度"))]})
	for id in career.condition_state.rehabilitation:
		var record: Dictionary = career.condition_state.rehabilitation[id]
		var stages := {"protection":"保护期","functional_recovery":"功能恢复","review":"等待复评","return_to_training":"重返训练"}
		rows.append({"label":"康复记录 · %s" % stages.get(record.stage,record.stage),"detail":"%s\n已执行%d个季度。进展按实际完成的恢复训练评估，可能出现平台或反复。\n身体通过复评后，高难度仍需新的训练证据，不会自动恢复旧编排。" % ["较长周期康复" if record.route_id == "full_rehabilitation" else "保守治疗",int(record.elapsed_quarters)]})
		for injury in career.condition_state.injuries:
			if injury.id == id and injury.status == "recovered" and not injury.get("residual_function_limits",{}).is_empty():
				rows[-1].action_id = "reassess:"+str(id)
				rows[-1].action_label = "商量进一步完整康复"
	return {"title":"身体与康复","subtitle":"身体允许做什么，与技术曾经学会什么，是两回事","rows":rows}
