class_name CompetitionTurningPointPresenter
extends RefCounted

static func build(segment_record: Dictionary) -> Array[Dictionary]:
	var calls := {}
	for call in segment_record.get("technical_review",{}).get("final_elements",[]): calls[str(call.get("element_id",""))] = call
	var positions := {}
	for anchor in segment_record.get("route_execution",{}).get("action_anchors",[]):
		if int(anchor.get("part_index",0)) == 0: positions[str(anchor.get("element_id",""))] = float(anchor.get("progress",0))
	var rows: Array[Dictionary] = []
	var late := {}
	for element in segment_record.get("performance",{}).get("elements",[]):
		if element.get("kind") != "jump": continue
		var id := str(element.get("element_id",""))
		if id.is_empty(): continue
		var call: Dictionary = calls.get(id,{})
		var kind := ""
		var text := ""
		var repeated := str(call.get("invalid_reason","")) == "REP"
		for part in call.get("parts",[]): repeated = repeated or str(part.get("invalid_reason","")) == "REP"
		if repeated:
			kind = "repetition_invalid"
			text = "这个跳跃被判定重复失效；落冰质量不能消除重复规则。"
		elif bool(element.get("combination_interrupted",false)):
			kind = "lost_combination"
			text = "这次连跳中断，后面的追加跳跃未完整执行；是否补回要看后续实际动作。"
		elif element.get("recovery_decision",{}).get("action_id") == "recover" and element.get("parts",[]).size() > 1 and _completed(element.parts):
			kind = "recovered_combination"
			text = "她在后面的跳跃接上了连跳，补回此前留下的追加跳跃；完成质量仍按实际判分。"
		elif float(positions.get(id,0)) >= 0.5 and _completed(element.get("parts",[])):
			late = _row(id,"late_completion","进入节目后半段，这个跳跃仍完成了。")
		if not kind.is_empty(): rows.append(_row(id,kind,text))
	if rows.is_empty() and not late.is_empty(): rows.append(late)
	return rows

static func _completed(parts: Array) -> bool:
	if parts.is_empty(): return false
	for part in parts:
		if not bool(part.get("actual",{}).get("success",false)) or bool(part.get("actual",{}).get("fall",false)): return false
	return true

static func _row(id: String, kind: String, text: String) -> Dictionary:
	return {"element_id":id,"kind":kind,"text":text,"evidence_refs":["performance:"+id,"technical_review:"+id]}
