class_name SeasonTargetPresenter
extends RefCounted

const Entry = preload("res://src/simulation/entry_application_service.gd")
const Annual = preload("res://src/presentation/annual_selection_policy_presenter.gd")
const Senior = preload("res://src/simulation/senior_championship_service.gd")
const GP = preload("res://src/simulation/senior_grand_prix_service.gd")
const JGPBoard = preload("res://src/presentation/jgp_competition_presenter.gd")
const Personal = preload("res://src/simulation/international_personal_eligibility.gd")

# A presentation projection. In particular, never commit dispatches or generate
# a roster just to fill an otherwise unknown competitor table.
static func build(career, calendar: Dictionary, entry_plan: Dictionary, target_event_id: String = "") -> Dictionary:
	if target_event_id.is_empty(): target_event_id = str(career.season_state.get("target_event_id",""))
	var targets: Array = []
	var target: Dictionary = {}
	for event in calendar.get("events",[]):
		if event.get("status") == "cancelled" or event.get("reference_only",false): continue
		targets.append({"event_id":str(event.get("event_id","")),"name":str(event.get("name","")),"date":str(event.get("start_date",""))})
		if event.get("event_id") == target_event_id: target = event
	if target.is_empty() and target_event_id.is_empty() and not targets.is_empty():
		target_event_id = str(targets[0].event_id)
		for event in calendar.get("events",[]):
			if event.get("event_id") == target_event_id: target = event; break
	var annual: Dictionary = Annual.build(career,calendar)
	var gate: Dictionary = {"eligible":false,"status":"unknown","explanations":["尚无可核对的目标赛事"]}
	var deadlines: Array = []
	var competitors: Array = []
	var consequences: Array = []
	var entry_options: Array = []
	if not target.is_empty():
		var bundle: Dictionary = preload("res://src/content/season_bundle_repository.gd").for_career(career)
		gate = Entry.current_eligibility(career,target,bundle)
		gate["entry_status"] = str(entry_plan.get("entries",{}).get(target_event_id,{}).get("status","unknown"))
		deadlines = _deadlines(target,career)
		entry_options = Entry.options(career,target,bundle,gate)
		if gate.entry_status == "confirmed":
			for application in career.selection_state.get("applications",{}).values():
				if application.get("event_id") != target_event_id or application.get("route_id") not in ["enter","self_fund_enter"]: continue
				for option in entry_options:
					if option.get("id") == application.route_id and application.get("option_snapshot",{}).has("costs"):
						option.costs = application.option_snapshot.costs.duplicate(true)
						option["paid_receipt"] = true
		competitors = _competitors(career,target,gate)
		var kind := "world_junior" if target.get("event_family") == "world_junior" else ("jgp" if target.get("event_family") == "jgp_stage" else target_event_id)
		for event in calendar.get("events",[]):
			if event.get("scope") != "domestic" and not _required_events(target_event_id).has(event.get("event_id","")) and event.get("event_id") != target_event_id and not (GP.supports_final(target) and GP.supports(event)): continue
			var role: Dictionary = annual.event_roles.get(str(event.get("event_id","")),{}).get(kind,{"role":"unknown","label":"本目标的逐场选拔影响未覆盖／未核实"})
			var senior_role: Dictionary = _senior_role(str(event.get("event_id","")),target_event_id)
			if not senior_role.is_empty(): role = senior_role
			if GP.supports_final(target) and GP.supports(event):
				role = {"role":"countable","label":"本场名次计入大奖赛积分；不参赛会减少晋级总决赛的机会。"}
			elif GP.supports(target) and event.get("scope") == "domestic" and career.selection_state.get("decisions",{}).has("senior_gp_%d" % int(target.ruleset_season_start_year)):
				role = {"role":"optional","label":"本站邀请已公布，本场国内成绩不会改写这份邀请。"}
			if event.get("event_id") == target_event_id:
				role = {"role":"target","label":"不参加将放弃本目标的个人赛果；已支付费用按报名规则处理，派遣名额可能递补给候补。"}
			var dates: Dictionary = event.get("actual_dates",{})
			var finish := str(dates.get("end",event.get("end_date","")))
			var now := str(career.competition_timeline.get("date",""))
			var ended: bool = career.competition_archive.any(func(archive):return archive.get("event_id") == event.event_id) or (finish.length() == 10 and now.length() == 10 and finish < now)
			consequences.append({"event_id":str(event.get("event_id","")),"name":str(event.get("name","")),"role":role.role,"label":"历史成绩已结算，已完成的资格证据继续有效。" if ended else role.label,"start":str(dates.get("start",event.get("start_date",""))),"end":str(dates.get("end",event.get("end_date",""))),"entry_status":str(entry_plan.get("entries",{}).get(event.get("event_id"),{}).get("status","unknown")),"training_effect":"该赛事已结束。" if ended else "不参赛可保留该赛事实际日期区间用于训练或恢复；收益取决于训练、疲劳和伤病。","historical":ended})
	var jgp_competition: Dictionary = JGPBoard.build(career,calendar,target_event_id) if target.get("event_family") == "jgp_stage" else {}
	var sections: Array = _sections(target,gate,deadlines,competitors,consequences,entry_options)
	if not jgp_competition.is_empty(): sections.insert(2,jgp_competition.section)
	return {"jgp_competition":jgp_competition,"targets":targets,"target_options":targets,"target_event_id":target_event_id,"target":target.duplicate(true),"eligibility":gate,"entry_options":entry_options,"reasons":gate.get("explanations",[]),"deadlines":deadlines,"competitors":competitors,"competitor_rows":competitors,"skip_consequences":consequences,"policy_status":annual.policy_status,"sections":sections,"source_notice":"冻结决定保留历史；当前预览尚未派遣。无认可记录表示证据未建立，不推断选手实际能力。"}

static func _deadlines(event: Dictionary, career = null) -> Array:
	var rows: Array = []
	for key in ["application_deadline","nomination_deadline","music_deadline"]:
		rows.append({"kind":key,"date":str(event.get(key,"未知")),"status":"known" if event.has(key) else "unknown","source":("游戏政策；" if key == "application_deadline" and event.get("application_deadline_game_policy",false) else "赛历原始字段（未自动宣称官方日期）；")+key})
	var policy: Dictionary = Personal.policy_for(event)
	if not policy.is_empty():
		rows.append({"kind":"personal_qualification_cutoff","date":str(policy.get("cutoff","未知")),"status":"known" if policy.has("cutoff") else "unknown","source":str(policy.get("source_id",policy.get("policy_id","个人资格政策"))),"precision":str(policy.get("cutoff_precision","unknown")),"historical_deadline":str(policy.get("final_historical_deadline","unknown"))})
	if career != null:
		var now := str(career.competition_timeline.get("date",""))
		for row in rows: row["expired"] = now.length() == 10 and str(row.date).length() == 10 and now > str(row.date)
	return rows

static func _competitors(career, event: Dictionary, gate: Dictionary = {}) -> Array:
	var id := str(event.get("event_id",""))
	if not event.get("event_family") in ["world_junior","jgp_stage"] and not Senior.supports(event) and not GP.supports(event) and not GP.supports_final(event): return []
	var key := "world_junior" if event.get("event_family") == "world_junior" else "jgp"
	if Senior.supports(event): key = Senior._key(event)
	elif GP.supports(event): key = "senior_gp_%d" % int(event.get("ruleset_season_start_year",0))
	elif GP.supports_final(event): key = GP.FINAL_ID
	var saved: Dictionary = career.selection_state.get("decisions",{}).get(key,{})
	var decision: Dictionary = saved.get("decision",{})
	var frozen := not decision.is_empty()
	if decision.is_empty():
		if GP.supports(event): decision = gate.get("senior_gp_invitation",{}).get("plan",{})
		elif GP.supports_final(event): decision = gate.get("gp_final_standings",{})
		elif Senior.supports(event): decision = gate.get("senior_championship",{})
	var source := ("selection_state.decisions." if frozen else "provisional_preview.")+key
	var candidates: Array = decision.get("audit",{}).get("candidate_rows",saved.get("inputs",[]))
	var policy: Dictionary = Personal.policy_for(event)
	var rows: Array = []
	for candidate in candidates:
		var athlete_id := str(candidate.get("athlete_id",""))
		if athlete_id.is_empty() or athlete_id == "player": continue
		var personal: Dictionary = candidate.get("personal",{})
		var gaps: Array = []
		for code in personal.get("reason_codes",[]):
			gaps.append({"code":str(code),"status":"unknown" if personal.get("status","unknown") == "unknown" else "unmet","source":"冻结个人资格评估"})
		if personal.is_empty() and not candidate.has("best_total"): gaps.append({"code":"personal_evidence_not_recorded","status":"unknown","source":"候选记录"})
		if GP.supports(event) and int(event.get("ruleset_season_start_year",0)) == 2022 and candidate.has("best_total"):
			gaps.append({"code":"gp_recognized_total","required":GP.MINIMUM_2022,"observed":candidate.best_total,"status":"met" if float(candidate.best_total) >= GP.MINIMUM_2022 else "unmet","source":source})
		for segment in policy.get("minimum_tes",{}):
			var receipt: Dictionary = personal.get("tes",{}).get("segments",{}).get(segment,{})
			gaps.append({"code":str(segment)+"_tes","required":policy.minimum_tes[segment],"observed":receipt.get("tes",null),"status":"met" if not receipt.is_empty() else ("unknown" if personal.get("status","unknown") == "unknown" else "not_established"),"source":"冻结个人资格认可成绩；无认可记录不推断实际能力","evidence":receipt.duplicate(true)})
		var assignments: Array = decision.get("assignments",{}).get(athlete_id,career.selection_state.get("assignments",{}).get(athlete_id,[]))
		var selected: bool = assignments.has(id) or decision.get("fields",{}).get(id,[]).has(athlete_id) or decision.get("qualified_ids",[]).has(athlete_id)
		for chosen in decision.get("selected",[]):
			if chosen.get("athlete_id") == athlete_id: selected = true
		if policy.has("minimum_combined_tes"):
			gaps.append({"code":"combined_tes","required":policy.minimum_combined_tes,"observed":personal.get("tes",{}).get("combined",null),"status":"met" if personal.get("tes",{}).get("eligible",false) else ("unknown" if personal.get("status","unknown") == "unknown" else "not_established"),"source":source})
		var required_events: Array = _required_events(id) if candidate.get("federation","") == "CHN" else []
		for required_id in required_events:
			var present: bool = candidate.get("results",[]).any(func(result):return result.get("event_id") == required_id)
			gaps.append({"code":"required_event_result","event_id":required_id,"status":"met" if present else "not_established","source":source})
		rows.append({"athlete_id":athlete_id,"display_name":str(career.world_athletes.get(athlete_id,{}).get("name",candidate.get("name",athlete_id))),"federation":str(candidate.get("federation",career.world_athletes.get(athlete_id,{}).get("federation",""))),"source":source,"frozen":frozen,"status":"selected" if selected else "candidate","personal_status":str(personal.get("status","unknown")),"gaps":gaps,"evidence":candidate.duplicate(true)})
	return rows

static func _required_events(target_id: String) -> Array:
	if target_id == Senior.MILANO_TRIAL: return ["cn_nationals_2024"]
	if target_id in [Senior.MILANO_QUALIFIER,Senior.CUP_OF_CHINA_2025]: return [Senior.MILANO_TRIAL]
	if target_id == Senior.MILANO_GAMES: return [Senior.CUP_OF_CHINA_2025,"cn_nationals_2025"]
	return []

static func _senior_role(event_id: String, target_id: String) -> Dictionary:
	if not _required_events(target_id).has(event_id): return {}
	return {"role":"required","label":"本目标的必要成绩：不参加将缺少该场完整成绩，影响后续派遣。"}

static func _sections(target: Dictionary, gate: Dictionary, deadlines: Array, competitors: Array, consequences: Array, options: Array) -> Array:
	var sections: Array = []
	var lines: Array[String] = ["目标："+str(target.get("name","未选择")),"当前资格："+("已满足" if gate.get("eligible",false) else "尚未满足，请查看下列条件")]
	for reason in gate.get("explanations",[]): lines.append(str(reason))
	for warning in gate.get("warnings",[]): lines.append(str(warning))
	for offer in gate.get("senior_gp_invitation",{}).get("plan",{}).get("audit",{}).get("supplemental_offers",[]):
		var added: Array = offer.get("added",{}).get(str(target.get("event_id","")),[])
		if not added.is_empty(): lines.append("%s 补充邀请 %d 人（游戏政策）：填补未开赛空位，原邀请保留。" % [str(offer.date),added.size()])
	for candidate in gate.get("senior_gp_invitation",{}).get("plan",{}).get("audit",{}).get("candidate_rows",[]):
		if candidate.get("athlete_id") == "player" and candidate.has("best_total"): lines.append("你的认可国际赛最好总分：%.2f" % float(candidate.best_total))
	var personal: Dictionary = gate.get("personal_eligibility",{})
	var tes: Dictionary = personal.get("tes",{})
	var policy: Dictionary = Personal.policy_for(target)
	if policy.has("minimum_combined_tes"):
		var observed := "%.2f" % float(tes.combined) if tes.has("combined") else "两段认可成绩尚未齐备"
		lines.append("你的认可技术分合计：%s；要求 %.2f" % [observed,float(policy.minimum_combined_tes)])
	sections.append({"heading":"目标与个人资格","body":"\n".join(lines)})
	lines = []
	var deadline_labels := {"application_deadline":"报名截止","nomination_deadline":"协会提名截止","music_deadline":"音乐提交截止","personal_qualification_cutoff":"个人资格成绩截止"}
	for row in deadlines:
		var basis := "游戏设定" if "游戏政策" in str(row.source) or row.get("precision") == "approved_game_date" else ("待核实" if row.status == "unknown" else "赛事 / 资格规则")
		lines.append("%s：%s · %s" % [deadline_labels.get(row.kind,row.kind),row.date,basis])
		if row.get("expired",false): lines[-1] += " · 已过截止日"
	for option in options:
		if option.get("id") in ["enter","self_fund_enter"]:
			var cost_label := "已付游戏资金" if option.get("paid_receipt",false) else "预计游戏资金支出"
			var date_label := "本次名单内改派确认截止" if str(option.get("label","")).contains("预报名姓名名单内改派") else "报名实际截止"
			lines.append("%s：%s；%s %s。%s" % [date_label,option.get("deadline","未知"),cost_label,str(option.get("costs",{}).get("money","未知")),option.get("label","")])
			if gate.get("entry_status") == "confirmed": lines.append("已完成报名，可继续备赛或在赛事详情中退赛。")
			else:
				lines.append("当前可提交报名" if option.get("available",false) else "当前无法提交报名")
				for reason in option.get("reasons",[]): lines.append(str(reason))
	sections.append({"heading":"截止日期与报名支出","body":"\n".join(lines)})
	lines = []
	for row in competitors:
		var detail: Array[String] = []
		for gap in row.gaps:
			if gap.has("required") and float(gap.required) <= 0: continue
			var label := _gap_label(str(gap.code))
			var state: String = str({"met":"已满足","unmet":"未满足","not_established":"尚无有效记录","unknown":"资料不足"}.get(gap.status,gap.status))
			var observed := str(gap.get("observed","未知")) if gap.get("observed") != null else "尚无认可成绩"
			detail.append("%s：%s%s" % [label,state,("（要求 %s；认可记录 %s）" % [str(gap.required),observed]) if gap.has("required") else (" · "+_event_label(str(gap.event_id)) if gap.has("event_id") else "")])
		var selected_label := "已获派遣 / 资格" if row.frozen else "按当前条件预计入选"
		lines.append("%s · %s · %s · %s\n%s" % [row.display_name,row.federation,"已公布" if row.frozen else "当前预览",selected_label if row.status == "selected" else "候选人","；".join(detail)])
	if lines.is_empty(): lines.append("尚无可核对的候选证据，不推断对手未达标。")
	sections.append({"heading":"竞争格局与资格差距","body":"\n".join(lines)})
	lines = []
	for row in consequences: lines.append("%s（%s 至 %s）：%s\n%s" % [row.name,row.start,row.end,row.label,row.training_effect])
	sections.append({"heading":"不参赛的影响","body":"\n".join(lines)})
	return sections

static func _gap_label(code: String) -> String:
	return {"gp_recognized_total":"认可国际赛最好总分","combined_tes":"短节目与自由滑技术分合计","combined_tes_below_minimum":"合计技术分未达要求","short_tes":"短节目技术分","free_tes":"自由滑技术分","short_tes_not_established":"短节目缺少认可成绩","free_tes_not_established":"自由滑缺少认可成绩","required_event_result":"指定比赛完整成绩","personal_evidence_not_recorded":"个人资格记录","invalid_birth_date":"出生日期待核实","too_young":"未达参赛年龄","too_old":"超出参赛年龄"}.get(code,"其他资格条件待核对")

static func _event_label(event_id: String) -> String:
	return {"cn_nationals_2024":"2024 全国锦标赛",Senior.MILANO_TRIAL:"2025 国内选拔赛",Senior.CUP_OF_CHINA_2025:"2025 中国杯","cn_nationals_2025":"2025 全国锦标赛"}.get(event_id,event_id)

