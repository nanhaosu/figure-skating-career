class_name KissAndCryBuilder
extends RefCounted

static func build(career, segment_record: Dictionary, standings: Dictionary) -> Dictionary:
	var score: Dictionary = segment_record.get("protocol",segment_record.get("score",{}))
	var rank := int(standings.get("current_rank",0)); var falls := int(segment_record.get("performance",{}).get("falls",0))
	var final_reaction := "我还在消化刚才发生的一切。"; var interpretation := "mixed"
	if bool(standings.get("personal_best",false)) or (rank > 3 and falls == 0): final_reaction = "名次不是最前面，但我对自己完成这套节目感到满意。"; interpretation = "personal_satisfaction"
	elif rank > 0 and rank <= 3: final_reaction = "看到名次的这一刻，我允许自己先高兴一下。"; interpretation = "placement_joy"
	var scope := str(standings.get("ranking_scope","provisional"))
	var rank_label := "排名等待确认"
	if rank > 0: rank_label = ("本段第%d名" if scope == "segment" else ("最终第%d名" if scope == "final" else "暂列第%d名")) % rank
	var coach := "教练判断：先确认分数和协议，之后再谈训练。"
	if career != null and career.relationships.has("coach") and float(career.relationships.coach.closeness) >= 60.0: coach = "教练判断：先接住你的情绪，再一起看最终确认。"
	if standings.get("event_family") == "jgp_stage":
		coach = "这是本段的结果，国际赛还要继续滑下去。" if scope == "segment" else ("本站成绩已经确定。看看这次与准备中的期待有什么不同，再谈下一步。" if scope == "final" else "这是暂列位置；最终结果未确定前，先不把它当作奖牌。")
	var pending := Array(segment_record.get("performance",{}).get("elements",[])).filter(func(e): return str(e.get("status","")) == "review").size()
	return {"athlete_reaction":"我还在等技术组确认，先把呼吸慢慢找回来。","revealed_athlete_reaction":final_reaction,"coach_reaction":coach,"pending_reviews":pending,"tes":float(score.get("tes",0.0)),"pcs":float(score.get("pcs",0.0)),"deductions":float(score.get("deductions",0.0)),"segment_score":float(score.get("total",0.0)),"total_score":float(standings.get("total_score",score.get("total",0.0))),"current_rank":rank,"rank_label":rank_label,"interpretation_kind":interpretation}
