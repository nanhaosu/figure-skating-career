class_name CoachHandoffPresenter
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const ClubCoachRepository = preload("res://src/content/club_coach_repository.gd")

static func build(career: CareerState) -> Dictionary:
	if career == null or career.athlete == null:
		return {"coach": {}, "existing_ability": [], "known_risks": [], "body_mind": [], "first_plan": []}
	var repository := ClubCoachRepository.new()
	var coach := repository.public_coach_summary(career.coach_assignment.coach_id)
	var club := repository.club_profile(career.coach_assignment.club_id)
	if coach.is_empty(): coach = {"name": "当前教练", "style": "先从已有训练记录了解你。", "history": ""}
	if club.is_empty(): club = {"name": "当前俱乐部"}
	return {
		"coach": {
			"name": str(coach.get("name", "当前教练")),
			"club_name": str(club.get("name", "当前俱乐部")),
			"style": str(coach.get("style", "")),
			"history": str(coach.get("history", "")),
			"known_strengths": Array(career.coach_assignment.known_strengths).duplicate(),
		},
		"existing_ability": _existing_ability(career),
		"known_risks": _known_risks(career),
		"body_mind": _body_mind(career),
		"first_plan": _first_plan(career),
	}

static func _existing_ability(career: CareerState) -> Array[Dictionary]:
	var singles := 0
	var doubles := 0
	for jump in career.athlete.jumps.values():
		singles += int(int(jump.attempt_evidence.single.attempts) > 0)
		doubles += int(int(jump.attempt_evidence.double.attempts) > 0)
	var strongest_spin := "直立旋转"
	var strongest_value := -1.0
	var spin_names := {"upright":"直立旋转", "sit":"蹲踞旋转", "camel":"燕式旋转", "layback":"躬身旋转", "combination":"联合旋转", "flying":"跳接旋转"}
	for spin_id in career.athlete.spins:
		var value := float(career.athlete.spins[spin_id].proficiency)
		if value > strongest_value:
			strongest_value = value
			strongest_spin = spin_names.get(spin_id, spin_id)
	var skating_mean := _mean(career.athlete.skating)
	return [
		_statement("单周跳已练过%d种；两周跳开始练%d种。上场稳定性还要再看。" % [singles, doubles], ["athlete.jumps.*.attempt_evidence", "history.training_quarters"]),
		_statement("目前最熟悉的是%s，其他基础姿势也有一起练。" % strongest_spin, ["athlete.spins", "athlete.spin_foundation"]),
		_statement("滑行基础%s。接下来把单脚、用刃和速度连起来。" % _band(skating_mean), ["athlete.skating"]),
	]

static func _known_risks(career: CareerState) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for observation in career.pre_career_history.get("known_observations", []):
		result.append(_statement("已经被指出：%s" % str(observation), ["history.known_observations"] ))
	for concern in career.coach_assignment.known_concerns:
		result.append(_statement("需要留意：%s。先看实跳与比赛反馈，不预判判罚。" % concern, ["coach_assignment.known_concerns"] ))
	if result.is_empty():
		result.append(_statement("暂未发现明确技术问题。正式比赛前，我们再看看动作。", ["history.known_observations", "coach_assignment.known_concerns"]))
	return result

static func _body_mind(career: CareerState) -> Array[Dictionary]:
	var fatigue := float(career.athlete.body.get("cumulative_fatigue", 0.0))
	var motivation := float(career.athlete.mind.get("motivation", 50.0))
	var injuries: Array = career.condition_state.get("injuries", [])
	var health_text := "没有正在记录的伤病"
	if not injuries.is_empty(): health_text = "有%d项需要继续跟踪的身体记录" % injuries.size()
	return [
		_statement("目前%s，累计疲劳%s。" % [health_text, _load_band(fatigue)], ["condition_state.injuries", "athlete.body.cumulative_fatigue"]),
		_statement("训练意愿%s。累了，或不想上冰了，都可以告诉教练。" % _motivation_band(motivation), ["athlete.mind.motivation", "relationships.coach"]),
	]

static func _first_plan(career: CareerState) -> Array[Dictionary]:
	var weakest_skating := "one_foot_stability"
	for key in career.athlete.skating:
		if float(career.athlete.skating[key]) < float(career.athlete.skating[weakest_skating]): weakest_skating = key
	var skating_names := {"speed":"速度", "flow":"滑出", "one_foot_stability":"单脚稳定", "deep_edge":"用刃", "turns":"转体步法", "knee_action":"膝部运用", "ice_efficiency":"冰面效率"}
	var coach_strength := "长期观察"
	if not career.coach_assignment.known_strengths.is_empty(): coach_strength = str(career.coach_assignment.known_strengths[0])
	return [
		_statement("先补%s，已接触的单周与两周跳轮换练。" % skating_names.get(weakest_skating, weakest_skating), ["athlete.skating.%s" % weakest_skating, "athlete.jumps"]),
		_statement("旋转一起练轴心、定心和基础姿势，再发展你擅长的动作。", ["athlete.spin_foundation", "athlete.spins"]),
		_statement("接下来也会多做%s。练一段后，再一起看进步和难处。" % coach_strength, ["coach_assignment.known_strengths", "relationships.coach"]),
	]

static func _statement(text: String, refs: Array) -> Dictionary:
	return {"text": text, "evidence_refs": refs.duplicate()}

static func _mean(values: Dictionary) -> float:
	if values.is_empty(): return 0.0
	var total := 0.0
	for value in values.values(): total += float(value)
	return total / float(values.size())

static func _band(value: float) -> String:
	if value >= 55.0: return "较扎实"
	if value >= 38.0: return "已有轮廓"
	return "正在打底"

static func _load_band(value: float) -> String:
	if value >= 35.0: return "偏高，需要先降量"
	if value >= 15.0: return "可以控制，但不能忽视恢复"
	return "不高"

static func _motivation_band(value: float) -> String:
	if value >= 72.0: return "很积极"
	if value >= 48.0: return "稳定"
	return "有些犹豫"
