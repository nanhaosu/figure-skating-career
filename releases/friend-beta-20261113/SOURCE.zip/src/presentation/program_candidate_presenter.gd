class_name ProgramCandidatePresenter
extends RefCounted

const JumpCatalog = preload("res://src/domain/jump_catalog.gd")
const ProgramValidator = preload("res://src/simulation/program_validator.gd")
const FormalScoringRepository = preload("res://src/content/formal_scoring_repository.gd")

const ROTATION_KEYS := {1:"single", 2:"double", 3:"triple", 4:"quad"}
const BAND_LABELS := {"stable":"稳定", "risky":"冒险", "unavailable":"尚不可用"}
const JUMP_NAMES := {"toe_loop":"后外点冰跳", "salchow":"后内结环跳", "loop":"后外结环跳", "flip":"后内点冰跳", "lutz":"勾手跳", "axel":"阿克塞尔跳"}
const REASON_LABELS := {
	"trained_and_available":"训练储备足够",
	"limited_training_evidence":"已经练过，但成功证据仍少",
	"prerequisite_missing":"尚未形成前一周数的训练基础",
	"no_training_evidence":"训练中还没有正式尝试记录",
	"repeat_limit":"放进这个位置会触发跳跃重复限制",
	"illegal_connection":"当前连跳连接不符合规则",
	"allowed_spin":"可选择的旋转类型；等级由比赛执行和技术组判定",
	"step_sequence":"接续步等级由比赛执行和技术组判定",
}

static func for_slot(career, program, slot_index: int, rules: Dictionary) -> Array[Dictionary]:
	var choices: Array[Dictionary] = []
	if career == null or career.athlete == null or program == null:
		return choices
	if slot_index < 0 or slot_index >= program.elements.size():
		return choices
	var element = program.elements[slot_index]
	match element.kind:
		"jump": choices = _jump_choices(career, program, slot_index, rules)
		"spin": choices = _spin_choices(career, rules)
		"step_sequence":
			choices.append(_choice("step_sequence", "接续步", "stable", ["step_sequence"], 0.0))
		"choreographic_sequence":
			choices.append(_choice("choreographic_sequence", "编排步法", "stable", ["step_sequence"], 0.0))
	return choices

static func _jump_choices(career, program, slot_index: int, rules: Dictionary) -> Array[Dictionary]:
	var choices: Array[Dictionary] = []
	var scoring := _scoring_catalog(rules)
	for jump_id in JumpCatalog.JUMP_IDS:
		var profile = career.athlete.jumps.get(jump_id)
		for rotations in range(1, 5):
			var band := "unavailable"
			var reasons: Array[String] = []
			var key: String = ROTATION_KEYS[rotations]
			var evidence: Dictionary = Dictionary(profile.attempt_evidence.get(key, {})) if profile != null else {}
			var attempts := int(evidence.get("attempts", 0))
			if profile != null and rotations <= int(profile.unlocked_rotations):
				# Unlocking permits selection; it does not establish reliable execution.
				var practiced := attempts >= 20 and float(evidence.get("successes", 0))/float(maxi(1,attempts)) >= 0.45 and int(evidence.get("clean_successes", 0)) >= 3
				var proficient := float(profile.proficiency.get(key, 0.0)) >= 40.0
				band = "stable" if practiced and proficient else "risky"
				reasons.append("trained_and_available" if band == "stable" else "limited_training_evidence")
			elif profile != null and attempts > 0 and rotations <= int(profile.unlocked_rotations) + 1:
				band = "risky"
				reasons.append("limited_training_evidence")
			else:
				reasons.append("no_training_evidence" if rotations <= 1 or (profile != null and rotations <= int(profile.unlocked_rotations) + 1) else "prerequisite_missing")
			if _violates_repeat_limit(program, slot_index, jump_id, rotations, rules):
				band = "unavailable"
				if not reasons.has("repeat_limit"): reasons.append("repeat_limit")
			var code := "%d%s" % [rotations, ProgramValidator.JUMP_CODES.get(jump_id, jump_id)]
			var choice := _choice("jump", code, band, reasons, FormalScoringRepository.element_value(scoring, code))
			choice.jump_id = jump_id
			choice.rotations = rotations
			choice.readable_name = "%s周%s" % [{1:"一",2:"二",3:"三",4:"四"}[rotations],JUMP_NAMES[jump_id]]
			choices.append(choice)
	return choices

static func _spin_choices(career, rules: Dictionary) -> Array[Dictionary]:
	var choices: Array[Dictionary] = []
	var allowed: Array = rules.get("allowed_spin_codes", ["CCoSp", "FCSp", "LSp", "FSSp", "CSp"])
	for code in allowed:
		var choice := _choice("spin", spin_label(str(code)), "stable", ["allowed_spin"], 0.0)
		choice.spin_code = str(code)
		choices.append(choice)
	return choices

static func _violates_repeat_limit(program, slot_index: int, jump_id: String, rotations: int, rules: Dictionary) -> bool:
	if rotations < 2: return false
	var count := 0
	for index in program.elements.size():
		if index == slot_index: continue
		var element = program.elements[index]
		if element.kind != "jump": continue
		if element.jump_id == jump_id and int(element.rotations) == rotations: count += 1
		for part in element.combination_parts:
			if str(part.get("jump_id", "")) == jump_id and int(part.get("rotations", 0)) == rotations: count += 1
	var repeat_limits = rules.get("repeat_limits", {})
	if repeat_limits is Dictionary and repeat_limits.has("max_repeated_triples_or_quads"):
		return count >= 2
	return count >= int(rules.get("same_jump_max", 2))

static func _scoring_catalog(rules: Dictionary) -> Dictionary:
	var year := int(rules.get("season_start_year", 2018))
	if year <= 0: year = 2018
	var loaded := FormalScoringRepository.load_catalog(year, "women_singles")
	if not loaded.errors.is_empty() and year != 2018:
		loaded = FormalScoringRepository.load_catalog(2018, "women_singles")
	return Dictionary(loaded.get("catalog", {}))

static func _choice(kind: String, label: String, band: String, reason_codes: Array[String], base_value: float) -> Dictionary:
	var reason_labels: Array[String] = []
	for code in reason_codes: reason_labels.append(str(REASON_LABELS.get(code, code)))
	return {
		"kind":kind, "label":label, "band":band,
		"group_id":"jumps" if kind == "jump" else "spins_steps",
		"band_label":str(BAND_LABELS.get(band, band)),
		"reason_codes":reason_codes.duplicate(), "reason_text":"；".join(reason_labels),
		"base_value":base_value,
	}

static func spin_label(code: String) -> String:
	return {
		"CCoSp":"换足联合旋转", "FCSp":"跳接燕式旋转", "LSp":"躬身转",
		"FSSp":"跳接蹲踞旋转", "CSp":"燕式旋转", "SSp":"蹲踞旋转",
	}.get(code, code) + "（%s）" % code
