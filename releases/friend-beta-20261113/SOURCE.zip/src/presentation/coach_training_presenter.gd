class_name CoachTrainingPresenter
extends RefCounted

const Plan = preload("res://src/domain/training_plan.gd")

static func proposal(career, result: Dictionary) -> Dictionary:
	var plan = result.get("plan")
	if plan == null: return {"headline":"本期课程待调整","detail":"；".join(result.get("errors",[]))}
	var decision: Dictionary = plan.coach_decision
	var allocated: Array = decision.get("allocated_gap_ids",[])
	var headline := "按原有约定继续训练"
	if not decision.is_empty():
		if decision.get("reason_codes",[]).has("gap_budget_unavailable"):
			headline = "本期优先身体与已选重点，短板保留基础维护"
		elif not allocated.is_empty():
			headline = "教练安排补练%s，其他类别照常" % Plan.JUMP_LABELS.get(allocated[0],"基础")
		else:
			var profile: Dictionary = career.coach_assignment.technical_tendencies
			if float(profile.get("toe_jump_mechanics",0.0)) > 0.1: headline = "本期侧重点冰技术，保留完整基础与恢复"
			elif float(profile.get("component_development",0.0)) > 0.1: headline = "本期侧重滑行表达，跳跃继续积累"
			elif float(profile.get("edge_foundation",0.0)) > 0.1: headline = "本期侧重用刃与动作基础，逐步巩固难度"
			else: headline = "本期完整课程，兼顾技术、状态与恢复"
	var detail: Array[String] = [headline]
	for id in Plan.JUMP_LABELS:
		var share := int(plan.shares.get("jump_"+id,0))
		detail.append("%s：%d周练习 · %d%%课时%s" % [Plan.JUMP_LABELS[id],int(plan.jump_rotations.get(id,1)),share,"（本期禁练或暂停）" if share == 0 else ""])
	detail.append("恢复%d%%；滑行%d%%；旋转%d%%；体能%d%%。" % [int(plan.shares.rest),int(plan.shares.skating_foundation),int(plan.shares.rotation),int(plan.shares.conditioning)])
	detail.append_array(result.get("reasons",[]))
	detail.append("安排练习不代表已经掌握；完成情况以训练后的实际储备为准。")
	return {"headline":headline,"detail":"\n".join(detail)}

static func review(facts: Array) -> Array:
	var lines: Array = []
	var corrected: Array[String] = []
	var supported := false
	for fact in facts:
		if fact.get("kind") == "state_change":
			var target := str(fact.get("target",""))
			if fact.get("category") == "coach_correction" and float(fact.get("delta",0.0)) > 0.0:
				var parts := target.split(".")
				if parts.size() == 3:
					var label := str(Plan.JUMP_LABELS.get(parts[0],"跳跃"))+str({"edge_stability":"用刃","edge_quality":"用刃","axis":"轴心","control":"落冰控制"}.get(parts[2],"技术"))
					if not corrected.has(label): corrected.append(label)
			if fact.get("category") == "coach_support" and target == "stress" and float(fact.get("delta",0.0)) < 0.0: supported = true
		if fact.get("kind") != "coach_training": continue
		var allocated: Array = fact.get("decision",{}).get("allocated_gap_ids",[])
		if allocated.is_empty(): continue
		var labels: Array[String] = []
		for id in allocated: labels.append(Plan.JUMP_LABELS.get(id,"跳跃"))
		lines.append({"kind":"coach_review","text":"本期已实际补练%s；是否可用于比赛，仍看完成质量与稳定性。" % "、".join(labels),"evidence_refs":["history.coach_training"]})
	if not corrected.is_empty():
		lines.append({"kind":"coach_review","text":"教练针对已观察到的问题，帮助%s有所改善；仍需继续巩固。" % "、".join(corrected),"evidence_refs":["outcomes.coach_correction"]})
	if supported:
		lines.append({"kind":"coach_review","text":"本期实际训练中的教练支持让压力有所缓和，不代表紧张已经消失。","evidence_refs":["outcomes.coach_support"]})
	return lines
