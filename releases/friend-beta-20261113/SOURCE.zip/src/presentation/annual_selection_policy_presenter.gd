class_name AnnualSelectionPolicyPresenter
extends RefCounted

const Assignment = preload("res://src/simulation/international_assignment_service.gd")
const Senior = preload("res://src/simulation/senior_championship_service.gd")
const Policy = preload("res://src/simulation/annual_selection_policy_service.gd")
const NOTICE := "当前采用既有游戏政策（非官方历史公告）；仅作规则展示，未冻结年度政策版本。世青截止沿用季度粒度，精确截止日未核实；年龄、个人资格与国家名额仍独立核对。"

static func build(_career, calendar: Dictionary) -> Dictionary:
	var season := str(calendar.get("season_id","未知赛季"))
	var year := 0
	# An explicit unknown/malformed season never borrows the civil-year field.
	if season.length() == 7 and season.substr(0,4).is_valid_int():
		var candidate := int(season.substr(0,4))
		if season == "%04d-%02d" % [candidate,(candidate+1)%100]: year = candidate
	var covered := year >= 2018 and year <= 2021
	var selected := Policy.effective(_career,year)
	covered = covered and selected.errors.is_empty() and not selected.policy.is_empty()
	var canonical_targets := {}
	if covered:
		var junior := preload("res://src/content/season_calendar_repository.gd").load_international_calendar(year,"women_singles","junior")
		for event in junior.get("calendar",{}).get("events",[]): canonical_targets[str(event.event_id)] = str(event.get("event_family",""))
	var standards := {}
	var roles := {}
	var notice := NOTICE
	if selected.status == "frozen": notice = "%s\n本季青年JGP/世青制度已公布并冻结；内容版本%s。成年目标仍按各自公开游戏办法，未纳入此青年公告冻结。" % [selected.policy.label,selected.content_sha256.left(12)]
	if not selected.errors.is_empty(): notice = "年度政策损坏，不能借用当前模板替换已公告制度："+"；".join(selected.errors)
	var lines: Array[String] = ["%s赛季 · 年度选拔标准" % season,notice]
	var targets := {"world_junior":"世青","jgp":"JGP分站"}
	if covered:
		lines.append("世青："+Policy.public_formula(selected.policy,"world_junior"))
		lines.append("JGP分站："+Policy.public_formula(selected.policy,"jgp"))
		lines.append("指定赛ID与既有选拔计算一致；可计入不等于必须全勤。2019 JGP还承认2018完整指定赛成绩。")
	else: lines.append("本赛季未覆盖：没有可核对的年度选拔公式，不借用邻年标准。")
	for event in calendar.get("events",[]):
		var id := str(event.get("event_id",""))
		if str(event.get("scope","")) == "domestic":
			roles[id] = {}
			for kind in targets:
				var designated: Array = selected.policy.targets[kind].designated_event_ids if covered else []
				var role := ("required" if kind == "world_junior" else "countable") if designated.has(id) else ("optional" if covered else "unknown")
				var label := str({"required":"必要成绩场次：不参加会失去本目标的指定成绩路径", "countable":"可计入指定成绩：不参加会减少一次成绩机会，仍可使用其他指定赛", "optional":"非本目标指定赛：不参加不直接移除该选拔路径", "unknown":"当季标准未覆盖，不能判断选拔影响"}[role])
				roles[id][kind] = {"role":role,"label":"%s · %s" % [targets[kind],label]}
		else:
			var kind := "world_junior" if event.get("event_family") == "world_junior" else ("jgp" if event.get("event_family") == "jgp_stage" else "")
			var standard := {"covered":false,"kind":"","public_formula":"本目标选拔标准未覆盖／未核实；不能套用JGP分站公式。"}
			if covered and not kind.is_empty() and canonical_targets.get(id,"") == str(event.get("event_family","")):
				standard = {"covered":true,"kind":kind,"public_formula":Policy.public_formula(selected.policy,kind)}
			elif (year == 2020 and id == "isu_wc2021") or (year == 2021 and id in ["isu_olympic_qualifier_nebelhorn_2021","isu_fc2022","isu_wc2022"]):
				standard = {"covered":true,"kind":Senior._key(event),"public_formula":Senior.public_standard(event)}
			standards[id] = standard
			if bool(standard.covered) and kind.is_empty(): lines.append(str(event.get("name",id))+"："+str(standard.public_formula))
	for id in roles:
		for target_id in standards:
			var standard: Dictionary = standards[target_id]
			if str(standard.get("kind","")) in ["jgp","world_junior"]: continue
			roles[id][target_id] = {"role":"unknown","label":"%s · 逐场可计入性未覆盖／未核实；须按该目标有效窗口与完整成绩核对，不能套用JGP必要场次。" % target_id}
	return {"season_id":season,"season_start_year":year,"announcements":"\n".join(lines),"event_roles":roles,"target_standards":standards,"policy_status":selected.status,"policy_content_sha256":selected.content_sha256}
