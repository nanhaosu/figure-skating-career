class_name TrainingFocusPresenter
extends RefCounted

const LABELS := {"musical_expression":"音乐表达","skating_edges":"滑行用刃","spin":"旋转","steps":"步法","execution":"比赛兑现","program_connections":"节目衔接","recovery":"找回技术","new_difficulty":"探索难度"}
const Repertoire = preload("res://src/domain/technical_repertoire.gd")
const Plan = preload("res://src/domain/training_plan.gd")

static func label(focus: Dictionary) -> String:
	var target: Dictionary = focus.get("target",{})
	var suffix := Repertoire.action_id(target) if target.get("kind") == "jump" else ("短节目" if target.get("segment") == "short" else ("自由滑" if target.get("segment") == "free" else ""))
	return "%s%s" % [LABELS.get(focus.get("kind"),"教练安排")," · "+suffix if not suffix.is_empty() else ""]

static func options(career) -> Array:
	var result: Array = [{"label":"交给教练，不另设重点","focus":{}}]
	for kind in ["musical_expression","skating_edges","spin","steps"]:
		var focus := {"id":kind,"kind":kind,"target":{}}
		result.append({"label":label(focus),"focus":focus})
	for segment in ["short","free"]:
		if career.active_programs.get(segment,{}).is_empty(): continue
		for kind in ["execution","program_connections"]:
			var focus := {"id":kind+":"+segment,"kind":kind,"target":{"segment":segment}}
			result.append({"label":label(focus),"focus":focus})
	for id in Plan.JUMP_LABELS:
		for rotations in range(1,5):
			var action := {"kind":"jump","parts":[{"jump_id":id,"rotations":rotations}]}
			var focus := {"id":"explore:"+Repertoire.action_id(action),"kind":"new_difficulty","target":action}
			result.append({"label":"%s（%d周%s）" % [label(focus),rotations,Plan.JUMP_LABELS[id]],"focus":focus})
		for tail in [{"jump_id":"toe_loop","rotations":2},{"jump_id":"toe_loop","rotations":3},{"jump_id":"loop","rotations":3}]:
			var action := {"kind":"jump","parts":[{"jump_id":id,"rotations":3},tail]}
			var focus := {"id":"explore:"+Repertoire.action_id(action),"kind":"new_difficulty","target":action}
			result.append({"label":label(focus)+"（连跳）","focus":focus})
	for entry in career.technical_repertoire.entries.values():
		if not bool(entry.get("learned_history",{}).get("ever_learned",false)): continue
		var focus := {"id":"recover:"+Repertoire.action_id(entry.action),"kind":"recovery","target":entry.action.duplicate(true)}
		result.append({"label":label(focus),"focus":focus})
	return result

static func build(career) -> Dictionary:
	var built: Dictionary = preload("res://src/simulation/coach_training_plan_service.gd").build(career,preload("res://src/domain/training_intent.gd").create("accept").intent)
	var lines: Array[String] = []
	for focus in career.training_direction.focuses: lines.append(label(focus))
	return {"summary":" / ".join(lines) if not lines.is_empty() else "完整基础课 · 教练安排", "reasons":built.get("reasons",[]),"states":built.get("focus_states",[]),"conflicts":built.get("conflicts",[]),"errors":built.errors}
