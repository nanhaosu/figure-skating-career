class_name JGPCompetitionPresenter
extends RefCounted

# Saved evidence only: opening this board cannot publish a round or reroll rivals.
static func build(career, calendar: Dictionary, target_event_id: String = "") -> Dictionary:
	var season := str(calendar.get("season_id",""))
	var saved: Dictionary = career.selection_state.get("jgp_second_start",{})
	if str(saved.get("season_id","")) != season: saved = {}
	var snapshot: Dictionary = career.season_state.get("selection_policy",{}).get("payload",{})
	var policy: Dictionary = saved.get("policy",{})
	if policy.is_empty() and str(snapshot.get("season_id","")) == season:
		policy = snapshot.get("targets",{}).get("jgp",{}).get("second_start",{})
	var active: bool = not saved.is_empty() or policy.get("mode","") == "after_first"
	var first: Dictionary = saved.get("first_assignments",{}).duplicate(true)
	var reserved: Array = saved.get("reserved_event_ids",[]).duplicate(true)
	var round: Dictionary = {}
	for published in saved.get("rounds",[]):
		if target_event_id.is_empty() or published.get("event_id") == target_event_id: round = published
	var cutoff := str(round.get("cutoff","未知"))
	if round.is_empty():
		for event in calendar.get("events",[]):
			if event.get("event_id") == target_event_id: cutoff = str(event.get("nomination_deadline",event.get("application_deadline","未知")))
	var official_entry_deadline := str(saved.get("official_entry_deadlines",{}).get(target_event_id,"未知"))
	var entry_deadline_source := str(saved.get("entry_deadline_sources",{}).get(target_event_id,"unverified"))
	if entry_deadline_source == "unverified":
		for event in calendar.get("events",[]):
			if event.get("event_id") == target_event_id and event.get("application_deadline_game_policy",false): entry_deadline_source = "game_setting"
	var pre_registered: Array = saved.get("pre_registered_ids",{}).get(target_event_id,[]).duplicate()
	if round.is_empty() and saved.get("substitution_deadlines",{}).has(target_event_id): cutoff = str(saved.substitution_deadlines[target_event_id])
	var domestic_rows: Array = career.selection_state.get("decisions",{}).get("jgp",{}).get("decision",{}).get("audit",{}).get("candidate_rows",[])
	var domestic := {}
	for candidate in domestic_rows: domestic[str(candidate.get("athlete_id",""))] = candidate
	var rows: Array = []
	for candidate in round.get("candidate_rows",[]):
		var id := str(candidate.get("athlete_id",""))
		var row: Dictionary = candidate.duplicate(true)
		row["domestic_score"] = domestic.get(id,{}).get("score",null)
		row["rank"] = rows.size()+1
		row["display_name"] = str(candidate.get("name",id))
		row["status"] = "selected" if round.get("selected_ids",[]).has(id) else ("alternate" if round.get("alternate_ids",[]).has(id) else "not_selected")
		row["published_status"] = row.status
		for replacement in career.selection_state.get("jgp_replacements",[]):
			if replacement.get("event_id") != round.get("event_id"): continue
			if replacement.get("removed_id") == id: row.status = "withdrawn"
			elif replacement.get("promoted_id") == id and career.selection_state.get("assignments",{}).get(id,[]).has(round.get("event_id")): row.status = "promoted"
		row["first_event_ids"] = first.get(id,[]).duplicate()
		row["second_event_ids"] = round.get("assignments",{}).get(id,[]).duplicate()
		rows.append(row)
	if round.is_empty():
		var pending_ids: Array = []
		for candidate in domestic_rows:
			var id := str(candidate.get("athlete_id",""))
			if (pre_registered.has(id) or first.has(id)) and not pending_ids.has(id): pending_ids.append(id)
		for id in pre_registered + first.keys():
			if not pending_ids.has(id): pending_ids.append(id)
		for id in pending_ids:
			var initial: Dictionary = domestic.get(id,{})
			var first_ids: Array = first.get(id,[]).duplicate()
			rows.append({"athlete_id":str(id),"display_name":str(initial.get("name",career.world_athletes.get(id,{}).get("name","你" if id == "player" else id))),"domestic_score":initial.get("score",null),"rank":null,"score":null,"points":null,"eligible":null,"reason_codes":["eligible_first_start_reserve"] if first_ids.is_empty() else [],"status":"pending","first_event_ids":first_ids,"second_event_ids":[]})
	var lines: Array[String] = []
	if active:
		var series: Dictionary = career.selection_state.get("jgp",{})
		var player_totals: Array = series.get("standings",[]).filter(func(row):return row.get("athlete_id") == "player")
		var expected: Array = calendar.get("events",[]).filter(func(e):return e.get("event_family") == "jgp_stage" and e.get("status") != "cancelled" and not e.get("reference_only",false)).map(func(e):return e.event_id)
		var series_complete: bool = series.get("complete",false) and not expected.is_empty() and expected.all(func(id):return series.get("events",{}).has(id))
		var player_points := int(player_totals[0].get("points",0)) if not player_totals.is_empty() else 0
		var final_label := ("已入围总决赛" if series.get("qualified_ids",[]).has("player") else "未入围总决赛") if series_complete else "系列赛尚未完整结算，总决赛资格待定"
		lines.append("你的本季JGP累计积分：%d；%s。" % [player_points,final_label])
		var threshold := str(policy.minimum_first_points) if policy.has("minimum_first_points") else "未记录"
		lines.append("游戏设定：首站后竞争第二站；首站积分门槛 %s。达标不保证派遣，仍受截止日、可用站次与名额限制。" % threshold)
		if not str(policy.get("label","")).is_empty(): lines.append(str(policy.label))
		lines.append("初次派遣仅安排首站；预留第二站："+("、".join(reserved.map(func(id):return _event_name(calendar,id))) if not reserved.is_empty() else "尚无记录"))
		var deadline_label := "姓名报名截止（游戏设定，官方日期未核实）" if entry_deadline_source == "game_setting" else "官方姓名报名截止" if entry_deadline_source == "official_archive" else "赛历姓名报名截止（官方窗口待核实）"
		lines.append("%s：%s；该站已报名名单：%s。截止后第二站人选仅在已报名名单内确认。" % [deadline_label,official_entry_deadline,"、".join(pre_registered.map(func(id):return str(career.world_athletes.get(id,{}).get("name","你" if id == "player" else id)))) if not pre_registered.is_empty() else "尚无记录"])
		lines.append("国内第二站确认截止：%s（游戏设定）；%s" % [cutoff,"本轮已公布，以下保留公布时顺序与成绩。" if not round.is_empty() else "尚未公布该站评估轮次；不按当前能力重排。"])
		for row in rows:
			var status_label: String = {"selected":"第二站已入选","alternate":"第二站候补","not_selected":"本轮未入选","pending":"第二站待评估","withdrawn":"已退出本场","promoted":"已递补入选"}.get(row.status,row.status)
			var unstarted: bool = row.get("reason_codes",[]).has("eligible_first_start_reserve") or (row.has("first_event_id") and str(row.first_event_id).is_empty())
			var result := "未首发候补 · 争取首站" if unstarted else "首站赛果待公布" if row.get("points") == null else "首站 %.2f 分 / %d 积分" % [float(row.get("score",0)),int(row.points)]
			var gap := "；国内选拔依据 %.2f 分（公告时记录）" % float(row.domestic_score) if row.get("domestic_score") != null else ""
			if not unstarted and row.get("points") != null and policy.has("minimum_first_points"): gap += "；距积分门槛还差 %d 分" % maxi(0,int(policy.minimum_first_points)-int(row.points))
			var labels := {"eligible_second_start":"首站达标，按成绩竞争第二站","eligible_first_start_reserve":"预报名合格候补，可竞争首发机会","first_result_below_standard_or_unavailable":"首站未达标准、站次已满或当前不可参赛"}
			if not row.get("reason_codes",[]).is_empty(): gap += "；本轮条件："+"、".join(row.reason_codes.map(func(code):return labels.get(code,"查看资格与派遣说明")))
			lines.append("%s%s · %s · 首站：%s · %s%s" % [("%d. " % int(row.rank)) if row.rank != null else "",row.display_name,status_label,"、".join(row.first_event_ids.map(func(id):return _event_name(calendar,id))),result,gap])
		if rows.is_empty(): lines.append("尚无已公布国内候选记录；等待首站派遣与赛果。")
	else:
		lines.append("既有游戏政策：该存档没有首站后第二站竞争公告，保留原派遣记录；不补造第二站评估。")
	return {"official_entry_deadline":official_entry_deadline,"pre_registered_ids":pre_registered,"policy_status":"after_first" if active else "legacy","rows":rows,"first_assignments":first,"reserved_event_ids":reserved,"cutoff":cutoff,"frozen":not round.is_empty(),"round":round.duplicate(true),"section":{"heading":"国内JGP第二站竞争（游戏设定）","body":"\n".join(lines)}}

static func _event_name(calendar: Dictionary, id: String) -> String:
	for event in calendar.get("events",[]):
		if event.get("event_id") == id: return str(event.get("name",id))
	return id







