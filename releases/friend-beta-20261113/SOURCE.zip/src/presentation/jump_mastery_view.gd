class_name JumpMasteryView
extends RefCounted

const JumpStageEvaluator = preload("res://src/simulation/jump_stage_evaluator.gd")

const ISSUE_LABELS := {
	"edge_unstable": "用刃不稳定",
	"wrong_edge": "疑似错刃",
	"underrotation": "疑似周数不足",
	"prerotation": "起跳预转偏多",
	"axis_unstable": "空中轴不稳定",
	"landing_unstable": "落冰不稳定",
}

static func describe(profile, body: Dictionary) -> Dictionary:
	var rotations := clampi(int(profile.unlocked_rotations), 1, 4)
	var evaluation := JumpStageEvaluator.evaluate_profile(profile, rotations, body)
	return {
		"stage": evaluation.stage_label,
		"stage_id": evaluation.stage_id,
		"gaps": evaluation.gaps,
		"success_min": evaluation.success_range.min,
		"success_max": evaluation.success_range.max,
		"issue_text": _observed_issue_text(profile.observations),
	}

static func _observed_issue_text(observations: Array) -> String:
	var issues: Array[String] = []
	for observation in observations:
		if float(observation.get("confidence", 0.0)) < 0.55:
			continue
		var key := str(observation.get("key", ""))
		var label := str(ISSUE_LABELS.get(key, "已观察到未分类技术问题"))
		if not issues.has(label):
			issues.append(label)
	return "尚未识别明确技术问题" if issues.is_empty() else "、".join(issues)
