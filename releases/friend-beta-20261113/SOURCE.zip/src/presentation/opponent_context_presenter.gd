class_name OpponentContextPresenter
extends RefCounted

# Read only the public archive indexes. Never inflate whole protocols here.
static func build(career, event: Dictionary, roster: Array) -> Array[Dictionary]:
	var meetings := {}
	var seen := {}
	var current_year := int(event.get("ruleset_season_start_year",career.clock.season_start_year()))
	var current_date := str(event.get("actual_dates",{}).get("start",event.get("start_date","")))
	var ordered: Array = career.competition_archive.duplicate()
	ordered.sort_custom(func(a,b):
		var left := str(a.get("event",{}).get("start_date",a.get("season_id","")))
		var right := str(b.get("event",{}).get("start_date",b.get("season_id","")))
		return left < right if left != right else str(a.get("event_id","")) < str(b.get("event_id","")))
	for archive in ordered:
		if bool(archive.get("world_only",false)) or archive.get("status","complete") != "complete" or archive.get("event_id") == event.get("event_id"): continue
		var season_id := str(archive.get("season_id",""))
		var year := int(season_id.get_slice("-",0))
		if year <= 0 or year > current_year: continue
		var previous_end := str(archive.get("event",{}).get("actual_dates",{}).get("end",archive.get("event",{}).get("end_date","")))
		if current_date.length() == 10 and previous_end.length() == 10 and previous_end >= current_date: continue
		var event_id := str(archive.get("event_id",""))
		if event_id.is_empty(): continue
		var archive_key := season_id+":"+event_id
		if seen.has(archive_key): continue
		var standings: Array = archive.get("final_standings",[])
		var player_rank := 0
		for index in standings.size():
			if standings[index].get("athlete_id") == "player": player_rank = int(standings[index].get("rank",index+1)); break
		if player_rank <= 0: continue
		seen[archive_key] = true
		for index in standings.size():
			var row: Dictionary = standings[index]
			var id := str(row.get("athlete_id",""))
			if id.is_empty() or id == "player": continue
			var earlier: Dictionary = meetings.get(id,{})
			var count := int(earlier.get("meetings",0))+1
			var recent_count := int(earlier.get("recent_meetings",0)) + (1 if year >= current_year-1 else 0)
			meetings[id] = {"event_id":event_id,"event_name":str(archive.get("event_name",archive.get("event",{}).get("name","此前比赛"))),"season_id":season_id,"meetings":count,"recent_meetings":recent_count,"player_rank":player_rank,"opponent_rank":int(row.get("rank",index+1))}
	var rows: Array[Dictionary] = []
	var roster_ids := {}
	var distances := {}
	var player_best: float = preload("res://src/simulation/focus_skater_service.gd").best_total(career.record_book)
	for record in roster:
		if not record is Dictionary: continue
		var id := str(record.get("athlete_id",""))
		if id.is_empty() or id == "player" or roster_ids.has(id): continue
		roster_ids[id] = true
		var rival_best: float = preload("res://src/simulation/focus_skater_service.gd").best_total(career.world_athletes.get(id,{}).get("record_book",{}))
		distances[id] = absf(player_best-rival_best) if player_best > 0 and rival_best > 0 else INF
		var previous: Dictionary = meetings.get(id,{}).duplicate(true)
		var reason := "本场参赛选手，尚无可核实的交手记录。"
		var refs: Array = []
		if not previous.is_empty():
			reason = "曾在%s交手：你第%d名，她第%d名。" % [previous.event_name,previous.player_rank,previous.opponent_rank]
			if previous.meetings > 1 or previous.recent_meetings == 0:
				reason += "累计交手%d次，上次在%s赛季。" % [previous.meetings,previous.season_id]
			refs.append("competition:"+str(previous.event_id))
		rows.append({"athlete_id":id,"display_name":str(record.get("name",record.get("display_name","参赛选手"))),"reason":reason,"previous_meeting":previous,"evidence_refs":refs})
	rows.sort_custom(func(a,b):
		var a_meetings := int(a.previous_meeting.get("recent_meetings",0))
		var b_meetings := int(b.previous_meeting.get("recent_meetings",0))
		if a_meetings != b_meetings: return a_meetings > b_meetings
		var a_total := int(a.previous_meeting.get("meetings",0))
		var b_total := int(b.previous_meeting.get("meetings",0))
		if a_total != b_total: return a_total > b_total
		if distances[a.athlete_id] != distances[b.athlete_id]: return distances[a.athlete_id] < distances[b.athlete_id]
		return str(a.athlete_id) < str(b.athlete_id))
	return rows.slice(0,3)
