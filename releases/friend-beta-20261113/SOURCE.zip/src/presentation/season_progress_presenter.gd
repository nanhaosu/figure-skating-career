class_name SeasonProgressPresenter
extends RefCounted

const Labels = preload("res://src/presentation/training_focus_presenter.gd")
const Repertoire = preload("res://src/domain/technical_repertoire.gd")

# A read-only view of known achievements, not a second skill evaluator.
static func build(career, season_id: String) -> Dictionary:
	var rows: Array = []
	var highlights: Array = []
	var refs: Array = []
	for focus in career.training_direction.get("focuses",[]):
		var row := {"id":str(focus.id),"label":Labels.label(focus),"stage":"preparation","progress":"正在建立相关基础，暂无已记录的目标动作完成。","bottleneck":"尚无目标动作完成证据。","suggestion":"可沿用现有安排，也可以调整培养重点。","evidence_refs":[]}
		if focus.get("target",{}).get("kind") != "jump":
			row.progress = "当前方向：%s。具体提升以本阶段实际训练变化为准。" % row.label
			row.bottleneck = "滑表、旋转与步法不以解锁周数衡量。"
			rows.append(row)
			continue
		var action_id := Repertoire.action_id(focus.target)
		var item: Dictionary = career.technical_repertoire.entries.get(action_id,{})
		var contexts: Dictionary = item.get("learned_history",{}).get("first_success_contexts",{}).duplicate(true)
		# Older windows can support known execution, but never prove a first-ever
		# achievement. Do not label them as new milestones.
		for evidence in item.get("evidence",[]):
			if int(evidence.get("successes",0)) <= 0: continue
			var context := _context(str(evidence.get("context","")))
			if context.is_empty() or contexts.has(context): continue
			contexts[context] = {"batch_id":str(evidence.batch_id),"clock":evidence.get("clock",{}),"observed_only":true}
		var chosen := ""
		for context in ["competition","program_late","program","practice"]:
			if contexts.has(context): chosen = context; break
		if not chosen.is_empty():
			row.stage = {"practice":"practice","program":"program_transfer","program_late":"program_transfer","competition":"competition_confirmed"}[chosen]
			row.progress = "%s：%s" % [action_id,{"practice":"已有训练完成记录，还不代表整套或比赛稳定可用。","program":"已有节目练习中的完成记录，仍需比赛检验。","program_late":"已有节目后段练习中的完成记录，仍需比赛检验。","competition":"已有比赛完成记录；一次兑现不保证以后稳定。"}[chosen]]
			row.bottleneck = "接下来继续积累当前状态下的执行证据。" if chosen == "competition" else "训练完成与比赛兑现仍是两回事。"
			var evidence_ref := "technical:%s:%s:%s" % [action_id,chosen,str(contexts[chosen].get("batch_id",""))]
			row.evidence_refs.append(evidence_ref)
			refs.append(evidence_ref)
		elif bool(item.get("legacy_unverified",false)):
			row.stage = "unknown"
			row.progress = "%s：旧存档保留了储备，但没有足够上下文还原完成经历。" % action_id
			row.bottleneck = "历史情境不完整，未补造训练或比赛完成。"
		rows.append(row)
	# Season memories survive changing the current focus. Only durable first
	# contexts prove a milestone; recent legacy windows are not backfilled.
	for action_id in career.technical_repertoire.entries:
		var contexts: Dictionary = career.technical_repertoire.entries[action_id].get("learned_history",{}).get("first_success_contexts",{})
		for context in contexts:
			var clock: Dictionary = contexts[context].get("clock",{})
			var year := int(clock.get("year",0))-(1 if int(clock.get("quarter",3)) < 3 else 0)
			if "%d-%02d" % [year,(year+1)%100] != season_id: continue
			var evidence_ref := "technical:%s:%s:%s" % [action_id,context,str(contexts[context].get("batch_id",""))]
			highlights.append({"action_id":action_id,"stage":{"practice":"practice","program":"program_transfer","program_late":"program_transfer","competition":"competition_confirmed"}.get(context,"unknown"),"evidence_refs":[evidence_ref]})
			if not refs.has(evidence_ref): refs.append(evidence_ref)
	return {"focuses":rows,"highlights":highlights,"evidence_refs":refs}

static func _context(value: String) -> String:
	return Repertoire.first_context_type(value)
