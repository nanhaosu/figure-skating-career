class_name ProgramUpgradePresenter
extends RefCounted

const Program = preload("res://src/domain/skating_program.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Repertoire = preload("res://src/domain/technical_repertoire.gd")
const Scoring = preload("res://src/content/formal_scoring_repository.gd")
const CODES := {"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz","axel":"A"}

static func build(career, proposal: Dictionary) -> Dictionary:
	var segment := str(proposal.get("segment",""))
	var original = Program.from_dict(career.active_programs.get(segment,{}))
	var edited = Program.from_dict(proposal.get("programs",{}).get(segment,{}))
	if original == null or edited == null: return {"ok":false,"text":"缺少可比较的节目版本"}
	var revised := Draft.save_draft(original,edited)
	if not revised.errors.is_empty(): return {"ok":false,"text":"；".join(revised.errors)}
	var loaded := Scoring.load_catalog(preload("res://src/content/season_bundle_repository.gd").season_year(career),"women_singles")
	if not loaded.errors.is_empty(): return {"ok":false,"text":"当前赛季基础分目录不可用"}
	var delta := 0.0
	var lines: Array[String] = []
	for index in mini(original.elements.size(),edited.elements.size()):
		var old = original.elements[index]
		var next = edited.elements[index]
		if old.to_dict() == next.to_dict() or old.kind != "jump" or next.kind != "jump": continue
		var before := _action(old)
		var after := _action(next)
		delta += _value(after,loaded.catalog)-_value(before,loaded.catalog)
		lines.append("第%d个动作：%s → %s" % [index+1,Repertoire.action_id(before),Repertoire.action_id(after)])
		if after.parts.size() == 1:
			var part: Dictionary = after.parts[0]
			var evidence: Dictionary = career.athlete.jumps[part.jump_id].attempt_evidence[["","single","double","triple","quad"][int(part.rotations)]]
			lines.append("已有动作记录：%d次尝试，%d次成功，其中%d次干净完成。" % [int(evidence.get("attempts",0)),int(evidence.get("successes",0)),int(evidence.get("clean_successes",0))])
	var load_before := preload("res://src/simulation/program_load_estimator.gd").estimate(original,career.athlete,career.condition_state)
	var load_after := preload("res://src/simulation/program_load_estimator.gd").estimate(revised.program,career.athlete,career.condition_state)
	lines.append("动作基础分合计变化：%+.2f（未含后半段加成、GOE、重复判定或比赛失误，不是预计总分增加）。" % delta)
	lines.append("整套熟悉度：%.2f → %.2f；改动动作的分槽熟悉度也按实际修订规则重新计算。" % [original.whole_run_familiarity,revised.program.whole_run_familiarity])
	lines.append("游戏负荷估计：%.2f → %.2f；训练可用不等于比赛稳定。" % [load_before.total_load,load_after.total_load])
	return {"ok":true,"base_value_delta":snappedf(delta,0.01),"familiarity_before":original.whole_run_familiarity,"familiarity_after":revised.program.whole_run_familiarity,"load_before":load_before.total_load,"load_after":load_after.total_load,"text":"\n".join(lines)}

static func _action(element) -> Dictionary:
	return {"kind":"jump","parts":[{"jump_id":element.jump_id,"rotations":element.rotations}]+element.combination_parts}

static func _value(action: Dictionary,catalog: Dictionary) -> float:
	var value := 0.0
	for part in action.parts: value += Scoring.element_value(catalog,str(int(part.rotations))+str(CODES.get(part.jump_id,"")))
	return value
