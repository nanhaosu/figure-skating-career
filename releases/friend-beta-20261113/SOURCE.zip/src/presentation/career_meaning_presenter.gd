class_name CareerMeaningPresenter
extends RefCounted

static func build(career, context: Dictionary = {}) -> Dictionary:
	var view := {"jgp_stage":"none","axel_stage":"none","home":{},"training":{},"pre_event":{},"evidence_refs":[]}
	if career == null: return view
	var milestones: Dictionary = career.experience_state.get("milestones",{})
	var event: Dictionary = context.get("event",{})
	var id := str(event.get("event_id",""))
	var entries: Dictionary = career.season_state.get("entry_plan",{}).get("entries",{})
	if id.is_empty():
		for entry_id in entries:
			if _jgp_id(str(entry_id)) and _upcoming(career,str(entry_id),entries[entry_id]):
				id = str(entry_id); break
	var is_jgp: bool = event.get("event_family") == "jgp_stage" if not event.is_empty() else _jgp_id(id)
	var season_age := int(career.clock.year)-(1 if int(career.clock.quarter) < 3 else 0)-int(career.athlete.birth_year)
	var previous_jgp: bool = milestones.has("first_jgp_start") or _has_jgp_history(career)
	var known_first: bool = not previous_jgp and str(career.experience_state.get("milestone_history",{}).get("status","unexamined")) in ["native","complete"]
	if milestones.has("first_jgp_start"):
		view.jgp_stage = "complete" if milestones.has("first_jgp_complete") else "debut"
	elif is_jgp and season_age >= 13 and season_age <= 18:
		var entry: Dictionary = entries.get(id,{})
		var stage := "none"
		var upcoming := _upcoming(career,id,entry)
		if upcoming and entry.get("status") == "confirmed": stage = "entered"
		elif upcoming and Array(career.selection_state.get("assignments",{}).get("player",[])).has(id): stage = "assigned"
		elif upcoming:
			for application in career.selection_state.get("applications",{}).values():
				if application.get("event_id") == id and application.get("route_id") == "request_assignment": stage = "applied"
			if stage == "none" and Array(entry.get("available_adjustment_ids",[])).has("request_assignment") and bool(entry.get("eligibility_snapshot",{}).get("eligible",false)): stage = "candidate"
		view.jgp_stage = stage
		var titles := {"candidate":"争取第一次JGP机会","applied":"已提交首次JGP派遣申请","assigned":"首次JGP派遣已确认","entered":"下一站：你的首场JGP"}
		if not known_first: titles = {"candidate":"争取本次JGP机会","applied":"本次JGP派遣申请已提交","assigned":"本次JGP派遣已确认","entered":"下一站：JGP"}
		var texts := {"candidate":"国内成绩帮助你争取派遣，不是国际名次的保证。","applied":"申请还不是派遣；等待公开选拔结果，期间仍可训练。","assigned":"你获得了代表国家出场的机会；报名与节目准备仍按赛历办理。","entered":"报名已确认。下一步把平时准备带到国际青年赛场。"}
		if titles.has(stage): view.home = _block("jgp:"+id,titles[stage],[texts[stage]],"申请、派遣、实际出场与完成本站分别记录；出场不自动意味着争牌。",["entry:"+id])
	var interested := false
	var programme_axel := false
	for focus in career.training_direction.get("focuses",[]): interested = interested or _has_axel(focus.get("target",{}))
	for program in career.active_programs.values():
		for element in program.get("elements",[]): programme_axel = programme_axel or _has_axel(element)
	interested = interested or programme_axel
	if interested:
		var contexts: Dictionary = career.technical_repertoire.entries.get("3A",{}).get("learned_history",{}).get("first_success_contexts",{})
		var stage := "preparation"
		var text := "3A实际转三周半。本期先按你的基础推进前置准备，不把目标当成已经会。"
		var refs: Array = ["training_direction"]
		if contexts.has("practice"):
			stage = "practice"; text = "训练中已经留下3A完成记录；它还需要在整套节目和比赛里接受检验。"; refs = ["technical:3A:practice:"+str(contexts.practice.get("batch_id",""))]
		if contexts.has("program") or contexts.has("program_late"):
			stage = "program_transfer"; text = "3A已经进入节目练习。下次要检验的，是压力下的实际执行，不是再解锁一次。"; refs = ["technical:3A:program"]
		if milestones.has("first_formal_3a"):
			stage = "competition_confirmed"; text = "正式比赛已有有效足周3A记录；接下来练的是再次兑现，不是保证永远稳定。"; refs = milestones.first_formal_3a.evidence_refs
		view.axel_stage = stage
		view.training = _block("axel:"+stage,"把3A带到赛场",[text],"训练完成、节目练习和正式比赛最终认定是三个阶段。未练3A的路线不需要追赶这个目标。",refs)
	if not event.is_empty() and (is_jgp or interested):
		var lines: Array = []
		if is_jgp:
			lines.append("这是你的JGP首秀：先看这套节目在本场阵容中能站到哪里。" if known_first else ("你已经有JGP出场经历；这次与此前的自己和本场对手比较。" if previous_jgp else "这次走上JGP赛场，先看自己的准备在本场阵容中能站到哪里。"))
			if programme_axel: lines[0] = "首场JGP，也将检验节目中的3A；落冰后仍要等最终技术认定。" if known_first else "这次JGP将检验节目中的3A；落冰后仍要等最终技术认定。"
			lines.append(_outlook(career,event,context.get("roster",[])))
		elif interested:
			lines.append("如果按已确认节目尝试3A，最终是否兑现要等实际执行和技术组认定。")
		view.pre_event = _block("pre:"+id,"这一场，值得期待什么",lines,"只使用公开阵容和可比的同规则青年组历史成绩，不读取本场未来执行。",["event:"+id])
	for field in ["home","training","pre_event"]:
		if not view[field].is_empty(): view.evidence_refs.append_array(view[field].evidence_refs)
	return view

static func _jgp_id(id: String) -> bool:
	return id.begins_with("isu_jgp_") and not id.contains("_final_")

static func _upcoming(career, id: String, entry: Dictionary) -> bool:
	if entry.is_empty() or str(entry.get("status","")) in ["declined","withdrawn","completed","blocked"]: return false
	if str(career.season_state.get("entry_plan",{}).get("season_id","")) != career.clock.season_id(): return false
	if id.get_slice("_",id.get_slice_count("_")-1) != str(career.clock.season_start_year()): return false
	for archive in career.competition_archive:
		if archive.get("event_id") == id and _player_skated(archive): return false
	return true

static func _player_skated(archive: Dictionary) -> bool:
	if bool(archive.get("world_only",false)): return false
	if not archive.get("player_result",{}).is_empty(): return true
	for segment in ["short","free"]:
		var row: Dictionary = archive.get(segment+"_results",{}).get("player",{})
		if not row.get("performance",{}).get("elements",[]).is_empty() or float(row.get("score",row.get("protocol",{})).get("total",0)) > 0: return true
	return false

static func _has_jgp_history(career) -> bool:
	# Compact archive score indexes are enough to establish prior participation.
	# Never inflate historical protocols just to render a page.
	for archive in career.competition_archive:
		if (archive.get("event",{}).get("event_family") == "jgp_stage" or _jgp_id(str(archive.get("event_id","")))) and _player_skated(archive): return true
	return false

static func _has_axel(action: Dictionary) -> bool:
	if action.get("kind") != "jump": return false
	if action.get("jump_id") == "axel" and int(action.get("rotations",0)) == 3: return true
	for part in action.get("parts",[]):
		if part.get("jump_id") == "axel" and int(part.get("rotations",0)) == 3: return true
	for part in action.get("combination_parts",[]):
		if part.get("jump_id") == "axel" and int(part.get("rotations",0)) == 3: return true
	return false

static func _outlook(career, event: Dictionary, roster: Array) -> String:
	# Compare only already public junior results under the identical scoring era.
	# General personal bests can mix senior/junior layouts, so are not a proxy.
	var era := str(event.get("scoring_era_id",""))
	if era.is_empty() or roster.is_empty(): return "与本场对手的可比成绩不足，具体位置尚难判断；不预设中游或领奖台。"
	var best := {}
	for archive in career.competition_archive:
		var past_event: Dictionary = archive.get("event",{})
		var junior: bool = past_event.get("level") == "junior" or past_event.get("level_options",[]) == ["junior"]
		if archive.get("scoring_era_id") != era or not junior: continue
		if archive.get("status") != "complete" or past_event.get("scope") != "international" or archive.get("record_eligibility",past_event.get("record_eligibility","")) != "isu_recognized": continue
		var date := str(past_event.get("start_date",""))
		var current_date := str(event.get("start_date",""))
		if date.length() != 10 or current_date.length() != 10 or date >= current_date: continue
		for row in archive.get("final_standings",[]):
			var id := str(row.get("athlete_id",""))
			best[id] = maxf(float(best.get(id,0)),float(row.get("total_score",0)))
	if float(best.get("player",0)) <= 0: return "尚无足够可比的国际成绩；国内名次不能直接换算成本场名次。"
	var stronger := 0; var known := 0
	for row in roster:
		var id := str(row.get("athlete_id",""))
		if id == "player" or not best.has(id): continue
		known += 1
		if float(best[id]) > float(best.player): stronger += 1
	if known < maxi(1,roster.size()-1): return "本场部分对手缺少可比成绩，位置仍有不确定性；先看实际发挥。"
	return "可比历史成绩中，你已接近本场前列；把两套节目兑现，才有争牌的依据。" if stronger < 3 else "本场多位对手已有更高的可比成绩；先争取把自己的节目完整兑现。"

static func _block(id: String, title: String, lines: Array, detail: String, refs: Array) -> Dictionary:
	return {"id":id,"title":title,"lines":lines.slice(0,2),"detail":detail,"evidence_refs":refs.duplicate()}
