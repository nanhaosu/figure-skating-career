class_name TrainingPeriodPresenter
extends RefCounted

const CareerState = preload("res://src/domain/career_state.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")
const JUMP_LABELS := {"toe_loop":"后外点冰跳","salchow":"后内结环跳","loop":"后外结环跳","flip":"后内点冰跳","lutz":"勾手跳","axel":"阿克塞尔跳"}
const ROTATIONS := {1:"单周",2:"双周",3:"三周",4:"四周"}
const TARGET_LABELS := {"deep_edge":"滑行深刃","single_jumps":"跳跃基础","rotation":"旋转能力","landing":"落冰控制","acute_fatigue":"即时疲劳","cumulative_fatigue":"累积疲劳","ankle_load":"踝部负荷","impact_load":"冲击负荷","recovery_capacity":"恢复能力","growth_trend":"身体成长"}

static func build(before: CareerState, result: Dictionary) -> Dictionary:
	var after: CareerState = result.get("career")
	var plan_lines: Array[Dictionary] = []
	var happened: Array[Dictionary] = []
	var changes: Array[Dictionary] = []
	var next_step: Array[Dictionary] = []
	var jump_facts: Array[Dictionary] = []
	var first_successes: Array[String] = []
	var ordinary_change_count := 0
	happened.append_array(preload("res://src/presentation/coach_training_presenter.gd").review(result.get("facts",[])))
	if after != null:
		var plan = TrainingPlan.from_dict(after.last_generated_plan) if not after.last_generated_plan.is_empty() else null
		if plan != null:
			plan_lines.append(_line("滑行、六类跳跃、旋转、体能与恢复同步安排。", ["career.last_generated_plan"]))
	for fact in result.get("facts", []):
		var kind := str(fact.get("kind", ""))
		if kind == "training_stage": changes.append(_line("已执行的%d周训练已经保存；季度尚未结束，剩余课程待处理当前事件后继续。" % int(fact.get("weeks_elapsed",0)),["training_period_state.stage_checkpoint"]))
		elif kind == "jump_attempts": jump_facts.append(fact)
		elif kind == "focus_review": happened.append(_line(str(fact.get("text","")),Array(fact.get("evidence_refs",[]))))
		elif kind == "jump_milestone" and str(fact.get("signature","")).begins_with("first_jump_success"):
			first_successes.append("%s%s" % [JUMP_LABELS.get(str(fact.get("jump_id","")),"跳跃"),ROTATIONS.get(int(fact.get("rotations",1)),"")])
		elif kind == "coach_plan": happened.append(_line("教练已执行本期完整课程。",Array(fact.get("evidence_refs",[]))))
		elif kind == "period_progress" and int(result.get("elapsed_weeks",0)) > 0: happened.append(_line("本次继续训练%d周。" % int(result.elapsed_weeks),Array(fact.get("evidence_refs",[]))))
		elif kind == "state_change":
			var target := str(fact.get("target",""))
			var physical_change: bool = target in ["acute_fatigue","cumulative_fatigue","ankle_load","impact_load"]
			# A long technical curriculum must not hide its physical costs or recovery.
			if physical_change or ordinary_change_count < 3:
				var change := _line("%s变化%+.2f。" % [_target_label(target),float(fact.get("delta",0.0))],Array(fact.get("evidence_refs",[])))
				change.target = target
				changes.append(change)
				if not physical_change: ordinary_change_count += 1
		elif kind == "clock_advanced" and after != null: changes.append(_line("现已进入%d年第%d季度。" % [after.clock.year,after.clock.quarter],Array(fact.get("evidence_refs",[]))))
	if not first_successes.is_empty(): happened.push_front(_line("首次完成%s。下一步继续练稳。" % "、".join(first_successes),["history.jump_milestone"]))
	if jump_facts.size()>2:
		var attempts := 0
		var successes := 0
		var families: Dictionary = {}
		for fact in jump_facts:
			families[str(fact.get("jump_id",""))] = true
			attempts += int(fact.get("attempts",0))
			successes += int(fact.get("successes",0))
		happened.append(_line("%d类跳跃共尝试%d次，其中%d次成功。" % [families.size(),attempts,successes],["history.jump_attempt_batch"]))
		var actions: Dictionary = {}
		for fact in jump_facts:
			var key := "%s:%d" % [str(fact.get("jump_id","")),int(fact.get("rotations",1))]
			if not actions.has(key): actions[key] = {"jump_id":fact.get("jump_id",""),"rotations":fact.get("rotations",1),"attempts":0,"successes":0}
			actions[key].attempts += int(fact.get("attempts",0))
			actions[key].successes += int(fact.get("successes",0))
		var lines: Array[String] = []
		for action in actions.values():
			lines.append("%s%s %d/%d" % [JUMP_LABELS.get(str(action.jump_id),"跳跃"),ROTATIONS.get(int(action.rotations),""),int(action.successes),int(action.attempts)])
		happened.append(_line("各动作成功/尝试：%s。" % "；".join(lines),["history.jump_attempt_batch"]))
	else:
		for fact in jump_facts:
			happened.append(_line("%s%s：尝试%d次，成功%d次。" % [JUMP_LABELS.get(str(fact.get("jump_id","")),"跳跃"),ROTATIONS.get(int(fact.get("rotations",1)),""),int(fact.get("attempts",0)),int(fact.get("successes",0))],Array(fact.get("evidence_refs",[]))))
	if happened.is_empty(): happened.append(_line("本次推进在需要你决定的事情前停下，没有虚构训练结果。", ["result.stop_reason", "result.pending_action"]))
	if changes.is_empty(): changes.append(_line("本次完整训练已结算，结果已经保存；可展开查看记录。" if str(result.get("stop_reason","")) == "quarter_complete" else "尚未结算完整训练期，运动员状态和季度时钟没有被提前改写。", ["result.stop_reason", "career.training_period_state", "career.clock"]))
	var reason := str(result.get("stop_reason", ""))
	if reason == "quarter_complete": next_step.append(_line("季度已经结算，可以阅读事实总结后再决定下一期态度。", ["result.stop_reason", "career.clock"]))
	elif reason == "pending_action": next_step.append(_line("先处理当前事件，再从同一训练进度继续。", ["result.pending_action", "career.training_period_state"]))
	else: next_step.append(_line("训练期尚未结束，可继续推进，不需要逐周重复操作。", ["result.elapsed_weeks", "career.training_period_state"]))
	if plan_lines.is_empty(): plan_lines.append(_line("本次已执行训练，记录未附完整课表。" if int(result.get("elapsed_weeks",0)) > 0 else "计划尚未开始执行，当前没有可以声称完成的训练。", ["result.stop_reason","result.elapsed_weeks"]))
	if after != null:
		var meaning := preload("res://src/presentation/career_meaning_presenter.gd").build(after)
		if not meaning.training.is_empty():
			next_step = [_line(" ".join(meaning.training.lines),meaning.training.evidence_refs)]
	return {"plan":plan_lines, "happened":happened, "changes":changes, "next_step":next_step}

static func _line(text: String, refs: Array) -> Dictionary:
	return {"text":text, "evidence_refs":refs.duplicate()}

static func _target_label(target: String) -> String:
	var parts := target.split(".")
	if parts.size()==3 and JUMP_LABELS.has(parts[0]) and parts[2]=="proficiency":
		var rotation_names := {"single":"单周","double":"双周","triple":"三周","quad":"四周"}
		return str(JUMP_LABELS[parts[0]]) + str(rotation_names.get(parts[1],"")) + "熟练度"
	return str(TARGET_LABELS.get(target,"训练指标"))
