class_name SeasonReflectionPresenter
extends RefCounted

static func build(career, season_id: String) -> Dictionary:
	var expectation := {}
	var relationships: Array = []
	var competition: Array = []
	var refs: Array = []
	var seen := {}
	var saved_wish: Dictionary = career.experience_state.get("personal_expectations",{}).get(season_id,{})
	if not saved_wish.is_empty():
		expectation = {"choice_id":saved_wish.choice_id,"text":saved_wish.text,"evidence_refs":[saved_wish.source_id]}
		refs.append(saved_wish.source_id)
	var memory_ids := {}
	for memory in career.experience_state.get("relationship_memories",[]):
		if _season(memory.get("clock",{})) != season_id: continue
		memory_ids[memory.event_id] = true
		relationships.append({"text":memory.summary,"evidence_refs":[memory.event_id]})
		refs.append(memory.event_id)
	for record in career.event_ledger:
		if _season(record.get("clock",{})) != season_id: continue
		if record.get("kind") == "offseason_choice":
			var id := str(record.get("id",""))
			if id.ends_with(":2") and expectation.is_empty():
				expectation = {"choice_id":str(record.get("choice_id","")),"text":str(record.get("response","")),"evidence_refs":[id]}
			elif not id.ends_with(":2") and not memory_ids.has(id):
				relationships.append({"text":str(record.get("response","")),"evidence_refs":[id]})
			refs.append(id)
	for archive in career.competition_archive:
		if archive.get("season_id") != season_id or bool(archive.get("world_only",false)): continue
		var id := str(archive.get("event_id",""))
		if id.is_empty() or seen.has(id): continue
		var result := {}
		for index in archive.get("final_standings",[]).size():
			var row: Dictionary = archive.final_standings[index]
			if row.get("athlete_id") == "player":
				result = {"event_id":id,"name":str(archive.get("event_name",archive.get("event",{}).get("name","本季比赛"))),"rank":int(row.get("rank",index+1)),"total_score":float(row.get("total_score",0)),"evidence_refs":["competition:"+id]}
				break
		if result.is_empty(): continue
		seen[id] = true
		competition.append(result)
		refs.append("competition:"+id)
	var progress: Dictionary = preload("res://src/presentation/season_progress_presenter.gd").build(career,season_id)
	refs.append_array(progress.evidence_refs)
	return {"expectation":expectation,"progress":progress.highlights,"competition":competition,"relationships":relationships.slice(-3),"next_options":[{"id":"review_programmes","label":"看看现有节目"},{"id":"review_focuses","label":"想想下季重点"}],"evidence_refs":refs}

static func _season(clock: Dictionary) -> String:
	if not clock.has("year") or not clock.has("quarter"): return ""
	var year := int(clock.year)-(1 if int(clock.quarter) < 3 else 0)
	return "%d-%02d" % [year,(year+1)%100]
