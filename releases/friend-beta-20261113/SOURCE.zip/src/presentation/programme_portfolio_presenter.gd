class_name ProgrammePortfolioPresenter
extends RefCounted

const Codec = preload("res://src/persistence/competition_archive_codec.gd")

static func build(archives: Array) -> Array[Dictionary]:
	var versions := {}
	for entry in archives:
		if entry.get("status") != "complete" or entry.get("world_only",false): continue
		var event_id := str(entry.get("event_id",""))
		if event_id.is_empty(): continue
		if not entry.get("short_results",{}).has("player") and not entry.get("free_results",{}).has("player"): continue
		var archive: Dictionary = Codec.expand(entry) if entry.has("packed_archive") else entry
		for segment in ["short","free"]:
			var record: Dictionary = archive.get(segment+"_results",{}).get("player",{})
			var programme: Dictionary = record.get("snapshot",{}).get("program",{})
			var programme_id := str(programme.get("program_id",""))
			var revision = programme.get("revision")
			var score = record.get("score",{}).get("total")
			if programme_id.is_empty() or not (revision is int or revision is float): continue
			if not is_finite(float(revision)) or revision < 1 or revision != int(revision): continue
			if not (score is int or score is float) or not is_finite(float(score)): continue
			var key := JSON.stringify([segment,programme_id,int(revision)])
			var previous: Dictionary = versions.get(key,{})
			if not previous.is_empty() and float(previous.score) >= float(score): continue
			versions[key] = {
				"segment":segment,"program_id":programme_id,"revision":int(revision),
				"title":str(programme.get("music",{}).get("title","")).strip_edges(),
				"event_id":event_id,"event_name":str(entry.get("event_name",entry.get("event",{}).get("name",event_id))),
				"season_id":str(entry.get("season_id","")),"score":float(score),
			}
	var rows: Array[Dictionary] = []
	rows.assign(versions.values())
	rows.sort_custom(func(a,b):return a.season_id > b.season_id if a.season_id != b.season_id else a.score > b.score)
	return rows
