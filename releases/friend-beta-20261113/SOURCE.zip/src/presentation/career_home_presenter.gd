class_name CareerHomePresenter
extends RefCounted

const Guidance = preload("res://src/app/player_guidance_service.gd")
const NAVIGATION := [
	{"id":"home","label":"主页"},
	{"id":"training","label":"训练"},
	{"id":"programs","label":"节目"},
	{"id":"season","label":"赛季"},
	{"id":"records","label":"履历"},
]
const FACT_TARGET_LABELS := {
	"acute_fatigue":"即时疲劳",
	"cumulative_fatigue":"累积疲劳",
	"ankle_load":"踝部负荷",
	"impact_load":"跳跃冲击负荷",
	"confidence":"比赛信心",
	"coach_trust":"教练信任",
}

static func build(career) -> Dictionary:
	if career == null:
		return {
			"athlete_name":"", "date_label":"", "stage_title":"等待建立生涯",
			"career_goal":"", "current_event":_event("empty","尚未开始","创建选手后，这里会显示眼前正在发生的事。",["career:new"]),
			"next_event":{}, "changed_states":[], "recent_facts":[],
			"primary_action":{"id":"create_career","label":"创建新生涯","detail":"从选手的成长经历开始。","evidence_refs":["career:new"]},
			"navigation":NAVIGATION.duplicate(true),
		}
	var guidance: Dictionary = Guidance.build(career)
	var action: Dictionary = Dictionary(guidance.get("next_action",{})).duplicate(true)
	var current := _current_event(career,action)
	var meaning := preload("res://src/presentation/career_meaning_presenter.gd").build(career)
	if not meaning.home.is_empty() and career.competition_state.is_empty() and current.kind == "preparation":
		current = _event("preparation",meaning.home.title," ".join(meaning.home.lines),meaning.home.evidence_refs)
	action.evidence_refs = Array(current.evidence_refs).duplicate()
	return {
		"athlete_name":str(career.athlete.display_name),
		"date_label":"%d 年 · %d 岁" % [int(career.clock.year),int(career.clock.year)-int(career.athlete.birth_year)],
		"stage_title":str(guidance.get("stage_title","")),
		"career_goal":str(guidance.get("goal","")),
		"current_event":current,
		"next_event":_next_event(career),
		"changed_states":_changed_states(career,guidance),
		"recent_facts":_recent_facts(career),
		"primary_action":action,
		"navigation":NAVIGATION.duplicate(true),
	}

static func _current_event(career, action: Dictionary) -> Dictionary:
	if not career.competition_state.is_empty():
		var status := str(career.competition_state.get("status",""))
		var kind := "result" if status == "complete" else "competition"
		var title := "比赛结果已经确认" if kind == "result" else "比赛正在进行"
		return _event(kind,title,str(action.get("detail","继续当前比赛。")),[_competition_ref(career.competition_state)])
	if career.clock.year == 2022 and career.clock.quarter == 1 and not career.competition_archive.any(func(record):return record.get("event_id") == "isu_owg2022" and record.get("status") == "complete" and not record.get("world_only",false)):
		var trials: Dictionary = career.beijing_trial_series
		var decision: Dictionary = career.olympic_quota_state.dispatch if not career.olympic_quota_state.dispatch.is_empty() else trials.finalization
		if trials.status == "finalized" and decision.get("status") == "confirmed":
			var title := "北京选拔：本次未入选"
			var detail := "五场取最好四场的实际成绩已保留；国内名次不等于奥运个人资格。训练和后续赛事继续。"
			if decision.get("selected_ids",[]).has("player"):
				title = "你已入选北京冬奥"
				detail = "中国本届可用%d席；你的选拔成绩、成年国际资格和身体条件已通过核验，奥运报名已接通。接下来按教练安排备赛。" % int(decision.get("places",0))
			elif decision.get("alternate_ids",[]).has("player"):
				title = "北京选拔：你进入候补名单"
				detail = "本次尚未占用正式席位；最终派遣名单和你的五场实际成绩不会被改写。保持训练，候补不等于已经入选。"
			elif career.selection_state.applications.has("isu_owg2022:withdraw"):
				title = "你已退出北京冬奥参赛"
				detail = "原选拔成绩和最初入选记录仍保留。协会按已公布候补顺序另行核验递补，不会把这次退赛改写成选拔失利；你的恢复和生涯继续。"
			return _event("selection",title,detail,["beijing2022:dispatch:"+str(decision.get("decided_on",""))])
		for record in career.event_ledger:
			if record.get("kind") == "beijing_dispatch_checked" and record.get("status") == "pending":
				return _event("selection","北京派遣仍待核验","五场成绩已保留，但国家名额或个人资格的来源尚不能确认。未知不算落选，也不凭空发放资格；仍可继续训练。",["beijing2022:dispatch:pending"])
	var invitation := str(career.internal_invitation_state.get("status","not_ready"))
	if invitation in ["pending","accepted"]:
		var event_id := str(career.internal_invitation_state.get("event_id","first_internal"))
		return _event("invitation","第一次完整上场机会","教练已经把内部教学赛摆到你面前。先看规则，再决定是否参加。",["invitation:%s" % event_id])
	if int(career.clock.year) >= 2018:
		var upcoming := _next_event(career)
		var title := "准备下一场正式比赛" if upcoming.is_empty() else "为%s做准备" % str(upcoming.label)
		return _event("preparation",title,"报名、节目锁定和赛前状态都在赛季页统一确认。",["season:%d" % int(career.clock.year)])
	return _event("training","这一阶段：跟着教练练","先看教练本期安排，再决定接受、保守执行、沟通调整或私下加练。",["clock:%d-Q%d" % [int(career.clock.year),int(career.clock.quarter)]])

static func _next_event(career) -> Dictionary:
	var direct: Dictionary = career.season_state.get("next_event",{})
	if not direct.is_empty():
		return {"id":str(direct.get("event_id","next")),"label":str(direct.get("name",direct.get("label","下一场赛事"))),"when":"第%d周" % int(direct.get("week",0)),"evidence_refs":["schedule:%s" % str(direct.get("event_id","next"))]}
	var entries: Dictionary = career.season_state.get("entry_plan",{}).get("entries",{})
	for event_id in entries:
		var entry: Dictionary = entries[event_id]
		if str(entry.get("status","")) in ["eligible","planned","confirmed","registered"]:
			return {"id":str(event_id),"label":str(entry.get("event_name",entry.get("name","下一场赛事"))),"when":str(entry.get("date_label","等待赛程确认")),"evidence_refs":["entry:%s" % str(event_id)]}
	return {}

static func _changed_states(career, guidance: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var milano: Dictionary = career.milano_olympic_quota_state
	if int(career.clock.year) in [2025,2026] and milano.status in ["worlds_complete","qualifier_complete"]:
		var federation := str(career.story_context.home_federation)
		var places := int(milano.current.countries.get(federation,0))
		var stage := "波士顿世锦赛结算后" if milano.status == "worlds_complete" else "北京资格赛结算后"
		var detail := "%s · %s %d 席" % [stage,federation,places]
		if milano.dispatch.get("selected_ids",[]).has("player"): detail += " · 你已获国内派遣"
		result.append({"id":"milano_quota","label":"米兰冬奥国家席位","value":detail,"evidence_refs":["competition:"+str(milano.current.get("source_event_id",""))]})
	for row in guidance.get("key_states",[]):
		result.append({"id":str(row.get("id","state")),"label":str(row.get("label","状态")),"value":str(row.get("value","")),"evidence_refs":["state:%s:%d-Q%d" % [str(row.get("id","state")),int(career.clock.year),int(career.clock.quarter)]]})
		if result.size() == 3: break
	return result

static func _recent_facts(career) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var milestones: Dictionary = career.experience_state.get("milestones",{})
	for key in ["first_formal_3a","first_jgp_complete","first_jgp_start"]:
		var milestone: Dictionary = milestones.get(key,{})
		if milestone.is_empty() or milestone.get("clock",{}) != career.clock.to_dict(): continue
		var label := "正式比赛3A已完成" if key == "first_formal_3a" else "JGP国际出场已入档"
		result.append({"text":label+" · "+str(milestone.event_name),"evidence_refs":milestone.evidence_refs.duplicate()})
		break
	for index in range(career.history.size()-1,-1,-1):
		var entry: Dictionary = career.history[index]
		var text := _fact_text(entry)
		if text.is_empty() or result.any(func(row): return row.text == text): continue
		var ref := str(entry.get("record_id",entry.get("id","history:%d" % index)))
		result.append({"text":text,"evidence_refs":[ref]})
		if result.size() == 3: break
	return result

static func _fact_text(entry: Dictionary) -> String:
	for field in ["summary","label","reason"]:
		var authored := str(entry.get(field,"")).strip_edges()
		if not authored.is_empty(): return authored
	var summary_key := str(entry.get("summary_key","")).strip_edges()
	if summary_key.is_empty(): return ""
	# Authored Chinese summaries (for example a competition result) are already
	# suitable for the player. Machine keys must never leak onto the home screen.
	if not summary_key.contains("_"): return summary_key
	var target := str(entry.get("target",""))
	var label := str(FACT_TARGET_LABELS.get(target,"本期状态"))
	var delta := float(entry.get("delta",0.0))
	if is_zero_approx(delta): return "%s已经更新" % label
	var easing_targets := ["acute_fatigue","cumulative_fatigue","ankle_load","impact_load"]
	if target in easing_targets:
		return "%s有所上升" % label if delta > 0.0 else "%s有所回落" % label
	return "%s有所提升" % label if delta > 0.0 else "%s有所下降" % label

static func _event(kind: String, title: String, detail: String, refs: Array) -> Dictionary:
	return {"kind":kind,"title":title,"detail":detail,"evidence_refs":refs.duplicate()}

static func _competition_ref(session: Dictionary) -> String:
	return "competition:%s:%s" % [str(session.get("event_id",session.get("id","current"))),str(session.get("status","active"))]
