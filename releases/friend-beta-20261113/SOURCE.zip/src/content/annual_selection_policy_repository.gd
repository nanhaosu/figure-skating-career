class_name AnnualSelectionPolicyRepository
extends RefCounted

const PATH := "res://data/selection/annual_junior_game_policy_v1.json"

static func season_id(year: int) -> String:
	return "%04d-%02d" % [year,(year+1)%100]

static func load_for_season(season: String) -> Dictionary:
	var year := int(season.left(4))
	if year < 2018 or year > 2022 or season != season_id(year): return {"policy":{},"errors":[],"covered":false}
	var text := FileAccess.get_file_as_string(PATH).trim_prefix("\ufeff")
	var parsed = JSON.parse_string(text.replace("{year}",str(year)).replace("{next_year}",str(year+1)))
	if not parsed is Dictionary: return {"policy":{},"errors":["年度选拔游戏制度资料无效"],"covered":false}
	parsed.season_id = season
	parsed.season_start_year = year
	parsed.targets.world_junior.window.year = year+1
	parsed.targets.world_junior.window.quarter = int(parsed.targets.world_junior.window.quarter)
	if year == 2021:
		parsed.targets.world_junior.designated_event_ids = ["cn_junior_u_series_2021_stage_2","cn_club_league_2021_final"]
		parsed.targets.world_junior.weights = {"cn_junior_u_series_2021_stage_2":0.7,"cn_club_league_2021_final":0.3}
	if year == 2022:
		parsed.targets.jgp.second_start = {"mode":"after_first","minimum_first_points":11,"confirmation_days_before_start":7,"source_kind":"game_setting","label":"非官方国内游戏政策：首站前三进入第二站优先池，未首发合格候补填剩余名额；积分、总分、自由滑、固定身份排序；须提前列入正式/候补姓名名单，赛前7天国内改派确认截止"}
		parsed.targets.jgp.designated_event_ids = ["cn_club_league_2021_stage_1","cn_club_league_2021_stage_2","cn_club_league_2021_stage_3","cn_club_league_2021_final"]
		parsed.targets.world_junior.designated_event_ids = ["cn_nationals_chengde_2022"]
		parsed.targets.world_junior.weights = {"cn_nationals_chengde_2022":1.0}
	# Retain the published first-age-eligible JGP exception for every identity.
	if year == 2019:
		var previous: Dictionary = load_for_season("2018-19")
		if not previous.errors.is_empty(): return previous
		parsed.targets.jgp.designated_event_ids.append_array(previous.policy.targets.jgp.designated_event_ids)
	var error := validate(parsed)
	return {"policy":parsed if error.is_empty() else {},"errors":[] if error.is_empty() else [error],"covered":error.is_empty()}

static func validate(policy) -> String:
	if not policy is Dictionary: return "年度政策必须为对象"
	if not integer(policy.get("model_version"),1,1) or policy.get("policy_id") != "annual-chn-junior-game-v1": return "年度政策版本无效"
	if policy.get("source_kind") != "game_setting" or policy.get("federation") != "CHN" or policy.get("discipline") != "women_singles" or policy.get("level") != "junior": return "年度政策采用范围无效"
	if not policy.get("label") is String or not policy.label.contains("非官方"): return "年度政策须明确非官方游戏制度"
	if not integer(policy.get("season_start_year"),2018,2022) or policy.get("season_id") != season_id(int(policy.season_start_year)): return "年度政策赛季无效"
	if not policy.get("targets") is Dictionary or policy.targets.size() != 2: return "年度政策目标无效"
	for kind in ["jgp","world_junior"]:
		var target = policy.targets.get(kind)
		if not target is Dictionary: return "年度政策目标必须为对象"
		if target.get("mode") != ("best_complete_total" if kind == "jgp" else "weighted_complete_totals"): return "年度政策成绩定义无效"
		if target.get("tie_break") != ("same_event_free_then_seeded_identity" if kind == "jgp" else "weighted_free_then_seeded_identity"): return "年度政策同分规则无效"
		if not number(target.get("minimum_score"),0,1000) or not integer(target.get("places"),1,10): return "年度政策门槛或名额无效"
		if not integer(target.get("minimum_age"),1,99) or not integer(target.get("maximum_age"),int(target.minimum_age),99): return "年度政策年龄范围无效"
		var ids = target.get("designated_event_ids")
		if not ids is Array or ids.is_empty() or ids.size() > 32: return "年度政策有效赛事必须是有界列表"
		for id in ids:
			if not id is String or id.is_empty() or ids.count(id) != 1: return "年度政策有效赛事编号无效或重复"
		if kind == "world_junior":
			var weights = target.get("weights")
			if not weights is Dictionary or weights.size() != ids.size(): return "年度政策权重必须覆盖所有必需赛事"
			var total := 0.0
			for id in ids:
				if not number(weights.get(id),0,1): return "年度政策权重无效"
				total += float(weights[id])
			if not is_equal_approx(total,1.0): return "年度政策权重之和须为1"
			var window = target.get("window")
			if not window is Dictionary or not integer(window.get("year"),int(policy.season_start_year)+1,int(policy.season_start_year)+1) or not integer(window.get("quarter"),1,4) or window.get("precision") != "quarter" or window.get("exact_cutoff_verified") != false: return "年度政策季度截止声明无效"
		else:
			if target.has("second_start"):
				var second = target.second_start
				if not second is Dictionary or second.get("mode") != "after_first" or second.get("source_kind") != "game_setting" or not integer(second.get("minimum_first_points"),1,15) or not integer(second.get("confirmation_days_before_start"),1,28) or not str(second.get("label","")).contains("非官方"): return "第二站国内游戏政策无效"
			if not integer(target.get("max_starts"),1,2) or not integer(target.get("station_places"),1,3): return "年度政策分站名额无效"
			var choice = target.get("station_choice")
			if not choice is Dictionary or not number(choice.get("access_threshold"),0,100) or not integer(choice.get("high_choices"),1,10) or not integer(choice.get("base_choices"),1,int(choice.high_choices)): return "年度政策分站选择规则无效"
			var development = target.get("development")
			if not development is Dictionary: return "年度政策发展观察规则无效"
			for key in ["merit_places","minimum_age","maximum_age","minimum_complete_events","age_origin"]:
				if not integer(development.get(key),1,99): return "年度政策发展观察整数无效"
			if int(development.minimum_age) > int(development.maximum_age) or int(development.merit_places) >= int(target.places): return "年度政策发展观察范围无效"
			for key in ["growth_cap","growth_factor","age_factor","age_cap","access_factor","access_cap"]:
				if not number(development.get(key),0,1000): return "年度政策发展观察系数无效"
	return ""

static func integer(value, low: int, high: int) -> bool:
	return number(value,low,high) and float(value) == floorf(float(value))

static func number(value, low: float, high: float) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and float(value) >= low and float(value) <= high

static func content_hash(policy: Dictionary) -> String:
	return _canonical(policy).sha256_text()

static func _canonical(value) -> String:
	if value is Dictionary:
		# GDScript literal keys can be StringName while JSON keys are String.
		# Sort their textual values, not Variant type ordering across save/load.
		var keys: Array = value.keys(); keys.sort_custom(func(a,b):return str(a) < str(b))
		var parts: Array[String] = []
		for key in keys: parts.append(JSON.stringify(str(key))+":"+_canonical(value[key]))
		return "{"+",".join(parts)+"}"
	if value is Array:
		var parts: Array[String] = []
		for item in value: parts.append(_canonical(item))
		return "["+",".join(parts)+"]"
	if value is int or value is float: return JSON.stringify(float(value))
	return JSON.stringify(value)
