class_name InternalEventRules
extends RefCounted

const HistoricalRuleRepository = preload("res://src/content/historical_rule_repository.gd")
const SUPPORTED_LEVELS := ["junior", "senior"]
const CHANGE_SEASON_2026 := 2026

static func for_season(season_start_year: int, level: String, segment: String) -> Dictionary:
	if season_start_year >= 2014 and level == "teaching": return for_teaching_group(segment)
	if season_start_year < 2014 or not SUPPORTED_LEVELS.has(level) or not ["short", "free"].has(segment): return {}
	var historical := HistoricalRuleRepository.load_season(season_start_year, "women_singles")
	if historical.errors.is_empty():
		var catalog_rules := HistoricalRuleRepository.rules_for(historical.rules, level, segment)
		if not catalog_rules.is_empty():
			catalog_rules["rule_origin"] = "historical_catalog"
			return catalog_rules
	var era := "2026_2027" if season_start_year >= CHANGE_SEASON_2026 else "2014_2025"
	var rules := _short_rules(season_start_year, level, era) if segment == "short" else _free_rules(season_start_year, level, era)
	rules["rule_origin"] = "compatibility_generated"
	return rules

static func for_teaching_group(segment: String) -> Dictionary:
	if segment == "short":
		return {
			"ruleset_id": "club_teaching_short_v1", "rule_origin": "club_teaching",
			"segment": "short", "label": "内部教学组短节目", "element_max": 4,
			"jump_min": 2, "jump_max": 2, "jump_combination_min": 1, "jump_combination_max": 1,
			"spin_min": 1, "spin_max": 1, "step_min": 1, "step_max": 1,
			"choreographic_min": 0, "choreographic_max": 0,
			"repeat_limits": {"max_repeated_triples_or_quads": 2},
		}
	if segment == "free":
		return {
			"ruleset_id": "club_teaching_free_v1", "rule_origin": "club_teaching",
			"segment": "free", "label": "内部教学组自由滑", "element_max": 6,
			"jump_min": 3, "jump_max": 3, "jump_combination_min": 1, "jump_combination_max": 1,
			"spin_min": 2, "spin_max": 2, "step_min": 1, "step_max": 1,
			"choreographic_min": 0, "choreographic_max": 0,
			"repeat_limits": {"max_repeated_triples_or_quads": 2},
		}
	return {}

static func _short_rules(season_start_year: int, level: String, era: String) -> Dictionary:
	return {
		"ruleset_id": "isu_%d_%d_%s_short" % [season_start_year, season_start_year + 1, level],
		"source_family": "ISU Rule 611", "segment": "short", "level": level, "label": "短节目",
		"season_start_year": season_start_year, "jump_min": 3, "jump_max": 3,
		"requires_axel_jump": true, "requires_solo_jump": true, "requires_jump_combination": true,
		"jump_combination_min": 1, "jump_combination_max": 1,
		"spin_min": 3, "spin_max": 3, "step_min": 1, "step_max": 1,
		"choreographic_min": 0, "choreographic_max": 0,
		"element_max": 7, "spin_value_version": era,
		"repeat_limits": {"max_repeated_triples_or_quads": 2},
	}

static func _free_rules(season_start_year: int, level: String, era: String) -> Dictionary:
	var six_jump_era := season_start_year >= CHANGE_SEASON_2026
	var step_count := 0 if six_jump_era and level == "junior" else 1
	var jump_count := 6 if six_jump_era else 7
	return {
		"ruleset_id": "isu_%d_%d_%s_free" % [season_start_year, season_start_year + 1, level],
		"source_family": "ISU Rule 612", "segment": "free", "level": level, "label": "自由滑",
		"season_start_year": season_start_year, "jump_min": 0, "jump_max": jump_count,
		"requires_axel_jump": true,
		"jump_combination_min": 0, "jump_combination_max": 3,
		"spin_min": 0, "spin_max": 3, "step_min": 0, "step_max": step_count,
		"choreographic_min": 0, "choreographic_max": 1,
		"element_max": jump_count + 3 + step_count + 1, "spin_value_version": era,
		"repeat_limits": {"max_repeated_triples_or_quads": 2},
	}
