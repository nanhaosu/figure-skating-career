class_name HistoricalRuleRepository
extends RefCounted

const BASE_PATH := "res://data/rules"
const SEGMENTS := ["short", "free"]
const COUNT_FIELDS := [
	"jump_min", "jump_max", "jump_combination_min", "jump_combination_max",
	"spin_min", "spin_max", "step_min", "step_max",
	"choreographic_min", "choreographic_max", "element_max",
]

static func load_season(season_start_year: int, discipline: String) -> Dictionary:
	var season_id := "%d-%02d" % [season_start_year, (season_start_year + 1) % 100]
	var path := BASE_PATH.path_join("%d_%d_%s.json" % [season_start_year, season_start_year + 1, discipline])
	if not FileAccess.file_exists(path):
		return {"rules": {}, "errors": ["尚未收录%s赛季 %s 规则" % [season_id, discipline]]}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary:
		return {"rules": {}, "errors": ["历史规则文件不是有效对象：%s" % path]}
	var rules: Dictionary = Dictionary(json.data).duplicate(true)
	var errors := validate(rules)
	return {"rules": rules if errors.is_empty() else {}, "errors": errors}

static func rules_for(data: Dictionary, level: String, segment: String) -> Dictionary:
	var levels = data.get("levels", {})
	if not levels is Dictionary or not levels.has(level) or not levels[level] is Dictionary:
		return {}
	var segments = levels[level].get("segments", {})
	if not segments is Dictionary or not segments.has(segment) or not segments[segment] is Dictionary:
		return {}
	var result: Dictionary = Dictionary(segments[segment]).duplicate(true)
	result["catalog_version"] = int(data.get("catalog_version", 0))
	result["season_start_year"] = int(data.get("season_start_year", 0))
	result["season_id"] = str(data.get("season_id", ""))
	result["level"] = level
	return result

static func validate(data: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	for key in ["catalog_version", "season_start_year", "season_id", "discipline", "effective_from", "effective_to", "sources", "levels"]:
		if not data.has(key): errors.append("%s 缺失" % key)
	if not _is_non_negative_integer(data.get("catalog_version")): errors.append("catalog_version 必须是非负整数")
	if not _is_non_negative_integer(data.get("season_start_year")): errors.append("season_start_year 必须是非负整数")
	var start_year := int(data.get("season_start_year", 0))
	if str(data.get("season_id", "")) != "%d-%02d" % [start_year, (start_year + 1) % 100]:
		errors.append("season_id 必须与 season_start_year 对应")
	for key in ["discipline", "effective_from", "effective_to"]:
		if not data.get(key) is String or str(data.get(key, "")).is_empty(): errors.append("%s 必须是非空字符串" % key)
	var source_ids := _validate_sources(data.get("sources"), errors)
	var levels = data.get("levels")
	if not levels is Dictionary or not levels.get("junior") is Dictionary:
		errors.append("levels.junior 必须是对象")
		return errors
	for level_id in levels:
		if not ["junior","senior"].has(level_id):
			errors.append("未知规则组别：%s" % level_id)
			continue
		if not levels[level_id] is Dictionary or not levels[level_id].get("segments") is Dictionary:
			errors.append("levels.%s.segments 必须是对象" % level_id)
			continue
		var segments:Dictionary = levels[level_id].segments
		for segment_id in SEGMENTS:
			var path := "levels.%s.segments.%s" % [level_id,segment_id]
			var segment = segments.get(segment_id)
			if not segment is Dictionary:
				errors.append("%s 必须是对象" % path)
				continue
			_validate_segment(segment_id, segment, path, source_ids, errors)
	return errors

static func _validate_sources(value, errors: Array[String]) -> Array[String]:
	var ids: Array[String] = []
	if not value is Array or value.is_empty():
		errors.append("sources 必须是非空数组")
		return ids
	for index in value.size():
		var source = value[index]
		if not source is Dictionary:
			errors.append("sources.%d 必须是对象" % index)
			continue
		for key in ["source_id", "title", "url", "retrieved_on"]:
			if not source.get(key) is String or str(source.get(key, "")).is_empty():
				errors.append("sources.%d.%s 必须是非空字符串" % [index, key])
		var source_id := str(source.get("source_id", ""))
		if not source_id.is_empty() and not ids.has(source_id): ids.append(source_id)
	return ids

static func _validate_segment(segment_id: String, segment: Dictionary, path: String, source_ids: Array[String], errors: Array[String]) -> void:
	for key in ["ruleset_id", "segment", "label", "formal_scoring_catalog"]:
		if not segment.get(key) is String or str(segment.get(key, "")).is_empty(): errors.append("%s.%s 必须是非空字符串" % [path, key])
	if str(segment.get("segment", "")) != segment_id: errors.append("%s.segment 必须等于%s" % [path, segment_id])
	for key in ["duration_seconds", "duration_tolerance_seconds"] + COUNT_FIELDS:
		if not _is_non_negative_integer(segment.get(key)): errors.append("%s.%s 必须是非负整数" % [path, key])
	for key in ["required_jump_types", "source_ids"]:
		if not segment.get(key) is Array or segment.get(key, []).is_empty(): errors.append("%s.%s 必须是非空数组" % [path, key])
	if segment.get("source_ids") is Array:
		for source_id in segment.source_ids:
			if not source_ids.has(str(source_id)): errors.append("%s.source_ids 引用了未知来源：%s" % [path, source_id])
	if not segment.get("repeat_limits") is Dictionary: errors.append("%s.repeat_limits 必须是对象" % path)
	if not segment.get("bonus_window") is Dictionary: errors.append("%s.bonus_window 必须是对象" % path)
	if not segment.get("component_factor") is int and not segment.get("component_factor") is float:
		errors.append("%s.component_factor 必须是数字" % path)
	if _is_non_negative_integer(segment.get("element_max")) and _is_non_negative_integer(segment.get("jump_max")) and _is_non_negative_integer(segment.get("spin_min")) and _is_non_negative_integer(segment.get("step_min")):
		var required := int(segment.jump_max) + int(segment.spin_min) + int(segment.step_min) + int(segment.get("choreographic_min", 0))
		if int(segment.element_max) < required: errors.append("%s.element_max 小于必需动作总数" % path)

static func _is_non_negative_integer(value) -> bool:
	return (value is int or value is float) and is_equal_approx(float(value), floorf(float(value))) and float(value) >= 0.0
