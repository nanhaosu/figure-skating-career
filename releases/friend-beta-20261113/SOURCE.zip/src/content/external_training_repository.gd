class_name ExternalTrainingRepository
extends RefCounted

static func courses() -> Array:
	var decoded = JSON.parse_string(FileAccess.get_file_as_string("res://data/2014_cn/external_training.json"))
	if not decoded is Dictionary or not decoded.get("courses") is Array: return []
	return decoded.courses.duplicate(true)

static func course(id: String) -> Dictionary:
	for item in courses():
		if item.get("id") == id: return item
	return {}
