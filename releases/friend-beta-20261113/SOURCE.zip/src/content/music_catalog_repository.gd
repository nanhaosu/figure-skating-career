class_name MusicCatalogRepository
extends RefCounted

const PATH := "res://data/music/program_music_catalog.json"

static func load_catalog() -> Dictionary:
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(PATH)) != OK or not json.data is Dictionary:
		return {"works": [], "by_id": {}, "errors": ["内置曲库无法读取"]}
	var works = json.data.get("works", [])
	if not works is Array: return {"works": [], "by_id": {}, "errors": ["内置曲库作品列表无效"]}
	var by_id := {}
	var errors: Array[String] = []
	for index in works.size():
		var work = works[index]
		if not work is Dictionary or str(work.get("id", "")).is_empty() or str(work.get("title", "")).is_empty():
			errors.append("内置曲库第%d项无效" % (index + 1)); continue
		if by_id.has(work.id): errors.append("内置曲目编号重复：%s" % work.id)
		by_id[work.id] = work
	return {"works": works, "by_id": by_id, "errors": errors}
