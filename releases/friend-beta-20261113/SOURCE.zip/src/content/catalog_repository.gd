class_name CatalogRepository
extends RefCounted

const BACKGROUND_FILE := "backgrounds.json"
const TRAINING_FILE := "training.json"
const EVENT_PHRASES_FILE := "event_phrases.json"
const ENTRY_PATH_COUNT := 5
const FAMILY_PROFILE_COUNT := 4
const ENTRY_PATH_FIELDS := ["name", "description", "technique_delta", "resource_delta", "starting_relationship_id"]
const FAMILY_PROFILE_FIELDS := ["name", "description", "economic_capacity", "control", "health_priority", "emotional_support", "industry_knowledge"]
const TRAINING_CATEGORIES := {
	"skating_foundation": {"label": "滑行基础", "target": "skating"},
	"jump_toe_loop": {"label": "后外点冰跳", "target": "jump:toe_loop"},
	"jump_salchow": {"label": "后内结环跳", "target": "jump:salchow"},
	"jump_loop": {"label": "后外结环跳", "target": "jump:loop"},
	"jump_flip": {"label": "后内点冰跳", "target": "jump:flip"},
	"jump_lutz": {"label": "勾手跳", "target": "jump:lutz"},
	"jump_axel": {"label": "阿克塞尔跳", "target": "jump:axel"},
	"rotation": {"label": "旋转训练", "target": "rotation"},
	"conditioning": {"label": "体能与力量", "target": "recovery_capacity"},
	"rest": {"label": "恢复与自由活动", "target": "recovery"},
}

static func load_catalog(base_path: String = "res://data/2014_cn") -> Dictionary:
	var errors: Array[String] = []
	var backgrounds := _read_json(base_path.path_join(BACKGROUND_FILE), "backgrounds", errors)
	var training := _read_json(base_path.path_join(TRAINING_FILE), "training", errors)
	var event_phrases := _read_json(base_path.path_join(EVENT_PHRASES_FILE), "event_phrases", errors)
	if not backgrounds.is_empty():
		errors.append_array(validate_backgrounds(backgrounds))
	if not training.is_empty():
		errors.append_array(validate_training(training))
	if not event_phrases.is_empty():
		errors.append_array(validate_event_phrases(event_phrases))
	return {"backgrounds": backgrounds, "training": training, "event_phrases": event_phrases, "errors": errors}

static func validate_event_phrases(data: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not data.get("locations") is Array or data.locations.size() < 3:
		errors.append("event_phrases.locations must contain at least 3 entries")
	if not data.get("fragments") is Dictionary:
		errors.append("event_phrases.fragments must be a Dictionary")
		return errors
	for signature in ["jump_load_conflict", "delayed_pain", "fatigue_breakdown"]:
		if not data.fragments.get(signature) is Array or data.fragments[signature].is_empty():
			errors.append("event_phrases.fragments.%s must be a non-empty Array" % signature)
	return errors

static func validate_backgrounds(backgrounds: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not _is_non_empty_dictionary(backgrounds.get("entry_paths")):
		errors.append("backgrounds.entry_paths must be a non-empty Dictionary")
	if not _is_non_empty_dictionary(backgrounds.get("family_profiles")):
		errors.append("backgrounds.family_profiles must be a non-empty Dictionary")
	if not errors.is_empty():
		return errors
	if backgrounds.entry_paths.size() != ENTRY_PATH_COUNT:
		errors.append("backgrounds.entry_paths must contain exactly %d entries, got %d" % [ENTRY_PATH_COUNT, backgrounds.entry_paths.size()])
	if backgrounds.family_profiles.size() != FAMILY_PROFILE_COUNT:
		errors.append("backgrounds.family_profiles must contain exactly %d entries, got %d" % [FAMILY_PROFILE_COUNT, backgrounds.family_profiles.size()])
	for entry_id in backgrounds.entry_paths:
		_validate_entry_path("backgrounds.entry_paths.%s" % entry_id, backgrounds.entry_paths[entry_id], errors)
	for profile_id in backgrounds.family_profiles:
		_validate_family_profile("backgrounds.family_profiles.%s" % profile_id, backgrounds.family_profiles[profile_id], errors)
	errors.append_array(validate_id_references(backgrounds))
	return errors

static func validate_training(training: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not _is_non_empty_dictionary(training.get("categories")):
		return ["training.categories must be a non-empty Dictionary"]
	var categories: Dictionary = training.categories
	for category_id in TRAINING_CATEGORIES:
		if not categories.has(category_id):
			errors.append("training.categories.%s is required" % category_id)
	for category_id in categories:
		if not TRAINING_CATEGORIES.has(category_id):
			errors.append("training.categories.%s is not allowed" % category_id)
			continue
		var category_path := "training.categories.%s" % category_id
		var category = categories[category_id]
		if not category is Dictionary:
			errors.append("%s must be a Dictionary" % category_path)
			continue
		for field_name in ["label", "target"]:
			if not category.has(field_name):
				errors.append("%s.%s is required" % [category_path, field_name])
			elif not category[field_name] is String:
				errors.append("%s.%s must be a String" % [category_path, field_name])
		if category.get("label") != TRAINING_CATEGORIES[category_id].label:
			errors.append("%s.label must equal %s" % [category_path, TRAINING_CATEGORIES[category_id].label])
		if category.get("target") != TRAINING_CATEGORIES[category_id].target:
			errors.append("%s.target must equal %s" % [category_path, TRAINING_CATEGORIES[category_id].target])
	return errors

static func validate_id_references(backgrounds: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not _is_non_empty_dictionary(backgrounds.get("entry_paths")) or not _is_non_empty_dictionary(backgrounds.get("family_profiles")):
		return errors
	for entry_id in backgrounds.entry_paths:
		var entry = backgrounds.entry_paths[entry_id]
		if entry is Dictionary and entry.get("starting_relationship_id") is String and not backgrounds.family_profiles.has(entry.starting_relationship_id):
			errors.append("backgrounds.entry_paths.%s.starting_relationship_id references unknown family profile %s" % [entry_id, entry.starting_relationship_id])
	return errors

static func _read_json(file_path: String, catalog_name: String, errors: Array[String]) -> Dictionary:
	if not FileAccess.file_exists(file_path):
		errors.append("%s file is missing: %s" % [catalog_name, file_path])
		return {}
	var content := FileAccess.get_file_as_string(file_path)
	var json := JSON.new()
	if json.parse(content) != OK:
		errors.append("%s JSON is invalid: %s" % [catalog_name, json.get_error_message()])
		return {}
	if not json.data is Dictionary:
		errors.append("%s must be a Dictionary" % catalog_name)
		return {}
	return json.data

static func _validate_entry_path(path: String, entry: Variant, errors: Array[String]) -> void:
	if not entry is Dictionary:
		errors.append("%s must be a Dictionary" % path)
		return
	for field_name in ENTRY_PATH_FIELDS:
		if not entry.has(field_name):
			errors.append("%s.%s is required" % [path, field_name])
			continue
		var value = entry[field_name]
		if field_name in ["name", "description", "starting_relationship_id"] and not value is String:
			errors.append("%s.%s must be a String" % [path, field_name])
		elif field_name in ["technique_delta", "resource_delta"] and not value is int and not value is float:
			errors.append("%s.%s must be numeric" % [path, field_name])

static func _validate_family_profile(path: String, profile: Variant, errors: Array[String]) -> void:
	if not profile is Dictionary:
		errors.append("%s must be a Dictionary" % path)
		return
	for field_name in FAMILY_PROFILE_FIELDS:
		if not profile.has(field_name):
			errors.append("%s.%s is required" % [path, field_name])
			continue
		var value = profile[field_name]
		if field_name in ["name", "description"] and not value is String:
			errors.append("%s.%s must be a String" % [path, field_name])
		elif field_name not in ["name", "description"]:
			if not value is int and not value is float:
				errors.append("%s.%s must be numeric" % [path, field_name])
			elif value < 0 or value > 100:
				errors.append("%s.%s must be between 0 and 100" % [path, field_name])

static func _is_non_empty_dictionary(value: Variant) -> bool:
	return value is Dictionary and not value.is_empty()
