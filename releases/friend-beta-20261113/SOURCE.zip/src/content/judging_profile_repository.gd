class_name JudgingProfileRepository
extends RefCounted

static func load_profiles(year: int) -> Dictionary:
	var path := "res://data/judging/%d_%d_profiles.json" % [year,year+1]
	if not FileAccess.file_exists(path): return {"profiles":[],"errors":["无对应赛季裁判资料"]}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary: return {"profiles":[],"errors":["裁判资料格式错误"]}
	var data: Dictionary = json.data
	var seen := {}
	for profile in data.get("profiles",[]):
		for key in ["judge_id","federation","bloc","style_bloc","technical_bias","pcs_bias","affinity","risk_tolerance","consistency"]:
			if not profile.has(key): return {"profiles":[],"errors":["裁判资料字段缺失"]}
		if seen.has(profile.judge_id): return {"profiles":[],"errors":["裁判ID重复"]}
		seen[profile.judge_id] = true
	data.errors = []
	return data

static func panel(event: Dictionary, seed: int) -> Array[Dictionary]:
	var data := load_profiles(int(event.ruleset_season_start_year))
	var pool: Array[Dictionary] = []
	var federations := {}
	var host_only:bool = int(event.get("ruleset_season_start_year",0)) == 2020 and event.get("event_family") == "gp_stage"
	var host := str(event.get("host_federation",""))
	if host_only:
		var policy = event.get("pandemic_policy")
		if not policy is Dictionary or policy.get("officials_policy") != "host_country" or host.is_empty(): return []
	for profile in data.get("profiles",[]):
		if event.scope == "domestic" or host_only:
			if profile.federation == (host if host_only else "CHN"): pool.append(profile.duplicate(true))
		elif not federations.has(profile.federation):
			pool.append(profile.duplicate(true)); federations[profile.federation] = true
	var selected: Array[Dictionary] = []
	var count := preload("res://src/content/season_calendar_repository.gd").judging_panel_size(event)
	if count < 0 or pool.size() < count: return selected
	for index in count: selected.append(pool[(index + posmod(seed,pool.size())) % pool.size()])
	return selected

static func for_entrant(profiles: Array, row: Dictionary, event: Dictionary, reputation: float) -> Array[Dictionary]:
	var data := load_profiles(int(event.ruleset_season_start_year))
	var bloc := str(data.get("federation_blocs",{}).get(row.federation,"independent"))
	var result: Array[Dictionary] = []
	for raw in profiles:
		var judge: Dictionary = raw.duplicate(true)
		var reasons := {}; var preference := 0.0
		if judge.federation == row.federation: reasons.federation = 0.25
		if judge.bloc == bloc: reasons.bloc = 0.25
		if event.scope == "domestic" and judge.get("club_id","") == row.club_id: reasons.club = 0.30
		if judge.style_bloc == row.get("style_bloc",""): reasons.style = 0.15
		reasons.reputation = clampf(reputation/100.0,0.0,1.0) * clampf(float(judge.risk_tolerance),0,1) * 0.20
		for value in reasons.values(): preference += float(value)
		judge.affinity = minf(1.0, preference * clampf(float(raw.affinity),0,1))
		judge.affinity_audit = reasons
		result.append(judge)
	return result
