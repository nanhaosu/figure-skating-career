class_name SeasonBundleRepository
extends RefCounted

const SeasonCalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const HistoricalRuleRepository = preload("res://src/content/historical_rule_repository.gd")
const FormalScoringRepository = preload("res://src/content/formal_scoring_repository.gd")

const FEDERATION_BASE_PATH := "res://data/federations"

static func season_year(career) -> int:
	# The playable catalog starts in 2018; childhood uses its future calendar.
	var year := maxi(career.clock.season_start_year(),2018)
	var previous := "%d-%02d" % [year-1,year%100]
	# A quarter-ending decision can return at July before the coordinator has
	# archived that season. Keep its calendar long enough to close it once.
	# Only a matching immediately preceding active plan qualifies, never an
	# arbitrary stale legacy season or an already closed receipt.
	if year > 2018 and career.season_state.get("season_id","") == previous and career.season_program_plan.get("season_id","") == previous and career.season_program_plan.get("status","") == "confirmed":
		var closed: bool = career.season_state.get("season_history",{}).has(previous) or career.event_ledger.any(func(row):return row.get("kind") == "season_closed" and row.get("season_id") == previous)
		if not closed: return year-1
	return year

static func for_career(career) -> Dictionary:
	var year := season_year(career)
	var level := preload("res://src/simulation/competitive_level_service.gd").current(career)
	var bundle := load_bundle(year,"women_singles","senior" if level == "senior" and year >= 2020 else "junior")
	if not bundle.errors.is_empty(): return bundle
	if level == "transition" and year >= 2020:
		var senior := SeasonCalendarRepository.load_international_calendar(year,"women_singles","senior")
		if not senior.errors.is_empty():
			bundle.errors.append_array(senior.errors)
			return bundle
		var merged := _merge_calendars(bundle.calendar,senior.calendar)
		bundle.errors.append_array(merged.errors)
		bundle.calendar = merged.calendar
	elif level in ["junior","senior"]:
		bundle.calendar.events = bundle.calendar.events.filter(func(event):return event.get("scope") != "international" or event.get("level_options",[]).has(level))
	return bundle

static func competition_for_career(career, requested: Dictionary) -> Dictionary:
	# Infer offered groups from the canonical event first. Caller-edited
	# level_options must not turn a junior-only U event into a senior event.
	var canonical := competition_event(requested)
	if not canonical.errors.is_empty(): return canonical
	var event: Dictionary = canonical.event.duplicate(true)
	event.competition_level = preload("res://src/simulation/competitive_level_service.gd").event_level(career,event)
	return competition_event(event)
const FEDERATION_PROFILE_FIELDS := [
	"profile_tier", "pool_size", "mean_strength", "strength_deviation", "resource_level",
	"volatility", "late_bloomer_rate", "nationality_frequency", "fictional_generation_only",
]

static func load_bundle(season_start_year: int, discipline: String, level: String) -> Dictionary:
	var errors: Array[String] = []
	var domestic: Dictionary = SeasonCalendarRepository.load_calendar(season_start_year, "CHN", discipline)
	var international: Dictionary = SeasonCalendarRepository.load_international_calendar(season_start_year, discipline, level)
	var loaded_rules: Dictionary = HistoricalRuleRepository.load_season(season_start_year, discipline)
	var loaded_scoring: Dictionary = FormalScoringRepository.load_catalog(season_start_year, discipline)
	var loaded_federations := _load_federation_profiles(season_start_year, discipline)
	errors.append_array(_strings(domestic.get("errors", [])))
	errors.append_array(_strings(international.get("errors", [])))
	errors.append_array(_strings(loaded_rules.get("errors", [])))
	errors.append_array(_strings(loaded_scoring.get("errors", [])))
	errors.append_array(_strings(loaded_federations.get("errors", [])))

	var calendar := {}
	if domestic.get("errors", []).is_empty() and international.get("errors", []).is_empty():
		var merged := _merge_calendars(domestic.calendar, international.calendar)
		errors.append_array(_strings(merged.errors))
		if merged.errors.is_empty(): calendar = merged.calendar

	var rules: Dictionary = Dictionary(loaded_rules.get("rules", {})).duplicate(true)
	var scoring: Dictionary = Dictionary(loaded_scoring.get("catalog", {})).duplicate(true)
	var federation_profiles: Dictionary = Dictionary(loaded_federations.get("profiles", {})).duplicate(true)
	if not rules.is_empty() and HistoricalRuleRepository.rules_for(rules, level, "short").is_empty():
		errors.append("%s规则目录没有唯一的%s短节目规则" % [rules.get("season_id", ""), level])
	if not rules.is_empty() and HistoricalRuleRepository.rules_for(rules, level, "free").is_empty():
		errors.append("%s规则目录没有唯一的%s自由滑规则" % [rules.get("season_id", ""), level])
	if errors.is_empty():
		errors.append_array(_calendar_rule_errors(calendar,discipline))

	if not errors.is_empty() and calendar.is_empty():
		rules = {}
		scoring = {}
		federation_profiles = {}
	return {
		"calendar": calendar,
		"rules": rules,
		"scoring": scoring,
		"federation_profiles": federation_profiles,
		"errors": errors,
	}

static func _calendar_rule_errors(calendar:Dictionary,discipline:String) -> Array[String]:
	var errors:Array[String] = []
	for event in calendar.get("events",[]):
		if not event is Dictionary:
			errors.append("规则审计赛事必须为对象")
			continue
		var status := SeasonCalendarRepository.event_status(event)
		if status == "cancelled": continue
		if status not in ["scheduled","held"]:
			errors.append("规则审计赛事状态无效")
			continue
		var levels = event.get("level_options")
		if not levels is Array or levels.is_empty():
			errors.append("%s 缺少可执行组别" % event.get("event_id",""))
			continue
		# A merged calendar can offer junior-only U2 and senior-only GP alongside
		# mixed domestic events. The caller's selected group is not their rule.
		for offered_level in levels:
			if not offered_level is String or offered_level not in ["junior","senior"]:
				errors.append("赛事提供了未知组别")
				continue
			for segment in ["short","free"]:
				var resolved := rules_for_event_level(event,segment,discipline,offered_level)
				for error in resolved.errors:
					errors.append("%s.%s.%s：%s" % [event.get("event_id",""),offered_level,segment,error])
	return errors

static func rules_for_event(event: Dictionary, segment: String, discipline: String = "women_singles", level: String = "junior") -> Dictionary:
	var errors: Array[String] = []
	if not ["short", "free"].has(segment):
		return {"rules": {}, "scoring": {}, "errors": ["未知比赛阶段：%s" % segment]}
	var season_start_year := int(event.get("ruleset_season_start_year", 0))
	if season_start_year <= 0:
		return {"rules": {}, "scoring": {}, "errors": ["赛事缺少有效ruleset_season_start_year"]}
	var loaded_rules := HistoricalRuleRepository.load_season(season_start_year, discipline)
	errors.append_array(_strings(loaded_rules.errors))
	var resolved_rules := {}
	if loaded_rules.errors.is_empty():
		resolved_rules = HistoricalRuleRepository.rules_for(loaded_rules.rules, level, segment)
		if resolved_rules.is_empty(): errors.append("没有找到%s %s规则" % [level, segment])
	var loaded_scoring := FormalScoringRepository.load_catalog(season_start_year, discipline)
	errors.append_array(_strings(loaded_scoring.errors))
	var expected_catalog := "%d_%d_%s_scoring" % [season_start_year, season_start_year + 1, discipline]
	if not resolved_rules.is_empty() and str(resolved_rules.get("formal_scoring_catalog", "")) != expected_catalog:
		errors.append("规则引用的计分目录无效：%s" % resolved_rules.get("formal_scoring_catalog", ""))
	if event.has("formal_scoring_catalog") and str(event.formal_scoring_catalog) != expected_catalog:
		errors.append("赛事引用的计分目录无效：%s" % event.formal_scoring_catalog)
	if event.get("scoring_rule") == "isu_2022_" + level and errors.is_empty():
		var scoring: Dictionary = loaded_scoring.catalog
		scoring.scoring_era_id = "isu_2022_three_components"
		scoring.components = {"ids":["composition","presentation","skating_skills"],"short":{"factor":1.33},"free":{"factor":2.67}}
		resolved_rules.component_factor = scoring.components[segment].factor
		resolved_rules.axel_sequence_allowed = segment == "free"
		resolved_rules.ruleset_id = "isu_2022_" + level + "_" + segment
		resolved_rules.source_ids = ["isu_2494"]
		if level == "junior":
			resolved_rules.source_ids.append("isu_2022_junior_guide")
			if segment == "short":
				resolved_rules.required_solo_jump = "loop"
				resolved_rules.required_spin_codes = ["CCoSp","FCSp","LSp"]
				resolved_rules.allowed_spin_codes = ["CCoSp","FCSp","LSp","CSp"]
			else:
				resolved_rules.step_min = 0
				resolved_rules.step_max = 0
				resolved_rules.choreographic_min = 1
				resolved_rules.choreographic_max = 1
	if str(event.get("scope", "domestic")) == "international" and loaded_scoring.errors.is_empty():
		loaded_scoring.catalog.domestic_bonus = {}
	# Rule 353: escalating fall deductions apply to seniors, not juniors.
	if level == "junior" and loaded_scoring.errors.is_empty():
		loaded_scoring.catalog.deductions.fall_third_and_later = 1.0
	return {
		"rules": resolved_rules if errors.is_empty() else {},
		"scoring": Dictionary(loaded_scoring.get("catalog", {})).duplicate(true) if errors.is_empty() else {},
		"errors": errors,
	}

static func rules_for_event_level(event:Dictionary,segment:String,discipline:String,requested_level:String) -> Dictionary:
	if requested_level not in ["junior","senior"] or not event.get("level_options",[]).has(requested_level):
		return {"rules":{},"scoring":{},"errors":["赛事未提供请求的组别："+requested_level]}
	if SeasonCalendarRepository.event_status(event) not in ["scheduled","held"]:
		return {"rules":{},"scoring":{},"errors":["取消或状态无效的赛事不可执行"]}
	var count := SeasonCalendarRepository.judging_panel_size(event)
	if count < 0: return {"rules":{},"scoring":{},"errors":["赛事裁判人数或来源无效"]}
	var resolved := rules_for_event(event,segment,discipline,requested_level)
	if resolved.errors.is_empty(): resolved.scoring.panel.judge_count = count
	return resolved

static func competition_event(requested: Dictionary) -> Dictionary:
	var selected_level := str(requested.get("competition_level",""))
	if requested.has("competition_level") and selected_level not in ["junior","senior"]:
		return {"event":{},"rules":{},"errors":["未知请求比赛组别"]}
	var year := int(requested.get("ruleset_season_start_year",0))
	# Older catalogs merged all domestic groups with the single junior
	# international file. Keep that lookup, not a junior RULE fallback.
	var catalog_level := "junior" if year < 2020 or selected_level.is_empty() else selected_level
	var bundle := load_bundle(year, "women_singles", catalog_level)
	if not bundle.errors.is_empty(): return {"event":{},"rules":{},"errors":bundle.errors}
	var event := {}
	for candidate in bundle.calendar.events:
		if candidate.event_id == requested.get("event_id"): event = candidate.duplicate(true); break
	if event.is_empty() and year>=2020 and selected_level.is_empty():
		# Group inference comes from the canonical catalogs, never caller-edited
		# level_options. A separate senior international file is not in junior.
		var senior_bundle := load_bundle(year,"women_singles","senior")
		if not senior_bundle.errors.is_empty():return {"event":{},"rules":{},"errors":senior_bundle.errors}
		for candidate in senior_bundle.calendar.events:
			if candidate.event_id==requested.get("event_id"):
				event=candidate.duplicate(true)
				bundle=senior_bundle
				break
	if event.is_empty(): return {"event":{},"rules":{},"errors":["未知赛事"]}
	if selected_level.is_empty(): selected_level = "junior" if event.level_options.has("junior") else "senior"
	if not event.level_options.has(selected_level): return {"event":{},"rules":{},"errors":["赛事未提供请求比赛组别"]}
	event.competition_level = selected_level
	for key in ["scope","event_family","ranking_points_system","record_eligibility","formal_scoring_catalog","judge_count","judge_count_source_ids","judge_count_game_policy","panel_verification","qualification_policy_id"]:
		if requested.has(key) and requested[key] != event.get(key): return {"event":{},"rules":{},"errors":["赛事资料与赛历不一致：%s" % key]}
	if event.has("qualification_policy_id"):
		var adopted := preload("res://src/content/beijing_qualification_policy.gd").load_policy()
		if not adopted.errors.is_empty():return {"event":{},"rules":{},"errors":adopted.errors}
		if event.event_id!="isu_owg2022" or event.qualification_policy_id!=adopted.policy.policy_id:return {"event":{},"rules":{},"errors":["赛事采用资格规则范围无效"]}
		event.qualification_policy=adopted.policy.duplicate(true)
	var family := str(event.event_family)
	var policies: Dictionary = bundle.scoring.get("event_policies",{})
	if not policies.has(family): return {"event":{},"rules":{},"errors":["赛事缺少比赛策略"]}
	event.competition_policy = policies[family].duplicate(true)
	var resolved := {}
	for segment in ["short","free"]:
		var loaded := rules_for_event_level(event,segment,"women_singles",selected_level)
		if not loaded.errors.is_empty(): return {"event":{},"rules":{},"errors":loaded.errors}
		resolved[segment] = {"segment_rules":loaded.rules,"scoring_catalog":loaded.scoring}
	return {"event":event,"rules":resolved,"season_id":bundle.calendar.season_id,"errors":[]}

static func _merge_calendars(domestic: Dictionary, international: Dictionary) -> Dictionary:
	var errors: Array[String] = []
	if str(domestic.get("season_id", "")) != str(international.get("season_id", "")):
		errors.append("国内与国际赛历赛季不一致")
	if str(domestic.get("discipline", "")) != str(international.get("discipline", "")):
		errors.append("国内与国际赛历项目不一致")
	var qualifications := Dictionary(domestic.get("qualification_definitions", {})).duplicate(true)
	for qualification_id in Dictionary(international.get("qualification_definitions", {})):
		if qualifications.has(qualification_id):
			# Legacy catalogs use different descriptive labels for the same ID.
			# Only executable definition differences are conflicts; retain the
			# existing domestic display label rather than rewriting old content.
			var domestic_definition := Dictionary(qualifications[qualification_id]).duplicate(true)
			var international_definition := Dictionary(international.qualification_definitions[qualification_id]).duplicate(true)
			domestic_definition.erase("label")
			international_definition.erase("label")
			if domestic_definition != international_definition:
				errors.append("赛历资格定义冲突：%s" % qualification_id)
		else:
			qualifications[qualification_id] = international.qualification_definitions[qualification_id]
	qualifications = qualifications.duplicate(true)
	var series_rules := {}
	for calendar in [domestic,international]:
		for series_id in Dictionary(calendar.get("series_rules",{})):
			if series_rules.has(series_id) and series_rules[series_id] != calendar.series_rules[series_id]:
				errors.append("赛历系列规则冲突：%s" % series_id)
			else:
				series_rules[series_id] = calendar.series_rules[series_id]
	var sources_by_id := {}
	for calendar in [domestic, international]:
		for source in calendar.get("sources", []):
			var source_id := str(source.get("source_id", ""))
			if sources_by_id.has(source_id) and sources_by_id[source_id] != source:
				errors.append("赛历来源ID冲突：%s" % source_id)
			else:
				sources_by_id[source_id] = Dictionary(source).duplicate(true)
	var events_by_id := {}
	for calendar in [domestic, international]:
		for event in calendar.get("events", []):
			var event_id := str(event.get("event_id", ""))
			if events_by_id.has(event_id) and events_by_id[event_id] != event:
				errors.append("赛历赛事ID冲突：%s" % event_id)
			else:
				events_by_id[event_id] = Dictionary(event).duplicate(true)
	if not errors.is_empty(): return {"calendar": {}, "errors": errors}
	var source_ids: Array[String] = []
	source_ids.assign(sources_by_id.keys())
	source_ids.sort()
	var sources: Array = source_ids.map(func(source_id): return sources_by_id[source_id])
	var merged := {
		"catalog_version": maxi(int(domestic.get("catalog_version", 0)), int(international.get("catalog_version", 0))),
		"calendar_year": int(domestic.get("calendar_year", 0)),
		"season_id": str(domestic.get("season_id", "")),
		"federation": "ISU+CHN",
		"discipline": str(domestic.get("discipline", "")),
		"qualification_definitions": qualifications,
		"sources": sources,
		"events": events_by_id.values(),
	}
	if domestic.has("series_rules") or international.has("series_rules"):
		merged.series_rules = series_rules.duplicate(true)
	if domestic.has("coverage_policy"):merged.coverage_policy=domestic.coverage_policy.duplicate(true)
	var ordered := SeasonCalendarRepository.chronological_events(merged)
	for index in ordered.size(): ordered[index]["sequence"] = index + 1
	merged.events = ordered
	errors.append_array(SeasonCalendarRepository.validate(merged))
	return {"calendar": merged if errors.is_empty() else {}, "errors": errors}

static func _load_federation_profiles(season_start_year: int, discipline: String) -> Dictionary:
	var path := FEDERATION_BASE_PATH.path_join("%d_%d_%s.json" % [season_start_year, season_start_year + 1, discipline])
	if not FileAccess.file_exists(path): return {"profiles": {}, "errors": ["联邦生成参数不存在：%s" % path]}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary:
		return {"profiles": {}, "errors": ["联邦生成参数不是有效对象：%s" % path]}
	var data: Dictionary = Dictionary(json.data).duplicate(true)
	if season_start_year in [2020,2021]:
		var supplement = JSON.parse_string(FileAccess.get_file_as_string(FEDERATION_BASE_PATH.path_join("2020_2022_global_women_supplement.json")))
		if not supplement is Dictionary or supplement.get("model_version") != 1 or not supplement.get("defaults") is Dictionary or not supplement.get("countries") is Dictionary or not supplement.get("season_start_years") is Array or not supplement.season_start_years.any(func(year):return (year is int or year is float) and float(year) == float(season_start_year)):
			return {"profiles":{},"errors":["全球成年选手补充模型无效"]}
		for federation in supplement.countries:
			if data.federation_profiles.has(federation): continue
			if not supplement.countries[federation] is Dictionary: return {"profiles":{},"errors":["全球协会模型必须为对象"]}
			var profile: Dictionary = supplement.defaults.duplicate(true)
			profile.merge(supplement.countries[federation],true)
			data.federation_profiles[federation] = profile
	var errors := _validate_federation_catalog(data, season_start_year, discipline)
	return {"profiles": Dictionary(data.get("federation_profiles", {})).duplicate(true) if errors.is_empty() else {}, "errors": errors}

static func _validate_federation_catalog(data: Dictionary, season_start_year: int, discipline: String) -> Array[String]:
	var errors: Array[String] = []
	for key in ["catalog_version", "season_start_year", "season_id", "discipline", "sources", "modeling_note", "federation_profiles"]:
		if not data.has(key): errors.append("联邦生成参数.%s 缺失" % key)
	if int(data.get("season_start_year", 0)) != season_start_year: errors.append("联邦生成参数赛季不匹配")
	if str(data.get("discipline", "")) != discipline: errors.append("联邦生成参数项目不匹配")
	var sources = data.get("sources")
	if not sources is Array or sources.is_empty(): errors.append("联邦生成参数.sources 必须是非空数组")
	else:
		for index in sources.size():
			for key in ["source_id", "title", "url", "retrieved_on"]:
				if not sources[index] is Dictionary or not sources[index].get(key) is String or str(sources[index].get(key, "")).is_empty(): errors.append("联邦生成参数.sources.%d.%s 必须是非空字符串" % [index, key])
	var profiles = data.get("federation_profiles")
	if not profiles is Dictionary or profiles.is_empty():
		errors.append("联邦生成参数.federation_profiles 必须是非空对象")
		return errors
	for federation_id in profiles:
		var path := "联邦生成参数.federation_profiles.%s" % federation_id
		var profile = profiles[federation_id]
		if not profile is Dictionary:
			errors.append("%s 必须是对象" % path)
			continue
		for field in FEDERATION_PROFILE_FIELDS:
			if not profile.has(field): errors.append("%s.%s 缺失" % [path, field])
		var pool_size = profile.get("pool_size")
		if not (pool_size is int or pool_size is float) or float(pool_size) <= 0.0 or not is_equal_approx(float(pool_size), floorf(float(pool_size))): errors.append("%s.pool_size 必须是正整数" % path)
		for field in ["mean_strength", "strength_deviation", "resource_level"]:
			if not _number_in_range(profile.get(field), 0.0, 100.0): errors.append("%s.%s 必须在0至100之间" % [path, field])
		for field in ["volatility", "late_bloomer_rate", "nationality_frequency"]:
			if not _number_in_range(profile.get(field), 0.0, 1.0): errors.append("%s.%s 必须在0至1之间" % [path, field])
		if profile.get("fictional_generation_only") != true: errors.append("%s 必须明确为虚构生成输入" % path)
		if season_start_year in [2020,2021] and federation_id != "CHN":
			var model = profile.get("technical_generation")
			if not model is Dictionary:
				errors.append("%s 缺少当季国际技术采样" % path)
				continue
			if model.get("model_version") != 1:errors.append("%s 技术采样版本无效" % path)
			for field in ["axel_triple_probability","quad_probability"]:
				if not _number_in_range(model.get(field),0.0,1.0):errors.append("%s 技术概率无效：%s" % [path,field])
			var probabilities = model.get("triple_probabilities")
			if not probabilities is Dictionary:errors.append("%s 缺少三周分布" % path)
			else:
				for id in ["toe_loop","salchow","loop","flip","lutz"]:
					if not _number_in_range(probabilities.get(id),0.0,1.0):errors.append("%s 三周概率无效" % path)
			var families=model.get("quad_families")
			if not families is Array or families.is_empty():errors.append("%s 缺少四周采样范围" % path)
			else:
				for id in families:
					if id not in ["toe_loop","salchow","loop","flip","lutz"]:errors.append("%s 四周采样范围无效" % path)
			var model_sources=model.get("source_ids")
			if not model_sources is Array or model_sources.is_empty():errors.append("%s 技术采样缺少关联来源" % path)
			elif sources is Array:
				for id in model_sources:
					if not sources.any(func(source):return source is Dictionary and source.get("source_id")==id):errors.append("%s 技术采样引用未知来源" % path)
	return errors

static func _number_in_range(value, minimum: float, maximum: float) -> bool:
	return (value is int or value is float) and float(value) >= minimum and float(value) <= maximum

static func _strings(values: Array) -> Array[String]:
	var result: Array[String] = []
	for value in values: result.append(str(value))
	return result
