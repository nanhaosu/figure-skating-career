class_name ClubCoachRepository
extends RefCounted

const CLUBS_PATH := "res://data/2014_cn/clubs.json"
const COACHES_PATH := "res://data/2014_cn/coaches.json"
const RATING_LABELS := ["突出", "可靠", "一般", "存在争议"]
const RATING_FIELDS := ["基础滑行", "跳跃技术", "旋转", "节目表现", "心理支持", "临场策略", "伤病管理", "资源渠道"]

var _clubs: Array[Dictionary] = []
var _coaches: Array[Dictionary] = []
var _errors: Array[String] = []

func _init(clubs_path: String = CLUBS_PATH, coaches_path: String = COACHES_PATH) -> void:
	var clubs_data := _read_json(clubs_path, "clubs")
	var coaches_data := _read_json(coaches_path, "coaches")
	_errors.append_array(validate_catalogs(clubs_data, coaches_data))
	if not _errors.is_empty():
		return
	for club in clubs_data.clubs:
		_clubs.append(Dictionary(club).duplicate(true))
	for coach in coaches_data.coaches:
		_coaches.append(Dictionary(coach).duplicate(true))

func errors() -> Array[String]:
	return _errors.duplicate()

func clubs() -> Array[Dictionary]:
	return _clubs.duplicate(true)

func coaches_for_club(club_id: String) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for coach in _coaches:
		if str(coach.get("club_id", "")) == club_id:
			result.append(coach.duplicate(true))
	return result

func coach_profile(coach_id: String) -> Dictionary:
	for coach in _coaches:
		if str(coach.get("id", "")) == coach_id:
			return coach.duplicate(true)
	return {}

func club_profile(club_id: String) -> Dictionary:
	for club in _clubs:
		if str(club.get("id", "")) == club_id:
			return club.duplicate(true)
	return {}

func public_coach_summary(coach_id: String) -> Dictionary:
	var coach := coach_profile(coach_id)
	coach.erase("technical_tendencies")
	coach.erase("relationship_defaults")
	return coach

func _read_json(path: String, label: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		_errors.append("%s catalog is missing: %s" % [label, path])
		return {}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK:
		_errors.append("%s catalog JSON is invalid: %s" % [label, json.get_error_message()])
		return {}
	if not json.data is Dictionary:
		_errors.append("%s catalog must be a Dictionary" % label)
		return {}
	return json.data

static func validate_catalogs(clubs_data: Dictionary, coaches_data: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not clubs_data.get("clubs") is Array:
		errors.append("clubs catalog must contain an Array")
		return errors
	if not coaches_data.get("coaches") is Array:
		errors.append("coaches catalog must contain an Array")
		return errors
	var club_ids := {}
	for index in clubs_data.clubs.size():
		var club = clubs_data.clubs[index]
		if not club is Dictionary:
			errors.append("clubs.%d must be a Dictionary" % index)
			continue
		for field in ["id", "name", "summary", "resources", "competition_pressure", "support_model"]:
			if not club.has(field): errors.append("clubs.%d.%s is required" % [index, field])
		var club_id := str(club.get("id", ""))
		if club_id.is_empty() or club_ids.has(club_id): errors.append("invalid or duplicate club id: %s" % club_id)
		club_ids[club_id] = true
	var coach_ids := {}
	for index in coaches_data.coaches.size():
		var coach = coaches_data.coaches[index]
		if not coach is Dictionary:
			errors.append("coaches.%d must be a Dictionary" % index)
			continue
		for field in ["id", "club_id", "name", "style", "history", "visible_ratings", "known_strengths", "known_concerns", "relationship_defaults", "technical_tendencies"]:
			if not coach.has(field): errors.append("coaches.%d.%s is required" % [index, field])
		var coach_id := str(coach.get("id", ""))
		if coach_id.is_empty() or coach_ids.has(coach_id): errors.append("invalid or duplicate coach id: %s" % coach_id)
		coach_ids[coach_id] = true
		var club_id := str(coach.get("club_id", ""))
		if not club_ids.has(club_id): errors.append("coach %s references unknown club %s" % [coach_id, club_id])
		var ratings = coach.get("visible_ratings", {})
		if ratings is Dictionary:
			for field in RATING_FIELDS:
				if not ratings.has(field) or not str(ratings.get(field, "")) in RATING_LABELS:
					errors.append("coach %s has invalid visible rating %s" % [coach_id, field])
		else:
			errors.append("coach %s visible_ratings must be a Dictionary" % coach_id)
	return errors
