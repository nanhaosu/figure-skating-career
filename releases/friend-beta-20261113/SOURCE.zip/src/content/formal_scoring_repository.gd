class_name FormalScoringRepository
extends RefCounted

const BASE_PATH := "res://data/rules"
const REQUIRED_KEYS := [
	"catalog_version", "season_start_year", "season_id", "discipline", "scoring_era_id",
	"sources", "jump_base_values", "non_jump_base_values", "goe_scale", "goe_percent_per_step",
	"components", "deductions", "domestic_bonus", "panel", "record_eligibility",
]
const REQUIRED_JUMPS := [
	"1T", "2T", "3T", "4T", "1S", "2S", "3S", "4S", "1Lo", "2Lo", "3Lo", "4Lo",
	"1F", "2F", "3F", "4F", "1Lz", "2Lz", "3Lz", "4Lz", "1A", "2A", "3A", "4A",
]
const REQUIRED_LEVEL_ELEMENTS := ["CCoSp", "FCSp", "LSp", "FSSp", "StSq"]

static func load_catalog(season_start_year: int, discipline: String) -> Dictionary:
	var path := BASE_PATH.path_join("%d_%d_%s_scoring.json" % [season_start_year, season_start_year + 1, discipline])
	if not FileAccess.file_exists(path):
		return {"catalog": {}, "errors": ["正式计分目录不存在：%s" % path]}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary:
		return {"catalog": {}, "errors": ["正式计分目录不是有效对象：%s" % path]}
	var catalog: Dictionary = Dictionary(json.data).duplicate(true)
	_normalize(catalog)
	var errors := validate(catalog)
	return {"catalog": catalog if errors.is_empty() else {}, "errors": errors}

static func element_value(catalog: Dictionary, abbreviation: String) -> float:
	return float(Dictionary(catalog.get("jump_base_values", {})).get(abbreviation, 0.0))

static func level_value(catalog: Dictionary, abbreviation: String, level: int) -> float:
	var table = Dictionary(catalog.get("non_jump_base_values", {})).get(abbreviation, {})
	if not table is Dictionary: return 0.0
	return float(table.get("B" if level <= 0 else str(clampi(level, 1, 4)), 0.0))

static func validate(catalog: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	for key in REQUIRED_KEYS:
		if not catalog.has(key): errors.append("%s 缺失" % key)
	if not _whole_number(catalog.get("catalog_version"), 1): errors.append("catalog_version 必须是正整数")
	if not _whole_number(catalog.get("season_start_year"), 1): errors.append("season_start_year 必须是正整数")
	var year := int(catalog.get("season_start_year", 0))
	var fictional: bool = year == 2022 and catalog.get("scoring_era_id") == "fictional_career_v1"
	var isu_three_components: bool = year >= 2022 and catalog.get("scoring_era_id") == "isu_2022_three_components"
	if str(catalog.get("season_id", "")) != "%d-%02d" % [year, (year + 1) % 100]: errors.append("season_id 必须与赛季起始年对应")
	for key in ["discipline", "scoring_era_id"]:
		if not catalog.get(key) is String or str(catalog.get(key, "")).is_empty(): errors.append("%s 必须是非空字符串" % key)
	_validate_sources(catalog.get("sources"), errors)
	if year in [2020,2021] or catalog.has("rotation_call_standard"):
		if (year not in [2020,2021] and not fictional and not isu_three_components) or catalog.get("rotation_call_standard") != "isu_2334":
			errors.append("2020/21至2021/22必须明确采用适用的ISU2334周数判定")
		var source_id = catalog.get("rotation_call_source_id")
		var source_exists := false
		if source_id is String and not source_id.is_empty() and catalog.get("sources") is Array:
			for source in catalog.sources:
				if source is Dictionary and source.get("source_id") == source_id: source_exists = true
		if not source_exists: errors.append("周数判定缺少关联的规则来源")
	var jumps = catalog.get("jump_base_values")
	if not jumps is Dictionary:
		errors.append("jump_base_values 必须是对象")
	else:
		for code in REQUIRED_JUMPS:
			if not _positive_number(jumps.get(code)): errors.append("jump_base_values.%s 必须是正数" % code)
	var non_jumps = catalog.get("non_jump_base_values")
	if not non_jumps is Dictionary:
		errors.append("non_jump_base_values 必须是对象")
	else:
		var required_elements := REQUIRED_LEVEL_ELEMENTS.duplicate()
		if year in [2020,2021] or fictional or isu_three_components: required_elements.append_array(["SSp","CSp"])
		for code in required_elements:
			var levels = non_jumps.get(code)
			if not levels is Dictionary:
				errors.append("non_jump_base_values.%s 必须是对象" % code)
				continue
			for level in ["B", "1", "2", "3", "4"]:
				if not _positive_number(levels.get(level)): errors.append("non_jump_base_values.%s.%s 必须是正数" % [code, level])
	if catalog.get("goe_scale") != [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]: errors.append("goe_scale 必须是-5至+5")
	if not _positive_number(catalog.get("goe_percent_per_step")): errors.append("goe_percent_per_step 必须是正数")
	_validate_components(catalog.get("components"), errors, isu_three_components)
	_validate_panel(catalog.get("panel"), errors)
	_validate_bonus(catalog.get("domestic_bonus"), errors, year)
	if not catalog.get("deductions") is Dictionary: errors.append("deductions 必须是对象")
	if not catalog.get("record_eligibility") is Dictionary: errors.append("record_eligibility 必须是对象")
	return errors

static func _validate_sources(value, errors: Array[String]) -> void:
	if not value is Array or value.is_empty():
		errors.append("sources 必须是非空数组")
		return
	for index in value.size():
		var source = value[index]
		if not source is Dictionary:
			errors.append("sources.%d 必须是对象" % index)
			continue
		for key in ["source_id", "title", "url", "retrieved_on"]:
			if not source.get(key) is String or str(source.get(key, "")).is_empty(): errors.append("sources.%d.%s 必须是非空字符串" % [index, key])

static func _validate_components(value, errors: Array[String], isu_three_components: bool) -> void:
	if not value is Dictionary:
		errors.append("components 必须是对象")
		return
	var expected_ids := ["skating_skills", "transitions", "performance", "composition", "interpretation"]
	if isu_three_components:
		expected_ids = ["composition", "presentation", "skating_skills"]
	if value.get("ids") != expected_ids: errors.append("components.ids 与当季内容分规则不符")
	var factors := {"short": 1.33, "free": 2.67}
	for segment in ["short", "free"]:
		var part = value.get(segment)
		if not part is Dictionary or not _positive_number(part.get("factor")):
			errors.append("components.%s.factor 必须是正数" % segment)
		elif isu_three_components and not is_equal_approx(float(part.factor), factors[segment]):
			errors.append("components.%s.factor 与三项内容分女单系数不符" % segment)

static func _validate_panel(value, errors: Array[String]) -> void:
	if not value is Dictionary:
		errors.append("panel 必须是对象")
		return
	var count = value.get("judge_count",0)
	if not (count is int or count is float) or float(count) not in [5.0,7.0,9.0]: errors.append("正式计分目录裁判人数必须为5、7或9")
	if int(value.get("trim_high_count", -1)) != 1 or int(value.get("trim_low_count", -1)) != 1: errors.append("正式裁判面板必须去掉一个最高分和一个最低分")

static func _validate_bonus(value, errors: Array[String], year:int = 2018) -> void:
	if not value is Dictionary:
		errors.append("domestic_bonus 必须是对象")
		return
	if year >= 2020:
		if value.get("policy") != "none" or not value.get("short") is Dictionary or not value.get("free") is Dictionary:
			errors.append("新赛季不可自动继承旧国内奖励，必须明确无默认奖励策略")
		elif not value.short.is_empty() or not value.free.is_empty():
			errors.append("无默认奖励策略不得夹带额外分值")
		if bool(value.get("included_in_tes",true)): errors.append("国内奖励不得计入TES")
		return
	if not value.get("short") is Dictionary or float(value.short.get("triple_triple", 0.0)) != 1.0: errors.append("国内短节目三三奖励必须为1.0")
	if not value.get("free") is Dictionary or float(value.free.get("triple_triple", 0.0)) != 1.0 or float(value.free.get("five_triple_types", 0.0)) != 2.0: errors.append("国内自由滑奖励表无效")
	if bool(value.get("included_in_tes", true)): errors.append("国内奖励不得计入TES")

static func _positive_number(value) -> bool:
	return (value is int or value is float) and float(value) > 0.0

static func _whole_number(value, minimum: int) -> bool:
	return (value is int or value is float) and is_equal_approx(float(value), floorf(float(value))) and int(value) >= minimum

static func _normalize(catalog: Dictionary) -> void:
	var goe_scale: Array = []
	for value in catalog.get("goe_scale", []): goe_scale.append(int(value))
	catalog.goe_scale = goe_scale
