class_name SeasonCalendarRepository
extends RefCounted

const BASE_PATH := "res://data/calendars"
const EVENT_FAMILIES := ["club_league_stage", "club_league_final", "national_junior", "national_grand_prix", "national_championship", "jgp_stage", "jgp_final", "world_junior", "international_open", "gp_stage", "gp_final", "four_continents", "world_championships", "olympic_games", "olympic_qualifier", "beijing_trial"]
const REQUIRED_EVENT_FIELDS := ["event_id", "name", "event_family", "scope", "sequence", "start_date", "end_date", "date_precision", "location", "level_options", "entry_route", "qualification_ids", "ranking_points_system", "ruleset_season_start_year", "record_eligibility", "sources"]

static func load_calendar(year: int, federation: String, discipline: String) -> Dictionary:
	var file_federation: String = str({"CHN": "cn"}.get(federation.to_upper(), federation.to_lower()))
	var path := BASE_PATH.path_join("%d_%s_%s.json" % [year, file_federation, discipline])
	return _load_path(path, "%d年 %s %s" % [year, federation, discipline])

static func load_international_calendar(season_start_year: int, discipline: String, level: String) -> Dictionary:
	var discipline_file: String = str({"women_singles": "women"}.get(discipline, discipline))
	var path := BASE_PATH.path_join("%d_%d_international_%s_%s.json" % [season_start_year, season_start_year + 1, level, discipline_file])
	return _load_path(path, "%d-%02d赛季国际%s %s" % [season_start_year, (season_start_year + 1) % 100, level, discipline])

static func load_historical_women_reference(season_start_year: int) -> Dictionary:
	var path := BASE_PATH.path_join("%d_%d_historical_women_reference.json" % [season_start_year, season_start_year + 1])
	return _load_path(path, "%d赛季女单历史参考" % season_start_year)

static func _load_path(path: String, description: String) -> Dictionary:
	if not FileAccess.file_exists(path): return {"calendar": {}, "errors": ["尚未收录%s赛历" % description]}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary:
		return {"calendar": {}, "errors": ["赛历文件不是有效对象：%s" % path]}
	var calendar: Dictionary = Dictionary(json.data).duplicate(true)
	var errors := validate(calendar)
	return {"calendar": calendar if errors.is_empty() else {}, "errors": errors}

static func ordered_events(data: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for raw in data.get("events", []):
		if raw is Dictionary: result.append(Dictionary(raw).duplicate(true))
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if int(a.get("sequence", 0)) != int(b.get("sequence", 0)): return int(a.get("sequence", 0)) < int(b.get("sequence", 0))
		return str(a.get("event_id", "")) < str(b.get("event_id", ""))
	)
	return result

static func chronological_events(data: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for raw in data.get("events", []):
		if raw is Dictionary: result.append(Dictionary(raw).duplicate(true))
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if str(a.get("start_date", "")) != str(b.get("start_date", "")): return str(a.get("start_date", "")) < str(b.get("start_date", ""))
		if str(a.get("end_date", "")) != str(b.get("end_date", "")): return str(a.get("end_date", "")) < str(b.get("end_date", ""))
		return str(a.get("event_id", "")) < str(b.get("event_id", ""))
	)
	return result

static func event_status(event:Dictionary) -> String:
	# Absence is the legacy catalog contract, not a cancellation guess.
	return str(event.get("status","scheduled"))

static func playable_events(data:Dictionary) -> Array[Dictionary]:
	var result:Array[Dictionary] = []
	for event in ordered_events(data):
		if event_status(event) in ["scheduled","held"] and not event.get("reference_only", false):
			result.append(event)
	return result

static func judging_panel_size(event:Dictionary) -> int:
	if event.has("judge_count_game_policy"):
		var policy=event.judge_count_game_policy
		if event.get("event_id")!="isu_gpchn2020" or int(event.get("ruleset_season_start_year",0))!=2020 or event.get("scope")!="international" or event.get("event_family")!="gp_stage":return -1
		if not policy is Dictionary or policy.get("policy")!="explicit_simulation_only" or policy.get("user_approved")!=true or policy.get("approved_on")!="2026-10-22":return -1
		if not policy.get("label") is String or not str(policy.label).contains("7人模拟裁判组") or not str(policy.label).contains("历史人数未核实"):return -1
		if event.get("judge_count")!=7 or event.get("panel_verification",{}).get("status")!="unknown" or not event.get("judge_count_source_ids",[]).is_empty():return -1
		return 7
	if not event.has("judge_count"): return 9
	var count = event.judge_count
	if not (count is int or count is float) or float(count) not in [5.0,7.0,9.0]: return -1
	var ids = event.get("judge_count_source_ids")
	var event_sources = event.get("sources")
	if not ids is Array or ids.is_empty() or not event_sources is Array: return -1
	for id in ids:
		if not id is String or not event_sources.has(id): return -1
	return int(count)

static func validate(data: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	for key in ["catalog_version", "calendar_year", "season_id", "federation", "discipline", "qualification_definitions", "sources", "events"]:
		if not data.has(key): errors.append("%s 缺失" % key)
	var qualifications = data.get("qualification_definitions")
	if not qualifications is Dictionary: errors.append("qualification_definitions 必须是对象")
	var source_ids := _validate_sources(data.get("sources"), errors)
	if data.has("coverage_policy"):
		var policy=data.coverage_policy
		if int(data.get("calendar_year",0))!=2020 or data.get("federation") not in ["CHN","ISU+CHN"] or not policy is Dictionary:
			errors.append("疫情赛历游戏处理范围无效")
		else:
			if policy.get("scope")!="domestic" or policy.get("policy")!="verified_events_only" or policy.get("historical_census_complete")!=false or policy.get("training_continues")!=true or policy.get("user_approved")!=true or policy.get("approved_on")!="2026-10-22":errors.append("疫情赛历游戏处理不得冒充完整历史或中断训练")
			if not policy.get("label") is String or not str(policy.label).contains("游戏处理"):errors.append("疫情赛历游戏处理必须显著标注")
			if not policy.get("source_ids") is Array or policy.source_ids.is_empty():errors.append("疫情赛历覆盖说明缺少来源")
			else:
				for id in policy.source_ids:
					if not source_ids.has(str(id)):errors.append("疫情赛历覆盖说明引用未知来源")
	if data.has("series_rules"): _validate_series_rules(data.series_rules,source_ids,errors)
	var events = data.get("events")
	if not events is Array:
		errors.append("events 必须是数组")
		return errors
	var ids: Array[String] = []
	for index in events.size():
		var event = events[index]
		var path := "events.%d" % index
		if not event is Dictionary:
			errors.append("%s 必须是对象" % path)
			continue
		for field in REQUIRED_EVENT_FIELDS:
			if not event.has(field): errors.append("%s.%s 缺失" % [path, field])
		var event_id := str(event.get("event_id", ""))
		_validate_status(event,path,source_ids,errors)
		if event.has("application_window"):
			_validate_application_window(event, path, source_ids, errors)
		_validate_pandemic_grand_prix(event,path,source_ids,errors)
		_validate_game_schedule(event,path,source_ids,errors)
		if judging_panel_size(event) < 0: errors.append(path+" 裁判人数或其来源无效")
		if ids.has(event_id): errors.append("%s.event_id 重复：%s" % [path, event_id])
		else: ids.append(event_id)
		if not EVENT_FAMILIES.has(str(event.get("event_family", ""))): errors.append("%s.event_family 无效" % path)
		if not ["domestic", "international"].has(str(event.get("scope", ""))): errors.append("%s.scope 无效" % path)
		if str(event.get("record_eligibility", "")).is_empty(): errors.append("%s.record_eligibility 必须是非空字符串" % path)
		if str(event.get("scope", "")) == "domestic" and str(event.get("ranking_points_system", "")) == "isu_world_standings": errors.append("%s 国内赛事不能授予ISU世界排名积分" % path)
		if str(event.get("date_precision", "")) in ["day", "scheduled_day"] and str(event.get("start_date", "")) > str(event.get("end_date", "")): errors.append("%s 日期顺序无效" % path)
		if str(event.get("event_family", "")) == "national_junior": _validate_formal_national_event(event, path, errors)
		var qualification_ids = event.get("qualification_ids", [])
		if qualification_ids is Array and qualifications is Dictionary:
			for qualification_id in qualification_ids:
				if not qualifications.has(qualification_id): errors.append("%s.qualification_ids 引用了未知资质：%s" % [path, qualification_id])
		var event_sources = event.get("sources")
		if not event_sources is Array or event_sources.is_empty():
			errors.append("%s.sources 必须是非空数组" % path)
		else:
			for source_id in event_sources:
				if not source_ids.has(str(source_id)): errors.append("%s.sources 引用了未知来源：%s" % [path, source_id])
	return errors

static func _validate_application_window(event: Dictionary, path: String, source_ids: Array[String], errors: Array[String]) -> void:
	var window = event.application_window
	if not window is Dictionary:
		errors.append(path + " 报名窗口必须是对象")
		return
	var opens := str(window.get("opens", ""))
	var closes := str(window.get("closes", ""))
	if not _notice_date_valid(opens) or not _notice_date_valid(closes) or opens > closes or closes > str(event.get("start_date", "")):
		errors.append(path + " 报名窗口日期无效")
	var source_id := str(window.get("source_id", ""))
	if not source_ids.has(source_id) or not event.get("sources", []).has(source_id):
		errors.append(path + " 报名窗口缺少关联来源")

static func _validate_pandemic_grand_prix(event:Dictionary,path:String,source_ids:Array[String],errors:Array[String]) -> void:
	# ISU2339 is a 2020/21 GP exception, not a blanket ban on international TES.
	if int(event.get("ruleset_season_start_year",0)) != 2020 or event.get("event_family") != "gp_stage": return
	if event.get("host_federation") not in ["USA","CAN","CHN","FRA","RUS","JPN"]:
		errors.append(path+" 2020疫情大奖赛缺少有效举办国")
	if event.get("scope") != "international" or event.get("ranking_points_system") != "none":
		errors.append(path+" 2020疫情大奖赛不能授予世界排名或国内积分")
	if event_status(event) != "cancelled" and event.get("record_eligibility") != "domestic_only":
		errors.append(path+" 2020疫情大奖赛成绩不可认作国际纪录或国际最低TES")
	var policy = event.get("pandemic_policy")
	if not policy is Dictionary:
		errors.append(path+" 2020疫情大奖赛缺少特殊政策")
		return
	for key in ["international_minimum_tes_eligible","world_standing_points_eligible"]:
		if not policy.get(key) is bool or policy.get(key) != false: errors.append(path+" 疫情政策必须明确禁止"+key)
	if policy.get("entry_policy") != "host_training_or_geographic_assignment" or policy.get("officials_policy") != "host_country":
		errors.append(path+" 疫情大奖赛邀请或裁判来源政策不符")
	var id = policy.get("source_id")
	if not id is String or not source_ids.has(id) or not event.get("sources",[]).has(id):
		errors.append(path+" 疫情政策来源未关联")

static func _validate_game_schedule(event:Dictionary,path:String,source_ids:Array[String],errors:Array[String]) -> void:
	if event.get("date_precision") != "game_schedule" or int(event.get("ruleset_season_start_year",0)) < 2020: return
	var window = event.get("game_schedule_window")
	if not window is Dictionary:
		errors.append(path+" 游戏赛期必须有已核实的来源窗口")
		return
	for date in [event.get("start_date",""),event.get("end_date",""),window.get("start",""),window.get("end","")]:
		if not date is String or not _notice_date_valid(str(date)):
			errors.append(path+" 游戏赛期或窗口日期无效")
			return
	if not (window.start <= event.start_date and event.start_date <= event.end_date and event.end_date <= window.end):
		errors.append(path+" 游戏赛期超出来源窗口")
	var ids = window.get("source_ids")
	if not ids is Array or ids.is_empty():
		errors.append(path+" 游戏赛期窗口来源缺失")
	else:
		for id in ids:
			if not id is String or not source_ids.has(id) or not event.get("sources",[]).has(id): errors.append(path+" 游戏赛期窗口来源未关联")

static func _validate_series_rules(value,source_ids:Array[String],errors:Array[String]) -> void:
	if not value is Dictionary:
		errors.append("series_rules 必须是对象")
		return
	for id in value:
		if not id is String or str(id).strip_edges().is_empty():
			errors.append("series_rules 系列ID无效")
		var policy = value[id]
		if not policy is Dictionary or policy.is_empty():
			errors.append("series_rules.%s 必须是非空规则对象" % id)
			continue
		for field in policy:
			if str(field).ends_with("_source_id") and (not policy[field] is String or not source_ids.has(policy[field])):
				errors.append("series_rules.%s.%s 来源未关联" % [id,field])

static func _validate_status(event:Dictionary,path:String,source_ids:Array[String],errors:Array[String]) -> void:
	var status := event_status(event)
	if status not in ["scheduled","held","cancelled"]:
		errors.append(path+".status 无效")
		return
	if status != "cancelled":
		if event.has("cancellation"): errors.append(path+" 非取消赛事不能附取消通知")
		return
	if event.get("record_eligibility") != "none": errors.append(path+" 取消赛事不能授予正式成绩")
	if event.get("ranking_points_system") != "none": errors.append(path+" 取消赛事不能授予积分")
	var notice = event.get("cancellation")
	if not notice is Dictionary:
		errors.append(path+" 缺少取消通知")
		return
	if not notice.get("reason") is String or str(notice.get("reason","")).strip_edges().is_empty(): errors.append(path+" 取消原因缺失")
	if not _notice_date_valid(str(notice.get("announced_on",""))): errors.append(path+" 取消公告日期无效")
	if not notice.get("source_ids") is Array or notice.get("source_ids",[]).is_empty():
		errors.append(path+" 取消公告缺少来源")
	else:
		for id in notice.source_ids:
			if not id is String or not source_ids.has(id) or not event.get("sources",[]).has(id): errors.append(path+" 取消公告来源未与赛事关联")

static func _notice_date_valid(value:String) -> bool:
	var regex := RegEx.new()
	regex.compile("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
	if regex.search(value) == null: return false
	var year := int(value.substr(0,4))
	var month := int(value.substr(5,2))
	var day := int(value.substr(8,2))
	if year < 1 or month < 1 or month > 12: return false
	var days := [31,29 if year%4 == 0 and (year%100 != 0 or year%400 == 0) else 28,31,30,31,30,31,31,30,31,30,31]
	return day >= 1 and day <= int(days[month-1])

static func _validate_sources(value, errors: Array[String]) -> Array[String]:
	var ids: Array[String] = []
	if not value is Array or value.is_empty():
		errors.append("sources 必须是非空数组")
		return ids
	for index in value.size():
		var source = value[index]
		if not source is Dictionary:
			errors.append("sources.%d 必须是对象" % index)
			continue
		for key in ["source_id", "title", "url", "retrieved_on"]:
			if not source.get(key) is String or str(source.get(key, "")).is_empty(): errors.append("sources.%d.%s 必须是非空字符串" % [index, key])
		var source_id := str(source.get("source_id", ""))
		if source_id.is_empty(): continue
		if ids.has(source_id): errors.append("sources.%d.source_id 重复：%s" % [index, source_id])
		else: ids.append(source_id)
	return ids

static func _validate_formal_national_event(event: Dictionary, path: String, errors: Array[String]) -> void:
	for key in ["announced_dates", "actual_dates", "admission_policy", "record_eligibility", "formal_scoring_catalog"]:
		if not event.has(key): errors.append("%s.%s 缺失" % [path, key])
	for key in ["announced_dates", "actual_dates"]:
		var dates = event.get(key)
		if not dates is Dictionary or not dates.get("start") is String or not dates.get("end") is String:
			errors.append("%s.%s 必须包含起止日期" % [path, key])
		elif str(dates.start) > str(dates.end): errors.append("%s.%s 日期顺序无效" % [path, key])
	var policy = event.get("admission_policy")
	if not policy is Dictionary:
		errors.append("%s.admission_policy 必须是对象" % path)
		return
	if int(event.get("ruleset_season_start_year",2018)) >= 2020:
		_validate_sourced_admission(policy,event,path,errors)
		return
	if policy.get("explicit_exemptions") != ["HKG", "MAC"]: errors.append("%s.admission_policy 必须准确记录港澳明文豁免" % path)
	var routes = policy.get("review_routes")
	if not routes is Dictionary or not routes.get("TPE") is Array: errors.append("%s.admission_policy 必须记录中国台北审核路径" % path)
	elif Array(routes.TPE).any(func(route): return not ["club_filing", "invitation", "federation_review"].has(str(route))): errors.append("%s.admission_policy 中国台北审核路径无效" % path)

static func _validate_sourced_admission(policy:Dictionary,event:Dictionary,path:String,errors:Array[String]) -> void:
	var source_id = policy.get("source_id")
	if not source_id is String or source_id.is_empty() or not event.get("sources",[]).has(source_id):
		errors.append("%s.admission_policy 缺少关联的当季来源" % path)
	var grade = policy.get("min_grade")
	if not (grade is int or grade is float) or float(grade) < 1.0 or float(grade) != floorf(float(grade)):
		errors.append("%s.admission_policy 技术等级必须是正整数" % path)
	if policy.get("grade_categories") != ["steps_performance","free_skating"]:
		errors.append("%s.admission_policy 必须分别保留步法表演和自由滑等级" % path)
	var birth = policy.get("birth_date_range")
	if not birth is Dictionary or not _notice_date_valid(str(birth.get("start",""))) or not _notice_date_valid(str(birth.get("end",""))) or str(birth.get("start","")) > str(birth.get("end","")):
		errors.append("%s.admission_policy 出生日期窗口无效" % path)
	var tes = policy.get("minimum_tes")
	if not tes is Dictionary or tes.get("status") not in ["unknown","verified"] or tes.get("designated_events_only") != true:
		errors.append("%s.admission_policy 最低技术分必须保留核实状态与指定赛事限制" % path)
	elif tes.status == "unknown":
		if tes.get("short") != null or tes.get("free") != null: errors.append("%s.admission_policy 未知TES不可夹带猜测数值" % path)
	else:
		for segment in ["short","free"]:
			var value = tes.get(segment)
			if not (value is int or value is float) or float(value) <= 0.0: errors.append("%s.admission_policy 已核实TES必须是正数" % path)
	if tes is Dictionary and tes.has("game_fallback"):
		var fallback = tes.game_fallback
		if str(event.get("scope","")) != "domestic" or tes.get("status") != "unknown":
			errors.append("%s.admission_policy 国内未知TES兜底不得替代国际或已核实门槛" % path)
		if not fallback is Dictionary or fallback.get("policy") != "verified_domestic_requirements_only" or fallback.get("basis") != "explicit_user_approval" or fallback.get("label") != "游戏兜底规则" or not _notice_date_valid(str(fallback.get("approved_on",""))):
			errors.append("%s.admission_policy 游戏兜底必须有明确授权和可见游戏规则标记" % path)
	if not policy.get("explicit_exemptions") is Array:
		errors.append("%s.admission_policy 明文豁免必须显式列出，不能继承旧季" % path)
	var routes = policy.get("review_routes")
	if not routes is Dictionary:
		errors.append("%s.admission_policy 审核路径必须是对象" % path)
		return
	for region in routes:
		if not routes[region] is Array or routes[region].is_empty() or routes[region].any(func(route):return route != "federation_review"):
			errors.append("%s.admission_policy 核准参加不得偷换为自动资格" % path)
