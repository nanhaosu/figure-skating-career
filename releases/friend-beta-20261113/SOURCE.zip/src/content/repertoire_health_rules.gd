class_name RepertoireHealthRules
extends RefCounted

const PATH := "res://data/balance/repertoire_health_v1.json"
static var _cached: Dictionary = {}

static func load_rules() -> Dictionary:
	if _cached.is_empty():
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
		if not parsed is Dictionary or not validate(parsed).is_empty():
			push_error("技术储备规则配置无效")
			return {}
		_cached = parsed
	return _cached.duplicate(true)

static func validate(rules: Dictionary) -> String:
	for field in ["version","evidence_window","evidence_limit","entry_batches","entry_attempts","entry_successes","stable_batches","stable_attempts","warning_batches","warning_attempts","withdraw_batches","withdraw_attempts"]:
		var value = rules.get(field)
		if not (value is int or value is float) or not is_finite(float(value)) or float(value) <= 0 or float(value) != floorf(float(value)):
			return "技术储备规则 %s 必须为正整数" % field
	for field in ["entry_rate","stable_rate","warning_rate","withdraw_rate","stage_base_risk","stage_major_fraction","stage_overload_risk"]:
		var value = rules.get(field)
		if not (value is int or value is float) or not is_finite(float(value)) or float(value) < 0 or float(value) > 1:
			return "技术储备规则 %s 必须在0至1之间" % field
	if int(rules.evidence_window) > int(rules.evidence_limit) or int(rules.evidence_limit) > 32:
		return "技术储备窗口超过证据上限"
	return ""
