class_name HistoricalAthleteProfileRepository
extends RefCounted
const PATH := "res://data/athlete_generation/women_singles_historical_profiles.json"
const JUMPS := ["toe_loop","salchow","loop","flip","lutz","axel"]
static func load_catalog() -> Dictionary:
	var value = JSON.parse_string(FileAccess.get_file_as_string(PATH))
	if not value is Dictionary: return {"errors":["历史选手档案无法读取"]}
	value["errors"] = validate_catalog(value)
	return value
static func validate_catalog(catalog: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	if not catalog.get("profiles") is Array or not catalog.get("sources") is Array: return ["历史档案缺少 profiles/sources"]
	var source_ids := {}
	for source in catalog.sources:
		if not source is Dictionary or str(source.get("id", "")).is_empty():
			errors.append("无效来源")
			continue
		source_ids[str(source.id)] = true
	for p in catalog.profiles:
		if not p is Dictionary: errors.append("历史档案不是对象"); continue
		for key in ["id","discipline","year_from","year_to","federation","age_min","age_max","event_tier","archetype_shares","jump_distributions","spin_step_ranges","pcs_ranges","familiarity_ranges","source_ids","modeling_note","maximum_axel","maximum_non_axel"]:
			if not p.has(key): errors.append("历史档案缺少%s" % key)
		if not errors.is_empty(): continue
		var valid_types := true
		for key in ["archetype_shares","jump_distributions","spin_step_ranges","pcs_ranges","familiarity_ranges"]:
			if not p[key] is Dictionary: valid_types = false
		if not p.source_ids is Array: valid_types = false
		if not valid_types:
			errors.append("历史档案字段类型无效")
			continue
		for source_id in p.source_ids:
			if not source_ids.has(str(source_id)): errors.append("历史档案引用未知来源")
		if int(p.year_from) > int(p.year_to) or int(p.age_min) > int(p.age_max): errors.append("历史档案边界倒置")
		var total := 0.0
		for archetype in ["development","middle","top"]:
			total += float(p.archetype_shares.get(archetype,-100))
			if not p.jump_distributions.get(archetype) is Dictionary: errors.append("缺少跳跃分布"); continue
			var distribution: Dictionary = p.jump_distributions[archetype]
			for jump in JUMPS:
				if not distribution.has(jump) or float(distribution[jump]) < 0 or float(distribution[jump]) > 1: errors.append("无效跳跃概率")
			for jump in distribution:
				if not JUMPS.has(jump): errors.append("未知跳跃")
			for group in ["spin_step_ranges","pcs_ranges","familiarity_ranges"]:
				var bounds = p[group].get(archetype,[])
				if not bounds is Array or bounds.size() != 2: errors.append("无效范围")
				elif float(bounds[0]) < 0 or float(bounds[1]) > 100 or float(bounds[0]) > float(bounds[1]): errors.append("无效范围")
		if not is_equal_approx(total,100.0): errors.append("原型权重不等于100")
		if int(p.maximum_axel) > 2 or int(p.maximum_non_axel) > 3: errors.append("超出历史技术上限")
		if p.source_ids.is_empty() or str(p.modeling_note).is_empty(): errors.append("缺少依据说明")
	return errors
static func profile_for(year: int, federation: String, age: int, event_tier: String, catalog_snapshot: Dictionary = {}) -> Dictionary:
	var catalog := load_catalog() if catalog_snapshot.is_empty() else catalog_snapshot
	var errors := validate_catalog(catalog)
	if not errors.is_empty(): return {"errors":errors}
	for p in catalog.profiles:
		if p.federation == federation and p.event_tier == event_tier and year >= int(p.year_from) and year <= int(p.year_to) and age >= int(p.age_min) and age <= int(p.age_max):
			var result: Dictionary = p.duplicate(true)
			result["errors"] = []
			return result
	return {"errors":["没有对应年代、年龄和组别的历史档案"]}
static func age_on_july_first(birth_date: String, year: int) -> int:
	return year - int(birth_date.left(4)) - (1 if birth_date.substr(5) > "07-01" else 0)

