class_name InternationalParticipationPolicy
extends RefCounted

const SOURCE := "https://www.isu.org/en/news/isu-statement-on-the-ukrainian-crisis-participation-in-international-competitions-of-skaters-and-officials-from-russia-and-belarus"
const EFFECTIVE := "2022-03-01"

static func permitted(event: Dictionary, federation: String) -> bool:
	if int(event.get("ruleset_season_start_year",0)) == 2022 and event.get("world_mode") == "fictional":
		return true
	# Apply to the event, never rewrite athletes or earlier Olympic archives.
	# BLR is Belarus; BEL is Belgium and must remain eligible.
	return not (event.get("scope") == "international" and str(event.get("start_date","")) >= EFFECTIVE and federation in ["RUS","BLR"])
