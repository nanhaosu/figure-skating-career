class_name SkatingWorldContextRepository
extends RefCounted

const GENERIC := "国内与国际是两把尺：中国花滑各项目的实力不同，本游戏关注女子单人滑。国内前列不自动等于国际领奖台，JGP各站的阵容也不同。派遣机会、首次出场与争夺奖牌，是不同阶段；这不是给你的生涯设定上限。"

static func for_clock(clock: Dictionary = {}) -> Dictionary:
	var result := {"id":"generic","text":GENERIC,"source_urls":[],"as_of":""}
	if clock.is_empty(): return result
	var year := int(clock.get("year",0))
	var quarter := int(clock.get("quarter",0))
	if year < 1 or quarter < 1 or quarter > 4: return result
	var cutoff := "%04d-%02d-01" % [year,1+(quarter-1)*3]
	var rows = JSON.parse_string(FileAccess.get_file_as_string("res://data/history/women_world_context.json"))
	if not rows is Array: return result
	for row in rows:
		if not row is Dictionary: continue
		if row.get("discipline") != "women_singles" or row.get("level") != "junior": continue
		if year < int(row.get("from_year",0)) or year > int(row.get("through_year",0)): continue
		var date := str(row.get("as_of",""))
		if date.is_empty() or date > cutoff or date < str(result.as_of): continue
		if not row.get("source_urls") is Array or row.source_urls.is_empty(): continue
		result = {"id":str(row.id),"text":str(row.text),"source_urls":row.source_urls.duplicate(),"as_of":date}
	return result
