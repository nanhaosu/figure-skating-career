class_name HistoricalEvidenceRepository
extends RefCounted

# This index records human-audited support, not a network truth detector.
# A document's authority never automatically certifies every claim in it.
static func load_catalog(path:String) -> Dictionary:
	if not FileAccess.file_exists(path): return {"catalog":{},"errors":["证据目录不存在："+path]}
	var json := JSON.new()
	if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary:
		return {"catalog":{},"errors":["证据目录不是有效对象"]}
	var errors := validate(json.data)
	return {"catalog":json.data.duplicate(true) if errors.is_empty() else {},"errors":errors}

static func resolve(catalog:Dictionary,claim_id:String,as_of:String) -> Dictionary:
	var errors := validate(catalog)
	if not _date_valid(as_of): errors.append("查询日期无效")
	if not errors.is_empty(): return _result("unknown",null,[],errors)
	var sources := {}
	for source in catalog.sources: sources[source.source_id] = source
	var active := {}
	for record in catalog.claims:
		if record.claim_id != claim_id: continue
		if str(record.effective_from) > as_of or str(record.effective_to) < as_of: continue
		var source:Dictionary = sources.get(record.source_id,{})
		if not source.is_empty() and str(source.published_on) > as_of: continue
		active[record.record_id] = record
	var replaced := {}
	for record in active.values():
		for prior in record.supersedes: _collect_prior(prior,catalog.claims,replaced)
	var remaining:Array = active.values().filter(func(record): return not replaced.has(record.record_id))
	if remaining.is_empty(): return _result("unknown",null,[])
	var ids:Array = []
	var value:Variant = remaining[0].value
	var unknown := false
	var conflicting := false
	for record in remaining:
		if not str(record.source_id).is_empty() and not ids.has(record.source_id): ids.append(record.source_id)
		if record.verification_status != "verified": unknown = true
		elif record.value != value: conflicting = true
	ids.sort()
	if unknown: return _result("unknown",null,ids)
	if conflicting: return _result("conflicting",null,ids)
	return _result("verified",value,ids)

static func validate(data:Dictionary) -> Array[String]:
	var errors:Array[String] = []
	if data.get("catalog_version") != 1: errors.append("证据目录版本无效")
	if not data.get("sources") is Array or not data.get("claims") is Array:
		return ["sources和claims必须为数组"]
	var sources := {}
	for raw in data.sources:
		if not raw is Dictionary:
			errors.append("来源必须为对象"); continue
		var id := str(raw.get("source_id",""))
		if not raw.get("source_id") is String: errors.append("来源ID必须是字符串")
		if id.is_empty() or sources.has(id): errors.append("来源ID为空或重复")
		sources[id] = raw
		for field in ["title","url","kind","published_on","verified_on"]:
			if not raw.get(field) is String or str(raw.get(field,"")).strip_edges().is_empty(): errors.append("来源缺少"+field)
		if not _https_valid(str(raw.get("url",""))): errors.append("来源URL必须为有效HTTPS地址")
		if not ["official_primary","official_mirror","official_report","secondary"].has(raw.get("kind")): errors.append("来源类别无效")
		if not _date_valid(str(raw.get("published_on",""))) or not _date_valid(str(raw.get("verified_on",""))): errors.append("来源日期无效")
		elif str(raw.verified_on) < str(raw.published_on): errors.append("核验早于发布时间")
	var records := {}
	var scopes := {}
	for raw in data.claims:
		if not raw is Dictionary:
			errors.append("事实记录必须为对象"); continue
		for field in ["record_id","claim_id","scope","locator","effective_from","effective_to","verification_status"]:
			if not raw.get(field) is String or str(raw.get(field,"")).strip_edges().is_empty(): errors.append("事实记录缺少"+field)
		var id := str(raw.get("record_id",""))
		if records.has(id): errors.append("事实记录ID重复")
		records[id] = raw
		var claim := str(raw.get("claim_id",""))
		if scopes.has(claim) and scopes[claim] != raw.get("scope"): errors.append("同一claim_id不可跨适用范围")
		scopes[claim] = raw.get("scope")
		if not _date_valid(str(raw.get("effective_from",""))) or not _date_valid(str(raw.get("effective_to",""))): errors.append("事实生效日期无效")
		elif str(raw.effective_from) > str(raw.effective_to): errors.append("事实生效范围倒置")
		var status := str(raw.get("verification_status",""))
		if not ["verified","unknown"].has(status): errors.append("核验状态无效")
		if not raw.has("value"): errors.append("事实记录缺少value")
		if not raw.get("source_id") is String: errors.append("事实记录缺少source_id")
		var source_id := str(raw.get("source_id",""))
		if not source_id.is_empty() and not sources.has(source_id): errors.append("引用未知来源")
		if status == "verified":
			if raw.get("value") == null: errors.append("已核实事实不可为空")
			if not sources.has(source_id): errors.append("已核实事实缺少来源")
			elif sources[source_id].get("kind") == "secondary": errors.append("二手评论不能确认正式规则")
		elif raw.get("value") != null: errors.append("未知事实不可携带猜测值")
		if not raw.get("supersedes") is Array: errors.append("supersedes必须为数组")
	# Validate the graph before resolving; a cycle must never recurse at runtime.
	if not errors.is_empty(): return errors
	for record in data.claims:
		for prior in record.supersedes:
			if not prior is String or not records.has(prior): errors.append("替代关系引用不存在记录")
			elif records[prior].claim_id != record.claim_id or records[prior].scope != record.scope: errors.append("替代关系跨事实或范围")
		if _has_cycle(record.record_id,records,{}): errors.append("替代关系成环")
	return errors

static func _has_cycle(id:String,records:Dictionary,visiting:Dictionary) -> bool:
	if visiting.has(id): return true
	if not records.has(id): return false
	var next := visiting.duplicate()
	next[id] = true
	for prior in records[id].supersedes:
		if prior is String and _has_cycle(prior,records,next): return true
	return false

static func _collect_prior(id:String,records:Array,replaced:Dictionary) -> void:
	if replaced.has(id): return
	replaced[id] = true
	for record in records:
		if record.record_id == id:
			for prior in record.supersedes: _collect_prior(prior,records,replaced)

static func _result(status:String,value:Variant,ids:Array,errors:Array=[]) -> Dictionary:
	var copied:Variant = value.duplicate(true) if value is Dictionary or value is Array else value
	return {"status":status,"value":copied,"source_ids":ids.duplicate(),"errors":errors.duplicate()}

static func _https_valid(url:String) -> bool:
	var regex := RegEx.new()
	regex.compile("^https://[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\\.[A-Za-z]{2,}(?:[/?#][^\\s]*)?$")
	return regex.search(url) != null

static func _date_valid(value:String) -> bool:
	var regex := RegEx.new()
	regex.compile("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
	if regex.search(value) == null: return false
	var year := int(value.substr(0,4))
	var month := int(value.substr(5,2))
	var day := int(value.substr(8,2))
	if year < 1 or month < 1 or month > 12: return false
	var days := [31,29 if year%4 == 0 and (year%100 != 0 or year%400 == 0) else 28,31,30,31,30,31,31,30,31,30,31]
	return day >= 1 and day <= int(days[month-1])
