class_name BeijingQualificationPolicy
extends RefCounted

const Evidence=preload("res://src/content/historical_evidence_repository.gd")
const DATA="res://data/qualification/beijing_2022_adopted_policy.json"
const EVIDENCE="res://data/qualification/beijing_2022_evidence.json"

# Adoption is an explicit game decision. It never promotes an unexamined
# historical-final claim to verified, and it does not grant athlete eligibility.
static func load_policy() -> Dictionary:
	if not FileAccess.file_exists(DATA):return {"policy":{},"errors":["北京采用资格规则不存在"]}
	var data=JSON.parse_string(FileAccess.get_file_as_string(DATA))
	if not data is Dictionary:return {"policy":{},"errors":["北京采用资格规则不是对象"]}
	var errors:=validate(data)
	if errors.is_empty():data.valid_season_start_years=[2019,2020,2021]
	return {"policy":data.duplicate(true) if errors.is_empty() else {},"errors":errors}

static func validate(data:Dictionary) -> Array[String]:
	var errors:Array[String]=[]
	if data.get("policy_id")!="beijing2022_women_2395_adopted" or data.get("scope")!="2021-22/olympics/women/individual":errors.append("采用资格规则范围无效")
	if data.get("user_approved")!=true or data.get("approved_on")!="2026-10-22":errors.append("采用资格规则缺少明确授权")
	if data.get("final_historical_verification")!="unknown":errors.append("游戏采用规则不得认证未核实的历史最终版")
	var label=data.get("label")
	if not label is String or not str(label).contains("最终修订未核实") or not str(label).contains("2395"):errors.append("采用资格规则必须显示版本及未核实提示")
	if data.get("source_id")!="isu2395_20210607" or str(data.get("source_locator","")).is_empty():errors.append("采用资格规则来源未关联")
	if data.get("earned_level")!="senior" or data.get("record_scope")!="isu_recognized":errors.append("不能以青年或国内成绩替代成年国际TES")
	var window=data.get("valid_season_start_years")
	var valid_window:bool=window is Array and window.size()==3
	if valid_window:
		for i in 3:
			if not (window[i] is int or window[i] is float) or float(window[i])!=float(2019+i):valid_window=false
	if not valid_window:errors.append("采用规则成绩窗口必须为公告核实的三赛季")
	var loaded:=Evidence.load_catalog(EVIDENCE)
	if not loaded.errors.is_empty():
		errors.append_array(loaded.errors)
		return errors
	var snapshot:=Evidence.resolve(loaded.catalog,"beijing_women_tes_2395","2022-01-24")
	if snapshot.status!="verified" or not snapshot.value is Dictionary:
		errors.append("采用的2395原始最低TES尚未核实")
		return errors
	var expected={"short":snapshot.value.short,"free":snapshot.value.free}
	if data.get("minimum_tes")!=expected:errors.append("采用最低TES不得偏离已核实公告")
	return errors
