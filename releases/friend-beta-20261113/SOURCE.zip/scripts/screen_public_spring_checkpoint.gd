extends SceneTree

# Frozen eight-seed screen: this reporter reads only current visible skills,
# program legality/familiarity and already archived starts. It never scores a
# future event, requests selection, reads future random streams or edits state.
func _initialize() -> void: call_deferred("run")

func run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.is_empty(): push_error("Expected seed or existing Q2 save path"); quit(1); return
	var c
	var trace := []
	if args[0].is_valid_int():
		var seed_value := int(args[0])
		if seed_value < 41041 or seed_value > 41048: push_error("Seed outside frozen eight-candidate pool"); quit(1); return
		var created: Dictionary = load("res://src/simulation/career_factory.gd").create("林澄",2006,"entry_club_trial","family_ambitious",seed_value,load("res://src/content/catalog_repository.gd").load_catalog(),4)
		if not created.errors.is_empty(): push_error(str(created.errors)); quit(1); return
		var result: Dictionary = await load("res://scripts/international_season_journey.gd").new().run(created.career,true,"spring_ready")
		if not result.errors.is_empty(): push_error(str(result.errors)); quit(1); return
		c = result.career
		trace = result.trace
		var saved: Dictionary = load("res://src/persistence/save_repository.gd").save(c,"user://spring-screen-%d.json" % seed_value)
		if not saved.ok: push_error(str(saved.errors)); quit(1); return
	else:
		var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(args[0])
		if not loaded.ok: push_error(str(loaded.errors)); quit(1); return
		c = loaded.career
	if c.clock.year != 2019 or c.clock.quarter != 2: push_error("Refusing non-Q2 checkpoint"); quit(1); return
	var jumps := {}
	var unlocked := true
	for id in ["toe_loop","salchow","loop","flip","lutz","axel"]:
		var jump = c.athlete.jumps[id]
		var rotation := 2 if id == "axel" else 3
		jumps[id] = {"rotations":jump.unlocked_rotations,"proficiency":jump.proficiency["double" if id == "axel" else "triple"],"official":jump.consistency.official}
		unlocked = unlocked and jump.unlocked_rotations >= rotation
	var validations := {}
	var familiarities := {}
	for segment in ["short","free"]:
		validations[segment] = load("res://src/simulation/program_validator.gd").validate(load("res://src/domain/skating_program.gd").from_dict(c.active_programs[segment]),c.athlete,load("res://src/content/internal_event_rules.gd").for_season(2019,"junior",segment))
		familiarities[segment] = c.active_programs[segment].get("whole_run_familiarity",0)
	var injuries: Array = c.condition_state.injuries.filter(func(i): return i.get("status") == "active")
	var starts := []
	var cut_count := 0
	for archive in c.competition_archive:
		if archive.get("world_only",false): continue
		for row in archive.get("final_standings",[]):
			if row.get("athlete_id") != "player": continue
			var cut := float(row.get("free_score",0)) == 0
			if cut: cut_count += 1
			starts.append({"event_id":archive.event_id,"short_score":row.get("short_score",0),"free_score":row.get("free_score",0),"cut":cut})
	var mean_official: float = (jumps.loop.official+jumps.toe_loop.official+jumps.axel.official)/3.0
	print("SPRING_SCREEN ",JSON.stringify({"seed":c.seed,"clock":c.clock.to_dict(),"eligible":unlocked and injuries.is_empty() and validations.short.is_empty() and validations.free.is_empty(),"core_official_mean":mean_official,"jumps":jumps,"familiarity":familiarities,"validator_errors":validations,"body":c.athlete.body,"injuries":injuries,"past_starts":starts,"past_cut_count":cut_count,"past_start_count":starts.size(),"trace":trace}))
	quit(0)
