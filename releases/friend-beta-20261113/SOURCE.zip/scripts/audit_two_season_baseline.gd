extends RefCounted

# Instrument the existing public journey; never edit abilities or results here.
var _journey = preload("res://scripts/international_season_journey.gd").new()
var main:
	get: return _journey.main
	set(value): _journey.main = value
var errors: Array[String]:
	get: return _journey.errors

func _adopt(career) -> void:
	_journey._adopt(career)

func _handle_node(node: Dictionary, bundle: Dictionary) -> void:
	await _journey._handle_node(node,bundle)

func run(career, route_id: String) -> Dictionary:
	var started := Time.get_ticks_msec()
	if route_id not in ["planned","steady"]:
		return {"trace":[],"elapsed_ms":0,"errors":["unsupported_baseline_route:"+route_id],"last_node":""}
	var result: Dictionary = await _journey.run(career,route_id == "planned")
	result.elapsed_ms = Time.get_ticks_msec()-started
	result.last_node = _journey.trace.back() if not _journey.trace.is_empty() else ""
	result.scope = "legacy_public_journey_baseline_not_focus_route_calibration"
	return result
