extends SceneTree

const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")
const GameClock = preload("res://src/domain/game_clock.gd")
const FormalRosterGenerator = preload("res://src/simulation/formal_roster_generator.gd")
const CalendarRepository = preload("res://src/content/season_calendar_repository.gd")
const FormalCompetitionSimulator = preload("res://src/simulation/formal_competition_simulator.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")

func _initialize() -> void:
	var scenario := "qualify"; var output := "user://formal-competition-qualify.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--scenario="): scenario = argument.trim_prefix("--scenario=")
		if argument.begins_with("--output="): output = argument.trim_prefix("--output=")
	if not scenario in ["qualify", "cut"]: push_error("scenario 只支持 qualify 或 cut"); quit(2); return
	var created := CareerFactory.create("林心宁" if scenario == "qualify" else "沈若冰", 2007, "entry_interest_class", "family_supportive", 12001, CatalogRepository.load_catalog(), 4)
	if created.career == null: push_error("无法创建验收角色：%s" % ", ".join(created.errors)); quit(1); return
	var career = created.career; career.clock = GameClock.new(2018, 3); career.athlete.birth_year = 2004
	_set_strength(career.athlete, 96.0 if scenario == "qualify" else 4.0)
	career.athlete.jumps.lutz.takeoff.edge_quality = 48.0; career.athlete.jumps.lutz.takeoff.edge_stability = 51.0
	career.active_programs = {"short":_program("demo-sp", "short").to_dict(), "free":_program("demo-fs", "free").to_dict()}
	career.record_book = {"all_formal":{"isu_iqs_2018_plus":{"short":{"pb":48.2,"pb_meta":{},"sb":{}},"free":{"pb":82.1,"pb_meta":{},"sb":{}},"total":{"pb":130.3,"pb_meta":{},"sb":{}}}},"international":{}}
	var event := _event(); var event_id := str(event.event_id)
	career.season_state = {"season_id":"2018-19", "entry_plan":{"season_id":"2018-19","proposal_version":1,"entries":{event_id:{"status":"confirmed","requested_levels":["junior"],"route":"federation_approved_unit","funding_source":"club","coach_recommendation":"建议参赛","player_override":"enter","available_adjustment_ids":["enter","skip"],"eligibility_snapshot":{"eligible":true,"hard_gate_codes":[],"warnings":[]},"reason_codes":["formal_debut"]}}},"qualification_state":{"cfsa_registered":true,"club_final_top_six":false},"event_statuses":{event_id:"confirmed"}}
	career.competition_state = FormalCompetitionSimulator.create_session(career, event, career.active_programs, "balanced", 12001, 34)
	var saved := SaveRepository.save(career, output)
	if not saved.ok: push_error("无法保存验收档：%s" % ", ".join(saved.errors)); quit(1); return
	print("FORMAL_DEMO_SAVE=%s" % output); print("FORMAL_DEMO_SCENARIO=%s" % scenario); print("FORMAL_DEMO_NAME=%s" % career.athlete.display_name); quit(0)

func _event() -> Dictionary:
	for event in CalendarRepository.load_calendar(2018, "CHN", "women_singles").calendar.events:
		if str(event.event_id) == "cn_grand_prix_u_series_2018": return Dictionary(event).duplicate(true)
	return {}

func _program(id: String, segment: String):
	var program = FormalRosterGenerator._program(id, segment, "leader")
	program.whole_run_familiarity = 72.0; program.choreography_quality = 68.0; program.music = {"title":"月光" if segment == "short" else "舍赫拉查德", "source":"custom", "custom":true}
	for element_id in program.slot_familiarity: program.slot_familiarity[element_id] = 70.0
	return program

func _set_strength(athlete, value: float) -> void:
	for key in athlete.technique: athlete.technique[key] = value
	for key in athlete.skating: athlete.skating[key] = value
	for jump in athlete.jumps.values():
		jump.unlocked_rotations = 3; jump.proficiency.triple = value; jump.consistency.official = value
		for key in jump.takeoff: jump.takeoff[key] = value
		for key in jump.air: jump.air[key] = value
		for key in jump.landing: jump.landing[key] = value
