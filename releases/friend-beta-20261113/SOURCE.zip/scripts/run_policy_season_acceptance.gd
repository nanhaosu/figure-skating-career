extends SceneTree

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var report_path := "user://policy-season-42000-report.json"
	var snapshot := "user://policy-season-42000-final.json"
	var checked: Dictionary = load("res://scripts/run_natural_fast_acceptance.gd").validate_paths(report_path,snapshot)
	if not checked.ok: push_error(checked.error); quit(2); return
	var driver = load("res://scripts/policy_season_acceptance.gd").new()
	driver.snapshot_path = snapshot
	driver.checkpoint_directory = "user://policy-season-checkpoints"
	var resume_snapshot := ""
	var resume_report := ""
	var checkpoint_sha256 := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--resume-snapshot="): resume_snapshot = argument.trim_prefix("--resume-snapshot=")
		if argument.begins_with("--resume-report="): resume_report = argument.trim_prefix("--resume-report=")
		if argument.begins_with("--resume-checkpoint-sha256="): checkpoint_sha256 = argument.trim_prefix("--resume-checkpoint-sha256=")
	if not resume_snapshot.is_empty() or not resume_report.is_empty():
		if not FileAccess.file_exists(resume_snapshot) or not FileAccess.file_exists(resume_report): push_error("resume_evidence_missing"); quit(2); return
		var previous = JSON.parse_string(FileAccess.get_file_as_string(resume_report))
		if not previous is Dictionary or int(previous.get("seed",0)) != 42000: push_error("resume_evidence_mismatch"); quit(2); return
		var verified_prefix: bool = previous.get("first_attempt",{}).get("snapshot",{}).get("sha256","") == FileAccess.get_sha256(resume_snapshot)
		if not checkpoint_sha256.is_empty():
			var relative := "user://policy-season-checkpoints/"+resume_snapshot.get_file()
			verified_prefix = checkpoint_sha256 == FileAccess.get_sha256(resume_snapshot) and previous.get("checkpoints",[]).any(func(row):return row.get("path") == relative and row.get("node") == "2018:season_complete:")
		if not verified_prefix: push_error("resume_evidence_mismatch"); quit(2); return
		var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(resume_snapshot)
		if not loaded.ok or loaded.career.seed != 42000 or loaded.career.development_roadmap.get("route_id") != "fast" or not loaded.career.competition_state.is_empty(): push_error("resume_route_invalid"); quit(2); return
		var confirmation: Dictionary = previous.get("fast_confirmation",{})
		if confirmation.get("route",{}).get("route_id") != "fast" or int(confirmation.get("after_revisions",0)) != int(confirmation.get("before_revisions",0))+1 or loaded.career.roadmap_revision_history.size() < int(confirmation.get("after_revisions",0)): push_error("resume_fast_confirmation_invalid"); quit(2); return
		driver.initial_snapshot_path = resume_snapshot
		driver.fast_confirmation = previous.fast_confirmation.duplicate(true)
		driver.schedule_choices = previous.get("schedule_choices",[]).duplicate(true)
		driver.resume_evidence = {"snapshot":resume_snapshot,"snapshot_sha256":FileAccess.get_sha256(resume_snapshot),"report":resume_report,"report_sha256":FileAccess.get_sha256(resume_report),"scope":"read_only_real_factory_and_fast_route_prefix_to_before_first_formal_roster_no_stat_or_qualification_edits"}
		if not checkpoint_sha256.is_empty(): driver.resume_evidence.scope = "pinned_actual_2018_season_complete_checkpoint_before_2019_policy_publication_no_history_edits"
	print("POLICY_SEASON_POLICY seed42000 origin=", "fresh_factory" if resume_snapshot.is_empty() else "verified_read_only_natural_factory_prefix", " fast_once normal_coach first_club_U_Nationals_when_available other_optional_skip no_stats_or_qualifications end2019_20")
	var report: Dictionary = await driver.run_sample(42000,"coach")
	if not resume_report.is_empty() and FileAccess.get_sha256(resume_report) != driver.resume_evidence.report_sha256:
		report.completed = false
		report.errors.append("resume_report_changed")
	var file := FileAccess.open(report_path,FileAccess.WRITE)
	if file == null: push_error("cannot_write_policy_season_report"); quit(2); return
	file.store_string(JSON.stringify(report,"\t")); file.close()
	print("POLICY_SEASON_REPORT ",ProjectSettings.globalize_path(report_path)," completed=",report.get("completed",false)," closed=",report.get("closed_seasons",[])," errors=",report.get("errors",[]))
	quit(0 if report.get("completed",false) else 1)
