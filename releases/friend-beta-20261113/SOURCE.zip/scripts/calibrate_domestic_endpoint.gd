extends SceneTree

# Endpoint competition probe, NOT a complete calendar/selection journey.
# Actual factory, coach, training, draft revisions, eligibility and formal scores.
const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Training = preload("res://src/simulation/career_simulator.gd")
const Rehab = preload("res://src/simulation/rehabilitation_service.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Entry = preload("res://src/simulation/entry_application_service.gd")
const Competition = preload("res://src/simulation/formal_competition_simulator.gd")

func _initialize() -> void: call_deferred("run")
func run() -> void:
	var catalog := Catalog.load_catalog()
	var bundle := Bundle.load_bundle(2019,"women_singles","junior")
	var matching: Array = bundle.calendar.events.filter(func(e): return e.event_id == "cn_grand_prix_u_series_2019")
	if matching.is_empty(): push_error("Missing actual U-series event"); quit(1); return
	var event: Dictionary = matching[0]
	var rules := Bundle.competition_event(event)
	var rows := []
	var sample_count := 100
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--samples="): sample_count = clampi(int(argument.trim_prefix("--samples=")),1,100)
	for offset in sample_count:
		var seed_value := 1000+offset
		var career = Factory.create("竞技抽样",2006,"entry_interest_class","family_supportive",seed_value,catalog,4).career
		var revisions := {}
		var steps := 0
		while career.clock.year*4+career.clock.quarter < 2019*4+3 and steps < 96:
			steps += 1
			var pending: Dictionary = career.condition_state.get("pending_decision",{})
			if not pending.is_empty(): Rehab.choose(career,str(pending.injury_id),"full_rehabilitation","endpoint:%d:%d" % [seed_value,steps])
			if career.clock.year >= 2017:
				for segment in ["short","free"]:
					var season_year: int = career.clock.season_start_year()
					var revision_id := "%d:%s" % [season_year,segment]
					if revisions.has(revision_id): continue
					var season_rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(season_year,"junior",segment)
					var proposed := Draft.propose(career.athlete,segment,season_rules,{},seed_value)
					if proposed.program == null or not proposed.missing.is_empty() or not proposed.errors.is_empty(): continue
					var existing = load("res://src/domain/skating_program.gd").from_dict(career.active_programs.get(segment,{}))
					var saved := Draft.save_draft(existing,proposed.program)
					if saved.errors.is_empty():
						career.active_programs[segment] = saved.program.to_dict()
						revisions[revision_id] = true
			var plan := Coach.build(career,Intent.create("accept").intent)
			if not plan.errors.is_empty(): break
			Training.advance_quarter(career,plan.plan,catalog)
		for segment in ["short","free"]:
			var proposed := Draft.propose(career.athlete,segment,rules.rules[segment].segment_rules,{},seed_value)
			if proposed.program != null and proposed.errors.is_empty() and proposed.missing.is_empty():
				var existing = load("res://src/domain/skating_program.gd").from_dict(career.active_programs.get(segment,{}))
				var saved := Draft.save_draft(existing,proposed.program)
				if saved.errors.is_empty(): career.active_programs[segment] = saved.program.to_dict()
		var row := {"seed":seed_value,"rank":0,"score":0.0,"reason":"","clock":career.clock.to_dict(),"programme_revisions":revisions.size()}
		row.certification = load("res://src/simulation/certification_service.gd").assess(career)
		if sample_count == 1:
			print("CERTIFICATION_DIAGNOSTIC ",JSON.stringify({"state":career.certification_state,"birth":career.athlete.birth_year,"history_size":career.history.size(),"period":career.training_period_state}))
		var options: Array = Entry.options(career,event,bundle)
		var allowed: Array = options.filter(func(o): return o.id == "enter" and o.available)
		if allowed.is_empty(): row.reason = str(options[0].get("reasons",["not_eligible_or_medically_ready"]))
		else:
			var applied := Entry.apply(career,{"event_id":event.event_id,"route_id":"enter"})
			if not applied.ok: row.reason = str(applied.get("error","entry_failed"))
			else:
				var session := Competition.create_session(career,event,career.active_programs,"balanced",seed_value+9000)
				if not session.get("errors",[]).is_empty(): row.reason = str(session.errors)
				else:
					var response := "accept"
					if session.practice.get("meaningful",false): response = str(session.practice.response_options[0])
					session = Competition.complete_practice(session,response)
					session = Competition.lock_short(career,session)
					if session.get("status") == "free_adjustment": session = Competition.lock_free(career,session,"keep")
					if session.get("status") != "complete": row.reason = str(session.get("errors",["event_incomplete"]))
					else:
						var player: Array = session.final_standings.filter(func(r): return r.athlete_id == "player")
						if not player.is_empty(): row.rank = int(player[0].rank); row.score = float(player[0].get("total_score",player[0].get("short_score",0.0)))
		rows.append(row)
		print("DOMESTIC_ENDPOINT ",JSON.stringify(row))
	print("DOMESTIC_ENDPOINT_REPORT ",JSON.stringify({"event_id":event.event_id,"samples":sample_count,"age":13,"full_calendar":false,"top_six":rows.filter(func(r): return int(r.rank)>0 and int(r.rank)<=6).size(),"finished_events":rows.filter(func(r): return int(r.rank)>0).size(),"rows":rows}))
	quit()
