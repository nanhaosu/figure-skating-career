extends SceneTree

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() < 2: quit(2); return
	var source: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(args[0]))
	var career = load("res://src/domain/career_state.gd").from_dict(source.career_snapshot)
	var Element = load("res://src/domain/program_element.gd")
	var Program = load("res://src/domain/skating_program.gd")
	var elements: Array = []
	for spec in [["lutz",3],["flip",3],["axel",2],["loop",3],["salchow",3],["toe_loop",3],["axel",2]]:
		var jump = Element.create("j%d" % elements.size(),"jump",spec[0],spec[1]).element
		if elements.size() == 0: jump.set_combination_parts([{"jump_id":"toe_loop","rotations":2}])
		if elements.size() == 1: jump.set_combination_parts([{"jump_id":"loop","rotations":2}])
		if elements.size() == 6: jump.set_combination_parts([{"jump_id":"toe_loop","rotations":2},{"jump_id":"loop","rotations":2}])
		elements.append(jump)
	for code in ["CCoSp","FCSp","LSp"]:
		var spin = Element.create(code,"spin").element
		spin.spin_code = code
		elements.append(spin)
	elements.append(Element.create("steps","step_sequence").element)
	var programme = Program.create("five-triple-probe","free",elements).program
	var advanced := args.size() > 2 and args[2] == "advanced"
	if advanced:
		programme.elements[2].rotations = 3
		programme.elements[0].set_combination_parts([{"jump_id":"toe_loop","rotations":3}])
	var rules := {"segment_rules":load("res://src/content/internal_event_rules.gd").for_season(2018,"junior","free"),"scoring_catalog":load("res://src/content/formal_scoring_repository.gd").load_catalog(2018,"women_singles").catalog}
	var result := {"scope":"controlled legal free programme, naturally trained athlete, no stat or familiarity gifts; official segment engine, not calendar signup or ranking","seed":career.seed,"clock":career.clock.to_dict(),"programme":programme.to_dict(),"errors":[],"records":[],"recognized_triples":{},"recognized_combinations":{}}
	for index in 12:
		var record: Dictionary = load("res://src/simulation/formal_segment_simulator.gd").simulate(career.athlete,programme,{"risk":"balanced"},{"pressure":35.0},rules,80000+index)
		result.errors.append_array(record.get("errors",[]))
		result.records.append(record)
		for element in record.get("technical_review",{}).get("final_elements",[]):
			var clean_parts: Array[String] = []
			for part in element.get("parts",[element]):
				var facts: Dictionary = part.get("facts",{})
				var code := str(part.get("abbreviation",""))
				if int(part.get("called_rotations",0)) == 3 and not bool(facts.get("fall",false)) and not bool(facts.get("invalid",false)) and float(facts.get("rotation_ratio",0.0)) >= 0.95:
					clean_parts.append(code)
					for triple in ["3T","3S","3Lo","3F","3Lz","3A"]:
						if code == triple: result.recognized_triples[triple] = true
			if clean_parts == ["3Lz","3T"]: result.recognized_combinations["3Lz+3T"] = true
	var file := FileAccess.open(args[1],FileAccess.WRITE)
	file.store_string(JSON.stringify(result)); file.close()
	print("COMPETITION_PROBE recognized=",result.recognized_triples," combinations=",result.recognized_combinations," errors=",result.errors)
	quit(0 if result.errors.is_empty() else 1)
