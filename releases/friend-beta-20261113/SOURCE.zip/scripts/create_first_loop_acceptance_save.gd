extends SceneTree

const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")
const Teaching = preload("res://src/simulation/teaching_competition_service.gd")
const Invitation = preload("res://src/simulation/internal_invitation_service.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func _initialize() -> void:
	var output := "user://first-loop-acceptance.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="): output = argument.trim_prefix("--output=")
	var created: Dictionary = Factory.create("验收小选手",2007,"entry_club_trial","family_supportive",15150,Catalog.load_catalog(),4)
	if not created.errors.is_empty(): _finish(false,"career: "+"; ".join(created.errors)); return
	var career = created.career
	career.opening_stage = "complete"
	career.career_goal = {"id":"love_the_sport","chosen_clock":career.clock.to_dict(),"scoring_effect":false}
	# Place the deterministic checkpoint at the first invitation. It contains no
	# fabricated result: the user still chooses, skates, and receives any rank.
	Teaching.evaluate(career)
	career.training_period_state = {"weeks_elapsed":int(career.internal_invitation_state.scheduled_week),"started_clock":career.clock.to_dict(),"facts":[]}
	for segment in ["short","free"]:
		var proposal := Draft.propose(career.athlete,segment,Rules.for_teaching_group(segment),{"title":"验收练习曲"},15150+(0 if segment=="short" else 1))
		if not proposal.errors.is_empty() or not proposal.missing.is_empty(): _finish(false,"program %s" % segment); return
		var locked := Draft.lock_for_competition(proposal.program,career.athlete,Rules.for_teaching_group(segment))
		if not locked.errors.is_empty(): _finish(false,"lock %s: %s" % [segment,"; ".join(locked.errors)]); return
		career.active_programs[segment] = locked.program.to_dict()
	var status := Invitation.ensure_offer(career)
	if not status.ready: _finish(false,"invitation: "+"; ".join(status.missing)); return
	var saved := Save.save(career,output)
	_finish(bool(saved.ok),output if saved.ok else "; ".join(saved.errors))

func _finish(ok: bool, detail: String) -> void:
	print("FIRST_LOOP_ACCEPTANCE=%s %s" % ["passed" if ok else "failed",detail])
	quit(0 if ok else 1)
