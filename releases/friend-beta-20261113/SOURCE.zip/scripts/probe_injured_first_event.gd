extends SceneTree

# Diagnostic variation, not a production workaround: the player defers the
# teaching invitation while medically barred, using the driver's existing
# public defer/recovery route. Keep the ordinary ambitious route afterwards.
class RecoveryDriver:
	extends "res://scripts/international_season_journey.gd"
	func _train_quarter() -> void:
		var route_before := assigned_route
		if not load("res://src/simulation/athlete_condition_service.gd").can_compete(main.active_career):
			assigned_route = false
		await super._train_quarter()
		assigned_route = route_before

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var catalog: Dictionary = load("res://src/content/catalog_repository.gd").load_catalog()
	var created = load("res://src/simulation/career_factory.gd").create("伤后衔接探针",2006,"entry_club_trial","family_ambitious",41044,catalog,4)
	var result: Dictionary = await RecoveryDriver.new().run(created.career,true,"first_result")
	var career = result.career
	var rows: Array = []
	for archive in career.competition_archive:
		if not archive.get("world_only",false):
			rows.append_array(archive.final_standings.filter(func(row): return row.athlete_id == "player"))
	print("RECOVERY_PROBE ",JSON.stringify({"seed":41044,"clock":career.clock.to_dict(),"errors":result.errors,"results":rows,"trace_tail":result.trace.slice(maxi(0,result.trace.size()-10)),"saved":load("res://src/persistence/save_repository.gd").save(career,"user://recovery-probe.json").ok}))
	quit(0 if result.errors.is_empty() else 1)
