extends SceneTree

# Public-interface calibration report. It creates real careers, builds real
# roadmaps and advances real quarters; it never injects unlocks or evidence.
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")
const DevelopmentRoadmap = preload("res://src/domain/development_roadmap.gd")
const DevelopmentRoadmapEvaluator = preload("res://src/simulation/development_roadmap_evaluator.gd")
const RoadmapTrainingAdapter = preload("res://src/simulation/roadmap_training_adapter.gd")
const TrainingPolicyPlanner = preload("res://src/simulation/training_policy_planner.gd")
const CareerSimulator = preload("res://src/simulation/career_simulator.gd")
const PlanProposal = preload("res://src/domain/plan_proposal.gd")
const JumpStageEvaluator = preload("res://src/simulation/jump_stage_evaluator.gd")
const TrainingPlan = preload("res://src/domain/training_plan.gd")

const STABLE := ["training_stable", "internal_ready", "official_ready", "core"]
const ROUTE_GOALS := {
	"steady": [{"age": 11, "rotations": 2, "count": 6}, {"age": 15, "rotations": 3, "count": 3}],
	"balanced": [{"age": 10, "rotations": 2, "count": 6}, {"age": 14, "rotations": 3, "count": 4}],
	"fast": [{"age": 9, "rotations": 2, "count": 6}, {"age": 13, "rotations": 3, "count": 5}],
}

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var report := {"handoff": {}, "career_bands": {}}
	for handoff_age in [6, 7, 8]:
		report.handoff["interest_age_%d" % handoff_age] = _handoff_band(handoff_age, "entry_interest_class", "family_supportive", 6100 + handoff_age * 100)
	report.handoff.club_age_7 = _handoff_band(7, "entry_club_trial", "family_ambitious", 6900)
	var route_index := 0
	for route_id in ["steady", "balanced", "fast"]:
		report.career_bands[route_id] = {}
		for target_age in [9, 10, 13, 14, 15]:
			var rows: Array[Dictionary] = []
			for offset in 12:
				rows.append(_simulate_route(8000 + route_index * 1000 + target_age * 20 + offset, route_id, target_age))
			report.career_bands[route_id]["age_%d" % target_age] = _summarize_rows(rows)
		route_index += 1
	print(JSON.stringify(report, "  "))
	quit(0)

func _handoff_band(handoff_age: int, entry_id: String, family_id: String, seed_start: int) -> Dictionary:
	var singles: Array = []
	var doubles: Array = []
	var axel := 0
	var double_axel_attempts := 0
	for offset in 40:
		var career = CareerFactory.create("交接样本", 2014 - handoff_age, entry_id, family_id, seed_start + offset, CatalogRepository.load_catalog(), 4).career
		singles.append(_count_unlocked(career, 1))
		doubles.append(_count_unlocked(career, 2))
		axel += int(career.athlete.jumps.axel.unlocked_rotations >= 1)
		double_axel_attempts += int(career.athlete.jumps.axel.attempt_evidence.double.attempts > 0)
	return {
		"single_median": _median(singles),
		"double_median": _median(doubles),
		"axel_rate": float(axel) / 40.0,
		"double_axel_attempt_rate": float(double_axel_attempts) / 40.0,
	}

func _simulate_route(seed: int, route_id: String, target_age: int) -> Dictionary:
	var catalog := CatalogRepository.load_catalog()
	var career = CareerFactory.create("路线样本", 2008, "entry_club_trial", "family_ambitious", seed, catalog, 4).career
	var risk: String = str({"steady": "cautious", "balanced": "normal", "fast": "aggressive"}[route_id])
	var roadmap = DevelopmentRoadmap.create(route_id, ROUTE_GOALS[route_id], ["toe_loop", "salchow"], "", risk).roadmap
	career.development_roadmap = roadmap.to_dict()
	var peak_impact := float(career.athlete.body.impact_load)
	while career.clock.age_on(career.athlete.birth_year) < target_age:
		roadmap = DevelopmentRoadmap.from_dict(career.development_roadmap)
		var evaluation := DevelopmentRoadmapEvaluator.evaluate(career, roadmap)
		var rotations := _active_rotations(evaluation, route_id)
		roadmap.priority_jumps = _lowest_progress_jumps(career, rotations)
		career.development_roadmap = roadmap.to_dict()
		evaluation = DevelopmentRoadmapEvaluator.evaluate(career, roadmap)
		var adapted := RoadmapTrainingAdapter.build_policy(career, roadmap, evaluation)
		var planned := TrainingPolicyPlanner.build(career, adapted.policy, catalog)
		if planned.plan == null:
			push_error("calibration plan failed: %s" % planned.reasons)
			break
		var proposal = PlanProposal.create(planned.plan)
		proposal.status = "resolved"
		CareerSimulator.advance_proposal(career, proposal, catalog)
		peak_impact = maxf(peak_impact, float(career.athlete.body.impact_load))
	var official_sum := 0.0
	for jump_id in ["loop", "toe_loop", "axel"]: official_sum += float(career.athlete.jumps[jump_id].consistency.official)
	return {
		"doubles": _count_stable(career, 2),
		"triples": _count_stable(career, 3),
		"five_triples_2a": _five_triples_2a(career),
		"peak_impact": peak_impact,
		"official_lta_mean": official_sum / 3.0,
	}

func _summarize_rows(rows: Array[Dictionary]) -> Dictionary:
	var doubles: Array = []; var triples: Array = []; var impacts: Array = []; var official: Array = []
	var complete := 0
	for row in rows:
		doubles.append(row.doubles); triples.append(row.triples); impacts.append(row.peak_impact); official.append(row.official_lta_mean)
		complete += int(row.five_triples_2a)
	return {"double_median": _median(doubles), "triple_median": _median(triples), "peak_impact_median": _median(impacts), "official_lta_mean_median": _median(official), "five_triples_2a_unlocked_rate": float(complete) / float(rows.size())}

func _active_rotations(evaluation: Dictionary, route_id: String) -> int:
	for forecast in evaluation.get("milestone_forecasts", []):
		if int(forecast.current_count) < int(forecast.count): return int(forecast.rotations)
	return 2 if route_id == "steady" else 3

func _lowest_progress_jumps(career, rotations: int) -> Array[String]:
	var key: String = str({1: "single", 2: "double", 3: "triple", 4: "quad"}[rotations])
	var ranked: Array[Dictionary] = []
	for jump_id in TrainingPlan.JUMP_LABELS: ranked.append({"id": jump_id, "score": float(career.athlete.jumps[jump_id].proficiency[key])})
	ranked.sort_custom(func(a, b): return a.score < b.score)
	return [ranked[0].id, ranked[1].id]

func _count_stable(career, rotations: int) -> int:
	var count := 0
	for jump_id in TrainingPlan.JUMP_LABELS:
		if STABLE.has(JumpStageEvaluator.evaluate(career, jump_id, rotations).stage_id): count += 1
	return count

func _count_unlocked(career, rotations: int) -> int:
	var count := 0
	for jump_id in TrainingPlan.JUMP_LABELS:
		if int(career.athlete.jumps[jump_id].unlocked_rotations) >= rotations: count += 1
	return count

func _five_triples_2a(career) -> bool:
	var triples := 0
	for jump_id in ["toe_loop", "salchow", "loop", "flip", "lutz"]:
		triples += int(career.athlete.jumps[jump_id].unlocked_rotations >= 3)
	return triples == 5 and career.athlete.jumps.axel.unlocked_rotations >= 2

func _median(values: Array) -> float:
	values.sort()
	if values.is_empty(): return 0.0
	var middle := values.size() / 2
	return float(values[middle]) if values.size() % 2 == 1 else (float(values[middle - 1]) + float(values[middle])) / 2.0
