extends "res://src/persistence/browser_save_service.gd"

# Calibration adapter only. Real commands and UI commit boundaries remain in
# use, but this is NOT evidence of filesystem or IndexedDB durability.
func save_slot(id: String, career) -> Dictionary:
	if id not in IDS: return {"ok":false,"errors":["invalid calibration slot"]}
	var error: String = Repo._validate_payload({"save_version":preload("res://src/persistence/save_schema.gd").CURRENT_VERSION,"saved_at_unix":0,"career":career.serialization_view()},false)
	return {"ok":error.is_empty(),"errors":[] if error.is_empty() else [error]}

func list_slots() -> Array[Dictionary]:
	return []
