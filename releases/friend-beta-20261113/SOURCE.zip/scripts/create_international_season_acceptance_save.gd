extends SceneTree

const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Journey = preload("res://scripts/international_season_journey.gd")
const Save = preload("res://src/persistence/save_repository.gd")

func _initialize() -> void: call_deferred("create_acceptance")

func create_acceptance() -> void:
	var created := Factory.create("林澄",2006,"entry_club_trial","family_ambitious",41046,Catalog.load_catalog())
	if not created.errors.is_empty(): push_error(str(created.errors)); quit(1); return
	# Optional public-driver checkpoint avoids repeating completed history. It
	# uses the same validated load API and never edits the serialized career.
	var args := OS.get_cmdline_user_args()
	if not args.is_empty():
		var loaded := Save.load_save(args[0])
		if not loaded.ok: push_error(str(loaded.errors)); quit(1); return
		created.career = loaded.career
	var result := await Journey.new().run(created.career,true,"selection")
	if not result.errors.is_empty(): push_error(str(result.errors)); quit(1); return
	var career = result.career
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(career)
	var node: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(career,bundle,func(_c): return true).stop_node
	if node.get("kind") != "selection" or career.clock.year != 2019:
		push_error("Acceptance route did not reach the first eligible 2019 selection"); quit(1); return
	var preview: Dictionary = load("res://src/simulation/career_command_service.gd").apply(career,{"type":"apply_entry","event_id":node.event_id,"route_id":"request_assignment"})
	print("ACCEPTANCE_SELECTION_AUDIT ",JSON.stringify(preview.career.selection_state if preview.ok else preview))
	if not preview.ok or not preview.career.selection_state.assignments.has("player"):
		push_error("Public selection did not earn a JGP assignment; refusing a misleading acceptance save"); quit(1); return
	var saved := Save.save(career,"user://acceptance-international-season.json")
	print("ACCEPTANCE ",JSON.stringify({"ok":saved.ok,"path":ProjectSettings.globalize_path("user://acceptance-international-season.json"),"clock":career.clock.to_dict(),"screen":"SeasonOverviewPanel","next_node":node,"trace":result.trace}))
	quit(0 if saved.ok else 1)
