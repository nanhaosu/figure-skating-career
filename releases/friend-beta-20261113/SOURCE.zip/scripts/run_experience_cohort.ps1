param(
    [string]$GodotExe = 'C:/Users/25775/Desktop/figure_skating/.tools/godot-4.7.2/Godot_v4.7.2-stable_win64_console.exe',
    [string]$EvidenceDir = 'C:/Users/25775/Desktop/figure_skating/qa-runs/two-season-experience-20261015-cohort',
    [int]$Workers = 6,
    [int]$TimeoutSeconds = 1800,
    [switch]$FingerprintOnly
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null
Push-Location -LiteralPath $projectRoot
try { $sourceFiles = & rg --files src data scripts } finally { Pop-Location }
if ($LASTEXITCODE -ne 0) { throw 'Cannot enumerate candidate source' }
$sourceLines = foreach ($file in ($sourceFiles | Sort-Object)) { $file + ':' + (Get-FileHash -LiteralPath (Join-Path $projectRoot $file) -Algorithm SHA256).Hash }
$fingerprint = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes(($sourceLines -join "`n"))))
if ($FingerprintOnly) { Write-Output $fingerprint; return }
$queue = [Collections.Generic.Queue[object]]::new()
$all = [Collections.Generic.List[object]]::new()
foreach ($seedValue in 42000..42019) {
    foreach ($route in @('coach','combo_expression','programme_steps')) {
        $id = "$seedValue-$route"
        $metaPath = Join-Path $EvidenceDir "$id.meta.json"
        if (Test-Path -LiteralPath $metaPath) {
            $previous = Get-Content -LiteralPath $metaPath -Raw | ConvertFrom-Json
            if ($previous.source_hash -eq $fingerprint -and $previous.status -eq 'completed') { $all.Add($previous); continue }
        }
        $queue.Enqueue(@{id=$id; seed=$seedValue; route=$route; meta_path=$metaPath})
    }
}
$active = [Collections.Generic.List[object]]::new()
Write-Output "COHORT_BEGIN source=$fingerprint resumed=$($all.Count) remaining=$($queue.Count)"
while ($queue.Count -gt 0 -or $active.Count -gt 0) {
    while ($active.Count -lt $Workers -and $queue.Count -gt 0) {
        $job = $queue.Dequeue()
        $job.report_path = Join-Path $EvidenceDir ($job.id+'.json')
        $job.log = Join-Path $EvidenceDir ($job.id+'.log')
        $job.error_log = Join-Path $EvidenceDir ($job.id+'.stderr.log')
        $appData = Join-Path $EvidenceDir ('appdata-'+$job.id)
        New-Item -ItemType Directory -Force -Path $appData | Out-Null
        $job.started = [DateTime]::UtcNow
        $job.process = Start-Process -FilePath $GodotExe -WindowStyle Hidden -WorkingDirectory $projectRoot -ArgumentList @('--headless','--path',$projectRoot,'--script','scripts/run_two_season_experience.gd','--',('--seed='+$job.seed),('--route='+$job.route),('--report='+$job.report_path)) -RedirectStandardOutput $job.log -RedirectStandardError $job.error_log -Environment @{APPDATA=$appData} -PassThru
        $active.Add($job)
        Write-Output "COHORT_SAMPLE_BEGIN $($job.id) pid=$($job.process.Id)"
    }
    foreach ($job in @($active.ToArray())) {
        $job.process.Refresh()
        $timedOut = -not $job.process.HasExited -and ([DateTime]::UtcNow-$job.started).TotalSeconds -gt $TimeoutSeconds
        if (-not $job.process.HasExited -and -not $timedOut) { continue }
        if ($timedOut) {
            # Stop only this explicitly owned worker and its immediate Godot child.
            Get-CimInstance Win32_Process -Filter "ParentProcessId = $($job.process.Id)" | Where-Object { $_.Name -like 'Godot*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue }
            Stop-Process -Id $job.process.Id -ErrorAction SilentlyContinue
        } else { $job.process.WaitForExit() }
        $status = 'incomplete'
        $reason = 'timeout' 
        if (-not $timedOut) {
            $reason = 'missing_report'
            $runtimeErrors = @(Select-String -LiteralPath $job.log,$job.error_log -Pattern '^SCRIPT ERROR:|^ERROR:' | Where-Object { $_.Line -ne 'ERROR: Failed to read the root certificate store.' })
            if (Test-Path -LiteralPath $job.report_path) {
                $report = Get-Content -LiteralPath $job.report_path -Raw | ConvertFrom-Json
                $reason = ($report.errors -join ';')
                if ($report.completed -and $runtimeErrors.Count -eq 0 -and $job.process.ExitCode -eq 0) { $status = 'completed'; $reason = '' }
            }
            if ($runtimeErrors.Count -gt 0) { $reason = 'runtime_error: '+$runtimeErrors[0].Line }
        }
        $metadata = @{id=$job.id; seed=$job.seed; route=$job.route; source_hash=$fingerprint; status=$status; reason=$reason; elapsed_seconds=([DateTime]::UtcNow-$job.started).TotalSeconds; report=$job.report_path; log=$job.log; stderr=$job.error_log}
        [IO.File]::WriteAllText($job.meta_path,($metadata | ConvertTo-Json -Depth 8))
        $all.Add($metadata)
        $active.Remove($job) | Out-Null
        Write-Output "COHORT_SAMPLE_END $($job.id) status=$status reason=$reason total=$($all.Count)/60"
    }
    Start-Sleep -Milliseconds 500
}
[IO.File]::WriteAllText((Join-Path $EvidenceDir 'manifest.json'),(@{source_hash=$fingerprint; samples=$all.ToArray(); completed=@($all | Where-Object status -eq 'completed').Count; incomplete=@($all | Where-Object status -ne 'completed').Count} | ConvertTo-Json -Depth 10))
Write-Output "COHORT_END completed=$(@($all | Where-Object status -eq 'completed').Count)/60"
