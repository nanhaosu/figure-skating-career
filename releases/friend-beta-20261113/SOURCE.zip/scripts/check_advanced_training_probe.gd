extends SceneTree

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var args := OS.get_cmdline_user_args()
	var snapshot: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(args[0]))
	var career = load("res://src/domain/career_state.gd").from_dict(snapshot.career_snapshot)
	var direction: Dictionary = career.training_direction.duplicate(true)
	direction.focuses = [{"id":"3a","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}},{"id":"33","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"lutz","rotations":3},{"jump_id":"toe_loop","rotations":3}]}}]
	var changed: Dictionary = load("res://src/simulation/career_command_service.gd").apply(career,{"type":"set_training_direction","direction":direction,"receipt_id":"advanced-probe"})
	if not changed.ok: push_error(str(changed.error)); quit(1); return
	career = changed.career
	var catalogue: Dictionary = load("res://src/content/catalog_repository.gd").load_catalog()
	var intent = load("res://src/domain/training_intent.gd").create("accept").intent
	var report := {"scope":"continue a naturally trained five-triple snapshot using the ordinary training-direction command and real quarter training; no ability gifts","trace":[],"stop_reason":"","errors":[]}
	for period in 12:
		if not career.condition_state.pending_decision.is_empty(): report.stop_reason = "medical_choice"; break
		var built: Dictionary = load("res://src/simulation/coach_training_plan_service.gd").build(career,intent)
		if built.plan == null: report.errors.append_array(built.errors); break
		var authority = load("res://src/simulation/authority_resolver.gd")
		var proposal = authority.preview(career,built.plan)
		for step in 8:
			if proposal.status == "resolved": break
			authority.respond(career,proposal,proposal.conflicts[0].id,"accept",career.random_streams.take_rng("authority"))
		if proposal.status != "resolved": report.errors.append("authority_unresolved"); break
		var old: Dictionary = career.clock.to_dict()
		for continuation in 8:
			load("res://src/simulation/career_simulator.gd").advance_proposal(career,proposal,catalogue)
			if career.clock.to_dict() != old or not career.condition_state.pending_decision.is_empty(): break
		var combo: Dictionary = career.technical_repertoire.entries.get("3Lz+3T",{})
		report.trace.append({"clock":career.clock.to_dict(),"course":built.plan.to_dict(),"axel_attempts":career.athlete.jumps.axel.attempt_evidence.triple.duplicate(true),"axel_proficiency":career.athlete.jumps.axel.proficiency.triple,"combo_state":combo.get("state","missing"),"combo_batches":combo.get("evidence",[]).size()})
		if career.clock.to_dict() == old: report.stop_reason = "interrupted"; break
	report.career_snapshot = career.to_dict()
	var file := FileAccess.open(args[1],FileAccess.WRITE)
	file.store_string(JSON.stringify(report)); file.close()
	print("ADVANCED_TRAINING ",JSON.stringify(report.trace.back() if not report.trace.is_empty() else report)," stop=",report.stop_reason)
	quit(0 if report.errors.is_empty() else 1)
