extends SceneTree

func _initialize() -> void:
	var repo = load("res://src/persistence/save_repository.gd")
	var loaded: Dictionary = repo.load_save("user://memory-probe.json")
	if not loaded.ok: print(loaded.errors); quit(1); return
	var career = loaded.career
	var started := Time.get_ticks_usec()
	var serialized: Dictionary = career.serialization_view()
	print("SAVE_PHASE serialization_ms=",_ms(started))
	var payload := {"save_version":repo.SAVE_VERSION,"saved_at_unix":Time.get_unix_time_from_system(),"career":serialized}
	started = Time.get_ticks_usec()
	var error: String = repo._validate_payload(payload)
	print("SAVE_PHASE validation_ms=",_ms(started)," error=",error)
	started = Time.get_ticks_usec()
	var finite: bool = repo._finite_json_values(payload)
	print("SAVE_PHASE finite_ms=",_ms(started)," finite=",finite)
	started = Time.get_ticks_usec()
	var canonical: Dictionary = load("res://src/persistence/numeric_state.gd").canonical_copy(serialized)
	print("SAVE_PHASE canonical_ms=",_ms(started))
	started = Time.get_ticks_usec()
	var encoded := JSON.stringify(canonical,"",true,true)
	print("SAVE_PHASE json_ms=",_ms(started)," bytes=",encoded.length())
	started = Time.get_ticks_usec()
	var restored = load("res://src/domain/career_state.gd").from_dict(canonical,true)
	print("SAVE_PHASE restore_ms=",_ms(started)," restored=",restored != null)
	quit(0 if error.is_empty() and finite else 1)

func _ms(started: int) -> float:
	return float(Time.get_ticks_usec()-started)/1000.0
