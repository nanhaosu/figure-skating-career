param([string]$BuildDir = 'build/web')
$ErrorActionPreference = 'Stop'
$path = Join-Path (Resolve-Path -LiteralPath $BuildDir).Path 'index.js'
$expected = '33C94CB3175F3333B82E2A3BE5E8E86F77986F0AA2042B1631F6367A4E5BB6BA'
if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $expected) { throw 'Unsupported runtime: expected unmodified Godot 4.7.2 no-threads index.js' }
$script = [IO.File]::ReadAllText($path)
$anchor = 'Module["initFS"]=GodotFS.init;'
if ([regex]::Matches($script, [regex]::Escape($anchor)).Count -ne 1) { throw 'Unsupported Godot module: initFS anchor must occur exactly once' }
if ($script.Contains('figureSkatingInstallDurability')) { throw 'Durability bridge already installed; export a fresh build' }
$bridge = [IO.File]::ReadAllText((Join-Path $PSScriptRoot '../src/persistence/browser_durability_bridge.js'))
$script = $script.Replace($anchor, $anchor + $bridge + 'globalThis.figureSkatingInstallDurability(GodotFS,FS,IDBFS);')
[IO.File]::WriteAllText($path, $script, [Text.UTF8Encoding]::new($false))
Write-Output 'PASS: installed acknowledged IDBFS bridge at unique Godot initFS anchor.'
