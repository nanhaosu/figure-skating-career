extends RefCounted
const CODES := ["3T","3S","3Lo","3F","3Lz"]
const IDS := ["toe_loop","salchow","loop","flip","lutz"]
static func allowed_seed(seed_value: int, campaign: String = "") -> bool:
	return seed_value == 42000 if campaign.is_empty() else campaign == "predeclared-v1" and seed_value in [42000,42001,42002]
static func training_diagnostics(career, event_start: String) -> Dictionary:
	var result := {"timeline":career.competition_timeline.duplicate(true),"event_start":event_start,"actual_dated_days":0,"actual_dated_jump_attempts":0,"days_on_or_after_event":0,"last_training_date":"","quarters":{},"jumps":{},"body":career.athlete.body.duplicate(true)}
	for row in career.history:
		if row.get("category") != "dated_training": continue
		var date := str(row.get("date",""))
		result.actual_dated_days += 1
		result.actual_dated_jump_attempts += int(row.get("actual_jump_attempts",0))
		if date > str(result.last_training_date): result.last_training_date = date
		if not event_start.is_empty() and date >= event_start: result.days_on_or_after_event += 1
		var quarter := date.left(4)+"Q"+str((date.substr(5,2).to_int()-1)/3+1)
		if not result.quarters.has(quarter): result.quarters[quarter] = {"days":0,"jump_attempts":0}
		result.quarters[quarter].days += 1
		result.quarters[quarter].jump_attempts += int(row.get("actual_jump_attempts",0))
	for index in IDS.size():
		var profile = career.athlete.jumps[IDS[index]]
		var item: Dictionary = career.technical_repertoire.entries.get(CODES[index],{})
		var window: int = load("res://src/content/repertoire_health_rules.gd").load_rules().evidence_window
		result.jumps[CODES[index]] = {"recent":load("res://src/simulation/repertoire_evaluator.gd")._window(item.get("evidence",[]),window,false),"proficiency":profile.proficiency.duplicate(true),"consistency":profile.consistency.duplicate(true),"state":item.get("state","training"),"stage":load("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,IDS[index],3)}
	return result
static func ready(rows: Dictionary) -> bool:
	for code in CODES:
		var row := dictionary(rows.get(code))
		if row.get("stage_id") not in ["official_ready","core"] or row.get("state") != "available": return false
	return true
static func dictionary(value: Variant) -> Dictionary:
	return value if value is Dictionary else {}
static func array(value: Variant) -> Array:
	return value if value is Array else []
static func numeric(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value))
static func whole(value: Variant) -> bool:
	return numeric(value) and float(value) == floorf(float(value))
static func valid_programme(value: Variant) -> bool:
	if not value is Dictionary or not value.get("elements") is Array or value.elements.is_empty(): return false
	for element in value.elements:
		if not element is Dictionary: return false
		if element.get("kind") != "jump": continue
		if not whole(element.get("rotations")) or not element.get("combination_parts",[]) is Array: return false
		for part in element.get("combination_parts",[]):
			if not part is Dictionary or not whole(part.get("rotations")): return false
	return true
static func semantic_equal(left: Variant, right: Variant) -> bool:
	if (left is int or left is float) and (right is int or right is float): return absf(float(left)-float(right)) <= 0.00000001
	if left is Dictionary and right is Dictionary:
		if left.size() != right.size(): return false
		for key in left:
			if not right.has(key) or not semantic_equal(left[key],right[key]): return false
		return true
	if left is Array and right is Array:
		if left.size() != right.size(): return false
		for index in left.size():
			if not semantic_equal(left[index],right[index]): return false
		return true
	return typeof(left) == typeof(right) and left == right
static func formal(a: Dictionary) -> bool:
	var event := dictionary(a.get("event"))
	return not a.get("world_only",false) and event.get("scope") in ["domestic","international"] and event.get("event_family") not in ["teaching","internal"] and (dictionary(a.get("short_results")).has("player") or dictionary(a.get("free_results")).has("player"))
static func programme_codes(programme: Dictionary) -> Array:
	var codes := []
	if not valid_programme(programme): return codes
	for raw in array(programme.get("elements")):
		var element := dictionary(raw)
		if element.get("kind") != "jump": continue
		var parts := [element]
		parts.append_array(array(element.get("combination_parts")))
		for raw_part in parts:
			var part := dictionary(raw_part)
			var index := IDS.find(str(part.get("jump_id","")))
			if index >= 0 and int(part.get("rotations",0)) == 3 and not codes.has(CODES[index]): codes.append(CODES[index])
	return codes
static func inspect(raw: Dictionary) -> Dictionary:
	for segment in ["short","free"]:
		if raw.has(segment+"_results") and not raw[segment+"_results"] is Dictionary: return {"event_id":raw.get("event_id",""),"eligible":false,"single_free_five":false,"planned_five":false,"completed_codes":[]}
		for record in dictionary(raw.get(segment+"_results")).values():
			if not record is Dictionary: return {"event_id":raw.get("event_id",""),"eligible":false,"single_free_five":false,"planned_five":false,"completed_codes":[]}
	var a: Dictionary = load("res://src/persistence/competition_archive_codec.gd").expand(raw)
	var result := {"event_id":a.get("event_id",""),"eligible":formal(a),"planned_codes":[],"completed_codes":[],"single_free_five":false,"planned_five":false,"technical_elements":[],"submitted_programme_five":false,"diagnostics":[]}
	if not result.eligible: return result
	var record := dictionary(dictionary(a.get("free_results")).get("player"))
	result.actual_free_programme = dictionary(dictionary(record.get("snapshot")).get("program")).duplicate(true)
	result.actual_free_performance = dictionary(record.get("performance")).duplicate(true)
	result.player_roster_free_programme = {}
	for row in array(a.get("roster")):
		if dictionary(row).get("athlete_id",dictionary(row).get("id","")) == "player": result.player_roster_free_programme = dictionary(dictionary(row).get("free_program")).duplicate(true)
	result.submitted_programme_source = "free_record_snapshot" if not record.is_empty() else "roster_pre_free_or_cut"
	var submitted: Dictionary = result.actual_free_programme if not record.is_empty() else result.player_roster_free_programme
	if not valid_programme(submitted): result.diagnostics.append("missing_or_malformed_submitted_programme:"+result.submitted_programme_source)
	result.submitted_programme_codes = programme_codes(submitted)
	result.submitted_programme_five = CODES.all(func(code): return result.submitted_programme_codes.has(code))
	var elements := array(dictionary(record.get("technical_review")).get("final_elements"))
	result.technical_elements = elements.duplicate(true)
	for raw_element in elements:
		var element := dictionary(raw_element)
		var parts := array(element.get("parts"))
		# Single jumps carry facts on the outer final element; combinations on each part.
		if dictionary(element.get("facts")).has("planned_rotations"): parts = [element]
		for raw_part in parts:
			var part := dictionary(raw_part)
			var facts := dictionary(part.get("facts"))
			if not whole(facts.get("planned_rotations")) or not numeric(facts.get("rotation_ratio")) or not facts.get("fall") is bool or not facts.get("invalid") is bool:
				result.diagnostics.append("missing_or_malformed_technical_facts"); continue
			var planned := str(facts.get("planned_abbreviation",""))
			if planned in CODES and int(facts.get("planned_rotations",0)) == 3 and not result.planned_codes.has(planned): result.planned_codes.append(planned)
			var code := str(part.get("abbreviation",""))
			var called_value: Variant = part.get("called_rotations",-1)
			if part == element and not array(element.get("parts")).is_empty(): called_value = dictionary(element.parts[0]).get("called_rotations",-1)
			if not whole(called_value): result.diagnostics.append("malformed_called_rotations"); continue
			var called := int(called_value)
			var invalid := bool(facts.get("invalid",false)) or not str(part.get("invalid_reason","")).is_empty() or not str(element.get("invalid_reason","")).is_empty()
			for symbol in ["q","<","<<","*","REP","+REP"]: invalid = invalid or array(part.get("info")).has(symbol) or array(element.get("info")).has(symbol)
			if planned == code and int(facts.get("planned_rotations",0)) == 3 and code in CODES and called == 3 and facts.has("fall") and facts.fall == false and float(facts.get("rotation_ratio",-1)) >= 0.95 and not invalid and not result.completed_codes.has(code): result.completed_codes.append(code)
	result.planned_five = CODES.all(func(code): return result.planned_codes.has(code))
	result.single_free_five = a.get("status") == "complete" and CODES.all(func(code): return result.completed_codes.has(code))
	return result
static func archives(rows: Array) -> Dictionary:
	var first := {}; var union := []; var observed := []
	for raw in rows:
		if not raw is Dictionary: continue
		var item := inspect(raw)
		if not item.eligible: continue
		if first.is_empty(): first = item
		observed.append(item)
		for code in item.completed_codes:
			if not union.has(code): union.append(code)
	return {"first_archive":first,"formal_archives":observed,"across_event_codes":union,"across_event_five":CODES.all(func(code): return union.has(code))}
