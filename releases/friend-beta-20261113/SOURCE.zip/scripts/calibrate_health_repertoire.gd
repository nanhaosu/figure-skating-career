extends SceneTree

# Real factory -> coach -> executed quarter. No injected unlocks or evidence.
const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Career = preload("res://src/simulation/career_simulator.gd")
const Rehab = preload("res://src/simulation/rehabilitation_service.gd")

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var sample_count := 10
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--samples="): sample_count = clampi(int(argument.trim_prefix("--samples=")),1,100)
	var report := {"samples_per_route":sample_count,"quarters":32,"routes":{}}
	var catalog := Catalog.load_catalog()
	for route in ["accept","jump_focus","skating_focus","aggressive"]:
		var rows := []
		for offset in sample_count:
			var seed_value := 1000+offset
			var career = Factory.create("校准样本",2007,"entry_interest_class","family_supportive",seed_value,catalog,4).career
			var target_year: int = career.clock.year+8
			var steps := 0
			var peak_fatigue := 0.0
			var peak_rotation := 1
			var first_success := -1
			var total_attempts := 0
			var reserve_entry := -1
			var fatigue_interruptions := 0
			var previous_history: int = career.history.size()
			while career.clock.year < target_year and steps < 96:
				steps += 1
				var pending: Dictionary = career.condition_state.get("pending_decision",{})
				if not pending.is_empty():
					var choice := Rehab.choose(career,str(pending.injury_id),"full_rehabilitation","calibration:%s:%d:%d" % [route,seed_value,steps])
					if not choice.ok: push_error("treatment failed: %s" % choice); break
				if route == "jump_focus":
					var next_rotation := mini(3,int(career.athlete.jumps.axel.unlocked_rotations)+1)
					career.season_program_plan.targets = {"free":[{"element_id":"target:axel","action":{"kind":"jump","parts":[{"jump_id":"axel","rotations":next_rotation}]}}]}
				var planned := Coach.build(career,Intent.create("more_aggressive" if route == "aggressive" else "accept").intent)
				if not planned.errors.is_empty(): push_error(str(planned.errors)); break
				if route == "skating_focus":
					var allocation: Dictionary = planned.plan.shares
					for source in ["rotation","conditioning"]:
						var transfer := mini(5,maxi(0,int(allocation[source])-5))
						allocation[source] -= transfer
						allocation.skating_foundation += transfer
					planned.plan._shares = allocation
				Career.advance_quarter(career,planned.plan,catalog)
				peak_fatigue = maxf(peak_fatigue,float(career.athlete.body.acute_fatigue))
				fatigue_interruptions += int(float(career.athlete.body.acute_fatigue)>=38.0)
				for index in range(previous_history,career.history.size()):
					var fact: Dictionary = career.history[index]
					if fact.get("category") == "jump_attempt_batch":
						total_attempts += int(fact.get("attempts",0))
						peak_rotation = maxi(peak_rotation,int(fact.get("rotations",1)))
						if first_success == -1 and int(fact.get("successes",0))>0: first_success = steps
				previous_history = career.history.size()
				if reserve_entry == -1 and career.technical_repertoire.entries.values().any(func(item): return item.get("state") == "available"): reserve_entry = steps
			var triples := 0
			var doubles := 0
			for id in career.athlete.jumps:
				doubles += int(career.athlete.jumps[id].unlocked_rotations >= 2)
				if id != "axel": triples += int(career.athlete.jumps[id].unlocked_rotations >= 3)
			var majors := 0
			for injury in career.condition_state.injuries: majors += int(float(injury.get("severity",0.0))>=0.7)
			var row := {"seed":seed_value,"finished":career.clock.year == target_year,"steps":steps,"doubles":doubles,"triples":triples,"double_axel":career.athlete.jumps.axel.unlocked_rotations>=2,"major_injuries":majors,"peak_fatigue":peak_fatigue,"repertoire_entries":career.technical_repertoire.entries.size(),"attempts":total_attempts,"first_success_step":first_success,"first_reserve_step":reserve_entry,"highest_attempted_rotation":peak_rotation,"fatigue_interruptions":fatigue_interruptions}
			rows.append(row)
			print("HEALTH_SAMPLE ",route," ",JSON.stringify(row))
			report.routes[route] = rows
	print("HEALTH_REPORT ",JSON.stringify(report))
	quit()
