extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(960,540)
	root.gui_embed_subwindows = true
	var career = load("res://tests/fixtures.gd").starting_career(1794)
	career.training_direction.focuses = [{"id":"expression","kind":"musical_expression","target":{}},{"id":"axel","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"axel","rotations":3}]}}]
	for scene in ["training_focus_panel","external_training_panel"]:
		var panel = load("res://src/app/"+scene+".tscn").instantiate()
		panel.theme = load("res://src/app/theme_factory.gd").create()
		root.add_child(panel)
		panel.present(career)
		for frame in 6: await process_frame
		await RenderingServer.frame_post_draw
		var destination := "C:/Users/25775/Desktop/figure_skating/qa-dual-focus-20261011"
		DirAccess.make_dir_recursive_absolute(destination)
		print("CAPTURE ",scene," ",root.get_texture().get_image().save_png(destination.path_join(scene+".png")))
		panel.free()
	quit()
