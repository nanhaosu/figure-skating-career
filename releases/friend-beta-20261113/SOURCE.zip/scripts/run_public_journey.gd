extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var args := OS.get_cmdline_user_args()
	var assigned := args[0] == "planned"
	var seed_value := int(args[1])
	var created: Dictionary = load("res://src/simulation/career_factory.gd").create("林澄" if assigned else "陈雪",2006,"entry_club_trial" if assigned else "entry_interest_class","family_ambitious" if assigned else "family_supportive",seed_value,load("res://src/content/catalog_repository.gd").load_catalog(),4)
	if not created.errors.is_empty(): print(created.errors); quit(1); return
	var result: Dictionary = await load("res://scripts/international_season_journey.gd").new().run(created.career,assigned,args[2] if args.size() > 2 else "")
	var c = result.career
	var archives := []
	for archive in c.competition_archive:
		if archive.get("world_only",false): continue
		archives.append({"event":archive.event_id,"player":archive.final_standings.filter(func(r): return r.athlete_id == "player")})
	print("PUBLIC_JOURNEY ",JSON.stringify({"seed":seed_value,"route":args[0],"errors":result.errors,"trace":result.trace,"clock":c.clock.to_dict(),"selections":c.selection_state,"archives":archives,"reload":result.mid_competition_reload_equal,"archive_reload":result.archive_reload_equal,"free_edit":result.concrete_free_edit,"short_cut":result.short_cut}))
	print("PUBLIC_SAVE ",load("res://src/persistence/save_repository.gd").save(c,"user://public-journey-%s-%d.json" % [args[0],seed_value]))
	quit(0 if result.errors.is_empty() else 1)
