extends "res://scripts/natural_fast_acceptance.gd"

var schedule_choices: Array = []
var resume_evidence := {}

func _init() -> void:
	end_season_year = 2019
	formal_start_quarter = 1
	stop_after_first_formal_archive = false

static func wanted_event(event: Dictionary) -> bool:
	if event.get("scope") == "domestic":
		return event.get("event_family") in ["national_junior","national_championship"] or event.get("event_family") == "club_league_stage" and int(event.get("sequence",0)) == 1
	return event.get("event_family") in ["jgp_stage","jgp_final","world_junior"]

func _handle_node(node: Dictionary, bundle: Dictionary) -> void:
	if node.get("kind") == "competition_check_in" and not checkpoint_directory.is_empty():
		var checkpoint: Dictionary = _save_checkpoint(main.active_career,1000+trace.size())
		if not checkpoint.ok: errors.append("pre_event_checkpoint_failed:"+str(checkpoint.get("errors",[]))); return
	if node.get("kind") in ["registration","selection"]:
		var offered: Array = bundle.get("calendar",{}).get("events",[]).filter(func(event):return event.event_id == node.get("event_id"))
		if not offered.is_empty() and not wanted_event(offered[0]):
			await main._on_season_adjustment_selected(str(node.event_id),"skip")
			var status := str(main.active_career.season_state.get("entry_plan",{}).get("entries",{}).get(str(node.event_id),{}).get("status",""))
			if status != "declined": errors.append("policy_optional_skip_not_committed:"+str(node.event_id))
			trace.append("policy_optional_skip:"+str(node.event_id))
			return
	if node.get("kind") == "registration" and not main.active_career.season_state.get("domestic_schedule_selected",false):
		var events: Array = bundle.get("calendar",{}).get("events",[])
		var current: Array = events.filter(func(event):return event.event_id == node.get("event_id"))
		if not current.is_empty() and current[0].get("scope") == "domestic":
			main._on_domestic_schedule_requested()
			var selected := []
			var unavailable := []
			for choice in main.season_overview_panel._domestic_choices.get_children():
				var id := str(choice.get_meta("event_id",""))
				var matches: Array = events.filter(func(event):return str(event.event_id) == id)
				if matches.is_empty(): continue
				var event: Dictionary = matches[0]
				var wanted: bool = wanted_event(event)
				if not wanted: continue
				if choice.disabled and not choice.button_pressed:
					unavailable.append({"event_id":id,"reason":choice.tooltip_text})
					continue
				choice.button_pressed = true
				selected.append(id)
			await main._on_domestic_schedule_selected(selected)
			main.season_overview_panel._domestic_dialog.hide()
			if not main.active_career.season_state.get("domestic_schedule_selected",false): errors.append("policy_schedule_not_committed")
			schedule_choices.append({"season":bundle.calendar.season_id,"clock":main.active_career.clock.to_dict(),"selected":selected,"unavailable":unavailable})
			return
	await super._handle_node(node,bundle)

func _report(career) -> Dictionary:
	var report: Dictionary = super._report(career)
	report.policy.end_season_year = 2019
	report.policy.seed_policy = "fixed42000_all_attempts_retained_no_seed_search"
	report.policy.domestic_schedule = "predeclared_first_club_stage_plus_U_and_Nationals_when_actually_available_other_optional_races_declined"
	report.policy.international_schedule = "request_actual_JGP_stages_and_qualified_final_or_World_Junior_other_optional_opens_declined"
	report.terminal_scope = "two_complete_seasons_2018_19_and_2019_20_not_only_first_event"
	report.schedule_choices = schedule_choices.duplicate(true)
	report.resume_evidence = resume_evidence.duplicate(true)
	report.season_state = career.season_state.duplicate(true)
	report.selection_state = career.selection_state.duplicate(true)
	report.opponent_schedules = load("res://src/simulation/opponent_season_schedule_service.gd").summary(career,2019)
	report.opponent_season_acceptance = {}
	for year in [2018,2019]:
		var summary: Dictionary = load("res://src/simulation/opponent_season_schedule_service.gd").summary(career,year)
		var starters := 0
		for row in summary.records:
			if int(row.actual_starts) > 0 and float(row.actual_money_spent) > 0: starters += 1
		report.opponent_season_acceptance[str(year)] = {"managed":summary.managed_count,"actual_paid_starters":starters}
		if summary.managed_count < 3 or starters < 3: errors.append("opponent_actual_season_missing:"+str(year))
	report.world_roundtrip = {"ok":false,"fields":{}}
	if not snapshot_path.is_empty():
		var loaded: Dictionary = Save.load_save(snapshot_path)
		if loaded.ok:
			var original: Dictionary = career.to_dict()
			var restored: Dictionary = loaded.career.to_dict()
			for field in ["world_athletes","world_state","event_ledger","season_state","selection_state"]:
				report.world_roundtrip.fields[field] = Acceptance.semantic_equal(original.get(field),restored.get(field))
			report.world_roundtrip.ok = report.world_roundtrip.fields.values().all(func(value):return value)
		if not report.world_roundtrip.ok: errors.append("policy_world_roundtrip_failed")
	return report
