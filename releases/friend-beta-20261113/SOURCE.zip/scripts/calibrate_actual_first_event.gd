extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var seeds := [41041,41042,41043,41044,41045,41046,41047,41048]
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--seed="): seeds = [int(argument.trim_prefix("--seed="))]
	for seed_value in seeds:
		var created = load("res://src/simulation/career_factory.gd").create("林澄",2006,"entry_club_trial","family_ambitious",seed_value,load("res://src/content/catalog_repository.gd").load_catalog(),4)
		var result: Dictionary = await load("res://scripts/international_season_journey.gd").new().run(created.career,true,"first_result")
		var c = result.career
		if not result.errors.is_empty():
			print("ACTUAL_DIAGNOSTIC ",JSON.stringify({"clock":c.clock.to_dict(),"pending":c.condition_state.get("pending_decision",{}),"injuries":c.condition_state.injuries,"rehabilitation":c.condition_state.rehabilitation,"period":c.training_period_state,"trace_tail":result.trace.slice(maxi(0,result.trace.size()-12))}))
		var row := {}
		for archive in c.competition_archive:
			if archive.get("world_only",false): continue
			row = archive.final_standings.filter(func(r): return r.athlete_id == "player")[0]
		if row.is_empty(): result.errors.append("no_player_result_within_supported_seasons")
		print("ACTUAL_MATRIX ",JSON.stringify({"seed":seed_value,"errors":result.errors,"row":row}))
		print("ACTUAL_SAVE ",load("res://src/persistence/save_repository.gd").save(c,"user://actual-%d.json" % seed_value).ok)
	quit()
