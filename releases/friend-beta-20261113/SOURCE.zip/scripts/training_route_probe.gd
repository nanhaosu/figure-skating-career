extends RefCounted

const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Authority = preload("res://src/simulation/authority_resolver.gd")
const Events = preload("res://src/simulation/event_engine.gd")
const Simulator = preload("res://src/simulation/career_simulator.gd")
const Stage = preload("res://src/simulation/jump_stage_evaluator.gd")

func validate_report(report: Dictionary) -> Array[String]:
	var errors: Array[String] = []
	var executed := int(report.get("executed_quarters",-1))
	var requested := int(report.get("requested_quarters",0))
	if requested < 1 or executed < 0 or executed > requested: errors.append("invalid_period_count")
	if not report.get("trace") is Array or report.trace.size() != executed: errors.append("trace_count_mismatch")
	if not Array(report.get("errors",[])).is_empty(): errors.append("sample_errors")
	if not str(report.get("response","")) in ["accept","more_aggressive"]: errors.append("invalid_response")
	var final: Dictionary = report.get("final",{})
	for field in ["technique","spins","spin_foundation"]:
		if not final.get(field) is Dictionary or Dictionary(final.get(field,{})).is_empty(): errors.append("missing_component_"+field)
	var clock: Dictionary = final.get("clock",{})
	if int(clock.get("year",0)) < 2014 or not int(clock.get("quarter",0)) in [1,2,3,4] or final.get("snapshot_origin") != "actual_post_loop_career": errors.append("missing_final_provenance")
	if not report.get("trace",[]).is_empty():
		var expected_clock: Dictionary = report.trace[-1].get("to",{})
		if clock != expected_clock: errors.append("final_clock_mismatch")
	if bool(report.get("completed",false)):
		if executed != requested: errors.append("false_completion")
	elif str(report.get("stop_reason","")) != "major_medical_choice" or Dictionary(report.get("pending_decision",{})).is_empty():
		errors.append("unjustified_stop")
	return errors

func run_sample(seed_value: int, coach_id: String, route: String, quarters: int, response: String = "accept") -> Dictionary:
	var catalog := Catalog.load_catalog()
	var created: Dictionary = Factory.create("教练培养对照",2006,"entry_interest_class","family_supportive",seed_value,catalog,4)
	var report := {"seed":seed_value,"coach_id":coach_id,"route":route,"requested_quarters":quarters,"executed_quarters":0,"completed":false,"errors":[],"trace":[],"stop_reason":"","pending_decision":{},"scope":"natural_training_only_not_calendar_dispatch_or_durability","decision_policy":"accept_authority; report_pain; rest_when_fatigued; stop_for_major_medical_choice","baseline":"identical_precareer_resources_and_trust; change_assigned_coach_tendencies_only"}
	var profile: Dictionary = preload("res://src/content/club_coach_repository.gd").new().coach_profile(coach_id)
	report.response = response
	if created.career == null or profile.is_empty() or not route in ["balanced","fast"] or quarters < 1 or not response in ["accept","more_aggressive"]:
		report.errors = ["invalid_parameters"]
		return report
	var career = created.career
	career.opening_stage = "complete"
	career.coach_assignment.coach_id = coach_id
	career.coach_assignment.technical_tendencies = profile.technical_tendencies.duplicate(true)
	var route_dialog = preload("res://src/app/development_roadmap_dialog.gd").new()
	Engine.get_main_loop().root.add_child(route_dialog)
	route_dialog.career = career
	route_dialog.select_route(route)
	career.development_roadmap = route_dialog._build_roadmap().to_dict()
	route_dialog.free()
	report.priority_strategy = "unspecified_optional_jumps_delegated_to_coach"
	var intent = Intent.create(response).intent
	for period in quarters:
		if not career.condition_state.pending_decision.is_empty():
			report.stop_reason = "major_medical_choice"; break
		var before: Dictionary = career.clock.to_dict()
		var history_start: int = career.history.size()
		var built: Dictionary = Coach.build(career,intent)
		if built.plan == null: report.errors.append_array(built.errors); break
		var proposal = Authority.preview(career,built.plan)
		for authority_step in 8:
			if proposal.status == "resolved": break
			Authority.respond(career,proposal,proposal.conflicts[0].id,"accept",career.random_streams.take_rng("authority"))
		if proposal.status != "resolved": report.errors.append("authority_unresolved"); break
		var rng := RandomNumberGenerator.new(); rng.seed=seed_value+period*17
		var choices: Array = []
		for event in Events.generate(career,proposal,rng):
			var choice := str(event.choices[0].id)
			for preferred in ["report_pain","rest_now","reduce_load"]:
				if event.choices.any(func(row): return row.id == preferred): choice=preferred; break
			Events.resolve(career,event,choice,rng,proposal)
			choices.append({"event":event.signature,"choice":choice})
		for continuation in 8:
			Simulator.advance_proposal(career,proposal,catalog)
			if career.clock.to_dict() != before or not career.condition_state.pending_decision.is_empty(): break
			if not career.training_period_state.has("stage_checkpoint"): break
		if career.clock.to_dict() == before:
			if not career.condition_state.pending_decision.is_empty(): report.stop_reason="major_medical_choice"
			else: report.errors.append("training_did_not_complete")
			break
		var actual: Dictionary = proposal.executed.to_dict()
		var attempts: Array = []
		for row in career.history.slice(history_start):
			if row.get("category") == "jump_attempt_batch": attempts.append(row.duplicate(true))
		var stage_ids := {}
		for id in career.athlete.jumps:
			stage_ids[id] = {"double":Stage.evaluate(career,id,2).stage_id,"triple":Stage.evaluate(career,id,3).stage_id,"unlocked":career.athlete.jumps[id].unlocked_rotations}
		report.trace.append({"from":before,"to":career.clock.to_dict(),"plan":actual,"attempts":attempts,"stages":stage_ids,"choices":choices,"body":career.athlete.body.duplicate(true),"coach_memory":career.coach_training_state.duplicate(true)})
		report.executed_quarters += 1
		# These are post-training choices produced by the ordinary roadmap;
		# preserve the existing long-term target unless safety needs intervention.
		for data in career.condition_state.get("pending_training_events",[]):
			var event = preload("res://src/domain/quarter_event.gd").new()
			for key in ["id","signature","title","description"]: event.set(key,str(data.get(key,"")))
			event.choices.assign(data.get("choices",[]))
			if event.choices.is_empty(): report.errors.append("event_without_choice"); break
			var choice := str(event.choices[0].id)
			for preferred in ["roadmap_temporary_safety","roadmap_consolidate","keep_training_strategy"]:
				if event.choices.any(func(row): return row.id == preferred): choice=preferred; break
			Events.resolve(career,event,choice,rng)
		career.condition_state.pending_training_events = []
	report.final = {"clock":career.clock.to_dict(),"snapshot_origin":"actual_post_loop_career","jumps":{},"expression":career.athlete.mind.expression,"skating":career.athlete.skating.duplicate(true),"stress":career.condition_state.psychology.get("stress",0.0),"body":career.athlete.body.duplicate(true)}
	for id in career.athlete.jumps: report.final.jumps[id] = career.athlete.jumps[id].to_dict()
	for field in ["technique","spins","spin_foundation"]:
		report.final[field] = career.athlete.get(field).duplicate(true)
	report.completed = int(report.executed_quarters) == quarters and report.errors.is_empty()
	report.pending_decision = career.condition_state.pending_decision.duplicate(true)
	report.career_snapshot = career.to_dict()
	report.validation_errors = validate_report(report)
	return report
