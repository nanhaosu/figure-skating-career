extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var args := OS.get_cmdline_user_args()
	var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(args[0])
	if not loaded.ok: print("CONTINUE_LOAD ",loaded); quit(1); return
	var assigned := args.size() < 2 or args[1] != "steady"
	var result: Dictionary = await load("res://scripts/international_season_journey.gd").new().run(loaded.career,assigned,args[2] if args.size() > 2 else "selection")
	print("CONTINUED ",JSON.stringify({"errors":result.errors,"trace":result.trace,"clock":result.career.clock.to_dict(),"closed_seasons":result.career.season_state.get("season_history",{}).keys(),"reload":result.mid_competition_reload_equal,"archive_reload":result.archive_reload_equal,"free_edit":result.concrete_free_edit,"short_cut":result.short_cut}))
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(result.career)
	var node := {}
	if bundle.errors.is_empty(): node = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(result.career,bundle,func(_c): return true).stop_node
	print("SELECTION_NODE ",JSON.stringify(node))
	if node.get("kind") == "selection":
		var applied: Dictionary = load("res://src/simulation/career_command_service.gd").apply(result.career,{"type":"apply_entry","event_id":node.event_id,"route_id":"request_assignment"})
		print("SELECTION_RESULT ",JSON.stringify(applied.career.selection_state.decisions.jgp.decision if applied.ok else applied))
	print("CONTINUE_SAVE ",load("res://src/persistence/save_repository.gd").save(result.career,"user://continued-public-journey.json"))
	quit(0 if result.errors.is_empty() else 1)
