extends SceneTree

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var seed_value := 42000
	var route := "coach"
	var report_path := "user://experience-report.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--seed="): seed_value = int(argument.trim_prefix("--seed="))
		if argument.begins_with("--route="): route = argument.trim_prefix("--route=")
		if argument.begins_with("--report="): report_path = argument.trim_prefix("--report=")
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	var report: Dictionary = await driver.run_sample(seed_value,route)
	var file := FileAccess.open(report_path,FileAccess.WRITE)
	if file == null: push_error("cannot write calibration report"); quit(2); return
	file.store_string(JSON.stringify(report))
	file.close()
	quit(0 if report.get("completed",false) else 1)
