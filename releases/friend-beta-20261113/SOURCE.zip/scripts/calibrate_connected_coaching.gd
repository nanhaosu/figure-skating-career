extends SceneTree

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var args := {"seed":"42000","coach":"coach_lin","route":"fast","response":"accept","quarters":"24","report":"user://connected-coaching.json","source-hash":"unfingerprinted"}
	for argument in OS.get_cmdline_user_args():
		if not argument.begins_with("--") or not "=" in argument: continue
		var parts := argument.trim_prefix("--").split("=",true,1)
		if args.has(parts[0]): args[parts[0]]=parts[1]
	var report: Dictionary = preload("res://scripts/connected_coaching_sample.gd").new().run_sample(int(args.seed),args.coach,args.route,int(args.quarters),args.response)
	report.source_hash = args["source-hash"]
	var file := FileAccess.open(args.report,FileAccess.WRITE)
	if file == null: push_error("cannot write paired coaching report"); quit(2); return
	file.store_string(JSON.stringify(report)); file.close()
	print("COACHING_SAMPLE ",args.seed," ",args.coach," ",args.route," quarters=",report.executed_quarters," completed=",report.completed," errors=",report.get("validation_errors",report.errors))
	quit(0 if report.get("validation_errors",["missing_validation"]).is_empty() else 1)
