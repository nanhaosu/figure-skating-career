extends SceneTree
const F = preload("res://tests/fixtures.gd")
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var destination := "C:/Users/25775/Desktop/figure_skating/qa-health-visual-20261009"
	DirAccess.make_dir_recursive_absolute(destination)
	var main = load("res://src/app/main.tscn").instantiate()
	root.add_child(main)
	main.active_career = load("res://tests/simulation/test_combination_training_service.gd").new().prepared()
	var coach = preload("res://src/simulation/coach_training_plan_service.gd")
	var intent = preload("res://src/domain/training_intent.gd").create("accept").intent
	main.active_career.season_program_plan.targets = {"free":[{"element_id":"goal","action":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":3},{"jump_id":"toe_loop","rotations":3}]}}]}
	preload("res://src/simulation/career_simulator.gd").advance_quarter(main.active_career,coach.build(main.active_career,intent).plan,preload("res://src/content/catalog_repository.gd").load_catalog())
	for resolution in [Vector2i(960,540),Vector2i(1280,720)]:
		root.size = resolution
		main._open_player_home()
		await capture(destination,"home",resolution)
		for route in ["health","repertoire"]:
			main.open_route(route,{},main.screen_router.current())
			await capture(destination,route,resolution)
			main.back_route()
		main._present_season_planning("2019-20")
		await capture(destination,"planning",resolution)
		main._decision_dialog.hide()
		main.active_career.condition_state.injuries = [{"id":"visual-major","site":"ankle","severity":0.85,"remaining_quarters":2,"status":"active"}]
		main.active_career.condition_state.pending_decision = {"kind":"rehabilitation_initial","injury_id":"visual-major"}
		preload("res://src/persistence/save_repository.gd").save(main.active_career,destination+"/treatment-fixture.json")
		main._present_treatment(preload("res://src/simulation/season_progression_service.gd")._pending(main.active_career))
		await capture(destination,"treatment",resolution)
		main._decision_dialog.hide()
		main.active_career.condition_state.pending_decision = {}
		main.active_career.condition_state.injuries = []
		main._present_program_adjustment({"reason":"当前节目尚不符合本场青年组规则。","event_id":"visual-event","segment":"short","rules":{}})
		await capture(destination,"programme-unready",resolution)
		main._decision_dialog.hide()
	main.free()
	quit()
func capture(destination: String, name: String, resolution: Vector2i) -> void:
	for frame in 4: await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	var path := "%s/%s-%dx%d.png" % [destination,name,resolution.x,resolution.y]
	image.save_png(path)
	print("CAPTURE ",path)
