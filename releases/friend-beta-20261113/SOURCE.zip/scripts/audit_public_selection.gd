extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var loaded: Dictionary = load("res://src/persistence/save_repository.gd").load_save(OS.get_cmdline_user_args()[0])
	if not loaded.ok: print("AUDIT_LOAD ",loaded); quit(1); return
	var c = loaded.career
	var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
	var event: Dictionary = bundle.calendar.events.filter(func(e): return e.event_family == "jgp_stage")[0]
	# Public legal request on an isolated loaded copy; this diagnostic never saves
	# or changes the live journey, and is not claimed as its committed selection.
	var applied: Dictionary = load("res://src/simulation/career_command_service.gd").apply(c,{"type":"apply_entry","event_id":event.event_id,"route_id":"request_assignment"})
	if not applied.ok: print("AUDIT_REQUEST ",applied.error); quit(1); return
	var decision: Dictionary = applied.career.selection_state.decisions.jgp.decision
	var rows: Array = decision.audit.candidate_rows
	var player: Dictionary = rows.filter(func(r): return r.athlete_id == "player")[0]
	print("PUBLIC_SELECTION_AUDIT ",JSON.stringify({"clock":c.clock.to_dict(),"candidate_rank":rows.find(player)+1,"candidate_count":rows.size(),"available_slots":decision.audit.available_slots,"player":player,"leaders":rows.slice(0,4),"assignments":decision.assignments,"remaining_station_slots":decision.audit.remaining_station_slots}))
	quit()
