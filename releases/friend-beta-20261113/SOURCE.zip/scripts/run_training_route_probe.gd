extends SceneTree

func _initialize() -> void: call_deferred("run")

func run() -> void:
	var args := {"seed":"42000","coach":"coach_lin","route":"fast","quarters":"16","report":"user://training-probe.json"}
	for argument in OS.get_cmdline_user_args():
		var pieces := argument.trim_prefix("--").split("=",true,1)
		if pieces.size() == 2 and args.has(pieces[0]): args[pieces[0]] = pieces[1]
	var result: Dictionary = load("res://scripts/training_route_probe.gd").new().run_sample(int(args.seed),args.coach,args.route,int(args.quarters),"accept")
	var career = load("res://src/domain/career_state.gd").from_dict(result.career_snapshot)
	result.scope = "normal UI route preset and natural quarter coaching; not a complete calendar career"
	result.jump_readiness = {}
	for id in ["toe_loop","salchow","loop","flip","lutz"]:
		var profile = career.athlete.jumps[id]
		var stage: Dictionary = load("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,id,3)
		result.jump_readiness[id] = {"unlocked":profile.unlocked_rotations,"proficiency":profile.proficiency.triple,"official_consistency":profile.consistency.official,"stage":stage.stage_id,"evidence":stage.evidence,"repertoire":career.technical_repertoire.entries.get("3"+{"toe_loop":"T","salchow":"S","loop":"Lo","flip":"F","lutz":"Lz"}[id],{}).get("state","missing")}
	var file := FileAccess.open(args.report,FileAccess.WRITE)
	if file == null: push_error("Cannot write training probe"); quit(2); return
	file.store_string(JSON.stringify(result)); file.close()
	print("TRAINING_PROBE ",args.seed," ",args.coach," ",args.route," completed=",result.completed," errors=",result.validation_errors," readiness=",JSON.stringify(result.jump_readiness))
	quit(0 if result.validation_errors.is_empty() else 1)
