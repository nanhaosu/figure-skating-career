param(
    [string]$GodotExe='C:/Users/25775/Desktop/figure_skating/.tools/godot-4.7.2/Godot_v4.7.2-stable_win64_console.exe',
    [string]$EvidenceDir='C:/Users/25775/Desktop/figure_skating/qa-runs/connected-coach-20261019-cohort',
    [ValidateRange(1,2)][int]$Workers=2,
    [ValidateRange(1,20)][int]$SeedCount=20,
    [ValidateSet('accept','more_aggressive')][string]$Response='accept',
    [int]$TimeoutSeconds=600
)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path $PSScriptRoot -Parent
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null
Push-Location -LiteralPath $projectRoot
try { $sourceFiles=& rg --files src data scripts } finally { Pop-Location }
if ($LASTEXITCODE -ne 0) { throw 'Cannot enumerate source' }
$lines=foreach ($file in ($sourceFiles | Sort-Object)) { $file+':'+(Get-FileHash -LiteralPath (Join-Path $projectRoot $file) -Algorithm SHA256).Hash }
$fingerprint=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes(($lines -join "`n"))))
$queue=[Collections.Generic.Queue[object]]::new()
$results=[Collections.Generic.List[object]]::new()
foreach ($seedValue in 42000..(41999+$SeedCount)) {
    foreach ($coach in @('coach_lin','coach_zhao','coach_he','coach_tang','coach_sun','coach_qiao')) {
        foreach ($route in @('balanced','fast')) {
            $id="$seedValue-$coach-$route-$Response"
            $reportPath=Join-Path $EvidenceDir ($id+'.json')
            if (Test-Path -LiteralPath $reportPath) {
                $old=Get-Content -LiteralPath $reportPath -Raw | ConvertFrom-Json
                if ($old.source_hash -eq $fingerprint -and $old.response -eq $Response -and $old.seed -eq $seedValue -and $old.coach_id -eq $coach -and $old.route -eq $route -and $old.requested_quarters -eq 24 -and @($old.validation_errors).Count -eq 0 -and ($old.completed -or $old.stop_reason -eq 'major_medical_choice')) { $results.Add($old); continue }
            }
            $queue.Enqueue(@{id=$id;seed=$seedValue;coach=$coach;route=$route;report=$reportPath})
        }
    }
}
$active=[Collections.Generic.List[object]]::new()
$failures=0
Write-Output "COACHING_BEGIN hash=$fingerprint resumed=$($results.Count) remaining=$($queue.Count)"
while ($queue.Count -gt 0 -or $active.Count -gt 0) {
    while ($queue.Count -gt 0 -and $active.Count -lt $Workers) {
        $job=$queue.Dequeue()
        $job.log=Join-Path $EvidenceDir ($job.id+'.log')
        $job.err=Join-Path $EvidenceDir ($job.id+'.stderr.log')
        $job.started=[DateTime]::UtcNow
        $appData=Join-Path $EvidenceDir ('appdata-'+$job.id)
        New-Item -ItemType Directory -Force -Path $appData | Out-Null
        $job.process=Start-Process -FilePath $GodotExe -WindowStyle Hidden -WorkingDirectory $projectRoot -ArgumentList @('--headless','--path',$projectRoot,'--script','scripts/calibrate_connected_coaching.gd','--',('--seed='+$job.seed),('--coach='+$job.coach),('--route='+$job.route),('--response='+$Response),'--quarters=24',('--report='+$job.report),('--source-hash='+$fingerprint)) -Environment @{APPDATA=$appData} -RedirectStandardOutput $job.log -RedirectStandardError $job.err -PassThru
        $active.Add($job)
    }
    foreach ($job in @($active.ToArray())) {
        $job.process.Refresh()
        if (-not $job.process.HasExited) {
            if (([DateTime]::UtcNow-$job.started).TotalSeconds -gt $TimeoutSeconds) { Stop-Process -Id $job.process.Id; $failures++; $active.Remove($job) | Out-Null; Write-Output "COACHING_TIMEOUT $($job.id)" }
            continue
        }
        $job.process.WaitForExit()
        $runtime=Select-String -Path $job.log,$job.err -Pattern '^SCRIPT ERROR:|^ERROR:'
        $report=$null
        if (Test-Path -LiteralPath $job.report) { $report=Get-Content -LiteralPath $job.report -Raw | ConvertFrom-Json }
        if ($job.process.ExitCode -ne 0 -or $runtime -or $null -eq $report -or @($report.validation_errors).Count -gt 0) {
            $failures++; Write-Output "COACHING_FAILED $($job.id) exit=$($job.process.ExitCode)"
        } else { $results.Add($report); Write-Output "COACHING_VALID $($job.id) quarters=$($report.executed_quarters) completed=$($report.completed)" }
        $active.Remove($job) | Out-Null
        $job.process.Dispose()
    }
    Start-Sleep -Milliseconds 250
}
$summary=@{source_hash=$fingerprint;valid_reports=$results.Count;completed_24_quarters=@($results | Where-Object completed).Count;medical_stops=@($results | Where-Object { $_.stop_reason -eq 'major_medical_choice' }).Count;failures=$failures;expected=$SeedCount*12;scope='paired natural training only; not calendar/dispatch/persistence evidence'}
$summary | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $EvidenceDir 'summary.json') -Encoding utf8
Write-Output ($summary | ConvertTo-Json -Compress)
if ($failures -gt 0 -or $results.Count -ne $SeedCount*12) { exit 1 }
