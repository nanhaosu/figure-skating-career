param([string]$BuildDir = 'build/web')
$ErrorActionPreference = 'Stop'
$sourceBuild = (Resolve-Path -LiteralPath $BuildDir).Path
$probeRoot = Join-Path ([IO.Path]::GetTempPath()) ('figure-skating-web-smoke-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $probeRoot | Out-Null
foreach ($name in @('index.html','index.js','index.wasm','index.pck')) {
    Copy-Item -LiteralPath (Join-Path $sourceBuild $name) -Destination (Join-Path $probeRoot $name)
}
foreach ($missing in @('index.audio.worklet.js','index.audio.position.worklet.js')) {
    $rejected = $false
    try { & (Join-Path $PSScriptRoot 'web_smoke_check.ps1') -BuildDir $probeRoot | Out-Null }
    catch {
        if (-not $_.Exception.Message.Contains("Missing artifact: $missing")) { throw }
        $rejected = $true
    }
    if (-not $rejected) { throw "Missing worklet was accepted: $missing" }
    Write-Output "PASS: missing $missing rejected"
    Copy-Item -LiteralPath (Join-Path $sourceBuild $missing) -Destination (Join-Path $probeRoot $missing)
}
& (Join-Path $PSScriptRoot 'web_smoke_check.ps1') -BuildDir $probeRoot | Out-Null
Write-Output 'PASS: complete fixture accepted'
$runtimePath = Join-Path $probeRoot 'index.js'
$runtime = [IO.File]::ReadAllText($runtimePath)
[IO.File]::WriteAllText($runtimePath, $runtime.Replace('globalThis.figureSkatingInstallDurability(GodotFS,FS,IDBFS);',''))
$rejected = $false
try { & (Join-Path $PSScriptRoot 'web_smoke_check.ps1') -BuildDir $probeRoot | Out-Null }
catch {
    if (-not $_.Exception.Message.Contains('Missing acknowledged persistence bridge')) { throw }
    $rejected = $true
}
if (-not $rejected) { throw 'Unacknowledged memory-only persistence was accepted' }
Write-Output 'PASS: missing acknowledged persistence bridge rejected'
# Remove only the six files this probe copied; never recursively remove a path.
foreach ($name in @('index.html','index.js','index.wasm','index.pck','index.audio.worklet.js','index.audio.position.worklet.js')) {
    Remove-Item -LiteralPath (Join-Path $probeRoot $name)
}
Remove-Item -LiteralPath $probeRoot
