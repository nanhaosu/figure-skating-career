param([string]$BuildDir = "build/web", [switch]$Serve, [int]$Port = 8060, [string]$PythonExecutable = 'python')
$ErrorActionPreference = 'Stop'
$resolvedBuild = (Resolve-Path -LiteralPath $BuildDir).Path
foreach ($name in @('index.html','index.js','index.wasm','index.pck','index.audio.worklet.js','index.audio.position.worklet.js')) {
    $file = Join-Path $resolvedBuild $name
    if (-not (Test-Path -LiteralPath $file) -or (Get-Item -LiteralPath $file).Length -eq 0) { throw "Missing artifact: $name" }
}
$html = Get-Content -LiteralPath (Join-Path $resolvedBuild 'index.html') -Raw -Encoding UTF8
$chineseTitle = -join (0x82B1,0x6837,0x6ED1,0x51B0,0x751F,0x6DAF | ForEach-Object { [char]$_ })
if (-not $html.Contains($chineseTitle)) { throw 'Missing Chinese title' }
if (-not $html.Contains('figureSkatingUpload')) { throw 'Missing upload bridge' }
if ($html -notmatch '"\s*canvasResizePolicy"\s*:\s*2') { throw 'Responsive canvas not configured' }
if ($html -notmatch 'GODOT_THREADS_ENABLED\s*=\s*false') { throw 'Thread requirement must be disabled' }
$runtime = Get-Content -LiteralPath (Join-Path $resolvedBuild 'index.js') -Raw -Encoding UTF8
if (-not $runtime.Contains('globalThis.figureSkatingInstallDurability(GodotFS,FS,IDBFS);')) { throw 'Missing acknowledged persistence bridge' }
Write-Output 'PASS: Web artifacts, Chinese metadata, file bridge, acknowledged IDBFS, responsive canvas and no threads.'
Get-ChildItem -LiteralPath $resolvedBuild -File | ForEach-Object { Write-Output "$($_.Name) $($_.Length) bytes $((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)" }
if ($Serve) { & $PythonExecutable -m http.server $Port --bind 127.0.0.1 --directory $resolvedBuild }
