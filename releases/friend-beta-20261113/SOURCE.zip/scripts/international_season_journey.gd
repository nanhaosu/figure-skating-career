extends RefCounted

# Reproducible acceptance choices through the same panels, commands and services
# exposed to a player. Never manufacture athlete, selection or scoring state.
const Bundle = preload("res://src/content/season_bundle_repository.gd")
const Progression = preload("res://src/simulation/season_progression_service.gd")
const Command = preload("res://src/simulation/career_command_service.gd")
const Save = preload("res://src/persistence/save_repository.gd")
const Roadmap = preload("res://src/domain/development_roadmap.gd")
const Draft = preload("res://src/simulation/program_draft_service.gd")
const Nodes = preload("res://src/simulation/key_node_service.gd")

var main
var errors: Array[String] = []
var trace: Array[String] = []
var assigned_route := true
var concrete_free_edit := false
var short_cut := false
var mid_competition_reload_equal := false
var archive_reload_equal := false
var check_roundtrips := true
var prepared_content_seasons := {}

func run(career, assigned: bool, stop_at: String = "") -> Dictionary:
	assigned_route = assigned
	if career.clock.year >= 2019 and _season_content_already_prepared(career,career.clock.year):
		prepared_content_seasons[career.clock.year] = true
	# Screening runs are reachability samples, not persistence acceptance.
	check_roundtrips = stop_at not in ["selection","spring_ready"]
	var route := "planned" if assigned else "steady"
	var save_path := "user://journey-%s-%d.json" % [route,career.seed]
	var autosave_path := "user://journey-%s-%d-autosave.json" % [route,career.seed]
	_clear_save_family(save_path)
	_clear_save_family(autosave_path)
	main = load("res://src/app/main.tscn").instantiate()
	main.save_path = save_path
	main.autosave_path = autosave_path
	Engine.get_main_loop().root.add_child(main)
	_adopt(career)
	for step in 400:
		career = main.active_career
		if stop_at == "spring_ready" and career.clock.year == 2019 and career.clock.quarter == 2: break
		if stop_at == "trained" and career.clock.year == 2018 and career.clock.quarter == 2: break
		if stop_at == "first_result" and career.competition_archive.any(func(a): return not a.get("world_only",false)): break
		if career.clock.year < 2018 or (career.clock.year == 2018 and career.clock.quarter == 1):
			await _train_quarter()
		else:
			var year := 2019 if career.season_state.get("season_history",{}).has("2018-19") else 2018
			var bundle := Bundle.load_bundle(year,"women_singles","junior")
			if not bundle.errors.is_empty(): errors.append_array(bundle.errors); break
			if year == 2019 and not prepared_content_seasons.has(year) and career.competition_state.is_empty():
				var prepared := true
				for segment in ["short","free"]:
					if not _upgrade_program(segment,load("res://src/content/internal_event_rules.gd").for_season(year,"junior",segment)): prepared = false
				if prepared: prepared_content_seasons[year] = true
				career = main.active_career
			var result := Progression.advance_to_next_node(career,bundle,func(c): return Save.save(c,main.autosave_path).ok)
			if not result.errors.is_empty(): errors.append_array(result.errors); break
			_adopt(result.career)
			var node: Dictionary = result.stop_node
			var label := "%d:%s:%s" % [year,node.kind,node.get("event_id","")]
			trace.append(label); print("JOURNEY ",assigned," ",step," ",label)
			if stop_at == "selection" and year == 2019 and node.kind == "selection": break
			if node.kind == "season_complete":
				if year == 2019: break
				continue
			await _handle_node(node,bundle)
		if not errors.is_empty(): break
		if step == 399: errors.append("journey_node_limit")
	career = main.active_career
	var result := {"career":career,"errors":errors,"trace":trace,"concrete_free_edit":concrete_free_edit,"short_cut":short_cut,"mid_competition_reload_equal":mid_competition_reload_equal,"archive_reload_equal":archive_reload_equal}
	main.free()
	return result

func _clear_save_family(path: String) -> void:
	for suffix in ["",".tmp",".bak",".meta"]:
		var target: String = path + str(suffix)
		if FileAccess.file_exists(target): DirAccess.remove_absolute(ProjectSettings.globalize_path(target))

func _season_content_already_prepared(career, year: int) -> bool:
	var validator = load("res://src/simulation/program_validator.gd")
	for segment in ["short","free"]:
		var program = load("res://src/domain/skating_program.gd").from_dict(career.active_programs.get(segment,{}))
		var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(year,"junior",segment)
		if program == null or not validator.validate(program,career.athlete,rules).is_empty(): return false
		if assigned_route:
			if not program.elements.any(func(element): return element.kind == "jump" and element.combination_parts.any(func(part): return part.jump_id == "toe_loop" and int(part.rotations) == 3)):
				return false
	return true

func _adopt(career) -> void:
	# Publish this QA snapshot with the same activation effects as before.
	# It continues the current career, so it must not ask to replace it.
	main.get_node("%QuarterPanel").authority_confirmation.hide()
	main.get_node("%QuarterPanel").event_dialog.hide()
	main._activate_new_career(career)

func _train_quarter() -> void:
	var career = main.active_career
	var bundle := Bundle.for_career(career)
	var required: Dictionary = Progression.quarter_gate(career,bundle)
	if str(required.get("kind","")) in ["season_program_planning","rehabilitation_decision","offseason_event","season_transition"]:
		await _handle_node(required,bundle)
		return
	var pending := Nodes.pending(career)
	if not pending.is_empty():
		main.get_node("%SummaryPanel").key_node_response_requested.emit(pending[0].id)
		trace.append("body:"+str(pending[0].kind))
		return
	if not assigned_route: load("res://src/simulation/internal_invitation_service.gd").defer(career)
	main.open_next_quarter()
	var panel = main.get_node("%QuarterPanel")
	if not panel.visible:
		errors.append("training_screen_blocked:"+main.get_node("%GlobalMessage").text); return
	if panel.event_dialog.visible:
		_choose_events(panel)
		return
	var ready: bool = ["toe_loop","salchow","loop","axel"].all(func(id): return career.athlete.jumps[id].unlocked_rotations >= 1)
	if ready:
		for segment in ["short","free"]:
			if career.active_programs[segment].is_empty():
				_edit_program(segment,load("res://src/content/internal_event_rules.gd").for_teaching_group(segment),false)
				if not errors.is_empty(): return
			elif career.clock.year >= 2015 and career.active_programs[segment].elements.size() < (7 if segment == "short" else 11):
				var formal_rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(2018,"junior",segment)
				# Keep rehearsing the playable teaching programme until the required
				# 2A/prescribed jump content is actually learned. Opening a knowingly
				# invalid formal draft would trap the same novice this journey models.
				if _can_draft_program(career,segment,formal_rules):
					_edit_program(segment,formal_rules,true)
					if not errors.is_empty(): return
			elif career.clock.year == 2017 and career.clock.quarter == 1:
				_edit_program(segment,load("res://src/content/internal_event_rules.gd").for_season(2018,"junior",segment),true)
				if not errors.is_empty(): return
			elif career.clock.year == 2018 and career.clock.quarter == 1:
				_upgrade_program(segment,load("res://src/content/internal_event_rules.gd").for_season(2018,"junior",segment))
				if not errors.is_empty(): return
		if career.clock.quarter == 1:
			_prepare_next_season()
			if not errors.is_empty(): return
		career = main.active_career
		if assigned_route and load("res://src/simulation/internal_invitation_service.gd").status(career).ready:
			var started: Dictionary = main.start_internal_competition()
			if not started.ok: errors.append_array(started.errors); return
			var competition = main.get_node("%CompetitionPanel")
			competition.settle_immediately()
			competition.adjustment_selected.emit("keep")
			competition.settle_immediately()
			competition.competition_confirmed.emit()
			trace.append("internal:first_teaching_event")
			return
		main.open_next_quarter(); panel = main.get_node("%QuarterPanel"); career = main.active_career
		panel.internal_competition_deferred.emit()
		main.open_next_quarter(); panel = main.get_node("%QuarterPanel"); career = main.active_career
	var jump_ids: Array = career.athlete.jumps.keys()
	var rotation := 2 if career.clock.year < 2016 else 3
	var key := "double" if rotation == 2 else "triple"
	jump_ids.sort_custom(func(a,b): return career.athlete.jumps[a].proficiency[key] < career.athlete.jumps[b].proficiency[key])
	var roadmap := Roadmap.create("fast" if assigned_route else "steady",[{"age":10,"rotations":2,"count":6},{"age":13 if assigned_route else 15,"rotations":3,"count":5 if assigned_route else 3}],[jump_ids[0],jump_ids[1]],"","normal")
	panel.apply_roadmap(roadmap.roadmap)
	if ready:
		# Six jump families share the same supervised practice budget; keep recovery
		# and both full-program rehearsals instead of filling every spare hour.
		panel.set_allocations(_competitive_allocations(career))
		for id in ["toe_loop","salchow","loop","flip","lutz","axel"]: panel.set_jump_rotation(id,_practice_rotation(career,id,mini(2 if id == "axel" else rotation,career.athlete.jumps[id].unlocked_rotations+1)))
	if not ready:
		panel.set_allocations({"skating_foundation":10,"jump_toe_loop":10,"jump_salchow":10,"jump_loop":10,"jump_flip":10,"jump_lutz":10,"jump_axel":10,"rest":30})
		for id in ["toe_loop","salchow","loop","flip","lutz","axel"]: panel.set_jump_rotation(id,1)
	if not load("res://src/simulation/athlete_condition_service.gd").can_compete(career):
		panel.set_allocations({"skating_foundation":20,"conditioning":10,"rotation":10,"rest":60})
	var before: Dictionary = career.clock.to_dict()
	for attempt in 12:
		panel.request_advance()
		if panel.authority_confirmation.visible: panel.confirm_authority_adjustment()
		_choose_events(panel)
		if main.active_career.clock.to_dict() != before: break
		var gate: Dictionary = Progression.quarter_gate(main.active_career,panel.season_bundle)
		if str(gate.get("kind","")) == "rehabilitation_decision":
			await _handle_node(gate,panel.season_bundle)
			return
		if not assigned_route and str(gate.get("kind","")) == "internal_invitation":
			# The invitation can become due only after this quarter's training has
			# committed. Deferring it is itself this iteration's meaningful public
			# action; the next iteration reopens a fresh quarter panel and advances.
			await main._on_internal_competition_deferred()
			return
	if main.active_career.clock.to_dict() == before:
		errors.append("quarter_did_not_advance:"+panel.plan_error_label.text)
		print("TRAIN_STOP proposal=",panel._active_proposal.to_dict() if panel._active_proposal != null else {}," policy=",main.active_career.last_training_policy," pending=",panel._pending_events," node=",Progression.quarter_gate(main.active_career,panel.season_bundle)," message=",main.get_node("%GlobalMessage").text)
	else: print("TRAIN ",assigned_route," ",main.active_career.clock.to_dict()," grade=",main.active_career.certification_state.national_technical_grade)

func _can_draft_program(career, segment: String, rules: Dictionary) -> bool:
	var proposal: Dictionary = Draft.propose(career.athlete,segment,rules,{"title":"春江花月夜"},0)
	return proposal.errors.is_empty() and proposal.missing.is_empty()

func _competitive_allocations(career = null) -> Dictionary:
	# A viable long-term junior plan must keep every technical family moving
	# without turning programme rehearsals into an unrecoverable load spiral.
	# The compressed calendar makes each programme unit more effective, so eight
	# units per segment leave room for jump development. A junior newcomer should
	# first make the season's required solo jump and combination reliable instead
	# of spreading the same budget across five equally shaky triples.
	var axel_is_stable := career == null or float(career.athlete.jumps.axel.proficiency.double) >= 70.0
	if career != null and career.technical_repertoire.entries.get("2A",{}).get("state") == "unavailable": axel_is_stable = false
	# Keep total jump share below the ordinary guardian-intervention threshold.
	# Before 2A is stable, pause flip work for one compressed phase; afterwards
	# maintain 2A through shared foundations and restore flip training.
	return {"skating_foundation":5,"jump_toe_loop":10,"jump_salchow":5,"jump_loop":10,"jump_flip":5 if axel_is_stable else 0,"jump_lutz":5,"jump_axel":0 if axel_is_stable else 5,"rotation":5,"conditioning":10,"rest":25,"program_short":10,"program_free":10}

func _practice_rotation(career, jump_id: String, preferred: int) -> int:
	var recovery := 0
	for item in career.technical_repertoire.entries.values():
		if item.get("state") != "unavailable" or not bool(item.get("learned_history",{}).get("ever_learned",false)): continue
		var parts: Array = item.action.parts
		if parts.size() != 1 or parts[0].jump_id != jump_id: continue
		var rotations := int(parts[0].rotations)
		if rotations <= preferred and (recovery == 0 or rotations < recovery): recovery = rotations
	return recovery if recovery > 0 else preferred

func _choose_events(panel) -> void:
	for i in 24:
		if not panel.event_dialog.visible: return
		var buttons: Array = panel.event_dialog.choice_buttons.get_children().filter(func(b): return not b.is_queued_for_deletion())
		if buttons.is_empty(): return
		trace.append("event:"+panel.event_dialog.event_title.text)
		buttons[0].pressed.emit()

func _edit_program(segment: String, rules: Dictionary, competitive: bool) -> void:
	var career = main.active_career
	var editor = main.get_node("%ProgramEditorPanel")
	var proposal := Draft.propose(career.athlete,segment,rules,{"title":"春江花月夜"},0)
	editor.present(career,segment,rules,proposal)
	editor.refresh_coach_draft()
	if competitive:
		var stable_core := ["loop","toe_loop","salchow","lutz"].all(func(id): return _competition_rotation(career,id,3) == 3)
		var specs := [["axel",2,[]],["toe_loop",3,[{"jump_id":"toe_loop","rotations":3}]],["flip",3,[]]] if segment == "short" else [["lutz",3,[{"jump_id":"toe_loop","rotations":3}]],["flip",3,[{"jump_id":"loop","rotations":2}]],["axel",2,[{"jump_id":"toe_loop","rotations":2},{"jump_id":"loop","rotations":1}]],["loop",3,[]],["salchow",3,[]],["lutz",3,[]],["axel",2,[]]]
		if segment == "short" and rules.has("required_solo_jump"):
			# Junior short-program prescriptions change by season. Preserve the
			# mandated solo jump instead of assuming a fixed historical slot.
			var solo_id := str(rules.required_solo_jump)
			var combo_base := "lutz" if solo_id != "lutz" else "flip"
			specs = [["axel",2,[]],[solo_id,3,[]],[combo_base,3,[{"jump_id":"toe_loop","rotations":3}]]]
		if assigned_route and stable_core:
			# Once the core triples are genuinely ready, keep five triples but place
			# the most stable Loop and Toe jumps in combinations instead of gambling
			# the whole skate on 3Lz+3T. This remains a public player configuration.
			if segment != "short" or not rules.has("required_solo_jump"):
				specs = [["axel",2,[]],["loop",3,[{"jump_id":"toe_loop","rotations":3}]],["flip",3,[]]] if segment == "short" else [["loop",3,[{"jump_id":"toe_loop","rotations":3}]],["toe_loop",3,[{"jump_id":"loop","rotations":2}]],["axel",2,[{"jump_id":"toe_loop","rotations":2},{"jump_id":"loop","rotations":1}]],["loop",3,[]],["salchow",3,[]],["lutz",3,[]],["axel",2,[]]]
		if segment == "free" and ["flip","lutz"].any(func(id): return career.athlete.jumps[id].unlocked_rotations < 1):
			specs = [["toe_loop",2,[{"jump_id":"toe_loop","rotations":2}]],["salchow",2,[{"jump_id":"loop","rotations":2}]],["axel",2,[]],["loop",2,[]],["salchow",2,[]],["toe_loop",1,[]],["axel",2,[]]]
		for i in specs.size():
			var spec: Array = specs[i]
			var rotations: int = _competition_rotation(career,str(spec[0]),int(spec[1]))
			var parts: Array = spec[2].duplicate(true)
			for part in parts:
				part.rotations = _competition_rotation(career,str(part.jump_id),int(part.rotations))
				# The initial short-program choice stays cautious. Selecting a
				# triple follow-up is a separate public player action below.
				if segment == "short": part.rotations = mini(int(part.rotations),2)
			editor.replace_jump(i,spec[0],rotations,parts)
	if competitive:
		editor.difficulty_input.select(1 if assigned_route else 0)
		editor.difficulty_input.item_selected.emit(1 if assigned_route else 0)
		for i in editor.program.elements.size():
			if editor.program.elements[i].kind not in ["spin","step_sequence"]: continue
			editor.action_list.select(i); editor.action_list.item_selected.emit(i)
			var technique: float = float(career.athlete.technique.rotation) if editor.program.elements[i].kind == "spin" else _mean_skating(career)
			editor.get_node("%TargetLevelInput").value = clampi(int(floor(technique / 20.0)) + 1,1,4)
			editor.get_node("%ApplyDetailsButton").pressed.emit()
		if assigned_route:
			# Explicit legal ice-time ordering via the same public move operation.
			# Put eligible final jumps in the second half instead of front-loading.
			var order := [2,3,0,4,5,6,1] if segment == "short" else [0,7,1,8,2,10,3,9,4,5,6]
			var ids: Array = editor.program.elements.map(func(e): return e.element_id)
			# Historical rules can change the number of required spins or sequences.
			# Keep the preferred broadcast order where possible, then retain every
			# additional action instead of indexing a stale fixed-length template.
			order = order.filter(func(index): return int(index) >= 0 and int(index) < ids.size())
			for index in ids.size():
				if not order.has(index): order.append(index)
			for target in order.size():
				var current: Array = editor.program.elements.map(func(e): return e.element_id)
				var index: int = current.find(ids[order[target]])
				if index >= 0: editor.move_element(index,target-index)
	if editor.get_node("%LockButton").disabled:
		errors.append("program_invalid:"+editor.status_label.text); return
	# The public editor deliberately separates a harmless draft save from the
	# competition lock. This journey represents a player choosing to enter, so
	# it must use that explicit control rather than leaving a legal draft unfiled.
	editor.get_node("%LockButton").pressed.emit()
	var validation: Array = load("res://src/simulation/program_validator.gd").validate(load("res://src/domain/skating_program.gd").from_dict(main.active_career.active_programs[segment]),main.active_career.athlete,rules)
	if not validation.is_empty(): errors.append("program_save_did_not_commit:"+str(validation)+":"+main.get_node("%GlobalMessage").text)

func _prepare_next_season() -> void:
	var year: int = main.active_career.clock.year
	if year <= Bundle.season_year(main.active_career) or prepared_content_seasons.has(year): return
	for segment in ["short","free"]:
		main.open_program_editor(segment)
		var editor = main.get_node("%ProgramEditorPanel")
		var choice: OptionButton = editor.get_node("%TargetSeasonChoice")
		var index := -1
		for i in choice.item_count:
			if int(choice.get_item_metadata(i)) == year: index = i
		# Only published next-season rules are offered by the player's control.
		if index < 0 or choice.disabled: return
		choice.select(index)
		choice.item_selected.emit(index)
		var target_rules: Dictionary = editor.rules.duplicate(true)
		_adjust_program(segment,target_rules)
		if not errors.is_empty(): return
		if not _upgrade_program(segment,target_rules): return
		# This deterministic journey represents a player's explicit high-content
		# choice in the public editor. The career system itself never mutates a
		# saved combination merely because an individual jump improved.
		if assigned_route and year >= 2019: _apply_player_combo_choice(segment,target_rules)
	prepared_content_seasons[year] = true
	trace.append("program:preseason:%d" % year)

func _upgrade_program(segment: String, rules: Dictionary) -> bool:
	var career = main.active_career
	var existing = load("res://src/domain/skating_program.gd").from_dict(career.active_programs.get(segment,{}))
	var validator = load("res://src/simulation/program_validator.gd")
	# Mandatory menu changes remain a separate visible progression node.
	if existing == null or not validator.validate(existing,career.athlete,rules).is_empty(): return false
	var editor = main.get_node("%ProgramEditorPanel")
	editor.present(career,segment,rules,{})
	var changed := false
	for i in editor.program.elements.size():
		var e = editor.program.elements[i]
		if e.kind != "jump": continue
		var old_rotation: int = e.rotations
		var target: int = _competition_rotation(career,str(e.jump_id),2 if e.jump_id == "axel" else 3)
		if target <= old_rotation: continue
		var parts: Array = e.combination_parts.duplicate(true)
		editor.replace_jump(i,e.jump_id,target,parts)
		if not validator.validate(editor.program,career.athlete,rules).is_empty():
			editor.replace_jump(i,e.jump_id,old_rotation,parts)
		else: changed = true
	if changed:
		if editor.get_node("%SaveButton").disabled: errors.append("preseason_upgrade_invalid:"+editor.status_label.text); return false
		editor.get_node("%SaveButton").pressed.emit()
		if editor.get_node("%LockButton").disabled: errors.append("preseason_upgrade_lock_invalid:"+editor.status_label.text); return false
		editor.get_node("%LockButton").pressed.emit()
	return true

func _apply_player_combo_choice(segment: String, target_rules: Dictionary) -> bool:
	var career = main.active_career
	var editor = main.get_node("%ProgramEditorPanel")
	editor.present(career,segment,target_rules,{})
	var target_index := -1
	for i in editor.program.elements.size():
		var element = editor.program.elements[i]
		if element.kind == "jump" and element.combination_parts.any(func(part): return str(part.jump_id) == "toe_loop"):
			target_index = i
			break
	if target_index < 0:
		errors.append("player_combo_missing_toe_slot:%s" % segment)
		return false
	var element = editor.program.elements[target_index]
	var parts: Array = element.combination_parts.duplicate(true)
	var changed := false
	for part in parts:
		if str(part.jump_id) != "toe_loop": continue
		var target := _competition_rotation(career,"toe_loop",3)
		if target > int(part.rotations):
			part.rotations = target
			changed = true
	if not changed:
		var already_selected: bool = element.combination_parts.any(func(part): return str(part.jump_id) == "toe_loop" and int(part.rotations) == 3)
		if already_selected: trace.append("program:player_combo_choice:%d:%s" % [int(target_rules.get("season_start_year",career.clock.year)),segment])
		return already_selected
	var replacement_errors: Array = editor.replace_jump(target_index,element.jump_id,element.rotations,parts)
	if not replacement_errors.is_empty():
		errors.append("player_combo_replace_invalid:%s:%s" % [segment,";".join(replacement_errors)])
		return false
	if editor.get_node("%LockButton").disabled:
		errors.append("player_combo_lock_invalid:%s:%s" % [segment,editor.status_label.text])
		return false
	editor.get_node("%LockButton").pressed.emit()
	var saved = load("res://src/domain/skating_program.gd").from_dict(main.active_career.active_programs.get(segment,{}))
	if saved == null or not saved.elements.any(func(e): return e.kind == "jump" and e.combination_parts.any(func(part): return str(part.jump_id) == "toe_loop" and int(part.rotations) == 3)):
		errors.append("player_combo_not_persisted:%s" % segment)
		return false
	trace.append("program:player_combo_choice:%d:%s" % [int(target_rules.get("season_start_year",career.clock.year)),segment])
	return true

func _adjust_program(segment: String, rules: Dictionary) -> void:
	var career = main.active_career
	var editor = main.get_node("%ProgramEditorPanel")
	editor.present(career,segment,rules,{})
	if editor.program == null:
		_edit_program(segment,rules,true); return
	# A deferred teaching invitation may leave the small teaching programme in
	# place until the first formal start. Annual slot edits cannot expand it;
	# choose the public coach-redraft action before trying to lock formal rules.
	for requirement in [["jump","jump_min"],["spin","spin_min"],["step_sequence","step_min"]]:
		var kind: String = requirement[0]
		if editor.program.elements.filter(func(element): return element.kind == kind).size() < int(rules.get(requirement[1],0)):
			_edit_program(segment,rules,true); return
	if not _can_apply_required_jump_menu(career,editor.program,rules):
		trace.append("program:qualification_gap:%d:%s" % [int(rules.get("season_start_year",career.clock.year)),segment])
		editor.hide()
		return
	# Adding a senior choreographic sequence requires the explicitly chosen
	# coach redraft in the current editor; ordinary annual changes do not.
	if int(rules.get("choreographic_min",0)) > editor.program.elements.filter(func(e): return e.kind == "choreographic_sequence").size():
		_edit_program(segment,rules,true); return
	if int(rules.get("choreographic_min",0)) == 0:
		for index in range(editor.program.elements.size()-1,-1,-1):
			if editor.program.elements[index].kind == "choreographic_sequence":
				editor.action_list.select(index); editor.get_node("%RemoveActionButton").pressed.emit()
	if rules.has("required_spin_codes"):
		var kept := {}; var extras: Array = []
		for i in editor.program.elements.size():
			var e = editor.program.elements[i]
			if e.kind != "spin": continue
			var canonical: String = e.spin_code
			for code in rules.get("spin_alternatives",{}):
				if rules.spin_alternatives[code].has(e.spin_code): canonical = code
			if rules.required_spin_codes.has(canonical) and not kept.has(canonical): kept[canonical] = true
			else: extras.append(i)
		for code in rules.required_spin_codes:
			if not kept.has(code) and not extras.is_empty(): editor.set_spin_type(extras.pop_front(),code)
	if rules.has("required_solo_jump"):
		var axel_combo_index := -1
		var replacement_combo_index := -1
		for i in editor.program.elements.size():
			var e = editor.program.elements[i]
			if e.kind != "jump": continue
			if e.jump_id == "axel" and not e.combination_parts.is_empty(): axel_combo_index = i
			elif e.jump_id != "axel" and replacement_combo_index < 0: replacement_combo_index = i
		if axel_combo_index >= 0 and replacement_combo_index >= 0:
			var moved_parts: Array = editor.program.elements[axel_combo_index].combination_parts.duplicate(true)
			var replacement = editor.program.elements[replacement_combo_index]
			editor.replace_jump(axel_combo_index,"axel",int(rules.required_axel_rotations[0]),[])
			editor.replace_jump(replacement_combo_index,replacement.jump_id,replacement.rotations,moved_parts)
		for i in editor.program.elements.size():
			var e = editor.program.elements[i]
			if e.kind != "jump": continue
			if not e.combination_parts.is_empty():
				var minimum := int(rules.get("minimum_combination_rotations",1))
				var maximum := int(rules.get("maximum_combination_rotations",4))
				var parts: Array = e.combination_parts.duplicate(true)
				for part in parts: part.rotations = clampi(int(part.rotations),minimum,maximum)
				var changed: Array = editor.replace_jump(i,e.jump_id,clampi(int(e.rotations),minimum,maximum),parts)
				if not changed.is_empty(): errors.append_array(changed); return
				continue
			if e.jump_id == "axel":
				if not rules.required_axel_rotations.has(e.rotations): editor.replace_jump(i,"axel",int(rules.required_axel_rotations[0]),[])
			elif e.jump_id != rules.required_solo_jump or not e.rotations in [2,3]:
				editor.replace_jump(i,rules.required_solo_jump,2,[])
	if editor.get_node("%SaveButton").disabled:
		errors.append("incremental_program_invalid:"+editor.status_label.text); return
	# Competition lock already saves. A draft save closes the event editor
	# and clears its event context; never click a hidden second control.
	if editor.get_node("%LockButton").disabled:
		# An unchanged, already locked programme needs no second lock action.
		# Do not accept a merely disabled button when edits remain uncommitted.
		var saved_program = load("res://src/domain/skating_program.gd").from_dict(career.active_programs.get(segment,{}))
		if saved_program != null and editor.program.draft_status == "locked" and saved_program.to_dict() == editor.program.to_dict() and load("res://src/simulation/program_validator.gd").validate(saved_program,career.athlete,rules).is_empty():
			return
		errors.append("incremental_program_lock_invalid:"+editor.status_label.text); return
	editor.get_node("%LockButton").pressed.emit()
	var validation: Array = load("res://src/simulation/program_validator.gd").validate(load("res://src/domain/skating_program.gd").from_dict(main.active_career.active_programs[segment]),main.active_career.athlete,rules)
	if not validation.is_empty(): errors.append("incremental_program_not_legal:"+str(validation))

func _can_apply_required_jump_menu(career, program, rules: Dictionary) -> bool:
	if not rules.has("required_solo_jump"):
		return true
	var solo_id := str(rules.required_solo_jump)
	if not career.athlete.jumps.has(solo_id) or int(career.athlete.jumps[solo_id].unlocked_rotations) < 2:
		return false
	var axel_options: Array = rules.get("required_axel_rotations",[])
	if not axel_options.is_empty() and not axel_options.any(func(rotations): return int(rotations) <= int(career.athlete.jumps.axel.unlocked_rotations)):
		return false
	var minimum := int(rules.get("minimum_combination_rotations",1))
	for element in program.elements:
		if element.kind != "jump" or element.combination_parts.is_empty():
			continue
		if int(career.athlete.jumps[element.jump_id].unlocked_rotations) < minimum:
			return false
		for part in element.combination_parts:
			if not career.athlete.jumps.has(part.jump_id) or int(career.athlete.jumps[part.jump_id].unlocked_rotations) < minimum:
				return false
	return true

func _handle_node(node: Dictionary,bundle: Dictionary) -> void:
	var career = main.active_career
	match str(node.kind):
		"season_transition":
			await main._on_season_advance_requested()
		"offseason_event":
			main._present_season_node(node)
			if node.get("choices",[]).is_empty(): errors.append("offseason_without_choices"); return
			await main._resolve_offseason_event(str(node.id),str(node.choices[0].id))
			if not main.active_career.event_ledger.any(func(row): return row.get("kind") == "offseason_choice" and row.get("id") == node.id): errors.append("offseason_not_committed")
		"season_program_planning":
			main._present_season_planning(str(node.season_id))
			await main._confirm_season_planning()
		"rehabilitation_decision":
			main._present_treatment(node)
			await main._confirm_treatment(str(node.injury_id),"full_rehabilitation")
			if not main.active_career.condition_state.get("pending_decision",{}).is_empty():
				errors.append("treatment_not_committed:"+str(main.get_node("%GlobalMessage").text))
		"program_replacement":
			if node.proposal.legal: await main._confirm_program_replacement(node.proposal,str(node.event_id))
			else:
				var withdrawn := Command.apply(career,{"type":"withdraw_entry","event_id":node.event_id})
				if withdrawn.ok: _adopt(withdrawn.career)
				else: errors.append(withdrawn.error)
		"registration","selection":
			# Training can surface the public batch scheduler before this driver's
			# existing per-event choices. Cancel it through actual UI input first;
			# bypassing the modal with Command.apply would leak an exclusive window.
			var domestic = main.season_overview_panel.find_child("DomesticScheduleDialog",true,false)
			if is_instance_valid(domestic) and domestic.visible:
				domestic.grab_focus()
				await Engine.get_main_loop().process_frame
				domestic.get_cancel_button().grab_focus()
				for down in [true,false]:
					var input := InputEventAction.new()
					input.action = "ui_accept"; input.pressed = down
					domestic.push_input(input)
					await Engine.get_main_loop().process_frame
				if domestic.visible:
					errors.append("domestic_schedule_cancel_not_closed")
					return
			var choice := "skip"
			for option in node.choices:
				if option.id == "request_assignment" and option.available: choice = option.id; break
				if option.id in ["enter","self_fund_enter"] and option.available:
					# Keep the published self-funded junior entry fee available on the
					# alternative route; declining an optional domestic event is public.
					if not assigned_route and career.clock.year >= 2019 and option.id == "enter" and float(career.athlete.resources.money)-float(option.costs.money) < 30.0: continue
					choice = option.id
			var applied := Command.apply(career,{"type":"apply_entry","event_id":node.event_id,"route_id":choice})
			if not applied.ok: errors.append(applied.error); return
			_adopt(applied.career)
		"program_adjustment":
			# Annual preparation has no event-bound secondary programme. Keep
			# its trained slots; only an actual event uses the event editor.
			if str(node.get("event_id","")).is_empty():
				_adjust_program(str(node.segment),node.rules)
				return
			var proposal: Dictionary = Draft.propose(career.athlete,node.segment,node.rules,{},career.seed)
			if not proposal.get("errors",[]).is_empty() or not proposal.get("missing",[]).is_empty():
				trace.append("program:qualification_gap:%d:%s" % [int(node.rules.get("season_start_year",career.clock.year)),str(node.segment)])
				if str(node.get("event_id","")).is_empty(): return
				var withdrawn := Command.apply(career,{"type":"withdraw_entry","event_id":node.event_id})
				if withdrawn.ok:
					_adopt(withdrawn.career)
					trace.append("program:withdraw_unready:"+str(node.event_id))
				else: errors.append(withdrawn.error)
			else:
				# Use the same visible event-bound edit action as the player. A
				# generic quarterly editor targets the primary group and cannot
				# repair an independently stored secondary event programme.
				main._present_program_adjustment(node)
				var edit = main._decision_dialog.find_child("EditProgram",true,false)
				if edit == null:
					errors.append("event_program_edit_action_missing")
					return
				edit.pressed.emit()
				trace.append("event_editor_open:"+str(main._pending_program_event_id))
				var event_editor = main.get_node("%ProgramEditorPanel")
				event_editor.refresh_coach_draft()
				if event_editor.get_node("%LockButton").disabled:
					errors.append("event_program_lock_invalid:"+event_editor.status_label.text)
					return
				event_editor.get_node("%LockButton").pressed.emit()
		"competition_check_in":
			var started: Dictionary = await main.start_formal_competition(node.event_id)
			if not started.ok: errors.append_array(started.errors)
			elif assigned_route:
				# New planned starts use balanced; loaded archives are never replayed.
				await main._on_formal_strategy_selected(_event_strategy(node.event_id))
				if main.active_career.competition_state.get("status") in ["complete","free_adjustment"]:
					if main.active_career.competition_state.get("status") == "complete": short_cut = true
					_reload(true)
		"competition_practice","competition_short":
			var status_before := str(main.active_career.competition_state.get("status",""))
			if status_before in ["practice_ready","short_ready"]:
				await main._on_formal_practice_response_selected(_practice_response(main.active_career.competition_state))
			if str(main.active_career.competition_state.get("status","")) == status_before:
				errors.append("competition_practice_did_not_advance:%s:%s" % [status_before,main.get_node("%GlobalMessage").text])
				return
			if main.active_career.competition_state.get("status") == "complete": short_cut = true
			_reload(true)
		"between_segments","competition_free":
			var event_id := str(node.get("event_id",""))
			var should_exercise_edit := (check_roundtrips and not concrete_free_edit
				and _event_scope(bundle,event_id) == "international"
				and _event_family(bundle,event_id) != "jgp_stage")
			if not should_exercise_edit:
				# Screening uses the fixed published plan regardless of SP outcome.
				# Full acceptance exercises one real player edit, then keeps the
				# saved programme in later events instead of manufacturing a
				# familiarity penalty at every competition.
				await main._on_formal_adjustment_selected("keep")
				if main.active_career.competition_state.get("status") != "complete": errors.append("screening_free_not_completed:"+main.get_node("%GlobalMessage").text)
				return
			# A real revision explicitly chooses the protection/editor branch.
			await main._on_formal_adjustment_selected("protect")
			var editor = main.get_node("%ProgramEditorPanel")
			var before_ids: Array = editor.program.elements.map(func(e): return e.element_id)
			editor.move_element(0,1)
			if editor.get_node("%SaveButton").disabled:
				errors.append("free_revision_invalid:"+editor.status_label.text); return
			await main._confirm_formal_free(editor.program.to_dict())
			var committed: Dictionary = main.active_career.competition_state.get("free_revision",{}).get("program",{})
			var after_ids: Array = committed.get("elements",[]).map(func(e): return e.element_id)
			if before_ids == after_ids or main.active_career.competition_state.get("status") != "complete":
				errors.append("free_revision_not_committed:"+main.get_node("%GlobalMessage").text); return
			concrete_free_edit = true
		"result_acknowledgement":
			_reload(false)
			await main._on_formal_archive_confirmed()
		"growth_warning","injury_review","retirement_choice":
			main.get_node("%SummaryPanel").key_node_response_requested.emit(node.id)
		"authority_conflict","quarter_event","training_decision","training_plan","internal_invitation": await _train_quarter()
		"medical_restriction","entry_revalidation":
			if str(node.get("event_id","")).is_empty(): await _train_quarter()
			else:
				var withdrawn := Command.apply(career,{"type":"withdraw_entry","event_id":node.event_id})
				if not withdrawn.ok: errors.append(withdrawn.error)
				else: _adopt(withdrawn.career)
		_: errors.append("unhandled_node:"+str(node))

func _event_strategy(event_id: String) -> String:
	if not assigned_route and event_id.begins_with("cn_club_league_2018_stage_"): return "safe"
	return "balanced"

func _event_scope(bundle: Dictionary,event_id: String) -> String:
	for event in bundle.get("calendar",{}).get("events",[]):
		if str(event.get("event_id","")) == event_id:
			return str(event.get("scope",""))
	return ""

func _event_family(bundle: Dictionary,event_id: String) -> String:
	for event in bundle.get("calendar",{}).get("events",[]):
		if str(event.get("event_id","")) == event_id:
			return str(event.get("event_family",""))
	return ""

func _practice_response(session: Dictionary) -> String:
	var observation: Dictionary = Dictionary(session.get("practice",{}))
	if not bool(observation.get("meaningful",false)): return "accept"
	var options: Array = observation.get("response_options",[])
	return str(options[0]) if not options.is_empty() else "accept"

func _competition_rotation(career, jump_id: String, desired: int) -> int:
	var profile = career.athlete.jumps[jump_id]
	var available: int = mini(desired,int(profile.unlocked_rotations))
	if available <= 2: return available
	# Unlocking alone is not enough. A genuinely mastered triple is safe to
	# recommend; a lower-rated emerging triple needs a substantial attempt and
	# success record before it belongs in a junior selection programme.
	var mastered := float(profile.proficiency.triple) >= 45.0 and float(profile.consistency.official) >= 35.0
	var evidence: Dictionary = profile.attempt_evidence.triple
	var evidenced := (float(profile.proficiency.triple) >= 25.0
		and float(profile.consistency.official) >= 25.0
		and int(evidence.get("attempts",0)) >= 60
		and int(evidence.get("successes",0)) >= 10)
	if mastered or evidenced:
		return 3
	return 2

func _mean_skating(career) -> float:
	var total := 0.0
	var count := 0
	for value in career.athlete.skating.values():
		total += float(value)
		count += 1
	return total / float(maxi(1,count))

func _reload(mid: bool) -> void:
	if not check_roundtrips: return
	if mid and (mid_competition_reload_equal or main.active_career.competition_state.get("status") != "free_adjustment"): return
	if not mid and archive_reload_equal: return
	var saved: Dictionary = main.save_active_career()
	if not saved.ok: errors.append_array(saved.errors); return
	# A successful persistence transaction publishes the uniform numeric state.
	# Compare that complete authoritative state, not an uncommitted float tree.
	var before: Dictionary = JSON.parse_string(JSON.stringify(main.active_career.to_dict()))
	var loaded: Dictionary = main.load_active_career()
	if not loaded.ok: errors.append_array(loaded.errors); return
	var after: Dictionary = JSON.parse_string(JSON.stringify(main.active_career.to_dict()))
	var difference := _first_difference(before,after)
	var equal := difference.is_empty()
	if not equal: errors.append("reload_changed_committed_career:"+difference)
	if mid: mid_competition_reload_equal = equal
	else: archive_reload_equal = equal

func _first_difference(a,b,path: String = "career") -> String:
	if JSON.stringify(a) == JSON.stringify(b): return ""
	if a is Dictionary and b is Dictionary:
		for key in a:
			if not b.has(key): return path+"."+str(key)+" missing"
			var difference := _first_difference(a[key],b[key],path+"."+str(key))
			if not difference.is_empty(): return difference
		for key in b:
			if not a.has(key): return path+"."+str(key)+" added"
	elif a is Array and b is Array:
		if a.size() != b.size(): return path+" size"
		for i in a.size():
			var difference := _first_difference(a[i],b[i],path+"[%d]" % i)
			if not difference.is_empty(): return difference
	return path+": "+str(a)+" != "+str(b)
