extends SceneTree

# Bounded reachability samples. Every score is produced by the public journey;
# the selection command is committed, not a score probe or synthetic fixture.
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var any_failed := false
	for raw_seed in OS.get_cmdline_user_args():
		var seed_value := int(raw_seed)
		var created: Dictionary = load("res://src/simulation/career_factory.gd").create("林澄",2006,"entry_club_trial","family_ambitious",seed_value,load("res://src/content/catalog_repository.gd").load_catalog(),4)
		if not created.errors.is_empty(): print("SELECTION_SAMPLE_ERROR ",seed_value," ",created.errors); any_failed = true; continue
		var result: Dictionary = await load("res://scripts/international_season_journey.gd").new().run(created.career,true,"selection")
		if not result.errors.is_empty(): print("SELECTION_SAMPLE_ERROR ",seed_value," ",result.errors); any_failed = true; continue
		var c = result.career
		var bundle: Dictionary = load("res://src/content/season_bundle_repository.gd").for_career(c)
		var node: Dictionary = load("res://src/simulation/season_progression_service.gd").advance_to_next_node(c,bundle,func(_career): return true).stop_node
		var applied: Dictionary = load("res://src/simulation/career_command_service.gd").apply(c,{"type":"apply_entry","event_id":node.event_id,"route_id":"request_assignment"})
		if not applied.ok: print("SELECTION_SAMPLE_ERROR ",seed_value," ",applied.error); any_failed = true; continue
		c = applied.career
		var decision: Dictionary = c.selection_state.decisions.jgp.decision
		var rows: Array = decision.audit.candidate_rows
		var player: Dictionary = rows.filter(func(r): return r.athlete_id == "player")[0]
		var starts := []
		for archive in c.competition_archive:
			if archive.get("world_only",false): continue
			starts.append({"event":archive.event_id,"player":archive.final_standings.filter(func(r): return r.athlete_id == "player")})
		var saved: Dictionary = load("res://src/persistence/save_repository.gd").save(c,"user://selection-sample-%d.json" % seed_value)
		if not saved.ok: any_failed = true
		print("SELECTION_SAMPLE ",JSON.stringify({"seed":seed_value,"saved":saved.ok,"clock":c.clock.to_dict(),"node_count":result.trace.size(),"trace":result.trace,"event_count":starts.size(),"events":starts,"candidate_rank":rows.find(player)+1,"candidate_count":rows.size(),"available_slots":decision.audit.available_slots,"player":player,"assigned":decision.assignments.get("player",[]),"development_winner":rows.filter(func(r): return r.reason_codes.has("selected_by_development_observation")),"body":c.athlete.body,"condition":c.condition_state,"resources":c.athlete.resources,"internal_results":c.history.filter(func(e): return e.get("category") == "internal_competition"),"programs":c.active_programs}))
	quit(1 if any_failed else 0)
