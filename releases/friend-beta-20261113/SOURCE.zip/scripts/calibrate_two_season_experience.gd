extends "res://scripts/international_season_journey.gd"

const ROUTES := ["coach","combo_expression","programme_steps"]
var route_id := "coach"
var node_times: Array = []
var changed_focus_seasons := {}
# Explicit acceptance configuration; the historical two-season test retains
# its original defaults. Longer journeys still use the real player interfaces.
var end_season_year := 2019
var promote_from_year := 0
var requested_path := "junior"
var final_snapshot_path := ""
var initial_snapshot_path := ""
var checkpoint_directory := ""
var resume_metadata := {}
var checkpoint_records: Array = []
var formal_start_quarter := 2

func _initial_career(seed_value: int) -> Dictionary:
	resume_metadata = {}
	if initial_snapshot_path.is_empty():
		return load("res://src/simulation/career_factory.gd").create("路线验收",2006,"entry_interest_class","family_supportive",seed_value,load("res://src/content/catalog_repository.gd").load_catalog(),4)
	var digest := FileAccess.get_sha256(initial_snapshot_path)
	var loaded := Save.load_save(initial_snapshot_path)
	if not loaded.ok: return {"career":null,"errors":loaded.errors}
	if loaded.career.seed != seed_value: return {"career":null,"errors":["resume_seed_mismatch"]}
	if FileAccess.get_sha256(initial_snapshot_path) != digest: return {"career":null,"errors":["resume_source_changed"]}
	resume_metadata = {"path":initial_snapshot_path,"sha256":digest,"clock":loaded.career.clock.to_dict(),"scope":"preserved_saved_history_prefix_and_current_code_continuation_not_a_new_factory_run"}
	return {"career":loaded.career,"errors":[]}

func _save_checkpoint(career,step: int) -> Dictionary:
	if checkpoint_directory.is_empty(): return {"ok":true,"skipped":true}
	if not checkpoint_directory.begins_with("user://"): return {"ok":false,"errors":["QA checkpoints must remain inside the isolated user directory"]}
	var directory_error := DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(checkpoint_directory))
	if directory_error != OK: return {"ok":false,"errors":["checkpoint_directory_failed"]}
	var path := checkpoint_directory.path_join("step-%04d-%04d-q%d.json" % [step,career.clock.year,career.clock.quarter])
	if FileAccess.file_exists(path): return {"ok":false,"errors":["checkpoint_exists_preserve_evidence"],"path":path}
	var saved := Save.save(career,path)
	saved.path = path
	return saved

func _configured_stop(_career) -> String:
	return ""

func run_sample(seed_value: int, requested_route: String) -> Dictionary:
	var started := Time.get_ticks_msec()
	if requested_route not in ROUTES: return {"completed":false,"errors":["invalid_route"],"durability_evidence":false}
	route_id = requested_route
	errors.clear(); trace.clear(); node_times.clear(); changed_focus_seasons.clear()
	checkpoint_records.clear()
	assigned_route = true
	check_roundtrips = false
	var created: Dictionary = _initial_career(seed_value)
	if not created.errors.is_empty(): return {"completed":false,"errors":created.errors,"durability_evidence":false}
	main = load("res://src/app/main.tscn").instantiate()
	Engine.get_main_loop().root.add_child(main)
	main.browser_saves = load("res://scripts/experience_memory_save.gd").new()
	main.save_path = main.browser_saves.slot_path("manual-1")
	main.autosave_path = main.browser_saves.slot_path("autosave")
	main.active_career = created.career
	if resume_metadata.is_empty():
		await main._on_pre_career_history_continued()
		await main._on_career_goal_confirmed("highest_stage")
	if resume_metadata.is_empty() and end_season_year > 2019 and main.active_career.athlete.birth_date.is_empty():
		var birthday: Dictionary = Command.apply(main.active_career,{"type":"record_birth_date","birth_date":{"year":2006,"month":6,"day":30},"receipt_id":"natural-beijing-birthday-choice"})
		if not birthday.ok: errors.append(birthday.error)
		else: _adopt(birthday.career)
	var completed := false
	var configured_stop := ""
	var unchanged := 0
	print("EXPERIENCE_BEGIN ",seed_value," ",route_id)
	var node_limit := 1200 if end_season_year > 2019 else 600
	for step in node_limit:
		var career = main.active_career
		var before := _checkpoint(career)
		var node_started := Time.get_ticks_msec()
		var label := "training"
		if career.clock.year < 2018 or career.clock.year == 2018 and career.clock.quarter < formal_start_quarter:
			await _train_quarter()
		else:
			var year := _journey_year(career)
			_change_focus(year)
			var bundle: Dictionary = Bundle.for_career(career) if end_season_year > 2019 else Bundle.load_bundle(year,"women_singles","junior")
			var result: Dictionary = Progression.advance_to_next_node(main.active_career,bundle,func(_candidate): return true)
			if not result.errors.is_empty(): errors.append_array(result.errors); break
			_adopt(result.career)
			var node: Dictionary = result.stop_node
			label = "%d:%s:%s" % [year,str(node.get("kind","unknown")),str(node.get("event_id",""))]
			if node.get("kind") == "season_complete":
				main._present_season_node(node)
				if year == end_season_year: completed = true
			else: await _handle_node(node,bundle)
		trace.append(label)
		node_times.append({"node":label,"elapsed_ms":Time.get_ticks_msec()-node_started})
		print("EXPERIENCE_NODE ",seed_value," ",route_id," ",step," ",label," ",main.active_career.clock.to_dict()," ",node_times.back().elapsed_ms)
		if not checkpoint_directory.is_empty() and (label.contains(":season_complete:") or label.contains(":season_program_planning:") or not errors.is_empty()):
			var checkpoint := _save_checkpoint(main.active_career,step)
			if not checkpoint.ok: errors.append("checkpoint_failed:"+str(checkpoint.get("errors",[])))
			else:
				checkpoint_records.append({"path":checkpoint.path,"node":label,"clock":main.active_career.clock.to_dict()})
				print("EXPERIENCE_CHECKPOINT ",checkpoint.path)
		if errors.is_empty():
			configured_stop = _configured_stop(main.active_career)
			if not configured_stop.is_empty(): completed = true
		if completed or not errors.is_empty(): break
		unchanged = unchanged+1 if before == _checkpoint(main.active_career) else 0
		if unchanged >= 8: errors.append("repeated_unresolved_node:"+label+":"+main.global_message.text); break
		if step == node_limit-1: errors.append("node_limit")
		await Engine.get_main_loop().process_frame
	var report := _report(main.active_career)
	if not resume_metadata.is_empty() and FileAccess.get_sha256(initial_snapshot_path) != str(resume_metadata.sha256): errors.append("resume_source_changed_during_journey")
	if not final_snapshot_path.is_empty():
		var saved: Dictionary = Save.save(main.active_career,final_snapshot_path)
		report.final_snapshot = {"path":final_snapshot_path,"ok":saved.ok,"scope":"one_final_native_snapshot_not_all_intermediate_durable_commits"}
		if not saved.ok: errors.append_array(saved.get("errors",["final_snapshot_failed"]))
	report.merge({"seed":seed_value,"route":route_id,"completed":completed and errors.is_empty(),"errors":errors.duplicate(),"trace":trace.duplicate(),"node_times":node_times.duplicate(),"last_node":trace.back() if not trace.is_empty() else "initialization","elapsed_ms":Time.get_ticks_msec()-started,"durability_evidence":false,"scope":"real_factory_public_commands_and_panels_with_in_memory_commit_adapter"})
	report.configured_stop = configured_stop
	report.stop_reason = configured_stop if not configured_stop.is_empty() else ("season_complete" if completed else "incomplete")
	report.resume_source = resume_metadata.duplicate(true)
	report.checkpoints = checkpoint_records.duplicate(true)
	if not resume_metadata.is_empty(): report.scope = "preserved_native_history_prefix_current_code_public_commands_and_panels_continuation_with_in_memory_commit_adapter"
	print("EXPERIENCE_END ",seed_value," ",route_id," ",report.completed," ",report.elapsed_ms," ",errors)
	main.free()
	return report

func _adopt(career) -> void:
	main.active_career = career
	if is_instance_valid(main._decision_dialog): main._decision_dialog.hide()
	main.quarter_panel.authority_confirmation.hide()
	main.quarter_panel.event_dialog.hide()
	main.quarter_panel.teaching_invitation_dialog.hide()

func _checkpoint(career) -> String:
	return str([career.clock.to_dict(),career.competition_timeline.date,career.rng_step,career.event_ledger.size(),career.training_period_state.get("weeks_elapsed",0),career.competition_state.get("status",""),career.season_program_plan.get("revision",0)])

func _journey_year(career) -> int:
	var year := 2018
	while career.season_state.get("season_history",{}).has("%d-%02d" % [year,(year+1)%100]): year += 1
	return year

func _change_focus(year: int) -> void:
	if changed_focus_seasons.has(year): return
	var career = main.active_career
	var direction: Dictionary = career.training_direction.duplicate(true)
	if route_id == "combo_expression":
		direction.focuses = [{"id":"combination","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":3},{"jump_id":"toe_loop","rotations":3}]}},{"id":"expression","kind":"musical_expression","target":{}}]
	elif route_id == "programme_steps":
		direction.focuses = [{"id":"programme","kind":"execution","target":{"segment":"free"}},{"id":"steps","kind":"steps","target":{}}]
	else: direction.focuses = []
	var result: Dictionary = Command.apply(career,{"type":"set_training_direction","direction":direction,"receipt_id":"experience-focus:%d:%s:%d" % [career.seed,route_id,year]})
	if not result.ok: errors.append(result.error); return
	_adopt(result.career)
	changed_focus_seasons[year] = true

func _handle_node(node: Dictionary, bundle: Dictionary) -> void:
	if node.get("kind") == "season_program_planning":
		_change_focus(int(str(node.season_id).left(4)))
		main._present_season_planning(str(node.season_id))
		if promote_from_year > 0 and int(str(node.season_id).left(4)) >= promote_from_year:
			main._set_planning_level(requested_path)
		if route_id == "combo_expression":
			main._season_planning_draft.targets = {"free":[{"action":main.active_career.training_direction.focuses[0].target.duplicate(true)}]}
		await main._confirm_season_planning()
		return
	await super._handle_node(node,bundle)

func _train_quarter() -> void:
	var career = main.active_career
	var pending: Array = Nodes.pending(career)
	if not pending.is_empty(): await main._on_key_node_response(str(pending[0].id)); return
	var gate: Dictionary = Progression.training_entry_gate(career,Bundle.for_career(career))
	if not gate.is_empty() and str(gate.get("kind")) not in ["training_plan","authority_conflict","quarter_event","training_decision","internal_invitation"]:
		await _handle_node(gate,Bundle.for_career(career)); return
	if str(gate.get("kind","")) == "internal_invitation" or load("res://src/simulation/teaching_competition_service.gd").evaluate(career).available:
		if career.internal_invitation_state.get("status") not in ["completed","deferred"]:
			main.quarter_panel.teaching_invitation_dialog.hide()
			for segment in ["short","free"]: _edit_program(segment,load("res://src/content/internal_event_rules.gd").for_teaching_group(segment),false)
			var started: Dictionary = main.start_internal_competition({"rival_count":5})
			if started.ok:
				main.competition_panel.settle_immediately()
				main.competition_panel.adjustment_selected.emit("keep")
				main.competition_panel.settle_immediately()
				await main._on_competition_confirmed()
				return
			await main._on_internal_competition_deferred()
	main.open_next_quarter()
	if not main.quarter_panel.authority_confirmation.visible and not main.quarter_panel.event_dialog.visible:
		await main.quarter_panel.continue_training()
	await _resolve_training_choices(main.quarter_panel)
	if route_id == "combo_expression" and main.active_career.clock.year >= 2018:
		var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_season(Bundle.season_year(main.active_career),"junior","free")
		var proposal: Dictionary = load("res://src/simulation/program_upgrade_service.gd").propose(main.active_career,"free",rules)
		if proposal.changed:
			main._review_program_upgrade()
			await main._resolve_program_upgrade(proposal,"accept")
			main.program_editor_panel.present(main.active_career,"free",rules,{})
			if not main.program_editor_panel.lock_button.disabled: main.program_editor_panel.lock_button.pressed.emit()

func _resolve_training_choices(panel) -> void:
	for response in 24:
		var before := _checkpoint(main.active_career)+str(main.active_career.memories.size())
		if panel.authority_confirmation.visible:
			await panel._on_authority_response("accept")
		elif panel.event_dialog.visible and not panel._pending_events.is_empty():
			var event = panel._pending_events[0]
			trace.append("event:"+event.title)
			await panel.resolve_event_choice(str(event.choices[0].id))
		else: return
		if before == _checkpoint(main.active_career)+str(main.active_career.memories.size()):
			errors.append("training_response_not_committed:"+panel.plan_error_label.text)
			return
	errors.append("training_response_limit")

func _edit_program(segment: String, rules: Dictionary, _competitive: bool) -> void:
	var career = main.active_career
	var proposal: Dictionary = Draft.propose(career.athlete,segment,rules,{},career.seed)
	var editor = main.program_editor_panel
	editor.present(career,segment,rules,proposal)
	editor.refresh_coach_draft()
	if not editor.save_button.disabled: editor.save_button.pressed.emit()
	if not editor.lock_button.disabled: editor.lock_button.pressed.emit()

func _adjust_program(segment: String, rules: Dictionary) -> void:
	_edit_program(segment,rules,true)

func _report(career) -> Dictionary:
	var closed: Array = career.season_state.get("season_history",{}).keys()
	closed.sort()
	var courses: Array = []
	var clocks := {}
	var trained := {}
	for entry in career.event_ledger:
		if entry.get("kind") in ["quarter_advanced","dated_quarter_completed"]:
			var source: Dictionary = entry.get("from_clock",{})
			if int(source.get("year",0)) >= 2014: trained["%d:%d" % [int(source.year),int(source.quarter)]] = true
		if entry.get("kind") != "coach_curriculum": continue
		var clock: Dictionary = entry.get("clock",{})
		if int(clock.get("year",0)) < 2014: continue
		var key := str(clock)
		if clocks.has(key): continue
		clocks[key] = true
		courses.append({"clock":clock,"plan":entry.get("executed_plan",{})})
	var attempts := {}; var repertoire := {}; var competitions: Array = []
	for id in career.technical_repertoire.entries:
		var item: Dictionary = career.technical_repertoire.entries[id]
		attempts[id] = item.get("learned_history",{}).get("total_attempts",0)
		repertoire[id] = item.get("state","")
	for archive in career.competition_archive:
		if bool(archive.get("world_only",false)): continue
		for row in archive.get("final_standings",[]):
			if row.get("athlete_id") != "player": continue
			competitions.append({"event_id":archive.get("event_id",""),"season_id":archive.get("season_id",""),"scope":archive.get("event",{}).get("scope",""),"family":archive.get("event",{}).get("event_family",""),"rank":row.get("rank",0),"field_size":archive.get("final_standings",[]).size(),"score":row.get("total_score",0)})
	return {"closed_seasons":closed,"courses":courses,"course_scope":"optional_coach_curriculum_receipts","training_quarters":trained.size(),"attempts":attempts,"repertoire":repertoire,"expression":career.athlete.mind.expression,"skating":career.athlete.skating.duplicate(true),"health":load("res://src/simulation/athlete_function_service.gd").snapshot(career),"competitions":competitions,"selection":career.selection_state.duplicate(true)}
