extends SceneTree

func _initialize() -> void:
	var catalog = load("res://src/content/club_coach_repository.gd").new()
	var errors: Array = catalog.errors()
	if not errors.is_empty(): print(errors); quit(1); return
	var career = load("res://tests/fixtures.gd").starting_career(100105)
	var coach_service = load("res://src/simulation/coach_training_plan_service.gd")
	var intent_service = load("res://src/domain/training_intent.gd")
	var profiles: Array = []
	for club in catalog.clubs(): profiles.append_array(catalog.coaches_for_club(club.id))
	# Controlled counterfactual: same athlete and relationships, different
	# technical profile only. This is not a whole-career or JGP probability test.
	for mode in ["accept","more_aggressive"]:
		var signatures := {}
		for coach in profiles:
			career.coach_assignment.technical_tendencies = coach.technical_tendencies.duplicate(true)
			var planned: Dictionary = coach_service.build(career,intent_service.create(mode).intent)
			if not planned.errors.is_empty(): print(planned.errors); quit(1); return
			var signature := JSON.stringify(planned.plan.to_dict())
			signatures[signature] = true
			print("COACH_PROFILE mode=",mode," coach=",coach.id," shares=",JSON.stringify(planned.plan.shares))
		print("COACH_PROFILE mode=",mode," unique_course_count=",signatures.size()," profile_count=",profiles.size())
	quit()
