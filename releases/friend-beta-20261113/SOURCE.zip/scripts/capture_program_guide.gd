extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(960,540)
	var panel = load("res://src/app/program_editor_panel.tscn").instantiate()
	panel.theme = load("res://src/app/theme_factory.gd").create()
	root.add_child(panel)
	var career = load("res://tests/fixtures.gd").starting_career(100104)
	career.athlete.jumps.toe_loop.unlocked_rotations = 1
	var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_teaching_group("short")
	panel.present(career,"short",rules,load("res://src/simulation/program_draft_service.gd").propose(career.athlete,"short",rules,{},100104))
	panel.get_node("%ActionList").select(0)
	panel.get_node("%ActionList").item_selected.emit(0)
	await _capture("editor")
	panel.get_node("%ActionGuideButton").pressed.emit()
	await _capture("guide")
	panel.get_node("%ActionGuideDialog").hide()
	await _capture("returned")
	panel.free()
	quit()

func _capture(label: String) -> void:
	for frame in 5: await process_frame
	await RenderingServer.frame_post_draw
	var destination := "C:/Users/25775/Desktop/figure_skating/qa-editor-guide-20261010"
	DirAccess.make_dir_recursive_absolute(destination)
	print("CAPTURE ",label," ",root.get_texture().get_image().save_png(destination.path_join(label+".png")))
