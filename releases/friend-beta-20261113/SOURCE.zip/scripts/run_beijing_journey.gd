extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var driver = load("res://scripts/calibrate_two_season_experience.gd").new()
	driver.end_season_year = 2021
	driver.promote_from_year = 2021
	driver.requested_path = "senior"
	driver.final_snapshot_path = "user://natural-beijing-coach-senior-final.json"
	var report: Dictionary = await driver.run_sample(42000,"coach")
	var file := FileAccess.open("user://natural-beijing-coach-senior-report.json",FileAccess.WRITE)
	if file == null: push_error("无法写入隔离QA自然路线报告");quit(1);return
	file.store_string(JSON.stringify(report,"  "));file.close()
	print("BEIJING_NATURAL_RESULT completed=",report.completed," errors=",report.errors," elapsed_ms=",report.elapsed_ms)
	quit(0 if report.completed and report.errors.is_empty() else 1)
