extends SceneTree
const World = preload("res://src/simulation/world_generation_service.gd")
const Athlete = preload("res://src/domain/athlete_state.gd")
const Program = preload("res://src/domain/skating_program.gd")
const Rules = preload("res://src/content/internal_event_rules.gd")
const Scoring = preload("res://src/content/formal_scoring_repository.gd")
const Segment = preload("res://src/simulation/formal_segment_simulator.gd")
func _initialize() -> void:
	# 2020 calendar events use 2019-20 rules. A 2020-21 scoring catalog is
	# deliberately unsupported; never turn a missing catalog into zero scores.
	for year in [2018,2019]:
		var scoring := Scoring.load_catalog(year,"women_singles")
		if not scoring.errors.is_empty(): push_error(str(scoring.errors)); quit(1); return
		for seed in [88,880,2026]:
			var samples := {"development":[],"middle":[],"top":[]}
			for index in 28:
				var record := World.generate_record({},"CHN",{"mean_strength":70,"strength_deviation":8,"resource_level":55,"late_bloomer_rate":0.25,"volatility":0.2},seed,index,{"year":year,"quarter":3},"%d-%02d" % [year,(year+1)%100],13+index%6)
				if record.has("errors"): push_error(str(record.errors)); quit(1); return
				var total := 0.0
				for segment in ["short","free"]:
					var result := Segment.simulate(Athlete.from_dict(record.athlete),Program.from_dict(record[segment+"_program"]),{"risk":"balanced"},{},{"segment_rules":Rules.for_season(year,"junior",segment),"scoring_catalog":scoring.catalog},seed+index*11)
					if not result.errors.is_empty(): push_error(str(result.errors)); quit(1); return
					total += float(result.protocol.total)
				samples[record.archetype].append(snappedf(total,0.01))
			for archetype in samples:
				var scores: Array = samples[archetype]
				scores.sort()
				print(JSON.stringify({"year":year,"seed":seed,"archetype":archetype,"count":scores.size(),"min":scores[0],"median":scores[scores.size()/2],"max":scores[-1]}))
	quit(0)
