extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var fixture = load("res://tests/app/test_broadcast_playback.gd").new()
	var panel = fixture._panel()
	var record: Dictionary = fixture._record("free")
	panel.show_segment(record)
	var original := JSON.stringify(record)
	var samples: Array[int] = []
	for sample in 7:
		var started := Time.get_ticks_usec()
		for frame in 600:
			panel._elapsed = float(frame % 600) / 600.0
			panel._refresh_progress()
			panel._slow_candidate("spin")
		samples.append(Time.get_ticks_usec() - started)
	samples.sort()
	print("BROADCAST_PROFILE iterations=600 median_us=", samples[3], " min_us=", samples[0], " max_us=", samples[6], " note=native_cpu_only_no_gpu_or_web")
	var preserved := original == JSON.stringify(record)
	print("BROADCAST_PROFILE committed_input_preserved=", preserved)
	panel.free()
	quit(0 if preserved else 1)
