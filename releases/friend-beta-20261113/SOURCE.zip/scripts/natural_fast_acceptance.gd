extends "res://scripts/calibrate_two_season_experience.gd"
const Acceptance = preload("res://scripts/natural_fast_acceptance_report.gd")
var fast_confirmation := {}
var first_attempt := {}
var snapshot_path := ""
var stop_after_first_formal_archive := false
func _configured_stop(career) -> String:
	if not stop_after_first_formal_archive or first_attempt.is_empty() or not career.competition_state.is_empty(): return ""
	for raw in career.competition_archive:
		if not raw is Dictionary: continue
		var inspected: Dictionary = Acceptance.inspect(raw)
		if not inspected.get("eligible",false): continue
		if inspected.get("event_id") != first_attempt.get("event_id"): return ""
		if raw.get("status") != "complete": return ""
		return "first-formal-archive"
	return ""
func _init() -> void:
	end_season_year = 2018
	formal_start_quarter = 1
func _train_quarter() -> void:
	if fast_confirmation.is_empty():
		main.open_next_quarter()
		var panel = main.quarter_panel
		var dialog = panel._roadmap_dialog
		var before: int = main.active_career.roadmap_revision_history.size()
		dialog.begin(main.active_career)
		dialog.select_route("fast")
		await panel.apply_roadmap(dialog._build_roadmap())
		dialog.hide()
		fast_confirmation = {"clock":main.active_career.clock.to_dict(),"before_revisions":before,"after_revisions":main.active_career.roadmap_revision_history.size(),"route":main.active_career.development_roadmap.duplicate(true)}
		if main.active_career.development_roadmap.get("route_id") != "fast" or main.active_career.roadmap_revision_history.size() != before+1:
			errors.append("fast_route_commit_failed"); return
	await super._train_quarter()
func _handle_node(node: Dictionary, bundle: Dictionary) -> void:
	if node.get("kind") == "registration" and not main.active_career.season_state.get("domestic_schedule_selected",false):
		var events: Array = bundle.get("calendar",{}).get("events",[]).filter(func(event):return event.event_id == node.get("event_id"))
		if not events.is_empty() and events[0].get("scope") == "domestic":
			main._on_domestic_schedule_requested()
			var selected := []
			for choice in main.season_overview_panel._domestic_choices.get_children():
				if not choice.disabled and str(choice.get_meta("event_id","")) == str(node.event_id):
					choice.button_pressed = true
					selected.append(str(node.event_id))
			if not selected.is_empty():
				await main._on_domestic_schedule_selected(selected)
				main.season_overview_panel._domestic_dialog.hide()
				if main.active_career.season_state.get("entry_plan",{}).get("entries",{}).get(str(node.event_id),{}).get("status") != "confirmed": errors.append("natural_domestic_schedule_not_committed")
				trace.append("domestic_schedule:first_available:"+str(node.event_id))
				return
			main.season_overview_panel._domestic_dialog.hide()
	if node.get("kind") == "competition_check_in" and first_attempt.is_empty():
		var career = main.active_career
		var event := {}
		for candidate in bundle.get("calendar",{}).get("events",[]):
			if candidate.get("event_id") == node.get("event_id"): event = candidate.duplicate(true); break
		var rows := {}
		for index in Acceptance.CODES.size():
			var code: String = Acceptance.CODES[index]
			var id: String = Acceptance.IDS[index]
			var evaluated: Dictionary = load("res://src/simulation/jump_stage_evaluator.gd").evaluate(career,id,3)
			evaluated.state = career.technical_repertoire.entries.get(code,{}).get("state","")
			evaluated.repertoire = career.technical_repertoire.entries.get(code,{}).duplicate(true)
			evaluated.proficiency = career.athlete.jumps[id].proficiency.duplicate(true)
			rows[code] = evaluated
		first_attempt = {"event_id":node.get("event_id",""),"event":event,"node":node.duplicate(true),"clock":career.clock.to_dict(),"timeline":career.competition_timeline.duplicate(true),"age_year_bound":career.clock.year-career.athlete.birth_year,"stages":rows,"five_ready":Acceptance.ready(rows),"programmes":load("res://src/simulation/season_program_service.gd").programs_for_event(career,event),"health":load("res://src/simulation/athlete_function_service.gd").snapshot(career),"route":career.development_roadmap.duplicate(true),"entry":career.season_state.get("entry_plan",{}).duplicate(true),"qualification":career.season_state.get("qualification_state",{}).duplicate(true)}
		first_attempt.training_diagnostics = Acceptance.training_diagnostics(career,str(event.get("actual_dates",{}).get("start",event.get("start_date",""))))
		if not snapshot_path.is_empty():
			var path := snapshot_path+".pre-event.json"
			if FileAccess.file_exists(path): errors.append("preserve_existing_pre_event_snapshot"); return
			var before_saved: Dictionary = Save.save(career,path)
			first_attempt.snapshot = {"path":ProjectSettings.globalize_path(path),"saved":before_saved.ok}
			if not before_saved.ok: errors.append("pre_event_snapshot_save_failed"); return
			var before_loaded: Dictionary = Save.load_save(path)
			first_attempt.snapshot.readback_ok = before_loaded.ok and Acceptance.semantic_equal(career.to_dict(),before_loaded.career.to_dict())
			first_attempt.snapshot.sha256 = FileAccess.get_sha256(path)
			if not first_attempt.snapshot.readback_ok: errors.append("pre_event_snapshot_readback_failed"); return
	await super._handle_node(node,bundle)
func _report(career) -> Dictionary:
	var report: Dictionary = super._report(career)
	report.fast_confirmation = fast_confirmation.duplicate(true)
	report.first_attempt = first_attempt.duplicate(true)
	var archive_report := Acceptance.archives(career.competition_archive)
	report.natural_acceptance = archive_report
	var first: Dictionary = archive_report.first_archive
	var matching: bool = not first.is_empty() and first.get("event_id") == first_attempt.get("event_id","missing")
	report.readiness_programme_gate = not first_attempt.is_empty() and first_attempt.get("five_ready",false) and matching and first.get("submitted_programme_five",false)
	report.observed_first_free_five = matching and first.get("single_free_five",false)
	report.observation_status = "no_formal_attempt" if first_attempt.is_empty() else ("attempt_without_formal_archive" if first.is_empty() else ("first_archive_mismatch" if not matching else ("first_event_free_observed" if not first.get("technical_elements",[]).is_empty() else "first_event_missing_free_or_technical_facts")))
	report.terminal_competition_state = career.competition_state.duplicate(true)
	report.terminal_scope = "first_event_after_actual_acknowledgment_not_season_closure" if stop_after_first_formal_archive else "whole_first_season"
	report.policy = {"seed_policy":"predeclared42000_primary_42001_42002_followups_all_results_retained_no_seed_search","route":"one_actual_fast_dialog_commit_then_coach_curriculum","domestic_schedule":"select_first_available_formal_event_via_visible_schedule_no_delay_for_readiness","formal_coordinator_from":"2018Q1","end_season_year":2018,"medical":"inherited_real_choices_full_rehabilitation_no_stat_or_money_repairs","formal_scope":"first_player_domestic_or_international_attempt_and_archive_teaching_excluded","durability":"in_memory_intermediate_commits_pre_event_and_final_native_readback"}
	report.final_snapshot_roundtrip = {"ok":false,"scope":"one_final_native_snapshot_only_not_intermediate_commit_durability"}
	if not snapshot_path.is_empty():
		var saved: Dictionary = Save.save(career,snapshot_path)
		if not saved.ok: errors.append("native_snapshot_save_failed:"+str(saved.get("errors",[])))
		else:
			var loaded: Dictionary = Save.load_save(snapshot_path)
			if not loaded.ok: errors.append("native_snapshot_read_failed:"+str(loaded.get("errors",[])))
			else:
				var fields := ["clock","development_roadmap","roadmap_revision_history","active_programs","season_program_plan","season_state","competition_archive","condition_state","competition_state","competition_timeline","technical_repertoire","athlete","random_streams"]
				var original: Dictionary = career.to_dict()
				var restored: Dictionary = loaded.career.to_dict()
				var compared := {}
				for field in fields: compared[field] = Acceptance.semantic_equal(original.get(field),restored.get(field))
				report.final_snapshot_roundtrip.fields = compared
				report.final_snapshot_roundtrip.ok = compared.values().all(func(equal): return equal)
				if not report.final_snapshot_roundtrip.ok: errors.append("native_snapshot_important_fields_mismatch")
	return report
