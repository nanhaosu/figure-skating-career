param(
    [string]$BuildDir = 'build/friend-beta-20261009-candidate',
    [string]$PublishCheckout = '.tools/pages-publish',
    [string]$Release = 'friend-beta-20261009'
)
$ErrorActionPreference = 'Stop'
if ($Release -notmatch '^friend-beta-[0-9]{8}$') { throw 'Invalid release directory' }
$buildPath = (Resolve-Path -LiteralPath $BuildDir).Path
$publishPath = (Resolve-Path -LiteralPath $PublishCheckout).Path
if (-not (Test-Path -LiteralPath (Join-Path $publishPath '.git'))) { throw 'Expected isolated publishing checkout' }
$assets = @('index.html','index.js','index.pck','index.wasm','index.audio.worklet.js','index.audio.position.worklet.js','index.apple-touch-icon.png','index.icon.png','index.png')
foreach ($asset in $assets) {
    if (-not (Test-Path -LiteralPath (Join-Path $buildPath $asset))) { throw "Missing $asset" }
}
Push-Location -LiteralPath $publishPath
try {
    & git read-tree HEAD
    if ($LASTEXITCODE -ne 0) { throw 'Cannot preserve published tree' }
    $releasePath = Join-Path $publishPath "releases/$Release"
    New-Item -ItemType Directory -Path $releasePath -Force | Out-Null
    foreach ($asset in $assets) {
        Copy-Item -LiteralPath (Join-Path $buildPath $asset) -Destination (Join-Path $releasePath $asset)
        & git add -- "releases/$Release/$asset"
        if ($LASTEXITCODE -ne 0) { throw "Cannot stage $asset" }
    }
    Write-Output 'Prepared versioned assets, preserving every previous release. No commit or push performed.'
    & git diff --cached --stat
} finally { Pop-Location }
