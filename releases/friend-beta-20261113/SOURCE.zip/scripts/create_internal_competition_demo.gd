extends SceneTree

const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const CareerFactory = preload("res://src/simulation/career_factory.gd")
const ProgramElement = preload("res://src/domain/program_element.gd")
const SkatingProgram = preload("res://src/domain/skating_program.gd")
const SaveRepository = preload("res://src/persistence/save_repository.gd")

const DEFAULT_PATH := "user://internal-competition-route-acceptance.json"
const SURNAMES := ["林", "程", "沈", "顾", "唐", "许"]
const GIVEN_NAMES := ["澄", "念安", "清禾", "映岚", "若遥", "星宁"]

func _initialize() -> void:
	var output_path := DEFAULT_PATH
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="): output_path = argument.trim_prefix("--output=")
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var seed := int(rng.randi() & 0x7fffffff)
	var athlete_name: String = SURNAMES[rng.randi_range(0, SURNAMES.size() - 1)] + GIVEN_NAMES[rng.randi_range(0, GIVEN_NAMES.size() - 1)]
	var created := CareerFactory.create(athlete_name, 2006, "entry_club_trial", "family_supportive", seed, CatalogRepository.load_catalog(), 4)
	if created.career == null:
		push_error("无法创建验收档案：%s" % ", ".join(created.errors))
		quit(1)
		return
	var career = created.career
	career.athlete.technique = {"rotation": 61.0, "landing": 57.0, "single_jumps": 84.0}
	career.athlete.skating = {"speed": 59.0, "flow": 56.0, "one_foot_stability": 60.0, "deep_edge": 58.0, "turns": 52.0, "knee_action": 55.0, "ice_efficiency": 54.0}
	career.athlete.body.acute_fatigue = 14.0
	career.athlete.body.cumulative_fatigue = 19.0
	career.athlete.body.impact_load = 22.0
	career.athlete.body.strength_readiness = 61.0
	career.athlete.body.joint_readiness = 66.0
	career.athlete.body.recovery_capacity = 58.0
	career.athlete.mind.motivation = 72.0
	career.athlete.mind.training_fear = 9.0
	for jump_id in career.athlete.jumps:
		var jump = career.athlete.jumps[jump_id]
		jump.unlocked_rotations = 2
		jump.proficiency.single = 86.0
		jump.proficiency.double = rng.randf_range(55.0, 73.0)
		jump.consistency.training = rng.randf_range(62.0, 78.0)
		jump.consistency.internal = rng.randf_range(48.0, 70.0)
		jump.air.axis = rng.randf_range(56.0, 72.0)
		jump.air.height = rng.randf_range(52.0, 68.0)
		jump.air.distance = rng.randf_range(48.0, 66.0)
		jump.air.rotation_speed = rng.randf_range(55.0, 72.0)
		jump.air.tightness = rng.randf_range(54.0, 70.0)
		jump.landing.completion = rng.randf_range(54.0, 71.0)
		jump.landing.control = rng.randf_range(50.0, 70.0)
		jump.landing.flow = rng.randf_range(46.0, 66.0)
	career.athlete.jumps.axel.proficiency.double = 59.0
	career.athlete.jumps.lutz.takeoff.edge_quality = 43.0
	career.athlete.jumps.lutz.takeoff.edge_stability = 48.0
	career.athlete.jumps.lutz.habits.rigidity = 34.0
	var programs := build_demo_programs()
	var short_program = programs.short
	var free_program = programs.free
	career.active_programs = {"short": short_program.to_dict(), "free": free_program.to_dict()}
	career.competition_state = {
		"status": "ready", "event_name": "2014秋季俱乐部内部选拔（内部规则）", "seed": seed + 1703,
		"rival_count": 5, "strategy": {"risk": "balanced"},
		"context": {
			"event_name": "2014秋季俱乐部内部选拔（内部规则）", "season_start_year": 2014, "pressure": 39.0,
			"reputation": {"edge_reputation": 31.0},
			"influence": {"event_scope": "internal", "priority": 28.0, "coach_voice": 37.0},
			"club": {"priority": 28.0, "coach_favor": 42.0, "available_external_slots": 2},
		},
	}
	var saved := SaveRepository.save(career, output_path)
	if not saved.ok:
		push_error("无法保存验收档案：%s" % ", ".join(saved.errors))
		quit(1)
		return
	print("DEMO_SAVE=%s" % output_path)
	print("DEMO_NAME=%s" % athlete_name)
	print("DEMO_SEED=%d" % seed)
	quit(0)

func _jump(id: String, jump_id: String, rotations: int):
	return ProgramElement.create(id, "jump", jump_id, rotations).element

func _combo(id: String, jump_id: String, rotations: int, parts: Array[Dictionary]):
	var element = _jump(id, jump_id, rotations)
	element.set_combination_parts(parts)
	return element

func _element(id: String, kind: String):
	return ProgramElement.create(id, kind).element

func build_demo_programs() -> Dictionary:
	return {
		"short": _program("acceptance-short", "short", [
			_jump("sp-1", "axel", 2),
			_combo("sp-2", "lutz", 2, [{"jump_id": "toe_loop", "rotations": 2}]),
			_element("sp-spin", "spin"), _element("sp-step", "step_sequence"),
		], "月光（自定义剪辑）", 68.0, "rich", 72.0),
		"free": _program("acceptance-free", "free", [
			_jump("fs-1", "axel", 2), _jump("fs-2", "lutz", 2),
			_combo("fs-3", "flip", 2, [{"jump_id": "toe_loop", "rotations": 2}]),
			_jump("fs-4", "loop", 2), _jump("fs-5", "salchow", 2),
			_element("fs-spin-1", "spin"), _element("fs-step", "step_sequence"),
			_element("fs-spin-2", "spin"), _element("fs-choreo", "choreographic_sequence"),
		], "舍赫拉查德（自定义剪辑）", 63.0, "standard", 64.0),
	}

func _program(id: String, segment: String, elements: Array, title: String, familiarity: float, route_complexity: String, choreography_quality: float):
	var program = SkatingProgram.create(id, segment, elements).program
	program.whole_run_familiarity = familiarity
	program.route_complexity = route_complexity
	program.choreography_quality = choreography_quality
	program.music = {"title": title, "source": "custom", "custom": true}
	for element in program.elements:
		program.slot_familiarity[element.element_id] = familiarity + (3.0 if element.kind != "jump" else 0.0)
	return program
