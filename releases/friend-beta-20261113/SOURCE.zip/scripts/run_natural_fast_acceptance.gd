extends SceneTree
static func validate_paths(report_path: String, snapshot: String) -> Dictionary:
	var root := ProjectSettings.globalize_path("user://").replace("\\","/").simplify_path().trim_suffix("/")
	var canonical := []
	for path in [report_path,snapshot,snapshot+".pre-event.json"]:
		if not path.begins_with("user://"): return {"ok":false,"error":"nonisolated_output_path"}
		var resolved: String = ProjectSettings.globalize_path(path).replace("\\","/").simplify_path()
		if not resolved.to_lower().begins_with(root.to_lower()+"/"): return {"ok":false,"error":"output_escapes_user_directory"}
		if FileAccess.file_exists(resolved): return {"ok":false,"error":"preserve_existing_evidence"}
		canonical.append(resolved.to_lower())
	if canonical[0] == canonical[1] or canonical[0] == canonical[2]: return {"ok":false,"error":"report_and_snapshot_must_be_distinct"}
	return {"ok":true,"canonical_paths":canonical}
func _initialize() -> void: call_deferred("run")
func run() -> void:
	if OS.get_cmdline_user_args().has("--reclassify"):
		reclassify_preserved_sample(); return
	var configured_stop := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--stop="):
			configured_stop = argument.trim_prefix("--stop=")
			if configured_stop != "first-formal-archive": push_error("invalid_configured_stop"); quit(2); return
	var seed_value := 42000
	var campaign := ""
	var report_path := "user://natural-fast-42000-report.json"
	var snapshot := "user://natural-fast-42000-final.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--seed="): seed_value = int(argument.trim_prefix("--seed="))
		if argument.begins_with("--campaign="): campaign = argument.trim_prefix("--campaign=")
		if argument.begins_with("--report="): report_path = argument.trim_prefix("--report=")
		if argument.begins_with("--snapshot="): snapshot = argument.trim_prefix("--snapshot=")
	var validation := validate_paths(report_path,snapshot)
	if not validation.ok: push_error(validation.error); quit(2); return
	if not load("res://scripts/natural_fast_acceptance_report.gd").allowed_seed(seed_value,campaign): push_error("seed_outside_predeclared_scope"); quit(2); return
	var driver = load("res://scripts/natural_fast_acceptance.gd").new()
	driver.snapshot_path = snapshot
	driver.stop_after_first_formal_archive = configured_stop == "first-formal-archive"
	print("NATURAL_STOP ",configured_stop if not configured_stop.is_empty() else "whole_first_season")
	print("NATURAL_POLICY fixed_seed=",seed_value," fast_once=true coach_curriculum=true medical=real_full_rehabilitation end_season=2018 durability_evidence=false snapshot=",ProjectSettings.globalize_path(snapshot))
	var report: Dictionary = await driver.run_sample(seed_value,"coach")
	report.campaign = {"id":campaign,"seed":seed_value,"predeclared_seeds":[42000,42001,42002] if campaign == "predeclared-v1" else [42000],"all_results_retained":true}
	var file := FileAccess.open(report_path,FileAccess.WRITE)
	if file == null: push_error("report_write_failed"); quit(2); return
	file.store_string(JSON.stringify(report,"\t")); file.close()
	print("NATURAL_REPORT ",ProjectSettings.globalize_path(report_path)," completed=",report.get("completed",false)," readiness_programme_gate=",report.get("readiness_programme_gate",false)," first_free_five=",report.get("observed_first_free_five",false)," errors=",report.get("errors",[]))
	quit(0 if report.get("completed",false) and report.get("readiness_programme_gate",false) else 1)
func reclassify_preserved_sample() -> void:
	var destination := "user://natural-fast-42000-corrected-report.json"
	if FileAccess.file_exists(destination): push_error("preserve_existing_corrected_report"); quit(2); return
	var sources := {"original_report":"user://natural-fast-42000-report.json","snapshot":"user://natural-fast-42000-final.json","raw_log":"user://natural-fast-42000-run.log"}
	var provenance := {}
	for kind in sources:
		var path: String = sources[kind]
		if not FileAccess.file_exists(path): push_error("missing_reclassification_source:"+path); quit(2); return
		provenance[kind] = {"path":ProjectSettings.globalize_path(path),"sha256":FileAccess.get_sha256(path)}
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(sources.original_report))
	if not parsed is Dictionary: push_error("invalid_original_report"); quit(2); return
	var saved: Dictionary = load("res://src/persistence/save_repository.gd").load_save(sources.snapshot)
	if not saved.ok: push_error("snapshot_load_failed:"+str(saved.errors)); quit(2); return
	var classifier = load("res://scripts/natural_fast_acceptance_report.gd")
	var archive_report: Dictionary = classifier.archives(saved.career.competition_archive)
	var corrected: Dictionary = parsed.duplicate(true)
	corrected.natural_acceptance = archive_report
	var first: Dictionary = archive_report.first_archive
	var match_first: bool = not first.is_empty() and first.get("event_id") == corrected.first_attempt.get("event_id","missing")
	corrected.readiness_programme_gate = corrected.first_attempt.get("five_ready",false) and match_first and first.get("submitted_programme_five",false)
	corrected.observed_first_free_five = match_first and first.get("single_free_five",false)
	var source_hashes := {}
	for path in ["res://scripts/natural_fast_acceptance.gd","res://scripts/run_natural_fast_acceptance.gd","res://scripts/natural_fast_acceptance_report.gd","res://tests/scripts/test_natural_fast_acceptance.gd"]: source_hashes[path] = FileAccess.get_sha256(path)
	corrected.reporting_revision = {"revision":2,"scope":"pure_reclassification_of_same_preserved_final_snapshot_no_training_or_competition_rerun","sources":provenance,"current_source_sha256":source_hashes,"original_launch_source_sha256":{"driver":"868DCAF72202D55B110469627089BE8D2928A14FCDEAB849DE932894356D8051","cli":"27217459EEF1A045F2CC79ECFB4F4EB17B28146B53193CC4BF9C6AFB0319EBE6","report":"064CFDB69465235A7ADABE3D08AF5D9149A95C0F89C8130B4ACD287F846908F3","tests":"4759B9A52834EB79EB6818584EC1EC37872F78139C4D18E2A38E6BF53B7DB081"}}
	for kind in sources:
		if FileAccess.get_sha256(sources[kind]) != provenance[kind].sha256: push_error("reclassification_source_changed"); quit(2); return
	var output := FileAccess.open(destination,FileAccess.WRITE)
	if output == null: push_error("corrected_report_write_failed"); quit(2); return
	output.store_string(JSON.stringify(corrected,"\t")); output.close()
	print("NATURAL_RECLASSIFIED ",ProjectSettings.globalize_path(destination)," readiness_programme_gate=",corrected.readiness_programme_gate," first_free_five=",corrected.observed_first_free_five," no_trajectory_rerun=true")
	quit(0)
