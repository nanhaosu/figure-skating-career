extends SceneTree

const AthleteState = preload("res://src/domain/athlete_state.gd")
const RelationshipState = preload("res://src/domain/relationship_state.gd")
const CatalogRepository = preload("res://src/content/catalog_repository.gd")
const Generator = preload("res://src/simulation/pre_career_history_generator.gd")

func _init() -> void:
	call_deferred("_run")

func _run() -> void:
	var catalog := CatalogRepository.load_catalog()
	if not catalog.errors.is_empty():
		push_error("catalog invalid: %s" % catalog.errors)
		quit(1)
		return
	var report := {"paths": {}, "risk_cohorts": {}}
	for entry_id in catalog.backgrounds.entry_paths:
		var entry: Dictionary = catalog.backgrounds.entry_paths[entry_id]
		var family_id := str(entry.starting_relationship_id)
		var unlocked: Array[float] = []
		var loads: Array[float] = []
		var expression_total := 0.0
		var faults := 0
		var known_faults := 0
		var injuries := 0
		for seed in range(1000, 1200):
			var result := _generate(catalog, 2007, 4, seed, entry_id, family_id)
			unlocked.append(_unlocked_score(result.athlete))
			loads.append(float(result.athlete.body.impact_load))
			expression_total += float(result.athlete.mind.expression)
			var faulty := _has_fault(result.athlete)
			faults += int(faulty)
			known_faults += int(faulty and not result.history.known_observations.is_empty())
			injuries += int(not result.condition_state.injuries.is_empty())
		unlocked.sort()
		loads.sort()
		report.paths[entry_id] = {
			"mean_unlocked_rotations": _mean(unlocked),
			"unlock_percentiles": {"p25": _percentile(unlocked, 0.25), "p50": _percentile(unlocked, 0.50), "p75": _percentile(unlocked, 0.75)},
			"mean_expression": expression_total / 200.0,
			"fault_rate": float(faults) / 200.0,
			"known_fault_rate": float(known_faults) / 200.0,
			"load_percentiles": {"p50": _percentile(loads, 0.50), "p90": _percentile(loads, 0.90)},
			"injury_rate": float(injuries) / 200.0,
		}
	report.risk_cohorts.normal_interest_supportive = _injury_rate(catalog, 2007, 4, "entry_interest_class", "family_supportive", 2000, 2500)
	report.risk_cohorts.aggressive_club_ambitious = _injury_rate(catalog, 2006, 3, "entry_club_trial", "family_ambitious", 2000, 2500)
	print(JSON.stringify(report, "  "))
	quit(0)

func _generate(catalog: Dictionary, birth_year: int, start_age: int, seed: int, entry_id: String, family_id: String) -> Dictionary:
	var entry: Dictionary = catalog.backgrounds.entry_paths[entry_id]
	var family: Dictionary = catalog.backgrounds.family_profiles[family_id]
	var athlete := AthleteState.new("分布样本", birth_year, entry_id, family_id)
	var relationships := {
		"guardian": RelationshipState.new(float(family.emotional_support), float(family.industry_knowledge), float(family.control), float(family.health_priority)),
		"coach": RelationshipState.new(35.0, float(entry.technique_delta) + 30.0, 0.0, 75.0),
	}
	return Generator.generate(athlete, relationships, {"injuries": [], "notes": []}, birth_year, start_age, entry_id, family_id, seed, entry, family)

func _injury_rate(catalog: Dictionary, birth_year: int, start_age: int, entry_id: String, family_id: String, from_seed: int, to_seed: int) -> float:
	var count := 0
	for seed in range(from_seed, to_seed):
		count += int(not _generate(catalog, birth_year, start_age, seed, entry_id, family_id).condition_state.injuries.is_empty())
	return float(count) / float(to_seed - from_seed)

func _unlocked_score(athlete) -> float:
	var total := 0.0
	for jump in athlete.jumps.values(): total += float(jump.unlocked_rotations)
	return total

func _has_fault(athlete) -> bool:
	for jump_id in ["flip", "lutz"]:
		var jump = athlete.jumps[jump_id]
		if float(jump.takeoff.edge_quality) < 40.0 or float(jump.takeoff.prerotation) > 20.0 or float(jump.air.axis) < 40.0:
			return true
	return false

func _mean(values: Array[float]) -> float:
	var total := 0.0
	for value in values: total += value
	return total / float(values.size())

func _percentile(values: Array[float], proportion: float) -> float:
	if values.is_empty(): return 0.0
	return values[clampi(int(round(proportion * float(values.size() - 1))), 0, values.size() - 1)]
