extends SceneTree

const Factory = preload("res://src/simulation/career_factory.gd")
const Catalog = preload("res://src/content/catalog_repository.gd")
const Coach = preload("res://src/simulation/coach_training_plan_service.gd")
const Intent = preload("res://src/domain/training_intent.gd")
const Simulator = preload("res://src/simulation/career_simulator.gd")

func _initialize() -> void: call_deferred("run")

func jump_focus(id: String, family: String, rotations: int) -> Dictionary:
	return {"id":id,"kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":family,"rotations":rotations}]}}

func run() -> void:
	var catalog := Catalog.load_catalog()
	var routes := {
		"coach":[],
		"combo_execution":[],
		"recovery":[],
		"3A_expression":[jump_focus("axel","axel",3),{"id":"expression","kind":"musical_expression","target":{}}],
		"3A_4T":[jump_focus("axel","axel",3),jump_focus("toe","toe_loop",4)],
		"spin_steps":[{"id":"spin","kind":"spin","target":{}},{"id":"steps","kind":"steps","target":{}}],
		"expression_external":[{"id":"expression","kind":"musical_expression","target":{}}]}
	for route in routes:
		for seed_value in [1800,1801,1802]:
			var career = Factory.create("训练对照",2007,"entry_interest_class","family_supportive",seed_value,catalog,4).career
			career.training_direction.focuses = routes[route].duplicate(true)
			if route == "expression_external":
				var booking: Dictionary = load("res://src/simulation/external_training_service.gd").book(career,"expression_lab","expression","calibration:external")
				if not booking.ok: push_error(str(booking)); quit(1); return
			var executed := 0
			var stopped := ""
			for step in 32:
				if step == 8 and route == "combo_execution":
					var rules: Dictionary = load("res://src/content/internal_event_rules.gd").for_teaching_group("free")
					var draft: Dictionary = load("res://src/simulation/program_draft_service.gd").propose(career.athlete,"free",rules,{},seed_value)
					if draft.program != null and draft.errors.is_empty():
						career.active_programs.free = draft.program.to_dict()
						var rotation: int = mini(3,int(career.athlete.jumps.toe_loop.unlocked_rotations))
						career.training_direction.focuses = [{"id":"combo","kind":"new_difficulty","target":{"kind":"jump","parts":[{"jump_id":"toe_loop","rotations":rotation},{"jump_id":"toe_loop","rotations":rotation}]}},{"id":"execution","kind":"execution","target":{"segment":"free"}}]
				if step == 8 and route == "recovery":
					var best := {}
					var highest := 0
					for item in career.technical_repertoire.entries.values():
						if not bool(item.learned_history.get("ever_learned",false)): continue
						var difficulty := 0
						for part in item.action.parts: difficulty += int(part.rotations)
						if difficulty > highest: highest = difficulty; best = item.action
					if not best.is_empty(): career.training_direction.focuses = [{"id":"recovery","kind":"recovery","target":best.duplicate(true)}]
				if not career.condition_state.get("pending_decision",{}).is_empty():
					stopped = "major_medical_choice"
					break
				var built := Coach.build(career,Intent.create("accept").intent)
				if not built.errors.is_empty(): push_error(str(built.errors)); quit(1); return
				Simulator.advance_quarter(career,built.plan,catalog)
				executed += 1
			var attempts := {}
			for id in career.technical_repertoire.entries: attempts[id] = int(career.technical_repertoire.entries[id].learned_history.get("total_attempts",0))
			var unlocks := {}
			for id in career.athlete.jumps: unlocks[id] = career.athlete.jumps[id].unlocked_rotations
			print("FOCUS_SAMPLE ",JSON.stringify({"route":route,"seed":seed_value,"executed_quarters":executed,"stop":stopped,"unlocks":unlocks,"attempts":attempts,"expression":career.athlete.mind.expression,"skating":career.athlete.skating,"fatigue":career.athlete.body.acute_fatigue,"injuries":career.condition_state.injuries.size(),"scope":"training_only_not_dispatch_or_medal_evidence"}))
	quit()
